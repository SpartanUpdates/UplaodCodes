package com.xyz.vehiclemanager.rtoownerdetails.rtovehiclelicense.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.history.Model.LicenseHistory;
import com.xyz.vehiclemanager.history.Room.HistoryDatabase;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.rtoownerdetails.rtovehiclelicense.model.VehicleLicenseRoot;

import java.util.Calendar;
import java.util.List;

public class VehicleLicenseActivity extends AppCompatActivity implements View.OnClickListener {
    private Activity activity = VehicleLicenseActivity.this;
    private EditText input1, input2, input3, input4, edt_dob;
    private String id, licenseNumber, licenseHolderName, licenseDob, dateOfIssue, currentStatus, lastTransactionAt, validFrom,
            validTo, vehicleClass;
    private TextView tv_licenseNo, tv_dateOfBirth, tv_holderName, tv_dateOfIssue, tv_currentStatus, tv_lastTransactionAt,
            tv_validFrom, tv_validTo, tv_vehicleClass;
    private Button btn_search;
    private ImageView iv_reset;
    private String result;
    String resultTwo;
    private ImageView iv_back;
    private DatePickerDialog datePickerDialog;
    private ScrollView scrollView;
    private RtoDetailsInterface rtoDetailsInterface;
    private LinearLayout ll_vehiclelicenseData;
    private AppCompatDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_license);

        licenseNumber = getIntent().getStringExtra("licenseNumber");
        licenseHolderName = getIntent().getStringExtra("licenseHolderName");
        licenseDob = getIntent().getStringExtra("licenseDob");
        dateOfIssue = getIntent().getStringExtra("dateOfIssue");
        currentStatus = getIntent().getStringExtra("currentStatus");
        lastTransactionAt = getIntent().getStringExtra("lastTransactionAt");
        validFrom = getIntent().getStringExtra("validFrom");
        validTo = getIntent().getStringExtra("validTo");
        vehicleClass = getIntent().getStringExtra("vehicleClass");

        rtoDetailsInterface = RtoDetailsApiClient.getOwnerDetails().create(RtoDetailsInterface.class);
        BindView();
        PutAnalyticsEvent();
        SetClickListener();
        setDataFromHistory();
    }

    private void BindView() {
        iv_back = findViewById(R.id.iv_back);
        iv_reset = findViewById(R.id.iv_reset);
        input1 = findViewById(R.id.input1);
        input2 = findViewById(R.id.input2);
        input3 = findViewById(R.id.input3);
        input4 = findViewById(R.id.input4);

        edt_dob = findViewById(R.id.edt_dob);
        btn_search = findViewById(R.id.btn_search);
        tv_licenseNo = findViewById(R.id.tv_licenseNumber);
        tv_dateOfBirth = findViewById(R.id.tv_dob);
        tv_holderName = findViewById(R.id.tv_holderName);
        tv_dateOfIssue = findViewById(R.id.tv_dateOfIssue);
        tv_currentStatus = findViewById(R.id.tv_currentStatus);
        tv_lastTransactionAt = findViewById(R.id.tv_lastTransactionAt);
        tv_validFrom = findViewById(R.id.tv_validFrom);
        tv_validTo = findViewById(R.id.tv_validTo);
        tv_vehicleClass = findViewById(R.id.tv_vehicleClass);
        scrollView = findViewById(R.id.scrollView);
        scrollView.setScrollbarFadingEnabled(false);
        scrollView.setSmoothScrollingEnabled(true);
        ll_vehiclelicenseData = findViewById(R.id.ll_vehiclelicenseData);

        iv_reset.setOnClickListener(this);
        iv_back.setOnClickListener(this);
        btn_search.setOnClickListener(this);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VehicleLicenseActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void SetClickListener() {

        input1.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input1.getText().toString().length() == 2) {
                    input2.setText("");
                    input2.requestFocus();
                }
            }
        });

        input2.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input2.getText().toString().length() == 2) {
                    input3.setText("");
                    input3.requestFocus();
                }
            }
        });

        input3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (input3.getText().toString().length() == 4) {
                    input4.setText("");
                    input4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        input4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if (input4.length() == 6) {
                    View view = getCurrentFocus();
                    if (view != null) {
                        InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        edt_dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // calender class's instance and get current date , month and year from calender
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR); // current year
                int mMonth = c.get(Calendar.MONTH); // current month
                int mDay = c.get(Calendar.DAY_OF_MONTH); // current day
                // date picker dialog
                datePickerDialog = new DatePickerDialog(VehicleLicenseActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                edt_dob.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.getDatePicker().setCalendarViewShown(false);
                datePickerDialog.getDatePicker().setSpinnersShown(true);
                datePickerDialog.show();
            }
        });
    }

    private void setDataFromHistory() {
        if (licenseNumber != null) {
            ll_vehiclelicenseData.setVisibility(View.VISIBLE);
            input1.setText(licenseNumber.substring(0, 2));
            input2.setText(licenseNumber.substring(2, 4));
            input3.setText(licenseNumber.substring(4, 8));
            input4.setText(licenseNumber.substring(8, 15));

            edt_dob.setText(licenseDob);
            tv_licenseNo.setText(licenseNumber);
            tv_dateOfBirth.setText(licenseDob);
            tv_holderName.setText(licenseHolderName);
            tv_dateOfIssue.setText(dateOfIssue);
            tv_currentStatus.setText(currentStatus);
            tv_lastTransactionAt.setText(lastTransactionAt);
            tv_validFrom.setText(validFrom);
            tv_validTo.setText(validTo);
            tv_vehicleClass.setText(vehicleClass);

            input1.setEnabled(false);
            input2.setEnabled(false);
            input3.setEnabled(false);
            input4.setEnabled(false);
            edt_dob.setEnabled(false);
            btn_search.setEnabled(false);
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;

            case R.id.iv_reset:
                ResetData();
                break;

            case R.id.btn_search:
                GetData();
                break;
        }
    }

    private void ResetData() {
        tv_licenseNo.setText("");
        tv_dateOfBirth.setText("");
        tv_holderName.setText("");
        tv_dateOfIssue.setText("");
        tv_currentStatus.setText("");
        tv_lastTransactionAt.setText("");
        tv_validFrom.setText("");
        tv_validTo.setText("");
        tv_vehicleClass.setText("");
        edt_dob.setText("");
        input1.setText("");
        input2.setText("");
        input3.setText("");
        input4.setText("");
        scrollView.fullScroll(ScrollView.FOCUS_UP);
        btn_search.setEnabled(true);
        ll_vehiclelicenseData.setVisibility(View.GONE);
        input1.requestFocus();
    }

    private void GetData() {
        tv_licenseNo.setText("");
        tv_dateOfBirth.setText("");
        tv_holderName.setText("");
        tv_dateOfIssue.setText("");
        tv_currentStatus.setText("");
        tv_lastTransactionAt.setText("");
        tv_validFrom.setText("");
        tv_validTo.setText("");
        tv_vehicleClass.setText("");
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input3.getWindowToken(), 0);
        input3.clearFocus();
        if (!isConnected(this)) {
            Toast.makeText(this, "No Internet Connection", Toast.LENGTH_SHORT).show();
            return;
        }
        final String string = input1.getText().toString();
        final String string2 = input2.getText().toString();
        final String string3 = input3.getText().toString();
        final String string4 = input4.getText().toString();
        final String strdob = edt_dob.getText().toString();
        final StringBuilder sb = new StringBuilder();
        sb.append(string);
        sb.append(string2);
        sb.append(string3);
        sb.append(string4);
        result = sb.toString();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("&reg2=");
        resultTwo = sb2.toString();

        if (TextUtils.isEmpty(string)) {
            input1.setError("This should not be empty");
            input1.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string2)) {
            input2.setError("This should not be empty");
            input2.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string3)) {
            input3.setError("This should not be empty");
            input3.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(string4)) {
            input4.setError("This should not be empty");
            input4.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(strdob)) {
            edt_dob.setError("This should not be empty");
            return;
        }
        getVehicleLicenseData();
        scrollView.fullScroll(ScrollView.FOCUS_UP);

    }

    private void DialogAnimation() {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_dialog_search);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void getVehicleLicenseData() {
        Boolean checkExistOrNot = true;
        List<LicenseHistory> licenseHistoryList = HistoryDatabase.getDatabase(VehicleLicenseActivity.this).licenseHistoryDao().getLicenseHistory();
        for (int i = 0; i < licenseHistoryList.size(); i++) {
            if (licenseHistoryList.get(i).getLicenseNo().equals(result.toUpperCase())) {

                ll_vehiclelicenseData.setVisibility(View.VISIBLE);
                tv_licenseNo.setText(result);
                tv_dateOfBirth.setText(licenseHistoryList.get(i).getDob());
                tv_holderName.setText(licenseHistoryList.get(i).getHolderName());
                tv_dateOfIssue.setText(licenseHistoryList.get(i).getDateOfIssue());
                tv_currentStatus.setText(licenseHistoryList.get(i).getCurrentStatus());
                tv_lastTransactionAt.setText(licenseHistoryList.get(i).getLastTransactionAt());
                tv_validFrom.setText(licenseHistoryList.get(i).getValidFrom());
                tv_validTo.setText(licenseHistoryList.get(i).getValidTo());
                tv_vehicleClass.setText(licenseHistoryList.get(i).getVehicleClass());
                checkExistOrNot=false;
            }
        }
        if (checkExistOrNot) {
            DialogAnimation();
            String sDob = edt_dob.getText().toString().trim();
            Call<VehicleLicenseRoot> call = rtoDetailsInterface.getLicenseDetail(result, sDob);
            call.enqueue(new Callback<VehicleLicenseRoot>() {
                @Override
                public void onResponse(Call<VehicleLicenseRoot> call, Response<VehicleLicenseRoot> response) {

                    if (response.isSuccessful()) {
                        dialog.dismiss();
                        ll_vehiclelicenseData.setVisibility(View.VISIBLE);
                        btn_search.setEnabled(false);
                        VehicleLicenseRoot vehicleLicenseRoot = response.body();
                        String licenseNo = vehicleLicenseRoot.getDetails().getLicenseNo();
                        String dob = vehicleLicenseRoot.getDetails().getDob();
                        String holderName = vehicleLicenseRoot.getDetails().getHolderName();
                        String dateOfIssue = vehicleLicenseRoot.getDetails().getDateOfIssue();
                        String currentStatus = vehicleLicenseRoot.getDetails().getCurrentStatus();
                        String lastTransactionAt = vehicleLicenseRoot.getDetails().getLastTransactionAt();
                        String validFrom = vehicleLicenseRoot.getDetails().getValidFrom();
                        String validTo = vehicleLicenseRoot.getDetails().getValidTo();
                        String vehicleClass = vehicleLicenseRoot.getDetails().getVehicleClass();

                        tv_licenseNo.setText(licenseNo);
                        tv_dateOfBirth.setText(dob);
                        tv_holderName.setText(holderName);
                        tv_dateOfIssue.setText(dateOfIssue);
                        tv_currentStatus.setText(currentStatus);
                        tv_lastTransactionAt.setText(lastTransactionAt);
                        tv_validFrom.setText(validFrom);
                        tv_validTo.setText(validTo);
                        tv_vehicleClass.setText(vehicleClass);

                        //Insert
                        insertLicenseData(licenseNo, dob, holderName, dateOfIssue, currentStatus, lastTransactionAt, validFrom, validTo, vehicleClass);

                    } else {
                        btn_search.setEnabled(true);
                        dialog.dismiss();
                        ll_vehiclelicenseData.setVisibility(View.VISIBLE);
                        Toast.makeText(VehicleLicenseActivity.this, "Please enter valid license number", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<VehicleLicenseRoot> call, Throwable t) {
                    dialog.dismiss();
                    Toast.makeText(VehicleLicenseActivity.this, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void insertLicenseData(final String licenseNo, final String dob, final String holderName, final String dateOfIssue, final String currentStatus, final String lastTransactionAt, final String validFrom, final String validTo, final String vehicleClass) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                LicenseHistory licenseHistory = new LicenseHistory(licenseNo, dob, holderName, dateOfIssue, currentStatus, lastTransactionAt, validFrom, validTo, vehicleClass);
                HistoryDatabase.getDatabase(VehicleLicenseActivity.this).licenseHistoryDao().insertLicenseData(licenseHistory);
            }
        });
        thread.start();
    }

    public boolean isConnected(final Context context) {
        final ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        final NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting()) {
            final NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
            final NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(0);
            return (networkInfo2 != null && networkInfo2.isConnectedOrConnecting()) || (networkInfo != null && networkInfo.isConnectedOrConnecting());
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}