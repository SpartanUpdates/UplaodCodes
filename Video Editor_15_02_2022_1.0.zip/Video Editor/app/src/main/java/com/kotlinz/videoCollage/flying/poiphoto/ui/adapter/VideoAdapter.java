package com.kotlinz.videoCollage.flying.poiphoto.ui.adapter;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.kotlinz.videoCollage.flying.poiphoto.Util;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Video;
import com.kotlinz.videoeditor.R;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class VideoAdapter extends Adapter<VideoAdapter.VideoViewHolder> {
    private final String TAG;
    private Context context;
    private String from;
    private int height;
    private List<Video> mData;
    private int mMaxCount;
    private OnSelectedMaxListener mOnSelectedMaxListener;
    private OnSelectedTotalListener mOnSelectedTotalListener;
    private OnVideoSelectedListener mOnVideoSelectedListener;
    private OnVideoUnSelectedListener mOnVideoUnSelectedListener;
    private int mSelectedResId;
    private Set<Integer> mSelectedVideoPositions;
    private ArrayList<Video> mSelectedVideos;
    private boolean temp1;
    private boolean temp2;
    private int width;

    public interface OnSelectedMaxListener {
        void onSelectedMax();
    }

    public interface OnSelectedTotalListener {
        void onSelectedTotal();
    }

    public interface OnVideoSelectedListener {
        void onVideoSelected(Video video, int i);
    }

    public interface OnVideoUnSelectedListener {
        void onVideoUnSelected(Video video, int i);
    }

    public static class VideoViewHolder extends ViewHolder {
        ImageView mIvVideo;
        FrameLayout mMain;
        FrameLayout mShadow;
        TextView txtVideoDuration;

        public VideoViewHolder(View view) {
            super(view);
            this.mIvVideo = (ImageView) view.findViewById(R.id.iv_Video);
            this.mMain = (FrameLayout) view.findViewById(R.id.video_container);
            this.mShadow = (FrameLayout) view.findViewById(R.id.shadow);
            this.txtVideoDuration = (TextView) view.findViewById(R.id.txt_video_time);
        }
    }

    public VideoAdapter() {
        this.TAG = VideoAdapter.class.getSimpleName();
        this.mMaxCount = 10;
        this.mSelectedResId = R.color.photo_selected_shadow;
        this.temp1 = true;
        this.temp2 = true;
        this.mSelectedVideos = new ArrayList();
        this.mSelectedVideoPositions = new HashSet();
    }

    public VideoAdapter(Context context, String str) {
        this.TAG = VideoAdapter.class.getSimpleName();
        this.mMaxCount = 10;
        this.mSelectedResId = R.color.photo_selected_shadow;
        this.temp1 = true;
        this.temp2 = true;
        this.context = context;
        this.from = str;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.height = displayMetrics.heightPixels;
        this.width = displayMetrics.widthPixels;
        this.mSelectedVideos = new ArrayList();
        this.mSelectedVideoPositions = new HashSet();
    }

    public List<Video> getData() {
        return this.mData;
    }

    public void setData(List<Video> list) {
        this.mData = list;
    }

    public int getMaxCount() {
        return this.mMaxCount;
    }

    public void setMaxCount(int i) {
        this.mMaxCount = i;
    }

    public void setOnSelectedTotalListener(OnSelectedTotalListener onSelectedTotalListener) {
        this.mOnSelectedTotalListener = onSelectedTotalListener;
    }

    public void setOnSelectedMaxListener(OnSelectedMaxListener onSelectedMaxListener) {
        this.mOnSelectedMaxListener = onSelectedMaxListener;
    }

    public void setOnVideoSelectedListener(OnVideoSelectedListener onVideoSelectedListener) {
        this.mOnVideoSelectedListener = onVideoSelectedListener;
    }

    public void setOnVideoUnSelectedListener(OnVideoUnSelectedListener onVideoUnSelectedListener) {
        this.mOnVideoUnSelectedListener = onVideoUnSelectedListener;
    }

    public ArrayList<Video> getSelectedVideos() {
        return this.mSelectedVideos;
    }

    public ArrayList<String> getSelectedVideoPaths() {
        ArrayList arrayList = new ArrayList();
        Iterator it = this.mSelectedVideos.iterator();
        while (it.hasNext()) {
            arrayList.add(((Video) it.next()).getPath());
        }
        return arrayList;
    }

    public void refreshData(List<Video> list) {
        this.mData = list;
        this.mSelectedVideos.clear();
        notifyDataSetChanged();
    }

    public void reset() {
        this.mSelectedVideos.clear();
        this.mSelectedVideoPositions.clear();
        notifyDataSetChanged();
    }

    public VideoViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new VideoViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.poivideo_item_video, viewGroup, false));
    }

    public void onBindViewHolder(final VideoViewHolder videoViewHolder, int i) {
        LayoutParams layoutParams = videoViewHolder.mMain.getLayoutParams();
        if (this.from.equalsIgnoreCase("select")) {
            layoutParams.height = this.width / 4;
        } else {
            layoutParams.height = this.width / 3;
        }
        videoViewHolder.mMain.setLayoutParams(layoutParams);
        if (!this.mSelectedVideoPositions.contains(Integer.valueOf(i)) && videoViewHolder.mShadow.getVisibility() == View.VISIBLE) {
            videoViewHolder.mShadow.setVisibility(View.GONE);
        } else if (this.mSelectedVideoPositions.contains(Integer.valueOf(i)) && videoViewHolder.mShadow.getVisibility() != View.VISIBLE) {
            videoViewHolder.mShadow.setVisibility(View.VISIBLE);
        }
        String path = ((Video) this.mData.get(i)).getPath();
        videoViewHolder.txtVideoDuration.setText(convertSecondsToHMmSs(Long.valueOf(((Video) this.mData.get(i)).getDuration()).longValue()));
        ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load(path).skipMemoryCache(true)).placeholder(R.drawable.ic_baseline_image_24)).error(R.drawable.ic_baseline_image_24)).into(videoViewHolder.mIvVideo);

        videoViewHolder.itemView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                int adapterPosition = videoViewHolder.getAdapterPosition();
                if (VideoAdapter.this.mSelectedVideoPositions.contains(Integer.valueOf(adapterPosition))) {
                    if (VideoAdapter.this.temp1) {
                        VideoAdapter.this.temp1 = false;
                        VideoAdapter.this.mSelectedVideoPositions.remove(Integer.valueOf(adapterPosition));
                        VideoAdapter.this.mSelectedVideos.remove(VideoAdapter.this.mData.get(adapterPosition));
                        Util.selectedItemsCount--;
                        if (VideoAdapter.this.mOnVideoUnSelectedListener != null) {
                            VideoAdapter.this.mOnVideoUnSelectedListener.onVideoUnSelected((Video) VideoAdapter.this.mData.get(adapterPosition), adapterPosition);
                        }
                        videoViewHolder.mShadow.setVisibility(View.GONE);
                    }
                    new Handler().postDelayed(new Runnable() {
                        public void run() {
                            VideoAdapter.this.temp1 = true;
                        }
                    }, 300);
                } else if (VideoAdapter.this.from.equalsIgnoreCase("select")) {
                    if (Util.selectedItemsCount < 4) {
                        if (VideoAdapter.this.mSelectedVideoPositions.size() < VideoAdapter.this.mMaxCount) {
                            if (VideoAdapter.this.temp2) {
                                VideoAdapter.this.temp2 = false;
                                VideoAdapter.this.mSelectedVideoPositions.add(Integer.valueOf(adapterPosition));
                                VideoAdapter.this.mSelectedVideos.add(VideoAdapter.this.mData.get(adapterPosition));
                                if (VideoAdapter.this.mOnVideoSelectedListener != null) {
                                    VideoAdapter.this.mOnVideoSelectedListener.onVideoSelected((Video) VideoAdapter.this.mData.get(adapterPosition), adapterPosition);
                                }
                                Util.selectedItemsCount++;
                                videoViewHolder.mShadow.setVisibility(View.VISIBLE);
                            }
                            new Handler().postDelayed(new Runnable() {
                                public void run() {
                                    VideoAdapter.this.temp2 = true;
                                }
                            }, 300);
                        } else if (VideoAdapter.this.mOnSelectedMaxListener != null) {
                            VideoAdapter.this.mOnSelectedMaxListener.onSelectedMax();
                        }
                    } else if (VideoAdapter.this.mOnSelectedTotalListener != null) {
                        VideoAdapter.this.mOnSelectedTotalListener.onSelectedTotal();
                    }
                } else if (VideoAdapter.this.mSelectedVideoPositions.size() < VideoAdapter.this.mMaxCount) {
                    if (VideoAdapter.this.temp2) {
                        VideoAdapter.this.temp2 = false;
                        VideoAdapter.this.mSelectedVideoPositions.add(Integer.valueOf(adapterPosition));
                        VideoAdapter.this.mSelectedVideos.add(VideoAdapter.this.mData.get(adapterPosition));
                        if (VideoAdapter.this.mOnVideoSelectedListener != null) {
                            VideoAdapter.this.mOnVideoSelectedListener.onVideoSelected((Video) VideoAdapter.this.mData.get(adapterPosition), adapterPosition);
                        }
                        videoViewHolder.mShadow.setVisibility(View.VISIBLE);
                    }
                    new Handler().postDelayed(new Runnable() {
                        public void run() {
                            VideoAdapter.this.temp2 = true;
                        }
                    }, 300);
                } else if (VideoAdapter.this.mOnSelectedMaxListener != null) {
                    VideoAdapter.this.mOnSelectedMaxListener.onSelectedMax();
                }
            }
        });
    }

    public int getItemCount() {
        List list = this.mData;
        return list == null ? 0 : list.size();
    }

    public String convertSecondsToHMmSs(long j) {
        long toMinutes = TimeUnit.MILLISECONDS.toMinutes(j);
        j = TimeUnit.MILLISECONDS.toSeconds(j);
        return String.format("%02d:%02d", new Object[]{Long.valueOf(toMinutes), Long.valueOf(j)});
    }

    public void setSelectedResId(int i) {
        this.mSelectedResId = i;
    }
}
