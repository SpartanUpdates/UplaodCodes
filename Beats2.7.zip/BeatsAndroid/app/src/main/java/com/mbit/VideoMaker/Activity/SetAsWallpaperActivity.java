package com.mbit.VideoMaker.Activity;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.mbit.VideoMaker.R;

import java.io.File;
import java.io.IOException;

public class SetAsWallpaperActivity extends AppCompatActivity {

    Activity activity = SetAsWallpaperActivity.this;
    ImageView ivback;
    TextView tvTitle;
    ImageView ivshare, ivPreview;
    Button btnShareWallpapper;
    String PreviewPath;
    AdRequest adRequest;
    AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_as_wallpaper);
        if (getIntent() != null) {
            PreviewPath = getIntent().getStringExtra("PreviewPath");
        }
        BindView();
        loadAd();
        Glide.with(activity).load(PreviewPath).into(ivPreview);
    }

    private void loadAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    private void BindView() {
        ivback = findViewById(R.id.ivBack);
        tvTitle = findViewById(R.id.tv_title);
        ivshare = findViewById(R.id.ivWallpaperShare);
        ivPreview = findViewById(R.id.ivImagePreview);
        btnShareWallpapper = findViewById(R.id.btnSetAsWallpaper);
        Glide.with(activity).load(PreviewPath).into(ivPreview);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        ivshare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(PreviewPath);
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("image/*");
                intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.app_name));
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(getString(R.string.get_free_));
                stringBuilder.append(getString(R.string.app_name));
                stringBuilder.append(" Music at here : https://play.google.com/store/apps/details?id=");
                stringBuilder.append(getPackageName());
                intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                intent.putExtra("android.intent.extra.TITLE", "Beats Music : Particle.ly Video Status Maker");
                intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(activity, getPackageName(), file));
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, getString(R.string.wallpaper_share)));

            }
        });
        btnShareWallpapper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SetAsWallPapper(activity, PreviewPath);
            }
        });
    }

    private void SetAsWallPapper(Context context, String str) {
        if (!(context == null || str == null)) {
            WallpaperManager myWallpaperManager = WallpaperManager.getInstance(context);
            try {
                myWallpaperManager.setBitmap(BitmapFactory.decodeFile(str));
                Toast.makeText(context, context.getString(R.string.wallpaper_done), Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public void onBackPressed() {
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }
}
