package com.unitedvideosapp.photovideomaker.activity;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
