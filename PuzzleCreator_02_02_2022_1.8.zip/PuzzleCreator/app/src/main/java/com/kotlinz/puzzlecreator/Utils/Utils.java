package com.kotlinz.puzzlecreator.Utils;

import android.os.Environment;
import java.io.File;

public class Utils {
    public static final Utils INSTANCE;

    static {
        INSTANCE = new Utils();
    }


    public static void CreateDirectory() {
        try {
            String rootPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getAbsolutePath() + "/ Puzzle /";
            File root = new File(rootPath);
            if (!root.exists()) {
                root.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
