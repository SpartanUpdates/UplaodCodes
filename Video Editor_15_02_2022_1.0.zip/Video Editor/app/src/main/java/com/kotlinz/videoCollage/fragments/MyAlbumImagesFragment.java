package com.kotlinz.videoCollage.fragments;

import android.app.AlertDialog.Builder;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore.Images.Media;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.SelectActivity;
import com.kotlinz.videoCollage.ShareActivity;
import com.kotlinz.videoCollage.adpaters.MyAlbumPhotoAdapter;
import com.kotlinz.videoCollage.interfaces.MyAlbumPhotoAdapterCallBackInterface;
import com.kotlinz.videoCollage.models.Images;
import com.kotlinz.videoCollage.other.Util;
import com.kotlinz.videoCollage.puzzleview.FileUtils;
import com.kotlinz.videoeditor.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class MyAlbumImagesFragment extends Fragment {
    private MyAlbumPhotoAdapter adapter;
    private ImageView create;
    private ArrayList<Images> imagePaths = new ArrayList();
    private LinearLayout lineEmpty;
    private LinearLayout mainLinear;
    private Context myContext;
    private RecyclerView photoRecycler;

    public MyAlbumImagesFragment(Context context) {
        this.myContext = context;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.my_album_fragment_image, viewGroup, false);
        this.mainLinear = (LinearLayout) inflate.findViewById(R.id.myalbum_main_lin);
        this.photoRecycler = (RecyclerView) inflate.findViewById(R.id.myalbum_photo_list);
        this.lineEmpty = (LinearLayout) inflate.findViewById(R.id.myalbum_line_empty);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.img_album_create);
        this.create = imageView;
        imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyAlbumImagesFragment.this.startActivity(new Intent(MyAlbumImagesFragment.this.myContext, SelectActivity.class));
            }
        });
        Context context = getContext();
        this.myContext = context;
        getCreationFiles(FileUtils.getFolderName(context, "Photo"));
        this.photoRecycler.setLayoutManager(new GridLayoutManager(this.myContext, 2));
        MyAlbumPhotoAdapter myAlbumPhotoAdapter = new MyAlbumPhotoAdapter(this.myContext, this.imagePaths, new MyAlbumPhotoAdapterCallBackInterface() {
            public void itemClick(int i, String str) {
                Util.selectedTab = 0;
                Intent intent = new Intent(MyAlbumImagesFragment.this.myContext, ShareActivity.class);
                intent.putExtra("SELECTED_PATH", str);
                intent.putExtra("FROM", "MY ALBUM");
                MyAlbumImagesFragment.this.startActivity(intent);
            }

            public void itemShare(int i, String str) {
                MyAlbumImagesFragment.this.shareImage(str);
            }

            public void itemDelete(int i, String str) {
                MyAlbumImagesFragment.this.deleteConfirmationDialog(i, str);
            }
        });
        this.adapter = myAlbumPhotoAdapter;
        this.photoRecycler.setAdapter(myAlbumPhotoAdapter);
        if (this.imagePaths.size() <= 0) {
            this.photoRecycler.setVisibility(View.GONE);
            this.lineEmpty.setVisibility(View.VISIBLE);
        } else {
            this.photoRecycler.setVisibility(View.VISIBLE);
            this.lineEmpty.setVisibility(View.GONE);
        }
        return inflate;
    }

    public void getCreationFiles(String str) {
        File[] listFiles = new File(str).listFiles();
        if (listFiles != null && listFiles.length > 1) {
            Collections.sort(Arrays.asList(listFiles), new Comparator<File>() {
                public int compare(File file, File file2) {
                    long lastModified = file.lastModified();
                    long lastModified2 = file2.lastModified();
                    if (lastModified2 < lastModified) {
                        return -1;
                    }
                    return lastModified > lastModified2 ? 1 : 0;
                }
            });
        }
        if (listFiles != null) {
            for (File path : listFiles) {
                Images images = new Images();
                images.setPath(path.getPath());
                images.setChecked(false);
                this.imagePaths.add(images);
            }
        }
    }

    private void deleteConfirmationDialog(final int i, final String str) {
        String str2 = "No";
        new Builder(this.myContext).setMessage("Do you want to delete?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                if (new File(str).exists()) {
                    MyAlbumImagesFragment.this.imagePaths.remove(i);
                    if (MyAlbumImagesFragment.this.imagePaths.size() <= 0) {
                        MyAlbumImagesFragment.this.photoRecycler.setVisibility(View.GONE);
                        MyAlbumImagesFragment.this.lineEmpty.setVisibility(View.VISIBLE);
                    } else {
                        MyAlbumImagesFragment.this.photoRecycler.setVisibility(View.VISIBLE);
                        MyAlbumImagesFragment.this.lineEmpty.setVisibility(View.GONE);
                    }
                    MyAlbumImagesFragment.this.adapter.notifyDataSetChanged();
                    String str = "_id";
                    String[] strArr = new String[]{str};
                    String[] strArr2 = new String[]{str};
                    Uri uri = Media.EXTERNAL_CONTENT_URI;
                    ContentResolver contentResolver = MyAlbumImagesFragment.this.getActivity().getContentResolver();
                    Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
                    if (query != null) {
                        if (query.moveToFirst()) {
                            contentResolver.delete(ContentUris.withAppendedId(uri, query.getLong(query.getColumnIndexOrThrow(str))), null, null);
                        }
                        query.close();
                    }
                }
            }
        }).setNegativeButton(str2, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }

    private void shareImage(String str) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.SUBJECT", "Video Maker");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this.myContext, "com.kotlinz.videoeditor.provider", new File(str)));
        startActivity(Intent.createChooser(intent, "Where to Share?"));
    }
}
