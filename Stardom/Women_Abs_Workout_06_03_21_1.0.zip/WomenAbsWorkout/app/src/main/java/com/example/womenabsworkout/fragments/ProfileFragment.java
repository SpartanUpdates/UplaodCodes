package com.example.womenabsworkout.fragments;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.womenabsworkout.ConstantValues;
import com.example.womenabsworkout.R;
import com.example.womenabsworkout.activities.Activity_MyProfile;
import com.example.womenabsworkout.adapters.AllDayAdapter;
import com.example.womenabsworkout.adapters.WorkoutData;
import com.example.womenabsworkout.database.DatabaseOperations;
import com.example.womenabsworkout.newscreen.Library;
import com.example.womenabsworkout.receiver.NotificationReceiver;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.travijuu.numberpicker.library.Enums.ActionEnum;
import com.travijuu.numberpicker.library.Interface.ValueChangedListener;
import com.travijuu.numberpicker.library.NumberPicker;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;


public class ProfileFragment extends Fragment implements OnCheckedChangeListener {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public static boolean isSecond = true;

    public AllDayAdapter adapter;
    public ArrayList<String> arr = new ArrayList();
    public String b;
    public SharedPreferences c;
    public Context context;
    public int d = 25;
    public DatabaseOperations databaseOperations;
    public TextView dayleft;
    public int e = 15;
    public String exc_type;
    public String excercise_type;
    public SwitchCompat f;
    public Library f902a;
    public NumberPicker g;
    public NumberPicker h;
    public SharedPreferences i;
    public String j;
    public String k;
    public SimpleDateFormat l;
    public SimpleDateFormat m;
    public SharedPreferences mPreferences;
    public SharedPreferences mSharedPreferences;
    public int n;
    public Calendar o = Calendar.getInstance();
    public TextView percentScore1;
    public Editor prefsEditor;
    private TextView privacypolicy;
    private TextView profile;
    public ProgressBar progressBar;
    public RecyclerView recyclerView;
    private TextView reminder;
    private TextView reset;
    public List<WorkoutData> workoutDataList;
    AdView mAdView;
    private long getTimeFromDate(int i, int i2) {
        return (long) ((((i * 60) * 60) + (i2 * 60)) * 1000);
    }

    public static ProfileFragment newInstance(String str, String str2) {
        ProfileFragment profileFragment = new ProfileFragment();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_PARAM1, str);
        bundle.putString(ARG_PARAM2, str2);
        profileFragment.setArguments(bundle);
        return profileFragment;
    }

    private void setLayoutEnabledInit(Boolean bool) {
        isSecond = true;
    }

    public void shareApp() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/html");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("http://play.google.com/store/apps/details?id=");
        stringBuilder.append(getActivity().getPackageName());
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        startActivity(Intent.createChooser(intent, "Abs Workout For Women"));
    }

    private void updateSleepTimeEdit(Date date) {
        String format = this.l.format(date);
        this.k = format;
        this.f902a.saveString("getSleepTime", format, getActivity().getApplicationContext());
    }

    private void updateWakeTimeEdit(Date date) {
        String format = this.l.format(date);
        this.j = format;
        this.f902a.saveString("getWakeUpTime", format, getActivity().getApplicationContext());
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        Editor edit = this.mPreferences.edit();
        if (compoundButton.getId() == R.id.sound_switch) {
            String str = "sound";
            if (z) {
                edit.putInt(str, 1);
                Toast.makeText(getActivity(), "Sound is on!!", Toast.LENGTH_SHORT).show();
            } else {
                edit.putInt(str, 0);
            }
        }
        edit.apply();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.l = new SimpleDateFormat("hh:mm a");
        this.m = new SimpleDateFormat("HH:mm");
        this.context = getActivity();
        this.f902a = new Library(this.context);
        this.o.set(11, 10);
        this.o.set(12, 0);
        this.o.set(13, 0);
        updateWakeTimeEdit(this.o.getTime());
        this.o.set(11, 18);
        this.o.set(12, 0);
        this.o.set(13, 0);
        updateSleepTimeEdit(this.o.getTime());
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Log.d("fragments", "onCreateView-frofile-frag");

        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        this.mSharedPreferences = defaultSharedPreferences;
        this.prefsEditor = defaultSharedPreferences.edit();
        defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        this.c = defaultSharedPreferences;
        this.prefsEditor = defaultSharedPreferences.edit();
        this.exc_type = this.mSharedPreferences.getString("yoga_type", "beginner");
        this.context = getActivity();
        this.f902a = new Library(this.context);
        String string = this.c.getString("languageToLoad", "en");
        this.b = string;
        this.f902a.updateLocale(string);
        defaultSharedPreferences = ((FragmentActivity) Objects.requireNonNull(getActivity())).getSharedPreferences(getResources().getString(R.string.timer_fref_file_name), 0);
        this.mPreferences = defaultSharedPreferences;
        isSecond = false;
        this.n = defaultSharedPreferences.getInt("sound", 1);
        View inflate = layoutInflater.inflate(R.layout.fragment_profile, viewGroup, false);
        SwitchCompat switchCompat = (SwitchCompat) inflate.findViewById(R.id.sound_switch);
        this.f = switchCompat;
        switchCompat.setOnCheckedChangeListener(this);
        if (this.n == 1) {
            this.f.setChecked(true);
        } else {
            this.f.setChecked(false);
        }
        ((Toolbar) inflate.findViewById(R.id.mtoolbar)).setNavigationOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ProfileFragment.this.getActivity().onBackPressed();
            }
        });
        this.i = PreferenceManager.getDefaultSharedPreferences(getActivity());
        this.d = this.mPreferences.getInt("resttime", 15);
        this.e = this.mPreferences.getInt("readytimer", 10);
        NumberPicker numberPicker = (NumberPicker) inflate.findViewById(R.id.restTimeNumberPicker);
        this.h = numberPicker;
        numberPicker.setMin(3);
        this.h.setUnit(1);
        this.h.setValue(this.d);
        this.h.setValueChangedListener(new ValueChangedListener() {
            public void valueChanged(int i, ActionEnum actionEnum) {
                Editor edit = ProfileFragment.this.mPreferences.edit();
                edit.putInt("resttime", i);
                edit.apply();
            }
        });
        numberPicker = (NumberPicker) inflate.findViewById(R.id.countdownNumberPicker);
        this.g = numberPicker;
        numberPicker.setMax(35);
        this.g.setMin(5);
        this.g.setUnit(1);
        this.g.setValue(this.e);
        this.g.setValueChangedListener(new ValueChangedListener() {
            public void valueChanged(int i, ActionEnum actionEnum) {
                Editor edit = ProfileFragment.this.mPreferences.edit();
                edit.putInt("readytimer", i);
                edit.apply();
            }
        });
        TextView textView = (TextView) inflate.findViewById(R.id.myprofile);
        this.profile = textView;
        textView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ProfileFragment.this.startActivity(new Intent(ProfileFragment.this.getActivity(), Activity_MyProfile.class));
            }
        });
        textView = (TextView) inflate.findViewById(R.id.reminder);
        this.reminder = textView;
        textView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ProfileFragment.this.reminderpopup();
            }
        });
        RelativeLayout privacypolicy_layout=(RelativeLayout)inflate.findViewById(R.id.privacypolicy_layout);
        privacypolicy_layout.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String url = getResources().getString(R.string.privacy_policy);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        inflate.findViewById(R.id.rateus).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = "android.intent.action.VIEW";
                try {
                    ProfileFragment.this.getActivity().startActivity(new Intent(str, Uri.parse("market://details?id="+context.getPackageName())));
                } catch (ActivityNotFoundException unused) {
                    ProfileFragment.this.getActivity().startActivity(new Intent(str, Uri.parse("http://play.google.com/store/apps/details?id="+context.getPackageName())));
                }
            }
        });
        inflate.findViewById(R.id.share).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ProfileFragment.this.shareApp();
            }
        });
        textView = (TextView) inflate.findViewById(R.id.reset);
        this.reset = textView;
        textView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ProfileFragment.this.restartDialog();
            }
        });


        return inflate;
    }

    private void restartDialog() {
        final Dialog dialog = new Dialog(this.context, R.style.Theme_Dialog);
        try {
            dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        } catch (Exception e) {
            e.printStackTrace();
        }
        dialog.setContentView(R.layout.restart_confirm_addialog_layout);
        dialog.getWindow().setLayout(-1, -2);
        dialog.setCancelable(true);
        ((TextView) dialog.findViewById(R.id.btnYes)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                try {
                    dialog.dismiss();
                    Editor edit = PreferenceManager.getDefaultSharedPreferences(ProfileFragment.this.getActivity()).edit();
                    edit.clear();
                    edit.commit();
                    new DatabaseOperations(ProfileFragment.this.getActivity()).deleteTable();
                    ProfileFragment.this.getActivity().getSharedPreferences(ConstantValues.PREFS_NAME, 0).edit().clear().commit();
                    ProfileFragment.this.getActivity().finish();
                    System.exit(1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        ((TextView) dialog.findViewById(R.id.btnNo)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void reminderpopup() {
        final Dialog dialog = new Dialog(getContext());
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.reminder_popup);
        dialog.setCancelable(true);
        dialog.setOnCancelListener(new OnCancelListener() {
            public void onCancel(DialogInterface dialogInterface) {
            }
        });
        dialog.getWindow().setLayout(-1, -2);
        final TimePicker timePicker = (TimePicker) dialog.findViewById(R.id.datePicker1reminder);
        ((Button) dialog.findViewById(R.id.set_reminder)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = ":";
                String str2 = "ReminderCheck";
                String str3 = "notification_minute";
                String str4 = "notification_hour";
                try {
                    int hour;
                    int minute;
                    dialog.dismiss();
                    if (VERSION.SDK_INT >= 23) {
                        hour = timePicker.getHour();
                        minute = timePicker.getMinute();
                    } else {
                        hour = timePicker.getCurrentHour().intValue();
                        minute = timePicker.getCurrentMinute().intValue();
                    }
                    ProfileFragment.this.prefsEditor.putBoolean("user_selection", true);
                    ProfileFragment.this.prefsEditor.putInt(str4, hour);
                    ProfileFragment.this.prefsEditor.putInt(str3, minute);
                    Log.d(str2, "Reminder set in Main page");
                    ProfileFragment.this.prefsEditor.apply();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Reminder set in ");
                    stringBuilder.append(ProfileFragment.this.mSharedPreferences.getInt(str4, hour));
                    stringBuilder.append(str);
                    stringBuilder.append(ProfileFragment.this.mSharedPreferences.getInt(str3, minute));
                    stringBuilder.append(str);
                    stringBuilder.append(0);
                    Log.d(str2, stringBuilder.toString());
                    ProfileFragment.this.setAlarm(ProfileFragment.this.mSharedPreferences.getInt(str4, hour), ProfileFragment.this.mSharedPreferences.getInt(str3, minute), 0);
                    Toast.makeText(ProfileFragment.this.getActivity(), "Reminder Set Sucsessfully!", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        dialog.show();
    }

    @SuppressLint("WrongConstant")
    public void setAlarm(int i, int i2, int i3) {
        Calendar instance = Calendar.getInstance();
        instance.set(11, i);
        instance.set(12, i2);
        instance.set(13, i3);
        ((AlarmManager) getContext().getSystemService(NotificationCompat.CATEGORY_ALARM)).setRepeating(AlarmManager.RTC_WAKEUP, instance.getTimeInMillis(), 86400000, PendingIntent.getBroadcast(getContext(), 100, new Intent(getContext(), NotificationReceiver.class), 134217728));
    }

    public void onResume() {
        super.onResume();
        Log.d("fragments", "onResume-frofile-frag");
        this.d = this.mPreferences.getInt("resttime", 25);
        this.e = this.mPreferences.getInt("readytimer", 10);
        this.h.setValue(this.d);
        this.g.setValue(this.e);
    }

    public void onStart() {
        super.onStart();
        Log.d("fragments", "onResume-frofile-frag");
        this.h.setValue(this.d);
        this.g.setValue(this.e);
    }
}
