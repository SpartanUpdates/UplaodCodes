package com.vidsoft.videostatusmaker.Utils.gridview;

import android.view.*;
import java.util.*;

public class DynamicGridUtils
{
  public static float getViewX(final View view) {
    return Math.abs((view.getRight() - view.getLeft()) / 2);
  }

  public static float getViewY(final View view) {
    return Math.abs((view.getBottom() - view.getTop()) / 2);
  }

  public static void reorder(final List list, final int n, final int n2) {
    list.add(n2, list.remove(n));
  }

  public static void swap(final List list, final int n, final int n2) {
    final Object value = list.get(n);
    list.set(n, list.get(n2));
    list.set(n2, value);
  }
}
