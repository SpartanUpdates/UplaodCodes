package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;
import androidx.multidex.BuildConfig;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import com.bumptech.glide.Glide;
import com.vidsoft.collagemaker.Model.Frame;
import com.vidsoft.collagemaker.pipphotoeffect.R;

import java.util.ArrayList;

public class FrameAdapter extends Adapter<FrameAdapter.ViewHolder> {
    String Selection;
    Activity activity;
    ArrayList<Frame> list;

    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout border;
        ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.imageView = (ImageView) itemView.findViewById(R.id.imageView);
            this.border = (RelativeLayout) itemView.findViewById(R.id.rl_border);
        }
    }

    public FrameAdapter(Activity activity, ArrayList<Frame> list) {
        this.Selection = "0";
        this.list = list;
        this.activity = activity;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.frame_adapter, parent, false));
    }

    public void onBindViewHolder(ViewHolder holder, int position) {
        if (this.Selection.equals(BuildConfig.FLAVOR)) {
            holder.border.setVisibility(View.INVISIBLE);
        } else if (position == Integer.parseInt(this.Selection)) {
            holder.border.setVisibility(View.VISIBLE);
        } else {
            holder.border.setVisibility(View.INVISIBLE);
        }
        holder.setIsRecyclable(false);
        if (position == 0) {
            LayoutParams params = new LayoutParams(50, 50);
            params.addRule(13);
            holder.imageView.setLayoutParams(params);
        }
        Glide.with(this.activity).load(Integer.valueOf(((Frame) this.list.get(position)).getIcon())).into(holder.imageView);
    }

    public void selection(String pos) {
        this.Selection = pos;
    }

    public int getItemCount() {
        return this.list.size();
    }
}