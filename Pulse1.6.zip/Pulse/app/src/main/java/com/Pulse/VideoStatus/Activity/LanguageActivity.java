package com.Pulse.VideoStatus.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.Pulse.VideoStatus.Adapter.SelectLanguageAdapter;
import com.Pulse.VideoStatus.Extra.d;
import com.Pulse.VideoStatus.Extra.h;
import com.Pulse.VideoStatus.Model.LanguageModel;
import com.Pulse.VideoStatus.R;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class LanguageActivity extends AppCompatActivity {

    Activity activity = LanguageActivity.this;
    TextView tvSelectDone;
    RecyclerView rvlanguage;
    LinearLayout layoutRetry;
    RelativeLayout layoutLoading;
    AdRequest adRequest;
    AdView adView;
    GridLayoutManager gridLayoutManager;
    SelectLanguageAdapter languageAdapter;
    private ArrayList<LanguageModel> languageList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "LanguageActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
        BindView();
        AddLanguageList();
        loadAd();
        SetAdapter();
    }

    private void AddLanguageList() {
        languageList.add(0, new LanguageModel("63", "Rajashthahni"));
        languageList.add(1, new LanguageModel("55", "Malayalam"));
        languageList.add(2, new LanguageModel("62", "Marathi"));
        languageList.add(3, new LanguageModel("61", "Tamil"));
        languageList.add(4, new LanguageModel("57", "kannada"));
        languageList.add(5, new LanguageModel("60", "Telugu"));
        languageList.add(6, new LanguageModel("58", "Bengali"));
        languageList.add(7, new LanguageModel("59", "Bhojpuri"));
        languageList.add(8, new LanguageModel("56", "Islamic"));
        languageList.add(9, new LanguageModel("52", "English"));
        languageList.add(10, new LanguageModel("50", "Hindi"));
        languageList.add(11, new LanguageModel("53", "Gujarati"));
        languageList.add(12, new LanguageModel("64", "Punjabi"));
        SaveLanInPref(LanguageActivity.this, languageList);
    }

    private void BindView() {
        tvSelectDone = findViewById(R.id.tv_lan_select_done);
        rvlanguage = findViewById(R.id.rvLanguageList);
        layoutRetry = findViewById(R.id.llRetry);
        layoutLoading = findViewById(R.id.rl_loading_pager);
        tvSelectDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (languageList != null) {
                        final StringBuilder sb = new StringBuilder();
                        for (final LanguageModel languageModel : languageList) {
                            if (languageModel.d) {
                                sb.append(languageModel.LanId);
                                sb.append(",");
                            }
                        }
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append(sb.length());
                        Log.e("Lan", sb2.toString());
                        if (sb.length() != 0) {
                            if (!d.a(activity).a("pref_key_language_list", "1,2,3,4").equals(sb.substring(0, sb.length() - 1))) {
//                                if (MyApplication.q != null) {
//                                    MyApplication.q.finish();
//                                }
                                h.b();
                            }
                            d.a(activity).c("pref_key_language_list", sb.substring(0, sb.length() - 1));
                            d.a(activity).b("pref_key_is_language_set", true);
                            startActivity(new Intent(activity, HomeActivity.class));
                            finish();
                            return;
                        }
                        Toast.makeText(activity, "Please Select any language", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception ex) {
                    final StringBuilder sb3 = new StringBuilder("Error : ");
                    sb3.append(ex.getMessage());
                    Log.e("LangError", sb3.toString());
                    ex.printStackTrace();
                }
            }
        });
    }

    private void SaveLanInPref(LanguageActivity selectCountryAndLanguage, final ArrayList<LanguageModel> list) {
        final String[] split = d.a(selectCountryAndLanguage).a("pref_key_language_list", "50").split(",");
        languageList = new ArrayList<>();
        for (int length = split.length, i = 0; i < length; ++i) {
            Log.e("TAG", "Language Split" + split[i]);
        }
        for (final LanguageModel languageModel : list) {
            languageModel.d = Arrays.asList(split).contains(String.valueOf(languageModel.LanId));
            languageList.add(languageModel);
        }
        Collections.sort(languageList, new Comparator<LanguageModel>() {

            @Override
            public int compare(LanguageModel obj, LanguageModel obj2) {
                return Boolean.compare(obj2.d, obj.d);
            }
        });
    }

    private void SetAdapter() {
        gridLayoutManager = new GridLayoutManager(activity, 2);
        languageAdapter = new SelectLanguageAdapter(activity, languageList);
        rvlanguage.setLayoutManager(gridLayoutManager);
        rvlanguage.setAdapter(languageAdapter);
    }

    private void loadAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    public void onBackPressed() {
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }
}
