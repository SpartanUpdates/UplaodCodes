package com.esc.phoneheart.utility;

import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ForegroundCheck implements ActivityLifecycleCallbacks {
    public static final long CHECK_DELAY = 500;
    public static final String TAG = ForegroundCheck.class.getName();
    public static ForegroundCheck instance;
    public Runnable check;
    public boolean foreground = false;
    public Handler handler = new Handler();
    public List<Listener> listeners = new CopyOnWriteArrayList();
    public boolean paused = true;

    public interface Listener {
        void onBecameBackground();

        void onBecameForeground();
    }

    public static ForegroundCheck get(Application application) {
        if (instance == null) {
            init(application);
        }
        return instance;
    }

    public static ForegroundCheck init(Application application) {
        if (instance == null) {
            ForegroundCheck foregroundCheck = new ForegroundCheck();
            instance = foregroundCheck;
            application.registerActivityLifecycleCallbacks(foregroundCheck);
        }
        return instance;
    }

    public void addListener(Listener listener) {
        this.listeners.add(listener);
    }

    public boolean isBackground() {
        return this.foreground;
    }

    public boolean isForeground() {
        return this.foreground;
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
        this.paused = true;
        Runnable runnable = this.check;
        if (runnable != null) {
            this.handler.removeCallbacks(runnable);
        }
        Handler handler = this.handler;
        Runnable runnable1 = new Runnable() {
            public void run() {
                if (ForegroundCheck.this.foreground && ForegroundCheck.this.paused) {
                    ForegroundCheck.this.foreground = false;
                    Log.i(ForegroundCheck.TAG, "went background");
                    for (Listener onBecameBackground : ForegroundCheck.this.listeners) {
                        try {
                            onBecameBackground.onBecameBackground();
                        } catch (Exception e) {
                            Log.e(ForegroundCheck.TAG, "Listener threw exception!", e);
                        }
                    }
                    return;
                }
                Log.i(ForegroundCheck.TAG, "still foreground");
            }
        };
        this.check = runnable1;
        handler.postDelayed(runnable1, 500);
    }

    public void onActivityResumed(Activity activity) {
        paused = false;
        boolean i = this.foreground;
        foreground = true;
        Runnable runnable = this.check;
        if (runnable != null) {
            this.handler.removeCallbacks(runnable);
        }
        if (i) {
            Log.i(TAG, "went foreground");
            for (Listener onBecameForeground : this.listeners) {
                try {
                    onBecameForeground.onBecameForeground();
                } catch (Exception e) {
                    Log.e(TAG, "Listener threw exception!", e);
                }
            }
            return;
        }
        Log.i(TAG, "still foreground");
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity) {
    }

    public void onActivityStopped(Activity activity) {
    }

    public void removeListener(Listener listener) {
        this.listeners.remove(listener);
    }

    public static ForegroundCheck get(Context context) {
        ForegroundCheck foregroundCheck = instance;
        if (foregroundCheck != null) {
            return foregroundCheck;
        }
        context = context.getApplicationContext();
        if (context instanceof Application) {
            init((Application) context);
        }
        throw new IllegalStateException("Foreground is not initialised and cannot obtain the Application object");
    }

    public static ForegroundCheck get() {
        if (instance == null) {
            instance = new ForegroundCheck();
        }
        return instance;
    }
}
