package com.example.lyricsvideo.PickImages;

import android.content.Context;
import android.content.Intent;
import com.example.lyricsvideo.activity.SelectImageActivity;
import com.example.lyricsvideo.application.App;

public class ImageSelectionUsage {
    private static Context mContext;

    public ImageSelectionUsage(Context context) {
        mContext = context;
    }

    public static ImageSelectionUsage getInstance(Context context) {
        return new ImageSelectionUsage(context);
    }

    public static Context getUseContext() {
        return mContext;
    }

    public static void pickImages(int width, int hight, int TotalNoOfImage,boolean IsFromMytemplateVideo) {
        App.TotalSelectedImage = TotalNoOfImage;
        Intent i = new Intent(mContext, SelectImageActivity.class);
        i.putExtra("ImageHight", hight);
        i.putExtra("Imagewidth", width);
        i.putExtra("IsFromMyTemplateVideo", IsFromMytemplateVideo);
        mContext.startActivity(i);
    }
}
