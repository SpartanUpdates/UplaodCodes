package com.vidsoft.uvideostatus.Utility;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import androidx.viewpager.widget.ViewPager;

public class CustomViewPager extends ViewPager {
    private int childId;

    public CustomViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int i = this.childId;
        if (i > 0) {
            ViewPager viewPager = (ViewPager) findViewById(i);
            if (viewPager != null) {
                viewPager.requestDisallowInterceptTouchEvent(true);
            }
        }
        return super.onInterceptTouchEvent(motionEvent);
    }

    public void setChildId(int i) {
        this.childId = i;
    }
}
