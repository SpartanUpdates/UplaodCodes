package com.Pulse.VideoStatus.Model;

public class LanguageModel {
    public String LanId;
    public String LanName;
    public boolean d;

    public LanguageModel(String lanId, String lanName) {
        LanId = lanId;
        LanName = lanName;
    }

    public String getLanId() {
        return LanId;
    }

    public void setLanId(String lanId) {
        LanId = lanId;
    }

    public String getLanName() {
        return LanName;
    }

    public void setLanName(String lanName) {
        LanName = lanName;
    }
}
