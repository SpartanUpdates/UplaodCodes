package com.jenilcreation.photomusicvideo.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.jenilcreation.photomusicvideo.MyApplication;
import com.jenilcreation.photomusicvideo.R;
import com.jenilcreation.photomusicvideo.adapters.DefaultSongtAdapter;
import com.videolib.libffmpeg.FileUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class DefaultSongActivity extends Activity {

    final int[] SongList = new int[]
            {R.raw.birthday_music,
                    R.raw.color_party_music,
                    R.raw.dubstep_music,
                    R.raw.energy_beat_music,
                    R.raw.funday_music};
    Activity activity = DefaultSongActivity.this;
    ImageView ivback;
    TextView tvdone;
    AppCompatButton btnFromStorage;
    ListView lvDefaultSong;
    MediaPlayer Mplayer;
    String SongPath;
    DefaultSongtAdapter defaultSongtAdapter;
    ArrayList<String> songNameList;
    private MyApplication application;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_default_song);
        bindView();
        init();
        PutAnalyticsEvent();
        defaultSongtAdapter = new DefaultSongtAdapter(activity, this.songNameList);
        lvDefaultSong.setAdapter(this.defaultSongtAdapter);
    }

    private void init() {
        application = MyApplication.getInstance();
        songNameList = new ArrayList<>();
        songNameList.add("Birthday Music");
        songNameList.add("Color Party Music");
        songNameList.add("Dubstep Music");
        songNameList.add("Energy Beat Music");
        songNameList.add("Funday Music");

        btnFromStorage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (application.getMusicFiles(false).size() > 0) {
                    stopPlaying(Mplayer);
                    startActivityForResult(new Intent(activity, (Class) EditSongActivity.class), 101);
                    return;
                }
                Toast.makeText(activity, "No Music found in device\nPlease add music in sdCard", Toast.LENGTH_LONG).show();
            }
        });
        tvdone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopPlaying(Mplayer);
                new SelectSong().start();

            }
        });
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void bindView() {
        toolbar = findViewById(R.id.toolbar);
        lvDefaultSong = findViewById(R.id.lv_default_song);
        btnFromStorage = findViewById(R.id.btnFromStorage);
        tvdone = findViewById(R.id.tv_done);
        ivback = findViewById(R.id.ivBack);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "DefaultSongActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }
    @Override
    protected void onPause() {
        super.onPause();
        stopPlaying(Mplayer);
    }

    private void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setMusic(int pos) {
        this.SongPath = "android.resource://" + getPackageName() + "/" + this.SongList[pos];
        this.application.posForAddMusicDialog = pos;
        stopPlaying(this.Mplayer);
        this.Mplayer = MediaPlayer.create(this, this.SongList[pos]);
        this.Mplayer.start();
    }

    public void SetMusic() {
        try {
            FileUtils.TEMP_DIRECTORY_AUDIO.mkdirs();
            String path = FileUtils.TEMP_DIRECTORY_AUDIO.getAbsolutePath();
            File dir = new File(path);
            if (dir.mkdirs() || dir.isDirectory()) {
                String str_song_name = "temp.mp3";
                CopyRAWtoSDCard(SongList[this.application.posForAddMusicDialog], path + File.separator + str_song_name);
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("TAG", "setMusic: " + e.getMessage());
        }

    }

    private void CopyRAWtoSDCard(int id, String path) throws IOException {
        InputStream in = getResources().openRawResource(id);
        FileOutputStream out = new FileOutputStream(path);
        byte[] buff = new byte[1024];
        int read = 0;
        try {
            while ((read = in.read(buff)) > 0) {
                out.write(buff, 0, read);
            }
        } finally {
            in.close();
            out.close();
        }
    }

    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        final StringBuilder sb = new StringBuilder();
        sb.append("Default Song act onact result requestcode ");
        sb.append(n);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("Default Song act onact result resultcode ");
        sb2.append(n2);
        if (n2 == -1) {
            if (n != 101) {
                return;
            }
            this.setResult(-1);
            this.finish();
        }
    }

    public void onBackPressed() {
        stopPlaying(this.Mplayer);
        super.onBackPressed();
    }

    public class SelectSong extends Thread {
        @Override
        public void run() {
            activity.runOnUiThread((Runnable) new Runnable() {
                @Override
                public void run() {
                    SetMusic();
                    setResult(-1, new Intent((Context) DefaultSongActivity.this, (Class) PreviewActivity.class));
                    finish();
                }
            });
        }
    }
}
