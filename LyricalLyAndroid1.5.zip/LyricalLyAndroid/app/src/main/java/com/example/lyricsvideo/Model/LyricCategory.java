package com.example.lyricsvideo.Model;

public class LyricCategory {
    private String tabcategoryid ,name;

    public String getTabcategoryid() {
        return tabcategoryid;
    }

    public void setTabcategoryid(String tabcategoryid) {
        this.tabcategoryid = tabcategoryid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
