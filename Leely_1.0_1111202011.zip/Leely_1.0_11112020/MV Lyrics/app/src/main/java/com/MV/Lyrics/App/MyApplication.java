package com.MV.Lyrics.App;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import com.MV.Lyrics.CropImage.Model.CropImage;
import com.MV.Lyrics.ExitApplication.activity.ExitAppActivity;
import com.MV.Lyrics.MyStudio.activity.YourVideoActivity;
import com.MV.Lyrics.R;
import com.MV.Lyrics.Retrofit.AppConstant;
import com.MV.Lyrics.SelectImage.Model.ImageModel;
import com.MV.Lyrics.UnityPlayerActivity;
import com.MV.Lyrics.VideoPlay.activity.VideoPlayer;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.gson.JsonObject;
import com.root.UnitySendValue.AndroidUnityCall;
import com.unity3d.player.UnityPlayer;
import java.util.ArrayList;
import retrofit2.Call;


public class MyApplication extends Application {

    public static int TotalSelectedImage;
    public static boolean IsSelectImageFrom = false;
    public static boolean IsCropedImageFrom = false;
    public static boolean IsCropedExists = false;
    public static String SPLIT_PATTERN;
    public static String AppName = "Leely";
    private static MyApplication instance;
    public static Context mContext;
    public boolean isSettingEnable;
    public final ArrayList<ImageModel> selectedImages;
    public final ArrayList<CropImage> cropimaglist;

    //Partical Selected position
    public static String ThemeAssetSelectedPosition ="";
    public static String AllFilePath;
    public static String LyricsPath;


    //Video Recording
    public static boolean IsSongCuttingready = false;
    public static boolean IsVideoready = false;
    public static boolean IsAudioVideoMearge = false;
    public static String CutSongPath;


    /*Created Video path*/
    public static String VideoPath;

    public static boolean isEditCall = false;
    public static Call<JsonObject> Tempcall;

    public static int ThemePosition = -1;
    public static int CatSelectedPosition = -1;


    public static InterstitialAd mInterstitialAd;
    public static int AdsId;
    public static Activity AdsShowContext;

    public String CropImages = "";

    public static boolean IsHomeInterstitialAdsDisplay = false;

    public static Context PreviewContext;

    public static boolean IsNotification = true;


    static {
        MyApplication.TotalSelectedImage = 1;
        MyApplication.SPLIT_PATTERN = "?";
    }

    public MyApplication() {
        selectedImages = new ArrayList<ImageModel>();
        cropimaglist = new ArrayList<CropImage>();
    }

    public static MyApplication getInstance() {
        return MyApplication.instance;

    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        MyApplication.mContext = this.getApplicationContext();
        MobileAds.initialize(MyApplication.mContext, MyApplication.mContext.getResources().getString(R.string.admob_app_id));
        LoadInterstitialAd();
    }

    public static String getFileName(String str) {
        return str.substring(str.lastIndexOf("/") + 1);
    }

    public ArrayList<ImageModel> getSelectedImages() {
        return this.selectedImages;
    }

    public void addSelectedImage(final ImageModel imageData) {
        this.selectedImages.add(imageData);
        ++imageData.imageCount;
    }

    public void removeSelectedImage(final int imageData) {
        if (imageData <= this.selectedImages.size()) {
            final ImageModel imageData2 = this.selectedImages.remove(imageData);
            --imageData2.imageCount;
        }
    }

    public void ReplaceSelectedImage(ImageModel imageData, int pos) {
        this.selectedImages.set(pos, imageData);
    }

    //Image Crop
    public ArrayList<CropImage> getCropImages() {
        return this.cropimaglist;
    }

    public void AddCropImages(CropImage imageData) {
        this.cropimaglist.add(imageData);

    }

    public void ReplaceCropImages(ImageModel imageData, int pos) {
        this.selectedImages.set(pos, imageData);
    }

    public void removecropImage(int imageData) {
        cropimaglist.remove(imageData);

    }

    private void LoadInterstitialAd() {
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (AdsId) {
                    case 1:
                        ImageCorp();
                        break;
                    case 2:
                        GoToExit();
                        break;
                    case 3:
                        CloseVideoPlayer();
                        break;
                    case 6:
                        break;
                    case 7:
                        GoToPreview();
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    private void requestNewInterstitial() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void ImageCorp() {
        for (int i = 0; i < this.getCropImages().size(); ++i) {
            if (i == 0) {
                CropImages = this.getCropImages().get(i).a();
            } else {
                CropImages = String.valueOf(CropImages) + MyApplication.SPLIT_PATTERN + this.getCropImages().get(i).a();
            }
        }
        String UnitySendValue = CropImages + MyApplication.SPLIT_PATTERN + AppConstant.AspectRatioUnity + MyApplication.SPLIT_PATTERN + AppConstant.ImagePath + MyApplication.SPLIT_PATTERN + AppConstant.IsNew;
        UnityPlayer.UnitySendMessage("AppManager", "GetUserImage", UnitySendValue);
        AdsShowContext.finish();
    }

    private void GoToExit() {
        Intent intent = new Intent(AdsShowContext, ExitAppActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        AdsShowContext.finish();
    }

    private void CloseVideoPlayer() {
        if (VideoPlayer.IsFromAndroidlist) {
            Intent intent = new Intent(this, YourVideoActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            AdsShowContext.finish();
        } else {
            AndroidUnityCall.ScanVideoList(AdsShowContext, MyApplication.VideoPath);
            Intent intent = new Intent(this, YourVideoActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            AdsShowContext.finish();
        }
    }

    public void GoToPreview() {
        UnityPlayer.UnitySendMessage("AppManager", "GetBundleData", MyApplication.AllFilePath);
        HideShowUnityBannerAds();
        AdsShowContext.finish();
    }

    private void HideShowUnityBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
