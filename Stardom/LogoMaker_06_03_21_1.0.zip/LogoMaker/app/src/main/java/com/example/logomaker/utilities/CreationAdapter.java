package com.example.logomaker.utilities;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.logomaker.R;

import java.io.File;

public class CreationAdapter extends RecyclerView.Adapter<CreationAdapter.ViewHolder> {
    File[] files;
    Context context;
    private int[] items;

    public CreationAdapter(Context context, File[] totalFiles) {
        this.context = context;
        this.files = totalFiles;
        notifyDataSetChanged();
    }

    public CreationAdapter(Context context, int[] iArr)
    {
        this.context = context;
        this.items = iArr;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        ImageView img_logoo, img_delete, img_share;

        public ViewHolder(@NonNull View view) {
            super(view);
            img_logoo = view.findViewById(R.id.img_logoo);
           /* img_delete = view.findViewById(R.id.img_delete);
            img_share = view.findViewById(R.id.img_share);*/
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.creation_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        Log.e("fffffff", String.valueOf(files.length));

        if (this.items == null)
        {
            Glide.with(this.context).load(this.files[position]).into(holder.img_logoo);
        }
        else
        {
            Glide.with(this.context).load(Integer.valueOf(this.items[position])).into(holder.img_logoo);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(context, MyCardsSlider.class);
                intent.putExtra(Constants.SELECTED_ITEM, files);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        int[] iArr = this.items;
        if (iArr == null) {
            return this.files.length;
        }
        return iArr.length;
    }

    public void removeAt(int positionn)
    {
        files[positionn].delete();
        notifyDataSetChanged();
        notifyItemRangeChanged(positionn, files.length);
    }
}
