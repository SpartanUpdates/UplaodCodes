package com.mbit.VideoMaker.Model;

public class SongInfo {
    public String SongDownloadUri = "";
    public int counter;
    public float down_prg = 0.0f;
    public boolean isAvailableOffline = true;
    public boolean isDownloading = false;
    public long SongtrackId;
    public String SongTitle;
    public String SongTrackData;
    public String SongDisplayName;
    public long SongDuration;

    public long getSongtrackId() {
        return this.SongtrackId;
    }

    public void setSongtrackId(long j) {
        this.SongtrackId = j;
    }

    public long getSongDuration() {
        return this.SongDuration;
    }

    public void setSongDuration(long j) {
        this.SongDuration = j;
    }

    public String getSongTitle() {
        return this.SongTitle;
    }

    public void setSongTitle(String str) {
        this.SongTitle = str;
    }

    public String getSongTrackData() {
        return this.SongTrackData;
    }

    public void setSongTrackData(String str) {
        this.SongTrackData = str;
    }

    public String getSongDisplayName() {
        return this.SongDisplayName;
    }

    public void setSongDisplayName(String str) {
        this.SongDisplayName = str;
    }
}
