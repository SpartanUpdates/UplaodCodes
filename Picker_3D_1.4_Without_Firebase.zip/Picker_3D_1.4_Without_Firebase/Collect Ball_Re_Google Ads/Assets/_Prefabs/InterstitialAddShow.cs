﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using GoogleMobileAds.Api;
using UnityEngine.Analytics;

namespace BallCollect
{
    public class InterstitialAddShow : MonoBehaviour
    {
        public static InterstitialAddShow instance;
        
        [HideInInspector]
        public InterstitialAd interstitial;

        public void Awake()
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
            RequestInterstitial();            
        }
        private void OnDisable()
        {
            this.interstitial.OnAdLoaded -= OnIAdLoaded;
            this.interstitial.OnAdFailedToLoad -= OnIAdFailedToLoad;
            this.interstitial.OnAdOpening -= OnIAdOpened;
            this.interstitial.OnAdClosed -= OnIAdClosed;
            this.interstitial.OnAdLeavingApplication -= OnIAdLeavingApplication;
        }
        public void RequestInterstitial()
        {
            interstitial = new InterstitialAd(Manager.instance.interstitialId);

            this.interstitial.OnAdLoaded += OnIAdLoaded;
            this.interstitial.OnAdFailedToLoad += OnIAdFailedToLoad;
            this.interstitial.OnAdOpening += OnIAdOpened;
            this.interstitial.OnAdClosed += OnIAdClosed;
            this.interstitial.OnAdLeavingApplication += OnIAdLeavingApplication;

            AdRequest request = new AdRequest.Builder().Build();

            interstitial.LoadAd(request);
            Analytics.CustomEvent("Interstitial_Ads_Request_Fire");
        }

      
        public void ShowInterstitial()
        {
            interstitial.Show();
            Analytics.CustomEvent("Interstitial_Ads_Show");
        }
       

        public void OnIAdLoaded(object sender, EventArgs args)
        {
        }

        public void OnIAdFailedToLoad(object sender, AdFailedToLoadEventArgs args)
        {
            Analytics.CustomEvent("Interstitial_Ads_Request_Fail");
        }

        public void OnIAdOpened(object sender, EventArgs args)
        {
        }

        public void OnIAdClosed(object sender, EventArgs args)
        {
            GameController.instance.noAddInter.SetActive(true);
            if (GameController.instance.isLCompleteClick)
            {
                GameController.instance.LevelCompletedAfter();
                Analytics.CustomEvent("Level_Completed_Interstitial_Ads_Close");
            }
            if (GameController.instance.isRestartClick)
            {
                GameController.instance.BtnRestartAfter();
                Analytics.CustomEvent("Restart_Click_Interstitial_Ads_Close");
            }
            if (GameController.instance.isHomeClick)
            {
                GameController.instance.BtnHomeAfter();
                Analytics.CustomEvent("Home_Interstitial_Ads_Close");
            }
            RequestInterstitial();
            Analytics.CustomEvent("Interstitial_Ads_Close");
        }

        public void OnIAdLeavingApplication(object sender, EventArgs args)
        {

        }
    }
}