package com.esc.fontappstylish.utils;

import android.content.Context;
import android.os.Build.VERSION;
import com.esc.fontappstylish.FontColl.Aani1;
import com.esc.fontappstylish.FontColl.Aani2;
import com.esc.fontappstylish.FontColl.Aani4;
import com.esc.fontappstylish.FontColl.Aani7;
import com.esc.fontappstylish.FontColl.Aani8;
import com.esc.fontappstylish.FontColl.Aani9;
import com.esc.fontappstylish.FontColl.ChorasFilled;
import com.esc.fontappstylish.FontColl.ChorasOutline;
import com.esc.fontappstylish.FontColl.Comic;
import com.esc.fontappstylish.FontColl.Emoji;
import com.esc.fontappstylish.FontColl.Emoji7;
import com.esc.fontappstylish.FontColl.Font_1;
import com.esc.fontappstylish.FontColl.Font_10;
import com.esc.fontappstylish.FontColl.Font_2;
import com.esc.fontappstylish.FontColl.Font_3;
import com.esc.fontappstylish.FontColl.Font_4;
import com.esc.fontappstylish.FontColl.Font_5;
import com.esc.fontappstylish.FontColl.Font_6;
import com.esc.fontappstylish.FontColl.Font_7;
import com.esc.fontappstylish.FontColl.Font_8;
import com.esc.fontappstylish.FontColl.Font_9;
import com.esc.fontappstylish.FontColl.FoodEmoji;
import com.esc.fontappstylish.FontColl.FoodEmoji2;
import com.esc.fontappstylish.FontColl.GolFilled;
import com.esc.fontappstylish.FontColl.GolOutline;
import com.esc.fontappstylish.FontColl.Gothic;
import com.esc.fontappstylish.FontColl.GothicBold;
import com.esc.fontappstylish.FontColl.Manga;
import com.esc.fontappstylish.FontColl.NanaCaps;
import com.esc.fontappstylish.FontColl.ObjectEmoji;
import com.esc.fontappstylish.FontColl.Outline;
import com.esc.fontappstylish.FontColl.Sadu;
import com.esc.fontappstylish.FontColl.SansBold;
import com.esc.fontappstylish.FontColl.SansBoldItalic;
import com.esc.fontappstylish.FontColl.SansItalic;
import com.esc.fontappstylish.FontColl.Script;
import com.esc.fontappstylish.FontColl.ScriptBold;
import com.esc.fontappstylish.FontColl.SerifBold;
import com.esc.fontappstylish.FontColl.SerifBoldItalic;
import com.esc.fontappstylish.FontColl.SerifItalic;
import com.esc.fontappstylish.FontColl.SpecialSymbols;
import com.esc.fontappstylish.FontColl.SpecialSymbols2;
import com.esc.fontappstylish.FontColl.Streebug;
import com.esc.fontappstylish.FontColl.Thobda;
import com.esc.fontappstylish.FontColl.Thobda2;
import com.esc.fontappstylish.FontColl.Thobda3;
import com.esc.fontappstylish.FontColl.Thobda4;
import com.esc.fontappstylish.FontColl.Thobda5;
import com.esc.fontappstylish.FontColl.Thobda6;
import com.esc.fontappstylish.FontColl.Typewriter;
import com.esc.fontappstylish.FontColl.UperthiNiche;
import java.util.Arrays;

public class FontService {
    private static final FontInter[] AKSHARO_ORDER_OVER_OR_O = new FontInter[]{new Sadu(), new Script(), new ScriptBold(), new Outline(), new Typewriter(), new UperthiNiche(), new NanaCaps(), new GolOutline(), new GolFilled(), new ChorasOutline(), new ChorasFilled(), new Comic(), new SerifBold(), new SerifItalic(), new SerifBoldItalic(), new SansBold(), new SansItalic(), new SansBoldItalic(), new Gothic(), new GothicBold(), new Aani1(), new Font_1(), new Font_2(), new Font_3(), new Font_4()};
    private static final FontInter[] AKSHARO_ORDER_UNDER_O = new FontInter[]{new Sadu(), new NanaCaps(), new UperthiNiche(), new Comic(), new GolOutline(), new GolFilled(), new ChorasOutline(), new ChorasFilled(), new Streebug(), new Manga(), new Aani1(), new Aani2(), new Aani4(), new Aani7(), new Aani8(), new Aani9(), new Font_2(), new Font_3(), new Font_4(), new Font_5(), new Font_6(), new Font_7(), new Font_8(), new Font_9(), new Font_10(), new Thobda6(), new Thobda5(), new Thobda4(), new SpecialSymbols(), new SpecialSymbols2(), new Emoji7(), new ObjectEmoji(), new FoodEmoji(), new FoodEmoji2(), new Emoji(), new Thobda(), new Thobda2()};
    public static final FontService INSTANCE = new FontService();
    private static Context context;
    private static int currentFontIndex;
    private static SharedPreferenceclass sharedPreference;
    int val;
    int val2;

    private FontService() {
    }

    public final Context getContext() {
        return context;
    }

    public final void setContext(Context context) {
        if (context != null) {
            sharedPreference = new SharedPreferenceclass(context);
        }
    }

    public final FontInter getInitialFont() {
        SharedPreferenceclass sharedPreferenceclass = sharedPreference;
        if (sharedPreferenceclass != null) {
            int max = Math.max(Math.min(sharedPreferenceclass.getCurrentFontIndex(), getFontOrderEmoji().length - 1), 0);
            currentFontIndex = max;
            return getFontOrderEmoji()[max];
        }
        throw new NullPointerException("sharedPreference");
    }

    public final FontInter getCurrentFont() {
        return getFontOrderEmoji()[Math.max(Math.min(currentFontIndex, getFontOrderEmoji().length - 1), 0)];
    }

    public final void setCurrentFont(FontInter fontInter) {
        int indexOf = indexOf((Object[]) getFontOrderEmoji(), fontInter);
        currentFontIndex = indexOf;
        SharedPreferenceclass sharedPreferenceclass = sharedPreference;
        if (sharedPreferenceclass != null) {
            sharedPreferenceclass.setCurrentFontIndex(indexOf);
            return;
        }
        throw new NullPointerException("sharedPreference");
    }

    public final FontInter[] getFontOrder() {
        if (VERSION.SDK_INT >= 26) {
            return AKSHARO_ORDER_OVER_OR_O;
        }
        return AKSHARO_ORDER_UNDER_O;
    }

    public final FontInter[] getFontOrderEmoji() {
        SharedPreferenceclass sharedPreferenceclass = sharedPreference;
        if (sharedPreferenceclass != null) {
            this.val = sharedPreferenceclass.getCurrentEmojiArray();
        }
        return AKSHARO_ORDER_UNDER_O;
    }

    public final void nextFont() {
        currentFontIndex = (currentFontIndex + 1) % getFontOrder().length;
    }

    public static <T> int indexOf(T[] tArr, T t) {
        return Arrays.asList(tArr).indexOf(t);
    }
}
