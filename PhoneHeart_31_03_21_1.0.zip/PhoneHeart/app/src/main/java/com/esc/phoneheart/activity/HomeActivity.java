package com.esc.phoneheart.activity;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StatFs;
import android.text.format.Formatter;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.PopupMenu;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.esc.phoneheart.R;
import com.esc.phoneheart.batterymanager.BatterySaverActivity;
import com.esc.phoneheart.cooler.CoolerScanScreen;
import com.esc.phoneheart.duplicatefiles.DupFileHomeScreen;
import com.esc.phoneheart.kprogresshud.KProgressHUD;
import com.esc.phoneheart.permission.PermissionModel;
import com.esc.phoneheart.pref.EPreferences;
import com.esc.phoneheart.pref.MySharedPreference;
import com.esc.phoneheart.tools.SpaceManagerActivity;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.pref.SharedPrefUtil;
import com.esc.phoneheart.utility.Util;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import java.io.File;
import java.util.Locale;
import androidx.appcompat.app.AppCompatActivity;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;

public class HomeActivity extends AppCompatActivity implements OnClickListener {
    public static final String TAG = "HomeActivity";
    public Dialog dialog;
    public Handler handler = new Handler();
    public int height;
    public ImageView imghart;
    public Intent intent;
    public Context context;
    public SharedPrefUtil pref;
    public boolean pendingIntroAnimation;
    public ImageView iv_cpucooling;
    public ImageView iv_filemanager;
    public ImageView iv_battery;
    public ImageView iv_usememory;
    public ImageView iv_duplicatefile;
    public TextView tv_ramused;
    public TextView tv_spaceused;
    public TextView tv_totram;
    public TextView tv_totspace;
    public ImageView iv_heart;
    private ImageView iv_menuOption;
    public int v_count;
    public int width;
    public View layout_memory;
    public View layout_spcae;
    private EPreferences ePreferences;

    private void autostartCheck() {
        if (this.pref.getBoolean(SharedPrefUtil.HIDE_AUTOSTART)) {
        }
    }

    private void deviceParams() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.height = displayMetrics.heightPixels;
        this.width = displayMetrics.widthPixels;
    }

    private void increaseVisitCount() {
        String str = "v_count";
        int i = this.pref.getInt(str);
        this.v_count = i;
        i++;
        this.v_count = i;
        this.pref.saveInt(str, i);
    }

    private void init() {
        iv_cpucooling = findViewById(R.id.iv_cpucooling);
        iv_filemanager = findViewById(R.id.iv_filemanager);
        iv_battery = findViewById(R.id.iv_battery);
        iv_usememory = findViewById(R.id.iv_usememory);
        iv_duplicatefile = findViewById(R.id.iv_duplicatefile);

        iv_cpucooling.setOnClickListener(this);
        iv_filemanager.setOnClickListener(this);
        iv_battery.setOnClickListener(this);
        iv_usememory.setOnClickListener(this);
        iv_duplicatefile.setOnClickListener(this);

        imghart = findViewById(R.id.imghart);
        iv_heart = findViewById(R.id.pulse);
        tv_totram = (TextView) findViewById(R.id.tv_ramtot);
        tv_ramused = (TextView) findViewById(R.id.tv_ramused);
        tv_totspace = (TextView) findViewById(R.id.tv_spacetotal);
        tv_spaceused = (TextView) findViewById(R.id.tv_spaceused);
        layout_spcae = findViewById(R.id.layout_spcae);
        layout_memory = findViewById(R.id.layout_mem);
        iv_menuOption = findViewById(R.id.iv_menuOption);

        iv_menuOption.setOnClickListener(this);
        layout_spcae.setOnClickListener(this);
        layout_memory.setOnClickListener(this);

        Drawable drawable = this.iv_heart.getDrawable();
        if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (drawable instanceof AnimatedVectorDrawable) {
                final AnimatedVectorDrawable animatedVectorDrawable = (AnimatedVectorDrawable) drawable;
                animatedVectorDrawable.start();
                final Handler handler = new Handler();
                handler.post(new Runnable() {
                    public void run() {
                        animatedVectorDrawable.start();
                        handler.postDelayed(this, 2000);
                    }
                });
            } else if (drawable instanceof AnimatedVectorDrawableCompat) {
                final AnimatedVectorDrawableCompat animatedVectorDrawableCompat = (AnimatedVectorDrawableCompat) drawable;
                animatedVectorDrawableCompat.start();
                this.handler.post(new Runnable() {
                    public void run() {
                        animatedVectorDrawableCompat.start();
                        HomeActivity.this.handler.postDelayed(this, 2000);
                    }
                });
            }
        }
    }

    private void setlayoutParams() {
        int i = (this.height * 7) / 100;
        LayoutParams layoutParams2 = (LayoutParams) findViewById(R.id.layout_top_half).getLayoutParams();
        layoutParams2.height = (this.height * 45) / 100;
        findViewById(R.id.layout_top_half).setLayoutParams(layoutParams2);
        RelativeLayout.LayoutParams layoutParams3 = (RelativeLayout.LayoutParams) this.imghart.getLayoutParams();
        int i2 = this.width;
        layoutParams3.width = (i2 * 51) / 100;
        layoutParams3.height = (i2 * 80) / 100;
        this.imghart.setLayoutParams(layoutParams3);
        layoutParams3 = (RelativeLayout.LayoutParams) this.iv_heart.getLayoutParams();
        layoutParams3.width = (this.width * 90) / 100;
        layoutParams3.height = (this.height * 10) / 100;
        this.iv_heart.setLayoutParams(layoutParams3);
    }

    @SuppressLint("WrongConstant")
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (-1 == i2 && i == 54 && intent != null) {
            Locale locale;
            i = intent.getIntExtra("index", 0);
            String stringExtra = intent.getStringExtra("lng_code");
            if (stringExtra.contains("zh-rCN")) {
                locale = Locale.SIMPLIFIED_CHINESE;
            } else if (stringExtra.contains("pt-rBR")) {
                locale = new Locale("pt", "BR");
            } else {
                locale = new Locale(stringExtra);
            }
            Locale.setDefault(locale);
            Configuration configuration = new Configuration();
            configuration.locale = locale;
            getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());
            MySharedPreference.setLngIndex(this, i);
            Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage(getPackageName());
            if (launchIntentForPackage != null) {
                launchIntentForPackage.addFlags(335544320);
            }
            finishAffinity();
            startActivity(launchIntentForPackage);
        }
    }

    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.iv_cpucooling:
                id = 100;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    startActivity(new Intent(HomeActivity.this, CoolerScanScreen.class));
                }
                break;
            case R.id.iv_filemanager:
                id = 101;
                if (interstitial !=null && interstitial.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    startActivity(new Intent(HomeActivity.this, SpaceManagerActivity.class));
                }
                break;

            case R.id.iv_battery:
                id = 103;
                if (interstitial !=null && interstitial.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    startActivity(new Intent(this, BatterySaverActivity.class));
                }
                break;

            case R.id.iv_usememory:
                id = 104;
                if (interstitial != null && interstitial.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    startActivity(new Intent(this, PhoneBoostScreen.class));
                }
                break;

            case R.id.iv_duplicatefile:
                id = 105;
                if (interstitial != null &&  interstitial.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    startActivity(new Intent(HomeActivity.this, DupFileHomeScreen.class));
                }
                break;

            case R.id.iv_menuOption:
                PopupMenu popup = new PopupMenu(HomeActivity.this, iv_menuOption);
                popup.getMenuInflater().inflate(R.menu.option_menu, popup.getMenu());

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item)
                    {
                        switch (item.getItemId())
                        {
                            case R.id.share:
                                Intent intent = new Intent(Intent.ACTION_SEND);
                                intent.setType("text/plain");
                                intent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.share_msg) + getPackageName());
                                startActivity(Intent.createChooser(intent, "Share Via"));
                            break;

                            case R.id.rate:
                                try
                                {
                                    startActivity(new Intent(
                                            "android.intent.action.VIEW",
                                            Uri.parse(getResources().getString(R.string.rate_us)
                                                    + getPackageName())));
                                } catch (ActivityNotFoundException e) {
                                    Toast.makeText(HomeActivity.this, "You don't have Google Play Store installed",
                                            Toast.LENGTH_SHORT).show();
                                }
                                break;

                            case R.id.privacy:
                                try {
                                    Intent intent1 = new Intent(Intent.ACTION_VIEW);
                                    intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                                    startActivity(intent1);
                                }catch (ActivityNotFoundException e)
                                {
                                    Toast.makeText(HomeActivity.this, "You don't have Google installed",
                                            Toast.LENGTH_SHORT).show();
                                }
                                break;
                        }

                        return true;
                    }
                });

                popup.show();

            default:
                return;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_home);
        context = this;
        pref = new SharedPrefUtil(this.context);
        ePreferences = EPreferences.getInstance(this);
        deviceParams();
        init();
        loadAd();
        setlayoutParams();
        PermissionModel.checkPermission(this);

        Util.setSavedPreferences(this);
        getIntent().getStringExtra("TEMPERATURE");
        GlobalData.SETAPPLAnguage(this);
        if (!GlobalData.AUTO_START_SHOWN && VERSION.SDK_INT >= 26) {
            autostartCheck();
            GlobalData.AUTO_START_SHOWN = true;
        }
        increaseVisitCount();

        String totalRamValue = totalRamMemorySize();
        String freeRamValue = freeRamMemorySize();
        String totalstorage = getTotalInternalMemorySize();
        String usdestorage = getAvailableInternalMemorySize();

        tv_totram.setText(totalRamValue);
        tv_ramused.setText(freeRamValue);
        tv_totspace.setText(totalstorage);
        tv_spaceused.setText(usdestorage);
    }

    private String totalRamMemorySize() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        activityManager.getMemoryInfo(mi);
        long availabletotalram = mi.totalMem / 1048576L;
        String totalram = Formatter.formatFileSize(this, availabletotalram);
        return totalram;
    }

    private String freeRamMemorySize() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        activityManager.getMemoryInfo(mi);
        long availablefreeram = mi.availMem / 1048576L;
        long totlram = mi.totalMem / 1048576L;
        long usedram = totlram - availablefreeram;
        String freeram = Formatter.formatFileSize(this, usedram);
        return freeram;
    }

    public String getTotalInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long totalBlocks = stat.getBlockCount();
        long totalstorage = totalBlocks * blockSize;
        String storage = Formatter.formatFileSize(this, totalstorage);
        return storage;
    }

    public String getAvailableInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize1 = stat.getBlockSize();
        long totalBlocks = stat.getBlockCount();
        long totalstorage = totalBlocks * blockSize1;

        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        long usedspace = availableBlocks * blockSize;

        long totaluse = totalstorage - usedspace;

        String space = Formatter.formatFileSize(this, totaluse);
        return space;
    }

    private InterstitialAd interstitial;
    private UnifiedNativeAd nativeAd;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(HomeActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {

                    case 100:
                        startActivity(new Intent(HomeActivity.this, CoolerScanScreen.class));
                        break;
                    case 101:
                        startActivity(new Intent(HomeActivity.this, SpaceManagerActivity.class));
                        break;

                    case 103:
                        startActivity(new Intent(HomeActivity.this, BatterySaverActivity.class));
                        break;
                    case 104:
                        startActivity(new Intent(HomeActivity.this, PhoneBoostScreen.class));
                        break;
                    case 105:
                        startActivity(new Intent(HomeActivity.this, DupFileHomeScreen.class));
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(HomeActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(HomeActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.Ad_mob_native_advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = (ImageView) dialog.findViewById(R.id.ivStar1);
        ivStar2 = (ImageView) dialog.findViewById(R.id.ivStar2);
        ivStar3 = (ImageView) dialog.findViewById(R.id.ivStar3);
        ivStar4 = (ImageView) dialog.findViewById(R.id.ivStar4);
        ivStar5 = (ImageView) dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    finishAffinity();
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }


    public void ExitDialog() {
        final Dialog dialog = new Dialog(HomeActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.Ad_mob_native_advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });
        dialog.show();
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    public void onResume() {
        super.onResume();
        GlobalData.proceededToAd = false;
        if (this.pref == null) {
            this.pref = new SharedPrefUtil(this);
        }
    }
}

