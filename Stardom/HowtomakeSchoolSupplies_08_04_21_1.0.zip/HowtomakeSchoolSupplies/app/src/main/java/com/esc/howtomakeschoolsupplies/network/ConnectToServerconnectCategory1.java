package com.esc.howtomakeschoolsupplies.network;

import android.util.Log;

import androidx.core.app.NotificationCompat;
import java.util.List;
import java.util.Timer;
import kotlin.jvm.internal.Intrinsics;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import com.esc.howtomakeschoolsupplies.network.ConnectToServer.LoadingCategory;
import com.esc.howtomakeschoolsupplies.pojo.Category;


public class ConnectToServerconnectCategory1 implements Callback<List<Category>> {
    final LoadingCategory $loadingCategory;

    ConnectToServerconnectCategory1(LoadingCategory loadingCategory) {
        this.$loadingCategory = loadingCategory;
    }

    public void onResponse(Call<List<Category>> call, Response<List<Category>> response) {
        Intrinsics.checkParameterIsNotNull(call, NotificationCompat.CATEGORY_CALL);
        Intrinsics.checkParameterIsNotNull(response, "response");
        if (response.isSuccessful()) {
            List list = (List) response.body();
            if (list != null) {
                LoadingCategory loadingCategory = this.$loadingCategory;
                Intrinsics.checkExpressionValueIsNotNull(list, "it");
                loadingCategory.initCategory(list);
            }
        }
    }

    public void onFailure(Call<List<Category>> call, Throwable th) {
        Intrinsics.checkParameterIsNotNull(call, NotificationCompat.CATEGORY_CALL);
        Intrinsics.checkParameterIsNotNull(th, "t");
        th.printStackTrace();
        new Timer("connectCategory", false).schedule(new ConnectToServerconnectCategory1onFailureinlinedschedule1(this), 3000);
    }
}
