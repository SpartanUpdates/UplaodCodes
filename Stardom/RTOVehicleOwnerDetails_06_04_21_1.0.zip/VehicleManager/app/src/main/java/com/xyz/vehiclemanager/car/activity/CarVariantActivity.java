package com.xyz.vehiclemanager.car.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.car.adapter.CarColorAdapter;
import com.xyz.vehiclemanager.car.adapter.CarVariantAdapter;
import com.xyz.vehiclemanager.car.model.CarDetailsRoot;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.utils.Utils;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CarVariantActivity extends AppCompatActivity
{
    private String modelId, modelName, imageUrl;
    private ImageView iv_back, iv_carmodel;
    private TextView tv_title, tv_carname, tv_carprice;
    private RecyclerView rv_color;
    private RecyclerView rv_variant;
    private CarVariantAdapter carVarientAdapter;
    private CarColorAdapter carColorAdapter;
    private RtoDetailsInterface rtoDetailsInterface;
    private AppCompatDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_variant);

        modelId = getIntent().getStringExtra("modelId");
        modelName = getIntent().getStringExtra("modelName");
        imageUrl = getIntent().getStringExtra("imageUrl");
        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);

        BindView();
        PutAnalyticsEvent();
        DialogAnimation();
        if (Utils.isOnline(CarVariantActivity.this)) {
            getBikeVariantData();
        }else {
            Toast.makeText(this, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    private void BindView()
    {
        tv_carname = findViewById(R.id.tv_carname);
        tv_title = findViewById(R.id.tv_title);
        tv_carprice = findViewById(R.id.tv_carprice);
        iv_carmodel = findViewById(R.id.iv_carmodel);
        iv_back = findViewById(R.id.iv_back);
        rv_color = findViewById(R.id.rv_color);
        rv_variant = findViewById(R.id.rv_variant);
        tv_title.setText(modelName);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CarVariantActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void  DialogAnimation()
    {
        dialog = new AppCompatDialog(CarVariantActivity.this, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_cardialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void getBikeVariantData()
    {
        Call<CarDetailsRoot> call = rtoDetailsInterface.getCarVariantsData(modelId);
        call.enqueue(new Callback<CarDetailsRoot>() {
            @Override
            public void onResponse(Call<CarDetailsRoot> call, Response<CarDetailsRoot> response) {

                if (response.isSuccessful())
                {
                    if (dialog != null && dialog.isShowing())
                    {
                        dialog.dismiss();
                    }
                    String exShowroomPrice = response.body().getDetails().getExShowroomPrice();
                    tv_carname.setText(modelName);
                    tv_carprice.setText(exShowroomPrice);

                    Glide.with(CarVariantActivity.this)
                            .load(imageUrl)
                            .placeholder(R.drawable.ic_car)
                            .into(iv_carmodel);

                    //BikeColor Adapter Set
                    ArrayList<CarDetailsRoot.Details.Color> colorlist = response.body().getDetails().getColors();
                    carColorAdapter = new CarColorAdapter(CarVariantActivity.this, colorlist);
                    rv_color.setLayoutManager(new LinearLayoutManager(CarVariantActivity.this, LinearLayoutManager.HORIZONTAL,false));
                    rv_color.setAdapter(carColorAdapter);

                    //BikeVariantData Adapter Set
                    ArrayList<CarDetailsRoot.Details.Variant> variantlist = response.body().getDetails().getVariants();
                    carVarientAdapter = new CarVariantAdapter(CarVariantActivity.this, variantlist);
                    rv_variant.setLayoutManager(new LinearLayoutManager(CarVariantActivity.this));
                    rv_variant.setAdapter(carVarientAdapter);
                }
            }

            @Override
            public void onFailure(Call<CarDetailsRoot> call, Throwable t) {
                if (dialog != null && dialog.isShowing())
                {
                    dialog.dismiss();
                }
                Toast.makeText(CarVariantActivity.this, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }
}