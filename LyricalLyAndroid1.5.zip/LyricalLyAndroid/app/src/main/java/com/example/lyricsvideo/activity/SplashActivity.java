package com.example.lyricsvideo.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.example.lyricsvideo.R;
import com.example.lyricsvideo.UnityPlayerActivity;
import com.example.lyricsvideo.application.App;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.firebase.analytics.FirebaseAnalytics;

public class SplashActivity extends AppCompatActivity {

    Activity activity = SplashActivity.this;
    TextView tvStart, tvAppVersion, tvPrivacyPolicy;
    InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        tvStart = findViewById(R.id.tv_start);
        tvAppVersion = findViewById(R.id.tv_app_version);
        tvPrivacyPolicy = findViewById(R.id.tv_privacy_policy);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SplashActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
        GetAppVersion();
        InterstitialAd();
        tvPrivacyPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent("android.intent.action.VIEW");
                intent1.setData(Uri.parse(getResources().getString(R.string.privacy_link)));
            }
        });
        tvStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isAdLoaded()) {
                    App.ShowDialog(activity);
                    mInterstitialAd.show();
                } else {
                    GoToHome();
                }
            }
        });
    }

    private void GoToHome() {
        Intent i = new Intent(activity, UnityPlayerActivity.class);
        startActivity(i);
        finish();
    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(this, getString(R.string.FB_inter));
        mInterstitialAd.setAdListener(new InterstitialAdListener() {

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }

            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                GoToHome();
            }
        });
        mInterstitialAd.loadAd();

    }

    private void GetAppVersion() {
        PackageManager manager = activity.getPackageManager();
        PackageInfo info = null;
        try {
            info = manager.getPackageInfo(activity.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (info != null) {
            tvAppVersion.setText("Version" + " " + info.versionName);
        }
    }
}
