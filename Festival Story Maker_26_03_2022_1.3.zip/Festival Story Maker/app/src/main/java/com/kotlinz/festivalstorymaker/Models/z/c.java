package com.kotlinz.festivalstorymaker.Models.z;

public class c {
    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;

    public c() {
        this.e = -1;
    }
}
