package com.kotlinz.videoeditor.videotomp3.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore.Audio;
import android.provider.MediaStore.Images;
import android.provider.MediaStore.Video.Media;
import android.provider.MediaStore.Video.Thumbnails;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;

import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.activity.AudioPlayerActivity;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.Utils.UtilCommand;
import com.kotlinz.videoeditor.view.VideoPlayerState;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar;
import com.kotlinz.videoeditor.editvideo.activity.EditActivity;
import com.kotlinz.videoeditor.videotomp3.Adapter.FontListAdapter;
import com.kotlinz.videoeditor.videotomp3.Adapter.HorizontalListView;
import com.kotlinz.videoeditor.videotomp3.Utils.FileUtils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;


import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.kotlinz.videoeditor.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

@SuppressLint({"WrongConstant"})
public class VideoToMP3ConverterActivity extends AppCompatActivity {
    Activity activity = VideoToMP3ConverterActivity.this;
    static final boolean G = true;
    public static String Meta_File_path;
    Boolean A = Boolean.valueOf(false);
    int B = 0;
    int C = 0;
    int D;
    VideoSliceSeekBar E;
    VideoView F;
    ArrayList<String> a = new ArrayList<>();
    String b;
    String c;
    String d;
    String e;
    String f;
    String g;
    String h;
    String i = "00";
    public ImageView ivaac;
    public ImageView ivmp3;
    String[] j = {"None", "40\nCBR", "48\nCBR", "64\nCBR", "80\nCBR", "96\nCBR", "112\nCBR", "128\nCBR", "160\nCBR", "192\nCBR", "224\nCBR", "256\nCBR", "320\nCBR", "245\nVBR", "225\nVBR", "190\nVBR", "175\nVBR", "165\nVBR", "130\nVBR", "115\nVBR", "100\nVBR", "85\nVBR", " 65\nVBR"};
    Bundle k;
    ImageView l;
    HorizontalListView m;
    ImageView n;
    LinearLayout q;
    LinearLayout r;
    FontListAdapter s;
    ProgressDialog t = null;
    public TextView textViewLeft;
    public TextView textViewRight;
    public TextView txt_kbps;

    ImageView ivback, ivDone;
    TextView tvToolbarName;
    public VideoPlayerState videoPlayerState = new VideoPlayerState();
    public StateObserver videoStateObserver = new StateObserver();

    private NativeAd nativeAd;


    public class StateObserver extends Handler {
        public boolean alreadyStarted = false;
        public Runnable observerWork;

        public StateObserver() {
            this.observerWork = new Runnable() {
                public void run() {
                    StateObserver.this.startVideoProgressObserving();
                }
            };
        }

        public void startVideoProgressObserving() {
            if (!this.alreadyStarted) {
                this.alreadyStarted = VideoToMP3ConverterActivity.G;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            this.alreadyStarted = false;
            VideoToMP3ConverterActivity.this.E.videoPlayingProgress(VideoToMP3ConverterActivity.this.F.getCurrentPosition());
            if (!VideoToMP3ConverterActivity.this.F.isPlaying() || VideoToMP3ConverterActivity.this.F.getCurrentPosition() >= VideoToMP3ConverterActivity.this.E.getRightProgress()) {
                if (VideoToMP3ConverterActivity.this.F.isPlaying()) {
                    VideoToMP3ConverterActivity.this.F.pause();
                    VideoToMP3ConverterActivity.this.A = Boolean.valueOf(false);
                    VideoToMP3ConverterActivity.this.l.setBackgroundResource(R.drawable.ic_play_upress);
                }
                VideoToMP3ConverterActivity.this.E.setSliceBlocked(false);
                VideoToMP3ConverterActivity.this.E.removeVideoStatusThumb();
                return;
            }
            postDelayed(this.observerWork, 50);
        }
    }


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.videotomp3activity);
        for (String add : this.j) {
            this.a.add(add);
        }
        k = getIntent().getExtras();
        D = 1;
        if (k != null) {
            h = k.getString("videopath");
            StringBuilder sb = new StringBuilder();
            sb.append("=== videopath");
            sb.append(h);
            MyApplication.getInstance().VideoFileName = h;
            videoPlayerState.setFilename(h);
        }
        LoadNativeAds();
        try {
            ThumbVideo(getApplicationContext(), h);
        } catch (Exception unused) {
            unused.printStackTrace();
        }
        ivback = findViewById(R.id.iv_back);
        ivDone = findViewById(R.id.iv_done);
        tvToolbarName = findViewById(R.id.tv_app_name);
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder sb = new StringBuilder();
                sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
                sb.append("/");
                sb.append(getResources().getString(R.string.MainFolderName));
                sb.append("/");
                sb.append(getResources().getString(R.string.VideoToMP3));
                sb.append("/");
                File file = new File(sb.toString());
                if (!file.exists()) {
                    file.mkdirs();
                }
                new SimpleDateFormat("_HHmmss", Locale.US).format(new Date());
                if (F.isPlaying()) {
                    F.pause();
                    l.setBackgroundResource(R.drawable.ic_play_upress);
                    A = Boolean.valueOf(false);
                }
                try {
                    if (d.equals("MP3")) {
                        c = FileUtils.getTargetFileName(VideoToMP3ConverterActivity.this, h);
                    } else if (d.equals("AAC")) {
                        String substring = h.substring(h.lastIndexOf("/") + 1);
                        String substring2 = substring.substring(0, substring.lastIndexOf("."));
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
                        sb2.append("/");
                        sb2.append(getResources().getString(R.string.MainFolderName));
                        sb2.append("/");
                        sb2.append(getResources().getString(R.string.VideoToMP3));
                        sb2.append("/");
                        sb2.append(substring2);
                        sb2.append(System.currentTimeMillis());
                        sb2.append(".aac");
                        c = sb2.toString();
                    }
                } catch (Exception unused) {
                    unused.printStackTrace();
                }
                d();
            }
        });
        E = findViewById(R.id.seek_bar);
        F = findViewById(R.id.videoView);
        l = findViewById(R.id.btnPlayVideo);
        textViewLeft = findViewById(R.id.left_pointer);
        textViewRight = findViewById(R.id.right_pointer);
        m = findViewById(R.id.hs_Bitrate);
        ivaac = findViewById(R.id.iv_aac);
        ivmp3 = findViewById(R.id.iv_mp3);
        r = findViewById(R.id.llBitrate);
        q = findViewById(R.id.llFormate);
        s = new FontListAdapter(getApplicationContext(), a);
        m.setAdapter(this.s);
        ivaac.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ivmp3.setImageResource(R.drawable.ic_mp3_unpress);
                ivaac.setImageResource(R.drawable.ic_aac_press);
                d = "AAC";
            }
        });
        ivmp3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ivmp3.setImageResource(R.drawable.ic_mp3_press);
                ivaac.setImageResource(R.drawable.ic_aac_unpress);
                d = "MP3";
            }
        });
        m.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                FileUtils.Bitrate = i;
                if (i == 0) {
                    try {
                        g = "None";
                        f = "None";
                        e = "None";
                        txt_kbps.setText("None");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else if (i == 1) {
                    try {
                        txt_kbps.setText(" 40 (CBR)");
                        g = "-ab";
                        f = "40k";
                        e = "-vn";
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                } else if (i == 2) {
                    try {
                        txt_kbps.setText(" 48 (CBR)");
                        g = "-ab";
                        f = "48k";
                        e = "-vn";
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                } else if (i == 3) {
                    try {
                        txt_kbps.setText(" 64 (CBR)");
                        g = "-ab";
                        f = "64k";
                        e = "-vn";
                    } catch (Exception e4) {
                        e4.printStackTrace();
                    }
                } else if (i == 4) {
                    try {
                        txt_kbps.setText(" 80 (CBR)");
                        g = "-ab";
                        f = "80k";
                        e = "-vn";
                    } catch (Exception e5) {
                        e5.printStackTrace();
                    }
                } else if (i == 5) {
                    try {
                        txt_kbps.setText(" 96 (CBR)");
                        g = "-ab";
                        f = "96k";
                        e = "-vn";
                    } catch (Exception e6) {
                        e6.printStackTrace();
                    }
                } else if (i == 6) {
                    try {
                        txt_kbps.setText(" 112 (CBR)");
                        g = "-ab";
                        f = "112k";
                        e = "-vn";
                    } catch (Exception e7) {
                        e7.printStackTrace();
                    }
                } else if (i == 7) {
                    try {
                        txt_kbps.setText(" 128 (CBR)");
                        g = "-ab";
                        f = "128k";
                        e = "-vn";
                    } catch (Exception e8) {
                        e8.printStackTrace();
                    }
                } else if (i == 8) {
                    try {
                        txt_kbps.setText(" 160 (CBR)");
                        g = "-ab";
                        f = "160k";
                        e = "-vn";
                    } catch (Exception e9) {
                        e9.printStackTrace();
                    }
                } else if (i == 9) {
                    try {
                        txt_kbps.setText(" 192 (CBR)");
                        g = "-ab";
                        f = "192k";
                        e = "-vn";
                    } catch (Exception e10) {
                        e10.printStackTrace();
                    }
                } else if (i == 10) {
                    try {
                        txt_kbps.setText(" 224 (CBR)");
                        g = "-ab";
                        f = "224k";
                        e = "-vn";
                    } catch (Exception e11) {
                        e11.printStackTrace();
                    }
                } else if (i == 11) {
                    try {
                        txt_kbps.setText(" 256 (CBR)");
                        g = "-ab";
                        f = "256k";
                        e = "-vn";
                    } catch (Exception e12) {
                        e12.printStackTrace();
                    }
                } else if (i == 12) {
                    try {
                        txt_kbps.setText(" 320 (CBR)");
                        g = "-ab";
                        f = "320k";
                        e = "-vn";
                    } catch (Exception e13) {
                        e13.printStackTrace();
                    }
                } else if (i == 13) {
                    try {
                        txt_kbps.setText(" 245 (VBR)");
                        g = "-q:a";
                        f = "0";
                        e = "-vn";
                    } catch (Exception e14) {
                        e14.printStackTrace();
                    }
                } else if (i == 14) {
                    try {
                        txt_kbps.setText(" 225 (VBR)");
                        g = "-q:a";
                        f = "1";
                        e = "-vn";
                    } catch (Exception e15) {
                        e15.printStackTrace();
                    }
                } else if (i == 15) {
                    try {
                        txt_kbps.setText(" 190 (VBR)");
                        g = "-q:a";
                        f = "2";
                        e = "-vn";
                    } catch (Exception e16) {
                        e16.printStackTrace();
                    }
                } else if (i == 16) {
                    try {
                        txt_kbps.setText(" 175 (VBR)");
                        g = "-q:a";
                        f = "3";
                        e = "-vn";
                    } catch (Exception e17) {
                        e17.printStackTrace();
                    }
                } else if (i == 17) {
                    try {
                        txt_kbps.setText(" 165 (VBR)");
                        g = "-q:a";
                        f = "4";
                        e = "-vn";
                    } catch (Exception e18) {
                        e18.printStackTrace();
                    }
                } else if (i == 18) {
                    try {
                        txt_kbps.setText(" 130 (VBR)");
                        g = "-q:a";
                        f = "5";
                        e = "-vn";
                    } catch (Exception e19) {
                        e19.printStackTrace();
                    }
                } else if (i == 19) {
                    try {
                        txt_kbps.setText(" 115 (VBR)");
                        g = "-q:a";
                        f = "6";
                        e = "-vn";
                    } catch (Exception e20) {
                        e20.printStackTrace();
                    }
                } else if (i == 20) {
                    try {
                        txt_kbps.setText(" 100 (VBR)");
                        g = "-q:a";
                        f = "7";
                        e = "-vn";
                    } catch (Exception e21) {
                        e21.printStackTrace();
                    }
                } else if (i == 21) {
                    try {
                        txt_kbps.setText(" 85 (VBR)");
                        g = "-q:a";
                        f = "8";
                        e = "-vn";
                    } catch (Exception e22) {
                        e22.printStackTrace();
                    }
                } else if (i == 22) {
                    try {
                        txt_kbps.setText(" 65 (VBR)");
                        g = "-q:a";
                        f = "9";
                        e = "-vn";
                    } catch (Exception e23) {
                        e23.printStackTrace();
                    }
                }
            }
        });
        initVideoView();
        this.txt_kbps = findViewById(R.id.txt_kbps);
        this.txt_kbps.setText(" None ");
        this.d = "MP3";
        this.g = "None";
        return;
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (VideoToMP3ConverterActivity.this.nativeAd != null) {
                            VideoToMP3ConverterActivity.this.nativeAd.destroy();
                        }
                        VideoToMP3ConverterActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void c() {
        Intent intent = new Intent(this, AudioPlayerActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("song", this.c);
        bundle.putBoolean("isfrom", G);
        intent.putExtras(bundle);
        startActivity(intent);
        finish();
    }

    private void d() {
        String valueOf = String.valueOf(this.B / 1000);
        String valueOf2 = String.valueOf((this.C / 1000) - (this.B / 1000));
        String[] strArr = !this.g.equals("None") ? new String[]{"-y", "-i", this.h, "-vn", "-acodec", "copy", this.g, this.f, this.e, "-strict", "experimental", "-ss", valueOf, "-t", valueOf2, this.c} : this.d.equals("MP3") ? new String[]{"-y", "-i", this.h, "-vn", "-acodec", "copy", "-strict", "experimental", "-ss", valueOf, "-t", valueOf2, this.c} : this.d.equals("AAC") ? new String[]{"-y", "-ss", valueOf, "-t", valueOf2, "-i", this.h, "-vn", "-acodec", "copy", "-strict", "experimental", this.c} : null;
        for (int i2 = 0; i2 < strArr.length; i2++) {
            StringBuilder sb = new StringBuilder();
            sb.append(i2);
            sb.append(strArr[i2]);
        }
        a(strArr, this.c);
    }

    private void a(String[] strArr, final String str) {
        this.t = new ProgressDialog(this);
        this.t.setProgressStyle(1);
        this.t.setIndeterminate(G);
        this.t.setMessage("Please wait...");
        this.t.setCancelable(false);
        this.t.show();
        String ffmpegCommand = UtilCommand.main(strArr);
        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {

            @Override
            public void apply(final long executionId, final int returnCode) {
                Config.printLastCommandOutput(Log.INFO);
                t.dismiss();
                if (returnCode == RETURN_CODE_SUCCESS) {
                    VideoToMP3ConverterActivity.this.t.dismiss();
                    if (VideoToMP3ConverterActivity.this.d.equals("MP3")) {
                        StringBuilder sb = new StringBuilder(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath());
                        sb.append("/VEditor/VideoToMP3/");
                        File file = new File(sb.toString());
                        String substring = VideoToMP3ConverterActivity.this.c.substring(VideoToMP3ConverterActivity.this.c.lastIndexOf("/") + 1);
                        String substring2 = substring.substring(0, substring.lastIndexOf("."));
                        if (file.exists()) {
                            File file2 = new File(file, substring);
                            StringBuilder sb2 = new StringBuilder(substring2);
                            sb2.append(".mp3");
                            File file3 = new File(file, sb2.toString());
                            if (file2.exists()) {
                                file2.renameTo(file3);
                            }
                            VideoToMP3ConverterActivity.this.c = file3.getPath();
                        }
                    }
                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(VideoToMP3ConverterActivity.this.c)));
                    VideoToMP3ConverterActivity.this.sendBroadcast(intent);
                    c();
                    Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent2.setData(Uri.fromFile(new File(VideoToMP3ConverterActivity.this.c)));
                    sendBroadcast(intent2);
                    refreshGallery(str);

                } else if (returnCode == RETURN_CODE_CANCEL) {
                    try {
                        new File(str).delete();
                        VideoToMP3ConverterActivity.this.deleteFromGallery(str);
                        Toast.makeText(VideoToMP3ConverterActivity.this, "Error Creating Video", 0).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                } else {
                    try {
                        new File(str).delete();
                        VideoToMP3ConverterActivity.this.deleteFromGallery(str);
                        Toast.makeText(VideoToMP3ConverterActivity.this, "Error Creating Video", 0).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }


            }
        });

        getWindow().clearFlags(16);
    }

    public static String formatTimeUnit(long j2) throws ParseException {
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public void initVideoView() {
        this.F.setVideoPath(this.h);
        try {
            this.F.seekTo(200);
        } catch (Exception unused) {
        }
        this.F.setOnErrorListener(new OnErrorListener() {
            public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                Toast.makeText(VideoToMP3ConverterActivity.this.getApplicationContext(), "Video Player Not Supproting", 0).show();
                return VideoToMP3ConverterActivity.G;
            }
        });
        this.F.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                F.pause();
                l.setBackgroundResource(R.drawable.ic_play_upress);
                A = Boolean.valueOf(false);
            }
        });
        this.F.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (A.booleanValue()) {
                    F.pause();
                    A = Boolean.valueOf(false);
                    l.setBackgroundResource(R.drawable.ic_play_upress);
                }
                return G;
            }
        });
        this.F.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                E.setSeekBarChangeListener(new VideoSliceSeekBar.SeekBarChangeListener() {
                    public void SeekBarValueChanged(int i, int i2) {
                        if (E.getSelectedThumb() == 1) {
                            F.seekTo(E.getLeftProgress());
                        }
                        try {
                            textViewLeft.setText(VideoToMP3ConverterActivity.formatTimeUnit(i));
                            textViewRight.setText(VideoToMP3ConverterActivity.formatTimeUnit(i2));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        VideoToMP3ConverterActivity.this.i = VideoToMP3ConverterActivity.getTimeForTrackFormat(i, VideoToMP3ConverterActivity.G);
                        videoPlayerState.setStart(i);
                        b = VideoToMP3ConverterActivity.getTimeForTrackFormat(i2, VideoToMP3ConverterActivity.G);
                        videoPlayerState.setStop(i2);
                        B = i;
                        C = i2;
                    }
                });
                b = VideoToMP3ConverterActivity.getTimeForTrackFormat(mediaPlayer.getDuration(), VideoToMP3ConverterActivity.G);
                E.setMaxValue(mediaPlayer.getDuration());
                E.setLeftProgress(0);
                E.setRightProgress(mediaPlayer.getDuration());
                E.setProgressMinDiff(0);
                F.seekTo(200);
                l.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (A.booleanValue()) {
                            l.setBackgroundResource(R.drawable.ic_play_upress);
                            A = Boolean.valueOf(false);
                        } else {
                            l.setBackgroundResource(R.drawable.ic_pause_unpresss);
                            A = Boolean.valueOf(VideoToMP3ConverterActivity.G);
                        }
                        performVideoViewClick();
                    }
                });
            }
        });
        this.b = getTimeForTrackFormat(this.F.getDuration(), G);
    }


    @Override
    public void onResume() {
        super.onResume();
        this.d = "MP3";
        this.g = "None";
    }

    public void ThumbVideo(Context context, String str) {
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        String[] strArr = {"_data", "_id"};
        StringBuilder sb = new StringBuilder();
        sb.append("%");
        sb.append(str);
        sb.append("%");
        Cursor managedQuery = managedQuery(uri, strArr, "_data  like ?", new String[]{sb.toString()}, " _id DESC");
        int count = managedQuery.getCount();
        StringBuilder sb2 = new StringBuilder();
        sb2.append("count");
        sb2.append(count);
        Log.e("", sb2.toString());
        if (count > 0) {
            try {
                managedQuery.moveToFirst();
                for (int i2 = 0; i2 < count; i2++) {
                    try {
                        Uri.withAppendedPath(Media.EXTERNAL_CONTENT_URI, getLong(managedQuery));
                        managedQuery.getString(managedQuery.getColumnIndex("_data"));
                        Bitmap thumbnail = Thumbnails.getThumbnail(getContentResolver(), Long.valueOf(managedQuery.getLong(managedQuery.getColumnIndexOrThrow("_id"))).longValue(), 1, null);
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("Bitmap");
                        sb3.append(thumbnail);
                        Log.e("", sb3.toString());
                        managedQuery.moveToNext();
                    } catch (IllegalArgumentException e2) {
                        e2.printStackTrace();
                    }
                }
            } catch (IllegalArgumentException e3) {
                e3.printStackTrace();
            }
        }
    }

    public static String getLong(Cursor cursor) {
        return String.valueOf(cursor.getLong(cursor.getColumnIndexOrThrow("_id")));
    }

    public static String getTimeForTrackFormat(int i2, boolean z2) {
        int i3 = i2 / 3600000;
        int i4 = i2 / 60000;
        int i5 = (i2 - ((i4 * 60) * 1000)) / 1000;
        StringBuilder sb = new StringBuilder((!z2 || i3 >= 10) ? "" : "0");
        sb.append(i3);
        sb.append(":");
        StringBuilder sb2 = new StringBuilder(sb.toString());
        sb2.append((!z2 || i4 >= 10) ? "" : "0");
        StringBuilder sb3 = new StringBuilder(sb2.toString());
        sb3.append(i4 % 60);
        sb3.append(":");
        String sb4 = sb3.toString();
        if (i5 < 10) {
            StringBuilder sb5 = new StringBuilder(sb4);
            sb5.append("0");
            sb5.append(i5);
            return sb5.toString();
        }
        StringBuilder sb6 = new StringBuilder(sb4);
        sb6.append(i5);
        return sb6.toString();
    }

    public void performVideoViewClick() {
        if (this.F.isPlaying()) {
            this.F.pause();
            this.E.setSliceBlocked(false);
            this.E.removeVideoStatusThumb();
            return;
        }
        this.F.seekTo(this.E.getLeftProgress());
        this.F.start();
        this.E.videoPlayingProgress(this.E.getLeftProgress());
        this.videoStateObserver.startVideoProgressObserving();
    }

    public void scanMedia(String str) {
        String substring = str.substring(str.lastIndexOf("/") + 1);
        String substring2 = substring.substring(0, substring.lastIndexOf("."));
        ContentValues contentValues = new ContentValues();
        contentValues.put("_data", str);
        contentValues.put("title", substring2);
        contentValues.put("_size", Integer.valueOf(str.length()));
        contentValues.put("mime_type", "audio/mp3");
        contentValues.put("artist", getResources().getString(R.string.app_name));
        contentValues.put("is_ringtone", Boolean.valueOf(G));
        contentValues.put("is_notification", Boolean.valueOf(false));
        contentValues.put("is_alarm", Boolean.valueOf(false));
        contentValues.put("is_music", Boolean.valueOf(false));
        Uri contentUriForPath = Audio.Media.getContentUriForPath(str);
        StringBuilder sb = new StringBuilder();
        sb.append("=====Enter ====");
        sb.append(contentUriForPath);
        Log.e("", sb.toString());
        ContentResolver contentResolver = getContentResolver();
        StringBuilder sb2 = new StringBuilder();
        sb2.append("_data=\"");
        sb2.append(str);
        sb2.append("\"");
        contentResolver.delete(contentUriForPath, sb2.toString(), null);
        getApplicationContext().getContentResolver().insert(contentUriForPath, contentValues);
    }

    @Override
    public void onActivityResult(int i2, int i3, Intent intent) {
        super.onActivityResult(i2, i3, intent);
        if (intent != null) {
            Uri data = intent.getData();
            StringBuilder sb = new StringBuilder();
            sb.append("File Path :");
            sb.append(data);
            Log.e("", sb.toString());
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Final Image Path :");
            sb2.append(getRealPathFromURI(data));
            Log.e("", sb2.toString());
            String realPathFromURI = getRealPathFromURI(data);
            Meta_File_path = realPathFromURI;
            this.n.setImageBitmap(rotateBitmapOrientation(realPathFromURI));
        }
    }

    public String getRealPathFromURI(Uri uri) {
        Cursor managedQuery = managedQuery(uri, new String[]{"_data"}, null, null, null);
        int columnIndexOrThrow = managedQuery.getColumnIndexOrThrow("_data");
        managedQuery.moveToFirst();
        return managedQuery.getString(columnIndexOrThrow);
    }

    public Bitmap rotateBitmapOrientation(String str) {
        ExifInterface exifInterface;
        Options options = new Options();
        int i2 = 1;
        options.inJustDecodeBounds = G;
        BitmapFactory.decodeFile(str, options);
        Bitmap decodeFile = BitmapFactory.decodeFile(str, new Options());
        try {
            exifInterface = new ExifInterface(str);
        } catch (IOException e2) {
            e2.printStackTrace();
            exifInterface = null;
        }
        String attribute = exifInterface.getAttribute("Orientation");
        if (attribute != null) {
            i2 = Integer.parseInt(attribute);
        }
        int i3 = 0;
        if (i2 == 6) {
            i3 = 90;
        }
        if (i2 == 3) {
            i3 = 180;
        }
        if (i2 == 8) {
            i3 = 270;
        }
        Matrix matrix = new Matrix();
        matrix.setRotate((float) i3, ((float) decodeFile.getWidth()) / 2.0f, ((float) decodeFile.getHeight()) / 2.0f);
        return Bitmap.createBitmap(decodeFile, 0, 0, options.outWidth, options.outHeight, matrix, G);
    }


    @SuppressLint("ResourceType")
    public void f() {
        new AlertDialog.Builder(this).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                VideoToMP3ConverterActivity.this.finish();
            }
        }).create().show();
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Images.Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Images.Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        File file = new File(h);
        MediaScannerConnection.scanFile(this, new String[]{file.getPath()},
                null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        // now visible in gallery
                    }
                });
        if (MyApplication.isShowAd == 1) {
            Intent intent = new Intent(activity, EditActivity.class);
            intent.putExtra("videofilename", h);
            startActivity(intent);
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 9;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, EditActivity.class);
                intent.putExtra("videofilename", h);
                startActivity(intent);
                finish();
            }
        }
    }
}
