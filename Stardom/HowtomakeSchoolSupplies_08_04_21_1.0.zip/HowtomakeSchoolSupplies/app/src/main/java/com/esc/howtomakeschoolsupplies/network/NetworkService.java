package com.esc.howtomakeschoolsupplies.network;

import kotlin.jvm.internal.Intrinsics;
import retrofit2.Retrofit;
import retrofit2.Retrofit.Builder;
import retrofit2.converter.gson.GsonConverterFactory;
import com.esc.howtomakeschoolsupplies.activity.Constants;

public class NetworkService {
    public static final NetworkService INSTANCE = new NetworkService();
    private static final Retrofit mRetrofit = new Builder().baseUrl(Constants.SERVER_ADDRESS).addConverterFactory(GsonConverterFactory.create()).build();

    private NetworkService() {
    }

    public final JSONPlaceHolderApi jsonApi() {
        Object create = mRetrofit.create(JSONPlaceHolderApi.class);
        Intrinsics.checkExpressionValueIsNotNull(create, "mRetrofit.create(JSONPlaceHolderApi::class.java)");
        return (JSONPlaceHolderApi) create;
    }
}
