package com.jenilcreation.photomusicvideo;

import static com.jenilcreation.photomusicvideo.activity.PreviewActivity.handler;
import static com.jenilcreation.photomusicvideo.activity.PreviewActivity.lockRunnable;
import static com.jenilcreation.photomusicvideo.activity.PreviewActivity.strVideoName;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.app.Dialog;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.jenilcreation.photomusicvideo.activity.ActivityVideoAlbum;
import com.jenilcreation.photomusicvideo.activity.Activity_ArrangeImage;
import com.jenilcreation.photomusicvideo.activity.AddTitleActivity;
import com.jenilcreation.photomusicvideo.activity.DefaultSongActivity;
import com.jenilcreation.photomusicvideo.activity.Fragment_EndFrame;
import com.jenilcreation.photomusicvideo.activity.Fragment_StartFrame;
import com.jenilcreation.photomusicvideo.activity.MainActivity;
import com.jenilcreation.photomusicvideo.activity.PhotoselectActivity;
import com.jenilcreation.photomusicvideo.activity.PreviewActivity;
import com.jenilcreation.photomusicvideo.activity.ProgressActivity;
import com.jenilcreation.photomusicvideo.activity.videoPlay;
import com.jenilcreation.photomusicvideo.data.ImageData;
import com.jenilcreation.photomusicvideo.data.MusicData;
import com.jenilcreation.photomusicvideo.mask.THEMES;
import com.jenilcreation.photomusicvideo.mask.Themes1;
import com.jenilcreation.photomusicvideo.util.ActivityAnimUtil;
import com.jenilcreation.photomusicvideo.util.EPreferences;
import com.jenilcreation.photomusicvideo.util.PermissionModelUtil;
import com.jenilcreation.photomusicvideo.util.Utils;
import com.jenilcreation.photomusicvideo.util.apprater.AppRater;
import com.jenilcreation.photomusicvideo.util.service.CreateVideoService;
import com.jenilcreation.photomusicvideo.util.service.CreateVideoServicenew;
import com.jenilcreation.photomusicvideo.video.FileUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.regex.Pattern;

public class MyApplication extends Application {
    public static int TEMP_POSITION = -1;
    public static int VIDEO_HEIGHT = 480;
    public static int VIDEO_WIDTH = 720;
    private static MyApplication instance;
    public static boolean isBreak = false;
    public static boolean isEndSave = false;
    public static boolean isLastRemoved = false;
    public static boolean isStartRemoved = false;
    public static boolean isStartSave = false;
    public static boolean isStoryAdded = false;
    public static boolean islistchanged;
    public float EXTRA_FRAME_TIME;
    public HashMap<String, ArrayList<ImageData>> allAlbum;
    private ArrayList<String> allFolder;
    Bitmap bitmapSecond;
    public int endFrame;
    int frame;
    public boolean isEditModeEnable;
    public boolean isFristTimeTheme;
    public boolean isFromSdCardAudio;
    public boolean isSelectSYS;
    String mAudioDirPath;
    public int min_pos;
    private MusicData musicData;
    private OnProgressReceiver onProgressReceiver;
    public int posForAddMusicDialog;
    private float second;
    private String selectedFolderId;
    public final ArrayList<ImageData> selectedImages;
    public THEMES selectedTheme;
    public Themes1 selected_theme;
    public int startFrame;
    public ArrayList<String> videoImages;
    public ArrayList<String> welcomeImages;
    public static int check = 1;

    public static boolean IsVideo = false;

    public static InterstitialAd mInterstitialAd;
    public static Activity activity;
    public static int AdsId;
    public static int isShowAd = 0;


    public static boolean isFromPreview = false;
    public static boolean isDone = false;


    public static int[] SongList;

    public MyApplication() {
        this.posForAddMusicDialog = 0;
        this.videoImages = new ArrayList<String>();
        this.welcomeImages = new ArrayList<String>();
        this.selectedImages = new ArrayList<ImageData>();
        this.selectedFolderId = "";
        this.second = 2.0f;
        this.EXTRA_FRAME_TIME = 0.9f;
        this.selectedTheme = THEMES.Shine;
        this.selected_theme = Themes1.Shine;
        this.isEditModeEnable = false;
        this.isFromSdCardAudio = false;
        this.min_pos = Integer.MAX_VALUE;
        this.frame = 0;
        this.isFristTimeTheme = true;
        this.isSelectSYS = false;
        this.mAudioDirPath = "";
    }

    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    private void init() {
        if (!new PermissionModelUtil(this).needPermissionCheck()) {
            this.getFolderList();
            if (!FileUtils.APP_DIRECTORY.exists()) {
                FileUtils.APP_DIRECTORY.mkdirs();
            }
            this.copyAssets();
        }
        this.setVideoHeightWidth();
    }


    public void onCreate() {
        super.onCreate();
        (MyApplication.instance = this).init();
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        AudienceNetworkAds.initialize(this);
        AdSettings.addTestDevice("dc9d2374-d15c-4ec5-854e-20743a1489df");
        interstitialAd();
    }

    private void interstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, getResources().getString(R.string.admob_inter_mediation), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        requestNewInterstitial();
                                        switch (AdsId) {
                                            case 100:
                                                if (Utils.checkPermission(activity)) {
                                                    AsyncTaskRunner1 runner1 = new AsyncTaskRunner1();
                                                    runner1.execute("");
                                                }
                                                Utils.requestPermission(activity);
                                                break;

                                            case 101:
                                                loadVideoList();
                                                break;

                                            case 102:
                                                activity.startActivity(new Intent(activity, PhotoselectActivity.class));
                                                break;

                                            case 103:
                                                addTitle();
                                                break;

                                            case 105:
                                                isDone = true;
                                                new Thread(() -> {
                                                    FileUtils.TEMP_IMG_DIRECTORY.mkdirs();
                                                    final long currentTimeMillis = System.currentTimeMillis();
                                                    final StringBuilder sb = new StringBuilder();
                                                    sb.append("NewTitle save start frame ");
                                                    sb.append(currentTimeMillis);
                                                    Fragment_StartFrame.isSavingDone = false;
                                                    Fragment_StartFrame.getOnSaveStoryTitle().onSaveImageNew();
                                                    MyApplication.isStartSave = true;
                                                    final StringBuilder sb2 = new StringBuilder();
                                                    sb2.append("NewTitle save start frame ");
                                                    sb2.append(System.currentTimeMillis() - currentTimeMillis);
                                                    Fragment_EndFrame.isSavingDone = false;
                                                    Fragment_EndFrame.getOnSaveStoryTitle().onSaveImageNew();
                                                    MyApplication.isEndSave = true;
                                                    final StringBuilder sb3 = new StringBuilder();
                                                    sb3.append("NewTitle save end frame ");
                                                    sb3.append(System.currentTimeMillis() - currentTimeMillis);
                                                    updateVideoFramesNew(MyApplication.isStartSave, MyApplication.isEndSave);
                                                    final StringBuilder sb4 = new StringBuilder();
                                                    sb4.append("NewTitle save dismiss ");
                                                    sb4.append(System.currentTimeMillis() - currentTimeMillis);
                                                    resetBool();
                                                }).start();
                                                break;

                                            case 107:
                                                final Intent intent1 = new Intent(activity, Activity_ArrangeImage.class);
                                                intent1.putExtra("isFromCameraNotification", false);
                                                intent1.putExtra("KEY", "FromImageSelection");
                                                activity.startActivity(intent1);
                                                break;

                                            case 111:
                                                Intent intent;
                                                if (activity.getIntent().getExtras().get("KEY").equals("FromVideoAlbum")) {
                                                    if (new Random().nextInt(100) > 50) {
                                                        AppRater.showRateDialog(activity);
                                                        AppRater.setCallback(new AppRater.Callback() {
                                                            @Override
                                                            public void onCancelClicked() {
                                                                final Intent intent = new Intent(activity, ActivityVideoAlbum.class);
                                                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                                intent.putExtra("EXTRA_FROM_VIDEO", true);
                                                                activity.startActivity(intent);
                                                                activity.finish();
                                                            }

                                                            @Override
                                                            public void onNoClicked() {
                                                            }

                                                            @Override
                                                            public void onYesClicked() {
                                                            }
                                                        });
                                                        return;
                                                    }
                                                    intent = new Intent(activity, ActivityVideoAlbum.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                    intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                                                    activity.startActivity(intent);
                                                    activity.finish();
                                                } else if (activity.getIntent().getExtras().get("KEY").equals("FromProgress")) {
                                                    intent = new Intent(activity, ActivityVideoAlbum.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                    intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                                                    intent.putExtra("KEY", ActivityVideoAlbum.EXTRA_FROM_VIDEO);
                                                    activity.startActivity(intent);
                                                    activity.finish();
                                                } else if (activity.getIntent().getExtras().get("KEY").equals("FromNotify")) {
                                                    intent = new Intent(activity, MainActivity.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                    intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                                                    activity.startActivity(intent);
                                                    activity.finish();
                                                } else {
                                                    intent = new Intent(activity, MainActivity.class);
                                                    activity.startActivity(intent);
                                                }
                                                break;

                                            case 113:
                                                activity.startActivity(new Intent(activity, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                                                activity.finish();
                                                break;

                                            case 114:
                                                onBackDialog();
                                                break;

                                            case 115:
                                                Long l = 100L;
                                                int i = l.intValue();
                                                if (getAvailableInternalMemorySize() <= 100L) {
                                                    ShowLowSpaceAlert();
                                                } else {
                                                    lockRunnable.pause();
                                                    showSaveDialog();
                                                }
                                                break;

                                            case 116:
                                                new SelectSong().start();
                                                break;

                                            case 117:
                                                activity.onBackPressed();
                                                break;

                                            case 118:
                                                activity.onBackPressed();
                                                break;
                                            case 119:
                                                activity.setResult(-1);
                                                activity.finish();
                                                break;
                                        }
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    }
                });

    }

    private void requestNewInterstitial() {
        interstitialAd();
    }

    private class AsyncTaskRunner1 extends AsyncTask<String, String, String> {

        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            init();
            MyApplication.getInstance().getFolderList();
            if (MyApplication.getInstance().getAllFolder().size() > 0) {
                loadCreateVideo();
                return "";
            }
            return "Null";
        }


        @Override
        protected void onPostExecute(String result) {
            if (result.equalsIgnoreCase("Null")) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.no_images_found_in_device_please_add_images_in_sdcard), Toast.LENGTH_SHORT).show();
            }
            progressDialog.dismiss();
        }


        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(activity,
                    "Loading Images",
                    "Please Wait...");
        }


        @Override
        protected void onProgressUpdate(String... text) {
        }
    }

    private void loadCreateVideo() {
        if (getAllFolder().size() > 0) {
            MyApplication.isStoryAdded = false;
            MyApplication.isBreak = false;
            setMusicData(null);
            activity.startActivity(new Intent(activity, PhotoselectActivity.class));
        }
    }

    private void loadVideoList() {
        if (Utils.checkPermission(this)) {
            Intent intent = new Intent(activity, ActivityVideoAlbum.class);
            startActivity(intent);
        }
        Utils.requestPermission(this);

    }

    private void addTitle() {
        Intent intent = new Intent(this, AddTitleActivity.class);
        intent.putExtra("ISFROMPREVIEW", isFromPreview);
        activity.startActivity(intent);
        if (isFromPreview) {
            activity.finish();
        }
    }

    private void updateVideoFramesNew(final boolean b, final boolean b2) {
        final ArrayList<ImageData> list = new ArrayList<ImageData>();
        if (MyApplication.isStoryAdded) {
            if (!MyApplication.isStartRemoved && !MyApplication.isLastRemoved) {
                removeSelectedImage(0);
                MyApplication.isStartRemoved = true;
                removeSelectedImage(selectedImages.size() - 1);
                MyApplication.isLastRemoved = true;
                MyApplication.isStoryAdded = false;
            } else {
                if (!MyApplication.isStartRemoved) {
                    removeSelectedImage(0);
                    MyApplication.isStartRemoved = true;
                }
                if (!MyApplication.isLastRemoved) {
                    removeSelectedImage(selectedImages.size() - 1);
                    MyApplication.isLastRemoved = true;
                }
                MyApplication.isStoryAdded = false;
            }
        }
        final ImageData imageData = new ImageData();
        final ImageData imageData2 = new ImageData();
        imageData.imagePath = new File(Fragment_StartFrame.lastsaveTempPath).getAbsolutePath();
        list.add(imageData);
        list.addAll(getSelectedImages());
        imageData2.imagePath = new File(Fragment_EndFrame.lastsaveTempPath).getAbsolutePath();
        list.add(imageData2);
        selectedImages.removeAll(selectedImages);
        selectedImages.addAll(list);
        MyApplication.isStoryAdded = true;
        isEditModeEnable = false;
        if (AddTitleActivity.isFromPreview) {
            PreviewActivity.getmActivity().finish();
        }
        activity.startActivity(new Intent(activity, PreviewActivity.class));
        activity.finish();
    }


    public static void resetBool() {
        AddTitleActivity.isFilterApplied = false;
        AddTitleActivity.isStickerAdded = false;
        AddTitleActivity.isFrameChanged = false;
        AddTitleActivity.isTextAdded = false;
    }

    private void onBackDialog() {
        new AlertDialog.Builder(this, R.style.Theme_MovieMaker_AlertDialog).setTitle(R.string.app_name).setMessage(R.string.are_you_sure_your_video_is_not_prepared_yet_).setPositiveButton(R.string.yes_cap, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                videoImages.clear();
                MyApplication.isBreak = true;
                ((NotificationManager) activity.getSystemService(Service.NOTIFICATION_SERVICE)).cancel(1001);
                activity.finish();
            }
        }).setNegativeButton(R.string.stay_here, null).create().show();
    }

    private static long getAvailableInternalMemorySize() {
        StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
        return (((long) statFs.getAvailableBlocks()) * ((long) statFs.getBlockSize())) / 1048576L;
    }

    private void ShowLowSpaceAlert() {
        final AlertDialog.Builder alertDialog$Builder = new AlertDialog.Builder(this, R.style.AppAlertDialog);
        alertDialog$Builder.setTitle(this.getString(R.string.low_storage_alert));
        alertDialog$Builder.setMessage(this.getString(R.string.low_storage_alert_disc));
        alertDialog$Builder.setPositiveButton(R.string.go_to_settings, new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                activity.startActivityForResult(new Intent("android.settings.SETTINGS"), 0);
            }
        });
        alertDialog$Builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                dialogInterface.dismiss();
            }
        });
        alertDialog$Builder.show();
    }

    private void showSaveDialog() {
        final AlertDialog.Builder alertDialog$Builder = new AlertDialog.Builder(this, R.style.Theme_MovieMaker_AlertDialog);
        final EditText view = new EditText(this);
        view.setHint(R.string.enter_story_name);
        view.setTextColor(-1);
        alertDialog$Builder.setTitle(R.string.enter_video_name);
        alertDialog$Builder.setView(view);
        alertDialog$Builder.setPositiveButton(R.string.save, new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                final StringBuilder sb = new StringBuilder();
                sb.append(view.getText());
                strVideoName = sb.toString();
                if (strVideoName.equals("")) {
                    Toast.makeText(activity, R.string.please_enter_story_name_, Toast.LENGTH_SHORT).show();
                    view.setFocusable(true);
                    view.setSelected(true);
                    return;
                }
                final File file = new File(FileUtils.APP_DIRECTORY.getAbsolutePath());
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(strVideoName);
                sb2.append(".mp4");
                if (new File(file, sb2.toString()).exists()) {
                    Toast.makeText(activity, R.string.video_name_already_exist_, Toast.LENGTH_SHORT).show();
                    view.setFocusable(true);
                    view.setSelected(true);
                    return;
                }
                handler.removeCallbacks(lockRunnable);
                ((Dialog) dialogInterface).getWindow().setSoftInputMode(2);
                loadProgressActivity();
                dialogInterface.dismiss();
            }
        });
        alertDialog$Builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                dialogInterface.dismiss();
            }
        });
        final AlertDialog create = alertDialog$Builder.create();
        create.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimationForVideoTitleDailog;
        final long currentTimeMillis = System.currentTimeMillis();
        final Calendar instance = Calendar.getInstance();
        instance.setTimeInMillis(currentTimeMillis);
        final StringBuilder sb = new StringBuilder();
        sb.append("PhotoSlideshow_");
        sb.append(new SimpleDateFormat("MMddyyyy_HHmm", Locale.getDefault()).format(instance.getTime()));
        sb.append(".mp4");
        view.setText(sb.toString());
        view.selectAll();
        view.requestFocus();
        (create).getWindow().setSoftInputMode(4);
        (create).show();
    }

    private void loadProgressActivity() {
        final Intent intent;
        if (MyApplication.check == 1) {
            intent = new Intent(this, CreateVideoServicenew.class);
            if (!strVideoName.endsWith(".mp4")) {
                final StringBuilder sb = new StringBuilder();
                sb.append(strVideoName);
                sb.append(".mp4");
                strVideoName = sb.toString();
            }
            isFromSdCardAudio = false;
            intent.putExtra("VideoName", strVideoName);
            this.startService(intent);
        } else if (MyApplication.check == 2) {
            intent = new Intent(this, CreateVideoService.class);
            if (!strVideoName.endsWith(".mp4")) {
                final StringBuilder sb = new StringBuilder();
                sb.append(strVideoName);
                sb.append(".mp4");
                strVideoName = sb.toString();
            }
            isFromSdCardAudio = false;
            intent.putExtra("VideoName", strVideoName);
            activity.startService(intent);
        }
        final Intent intent2 = new Intent(activity, ProgressActivity.class);
        intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        activity.startActivity(intent2);
        activity.finish();
    }


    public class SelectSong extends Thread {
        @Override
        public void run() {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    SetMusic();
                    activity.setResult(-1, new Intent(activity, PreviewActivity.class));
                    activity.finish();
                }
            });
        }
    }

    public void SetMusic() {
        try {
            FileUtils.TEMP_DIRECTORY_AUDIO.mkdirs();
            String path = FileUtils.TEMP_DIRECTORY_AUDIO.getAbsolutePath();
            File dir = new File(path);
            if (dir.mkdirs() || dir.isDirectory()) {
                String str_song_name = "temp.mp3";
                CopyRAWtoSDCard(SongList[posForAddMusicDialog], path + File.separator + str_song_name);
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("TAG", "setMusic: " + e.getMessage());
        }

    }

    private void CopyRAWtoSDCard(int id, String path) throws IOException {
        InputStream in = getResources().openRawResource(id);
        FileOutputStream out = new FileOutputStream(path);
        byte[] buff = new byte[1024];
        int read = 0;
        try {
            while ((read = in.read(buff)) > 0) {
                out.write(buff, 0, read);
            }
        } finally {
            in.close();
            out.close();
        }
    }

    private boolean isAudioFile(final String s) {
        return !TextUtils.isEmpty(s) && s.endsWith(".mp3");
    }

    public static boolean isMyServiceRunning(final Context context, final Class<?> clazz) {
        final Iterator<ActivityManager.RunningServiceInfo> iterator = ((ActivityManager) context.getSystemService(ACTIVITY_SERVICE)).getRunningServices(Integer.MAX_VALUE).iterator();
        while (iterator.hasNext()) {
            if (clazz.getName().equals(iterator.next().service.getClassName())) {
                return true;
            }
        }
        return false;
    }


    private void setVideoHeightWidth() {
        final String s = this.getResources().getStringArray(R.array.video_height_width)[EPreferences.getInstance(this.getApplicationContext()).getInt("pref_key_video_quality", 2)];
        final StringBuilder sb = new StringBuilder();
        sb.append("MyApplication VideoQuality value is:- ");
        sb.append(s);
        MyApplication.VIDEO_WIDTH = Integer.parseInt(s.split(Pattern.quote("*"))[0]);
        MyApplication.VIDEO_HEIGHT = Integer.parseInt(s.split(Pattern.quote("*"))[1]);
    }

    public void addSelectedImage(final ImageData imageData) {
        if (MyApplication.isStoryAdded) {
            if (this.selectedImages.size() > 0) {
                this.selectedImages.add(this.selectedImages.size() - 1, imageData);
            } else {
                this.selectedImages.add(imageData);
            }
        } else {
            this.selectedImages.add(imageData);
        }
        ++imageData.imageCount;
    }

    public void removeSelectedImage(final int n) {
        if (n <= this.selectedImages.size()) {
            final ImageData imageData = this.selectedImages.remove(n);
            --imageData.imageCount;
        }
    }


    public void clearAllSelection() {
        this.videoImages.clear();
        this.allAlbum = null;
        this.getSelectedImages().clear();
        System.gc();
        this.getFolderList();
    }

    public void copyAssets() {
        final File file = new File(FileUtils.APP_DIRECTORY, "watermark.png");
        if (!file.exists()) {
            final AssetManager assets = this.getAssets();
            try {
                final InputStream open = assets.open("watermark.png");
                final byte[] array = new byte[1024];
                final FileOutputStream fileOutputStream = new FileOutputStream(file);
                while (true) {
                    final int read = open.read(array, 0, 1024);
                    if (read < 0) {
                        break;
                    }
                    fileOutputStream.write(array, 0, read);
                }
                fileOutputStream.flush();
                fileOutputStream.close();
                open.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void copyList(final ArrayList<ImageData> list) {
        this.selectedImages.addAll(list);
    }

    public HashMap<String, ArrayList<ImageData>> getAllAlbum() {
        return this.allAlbum;
    }

    public ArrayList<String> getAllFolder() {
        if (this.allAlbum != null) {
            Collections.sort(this.allFolder);
            return this.allFolder;
        }
        return this.allFolder;
    }

    public Typeface getApplicationTypeFace() {
        return null;
    }

    public String getBucketNameFromURI(final Uri uri) {
        if (uri.toString().startsWith("/")) {
            return uri.toString();
        }
        final ContentResolver contentResolver = this.getContentResolver();
        final String s = null;
        final Cursor query = contentResolver.query(uri, new String[]{"bucket_display_name"}, s, null, s);
        String string;
        if (query.moveToFirst()) {
            string = query.getString(query.getColumnIndexOrThrow("_data"));
        } else {
            string = null;
        }
        query.close();
        return string;
    }

    public String getCurrentTheme() {
        return this.getSharedPreferences("theme", 0).getString("current_theme", THEMES.Shine.toString());
    }

    public void getFolderList() {
        this.allFolder = new ArrayList<String>();
        this.allAlbum = new HashMap<String, ArrayList<ImageData>>();
        final Cursor query = this.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{"_data", "_id", "bucket_display_name", "bucket_id", "datetaken", "_data"}, null, null, "_data DESC");
        if (query.moveToFirst()) {
            final int columnIndex = query.getColumnIndex("bucket_display_name");
            final int columnIndex2 = query.getColumnIndex("bucket_id");
            this.setSelectedFolderId(query.getString(columnIndex2));
            do {
                final ImageData imageData = new ImageData();
                imageData.imagePath = query.getString(query.getColumnIndex("_data"));
                imageData.imageThumbnail = query.getString(query.getColumnIndex("_data"));
                if (!imageData.imagePath.endsWith(".gif")) {
                    final String string = query.getString(columnIndex);
                    final String string2 = query.getString(columnIndex2);
                    if (!this.allFolder.contains(string2)) {
                        this.allFolder.add(string2);
                    }
                    ArrayList<ImageData> list;
                    if ((list = this.allAlbum.get(string2)) == null) {
                        list = new ArrayList<ImageData>();
                    }
                    imageData.folderName = string;
                    list.add(imageData);
                    this.allAlbum.put(string2, list);
                }
            } while (query.moveToNext());
        }
    }


    public int getFrame() {
        return this.frame;
    }

    public ArrayList<ImageData> getImageByAlbum(final String s) {
        ArrayList<ImageData> list;
        if ((list = this.getAllAlbum().get(s)) == null) {
            list = new ArrayList<ImageData>();
        }
        return list;
    }

    public MusicData getMusicData() {
        return this.musicData;
    }

    public ArrayList<MusicData> getMusicFiles() {
        final ArrayList<MusicData> list = new ArrayList<MusicData>();
        final Cursor query = this.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "title", "_data", "_display_name", "duration"}, "is_music != 0", null, "title ASC");
        final int columnIndex = query.getColumnIndex("_id");
        final int columnIndex2 = query.getColumnIndex("title");
        final int columnIndex3 = query.getColumnIndex("_display_name");
        final int columnIndex4 = query.getColumnIndex("_data");
        final int columnIndex5 = query.getColumnIndex("duration");
        while (query.moveToNext()) {
            final String string = query.getString(columnIndex4);
            if (this.isAudioFile(string)) {
                final MusicData musicData = new MusicData();
                musicData.track_Id = query.getLong(columnIndex);
                musicData.track_Title = query.getString(columnIndex2);
                musicData.track_data = string;
                musicData.track_duration = query.getLong(columnIndex5);
                musicData.track_displayName = query.getString(columnIndex3);
                list.add(musicData);
            }
        }
        return list;
    }

    public ArrayList<MusicData> getMusicFiles(final boolean b) {
        final ArrayList<MusicData> list = new ArrayList<MusicData>();
        final Cursor query = this.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "title", "_data", "_display_name", "duration"}, "is_music != 0", null, "title ASC");
        final int columnIndex = query.getColumnIndex("_id");
        final int columnIndex2 = query.getColumnIndex("title");
        final int columnIndex3 = query.getColumnIndex("_display_name");
        final int columnIndex4 = query.getColumnIndex("_data");
        final int columnIndex5 = query.getColumnIndex("duration");
        while (query.moveToNext()) {
            final String string = query.getString(columnIndex4);
            final StringBuilder sb = new StringBuilder();
            sb.append("GLOB Fatch PAth = ");
            sb.append(string);
            final boolean b2 = false;
            int n = 0;


            if (b) {
                if (this.isAudioFile(string)) {
                    if (this.isAudioFilterPath(string)) {
                        n = 1;
                    }
                }
            } else {
                if (this.isAudioFile(string)) {
                    n = 1;
                }
            }

            if (n == 1) {
                final MusicData musicData = new MusicData();
                musicData.track_Id = query.getLong(columnIndex);
                musicData.track_Title = query.getString(columnIndex2);
                musicData.track_data = string;
                musicData.track_duration = query.getLong(columnIndex5);
                musicData.track_displayName = query.getString(columnIndex3);
                list.add(musicData);
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("Fatch PAth = ");
                sb2.append(musicData.track_data);
            }
        }
        return list;
    }

    public OnProgressReceiver getOnProgressReceiver() {
        return this.onProgressReceiver;
    }

    public float getSecond() {
        return this.second;
    }

    public String getSelectedFolderId() {
        return this.selectedFolderId;
    }

    public ArrayList<ImageData> getSelectedImages() {
        return this.selectedImages;
    }

    public Uri getUriFromPath(final String s) {
        return Uri.fromFile(new File(s));
    }

    public void initArray() {
        this.videoImages = new ArrayList<String>();
    }

    public boolean isAudioFilterPath(final String s) {
        if (this.mAudioDirPath.equals("")) {
            this.mAudioDirPath = Utils.INSTANCE.getAudioFolderPath();
        }
        return s.contains(this.mAudioDirPath);
    }


    public boolean runApp(final String s, final int n) {
        try {
            final Intent intent = new Intent("android.intent.action.MAIN", null);
            intent.addCategory("android.intent.category.LAUNCHER");
            for (final ResolveInfo resolveInfo : this.getPackageManager().queryIntentActivities(intent, 0)) {
                if (resolveInfo.loadLabel(this.getPackageManager()).equals(s)) {
                    final Intent launchIntentForPackage = this.getPackageManager().getLaunchIntentForPackage(resolveInfo.activityInfo.applicationInfo.packageName);
                    if (n != 1) {
                        return launchIntentForPackage != null;
                    }
                    this.startActivity(launchIntentForPackage);
                }
            }
            return false;
        } catch (Exception ex) {
            return false;
        }
    }

    public void setAutostartAppName() {
        if (Build.MANUFACTURER.equals("asus")) {
            Utils.autostart_app_name = "Auto-start Manager";
            return;
        }
        if (Build.MANUFACTURER.equals("Xiaomi")) {
            Utils.autostart_app_name = "Security";
        }
    }

    public void setCurrentTheme(final String s) {
        final SharedPreferences.Editor edit = this.getSharedPreferences("theme", 0).edit();
        edit.putString("current_theme", s);
        edit.commit();
    }

    public void setFrame(final int frame) {
        this.frame = frame;
    }

    public void setMusicData(final MusicData musicData) {
        this.musicData = musicData;
    }

    public void setOnProgressReceiver(final OnProgressReceiver onProgressReceiver) {
        this.onProgressReceiver = onProgressReceiver;
    }

    public void setSecond(final float second) {
        this.second = second;
    }

    public void setSelectedFolderId(final String selectedFolderId) {
        this.selectedFolderId = selectedFolderId;
    }

    public ArrayList<ImageData> sortDescending() {
        Collections.sort(null, Collections.reverseOrder());
        return null;
    }
}
