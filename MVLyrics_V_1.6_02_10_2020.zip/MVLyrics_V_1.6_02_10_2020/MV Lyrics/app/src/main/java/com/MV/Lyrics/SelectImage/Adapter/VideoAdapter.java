package com.MV.Lyrics.SelectImage.Adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.R;
import com.MV.Lyrics.SelectImage.Interface.OnItemClickListner;
import com.MV.Lyrics.SelectImage.Model.VideoModel;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<VideoModel> VideoList;
    private OnItemClickListner<Object> clickListner;

    public VideoAdapter(Context context, ArrayList<VideoModel> VideoList) {
        this.context = context;
        this.VideoList = VideoList;
    }

    public void setOnItemClickListner(OnItemClickListner<Object> clickListner) {
        this.clickListner = clickListner;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_video_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        VideoModel videoModel = VideoList.get(position);
        Glide.with(context).load(videoModel.getVideoFullPath()).into(holder.ivThumb);
        holder.tvVideoName.setText(videoModel.getVideoName());
        holder.tvVideoTime.setText(String.valueOf(Utils.INSTANCE.TimeCaculate(videoModel.getVideoDuration())));
        holder.layoutVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (clickListner != null) {
                    clickListner.onItemClick(view, position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return VideoList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        LinearLayout layoutVideo, layoutUseVideo;
        public CircleImageView ivThumb;
        public TextView tvVideoName, tvVideoTime, tvUseVideo;

        public MyViewHolder(View view) {
            super(view);
            layoutVideo = view.findViewById(R.id.ll_Video);
            layoutUseVideo = view.findViewById(R.id.llUseVideo);
            ivThumb = view.findViewById(R.id.iv_thumb);
            tvVideoName = view.findViewById(R.id.tvVideoName);
            tvVideoTime = view.findViewById(R.id.tvVideoTime);
            tvUseVideo = view.findViewById(R.id.tvUseVideo);

        }
    }
}

