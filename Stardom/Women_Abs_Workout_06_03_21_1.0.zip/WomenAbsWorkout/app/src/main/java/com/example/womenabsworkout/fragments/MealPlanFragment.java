package com.example.womenabsworkout.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.adapters.MealsAdapter;
import com.example.womenabsworkout.kprogresshud.KProgressHUD;
import com.example.womenabsworkout.listners.RecyclerItemClickListener;
import com.example.womenabsworkout.utils.MealsItemObject;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import static com.example.womenabsworkout.utils.Constants.Position;

import java.util.ArrayList;
import java.util.List;


public class MealPlanFragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public static final String TAG = "RecyclerViewFragment";
    public Button mShoppingBtn;
    public boolean isfirst = false;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    private List<MealsItemObject> getAllItemList() {
        ArrayList arrayList = new ArrayList();
        int i = 0;
        while (i < 30) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getResources().getString(R.string.day));
            i++;
            stringBuilder.append(i);
            arrayList.add(new MealsItemObject(stringBuilder.toString()));
        }
        return arrayList;
    }

    public static MealPlanFragment newInstance(String str, String str2) {
        MealPlanFragment mealPlanFragment = new MealPlanFragment();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_PARAM1, str);
        bundle.putString(ARG_PARAM2, str2);
        mealPlanFragment.setArguments(bundle);
        return mealPlanFragment;
    }

  /*  @Override
    public void onStart() {
        super.onStart();
        isfirst = true;
        Log.e("TAG", "Onstart" + isfirst);
    }*/

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isfirst = true;
        Log.e("TAG", "Onstart" + isfirst);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.meals_app_bar_main, viewGroup, false);

       interstitialAd();

        inflate.setTag(TAG);
        setHasOptionsMenu(true);
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.recycler);

        MealsAdapter mealsAdapter = new MealsAdapter(getActivity(), getAllItemList());

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        recyclerView.setAdapter(mealsAdapter);


        recyclerView.setLayoutManager(gridLayoutManager);

        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.onItemClickListener() {
            @Override
            public void OnItem(View view, int i) {
                Log.e("FFFFf", "dddddddddddd");
                if (isfirst) {

                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        try {
                            hud = KProgressHUD.create(getActivity())
                                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                    .setLabel("Showing Ads")
                                    .setDetailsLabel("Please Wait...");
                            hud.show();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();
                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }

                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    hud.dismiss();
                                } catch (IllegalArgumentException e) {
                                    e.printStackTrace();

                                } catch (NullPointerException e2) {
                                    e2.printStackTrace();
                                } catch (Exception e3) {
                                    e3.printStackTrace();
                                }
                                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                    id = 100;
                                    mInterstitialAd.show();
                                }
                            }
                        }, 2000);
                    } else {
                        DailyMeal dailyMeal = new DailyMeal();
                        Bundle bundle = new Bundle();
                        Position = i;
                        bundle.putInt("DAY", Position + 1);
                        Log.e("onPoddd", String.valueOf(Position + 1));
                        dailyMeal.setArguments(bundle);
                        FragmentTransaction beginTransaction = ((AppCompatActivity) getActivity()).getSupportFragmentManager().beginTransaction();
                        beginTransaction.replace(R.id.fragment_container, dailyMeal);
                        beginTransaction.addToBackStack((String) null);
                        beginTransaction.commit();
                    }


                } else {
                    DailyMeal dailyMeal = new DailyMeal();
                    Bundle bundle = new Bundle();
                    Position = i;
                    bundle.putInt("DAY", Position + 1);
                    Log.e("onPoddd", String.valueOf(Position + 1));
                    dailyMeal.setArguments(bundle);
                    FragmentTransaction beginTransaction = ((AppCompatActivity) getActivity()).getSupportFragmentManager().beginTransaction();
                    beginTransaction.replace(R.id.fragment_container, dailyMeal);
                    beginTransaction.addToBackStack((String) null);
                    beginTransaction.commit();
                }
            }
        }));



        Button button = (Button) inflate.findViewById(R.id.shoppinglistbtn);
        this.mShoppingBtn = button;

        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ShoppingListFragment shoppingListFragment = new ShoppingListFragment();
                FragmentTransaction beginTransaction = MealPlanFragment.this.getFragmentManager().beginTransaction();
                beginTransaction.replace(R.id.fragment_container, shoppingListFragment);
                beginTransaction.addToBackStack((String) null);
                beginTransaction.commit();
            }
        });
        return inflate;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            getActivity().finish();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(getActivity());
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        DailyMeal dailyMeal = new DailyMeal();
                        Bundle bundle = new Bundle();
                        bundle.putInt("DAY", Position + 1);

                        dailyMeal.setArguments(bundle);
                        FragmentTransaction beginTransaction = ((AppCompatActivity) getActivity()).getSupportFragmentManager().beginTransaction();
                        beginTransaction.replace(R.id.fragment_container, dailyMeal);
                        beginTransaction.addToBackStack((String) null);
                        beginTransaction.commit();
                        isfirst = false;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(getActivity());
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
