package com.wavymusic.DashBord.Fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.DashBord.Adapter.ThemeViewAllAdapterWavy;
import com.wavymusic.DashBord.Model.ThemeHomeModel;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.Preferance.LanguagePref;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.APIClient;
import com.wavymusic.RetrofitApiCall.APIInterface;
import com.wavymusic.RetrofitApiCall.AppConstant;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

public class ThemeViewAllFragmentWavy extends Fragment {

    public static LanguagePref sharedpreferences;
    public int id;
    public Handler i;
    LinearLayout llInternetCheck;
    Button btnRetry;
    RelativeLayout rlLoadingTheme;
    RecyclerView rvVideos;
    String offlineThemeData;
    int CategoryId = -1;
    String CatId;
    SharedPreferences pref;
    GridLayoutManager gridLayoutManager;

    private String WhsThemeItem;
    private ArrayList<ThemeHomeModel> ThemeListCategoryWise = new ArrayList<>();
    private ThemeViewAllAdapterWavy themeAdapter;
    APIInterface apiInterface;

    public static ThemeViewAllFragmentWavy newInstance(int catid) {
        ThemeViewAllFragmentWavy fragment = new ThemeViewAllFragmentWavy();
        Bundle bundle = new Bundle();
        bundle.putInt("CategoryId", catid);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            CategoryId = getArguments().getInt("CategoryId");
            CatId = String.valueOf(CategoryId);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_theme, container, false);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        sharedpreferences = LanguagePref.a(getActivity());
        apiInterface = APIClient.getClient().create(APIInterface.class);
        BindView(view);
        SetListener();
        if (ThemeListCategoryWise != null && ThemeListCategoryWise.size() == 0) {
            if (CategoryId == 111) {
                WhatsNewData();
            } else {
                SetThemeData();
            }
        } else {
            SetUpAdapter();
        }
        return view;
    }

    private void WhatsNewData() {
        getNewgetOfflineCategory(getActivity(), "NewThemeWavy");
        if (WhsThemeItem != null) {
            new WhatsNewData().execute(WhsThemeItem);
        }
    }

    private void SetThemeData() {
        String id = pref.getString("Wavy" + CatId, null);
        if (id != null && !id.equals("")) {
            getOfflineCategory(getActivity(), "Wavy" + CatId);
            if (offlineThemeData != null) {
                new GetofflineThemeData().execute();
            } else {
                llInternetCheck.setVisibility(View.VISIBLE);
                rlLoadingTheme.setVisibility(View.GONE);
                Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void BindView(View view) {
//        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
        rvVideos = view.findViewById(R.id.rvVideos);
        llInternetCheck = view.findViewById(R.id.llRetry);
        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
        rlLoadingTheme = view.findViewById(R.id.rl_loading_pager);
        rvVideos.setNestedScrollingEnabled(false);
        rvVideos.setHasFixedSize(true);
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    startActivity(new Intent(getActivity(), DashbordActivity.class));
                    getActivity().finish();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
        /*mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    ThemeListCategoryWise.clear();
                    GetCategoryOfTheme();
                    mSwipeRefreshLayout.setRefreshing(false);
                } else {
                    mSwipeRefreshLayout.setRefreshing(false);
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_SHORT).show();
                }
            }
        });*/

    }

    private void getNewgetOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        WhsThemeItem = pref.getString(key, null);
    }


    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlineThemeData = pref.getString(key, null);
    }


    private void SetUpAdapter() {
        RecyclerView recyclerView;
        int i2 = 0;
        gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        themeAdapter = new ThemeViewAllAdapterWavy(getActivity(), ThemeListCategoryWise);
        rvVideos.setLayoutManager(gridLayoutManager);
        rvVideos.setItemAnimator(new DefaultItemAnimator());
        rvVideos.setAdapter(themeAdapter);
        if (MyApplication.ThemePositionWavy == -1) {
            recyclerView = this.rvVideos;
        } else {
            recyclerView = this.rvVideos;
            i2 = MyApplication.ThemePositionWavy;
        }
        recyclerView.scrollToPosition(i2);
        rvVideos.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(gridLayoutManager.findFirstVisibleItemPosition());
                stringBuilder.append("");
                MyApplication.ThemePositionWavy = gridLayoutManager.findFirstVisibleItemPosition();
            }
        });
        themeAdapter.notifyDataSetChanged();
        if (!MyApplication.IsHomeAdsDisplay && MyApplication.mInterstitialAdWavy != null && MyApplication.mInterstitialAdWavy.isLoaded()) {
            MyApplication.IsHomeAdsDisplay = true;
            MyApplication.AdsId = 8;
            MyApplication.mInterstitialAdUv.show();
        }else if (!MyApplication.IsHomeAdsDisplay && MyApplication.fbinterstitialAd != null && MyApplication.fbinterstitialAd.isAdLoaded()) {
            MyApplication.IsHomeAdsDisplay = true;
            MyApplication.AdsId = 8;
            MyApplication.fbinterstitialAd.show();
        }
    }


    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }


    @SuppressLint("StaticFieldLeak")
    public class GetofflineThemeData extends AsyncTask<Void, Void, Void> {

        protected void onPreExecute() {
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlineThemeData);
                JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
                for (int j = 0; j < jSONArray4.length(); j++) {
                    ThemeHomeModel themeModel = new ThemeHomeModel();
                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                    themeModel.setThemeid(jsonobjecttheme.getString("id"));
                    themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                    themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                    themeModel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                    themeModel.setSmall_Thumbnail(jsonobjecttheme.getString("small_thumbnail"));
                    themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                    themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                    themeModel.setAnimSoundPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                    themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                    themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                    themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                    themeModel.setThemeCounter(jsonobjecttheme.getString("downloads"));
                    themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                    ThemeListCategoryWise.add(themeModel);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(Void result) {
            rlLoadingTheme.setVisibility(View.GONE);
            SetUpAdapter();
        }
    }


    @SuppressLint("StaticFieldLeak")
    public class WhatsNewData extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected String doInBackground(String... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(arg0[0]);
                JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
                for (int j = 0; j < jSONArray4.length(); j++) {
                    ThemeHomeModel themeModel = new ThemeHomeModel();
                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                    themeModel.setThemeid(jsonobjecttheme.getString("id"));
                    themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                    themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                    themeModel.setImage(AppConstant.ThemeThumburlWavy + jsonobjecttheme.getString("theme_thumbnail"));
                    themeModel.setSmall_Thumbnail(AppConstant.SmallThemeThumbrlWavy + jsonobjecttheme.getString("small_thumbnail"));
                    themeModel.setAnimsoundurl(AppConstant.SoundUrlWavy + jsonobjecttheme.getString("sound_file"));
                    themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename"));
                    themeModel.setAnimSoundPath(new File(Utils.PathOfThemeFolder).getAbsolutePath()  + File.separator + themeModel.getAnimSoundname());
                    themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                    themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                    themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                    themeModel.setThemeCounter(jsonobjecttheme.getString("downloads"));
                    themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                    if (themeModel.isNewRealise().equals("1")) {
                        ThemeListCategoryWise.add(themeModel);
                    }
                    /*if (isAdded()) {
                        if (Utils.checkConnectivity(getActivity(), false)) {
                            if (MyApplication.getInstance().IsNativeAdsLoaded) {
                                if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                    themeModel.setNativeAds(true);
                                    ThemeListCategoryWise.add(j, themeModel);
                                }
                            }
                        }
                    }*/
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(String result) {
            rlLoadingTheme.setVisibility(View.GONE);
            SetUpAdapter();
        }
    }

}
