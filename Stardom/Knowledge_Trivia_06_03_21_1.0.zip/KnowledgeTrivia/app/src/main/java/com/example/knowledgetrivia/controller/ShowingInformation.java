package com.example.knowledgetrivia.controller;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.knowledgetrivia.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.muddzdev.styleabletoast.StyleableToast;
import java.util.Calendar;

public class ShowingInformation extends AppCompatActivity {
    private ProgressDialog dialog;
    private TextView readText;
    private String textToShow = "";
    private MediaPlayer tick;

    public void onCreate(Bundle bundle) {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_showing_information);
        this.readText = (TextView) findViewById(R.id.lay_si_showInformation);


        this.tick = MediaPlayer.create(this, R.raw.tick);

        ((Button) findViewById(R.id.goBack)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ShowingInformation.this.tick.start();
                ShowingInformation.this.finish();
            }
        });
        this.dialog = new ProgressDialog(this);
        this.dialog.setIndeterminate(true);
        this.dialog.setCanceledOnTouchOutside(false);
        this.dialog.setMessage("Loading Information...");
        this.dialog.show();
        //loadInformation();
    }

    private void loadInformation()
    {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("informations");
        int i = Calendar.getInstance().get(5);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("D");
        stringBuilder.append(i);
        reference.child(stringBuilder.toString()).addListenerForSingleValueEvent(new ValueEventListener()
        {
            public void onDataChange(DataSnapshot dataSnapshot) {
                ShowingInformation.this.textToShow = (String) dataSnapshot.getValue(String.class);
            }

            public void onCancelled(DatabaseError databaseError)
            {
                new StyleableToast.Builder(ShowingInformation.this.getApplicationContext()).text("Database connectivity failed.").backgroundColor(ContextCompat.getColor(ShowingInformation.this.getApplicationContext(), R.color.sad_color)).textColor(-1).length(0).iconStart(R.drawable.sad).solidBackground().show();
            }
        });
    }

    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}
