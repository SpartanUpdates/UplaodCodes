package com.MV.Lyrics.Partical.Model;

public class ParticalModel {
    private int catId;
    private String ThemeName;
    private String BundelName;
    private String GmaeObjName;
    private String ThemeBundel;
    private String ThumbImage;
    private boolean IsFromAsset;
    private String ThemeBundelPath;
    private String ThemeUnity3dPath;
    private int BundelSize;
    public boolean isAvailableOffline = false;
    public boolean isDownloading = false;

    public boolean j;
    public boolean g;

    public boolean IsAssetSelected=false;
    public String getThemeName() {
        return ThemeName;
    }

    public void setThemeName(String themeName) {
        ThemeName = themeName;
    }

    public int getCatId() {
        return catId;
    }

    public void setCatId(int catId) {
        this.catId = catId;
    }

    public String getBundelName() {
        return BundelName;
    }

    public void setBundelName(String bundelName) {
        BundelName = bundelName;
    }

    public String getGmaeObjName() {
        return GmaeObjName;
    }

    public void setGmaeObjName(String gmaeObjName) {
        GmaeObjName = gmaeObjName;
    }

    public String getThemeBundel() {
        return ThemeBundel;
    }

    public void setThemeBundel(String themeBundel) {
        ThemeBundel = themeBundel;
    }

    public String getThumbImage() {
        return ThumbImage;
    }

    public void setThumbImage(String thumbImage) {
        ThumbImage = thumbImage;
    }

    public boolean isFromAsset() {
        return IsFromAsset;
    }


    public void setFromAsset(boolean fromAsset) {
        IsFromAsset = fromAsset;
    }

    public String getThemeBundelPath() {
        return ThemeBundelPath;
    }

    public void setThemeBundelPath(String themeBundelPath) {
        ThemeBundelPath = themeBundelPath;
    }

    public String getThemeUnity3dPath() {
        return ThemeUnity3dPath;
    }

    public void setThemeUnity3dPath(String themeUnity3dPath) {
        ThemeUnity3dPath = themeUnity3dPath;
    }

    public int getBundelSize() {
        return BundelSize;
    }

    public void setBundelSize(int bundelSize) {
        BundelSize = bundelSize;
    }

    @Override
    public final boolean equals(final Object o) {
        return o instanceof ParticalModel && this.GmaeObjName.equals(((ParticalModel)o).GmaeObjName);
    }

    @Override
    public final int hashCode() {
        return this.GmaeObjName.hashCode();
    }
}
