package com.esc.phoneheart.advancedclean;

import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.provider.Settings;
import android.util.Log;

import com.esc.phoneheart.advancedclean.BaseActivity.IPActivityListener;

public class StepCheckOverlayPermission extends Step implements IPActivityListener {
    public static final String TAG = "StepCheckOverlayPermi";
    public BaseActivity mActivity;

    public StepCheckOverlayPermission(BaseActivity baseActivity) {
        this.mActivity = baseActivity;
    }

    private void afterSettings() {
        int i = VERSION.SDK_INT;
        String str = TAG;
        if (i < 23 || !Settings.canDrawOverlays(this.mActivity)) {
            Log.i(str, "permission not grant yet,we can't step forward,finish it.");
            this.mActivity.finish();
            return;
        }
        Log.i(str, "we are granted to show overlay, check next.");
        doNext();
    }

    public void doAction() {
        if (VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this.mActivity)) {
            doNext();
            return;
        }
        this.mActivity.addResultListener(this);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("package:");
        stringBuilder.append(this.mActivity.getPackageName());
        this.mActivity.startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse(stringBuilder.toString())), 1001);
    }

    public boolean onActivityResult(int i, int i2, Intent intent) {
        if (i != 1001) {
            return false;
        }
        afterSettings();
        return true;
    }

    public void onRestart() {
        afterSettings();
    }
}
