package com.esc.motivationquotes.util;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.util.Base64;
import java.io.ByteArrayOutputStream;

public class BitmapUtils {
    public static String encodeBitmap(Bitmap bitmap) {
        if (bitmap == null) {
            return null;
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(CompressFormat.PNG, 100, byteArrayOutputStream);
        return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
    }

    public static Bitmap decodeBitmap(String str) {
        if (str.equalsIgnoreCase("")) {
            return null;
        }
        byte[] decode = Base64.decode(str.getBytes(), 0);
        return BitmapFactory.decodeByteArray(decode, 0, decode.length);
    }
}
