package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.View;
import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.FestivalFrameListAdapter;

public class m implements View.OnClickListener {
    public final  int n;
    public final  FestivalFrameListAdapter o;

    public m(FestivalFrameListAdapter festivalFrameListAdapter, int i) {
        this.o = festivalFrameListAdapter;
        this.n = i;
    }

    public void onClick(View view) {
        FestivalFrameListAdapter festivalFrameListAdapter = this.o;
        festivalFrameListAdapter.t = this.n;
        festivalFrameListAdapter.notifyDataSetChanged();
        festivalFrameListAdapter = this.o;
        festivalFrameListAdapter.r.a(this.n, festivalFrameListAdapter.s);
    }

}
