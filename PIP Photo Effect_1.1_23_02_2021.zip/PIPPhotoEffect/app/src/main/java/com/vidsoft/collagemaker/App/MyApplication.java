package com.vidsoft.collagemaker.App;


import android.app.Application;
import android.content.Context;
import com.facebook.ads.AdSettings;

public class MyApplication extends Application {


    private static MyApplication instance;
    public static Context mContext;

    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        MyApplication.mContext = this.getApplicationContext();
        AdSettings.addTestDevice("edc1db29-69cd-4296-a77d-d9f3782002b2");
    }
}
