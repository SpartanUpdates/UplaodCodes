package com.esc.poems;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.multidex.MultiDex;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class MyApplication extends Application {
    static String appLink = "https://play.google.com/store/apps/details?id=com.internetdesignzone.poems";
    static Boolean onceOnly = Boolean.valueOf(false);
    static String privacyPolicy = "http://www.touchzing.com/privacy/";

    public static InterstitialAd mInterstitialAd;
    public static int AdsId;
    public static Activity AdsShowContext;

    public void onCreate() {
        super.onCreate();
        onceOnly = Boolean.FALSE;
        InterstitialAd();
    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (AdsId) {
                    case 1:
                        GoToNext();
                        break;
                    case 2:
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });
    }

    private void GoToNext() {
        Intent intent = new Intent(AdsShowContext, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

}
