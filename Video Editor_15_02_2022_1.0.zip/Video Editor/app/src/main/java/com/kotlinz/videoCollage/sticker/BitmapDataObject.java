package com.kotlinz.videoCollage.sticker;

import java.io.Serializable;

public class BitmapDataObject implements Serializable {
    private static final long serialVersionUID = 111696345129311948L;
    public byte[] imageByteArray;
}
