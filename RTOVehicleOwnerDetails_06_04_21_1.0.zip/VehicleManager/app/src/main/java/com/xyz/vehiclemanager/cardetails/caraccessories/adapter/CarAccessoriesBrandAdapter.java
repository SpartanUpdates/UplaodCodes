package com.xyz.vehiclemanager.cardetails.caraccessories.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.cardetails.caraccessories.activity.CarAccessoriesDetailsActivity;
import com.xyz.vehiclemanager.cardetails.caraccessories.model.CarAccessories;
import com.xyz.vehiclemanager.model.CarBrands;

import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CarAccessoriesBrandAdapter extends RecyclerView.Adapter<CarAccessoriesBrandAdapter.MyViewHolder>
{
    Context mcontext;
    ArrayList<CarBrands> carBrandlist;

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_brandName;
        ImageView iv_brandImage;
        LinearLayout rl_carbrand;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_brandName=itemView.findViewById(R.id.tv_carbrandsname);
            iv_brandImage=itemView.findViewById(R.id.iv_carbrands);
            rl_carbrand = itemView.findViewById(R.id.ll_carbrand);
        }
    }

    public CarAccessoriesBrandAdapter(Context context, ArrayList<CarBrands> carBrandslist) {
        this.mcontext = context;
        this.carBrandlist = carBrandslist;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_carbrads,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {

        final CarBrands carBrands = carBrandlist.get(position);
        holder.tv_brandName.setText(carBrands.getBrandName());
        Glide.with(mcontext)
                .load(carBrands.getImageUrl())
                .placeholder(R.drawable.ic_car)
                .into(holder.iv_brandImage);


        holder.rl_carbrand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(mcontext, CarAccessoriesDetailsActivity.class);
                intent.putExtra("id", carBrands.getId());
                intent.putExtra("brandName",carBrands.getBrandName());
                mcontext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return carBrandlist.size();
    }
}
