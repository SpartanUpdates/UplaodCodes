﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using GoogleMobileAds.Api;
using UnityEngine.Analytics;

namespace BallCollect
{
    public class BannerAddView : MonoBehaviour
    {
        public static BannerAddView instance;

        private BannerView bannerView;

        public void Awake()
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
            RequestBanner();
        }
        private void OnEnable()
        {
            this.bannerView.OnAdLoaded += this.OnBannerAdLoaded;
            this.bannerView.OnAdFailedToLoad += this.OnBannerAdFailedToLoad;
            this.bannerView.OnAdOpening += this.OnBannerAdOpened;
            this.bannerView.OnAdClosed += this.OnBannerAdClosed;
            this.bannerView.OnAdLeavingApplication += this.OnBannerAdLeavingApplication;
        }

        private void OnDisable()
        {
            bannerView.Destroy();
            this.bannerView.OnAdLoaded -= this.OnBannerAdLoaded;
            this.bannerView.OnAdFailedToLoad -= this.OnBannerAdFailedToLoad;
            this.bannerView.OnAdOpening -= this.OnBannerAdOpened;
            this.bannerView.OnAdClosed -= this.OnBannerAdClosed;
            this.bannerView.OnAdLeavingApplication -= this.OnBannerAdLeavingApplication;
        }
        private void RequestBanner()
        {
            if (Manager.instance.isBannerAdsShow)
            {
                Analytics.CustomEvent("Banner_Ads_Request_Fire");
                AdSize adSize;

                if (Manager.instance.isAdaptiveAds)
                {
                    adSize = AdSize.GetLandscapeAnchoredAdaptiveBannerAdSizeWithWidth(AdSize.FullWidth);
                    Analytics.CustomEvent("Banner_Ads_Adaptive_BannerAds_Fire");
                }
                else
                {
                    adSize = AdSize.SmartBanner;
                    Analytics.CustomEvent("Banner_Ads_Smart_BannerAds_Fire");
                }

                this.bannerView = new BannerView(Manager.instance.bannerID, adSize, AdPosition.Bottom);

                AdRequest request = new AdRequest.Builder().Build();

                this.bannerView.LoadAd(request);
            }
        }

        public void ShowBannerAdd()
        {
            this.bannerView.Show();
        }
      
        public void DestroyBannerAdd()
        {
            bannerView.Hide();
        }


        //Banner Add
        public void OnBannerAdLoaded(object sender, EventArgs args)
        {
            if (!MainMenu.instance.shopPanel.activeSelf)
            {
                this.bannerView.Show();
                Analytics.CustomEvent("Banner_Ads_Show");
            }
        }

        public void OnBannerAdFailedToLoad(object sender, AdFailedToLoadEventArgs args)
        {
            Analytics.CustomEvent("Banner_Ads_Request_Fail");
        }

        public void OnBannerAdOpened(object sender, EventArgs args)
        {
        }

        public void OnBannerAdClosed(object sender, EventArgs args)
        {
        }

        public void OnBannerAdLeavingApplication(object sender, EventArgs args)
        {
        }
    }
}