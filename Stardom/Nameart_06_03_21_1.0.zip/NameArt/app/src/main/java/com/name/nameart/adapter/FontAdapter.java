package com.name.nameart.adapter;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.name.nameart.MyUtils.MyPreference;
import com.name.nameart.R;
import com.name.nameart.sticker.StickerView;

import java.util.ArrayList;

public class FontAdapter extends RecyclerView.Adapter<FontAdapter.ViewHolder> {
    public static StickerView mCurrentView;
    public ArrayList<Integer> coloe_array;
    Context context;
    ArrayList<String> fontarray;
    int index = -1;
    OnSelect onSelect;
    String status;

    public interface OnSelect {
        void onSelectfont(String str);
    }

    public FontAdapter(Context context2, String str, OnSelect onSelect2) {
        this.context = context2;
        this.status = str;
        this.onSelect = onSelect2;
        ArrayList<String> arrayList = new ArrayList<>();
        this.fontarray = arrayList;
        arrayList.add("f14.otf");
        this.fontarray.add("normal_font.ttf");
        this.fontarray.add("f27.ttf");
        this.fontarray.add("f28.ttf");
        this.fontarray.add("f29.ttf");
        this.fontarray.add("f31.ttf");
        this.fontarray.add("f15.ttf");
        this.fontarray.add("f16.ttf");
        this.fontarray.add("f18.ttf");
        this.fontarray.add("f19.ttf");
        this.fontarray.add("f20.ttf");
        this.fontarray.add("f21.ttf");
        this.fontarray.add("f22.ttf");
        this.fontarray.add("f23.ttf");
        this.fontarray.add("f24.ttf");
        this.fontarray.add("f26.otf");
        this.fontarray.add("f1.ttf");
        this.fontarray.add("f2.ttf");
        this.fontarray.add("f3.ttf");
        this.fontarray.add("f4.ttf");
        this.fontarray.add("f5.ttf");
        this.fontarray.add("f6.ttf");
        this.fontarray.add("f7.ttf");
        this.fontarray.add("f8.ttf");
        this.fontarray.add("f9.ttf");
        this.fontarray.add("f10.ttf");
        this.fontarray.add("f11.ttf");
        this.fontarray.add("f12.ttf");
        this.fontarray.add("f13.ttf");
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.font_adapter, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        try {
            viewHolder.font_row_txt.setText(this.status);
            AssetManager assets = this.context.getAssets();
            TextView textView = viewHolder.font_row_txt;
            textView.setTypeface(Typeface.createFromAsset(assets, "fonts/" + this.fontarray.get(i)));
            viewHolder.font_row_txt.setOnClickListener(new View.OnClickListener()
            {
                public void onClick(View view)
                {
                    FontAdapter.this.index = i;
                    FontAdapter.this.notifyDataSetChanged();
                    MyPreference.Companion.writeSharedPreferences(MyPreference.FONT_STYLE, FontAdapter.this.fontarray.get(i));
                    FontAdapter.this.onSelect.onSelectfont(FontAdapter.this.fontarray.get(i));
                }
            });

            if (this.index == i)
            {
                viewHolder.font_row_txt.setBackgroundResource(R.drawable.bg_selected);
            } else {
                viewHolder.font_row_txt.setBackgroundColor(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return this.fontarray.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView font_row_txt;
        public View parentLayout;

        public ViewHolder(View view)
        {
            super(view);
            this.font_row_txt = (TextView) view.findViewById(R.id.font_row_txt);
        }
    }
}
