package com.esc.photoslideshow.mask;

import com.esc.photoslideshow.R;

import java.util.ArrayList;

public enum Themes1 {
    Shine("Shine") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> mEffects = new ArrayList();
            mEffects.add(MaskBitmap.EFFECT.PIN_WHEEL);
            mEffects.add(MaskBitmap.EFFECT.SKEW_RIGHT_SPLIT);
            mEffects.add(MaskBitmap.EFFECT.SKEW_LEFT_SPLIT);
            mEffects.add(MaskBitmap.EFFECT.SKEW_RIGHT_MEARGE);
            mEffects.add(MaskBitmap.EFFECT.SKEW_LEFT_MEARGE);
            mEffects.add(MaskBitmap.EFFECT.FOUR_TRIANGLE);
            mEffects.add(MaskBitmap.EFFECT.SQUARE_IN);
            mEffects.add(MaskBitmap.EFFECT.SQUARE_OUT);
            mEffects.add(MaskBitmap.EFFECT.CIRCLE_LEFT_BOTTOM);
            mEffects.add(MaskBitmap.EFFECT.CIRCLE_IN);
            mEffects.add(MaskBitmap.EFFECT.DIAMOND_OUT);
            mEffects.add(MaskBitmap.EFFECT.HORIZONTAL_COLUMN_DOWNMASK);
            mEffects.add(MaskBitmap.EFFECT.RECT_RANDOM);
            mEffects.add(MaskBitmap.EFFECT.CROSS_IN);
            mEffects.add(MaskBitmap.EFFECT.DIAMOND_IN);
            return mEffects;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return null;
        }

        public int getThemeDrawable() {
            return R.drawable.all_animation_2;
        }

        public int getThemeMusic() {
            return R.raw._1;
        }
    },
    Love("Love") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> mEffects = new ArrayList();
            mEffects.add(MaskBitmap.EFFECT.CIRCLE_IN);
            mEffects.add(MaskBitmap.EFFECT.HORIZONTAL_RECT);
            mEffects.add(MaskBitmap.EFFECT.HORIZONTAL_COLUMN_DOWNMASK);
            mEffects.add(MaskBitmap.EFFECT.LEAF);
            return mEffects;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return null;
        }

        public int getThemeDrawable() {
            return R.drawable.love;
        }

        public int getThemeMusic() {
            return R.raw._3;
        }
    },
    CIRCLE_IN("Circle In") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.CIRCLE_IN);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.circle_in;
        }

        public int getThemeMusic() {
            return R.raw._5;
        }
    },
    CIRCLE_LEFT_BOTTOM("Circle Left Bottom") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.CIRCLE_LEFT_BOTTOM);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.circle_left_up;
        }

        public int getThemeMusic() {
            return R.raw._1;
        }
    },
    CIRCLE_OUT("Circle Out") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.CIRCLE_OUT);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.circle_out;
        }

        public int getThemeMusic() {
            return R.raw._3;
        }
    },
    CIRCLE_RIGHT_BOTTOM("Circle Right Bottom") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.CIRCLE_RIGHT_BOTTOM);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.circle_right_bottom;
        }

        public int getThemeMusic() {
            return R.raw._4;
        }
    },
    DIAMOND_IN("Diamond In") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.DIAMOND_IN);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.daimond_in;
        }

        public int getThemeMusic() {
            return R.raw._1;
        }
    },
    DIAMOND_OUT("Diamond out") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.DIAMOND_OUT);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.daimond_out;
        }

        public int getThemeMusic() {
            return R.raw._2;
        }
    },
    ECLIPSE_IN("Eclipse In") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.ECLIPSE_IN);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.eclipse_in;
        }

        public int getThemeMusic() {
            return R.raw._3;
        }
    },
    FOUR_TRIANGLE("Four Triangle") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.FOUR_TRIANGLE);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.four_train;
        }

        public int getThemeMusic() {
            return R.raw._4;
        }
    },
    OPEN_DOOR("Open Door") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.OPEN_DOOR);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.open_door;
        }

        public int getThemeMusic() {
            return R.raw._1;
        }
    },
    PIN_WHEEL("Pin Wheel") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.PIN_WHEEL);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.pin_wheel;
        }

        public int getThemeMusic() {
            return R.raw._2;
        }
    },
    RECT_RANDOM("Rect Random") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.RECT_RANDOM);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.rect_rand;
        }

        public int getThemeMusic() {
            return R.raw._3;
        }
    },
    SKEW_LEFT_MEARGE("Skew Left Mearge") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.SKEW_LEFT_MEARGE);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.skew_left_close;
        }

        public int getThemeMusic() {
            return R.raw._4;
        }
    },
    SKEW_RIGHT_MEARGE("Skew Right Mearge") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.SKEW_RIGHT_MEARGE);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.skew_right_open;
        }

        public int getThemeMusic() {
            return R.raw._1;
        }
    },
    SQUARE_OUT("Square Out") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.SQUARE_OUT);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.square_out;
        }

        public int getThemeMusic() {
            return R.raw._3;
        }
    },
    SQUARE_IN("Square In") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.SQUARE_IN);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.square_in;
        }

        public int getThemeMusic() {
            return R.raw._4;
        }
    },
    VERTICAL_RECT("Vertical Rect") {
        public ArrayList<MaskBitmap.EFFECT> getTheme() {
            ArrayList<MaskBitmap.EFFECT> list = new ArrayList();
            list.add(MaskBitmap.EFFECT.VERTICAL_RECT);
            return list;
        }

        public ArrayList<MaskBitmap.EFFECT> getTheme(ArrayList<MaskBitmap.EFFECT> arrayList) {
            return new ArrayList();
        }

        public int getThemeDrawable() {
            return R.drawable.vertical_ran;
        }

        public int getThemeMusic() {
            return R.raw._5;
        }
    };

    String name;

    public abstract ArrayList<MaskBitmap.EFFECT> getTheme();


    public abstract int getThemeDrawable();

    public abstract int getThemeMusic();

    private Themes1(String string) {
        this.name = "";
        this.name = string;
    }

    public String getName() {
        return this.name;
    }
}
