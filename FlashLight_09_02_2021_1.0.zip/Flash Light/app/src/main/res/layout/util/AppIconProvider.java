package flash.light.shine.com.util;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.ImageView;
import androidx.collection.LruCache;
import java.util.Collections;
import java.util.EventListener;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AppIconProvider extends LruCache<String, Drawable> {
    private Context context;
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(5);
    private Map<ImageView, String> mImageViews = Collections.synchronizedMap(new WeakHashMap());
    private PackageManager mPackageManager;
    protected final int nullResID;
    private OnCCLAppIconLoaderCompleteListener onCCLAppIconLoaderCompleteListener;
    protected final int stubResID;

    class C01971 implements Runnable {
        private final LoadItem val$item;

        C01971(LoadItem loadItem) {
            this.val$item = loadItem;
        }

        public void run() {
            if (!AppIconProvider.this.isConvertView(this.val$item)) {
                Drawable bitmap = AppIconProvider.this.getBitmap(this.val$item.packageName);
                AppIconProvider.this.put(this.val$item.packageName, bitmap);
                AppIconProvider.this.displayBitmap(bitmap, this.val$item);
            }
        }
    }

    class C01982 implements Runnable {
        private final Drawable val$d;
        private final LoadItem val$item;

        C01982(LoadItem loadItem, Drawable drawable) {
            this.val$item = loadItem;
            this.val$d = drawable;
        }

        public void run() {
            if (AppIconProvider.this.onCCLAppIconLoaderCompleteListener != null) {
                AppIconProvider.this.onCCLAppIconLoaderCompleteListener.onComplete(this.val$item.packageName);
            }
            if (!AppIconProvider.this.isConvertView(this.val$item)) {
                if (this.val$d != null) {
                    this.val$item.iv.setImageDrawable(this.val$d);
                } else {
                    this.val$item.iv.setImageResource(AppIconProvider.this.nullResID);
                }
            }
        }
    }

    private class LoadItem {
        public ImageView iv;
        public String packageName;

        public LoadItem(String str, ImageView imageView) {
            this.packageName = str;
            this.iv = imageView;
        }
    }

    public interface OnCCLAppIconLoaderCompleteListener extends EventListener {
        void onComplete(String str);
    }

    /* Access modifiers changed, original: protected */
    public Drawable create(String str) {
        return null;
    }

    public OnCCLAppIconLoaderCompleteListener getOnCCLAppIconLoaderCompleteListener() {
        return this.onCCLAppIconLoaderCompleteListener;
    }

    public void setOnCCLAppIconLoaderCompleteListener(OnCCLAppIconLoaderCompleteListener onCCLAppIconLoaderCompleteListener) {
        this.onCCLAppIconLoaderCompleteListener = onCCLAppIconLoaderCompleteListener;
    }

    public AppIconProvider(Context context, int i, int i2, int i3) {
        super(i);
        this.context = context;
        this.stubResID = i2;
        this.nullResID = i3;
        this.mPackageManager = context.getPackageManager();
    }

    /* Access modifiers changed, original: protected */
    public Drawable getBitmap(String str) {
        try {
            return this.mPackageManager.getApplicationIcon(str);
        } catch (NameNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    /* Access modifiers changed, original: protected */
    public void queuePhoto(String str, ImageView imageView) {
        this.mExecutorService.submit(new C01971(new LoadItem(str, imageView)));
    }

    /* Access modifiers changed, original: 0000 */
    public boolean isConvertView(LoadItem loadItem) {
        String str = (String) this.mImageViews.get(loadItem.iv);
        return str == null || !str.equals(loadItem.packageName);
    }

    public void load(String str, ImageView imageView) {
        putView(str, imageView);
        Drawable drawable = (Drawable) get(str);
        if (drawable != null) {
            imageView.setImageDrawable(drawable);
            return;
        }
        Log.d("LruCache", "insert queue!");
        imageView.setImageResource(this.stubResID);
        queuePhoto(str, imageView);
    }

    /* Access modifiers changed, original: protected */
    public void displayBitmap(Drawable drawable, LoadItem loadItem) {
        ((Activity) this.context).runOnUiThread(new C01982(loadItem, drawable));
    }

    /* Access modifiers changed, original: protected */
    public void putView(String str, ImageView imageView) {
        this.mImageViews.put(imageView, str);
    }
}
