package com.videolib.libffmpeg;

interface ResponseHandler {
    void onFinish();

    void onStart();
}
