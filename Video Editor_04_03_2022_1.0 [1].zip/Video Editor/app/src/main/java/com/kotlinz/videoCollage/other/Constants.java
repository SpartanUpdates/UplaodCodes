package com.kotlinz.videoCollage.other;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Typeface;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;

public class Constants {

    public static Typeface getTextTypeface(Activity activity) {
        return Typeface.createFromAsset(activity.getAssets(), "OpenSans-Semibold.ttf");
    }


    public static String saveBitmapObjectSticker(Bitmap bitmap) {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), ".Dynamo Stickers/category1");
        file.mkdirs();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("raw1-");
        stringBuilder.append(System.currentTimeMillis());
        stringBuilder.append(".png");
        File file2 = new File(file, stringBuilder.toString());
        String absolutePath = file2.getAbsolutePath();
        if (file2.exists()) {
            file2.delete();
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            bitmap.compress(CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.close();
            return absolutePath;
        } catch (Exception e) {
            e.printStackTrace();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Exception");
            stringBuilder2.append(e.getMessage());
            Log.i("testing", stringBuilder2.toString());
            return "";
        }
    }
}
