package com.Pulse.VideoStatus.View;

import android.view.View;
import android.view.animation.Animation;

public class PopleftoutAnimation implements Animation.AnimationListener {
    public final  ExpandableView expandableView;

    public PopleftoutAnimation(ExpandableView expandableView) {
        this.expandableView = expandableView;
    }

    public void onAnimationEnd(Animation animation) {
        this.expandableView.rvSelectedImage.setVisibility(View.GONE);
        this.expandableView.tvNoImage.setVisibility(View.GONE);
        this.expandableView.n = false;
        this.expandableView.SetSelectedImage();
    }

    public void onAnimationRepeat(Animation animation) {
    }

    public void onAnimationStart(Animation animation) {
    }


}
