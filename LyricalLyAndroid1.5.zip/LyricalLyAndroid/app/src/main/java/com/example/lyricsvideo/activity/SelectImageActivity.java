package com.example.lyricsvideo.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lyricsvideo.Adapter.AlbumWiseImageAdapter;
import com.example.lyricsvideo.Adapter.ImageAlbumAdapter;
import com.example.lyricsvideo.Adapter.SelectedImageAdapter;
import com.example.lyricsvideo.CoustomControl.CoustomRecyclerView;
import com.example.lyricsvideo.CoustomControl.ExpandIconView;
import com.example.lyricsvideo.CoustomControl.VerticalSlidingPanel;
import com.example.lyricsvideo.Interface.OnItemClickListner;
import com.example.lyricsvideo.Model.ImageInfo;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.Utils.AppFont;
import com.example.lyricsvideo.application.App;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.util.ArrayList;

public class SelectImageActivity extends Activity implements VerticalSlidingPanel.PanelSlideListener {

    public static ArrayList<ImageInfo> tempImage = new ArrayList();
    public static boolean isFirstImage = false;
    public boolean isFromPreview = false;
    public String PathOfImage;
    Activity activity = SelectImageActivity.this;
    Button btndone;
    int ImageHight;
    int ImageWidth;
    ArrayList<String> arrayList;
    String imageOrientation;
    boolean isPause = false;
    private RecyclerView rvAlbumByFolder;
    private RecyclerView rvAlbumByImages;
    private ImageAlbumAdapter imageAlbumAdapter;
    private AlbumWiseImageAdapter albumWiseImageAdapter;
    private SelectedImageAdapter selectedImageAdapter;
    private VerticalSlidingPanel verticalSlidingPanel;
    private View parent;
    private ExpandIconView ViewexpandIcon;
    private Button btnClearImages;
    private TextView tvTotalImageCount;
    private App application;
    private CoustomRecyclerView rvSelectedImage;
    private boolean IsFromMyTemplateVideo;
    InterstitialAd mInterstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_image);
        application = App.getInstance();
        isFromPreview = getIntent().hasExtra("extra_from_preview");
        ImageHight = getIntent().getIntExtra("ImageHight", 640);
        ImageWidth = getIntent().getIntExtra("Imagewidth", 520);
        IsFromMyTemplateVideo = getIntent().getBooleanExtra("IsFromMyTemplateVideo", false);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SelectImageActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
        application.init();
        init();
        InterstitialAd();
        AllClickListener();
        AppFont.Textfont(activity, tvTotalImageCount);
        AppFont.Buttonfont(activity, btndone);
        AppFont.Buttonfont(activity, btnClearImages);
    }

    @SuppressLint({"NewApi"})
    private void init() {
        btndone = findViewById(R.id.btnDone);
        tvTotalImageCount = findViewById(R.id.tv_Image_Counter);
        ViewexpandIcon = findViewById(R.id.View_Expand);
        rvAlbumByFolder = findViewById(R.id.rvAllAlbum);
        rvAlbumByImages = findViewById(R.id.rv_Album_wise_Image);
        rvSelectedImage = findViewById(R.id.rvSelectedImagesList);
        verticalSlidingPanel = findViewById(R.id.overview_panel);
        verticalSlidingPanel.setEnableDragViewTouchEvents(true);
        verticalSlidingPanel.setDragView(findViewById(R.id.rl_image_info));
        verticalSlidingPanel.setPanelSlideListener(this);
        parent = findViewById(R.id.ll_image_select_panel_main);
        btnClearImages = findViewById(R.id.btn_all_image_clear);


        imageAlbumAdapter = new ImageAlbumAdapter(this);
        albumWiseImageAdapter = new AlbumWiseImageAdapter(this);
        selectedImageAdapter = new SelectedImageAdapter(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(
                getApplicationContext(), 0, false);

        rvAlbumByFolder.setLayoutManager(mLayoutManager);
        rvAlbumByFolder.setItemAnimator(new DefaultItemAnimator());
        rvAlbumByFolder.setAdapter(imageAlbumAdapter);

        RecyclerView.LayoutManager gridLayputManager = new GridLayoutManager(
                getApplicationContext(), 4);
        rvAlbumByImages.setLayoutManager(gridLayputManager);
        rvAlbumByImages.setItemAnimator(new DefaultItemAnimator());
        rvAlbumByImages.setAdapter(albumWiseImageAdapter);

        RecyclerView.LayoutManager gridLayputManager1 = new GridLayoutManager(
                getApplicationContext(), 4);
        rvSelectedImage.setLayoutManager(gridLayputManager1);
        rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        rvSelectedImage.setAdapter(selectedImageAdapter);
        rvSelectedImage.setEmptyView(findViewById(R.id.ll_no_selected_images));
        if (App.TotalSelectedImage >= 50) {
            tvTotalImageCount.setText(String.valueOf(application.getSelectedImageslist().size()));
        } else {
            tvTotalImageCount.setText(String.valueOf(application.getSelectedImageslist().size()) + "/" + App.TotalSelectedImage);
        }
    }
    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(this, getString(R.string.FB_inter));
        mInterstitialAd.setAdListener(new InterstitialAdListener() {

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }

            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Done();
            }
        });
        mInterstitialAd.loadAd();
    }
    private String getDropboxIMGSize(final String uri) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(new File(uri).getAbsolutePath(), options);
        final int imageHeight = options.outHeight;
        final int imageWidth = options.outWidth;
        if (imageHeight > imageWidth) {
            return "P";
        }
        return "L";
    }

    private void AllClickListener() {
        arrayList = new ArrayList<String>();
        btndone.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (mInterstitialAd != null && mInterstitialAd.isAdLoaded()) {
                    App.ShowDialog(activity);
                    mInterstitialAd.show();
                } else {
                    Done();
                }
            }
        });
        btnClearImages.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (application.getSelectedImageslist().size() != 0) {
                    AllInfoClear();
                } else {
                    Toast.makeText(activity, "Please Select Image!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        imageAlbumAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                albumWiseImageAdapter.notifyDataSetChanged();
            }
        });
        albumWiseImageAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                if (App.TotalSelectedImage >= 50) {
                    tvTotalImageCount.setText(String.valueOf(application.getSelectedImageslist().size()));
                } else {
                    tvTotalImageCount.setText(String.valueOf(String.valueOf(application.getSelectedImageslist().size())) + "/" + App.TotalSelectedImage);
                }
                selectedImageAdapter.notifyDataSetChanged();
            }
        });
        selectedImageAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                if (App.TotalSelectedImage >= 50) {
                    tvTotalImageCount.setText(String.valueOf(application.getSelectedImageslist().size()));
                } else {
                    tvTotalImageCount.setText(String.valueOf(String.valueOf(application.getSelectedImageslist().size())) + "/" + App.TotalSelectedImage);
                }
                albumWiseImageAdapter.notifyDataSetChanged();
            }
        });
    }

    private void Done() {
        if (application.getSelectedImageslist().size() != 0) {
            if (application.getSelectedImageslist().size() <= App.TotalSelectedImage) {
                int i = 0;
                for (final ImageInfo d : application.getSelectedImageslist()) {
                    final String isLandOrPort = getDropboxIMGSize(d.getImagePath());
                    if (i == 0) {
                        PathOfImage = d.getImagePath();
                        imageOrientation = isLandOrPort;
                    } else {
                        PathOfImage = String.valueOf(String.valueOf(PathOfImage)) + App.APP_SPLIT_PATTERN + d.getImagePath();
                        imageOrientation = String.valueOf(String.valueOf(imageOrientation)) + "$" + isLandOrPort;
                    }
                    ++i;
                }
                final Intent intent = new Intent(activity, SampleCropActivity.class);
                intent.putExtra("path", PathOfImage);
                intent.putExtra("ImageHight", ImageHight);
                intent.putExtra("Imagewidth", ImageWidth);
                intent.putExtra("IsFromMyTemplateVideo", IsFromMyTemplateVideo);
                startActivity(intent);
                finish();

//                App.Test_intent = intent;
//                if (App.mInterstitialAd_Fb != null) {
//                    if (App.mInterstitialAd_Fb.isAdLoaded()) {
//                        App.Tast_Context = SelectImageActivity.this;
//                        App.id = 103;
//                        App.ShowDialog(activity);
//                        App.mInterstitialAd_Fb.show();
//                    } else {
//                        App.loadInterstitialNew(SelectImageActivity.this);
//                        startActivity(intent);
//                        finish();
//                    }
//                } else {
//                    App.loadInterstitialAd(SelectImageActivity.this);
//                    startActivity(intent);
//                    finish();
//                }


            } else if (application.getSelectedImageslist().size() > App.TotalSelectedImage) {
                new StringBuilder("Please Remove ").append(application.getSelectedImageslist().size() - App.TotalSelectedImage).append(" Images").toString();
            } else {
                Toast.makeText(activity, "Selected : " + App.TotalSelectedImage + " Image", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(activity, "Please Select Image!", Toast.LENGTH_SHORT).show();
        }
    }

    protected void onResume() {
        super.onResume();
        if (isPause) {
            isPause = false;
            if (App.TotalSelectedImage >= 50) {
                tvTotalImageCount.setText(String.valueOf(application
                        .getSelectedImageslist().size()));
            } else {
                tvTotalImageCount.setText(String.valueOf(application
                        .getSelectedImageslist().size()) + "/" +
                        App.TotalSelectedImage);
            }

            albumWiseImageAdapter.notifyDataSetChanged();
            selectedImageAdapter.notifyDataSetChanged();
        }
    }

    protected void onPause() {
        super.onPause();
        isPause = true;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_selection, menu);
        if (isFromPreview)
            menu.removeItem(R.id.menu_clear);
        return super.onCreateOptionsMenu(menu);
    }


    public void onBackPressed() {
        if (this.verticalSlidingPanel.isExpanded()) {
            this.verticalSlidingPanel.collapsePane();
        } else {
            if (IsFromMyTemplateVideo) {
                startActivity(new Intent(activity, MyTemplateActivity.class));
                finish();
            } else {
                startActivity(new Intent(activity, MainActivity.class));
                finish();
            }
        }
    }

    public void onPanelSlide(View panel, final float slideOffset) {
        if (ViewexpandIcon != null)
            ViewexpandIcon.setFraction(slideOffset, false);
        if (slideOffset >= 0.005f) {
            if ((parent != null) && (parent.getVisibility() != View.VISIBLE)) {
                parent.setVisibility(View.VISIBLE);
            }
        } else if ((parent != null) && (parent.getVisibility() == View.VISIBLE)) {
            parent.setVisibility(View.GONE);
        }
    }


    public void onPanelCollapsed(View panel) {
        if (parent != null) {
            parent.setVisibility(View.VISIBLE);
        }
        selectedImageAdapter.isExpanded = false;
        selectedImageAdapter.notifyDataSetChanged();
    }

    public void onPanelExpanded(View panel) {
        if (parent != null) {
            parent.setVisibility(View.GONE);
        }
        selectedImageAdapter.isExpanded = true;
        selectedImageAdapter.notifyDataSetChanged();
    }


    public void onPanelAnchored(View panel) {
    }


    public void onPanelShown(View panel) {
    }


    private void AllInfoClear() {
        ArrayList<ImageInfo> selectedImages = application.getSelectedImageslist();
        for (int i = selectedImages.size() - 1; i >= 0; i--) {
            application.removeSelectedImage(i);
        }
        if (App.TotalSelectedImage >= 50) {
            tvTotalImageCount.setText("0");
        } else {
            tvTotalImageCount.setText("0/" + App.TotalSelectedImage);
        }
        selectedImageAdapter.notifyDataSetChanged();
        albumWiseImageAdapter.notifyDataSetChanged();
    }
}
