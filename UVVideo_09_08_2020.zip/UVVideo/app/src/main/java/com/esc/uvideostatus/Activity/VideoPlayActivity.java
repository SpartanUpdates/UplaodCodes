package com.esc.uvideostatus.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.request.RequestOptions;
import com.esc.uvideostatus.Adapters.SuggestionAdapter;
import com.esc.uvideostatus.Fragments.TrendingFragment;
import com.esc.uvideostatus.Models.VideoData;
import com.esc.uvideostatus.R;
import com.esc.uvideostatus.Utility.FontTextView;
import com.esc.uvideostatus.Utility.Utility;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.android.exoplayer.text.ttml.TtmlNode;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource.Factory;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpHeaders;
import cz.msebera.android.httpclient.util.ByteArrayBuffer;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class VideoPlayActivity extends AppCompatActivity implements OnClickListener {
    Activity activity = VideoPlayActivity.this;
    private static final String SEEK_POSITION_KEY = "SEEK_POSITION_KEY";
    private static final String TAG = "MainActivity";
    public static LottieAnimationView icon_like;
    private RecyclerView album_recyclerview;
    ImageView back;
    public DefaultBandwidthMeter bandwidthMeter;
    public int cachedHeight;
    FontTextView dow_txt;
    ImageView download;
    public DefaultExtractorsFactory extractorsFactory;
    File file;
    public ImageView icon_like_main;
    String imgPath;
    ImageView like_img;
    FontTextView like_txt;
    public SuggestionAdapter mAdapter;
    LinearLayoutManager mLayoutManager;
    private int mSeekPosition;
    FrameLayout mVideoLayout;
    public PlayerView mVideoPlayer_1;
    public Factory mediaDataSourceFactory;
    public MediaSource mediaSource;
    public boolean ontouch = true;
    public boolean pause = true;
    public ImageView play;
    public SimpleExoPlayer player;
    LinearLayout recommended;
    ImageView share;
    FontTextView share_txt;
    LinearLayout suggestion_layout;
    public String title;
    public DefaultTrackSelector trackSelector;
    TextView tvVideoListingName;
    FontTextView tvlist_view;
    VideoData videoData;
    ArrayList<VideoData> videoDataArrayList = new ArrayList<>();
    private String videoPath;
    public TrackSelection.Factory videoTrackSelectionFactory;
    private ProgressDialog progressDialog;
    private MainActivity mainActivity;

    private class ImageDownloadAndSave extends AsyncTask<String, Void, Bitmap> {
        private ImageDownloadAndSave() {
        }

        public void onPreExecute() {
            progressDialog = new ProgressDialog(VideoPlayActivity.this);
            progressDialog.setMessage("Plz wait");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setCancelable(false);
            progressDialog.show();

            super.onPreExecute();
        }

        public Bitmap doInBackground(String... strArr) {
            String str = strArr[0];
            StringBuilder sb = new StringBuilder();
            sb.append(strArr[1]);
            sb.append(".mp4");
            downloadImagesToSdCard(str, sb.toString());
            return null;
        }

        public void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    progressDialog.dismiss();
                }
            }, 1000);
            VideoPlayActivity.this.shareMultiplePhotos();
        }

        private void downloadImagesToSdCard(String str, String str2) {
            String str3 = "/";
            VideoPlayActivity video_play_Activity = VideoPlayActivity.this;
            video_play_Activity.imgPath = str;
            video_play_Activity.title = str2;
            try {
                URL url = new URL(VideoPlayActivity.this.imgPath);
                Log.e("url", "" + url);
                StringBuilder sb = new StringBuilder();
                sb.append(Environment.getExternalStorageDirectory());
                sb.append(str3);
                sb.append(VideoPlayActivity.this.getString(R.string.app_name));
                Log.e("ShareImage", "" + sb.toString());
                File file = new File(sb.toString());
                if (!file.exists()) {
                    file.mkdirs();
                }
                String[] split = VideoPlayActivity.this.imgPath.split(Pattern.quote(str3));
                StringBuilder sb2 = new StringBuilder();
                sb2.append("captureImage: ");
                sb2.append(VideoPlayActivity.this.imgPath);
                sb2.append("    ");
                sb2.append(split[split.length - 1]);
                Log.e("TAGSplite", sb2.toString());
                VideoPlayActivity.this.file = new File(file.getAbsolutePath(), split[split.length - 1]);
                if (!VideoPlayActivity.this.file.exists()) {
                    InputStream inputStream = null;
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();
                    if (httpURLConnection.getResponseCode() == 200) {
                        inputStream = httpURLConnection.getInputStream();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(VideoPlayActivity.this.file);
                    int contentLength = httpURLConnection.getContentLength();
                    byte[] bArr = new byte[1024];
                    int i = 0;
                    while (true) {
                        int read = inputStream.read(bArr);
                        if (read <= 0) {
                            break;
                        }
                        fileOutputStream.write(bArr, 0, read);
                        i += read;
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("downloadedSize:");
                        sb3.append(i);
                        sb3.append("totalSize:");
                        sb3.append(contentLength);
                        Log.i("Progress:", sb3.toString());
                    }
                    fileOutputStream.close();
                }
                Log.d("test", "Image Saved in sdcard..");
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    class DownloadVideo extends AsyncTask<String, String, String> {

        public DownloadVideo() {
        }

        public void onPreExecute() {
            progressDialog = new ProgressDialog(VideoPlayActivity.this);
            progressDialog.setMessage("Plz wait");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        public String doInBackground(String... strArr) {
            String str = strArr[0];
            StringBuilder sb = new StringBuilder();
            sb.append(strArr[1]);
            sb.append(".mp4");
            VideoPlayActivity.this.DownloadFile(str, sb.toString());
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute(str);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    progressDialog.dismiss();
                }
            }, 1000);
            VideoPlayActivity.this.download.setImageResource(R.drawable.ic_downloaded);
            VideoPlayActivity.this.download.setColorFilter(VideoPlayActivity.this.getResources().getColor(R.color.icon_green));
            VideoPlayActivity.this.download.setClickable(false);
        }
    }

    class datasuggestvideos extends AsyncHttpResponseHandler {
        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
        }

        datasuggestvideos() {
        }

        public void onStart() {
            super.onStart();
        }

        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            String str = "url";
            String str2 = new String(bArr);
            StringBuilder sb = new StringBuilder();
            sb.append("responsesuggest: ");
            sb.append(str2);
            String str3 = "ContentValues";
            Log.d(str3, sb.toString());
            VideoPlayActivity.this.videoDataArrayList = new ArrayList<>();
            try {
                JSONArray jSONArray = new JSONArray(str2);
//                Log.e("VideoListSize", "" + videoDataArrayList.size());
                if (jSONArray.length() != 0) {
                    for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                        JSONObject jSONObject = jSONArray.getJSONObject(i2);
                        VideoData videoData = new VideoData();
                        videoData.setVideo_id(jSONObject.getLong(TtmlNode.ATTR_ID));
                        videoData.setTitle(jSONObject.getString("title"));
                        videoData.setUrl(jSONObject.getString(str));
                        videoData.setReal_videopath(jSONObject.getString(str));
                        videoData.setThumbnail(jSONObject.getString(TtmlNode.TAG_IMAGE));
                        videoData.setCatagory(jSONObject.getString("cname"));
                        videoData.setViews(jSONObject.getString("downloads"));
                        VideoPlayActivity.this.videoDataArrayList.add(videoData);
                    }
                    SetAdapter();
                }
                StringBuilder sb2 = new StringBuilder();
                sb2.append("data:tt ");
                sb2.append(VideoPlayActivity.this.videoDataArrayList.size());
                Log.e(str3, sb2.toString());
            } catch (Exception unused) {
            }
        }
    }

    @SuppressLint("WrongConstant")
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_video_play_);
        getSupportActionBar().hide();
        this.play = findViewById(R.id.play);
        this.suggestion_layout = findViewById(R.id.suggestion_layout);
        this.recommended = findViewById(R.id.recommended);
        this.videoPath = getIntent().getStringExtra("VIDEO_PATH");
        Log.e("VideoPath", "" + videoPath);
        this.videoData = (VideoData) getIntent().getSerializableExtra("list");
        Log.e("VideoData", "" + videoData);
        this.mVideoPlayer_1 = findViewById(R.id.video_player_1);
        this.extractorsFactory = new DefaultExtractorsFactory();
        this.mediaDataSourceFactory = new DefaultDataSourceFactory(this, Util.getUserAgent(this, getString(R.string.app_name)));
        this.bandwidthMeter = new DefaultBandwidthMeter();
        ExtractorMediaSource extractorMediaSource = new ExtractorMediaSource(Uri.parse(this.videoPath), this.mediaDataSourceFactory, this.extractorsFactory, null, null);
        this.mediaSource = extractorMediaSource;
        this.videoTrackSelectionFactory = new AdaptiveTrackSelection.Factory(this.bandwidthMeter);
        this.trackSelector = new DefaultTrackSelector(this.videoTrackSelectionFactory);
        this.back = findViewById(R.id.back);
        this.player = ExoPlayerFactory.newSimpleInstance(this, this.trackSelector);
        this.mVideoPlayer_1.setPlayer(this.player);
        this.player.prepare(this.mediaSource);
        this.mVideoPlayer_1.setResizeMode(0);
        this.player.setPlayWhenReady(true);
        Log.e("PlayerTop", "" + player);
        this.mVideoLayout = findViewById(R.id.video_layout);
        this.mVideoLayout.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (VideoPlayActivity.this.pause) {
                    VideoPlayActivity.this.pause = false;
                    VideoPlayActivity.this.player.setPlayWhenReady(false);
                    VideoPlayActivity.this.play.setVisibility(View.VISIBLE);
                    return;
                }
                VideoPlayActivity.this.pause = true;
                VideoPlayActivity.this.play.setVisibility(View.GONE);
                VideoPlayActivity.this.player.setPlayWhenReady(true);
            }
        });
        this.back.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(VideoPlayActivity.this, MainActivity.class));
                finish();
            }
        });

        initview();
        LoadAds();
    }

    private void initview() {

        this.like_img = findViewById(R.id.like_img);
        this.like_txt = findViewById(R.id.like_txt);
        this.share_txt = findViewById(R.id.share_txt);
        this.dow_txt = findViewById(R.id.dow_txt1);
        this.back = findViewById(R.id.back_video);
        this.share = findViewById(R.id.share);
        this.download = findViewById(R.id.download);
        this.album_recyclerview = findViewById(R.id.album_recyclerview);
        this.tvVideoListingName = findViewById(R.id.tvVideoListingName);
        this.tvlist_view = findViewById(R.id.tvlist_view);
        this.icon_like_main = findViewById(R.id.icon_like_main);
        icon_like = findViewById(R.id.icon_like);
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.video_placeholder);
        requestOptions.error(R.drawable.video_placeholder);
        requestOptions.centerCrop();
        if (this.videoData.getTitle() != null) {
            this.tvVideoListingName.setText(this.videoData.getTitle());
            Log.e("VideoName", "Name" + videoData.getTitle());
        }
        if (this.videoData.getViews() != null) {
            FontTextView fontTextView = this.tvlist_view;
            StringBuilder sb = new StringBuilder();
            sb.append(Utility.getViews(Double.parseDouble(this.videoData.getViews())));
            sb.append(" views");
            fontTextView.setText(sb.toString());
        }

        this.share.setOnClickListener(this);
        this.download.setOnClickListener(this);
        this.back.setOnClickListener(this);
        this.like_img.setOnClickListener(this);
        this.icon_like_main.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                VideoPlayActivity.this.like_txt.setTextColor(VideoPlayActivity.this.getResources().getColor(R.color.tab));
                VideoPlayActivity.this.icon_like_main.setVisibility(View.GONE);
                VideoPlayActivity.icon_like.setVisibility(View.VISIBLE);
                VideoPlayActivity.icon_like.playAnimation();
                VideoPlayActivity.icon_like.loop(false);
            }
        });
//        SetAdapter();
        getsuggestvideo();
    }

    public void SetAdapter() {
        mLayoutManager = new LinearLayoutManager(this);
        album_recyclerview.setLayoutManager(mLayoutManager);
        album_recyclerview.setItemAnimator(new DefaultItemAnimator());
        album_recyclerview.addItemDecoration(new DividerItemDecoration(this, 0));
        mAdapter = new SuggestionAdapter(VideoPlayActivity.this, videoDataArrayList);
        album_recyclerview.setAdapter(this.mAdapter);
        mAdapter.notifyDataSetChanged();

    }

    public void onPause() {
        super.onPause();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt(SEEK_POSITION_KEY, this.mSeekPosition);
    }

    public void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.mSeekPosition = bundle.getInt(SEEK_POSITION_KEY);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.back_video:
                startActivity(new Intent(VideoPlayActivity.this, MainActivity.class));
                finish();
                return;
            case R.id.download:

                if (mAdapter.SelectPosition != -1) {
                    new DownloadVideo().execute(videoDataArrayList.get(mAdapter.SelectPosition).getReal_videopath(), videoDataArrayList.get(mAdapter.SelectPosition).getTitle());
                    Log.e("TAG", "Download Suggest " + videoDataArrayList.get(mAdapter.SelectPosition).getReal_videopath() + " Title Suggest" + videoDataArrayList.get(mAdapter.SelectPosition).getTitle());
                } else {
                    new DownloadVideo().execute(videoData.getReal_videopath(), videoData.getTitle());
                    Log.e("TAG", "Download " + videoData.getReal_videopath() + " Title " + videoData.getTitle());
                }
                return;
            case R.id.like_img:
                this.ontouch = false;
                return;
            case R.id.share:
                if (mAdapter.SelectPosition != -1) {
                    new ImageDownloadAndSave().execute(videoDataArrayList.get(mAdapter.SelectPosition).getReal_videopath(), videoDataArrayList.get(mAdapter.SelectPosition).getTitle());
                    Log.e("TAG", "Share SuggestVideo " + videoDataArrayList.get(mAdapter.SelectPosition).getReal_videopath() + " Share SuggestTitle " + videoDataArrayList.get(mAdapter.SelectPosition).getTitle());

                } else {
                    new ImageDownloadAndSave().execute(this.videoData.getReal_videopath(), this.videoData.getTitle());
                    Log.e("TAG", "ShareUrl " + videoData.getReal_videopath() + " Share Title " + videoData.getTitle());
                }
                return;
            default:
                return;
        }
    }

    public void shareMultiplePhotos() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.SUBJECT", "Share");
        StringBuilder sb3 = new StringBuilder();
        sb3.append(getApplicationContext().getPackageName());
        sb3.append(".provider");
        intent.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(activity, sb3.toString(), file));
        startActivity(Intent.createChooser(intent, "Select"));
    }

    public void getsuggestvideo() {
        String str = "cid";
        try {
            String stringExtra = getIntent().getStringExtra(str);
            if (stringExtra != null) {
                JSONObject jSONObject = new JSONObject();
                try {
                    jSONObject.put(str, stringExtra);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                RequestParams requestParams = new RequestParams();
                requestParams.put("q", jSONObject.toString());
                Log.e("Cidq", "Cidq" + jSONObject.toString());
                requestParams.put("sk", "0");
                requestParams.put("l", 20);
                AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                asyncHttpClient.setTimeout(60000);
                StringBuilder sb = new StringBuilder();
                sb.append(Utility.baseUrl);
                sb.append("collections/tbl_video?apiKey=");
                sb.append(Utility.apiKey);
                asyncHttpClient.get(sb.toString(), requestParams, new datasuggestvideos());
                return;
            }
            String stringExtra2 = getIntent().getStringExtra(HttpHeaders.FROM);
            if (stringExtra2.equalsIgnoreCase("Trending")) {
                Collections.shuffle(TrendingFragment.videoData);
                this.mAdapter.addAll(TrendingFragment.videoData);
                this.mAdapter.notifyDataSetChanged();

            } else if (stringExtra2.equalsIgnoreCase("Searching")) {
                Collections.shuffle(SearchActivity.videoData);
                this.mAdapter.addAll(SearchActivity.videoData);
                this.mAdapter.notifyDataSetChanged();
            }
        } catch (Exception unused) {
        }
    }

    public void DownloadFile(String str, String str2) {
        try {
            String replace = str.replace(" ", "%20");
            StringBuilder sb = new StringBuilder();
            sb.append(Environment.getExternalStorageDirectory());
            sb.append("/Video_player");
            File file2 = new File(sb.toString());
            if (!file2.exists()) {
                file2.mkdirs();
            }
            URL url = new URL(replace);
            Log.e("Replace", "" + replace);
            File file3 = new File(file2, str2);
            BufferedInputStream bufferedInputStream = new BufferedInputStream(url.openConnection().getInputStream());
            ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer(20000);
            while (true) {
                int read = bufferedInputStream.read();
                if (read != -1) {
                    byteArrayBuffer.append((byte) read);
                } else {
                    FileOutputStream fileOutputStream = new FileOutputStream(file3);
                    fileOutputStream.write(byteArrayBuffer.toByteArray());
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void playVideo(VideoData videoData2) {
        this.player.release();
        this.player.seekTo(0);
        this.play.setVisibility(View.GONE);

        this.mVideoLayout.post(new Runnable() {
            @SuppressLint("WrongConstant")
            public void run() {
                if (new Random().nextInt(5) == 1) {
                    if (mainActivity.interstitialAd != null && mainActivity.interstitialAd.isLoaded()) {
                        mainActivity.interstitialAd.show();
                    }
                }

                cachedHeight = (int) ((((float) mVideoLayout.getWidth()) * 405.0f) / 720.0f);
                LayoutParams layoutParams = mVideoLayout.getLayoutParams();
                layoutParams.width = -1;
                layoutParams.height = cachedHeight;
                mVideoLayout.setLayoutParams(layoutParams);
                RequestOptions requestOptions = new RequestOptions();
                requestOptions.placeholder(R.drawable.video_placeholder);
                requestOptions.error(R.drawable.video_placeholder);
                if (videoData.getTitle() != null) {
                    tvVideoListingName.setText(videoData2.getTitle());
                    Log.e("tvVideotitle", "" + videoData2.getTitle());
                }
                download.setClickable(true);
                if (videoData.getViews() != null) {
                    FontTextView fontTextView = VideoPlayActivity.this.tvlist_view;
                    StringBuilder sb = new StringBuilder();
                    sb.append(Utility.getViews(Double.parseDouble(videoData2.getViews())));
                    sb.append(" views");
                    fontTextView.setText(sb.toString());
                    Log.e("VideoView", "" + sb.toString());
                }
                ExtractorMediaSource extractorMediaSource = new ExtractorMediaSource(Uri.parse(videoData2.getReal_videopath()), mediaDataSourceFactory, extractorsFactory, null, null);
                Log.e("Uri", "" + videoData2.getReal_videopath());
                mediaSource = extractorMediaSource;
                videoTrackSelectionFactory = new AdaptiveTrackSelection.Factory(bandwidthMeter);
                trackSelector = new DefaultTrackSelector(videoTrackSelectionFactory);
                player = ExoPlayerFactory.newSimpleInstance(VideoPlayActivity.this, trackSelector);
                mVideoPlayer_1.setPlayer(player);
                player.prepare(mediaSource);
                Log.e("player", "" + player);
                mVideoPlayer_1.setResizeMode(0);
                player.setPlayWhenReady(true);

            }
        });
        getsuggestvideo();
    }

    private AdView adView;

    private void LoadAds() {
        //FaceBookBannerAd
        adView = new AdView(getApplicationContext(), getResources().getString(R.string.fb_banner), AdSize.BANNER_HEIGHT_50);
        final FrameLayout frameLayout = findViewById(R.id.adView_banner);
        frameLayout.addView(adView);
        adView.loadAd();
        adView.setAdListener(new com.facebook.ads.AdListener() {
            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                frameLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
    }

    public void onDestroy() {
        super.onDestroy();
        try {
            this.player.release();
        } catch (Exception unused) {
        }
    }

    public void onStop() {
        super.onStop();
        try {
            this.player.release();
        } catch (Exception unused) {
        }
    }

    public void onBackPressed()
    {
        Intent intent = new Intent(VideoPlayActivity.this, MainActivity.class);
        if (mainActivity.interstitialAd != null && mainActivity.interstitialAd.isLoaded())
        {
            mainActivity.interstitialAd.show();
        } else {
            startActivity(intent);
            finish();
        }
    }
}
