package com.kotlinz.festivalstorymaker.Listener.SetListener;


import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class CETextStickerView implements TextStickerViewNew1.b
{
    public final CanvasEditorActivity activity;

    public CETextStickerView(final CanvasEditorActivity a) {
        this.activity = a;
    }

    @Override
    public void a(final boolean b, final TextStickerViewNew1 textStickerViewNew1) {
        if (this.activity.llTextEditor.isShown() && !b) {
            final TextStickerViewNew1 t1 = activity.t1;
            if (t1 == null || t1 == textStickerViewNew1) {
                activity.D0(b);
            }
        }
    }
}
