package com.esc.flashlight.util;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build.VERSION;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;

import com.esc.flashlight.App.APP;
import com.esc.flashlight.receiver.MissedAlertReceiver;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class FlashAlertUtil {
    public static final String ACTION_CHANGED_STATUS_BAR = "flash.light.shine.statusbar";
    public static final String ACTION_COMING_MSG = "flash.light.shine.comingmsg";
    public static final String ACTION_OFF = "flash.light.shine.off";
    public static final String ACTION_RINGING = "flash.light.shine.ringing";
    public static final String IDLE = "IDLE";
    private static final String OFFHOOK = "OFFHOOK";
    private static final String RINGING = "RINGING";
    public static final long SCREEN_OFF_TIME = -1;
    public static final long SCREEN_ON_SAFE_DELAY = 1200;
    private static final String TAG = "FlashAlertUtil";

    public static final boolean checkUseMode(Context context, PrefManager prefManager) {
        int ringerMode = ((AudioManager) context.getSystemService("audio")).getRingerMode();
        if (ringerMode == 0) {
            return prefManager.getUseModeSilent();
        }
        if (ringerMode == 1) {
            return prefManager.getUseModeVibrate();
        }
        if (ringerMode != 2) {
            return false;
        }
        return prefManager.getUseModeNormal();
    }

    public static final boolean isEnableAlert(Context context, PrefManager prefManager) {
        if (!prefManager.getUseScreenOn() && checkScreenOn(context, prefManager)) {
            Log.d(TAG, "IGNORE curse 'Screen on'");
            return false;
        } else if (!checkUseMode(context, prefManager)) {
            Log.d(TAG, "IGNORE curse 'Ringer mode off'");
            return false;
        } else if (isIgnoreTime(prefManager)) {
            return false;
        } else {
            return true;
        }
    }

    public static final boolean checkedPhoneState(Context context, String str, Intent intent) {
        PrefManager prefManager = APP.getPrefManager();
        if (!RINGING.equals(str)) {
            intent.setAction("flash.light.shine.off");
            Log.d(TAG, "OFF FLASH");
            if (IDLE.equals(str) && prefManager.getUseTotally() && prefManager.getUseCall() && prefManager.getUseMissedCall()) {
                Intent intent2 = new Intent(context, MissedAlertReceiver.class);
                intent2.setAction(MissedAlertReceiver.ACTION_CALL_PREPARE);
                context.sendBroadcast(intent2);
            }
        } else if (!prefManager.getUseTotally() || !prefManager.getUseCall()) {
            Log.d(TAG, "IGNORE curse 'totally off or call off'");
            return false;
        } else if (!isEnableAlert(context, prefManager)) {
            return false;
        } else {
            intent.setAction("flash.light.shine.ringing");
            Log.d(TAG, "ON FLASH");
        }
        return true;
    }

    public static final boolean checkedReceiveMsg(Context context, Intent intent) {
        PrefManager prefManager = APP.getPrefManager();
        if (!prefManager.getUseTotally() || !prefManager.getUseMessage()) {
            Log.d(TAG, "IGNORE curse 'totally off or Message off'");
            return false;
        } else if (!isEnableAlert(context, prefManager)) {
            return false;
        } else {
            intent.setAction("flash.light.shine.comingmsg");
            return true;
        }
    }

    public static final Intent checkChangedStatusBarState(Context context) {
        PrefManager prefManager = APP.getPrefManager();
        if (!prefManager.getUseTotally() || !prefManager.getUseStatusBar()) {
            Log.d(TAG, "IGNORE curse 'totally off or StatusBar off'");
            return null;
        } else if (!isEnableAlert(context, prefManager)) {
            return null;
        } else {
            Intent intent = new Intent();
            intent.setAction("flash.light.shine.statusbar");
            Log.i(TAG, "ON FLASH");
            return intent;
        }
    }

    private static final boolean isIgnoreTime(PrefManager prefManager) {
        if (!prefManager.getUseModeIgnore()) {
            return false;
        }
        int[] ignoreTimeBegin = prefManager.getIgnoreTimeBegin();
        int[] ignoreTimeEnd = prefManager.getIgnoreTimeEnd();
        if (ignoreTimeBegin[0] == ignoreTimeEnd[0] && ignoreTimeBegin[1] == ignoreTimeEnd[1]) {
            return false;
        }
        Calendar instance = Calendar.getInstance();
        GregorianCalendar gregorianCalendar = new GregorianCalendar(0, 0, 0, ignoreTimeBegin[0], ignoreTimeBegin[1]);
        GregorianCalendar gregorianCalendar2 = new GregorianCalendar(0, 0, 0, ignoreTimeEnd[0], ignoreTimeEnd[1]);
        if (gregorianCalendar.compareTo(gregorianCalendar2) == 1) {
            gregorianCalendar2.add(5, 1);
        }
        instance.set(0, 0, 0, instance.get(11), instance.get(12), instance.get(13));
        if (!instance.after(gregorianCalendar) || !instance.before(gregorianCalendar2)) {
            return false;
        }
        Log.d(TAG, "IGNORE curse 'Ignore time'");
        return true;
    }

    private static final boolean checkScreenOn(Context context, PrefManager prefManager) {
        return isScreenOn(context) && checkScreenOnTime(prefManager.getScreenOnTime());
    }

    private static final boolean checkScreenOnTime(long j) {
        if (j == -1) {
            Log.d(TAG, "SCREEN_OFF_TIME");
            return false;
        }
        long elapsedRealtime = SystemClock.elapsedRealtime();
        if (elapsedRealtime < j) {
            Log.d(TAG, "currentRealTime < onTime");
            return true;
        }
        elapsedRealtime -= j;
        Log.d(TAG, "delay = " + elapsedRealtime);
        if (elapsedRealtime > SCREEN_ON_SAFE_DELAY) {
            return true;
        }
        return false;
    }

    public static final boolean isScreenOn(Context context) {
        PowerManager powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        if (VERSION.SDK_INT < 20) {
            return isScreenOnOld(powerManager);
        }
        return isScreenOnNew(powerManager);
    }

    private static final boolean isScreenOnOld(PowerManager powerManager) {
        return powerManager.isScreenOn();
    }

    private static final boolean isScreenOnNew(PowerManager powerManager) {
        return powerManager.isInteractive();
    }
}
