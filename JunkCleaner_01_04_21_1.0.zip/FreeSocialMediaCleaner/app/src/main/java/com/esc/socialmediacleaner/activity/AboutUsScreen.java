package com.esc.socialmediacleaner.activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class AboutUsScreen extends ShareAppScreen implements OnClickListener {
    private Activity activity = AboutUsScreen.this;
    public long lastClickedTime = 0;
    private ImageView iv_back;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;
    private TextView tv_share, tv_rate, tv_policy;

    public int getFacePosition() {
        return super.getFacePosition();
    }

    public void hideKeyboard() {
        super.hideKeyboard();
    }

    public boolean isEmailValid(String str) {
        return super.isEmailValid(str);
    }

    public void setFacePosition(int i) {
        super.setFacePosition(i);
    }

    public void shareApp() {
        super.shareApp();
    }

    public void toast(String str) {
        super.toast(str);
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_about_screen);
        initialize();
        loadAd();
    }

    private void initialize() {
        iv_back = findViewById(R.id.iv_back);
        tv_policy = findViewById(R.id.tv_pp);
        tv_rate = findViewById(R.id.tv_rate);
        TextView textView4 = (TextView) findViewById(R.id.tv_version);
        tv_share = findViewById(R.id.tv_share);

        tv_share.setOnClickListener(this);
        tv_rate.setOnClickListener(this);
        tv_policy.setOnClickListener(this);
        iv_back.setOnClickListener(this);

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(getString(R.string.IDS_app_version_txt).replace("DO_NOT_TRANSLATE", ""));
        textView4.setText(stringBuilder.toString());
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_pp:
                if (!doubleClicked()) {
                    try {
                        Intent intent1 = new Intent(Intent.ACTION_VIEW);
                        intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                        startActivity(intent1);
                    }catch (ActivityNotFoundException e)
                    {
                        Toast.makeText(AboutUsScreen.this, "You don't have Google installed",
                                Toast.LENGTH_SHORT).show();
                    }
                    break;
                }
                return;
            case R.id.tv_rate:
                try {
                    startActivity(new Intent(
                            "android.intent.action.VIEW",
                            Uri.parse(getResources().getString(R.string.rate_us)
                                    + getPackageName())));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(AboutUsScreen.this, "You don't have Google Play installed",
                            Toast.LENGTH_SHORT).show();
                }
                return;
            case R.id.tv_share:
                if (!doubleClicked()) {
                    shareApp();
                    break;
                }
                return;

            case R.id.iv_back:

                if (interstitial !=null && interstitial.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                id = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                }else {
                    startActivity(new Intent(AboutUsScreen.this, HomeScreen.class));
                    finish();
                }
        }
    }


    private void loadAd() {

        //interstitial FullScreenAd
        interstitial = new InterstitialAd(AboutUsScreen.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id)
                {
                    case 100:
                        startActivity(new Intent(AboutUsScreen.this, HomeScreen.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(activity);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public boolean doubleClicked() {
        long elapsedRealtime = SystemClock.elapsedRealtime() - this.lastClickedTime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("diff ");
        stringBuilder.append(elapsedRealtime);
        this.lastClickedTime = SystemClock.elapsedRealtime();
        return elapsedRealtime < 600;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        finish();
        return super.onOptionsItemSelected(menuItem);
    }
}
