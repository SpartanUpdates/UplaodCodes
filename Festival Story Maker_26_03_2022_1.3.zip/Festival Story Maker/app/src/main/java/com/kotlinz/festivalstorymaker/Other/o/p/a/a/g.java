package com.kotlinz.festivalstorymaker.Other.o.p.a.a;

public interface g {
    void V(int i);

    void Y(int i, int i2);

}
