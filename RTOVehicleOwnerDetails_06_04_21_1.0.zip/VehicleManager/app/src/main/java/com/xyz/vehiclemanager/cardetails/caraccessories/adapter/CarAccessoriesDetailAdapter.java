package com.xyz.vehiclemanager.cardetails.caraccessories.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.cardetails.caraccessories.model.CarAccessories;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CarAccessoriesDetailAdapter extends RecyclerView.Adapter<CarAccessoriesDetailAdapter.MyViewHolder>
{
    private Context mcontext;
    private ArrayList<CarAccessories> carAccessoriesDetailslist;

    public class MyViewHolder extends RecyclerView.ViewHolder{

        ImageView iv_accessoriesicon;
        TextView tv_accessoriestitle;
        TextView tv_accessoriesofferPrice;
        TextView tv_accessoriesstoreName;
        LinearLayout ll_click;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            iv_accessoriesicon = itemView.findViewById(R.id.iv_accessoriesicon);
            tv_accessoriestitle = itemView.findViewById(R.id.tv_accessoriestitle);
            tv_accessoriesofferPrice = itemView.findViewById(R.id.tv_accessoriesofferPrice);
            tv_accessoriesstoreName = itemView.findViewById(R.id.tv_accessoriesstoreName);
            ll_click = itemView.findViewById(R.id.ll_click);
        }
    }

    public CarAccessoriesDetailAdapter(Context mcontext, ArrayList<CarAccessories> carAccessoriesDetailslist) {
        this.mcontext = mcontext;
        this.carAccessoriesDetailslist = carAccessoriesDetailslist;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_accessories,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position)
    {
        final CarAccessories carAccessoriesDetails = carAccessoriesDetailslist.get(position);

        holder.tv_accessoriestitle.setText(carAccessoriesDetails.getTitle());
        holder.tv_accessoriesofferPrice.setText(carAccessoriesDetails.getOfferPrice());
        holder.tv_accessoriesstoreName.setText(carAccessoriesDetails.getStoreName());

        Glide.with(mcontext)
                .load(carAccessoriesDetails.getImage())
                .placeholder(R.mipmap.ic_launcher)
                .into(holder.iv_accessoriesicon);

        holder.ll_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(carAccessoriesDetails.getUrl()));
                mcontext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return carAccessoriesDetailslist.size();
    }
}
