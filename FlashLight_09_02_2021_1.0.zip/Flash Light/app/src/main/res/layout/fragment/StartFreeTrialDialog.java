package flash.light.shine.com.fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.work.PeriodicWorkRequest;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.google.android.material.textview.MaterialTextView;
import flash.light.shine.com.R;
import flash.light.shine.com.TinyDB;
import flash.light.shine.com.UnityImpl;
import flash.light.shine.com.UnityImpl.UnityListner;
import flash.light.shine.com.billing.BillingManager;
import io.branch.referral.util.BranchEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class StartFreeTrialDialog extends Fragment implements PurchasesUpdatedListener {
    public static String TAG = "StartFreeTrialDialog";
    private static Activity mActivity;
    private static Callback mCallback;
    private BillingManager billingManager;
    private boolean isRepay;
    private ImageView ivClose;
    private FrameLayout laySubscribe;
    private TextView policyText;
    private int state = 0;
    private int stateClose = 0;
    private CountDownTimer timer;
    private TinyDB tinyDB;
    private TextView tvPrice;
    private UnityImpl unity;

    public interface Callback {
        void OnResult();

        void OnSubscribed();
    }

    public static StartFreeTrialDialog newInstance(Activity activity, Callback callback) {
        mActivity = activity;
        mCallback = callback;
        return new StartFreeTrialDialog();
    }

    private void initView(View view) {
        this.ivClose = (ImageView) view.findViewById(R.id.iv_close);
        this.tvPrice = (TextView) view.findViewById(R.id.tv_price);
        this.laySubscribe = (FrameLayout) view.findViewById(R.id.lay_subscribe);
        this.policyText = (TextView) view.findViewById(R.id.policy_text);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.tinyDB = new TinyDB(mActivity);
        this.unity = new UnityImpl(mActivity);
        this.billingManager = new BillingManager(mActivity, this);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreateView(layoutInflater, viewGroup, bundle);
        View inflate = layoutInflater.inflate(R.layout.activity_pay, viewGroup, false);
        initView(inflate);
        return inflate;
    }

    public void onDestroy() {
        CountDownTimer countDownTimer = this.timer;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        super.onDestroy();
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.billingManager.setprice("flashlight.monthly.com", this.tvPrice);
        this.ivClose.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (StartFreeTrialDialog.this.stateClose == 0) {
                    StartFreeTrialDialog.this.showPayPage2();
                } else if (StartFreeTrialDialog.this.stateClose == 1) {
                    StartFreeTrialDialog.this.showPayDialog();
                } else {
                    StartFreeTrialDialog.this.showAdsDialog();
                }
            }
        });
        this.laySubscribe.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                StartFreeTrialDialog.this.billingManager.startPurchaseFlow("flashlight.monthly.com");
                StartFreeTrialDialog.this.state = 0;
            }
        });
    }

    public void showPayPage2() {
        this.stateClose = 1;
        final Dialog dialog = new Dialog(mActivity, R.style.AppTheme);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setContentView(R.layout.layout_exit);
        String str = "pay_page_2_view";
        new BranchEvent(str).addCustomDataProperty("type", str).logEvent(mActivity);
        FrameLayout frameLayout = (FrameLayout) dialog.findViewById(R.id.lay_subscribe);
        ImageView imageView = (ImageView) dialog.findViewById(R.id.iv_close);
        this.billingManager.setprice("flashlight.monthly.com", (TextView) dialog.findViewById(R.id.price_text));
        frameLayout.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
                String str = "click_view_2";
                new BranchEvent(str).addCustomDataProperty("type", str).logEvent(StartFreeTrialDialog.mActivity);
                StartFreeTrialDialog.this.billingManager.startPurchaseFlow("flashlight.monthly.com");
                StartFreeTrialDialog.this.state = 1;
            }
        });
        imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
                StartFreeTrialDialog.this.showPayDialog();
            }
        });
        if (!mActivity.isFinishing()) {
            dialog.show();
        }
    }

    private void showPayDialog() {
        this.isRepay = true;
        this.stateClose = 2;
        final Dialog dialog = new Dialog(mActivity, R.style.AppTheme);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setContentView(R.layout.dilog_pay);
        MaterialTextView materialTextView = (MaterialTextView) dialog.findViewById(R.id.button_try_free_for_3_days);
        ((ImageView) dialog.findViewById(R.id.iv_close)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.cancel();
            }
        });
        final TextView textView = (TextView) dialog.findViewById(R.id.timer_text);
        this.billingManager.setprice("flashlight.monthly.com", (TextView) dialog.findViewById(R.id.price_Text));
        materialTextView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                StartFreeTrialDialog.this.billingManager.startPurchaseFlow("flashlight.monthly.com");
                StartFreeTrialDialog.this.state = 1;
            }
        });
        dialog.setOnCancelListener(new OnCancelListener() {
            public void onCancel(DialogInterface dialogInterface) {
                StartFreeTrialDialog.this.showAdsDialog();
            }
        });
        final Dialog dialog2 = dialog;
        AnonymousClass8 anonymousClass8 = new CountDownTimer(PeriodicWorkRequest.MIN_PERIODIC_FLEX_MILLIS, 100) {
            public void onTick(long j) {
                TextView textView = textView;
                String str = "%1$02d";
                StringBuilder append = new StringBuilder().append("").append(String.format(str, new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(j)))}));
                String str2 = " : ";
                textView.setText(append.append(str2).append(String.format(str, new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j)))})).append(str2).append(String.format(str, new Object[]{Long.valueOf((TimeUnit.MILLISECONDS.toMillis(j) - TimeUnit.SECONDS.toMillis(TimeUnit.MILLISECONDS.toSeconds(j))) / 10)})).toString());
            }

            public void onFinish() {
                dialog2.dismiss();
                StartFreeTrialDialog.this.showAdsDialog();
            }
        };
        this.timer = anonymousClass8;
        anonymousClass8.start();
        if (!mActivity.isFinishing()) {
            dialog.show();
        }
    }

    private void showAdsDialog() {
        final Dialog dialog = new Dialog(mActivity, R.style.AppTheme);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setContentView(R.layout.dilog_ads);
        dialog.setCancelable(false);
        ((MaterialTextView) dialog.findViewById(R.id.watch)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                StartFreeTrialDialog.this.unity.showReward(new UnityListner() {
                    public void onAdClosed() {
                        dialog.dismiss();
                        if (StartFreeTrialDialog.mCallback != null) {
                            StartFreeTrialDialog.mCallback.OnResult();
                        }
                    }
                });
            }
        });
        dialog.show();
    }

    public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
        if (billingResult.getResponseCode() == 0) {
            this.tinyDB.putBoolean("purchased", true);
            this.billingManager.acknowledgement(billingResult, list);
            Toast.makeText(mActivity, "You are successfully Subscribed", 0).show();
            Callback callback = mCallback;
            if (callback != null) {
                callback.OnSubscribed();
            }
        } else if (this.state == 0) {
            showPayDialog();
        } else {
            showAdsDialog();
        }
    }
}
