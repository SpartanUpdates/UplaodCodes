package com.kotlinz.vehiclemanager.famousperson.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.famousperson.adapter.famousListAdapter;
import com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.utils.Utils;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.jetbrains.annotations.NotNull;

public class FamousPersonListActivity extends AppCompatActivity implements View.OnClickListener {

    public Activity activity = FamousPersonListActivity.this;
    private RecyclerView rv_trending;
    private ImageView iv_back;
    private TextView tv_tile;
    private String catName;
    private famousListAdapter trendingListAdapter;
    private String Input1;
    private String Input2;
    private String Input3;


    GGAdview gg_native;

    public int id;
    public GGInterstitialAd interstitialAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_celebrity_list);
        PutAnalyticsEvent();
        catName = getIntent().getStringExtra("categoryname");
        BindView();
        tv_tile.setText(this.catName);
        SetData();
        CallNativeAds();
        InterAds();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            tv_tile.setTextColor(Color.parseColor("#FFFFFF"));
        }

        DarkTheame darkTheame = new DarkTheame(FamousPersonListActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            tv_tile.setTextColor(Color.parseColor("#FFFFFF"));
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "FamousPersonListActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void CallNativeAds(){
        gg_native = findViewById(R.id.ggAdView_native);
        gg_native.setUnitId(getResources().getString(R.string.NativeAd));
        gg_native.loadAd(new AdLoadCallback()
                         {
                             @Override
                             public void onReadyForRefresh() {

                             }
                             @Override
                             public void onUiiClosed() {

                             }
                             @Override
                             public void onUiiOpened() {

                             }
                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 1:
                        startActivity(new Intent(FamousPersonListActivity.this, MainActivity.class));
                        finish();
                }
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }


    private void BindView() {
        iv_back = findViewById(R.id.iv_back);
        tv_tile = findViewById(R.id.tv_title);
        rv_trending = findViewById(R.id.rv_trending);

        iv_back.setOnClickListener(this);
    }

    private void SetData() {
        if (catName.equals("Mr.Perfect")) {
            tv_tile.setText("Mr.Perfect");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new famousListAdapter(activity, Utils.mrperfectsnum, Utils.mrperfectsname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.mrperfectsnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Dancers")) {
            tv_tile.setText("Dancers");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            trendingListAdapter = new famousListAdapter(activity, Utils.dancersnum, Utils.dancersname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.dancersnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Singers")) {
            tv_tile.setText("Singers");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            trendingListAdapter = new famousListAdapter(activity, Utils.singersnum, Utils.singersname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.singersnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Actors")) {
            tv_tile.setText("Actors");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            trendingListAdapter = new famousListAdapter(activity, Utils.actorsnum, Utils.actorsname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.actorsnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Politicians")) {
            tv_tile.setText("Politicians");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new famousListAdapter(activity, Utils.politiciansnum, Utils.politiciansname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.politiciansnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Sports Person")) {
            tv_tile.setText("Sports Person");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new famousListAdapter(activity, Utils.sportspersonsnum, Utils.sportspersonsname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.sportspersonsnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Actresses")) {
            tv_tile.setText("Actresses");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new famousListAdapter(activity, Utils.actressesnum, Utils.actressesname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.actressesnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }

    public void substring(String str) {
        String substring;
        if (Character.isDigit(str.charAt(4))) {
            substring = str.substring(0, 4);
            str = str.substring(4);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = "";
        } else if (Character.isDigit(str.charAt(5))) {
            substring = str.substring(0, 5);
            str = str.substring(5);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = substring.substring(4, 5);
        } else if (Character.isDigit(str.charAt(6))) {
            substring = str.substring(0, 6);
            str = str.substring(6);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = substring.substring(4, 6);
        } else {
            substring = str.substring(0, 7);
            str = str.substring(7);
        }

        Intent intent = new Intent(this, RtoOwnerDetailActivity.class);
        intent.putExtra("first", Input1);
        intent.putExtra("second", Input2);
        intent.putExtra("third", Input3);
        intent.putExtra("fourth", str);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 1;
            interstitialAd.show();
        } else {
            startActivity(new Intent(FamousPersonListActivity.this, MainActivity.class));
            finish();
            super.onBackPressed();
        }
    }
}