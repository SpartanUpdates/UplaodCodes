package com.esc.phoneheart.activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.esc.phoneheart.R;
import com.esc.phoneheart.kprogresshud.KProgressHUD;
import com.esc.phoneheart.pref.MySharedPreference;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.pref.SharedPrefUtil;
import com.esc.phoneheart.utility.Util;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class FinalScreen extends AppCompatActivity implements OnClickListener {
    public static final String TAG = "CommonResultScreen";
    private Activity activity = FinalScreen.this;
    public Context context;
    public int notDeleted = 0;
    public boolean redirectTonoti;
    public SharedPrefUtil savedPref;
    public LinearLayout toplayout;
    public TextView tv_message;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitialAd;
    private int Adid;
    private KProgressHUD hud;

    private void findids() {
        this.tv_message = (TextView) findViewById(R.id.tv_resultmessage);
        this.toplayout = (LinearLayout) findViewById(R.id.upper_layout_top);
    }

    private void redirectToNoti() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.redirectTonoti);
        Log.e(TAG, stringBuilder.toString());
        this.redirectTonoti = getIntent().getBooleanExtra(GlobalData.REDIRECTNOTI, false);
    }

    private void saveVisitCount() {
        SharedPrefUtil savedPref = new SharedPrefUtil(this);
        String str = SharedPrefUtil.RES_VCOUNT;
        int i = savedPref.getInt(str) + 1;
        savedPref.saveInt(str, i);
    }

    private void setTopLayoutAsPerType() {
        char c = 0;
        String str = "DATA";
        String stringExtra = getIntent().getStringExtra(str);
        this.toplayout.setVisibility(View.VISIBLE);
        String stringExtra2 = getIntent().getStringExtra("TYPE");
        StringBuilder sb = new StringBuilder();
        sb.append("method:setTopLayoutAsPerType ");
        sb.append(stringExtra2);
        String str2 = "";
        Util.appendLogphonecleaner(TAG, sb.toString(), str2);
        switch (stringExtra2.hashCode())
        {
            case -1843721363:
                if (stringExtra2.equals("SOCIAL")) {
                    c = 2;
                }
                break;
            case -1293709085:
                if (stringExtra2.equals("Recovered")) {
                    c = 6;
                }
                break;
            case -1287687863:
                if (stringExtra2.equals("NODOWNLOAD")) {
                    c = 9;
                }
                break;
            case -306684693:
                if (stringExtra2.equals("DUPLICATE")) {
                    c = 3;
                }
                break;
            case 68063:
                if (stringExtra2.equals("DUP")) {
                    c = 8;
                }
                break;
            case 2288712:
                if (stringExtra2.equals("JUNK")) {
                    c = 0;
                }
                break;
            case 63384451:
                if (stringExtra2.equals("BOOST")) {
                    c = 5;
                }
                break;
            case 183360354:
                if (stringExtra2.equals("COMPRESS")) {
                    c = 7;
                }
                break;
            case 256754361:
                if (stringExtra2.equals("JUNK_ALLREADY")) {
                    c = 1;
                }
                break;
            case 1993540022:
                if (stringExtra2.equals("COOLER")) {
                    c = 4;
                }
                break;
            default:
                c = 65535;
                break;
        }
        String str3 = "%d";
        String str4 = "DO_NOT_TRANSLATE";
        switch (c) {
            case 0:
                this.tv_message.setText(getString(R.string.junk_finish_Success));
                return;
            case 1:
                this.tv_message.setText(String.format("%s", new Object[]{getIntent().getStringExtra(str)}));
                return;
            case 3:
                this.tv_message.setText(String.format(getResources().getString(R.string.pcl_deletionmsg_two).replace(str4, str3), new Object[]{Integer.valueOf(this.notDeleted)}));
                return;
            case 4:
                this.tv_message.setText(getString(R.string.cpu_finish_success));
                return;
            case 5:
                TextView textView = this.tv_message;
                StringBuilder sb2 = new StringBuilder();
                sb2.append(str2);
                sb2.append(stringExtra);
                textView.setText(sb2.toString());
                return;
            case 6:
                if (this.notDeleted > 0) {
                    this.tv_message.setText(String.format(getResources().getString(R.string.pcl_deletionmsg_two).replace(str4, str3), new Object[]{Integer.valueOf(this.notDeleted)}));
                    return;
                }
                this.tv_message.setText(getResources().getString(R.string.file_manager_finish_Success));
                return;
            case 7:
                this.tv_message.setText(getResources().getString(R.string.file_manager_finish_Success));
                return;
            case 8:
                TextView textView2 = this.tv_message;
                StringBuilder sb3 = new StringBuilder();
                sb3.append(str2);
                sb3.append(getIntent().getStringExtra(str));
                textView2.setText(sb3.toString());
                return;
            case 9:
                this.tv_message.setText(str2);
                return;
            default:
                return;
        }
    }

    public void onBackPressed() {
        boolean z = GlobalData.returnedAfterSocialDeletion;
        try {
            PhoneCleaner.getInstance().junkData = null;
            System.runFinalization();
            Runtime.getRuntime().gc();
            System.gc();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (PhoneCleaner.getInstance().spaceManagerModule != null) {
            GlobalData.returnedAfterDeletion = true;
        }
        if (this.redirectTonoti) {
                finish();
                startActivity(new Intent(this.context, HomeActivity.class));
            return;
        }
        super.onBackPressed();
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.iv_backs) {

            if (interstitialAd != null && interstitialAd.isLoaded()){
                try {
                    hud = KProgressHUD.create(activity)
                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                            .setLabel("Showing Ads")
                            .setDetailsLabel("Please Wait...");
                    hud.show();
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (NullPointerException e2) {
                    e2.printStackTrace();
                } catch (Exception e3) {
                    e3.printStackTrace();
                }

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            hud.dismiss();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();

                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }
                        if (interstitialAd != null && interstitialAd.isLoaded()) {
                            Adid = 100;
                            interstitialAd.show();
                        }
                    }
                }, 2000);
            }else {
                startActivity(new Intent(this.context, HomeActivity.class));
                finish();
            }
        } else if (id == R.id.iv_rate) {
            try {
                startActivity(new Intent(
                        "android.intent.action.VIEW",
                        Uri.parse(getResources().getString(R.string.rate_us)
                                + getPackageName())));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(FinalScreen.this, "You don't have Google Play installed",
                        Toast.LENGTH_SHORT).show();
            }
        } else if (id == R.id.iv_share) {
            Intent share = new Intent("android.intent.action.SEND");
            share.setType("text/plain");
            share.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.share_msg) + getPackageName());
            startActivity(Intent.createChooser(share, "Share Via"));
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        GlobalData.SETAPPLAnguage(this);
        setContentView(R.layout.activity_final_screen);
        Util.saveScreen(FinalScreen.class.getName(), this);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
        }
        String str = "";
        String str2 = TAG;
        Util.appendLogphonecleaner(str2, "onCreate()", str);
        this.notDeleted = getIntent().getIntExtra("not_deleted", 0);
        this.context = this;
        this.savedPref = new SharedPrefUtil(this.context);
        if (BaseActivity.displaymetrics == null) {
            BaseActivity.displaymetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(BaseActivity.displaymetrics);
        }
        findids();
        redirectToNoti();
        loadAd();
        BannerAds();
        setTopLayoutAsPerType();
        findViewById(R.id.iv_backs).setOnClickListener(this);
        findViewById(R.id.iv_share).setOnClickListener(this);
        findViewById(R.id.iv_rate).setOnClickListener(this);
        Util.appendLogphonecleaner(str2, "oncreate ends ", str);
        GlobalData.imageviewed = false;
        if (PhoneCleaner.getInstance().junkData != null) {
            PhoneCleaner.getInstance().junkData.sys_cache_deleted = false;
        }
        saveVisitCount();
    }

    private void loadAd() {

        //InterstitialAd
        interstitialAd = new InterstitialAd(FinalScreen.this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        startActivity(new Intent(FinalScreen.this, HomeActivity.class));
                        finish();
                        break;

                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitialAd = new InterstitialAd(activity);
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        return super.onOptionsItemSelected(menuItem);
    }

    public void onPause() {
        super.onPause();
        GlobalData.loadAds = true;
        GlobalData.backPressedResult = true;
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        return true;
    }

    public void onResume() {
        super.onResume();
        Log.w(TAG, "OnResume Called");
        GlobalData.proceededToAd = false;
    }
}
