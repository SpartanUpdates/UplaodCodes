package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.Typeface;
import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;

public class QuoteSetFont implements com.kotlinz.festivalstorymaker.texteditor.FontListAdapter.a {
    public final  QuoteMakerDetailActivity activity;

    public QuoteSetFont(QuoteMakerDetailActivity quoteMakerDetailActivity) {
        this.activity = quoteMakerDetailActivity;
    }

    public final void B(Typeface typeface, int i) {
        activity.B(typeface, i);
    }
}
