package com.esc.motivationquotes.managers;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.esc.motivationquotes.Quotes;
import java.util.ArrayList;
import java.util.List;

public class FavoritesManager {
    private static final String PREF_FAVORITES = "pref_favorites_com.esc.motivationquotes.motivation";

    public static void addFavorite(String str) {
        ArrayList<String> favorites = getFavorites();
        if (favorites == null) {
            favorites = new ArrayList();
        }
        favorites.add(str);
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        if (str != null) {
            edit.putString(PREF_FAVORITES, new Gson().toJson(favorites));
        }
        edit.commit();
    }

    public static ArrayList<String> getFavorites() {
        String string = PreferenceManager.getDefaultSharedPreferences(getContext()).getString(PREF_FAVORITES, null);
        if (string != null) {
            return (ArrayList) new Gson().fromJson(string, new TypeToken<List<String>>() {
            }.getType());
        }
        return new ArrayList();
    }

    public static int getFavoritesCount() {
        String string = PreferenceManager.getDefaultSharedPreferences(getContext()).getString(PREF_FAVORITES, null);
        return string != null ? ((ArrayList) new Gson().fromJson(string, new TypeToken<List<String>>() {
        }.getType())).size() : 0;
    }

    public static boolean isFavorite(String str) {
        ArrayList favorites = getFavorites();
        return favorites != null ? favorites.contains(str) : false;
    }

    public static void removeFavorite(String str) {
        ArrayList<String> favorites = getFavorites();
        favorites.remove(str);
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        if (str != null) {
            edit.putString(PREF_FAVORITES, new Gson().toJson(favorites));
        }
        edit.commit();
    }

    private static Context getContext() {
        return Quotes.getInstance();
    }
}
