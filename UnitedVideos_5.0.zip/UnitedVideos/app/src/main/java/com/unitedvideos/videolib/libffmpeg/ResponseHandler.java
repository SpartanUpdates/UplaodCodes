package com.unitedvideos.videolib.libffmpeg;

abstract interface ResponseHandler
{
  public abstract void onStart();
  
  public abstract void onFinish();
}
