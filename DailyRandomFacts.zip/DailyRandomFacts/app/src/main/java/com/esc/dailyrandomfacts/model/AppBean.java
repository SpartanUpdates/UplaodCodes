package com.esc.dailyrandomfacts.model;

public class AppBean {
    public String appDescr;
    public int appLogoName;
    public String appName;
    public String appPackageName;
}
