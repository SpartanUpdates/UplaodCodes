package com.kotlinz.festivalstorymaker.Model.PosterMaker.CategoryWiseData;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class CategoryWiseResponse {

	@SerializedName("data")
	private ArrayList<CategoryWiseData> data;

	@SerializedName("total_records")
	private int totalRecords;

	@SerializedName("status")
	private String status;

	public ArrayList<CategoryWiseData> getData(){
		return data;
	}

	public int getTotalRecords(){
		return totalRecords;
	}

	public String getStatus(){
		return status;
	}
}