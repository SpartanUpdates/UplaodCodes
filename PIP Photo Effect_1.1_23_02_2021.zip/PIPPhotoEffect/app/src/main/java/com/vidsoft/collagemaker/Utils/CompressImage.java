package com.vidsoft.collagemaker.Utils;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.MaskFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.media.ExifInterface;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class CompressImage {
    public static final float BITMAP_SCALE = 0.4f;
    public static final float BLUR_RADIUS = 7.5f;
    public static final int RADIUS = 5;


    public static Bitmap flip(final Bitmap bitmap, final boolean b, final boolean b2) {
        float n = -1.0f;
        final Matrix matrix = new Matrix();
        float n2;
        if (b) {
            n2 = -1.0f;
        } else {
            n2 = 1.0f;
        }
        if (!b2) {
            n = 1.0f;
        }
        matrix.preScale(n2, n);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }


    public static String getPath(final Context context, final Uri uri) {
        if (uri == null) {
            return null;
        }
        final Cursor query = context.getContentResolver().query(uri, new String[]{"_data"}, (String) null, (String[]) null, (String) null);
        if (query != null) {
            final int columnIndexOrThrow = query.getColumnIndexOrThrow("_data");
            query.moveToFirst();
            final String string = query.getString(columnIndexOrThrow);
            query.close();
            return string;
        }
        return uri.getPath();
    }

    public static Bitmap modifyOrientation(final Bitmap bitmap, final String s) throws IOException {
        switch (new ExifInterface(s).getAttributeInt("Orientation", 1)) {
            default: {
                return bitmap;
            }
            case 6: {
                return rotate(bitmap, 90.0f);
            }
            case 3: {
                return rotate(bitmap, 180.0f);
            }
            case 8: {
                return rotate(bitmap, 270.0f);
            }
            case 2: {
                return flip(bitmap, true, false);
            }
            case 4: {
                return flip(bitmap, false, true);
            }
        }
    }

    public static Bitmap originalBitmap(final Bitmap bitmap) {
        final int width = bitmap.getWidth();
        final int height = bitmap.getHeight();
        int n;
        int n2;
        if (width > height) {
            n = 960;
            n2 = height * 960 / width;
        } else {
            n2 = 960;
            n = width * 960 / height;
        }
        return Bitmap.createScaledBitmap(bitmap, n, n2, false);
    }

    public static Bitmap resize(final Bitmap bitmap, final int n, final int n2) {
        final float n3 = bitmap.getWidth();
        final float n4 = bitmap.getHeight();
        final float n5 = n;
        final float n6 = n2 - 120;
        final float n7 = n3 / n4;
        final float n8 = n4 / n3;
        float n9;
        float n10;
        if (n3 > n5) {
            n9 = n5;
            n10 = n8 * n5;
        } else if (n4 > n6) {
            n10 = n6;
            n9 = n10 * n7;
        } else {
            n9 = n5;
            n10 = n9 * n8;
        }
        return Bitmap.createScaledBitmap(bitmap, (int) n9, (int) n10, false);
    }

    public static Bitmap rotate(final Bitmap bitmap, final float n) {
        final Matrix matrix = new Matrix();
        matrix.postRotate(n);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static Bitmap rotateBitmap(final Bitmap bitmap, final float n) {
        final Matrix matrix = new Matrix();
        matrix.postRotate(n);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static Bitmap rotateBitmap1(final Bitmap bitmap, final int n) {
        final int width = bitmap.getWidth();
        final int height = bitmap.getHeight();
        int n2 = width;
        int n3 = height;
        if (n == 90 || n == 270) {
            n2 = height;
            n3 = width;
        }
        final Bitmap bitmap2 = Bitmap.createBitmap(n2, n3, bitmap.getConfig());
        final Canvas canvas = new Canvas(bitmap2);
        final Rect rect = new Rect(0, 0, n2, n3);
        final Matrix matrix = new Matrix();
        final float exactCenterX = rect.exactCenterX();
        final float exactCenterY = rect.exactCenterY();
        matrix.postTranslate((float) (-bitmap.getWidth() / 2), (float) (-bitmap.getHeight() / 2));
        matrix.postRotate((float) n);
        matrix.postTranslate(exactCenterX, exactCenterY);
        canvas.drawBitmap(bitmap, matrix, new Paint(7));
        matrix.reset();
        return bitmap2;
    }

    public static Bitmap sideBlur(final Bitmap bitmap, final int n) {
        final Bitmap bitmap2 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        final Canvas canvas = new Canvas(bitmap2);
        final Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setMaskFilter((MaskFilter) new BlurMaskFilter((float) n, BlurMaskFilter.Blur.NORMAL));
        final Path path = new Path();
        path.moveTo((float) n, (float) n);
        path.lineTo((float) (canvas.getWidth() - n), (float) n);
        path.lineTo((float) (canvas.getWidth() - n), (float) (canvas.getHeight() - n));
        path.lineTo((float) n, (float) (canvas.getHeight() - n));
        path.lineTo((float) n, (float) n);
        path.close();
        canvas.drawPath(path, paint);
        paint.setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
        return bitmap2;
    }

    public static File tempImage(final Context context, final Bitmap bitmap) {
        File tempFile = null;
        while (true) {
            try {
                final File file = tempFile = File.createTempFile("temp", null, context.getCacheDir());
                if (file.exists()) {
                    tempFile = file;
                    file.delete();
                }
                tempFile = file;
                final FileOutputStream fileOutputStream = new FileOutputStream(file);
                tempFile = file;
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream) fileOutputStream);
                tempFile = file;
                fileOutputStream.flush();
                tempFile = file;
                fileOutputStream.close();
                tempFile = file;
                context.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(tempFile)));
                return tempFile;
            } catch (IOException ex) {
                ex.printStackTrace();
                continue;
            }
        }
    }
}
