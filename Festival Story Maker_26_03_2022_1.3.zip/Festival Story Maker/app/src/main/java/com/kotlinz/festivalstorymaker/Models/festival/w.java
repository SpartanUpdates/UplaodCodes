package com.kotlinz.festivalstorymaker.Models.festival;

import java.io.Serializable;

public class w implements Serializable {
    public String n;
    public String o;
    public String p;
    public String q;
    public String r;
}
