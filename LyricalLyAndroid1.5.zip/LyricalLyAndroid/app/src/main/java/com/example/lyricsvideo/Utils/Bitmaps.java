package com.example.lyricsvideo.Utils;

import android.graphics.Bitmap;

public class Bitmaps {
    public static Bitmap bitmap(Bitmap bitmap, int i, int i2) {
        return CreateBitmap.bitmap(CreateBitmap.bitmap(Orientation.bitmap(bitmap, i, i2), 25, true), 25, true);
    }

}
