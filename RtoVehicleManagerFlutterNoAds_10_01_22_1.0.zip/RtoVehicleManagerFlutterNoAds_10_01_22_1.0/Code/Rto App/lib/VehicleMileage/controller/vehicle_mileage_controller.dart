import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:rto_app/VehicleMileage/model/vehicle_mileage_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'dart:io' as io;

class VehicleMileageController extends GetxController {
  List<VehicleMileageModel> mileageDataList = [];

  FocusNode? focusNode;

  double? kmPerLtr = 00;
  double? rsPerLtr = 00;
  double? rsPerKm = 00;

  static Database? _db;

  Future<Database?> get db async {
    if (_db != null) {
      return _db;
    }
    _db = await initDatabase();
    return _db;
  }

  initDatabase() async {
    io.Directory documentDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentDirectory.path, 'vehiclemileage.db');
    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async {
    await db.execute(
        "CREATE TABLE mileage (id INTEGER PRIMARY KEY AUTOINCREMENT,randomId TEXT NOT NULL,date TEXT NOT NULL,lastreserve TEXT NOT NULL,currentreserve TEXT NOT NULL,totalprice TEXT NOT NULL,totalfuel TEXT NOT NULL,kmperltr TEXT NOT NULL,rsperltr TEXT NOT NULL,rsperkm TEXT NOT NULL)");
  }

  Future<void> insert(VehicleMileageModel notesModel) async {
    try {
      var dbClient = await db;
      await dbClient!.insert('mileage', notesModel.toMap());
    } on Exception catch (e) {
      throw Exception(e.toString());
    }
  }

  Future<void> getAllData() async {
    try {
      var dbClient = await db;
      final List<Map<String, Object?>> queryResult =
          await dbClient!.rawQuery('select * from mileage');
      mileageDataList =
          queryResult.map((e) => VehicleMileageModel.fromMap(e)).toList();
    } on Exception catch (_) {
      throw Exception("error");
    }
    update();
  }

  Future<int> delete(String randomId) async {
    try {
      var dbClient = await db;
      return await dbClient!
          .delete('mileage', where: 'randomId=?', whereArgs: [randomId]);
    } on Exception catch (_) {
      throw Exception("error");
    }
    update();
  }

  Future<void> calculation(BuildContext context, String lastReserve,
      String currentReserve, String totalPrice, String totalFuel) async {
    kmPerLtr = double.parse(currentReserve) - double.parse(lastReserve);
    kmPerLtr = (kmPerLtr! / double.parse(totalFuel));

    rsPerKm = double.parse(currentReserve) - double.parse(lastReserve);
    rsPerKm = double.parse(totalPrice) / rsPerKm!;

    rsPerLtr = double.parse(totalPrice) / double.parse(totalFuel);
    FocusScope.of(context).unfocus();
    update();
  }
}
