package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;

import com.kotlinz.videostatusmaker.Utils.Utils;
import com.kotlinz.videostatusmaker.Others.CropImageView;


public class ActivityImageCrop extends Activity {
    Activity activity = ActivityImageCrop.this;
    ImageView ivBack;
    TextView ivDone;
    Typeface typeface;
    CropImageView cropImageView;
    TextView tvTitle;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.image_crop);
        getWindow().addFlags(1024);
        PutAnalyticsEvent();
        BannerAds();
        bindview();
        init();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityImageCrop");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void bindview() {
        this.cropImageView = (CropImageView) findViewById(R.id.img);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.ivDone = (TextView) findViewById(R.id.done);
        this.tvTitle = (TextView) findViewById(R.id.title);

    }

    private void init() {
        this.tvTitle.setTextSize(18.0f);
        this.typeface = Typeface.createFromAsset(getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        this.cropImageView.setImageUriAsync(Utils.uri);
        this.cropImageView.setFixedAspectRatio(false);
        this.ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.isShowAd == 1) {
                    GoToNext();
                    setResult(-1);
                    finish();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        GoToNext();
                        MyApplication.AdsId = 6;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        GoToNext();
                        setResult(-1);
                        finish();
                    }
                }
            }
        });
        this.ivBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityImageCrop.this.onBackPressed();
            }
        });
    }

    private void GoToNext(){
        Utils.selected_Bitmap = ActivityImageCrop.this.cropImageView.getCroppedImage();
    }

}
