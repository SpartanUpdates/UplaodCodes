package com.esc.poems;

import android.app.Activity;
import android.content.SharedPreferences;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import java.util.ArrayList;
import java.util.Random;

public class TopCategoryAdapter extends RecyclerView.Adapter<TopCategoryAdapter.MyViewHolder> {
    private int[] c_img = new int[]{R.drawable.toplovepoems_unlocked, R.drawable.bestpoems_unlocked, R.drawable.topbirthdaypoems_unlocked, R.drawable.topfriendshippoems_unlocked, R.drawable.topmissingyoupoems_unlocked, R.drawable.top100poems_unlocked};
    private int[] c_imgL = new int[]{R.drawable.toplovepoems_locked, R.drawable.bestpoems_locked, R.drawable.topbirthdaypoems_locked, R.drawable.topfriendshippoems_locked, R.drawable.topmissingyoupoems_locked, R.drawable.top100poems_locked};
    private ArrayList<String> cat;
    private ItemClickListener mClickListener;
    private SharedPreferences prefs;
    private int sh;
    private int sw;
    private ArrayList<String> unlockkey;

    public interface ItemClickListener {
        void onItemClick(View view, int i);
    }

    class MyViewHolder extends ViewHolder implements OnClickListener {
        ImageView img;

        public MyViewHolder(View view) {
            super(view);
            this.img = (ImageView) view.findViewById(R.id.img);
            view.setOnClickListener(this);
        }

        public void onClick(View view) {
            if (TopCategoryAdapter.this.mClickListener != null) {
                TopCategoryAdapter.this.mClickListener.onItemClick(view, getAdapterPosition());
            }
        }
    }

    public TopCategoryAdapter(Activity activity, ArrayList<String> arrayList, ArrayList<String> arrayList2) {
        this.cat = arrayList;
        this.unlockkey = arrayList2;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.sw = displayMetrics.widthPixels;
        this.sh = displayMetrics.heightPixels;
        this.prefs = activity.getSharedPreferences("bdaymsg", 0);
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.top_category_items, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        Random random = new Random();
        if (this.prefs.getBoolean((String) this.unlockkey.get(i), false)) {
            myViewHolder.img.setImageResource(this.c_img[i]);
        } else {
            myViewHolder.img.setImageResource(this.c_imgL[i]);
        }
        LayoutParams layoutParams = myViewHolder.img.getLayoutParams();
        double d = (double) this.sw;
        Double.isNaN(d);
        layoutParams.width = (int) (d / 2.1d);
        LayoutParams layoutParams2 = myViewHolder.img.getLayoutParams();
        d = (double) this.sw;
        Double.isNaN(d);
        layoutParams2.height = (int) (d / 2.1d);
    }

    public int getItemCount() {
        return this.cat.size();
    }


    public void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }
}
