package com.kotlinz.videoeditor.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;


import com.kotlinz.videoeditor.R;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.LoopingMediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.ui.TimeBar;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DataSpec;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.FileDataSource;

import java.io.File;

public class ShareVideoActivity extends AppCompatActivity {
    Activity activity = ShareVideoActivity.this;
    static final boolean r = true;
    private SimpleExoPlayerView ShrExoPlay;
    private DataSpec dataSpec;
    private SimpleExoPlayer ecoPlayer;
    private boolean onBack;
    private TimeBar timeBar;
    private String yourRealPath;
    private Uri o;
    private ImageView iv_back, videodelete;
    private ImageView videoshare;


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.share_video_activity);
        iv_back = findViewById(R.id.iv_back);
        videodelete = findViewById(R.id.ic_video_delete);
        videoshare = findViewById(R.id.ic_video_share);
        ShrExoPlay = findViewById(R.id.ShrExoPlay);
        timeBar = findViewById(R.id.exo_progress);
        initializePlayer();
        videodelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Delete();
            }
        });
        videoshare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Share();
            }
        });
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity, MyCreationActivity.class));
            }
        });
    }

    public void Delete() {
        new AlertDialog.Builder(this).setMessage("Are you sure you want to delete this file ?").setPositiveButton("delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                File file = new File(yourRealPath);
                if (file.exists()) {
                    file.delete();
                    try {
                        ContentResolver contentResolver = getContentResolver();
                        Uri uri = o;
                        StringBuilder sb = new StringBuilder();
                        sb.append("_data=\"");
                        sb.append(yourRealPath);
                        sb.append("\"");
                        contentResolver.delete(uri, sb.toString(), null);
                    } catch (Exception unused) {
                        unused.printStackTrace();
                    }
                }
                Intent intent = new Intent(ShareVideoActivity.this, MyCreationActivity.class);
                startActivity(intent);
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        }).setCancelable(r).show();
    }

    public void Share() {
        File file = new File(yourRealPath);

        Uri screenshotUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", file);
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/*");
        intent.putExtra("android.intent.extra.STREAM", screenshotUri);
        startActivity(Intent.createChooser(intent, "Share File"));
    }

    private void initializePlayer() {
        String str = "mIntentData";
        this.yourRealPath = ((IntentData) getIntent().getSerializableExtra(str)).getDataStr();
        this.onBack = ((IntentData) getIntent().getSerializableExtra(str)).isDataBoln();
        try {
            this.ecoPlayer = ExoPlayerFactory.newSimpleInstance((Context) this, new DefaultTrackSelector(new AdaptiveTrackSelection.Factory(new DefaultBandwidthMeter())));
            this.dataSpec = new DataSpec(Uri.parse(this.yourRealPath));
            final FileDataSource fileDataSource = new FileDataSource();
            try {
                fileDataSource.open(this.dataSpec);
            } catch (FileDataSource.FileDataSourceException e) {
                e.printStackTrace();
            }
            this.ecoPlayer.prepare(new LoopingMediaSource(new ExtractorMediaSource(fileDataSource.getUri(), new DataSource.Factory() {
                public DataSource createDataSource() {
                    return fileDataSource;
                }
            }, new DefaultExtractorsFactory(), null, null)));
            this.ecoPlayer.setPlayWhenReady(true);
            this.ShrExoPlay.setPlayer(this.ecoPlayer);

            this.ShrExoPlay.setVisibility(View.VISIBLE);
            this.ecoPlayer.setRepeatMode(Player.REPEAT_MODE_ALL);

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public void onBackPressed() {
        if (this.onBack) {
            finish();
            return;
        }
        finish();
    }

    public void onPause() {
        super.onPause();
        SimpleExoPlayer simpleExoPlayer = this.ecoPlayer;
        if (simpleExoPlayer != null) {
            simpleExoPlayer.release();
            this.ecoPlayer = null;
        }
    }

    public void onResume() {
        super.onResume();
        if (this.ecoPlayer == null) {
            initializePlayer();
        }
    }


}
