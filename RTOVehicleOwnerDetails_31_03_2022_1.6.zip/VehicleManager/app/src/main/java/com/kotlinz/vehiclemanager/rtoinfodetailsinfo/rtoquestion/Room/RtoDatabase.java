package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.Room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {QuestionModel.class},version = 1,exportSchema = false)
public abstract class RtoDatabase extends RoomDatabase {
    public abstract RtoQuestionDao rtoQuestionDao();
    public static RtoDatabase rtoDatabase;
    public static RtoDatabase getInstance(Context context)
    {
        if(rtoDatabase==null)
        {
            synchronized (RtoDatabase.class)
            {
                if(rtoDatabase==null){
                    rtoDatabase= Room.databaseBuilder(context,RtoDatabase.class,"RtoDatabase")
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return rtoDatabase;
    }
}
