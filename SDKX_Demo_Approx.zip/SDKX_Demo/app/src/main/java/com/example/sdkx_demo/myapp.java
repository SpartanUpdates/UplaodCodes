package com.example.sdkx_demo;

import android.app.Application;

import com.facebook.ads.AudienceNetworkAds;
import com.greedygame.core.AppConfig;
import com.greedygame.core.GreedyGameAds;

public class myapp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        AppConfig appConfig = new AppConfig.Builder(this)
                .withAppId("91679411")
                .enableFacebookAds(true)
                .build();
        GreedyGameAds.initWith(appConfig, null);
        AudienceNetworkAds.initialize(this);
    }
}
