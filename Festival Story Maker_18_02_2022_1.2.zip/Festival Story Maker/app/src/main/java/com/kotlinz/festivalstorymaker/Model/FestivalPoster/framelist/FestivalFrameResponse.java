package com.kotlinz.festivalstorymaker.Model.FestivalPoster.framelist;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;

public class FestivalFrameResponse {

	@SerializedName("success")
	private String success;

	@SerializedName("response")
	private FestivalFrameResponse festivalFrameResponse;

	@SerializedName("data")
	private ArrayList<FestivalFrameDataItem> data;

	@SerializedName("total_records")
	private String totalRecords;

	@SerializedName("total_pages")
	private String totalPages;

	@SerializedName("current_page_number")
	private String currentPageNumber;

	public String getSuccess(){
		return success;
	}

	public FestivalFrameResponse getResponse(){
		return festivalFrameResponse;
	}

	public ArrayList<FestivalFrameDataItem> getData(){
		return data;
	}

	public String getTotalRecords(){
		return totalRecords;
	}

	public String getTotalPages(){
		return totalPages;
	}

	public String getCurrentPageNumber(){
		return currentPageNumber;
	}
}