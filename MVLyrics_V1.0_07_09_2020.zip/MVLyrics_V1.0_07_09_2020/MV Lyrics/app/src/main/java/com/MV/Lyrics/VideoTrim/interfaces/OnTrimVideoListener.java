package com.MV.Lyrics.VideoTrim.interfaces;

import android.net.Uri;


public interface OnTrimVideoListener {

    void getResult(final Uri uri);

    void cancelAction();
}
