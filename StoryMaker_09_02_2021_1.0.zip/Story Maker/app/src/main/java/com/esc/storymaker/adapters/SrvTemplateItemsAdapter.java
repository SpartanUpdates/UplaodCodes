package com.esc.storymaker.adapters;

import android.content.res.AssetManager;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.esc.storymaker.MainActivity;
import com.esc.storymaker.R;
import com.esc.storymaker.interfaces.ItemClickListener;
import com.esc.storymaker.utils.AppUtil;
import java.util.ArrayList;
import java.util.Arrays;

public class SrvTemplateItemsAdapter extends RecyclerView.Adapter<SrvTemplateItemsAdapter.ItemViewHolder> {
    private String category;
    private boolean isFirstClick;
    private long mLastClickTime = System.currentTimeMillis();
    private MainActivity mainActivity;
    private ArrayList<String> thumbnails;

    public class ItemViewHolder extends ViewHolder implements OnClickListener {
        ItemClickListener itemClickListener;
        private CardView rootView;
        private ImageView thumbnail;
        private ImageView ivDownload;

        public ItemViewHolder(View view) {
            super(view);
            rootView = view.findViewById(R.id.rootView);
            thumbnail = view.findViewById(R.id.iv_thumbnail);
            ivDownload=view.findViewById(R.id.iv_download);
            view.setOnClickListener(this);

        }

        public void setItemClickListener(ItemClickListener itemClickListener) {
            this.itemClickListener = itemClickListener;
        }

        public void onClick(View view) {
            this.itemClickListener.onItemClick(view, getLayoutPosition());
        }
    }

    public SrvTemplateItemsAdapter(MainActivity mainActivity, String str) {
        this.mainActivity = mainActivity;
        this.category = str;
        try {
            AssetManager assets = mainActivity.getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Thumbnails/");
            stringBuilder.append(str);
            String[] list = assets.list(stringBuilder.toString());
            list.getClass();
            this.thumbnails = new ArrayList(Arrays.asList(list));
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.isFirstClick = true;
    }

    public ItemViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ItemViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_srv_templates, viewGroup, false));
    }

    public void onBindViewHolder(ItemViewHolder itemViewHolder, int i) {
//        double screenWidth = ScreenUtil.getScreenWidth(this.mainActivity);
//        Double.isNaN(screenWidth);
//        Double.isNaN(screenWidth);
//        int i2 = (int) (screenWidth / 3.8d);
//        double d = i2;
//        Double.isNaN(d);
//        Double.isNaN(d);
//        int i3 = (int) (d * 1.7777777777777777d);
//        itemViewHolder.rootView.getLayoutParams().width = i2;
//        itemViewHolder.rootView.getLayoutParams().height = i3;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("file:///android_asset/Thumbnails/");
        stringBuilder.append(this.category);
        stringBuilder.append("/");
        stringBuilder.append(this.thumbnails.get(i));
        Glide.with(this.mainActivity).load(Uri.parse(stringBuilder.toString())).into(itemViewHolder.thumbnail);
        itemViewHolder.setItemClickListener(new ItemClickListener() {
            public void onItemClick(View view, int i) {
                long currentTimeMillis = System.currentTimeMillis();
                if (SrvTemplateItemsAdapter.this.isFirstClick || currentTimeMillis - SrvTemplateItemsAdapter.this.mLastClickTime >= 3000) {
                    SrvTemplateItemsAdapter.this.mLastClickTime = currentTimeMillis;
                    SrvTemplateItemsAdapter.this.isFirstClick = false;
                    if (SrvTemplateItemsAdapter.this.mainActivity instanceof MainActivity) {
                        AppUtil.mainPermissionGranted(SrvTemplateItemsAdapter.this.mainActivity, "android.permission.WRITE_EXTERNAL_STORAGE", SrvTemplateItemsAdapter.this.category, SrvTemplateItemsAdapter.this.thumbnails.get(i).replace(".jpg", ""), null);
                    }
                }
            }
        });
    }

    public int getItemCount() {
        return this.thumbnails.size();
    }
}
