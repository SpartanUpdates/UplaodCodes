package com.esc.storymaker.help;

import android.app.Application;
import android.content.Context;
import androidx.multidex.MultiDex;

import com.esc.storymaker.OpenAds.AppOpenManager;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;


public class VideoApplication extends Application {
    private static VideoApplication instance;
    AppOpenManager appOpenManager;
    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(this);

    }

    public static synchronized VideoApplication getInstance() {
        VideoApplication videoApplication;
        synchronized (VideoApplication.class) {
            videoApplication = instance;
        }
        return videoApplication;
    }

    public void onCreate() {
        super.onCreate();
        instance = this;
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        appOpenManager = new AppOpenManager(this);
    }
}
