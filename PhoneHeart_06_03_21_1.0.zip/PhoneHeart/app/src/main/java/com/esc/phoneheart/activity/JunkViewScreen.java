package com.esc.phoneheart.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint.Cap;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import com.esc.phoneheart.R;
import com.esc.phoneheart.animations.CircleProgressView;
import com.esc.phoneheart.model.JunkData;
import com.esc.phoneheart.model.JunkData.ProgressUpdate;
import com.esc.phoneheart.pref.MySharedPreference;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.Util;

import java.util.ArrayList;
import java.util.Collections;

import androidx.appcompat.widget.Toolbar;

public class JunkViewScreen extends BaseActivity implements OnClickListener, ProgressUpdate {
    public PhoneCleaner app;
    public CircleProgressView circleProgressView;
    public CircleProgressView circleProgressViewSmall;
    public Context context;
    public int deviceHeight;
    public int deviceWidth;
    public boolean isPaused = false;
    public float l = 1.0f;
    public float m = 1.0f;
    public float n = 1.0f;
    public LinearLayout parent_layout;
    public boolean scanCompleted = false;
    public TextView tv_filecount;
    public TextView tv_status;

    private void init() {
        this.context = this;
        this.tv_status = (TextView) findViewById(R.id.tv_status);
        this.tv_filecount = (TextView) findViewById(R.id.tv_totsize);
        CircleProgressView circleProgressView = (CircleProgressView) findViewById(R.id.circleView);
        this.circleProgressView = circleProgressView;
        circleProgressView.setSpinnerStrokeCap(Cap.ROUND);
        this.circleProgressView.setBarStrokeCap(Cap.ROUND);
        this.circleProgressView.setRimColor(Color.parseColor("#00000000"));
        circleProgressView = this.circleProgressView;
        int[] iArr = new int[1];
        String str = "#ffffff";
        iArr[0] = Color.parseColor(str);
        circleProgressView.setBarColor(iArr);
        this.circleProgressView.setTextSize(0);
        this.circleProgressView.setTextColor(Color.parseColor(str));
        circleProgressView = (CircleProgressView) findViewById(R.id.circleViewsmall);
        this.circleProgressViewSmall = circleProgressView;
        circleProgressView.setSpinnerStrokeCap(Cap.ROUND);
        this.circleProgressViewSmall.setBarStrokeCap(Cap.ROUND);
        this.circleProgressViewSmall.setRimColor(Color.parseColor("#6a6a7b"));
        this.circleProgressViewSmall.setBarColor(Color.parseColor("#6a6a7b"));
        this.circleProgressViewSmall.setTextSize(0);
        this.circleProgressViewSmall.setTextColor(Color.parseColor("#1c58b1"));
        this.app = PhoneCleaner.getInstance();
        this.parent_layout = (LinearLayout) findViewById(R.id.parent_layout);
    }

    private void setAnimation() {
        int i = this.deviceHeight;
        TranslateAnimation translateAnimation = new TranslateAnimation((float) (((-i) * 20) / 100), 0.0f, (float) (((-i) * 30) / 100), 0.0f);
        translateAnimation.setDuration(2000);
        translateAnimation.setInterpolator(new DecelerateInterpolator());
        translateAnimation.setRepeatCount(-1);
        translateAnimation.setFillAfter(true);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            public void run() {
                JunkViewScreen junkViewScreen = JunkViewScreen.this;
                if (junkViewScreen.l <= 0.0f) {
                    junkViewScreen.l = 1.0f;
                }
                handler.postDelayed(this, 200);
                junkViewScreen = JunkViewScreen.this;
                junkViewScreen.l = (float) (((double) junkViewScreen.l) - 0.1d);
            }
        });
        new Handler().postDelayed(new Runnable() {
            public void run() {
                TranslateAnimation translateAnimation = new TranslateAnimation((float) (((-JunkViewScreen.this.deviceHeight) * 10) / 100), 0.0f, (float) (((-JunkViewScreen.this.deviceHeight) * 33) / 100), 0.0f);
                translateAnimation.setDuration(1500);
                translateAnimation.setInterpolator(new DecelerateInterpolator());
                translateAnimation.setRepeatCount(-1);
                translateAnimation.setFillAfter(true);
                final Handler handler = new Handler();
                handler.post(new Runnable() {
                    public void run() {
                        JunkViewScreen junkViewScreen = JunkViewScreen.this;
                        if (junkViewScreen.m <= 0.0f) {
                            junkViewScreen.m = 1.0f;
                        }
                        handler.postDelayed(this, 150);
                        junkViewScreen = JunkViewScreen.this;
                        junkViewScreen.m = (float) (((double) junkViewScreen.m) - 0.1d);
                    }
                });
            }
        }, 1000);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                TranslateAnimation translateAnimation = new TranslateAnimation((float) (((-JunkViewScreen.this.deviceHeight) * 15) / 100), 0.0f, (float) (((-JunkViewScreen.this.deviceHeight) * 20) / 100), 0.0f);
                translateAnimation.setDuration(1500);
                translateAnimation.setInterpolator(new DecelerateInterpolator());
                translateAnimation.setRepeatCount(-1);
                translateAnimation.setFillAfter(true);
                final Handler handler = new Handler();
                handler.post(new Runnable() {
                    public void run() {
                        JunkViewScreen junkViewScreen = JunkViewScreen.this;
                        if (junkViewScreen.n <= 0.0f) {
                            junkViewScreen.n = 1.0f;
                        }
                        handler.postDelayed(this, 150);
                        junkViewScreen = JunkViewScreen.this;
                        junkViewScreen.n = (float) (((double) junkViewScreen.n) - 0.1d);
                    }
                });
            }
        }, 500);
    }

    private void setDeviceDimensions() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.deviceHeight = displayMetrics.heightPixels;
        this.deviceWidth = displayMetrics.widthPixels;
    }

    private void setFontSize() {
        int lngIndex = MySharedPreference.getLngIndex(this);
    }

    private void setKeysList() {
        if (this.app.junkData != null) {
            String[] stringArray = getResources().getStringArray(R.array.junkmodulesaboven);
            if (this.app.junkData.isAlreadyBoosted(this)) {
                stringArray = getResources().getStringArray(R.array.junkmodulesabovenlessboost);
            }
            this.app.junkData.listDataHeader = new ArrayList();
            this.app.junkData.listDataHeader.clear();
            Collections.addAll(this.app.junkData.listDataHeader, stringArray);
        }
    }

    private void setLayoutParams() {
        setAnimation();
    }

    private void setParams() {
        View view = (View) this.circleProgressView.getParent();
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int i = this.deviceWidth;
        layoutParams.width = (i * 55) / 100;
        layoutParams.height = (i * 55) / 100;
        view.setLayoutParams(layoutParams);
    }

    private void switchScreen() {
        JunkData junkData = app.junkData;
        long j = junkData.totalsize;
        String str = "%s";
        String str2 = "DO_NOT_TRANSLATE";
        String str3 = GlobalData.REDIRECTNOTI;
        String str4 = "JUNK";
        String str5 = "TYPE";
        String str6 = "DATA";
        String str7 = "";
        String replace;
        Object[] objArr;
        StringBuilder stringBuilder;
        Intent intent;
        Intent intent2;
        StringBuilder stringBuilder2;
        if (j > 0) {
            long sizeAsPerOS = junkData.getSizeAsPerOS(j);
            if (sizeAsPerOS != 0) {
                Intent intent3 = new Intent(this, FinalScreen.class);
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append(str7);
                stringBuilder3.append(Util.convertBytes(sizeAsPerOS));
                intent3.putExtra(str6, stringBuilder3.toString());
                intent3.putExtra(str5, str4);
                intent3.putExtra(str3, true);
                finish();
                startActivity(intent3);
            } else if (this.app.junkData.totalemptyfoldersDeleted > 0) {
                replace = getResources().getString(R.string.junk_scan_btn_folder_txt).replace(str2, str);
                objArr = new Object[1];
                stringBuilder = new StringBuilder();
                stringBuilder.append(str7);
                stringBuilder.append(this.app.junkData.totalemptyfoldersDeleted);
                objArr[0] = stringBuilder.toString();
                replace = String.format(replace, objArr);
                intent = new Intent(this, FinalScreen.class);
                stringBuilder = new StringBuilder();
                stringBuilder.append(str7);
                stringBuilder.append(replace);
                intent.putExtra(str6, stringBuilder.toString());
                intent.putExtra(str5, str4);
                intent.putExtra(str3, true);
                finish();
                startActivity(intent);
            } else {
                intent2 = new Intent(this, FinalScreen.class);
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str7);
                stringBuilder2.append(getResources().getString(R.string.file_manage_category_no_item));
                intent2.putExtra(str6, stringBuilder2.toString());
                intent2.putExtra(str5, str4);
                intent2.putExtra(str3, true);
                finish();
                startActivity(intent2);
            }
        } else if (junkData.totalemptyfoldersDeleted > 0) {
            replace = getResources().getString(R.string.junk_scan_btn_folder_txt).replace(str2, str);
            objArr = new Object[1];
            stringBuilder = new StringBuilder();
            stringBuilder.append(str7);
            stringBuilder.append(this.app.junkData.totalemptyfoldersDeleted);
            objArr[0] = stringBuilder.toString();
            replace = String.format(replace, objArr);
            intent = new Intent(this, FinalScreen.class);
            stringBuilder = new StringBuilder();
            stringBuilder.append(str7);
            stringBuilder.append(replace);
            intent.putExtra(str6, stringBuilder.toString());
            intent.putExtra(str5, str4);
            intent.putExtra(str3, true);
            finish();
            startActivity(intent);
        } else {
            intent2 = new Intent(this, FinalScreen.class);
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str7);
            stringBuilder2.append(Util.convertBytes(this.app.junkData.totalsize));
            intent2.putExtra(str6, stringBuilder2.toString());
            intent2.putExtra(str5, str4);
            intent2.putExtra(str3, true);
            finish();
            startActivity(intent2);
        }
    }

    public void onBackPressed() {
        String str = "";
        Util.appendLogphonecleaner(str, " backpressed ", str);
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
        }
        dialog.setContentView(R.layout.new_dialog_junk_cancel);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.getWindow().setGravity(17);
        ((TextView) dialog.findViewById(R.id.dialog_msg)).setText(getString(R.string.dialouge_result_back));
        dialog.findViewById(R.id.ll_no).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.ll_yes).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
                String str = "";
                Util.appendLogphonecleaner(str, " backpressed pDialog finish", str);
                try {
                    JunkViewScreen.this.app.junkData.cancelCleaning();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        dialog.show();
    }

    public void onClick(View view) {
        this.app.junkData.deleteJunk(this, this, true);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_junk_reward_screen);
        init();
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle((CharSequence) "");
        }
        this.context = this;
        GlobalData.SETAPPLAnguage(this);
        setDeviceDimensions();
        setLayoutParams();
        setParams();
        setFontSize();
        setKeysList();
        AnimationUtils.loadAnimation(this, R.anim.seesaa).setRepeatCount(-1);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                try {
                    JunkViewScreen.this.app.junkData.deleteJunk(JunkViewScreen.this, JunkViewScreen.this, false);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 2000);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        onBackPressed();
        return super.onOptionsItemSelected(menuItem);
    }

    public void onPause() {
        super.onPause();
        this.isPaused = true;
    }

    public void onResume() {
        super.onResume();
        this.isPaused = false;
        if (this.scanCompleted) {
            switchScreen();
        }
    }

    public void onUpdate(long j, long j2, long j3, long j4) {
        String str = " ";
        String str2 = "";
        if (j == -1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str2);
            stringBuilder.append(str);
            JunkData junkData = this.app.junkData;
            stringBuilder.append(junkData.totselectedTodelete - junkData.totalDeletedCount);
            String stringBuilder2 = stringBuilder.toString();
            String str3 = "#ffffff";
            new SpannableString(stringBuilder2).setSpan(new ForegroundColorSpan(Color.parseColor(str3)), stringBuilder2.toLowerCase().indexOf(str2.toLowerCase()), stringBuilder2.toLowerCase().indexOf(str2.toLowerCase()) + 0, 0);
            JunkData junkData2 = this.app.junkData;
            long j5 = junkData2.totSelectedToDeleteSize - junkData2.totalDeletedSize;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(str);
            stringBuilder.append(Util.convertBytes(j5));
            stringBuilder2 = stringBuilder.toString();
            new SpannableString(stringBuilder2).setSpan(new ForegroundColorSpan(Color.parseColor(str3)), stringBuilder2.toLowerCase().indexOf(str.toLowerCase()), stringBuilder2.toLowerCase().indexOf(str.toLowerCase()) + 1, 0);
            junkData2 = this.app.junkData;
            j5 = junkData2.totalDeletedSize;
            long j6 = junkData2.totalsize;
            if (j5 > j6) {
                junkData2.totalDeletedSize = j6;
            }
            junkData2 = this.app.junkData;
            int i = junkData2.totalDeletedCount;
            int i2 = junkData2.totselectedTodelete;
            if (i > i2) {
                junkData2.totalDeletedCount = i2;
            }
        } else if (j == -2) {
            if (!this.isPaused) {
                switchScreen();
            }
            this.scanCompleted = true;
        } else {
            if (j == -3) {
                finish();
            }
            long j7 = this.app.junkData.totalsize;
            if (j2 > j7) {
                j2 = j7;
            }
            int i3 = this.app.junkData.totselectedTodelete;
            if (j3 > ((long) i3)) {
                j3 = (long) i3;
            }
            JunkData junkData3 = this.app.junkData;
            j7 = junkData3.getSizeAsPerOS(junkData3.totalsize);
            String str4 = "/";
            TextView textView;
            StringBuilder stringBuilder3;
            TextView textView2;
            StringBuilder stringBuilder4;
            if (j7 != 0) {
                textView = this.tv_filecount;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append(str2);
                stringBuilder3.append(Util.convertBytes(j2));
                stringBuilder3.append(str);
                textView.setText(stringBuilder3.toString());
                textView2 = this.tv_status;
                stringBuilder4 = new StringBuilder();
                stringBuilder4.append(str2);
                stringBuilder4.append(j3);
                stringBuilder4.append(str4);
                stringBuilder4.append(this.app.junkData.totselectedTodelete);
                textView2.setText(stringBuilder4.toString());
            } else {
                textView = this.tv_status;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append(str2);
                stringBuilder3.append(Util.convertBytes(j2));
                stringBuilder3.append(str);
                textView.setText(stringBuilder3.toString());
                textView2 = this.tv_filecount;
                stringBuilder4 = new StringBuilder();
                stringBuilder4.append(str2);
                stringBuilder4.append(j3);
                stringBuilder4.append(str4);
                stringBuilder4.append(this.app.junkData.totselectedTodelete);
                textView2.setText(stringBuilder4.toString());
            }
            this.circleProgressView.setValue((float) j);
        }
    }
}
