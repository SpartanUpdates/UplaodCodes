package com.natsuite.natrender;

import android.view.*;
import android.graphics.*;
import android.os.*;
import android.util.*;
import android.opengl.*;

public final class GLRenderContext extends HandlerThread
{
    private final Surface surface;
    private final SurfaceTexture surfaceTexture;
    private final EGLContext sharedContext;
    private final boolean recordHint;
    private int width;
    private int height;
    private volatile EGLContext eglContext;
    private EGLDisplay eglDisplay;
    private EGLSurface eglSurface;
    
    public GLRenderContext(final EGLContext sharedContext, final Surface surface, final boolean recordHint) {
        super("NatRender GLRenderContext");
        this.eglContext = EGL14.EGL_NO_CONTEXT;
        this.eglDisplay = EGL14.EGL_NO_DISPLAY;
        this.eglSurface = EGL14.EGL_NO_SURFACE;
        this.sharedContext = ((sharedContext != null) ? sharedContext : EGL14.EGL_NO_CONTEXT);
        this.surfaceTexture = null;
        this.surface = surface;
        this.recordHint = recordHint;
        final int n = 0;
        this.height = n;
        this.width = n;
    }
    
    public GLRenderContext(final EGLContext sharedContext, final int width, final int height) {
        super("NatRender GLRenderContext");
        this.eglContext = EGL14.EGL_NO_CONTEXT;
        this.eglDisplay = EGL14.EGL_NO_DISPLAY;
        this.eglSurface = EGL14.EGL_NO_SURFACE;
        this.sharedContext = ((sharedContext != null) ? sharedContext : EGL14.EGL_NO_CONTEXT);
        (this.surfaceTexture = new SurfaceTexture(0)).setDefaultBufferSize(width, height);
        this.surface = new Surface(this.surfaceTexture);
        this.width = width;
        this.height = height;
        this.recordHint = false;
    }
    
    public boolean quit() {
        return this.quitSafely();
    }
    
    public boolean quitSafely() {
        if (this.getLooper() == null) {
            return false;
        }
        new Handler(this.getLooper()).post((Runnable)new Runnable() {
            @Override
            public void run() {
                GLRenderContext.this.onLooperExiting();
            }
        });
        return super.quitSafely();
    }
    
    public EGLContext getContext() {
        return this.eglContext;
    }
    
    public Surface getSurface() {
        return (this.surfaceTexture == null) ? this.surface : null;
    }
    
    public boolean swapBuffers() {
        return EGL14.eglSwapBuffers(this.eglDisplay, this.eglSurface);
    }
    
    public void setPresentationTime(final long nsecs) {
        EGLExt.eglPresentationTimeANDROID(this.eglDisplay, this.eglSurface, nsecs);
    }
    
    public void resize(final int width, final int height) {
        if (this.width == width && this.height == height) {
            return;
        }
        Log.v("Unity", "NatRender: Resizing render context from " + this.width + "x" + this.height + " to " + width + "x" + height);
        GLES20.glViewport(0, 0, width, height);
        this.width = ((this.surfaceTexture == null) ? this.width : width);
        this.height = ((this.surfaceTexture == null) ? this.height : height);
    }
    
    public int width() {
        return this.width;
    }
    
    public int height() {
        return this.height;
    }
    
    protected void onLooperPrepared() {
        super.onLooperPrepared();
        this.eglDisplay = EGL14.eglGetDisplay(0);
        final int[] version = new int[2];
        EGL14.eglInitialize(this.eglDisplay, version, 0, version, 1);
        EGLConfig config = this.getConfig(3);
        if (config != null) {
            final EGLContext context = EGL14.eglCreateContext(this.eglDisplay, config, this.sharedContext, new int[] { 12440, 3, 12344 }, 0);
            if (EGL14.eglGetError() == 12288) {
                this.eglContext = context;
            }
        }
        if (this.eglContext == EGL14.EGL_NO_CONTEXT) {
            config = this.getConfig(2);
            this.eglContext = EGL14.eglCreateContext(this.eglDisplay, config, this.sharedContext, new int[] { 12440, 2, 12344 }, 0);
        }
        this.eglSurface = EGL14.eglCreateWindowSurface(this.eglDisplay, config, (Object)this.surface, new int[] { 12344 }, 0);
        EGL14.eglMakeCurrent(this.eglDisplay, this.eglSurface, this.eglSurface, this.eglContext);
        final int[] values = { 0 };
        EGL14.eglQueryContext(this.eglDisplay, this.eglContext, 12440, values, 0);
    }
    
    private void onLooperExiting() {
        if (this.eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(this.eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
            EGL14.eglDestroyContext(this.eglDisplay, this.eglContext);
            EGL14.eglDestroySurface(this.eglDisplay, this.eglSurface);
            EGL14.eglReleaseThread();
            EGL14.eglTerminate(this.eglDisplay);
        }
        this.eglDisplay = EGL14.EGL_NO_DISPLAY;
        this.eglContext = EGL14.EGL_NO_CONTEXT;
        this.eglSurface = EGL14.EGL_NO_SURFACE;
        if (this.surfaceTexture != null) {
            this.surface.release();
            this.surfaceTexture.release();
        }
    }
    
    private EGLConfig getConfig(final int version) {
        final int RECORD_BIT_KEY = this.recordHint ? 12610 : 12344;
        final int RECORD_BIT_VALUE = this.recordHint ? 1 : 12344;
        final int[] numConfigs = { 0 };
        final int[] attribList = { 12324, 8, 12323, 8, 12322, 8, 12321, 8, 12352, 0x4 | ((version >= 3) ? 64 : 0), RECORD_BIT_KEY, RECORD_BIT_VALUE, 12344 };
        final EGLConfig[] configs = { null };
        if (!EGL14.eglChooseConfig(this.eglDisplay, attribList, 0, configs, 0, configs.length, numConfigs, 0)) {
            Log.e("Unity", "NatRender Error: Failed to find suitable ES" + version + " EGLConfig: " + EGL14.eglGetError());
            return null;
        }
        return configs[0];
    }
}
