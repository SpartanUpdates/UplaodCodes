package com.kotlinz.festivalstorymaker.Model.PreArtbord;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class PreArtbordMain {

	@SerializedName("success")
	private String success;

	@SerializedName("response")
	private ArrayList<PreArtbordCategory> response;

	public String getSuccess(){
		return success;
	}

	public ArrayList<PreArtbordCategory> getResponse(){
		return response;
	}
}