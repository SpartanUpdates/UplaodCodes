package com.kotlinz.festivalstorymaker.Model;


import com.google.gson.annotations.SerializedName;


public class PosterCategoryData {

    @SerializedName("content_id")
    private String mContentId;
    @SerializedName("design_id")
    private String mDesignId;
    @SerializedName("frame_name")
    private String mFrameName;
    @SerializedName("id")
    private String mId;
    @SerializedName("image")
    private String mImage;
    @SerializedName("is_free")
    private String mIsFree;
    @SerializedName("is_image_count")
    private String mIsImageCount;
    @SerializedName("is_mask")
    private String mIsMask;
    @SerializedName("maincategory_id")
    private String mMaincategoryId;
    @SerializedName("mask_image")
    private String mMaskImage;
    @SerializedName("subcategory_id")
    private String mSubcategoryId;
    @SerializedName("thumb")
    private String mThumb;
    @SerializedName("type_id")
    private String mTypeId;

    public String getContentId() {
        return mContentId;
    }

    public void setContentId(String contentId) {
        mContentId = contentId;
    }

    public String getDesignId() {
        return mDesignId;
    }

    public void setDesignId(String designId) {
        mDesignId = designId;
    }

    public String getFrameName() {
        return mFrameName;
    }

    public void setFrameName(String frameName) {
        mFrameName = frameName;
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getImage() {
        return mImage;
    }

    public void setImage(String image) {
        mImage = image;
    }

    public String getIsFree() {
        return mIsFree;
    }

    public void setIsFree(String isFree) {
        mIsFree = isFree;
    }

    public String getIsImageCount() {
        return mIsImageCount;
    }

    public void setIsImageCount(String isImageCount) {
        mIsImageCount = isImageCount;
    }

    public String getIsMask() {
        return mIsMask;
    }

    public void setIsMask(String isMask) {
        mIsMask = isMask;
    }

    public String getMaincategoryId() {
        return mMaincategoryId;
    }

    public void setMaincategoryId(String maincategoryId) {
        mMaincategoryId = maincategoryId;
    }

    public String getMaskImage() {
        return mMaskImage;
    }

    public void setMaskImage(String maskImage) {
        mMaskImage = maskImage;
    }

    public String getSubcategoryId() {
        return mSubcategoryId;
    }

    public void setSubcategoryId(String subcategoryId) {
        mSubcategoryId = subcategoryId;
    }

    public String getThumb() {
        return mThumb;
    }

    public void setThumb(String thumb) {
        mThumb = thumb;
    }

    public String getTypeId() {
        return mTypeId;
    }

    public void setTypeId(String typeId) {
        mTypeId = typeId;
    }

}
