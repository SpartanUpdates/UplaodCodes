package com.unitedvideosapp.photovideomaker.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unitedvideosapp.photovideomaker.MyApplication;
import com.unitedvideosapp.photovideomaker.adapters.AlbumAdapterById;
import com.unitedvideosapp.photovideomaker.adapters.ImageByAlbumAdapter;
import com.unitedvideosapp.photovideomaker.adapters.OnItemClickListner;
import com.unitedvideosapp.photovideomaker.adapters.SelectedImageAdapter;
import com.unitedvideosapp.photovideomaker.kprogresshud.KProgressHUD;
import com.unitedvideosapp.photovideomaker.modelclass.ImageData;
import com.unitedvideosapp.photovideomaker.util.ActivityAnimUtil;
import com.unitedvideosapp.photovideomaker.util.Utils;
import com.unitedvideosapp.photovideomaker.view.EmptyRecyclerView;
import com.unitedvideosapp.photovideomaker.view.ExpandIconView;
import com.unitedvideosapp.photovideomaker.view.VerticalSlidingPanel;
import com.unitedvideosapp.photovideomaker.view.VerticalSlidingPanel.PanelSlideListener;
import com.uvvideos.photo.video.slideshow.maker.R;

import java.io.File;
import java.util.ArrayList;

import static com.unitedvideosapp.photovideomaker.view.CustomNativeAd.populateUnifiedNativeAdView;

public class PhotoselectActivity extends AppCompatActivity implements PanelSlideListener {
    Activity activity = PhotoselectActivity.this;
    private EmptyRecyclerView rvSelectedImage;
    public static final String EXTRA_FROM_PREVIEW = "extra_from_preview";
    public static boolean isForFirst = false;
    public static ArrayList<ImageData> tempImage = new ArrayList();
    private View parent;
    private RecyclerView rvAlbum;
    private SelectedImageAdapter selectedImageAdapter;
    public static TextView tvImageCount;
    private AlbumAdapterById albumAdapter;
    private ImageByAlbumAdapter albumImagesAdapter;
    private MyApplication application;
    private TextView btnClear;
    private ExpandIconView expandIcon;
    public boolean isFromCameraNotification = false;
    public boolean isFromPreview = false;
    boolean isPause = false;
    private VerticalSlidingPanel verticalSlidingPanel;
    TextView tvDone;
    public static LinearLayout fregmentLayouts;
    public static ArrayList<String> arrayListID;

    RelativeLayout rlToolbar;
    ImageView ivback, ivnext;

    private KProgressHUD hud;

    private InterstitialAd mInterstitialAd;
    int id;

    public void onPanelAnchored(View view) {
    }

    public void onPanelShown(View view) {
    }


    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.image_select_activity);
        this.application = MyApplication.getInstance();
        this.isFromPreview = getIntent().hasExtra("extra_from_preview");
        this.isFromCameraNotification = getIntent().hasExtra("isFromCameraNotification");
        bindView();
        init();
        loadNativeAd();
//        if (Utils.checkAds) {
        loadNextBtnInterstitial();
//        } else {
//            Utils.checkAds = true;
//        }
        arrayListID = new ArrayList<>();
        PutAnalyticsEvent();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "PhotoselectActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void loadNextBtnInterstitial() {
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admob_inter));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        final Intent intent = new Intent(PhotoselectActivity.this, Activity_ArrangeImage.class);
                        intent.putExtra("isFromCameraNotification", false);
                        intent.putExtra("KEY", "FromImageSelection");
                        startActivity(intent);
                        break;
                  /*  case 101:
                        Intent intent1 = new Intent(PhotoselectActivity.this, AddTitleActivity.class);
                        intent1.putExtra("ISFROMPREVIEW", isFromPreview);
                        ActivityAnimUtil.startActivitySafely(toolbar, intent1);
                        if (isFromPreview) {
                            finish();
                        }
                        break;*/
                }
                requestNewInterstitial();
            }
        });
    }

    private void requestNewInterstitial() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void init() {
        Utils.setFont(activity, R.id.toolbar_title);
        if (this.isFromCameraNotification) {
            AsyncTaskRunner runner = new AsyncTaskRunner();
            runner.execute("");
        }
        this.albumAdapter = new AlbumAdapterById(this);
        this.albumImagesAdapter = new ImageByAlbumAdapter(this);
        this.selectedImageAdapter = new SelectedImageAdapter(this);
        this.rvAlbum.setHasFixedSize(true);
        this.rvAlbum.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        this.rvAlbum.setItemAnimator(new DefaultItemAnimator());
        this.rvAlbum.setAdapter(this.albumAdapter);
        this.rvSelectedImage.setLayoutManager(new GridLayoutManager(getApplicationContext(), 4));
        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
        this.rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
        tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
        this.btnClear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                PhotoselectActivity.this.clearData();
            }
        });
        this.albumAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object o) {
                PhotoselectActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
        this.albumImagesAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                tvImageCount.setText(String.valueOf(PhotoselectActivity.this.application.getSelectedImages().size()));
                PhotoselectActivity.this.selectedImageAdapter.notifyDataSetChanged();
            }
        });
        this.selectedImageAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                tvImageCount.setText(String.valueOf(PhotoselectActivity.this.application.getSelectedImages().size()));
                PhotoselectActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
    }

    private class AsyncTaskRunner extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            application.getFolderList();
            return "";
        }

        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
        }


        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(PhotoselectActivity.this,
                    "ProgressDialog",
                    "Please Wait...");
        }


        @Override
        protected void onProgressUpdate(String... text) {

        }
    }

    private void bindView() {
        tvImageCount = findViewById(R.id.tvImageCount);
        this.tvDone = findViewById(R.id.tvDone);
        this.expandIcon = findViewById(R.id.settings_drag_arrow);
        this.rvAlbum = findViewById(R.id.rvAlbum);
        this.rvSelectedImage = findViewById(R.id.rvSelectedImagesList);
        this.verticalSlidingPanel = findViewById(R.id.overview_panel);
        this.verticalSlidingPanel.setEnableDragViewTouchEvents(true);
        this.verticalSlidingPanel.setDragView(findViewById(R.id.settings_pane_header));
        this.verticalSlidingPanel.setPanelSlideListener(this);
        this.parent = findViewById(R.id.default_home_screen_panel);
        rlToolbar = findViewById(R.id.rl_toolbar);
        ivback = findViewById(R.id.iv_back);
        ivnext = findViewById(R.id.iv_next);
        btnClear = findViewById(R.id.btnClear);
        tvDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (application.getSelectedImages().size() > 2) {
                    loadDone();
                    return;
                }
                Toast.makeText(PhotoselectActivity.this, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();
            }
        });
        fregmentLayouts = findViewById(R.id.fregmentspace);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        ivnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (application.getSelectedImages().size() > 2) {
                    loadDone();
                } else {
                    Toast.makeText(activity, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();
                }
            }
        });


        if (this.isFromPreview) {
            btnClear.setVisibility(View.GONE);
        }
    }

    public int getItemCount() {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).size();
    }

    public ImageData getItem(final int n) {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).get(n);
    }


    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 999 && i2 == -1) {
            this.application.selectedImages.remove(MyApplication.TEMP_POSITION);
            ImageData imgData = new ImageData();
            imgData.setImagePath(intent.getExtras().getString("ImgPath"));
            this.application.selectedImages.add(MyApplication.TEMP_POSITION, imgData);
            setupAdapter();
        }
    }

    private void setupAdapter() {
        this.selectedImageAdapter = new SelectedImageAdapter(this);
        this.rvSelectedImage.setLayoutManager(new GridLayoutManager(getApplicationContext(), 4));
        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
        this.rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
    }

    protected void onResume() {
        super.onResume();
        if (this.isPause) {
            this.isPause = false;
            tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
            this.albumImagesAdapter.notifyDataSetChanged();
            this.selectedImageAdapter.notifyDataSetChanged();
        }
    }

    protected void onPause() {
        super.onPause();
        this.isPause = true;
    }


    private boolean isEndFrameExist() {
        if (Fragment_EndFrame.lastsaveTempPath == null) {
            return false;
        }
        return new File(Fragment_EndFrame.lastsaveTempPath).exists();
    }


    private boolean loadDone() {
        final boolean isFromPreview = this.isFromPreview;
        int i = 0;
        if (isFromPreview) {
            if (this.isEndFrameExist()) {
                ImageData imageData = null;
                final ArrayList<ImageData> list = new ArrayList<ImageData>();
                list.addAll(this.application.selectedImages);
                this.application.selectedImages.clear();
                while (i < list.size()) {
                    if (list.get(i).imagePath.equals(Fragment_EndFrame.lastsaveTempPath)) {
                        imageData = list.get(i);
                    } else {
                        this.application.selectedImages.add(list.get(i));
                    }
                    ++i;
                }
                if (imageData != null) {
                    this.application.selectedImages.add(imageData);
                }
            }
            this.setResult(-1);
            this.finish();
            return true;
        } else {
            nextDialog();
        }
        return false;
    }

    private void nextDialog() {
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            try {
                hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        id = 100;
                        mInterstitialAd.show();
                    }
                }
            }, 2000);
        } else {
            final Intent intent = new Intent(PhotoselectActivity.this, Activity_ArrangeImage.class);
            intent.putExtra("isFromCameraNotification", false);
            intent.putExtra("KEY", "FromImageSelection");
            startActivity(intent);

        }
    }

    public void onBackPressed() {
        if (findViewById(R.id.fregmentspace).getVisibility() == View.VISIBLE) {
            findViewById(R.id.fregmentspace).setVisibility(View.GONE);
            return;
        }
        if (this.verticalSlidingPanel.isExpanded()) {
            this.verticalSlidingPanel.collapsePane();
        } else if (this.isFromCameraNotification) {
            startActivity(new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            this.application.clearAllSelection();
            finish();
        } else if (this.isFromPreview) {
            setResult(-1);
            finish();
        } else {
            this.application.videoImages.clear();
            this.application.clearAllSelection();
            startActivity(new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            finish();
            super.onBackPressed();
        }
    }

    public void onPanelSlide(final View view, final float n) {
        if (this.expandIcon != null) {
            this.expandIcon.setFraction(n, false);
        }
        if (n >= 0.005f) {
            if (this.parent != null && this.parent.getVisibility() != View.VISIBLE) {
                this.parent.setVisibility(View.VISIBLE);
            }
        } else if (this.parent != null && this.parent.getVisibility() == View.VISIBLE) {
            this.parent.setVisibility(View.GONE);
        }
    }

    public void onPanelCollapsed(View view) {
        if (this.parent != null) {
            this.parent.setVisibility(View.VISIBLE);
        }
        this.selectedImageAdapter.isExpanded = false;
        this.selectedImageAdapter.notifyDataSetChanged();
    }

    public void onPanelExpanded(View view) {
        if (this.parent != null) {
            this.parent.setVisibility(View.GONE);
        }
        this.selectedImageAdapter.isExpanded = true;
        this.selectedImageAdapter.notifyDataSetChanged();
    }

    private void clearData() {
        for (int size = this.application.getSelectedImages().size() - 1; size >= 0; size--) {
            this.application.removeSelectedImage(size);
        }
        tvImageCount.setText("0");
//        this.chbAllSelect.setChecked(false);
        this.selectedImageAdapter.notifyDataSetChanged();
        this.albumImagesAdapter.notifyDataSetChanged();
    }

    private UnifiedNativeAd nativeAd;

    private void loadNativeAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

    }
}
