package com.kotlinz.videoCollage.textmodule;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Camera;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.TypedValue;
import androidx.appcompat.widget.AppCompatTextView;

import com.kotlinz.videoCollage.scal.SubSamplingScaleImageView;

public class AutoResizeTextView extends AppCompatTextView {
    private static final int NO_LINE_LIMIT = -1;
    private final RectF _availableSpaceRect;
    private boolean _initialized;
    private int _maxLines;
    private float _maxTextSize;
    private float _minTextSize;
    private TextPaint _paint;
    private final SizeTester _sizeTester;
    private float _spacingAdd;
    private float _spacingMult;
    private int _widthLimit;
    boolean drawTextBol;
    Camera mCamera;
    Path path;
    private int startAngle;
    private int sweepAngle;
    Paint tPaint;

    private interface SizeTester {
        int onTestSize(int i, RectF rectF);
    }

    public boolean isValidWordWrap(char c, char c2) {
        return c == ' ' || c == '-';
    }

    public AutoResizeTextView(Context context) {
        this(context, null, 16842884);
    }

    public AutoResizeTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    public AutoResizeTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this._availableSpaceRect = new RectF();
        this._spacingMult = 1.0f;
        this._spacingAdd = 0.0f;
        this._initialized = false;
        this.sweepAngle = 1;
        this.startAngle = 1;
        this.drawTextBol = false;
        Paint paint = new Paint(1);
        this.tPaint = paint;
        paint.setStyle(Style.FILL_AND_STROKE);
        this.tPaint.setColor(-16777216);
        this.tPaint.setTextSize(55.0f);
        this._minTextSize = TypedValue.applyDimension(2, 12.0f, getResources().getDisplayMetrics());
        this._maxTextSize = getTextSize();
        this._paint = new TextPaint(getPaint());
        if (this._maxLines == 0) {
            this._maxLines = -1;
        }
        this._sizeTester = new SizeTester() {
            final RectF textRect = new RectF();

            public int onTestSize(int i, RectF rectF) {
                String charSequence;
                AutoResizeTextView.this._paint.setTextSize((float) i);
                TransformationMethod transformationMethod = AutoResizeTextView.this.getTransformationMethod();
                if (transformationMethod != null) {
                    charSequence = transformationMethod.getTransformation(AutoResizeTextView.this.getText(), AutoResizeTextView.this).toString();
                } else {
                    charSequence = AutoResizeTextView.this.getText().toString();
                }
                if (AutoResizeTextView.this.getMaxLines() == 1) {
                    this.textRect.bottom = AutoResizeTextView.this._paint.getFontSpacing();
                    this.textRect.right = AutoResizeTextView.this._paint.measureText(charSequence);
                } else {
                    StaticLayout staticLayout = new StaticLayout(charSequence, AutoResizeTextView.this._paint, AutoResizeTextView.this._widthLimit, Alignment.ALIGN_CENTER, AutoResizeTextView.this._spacingMult, AutoResizeTextView.this._spacingAdd, true);
                    if (AutoResizeTextView.this.getMaxLines() != -1 && staticLayout.getLineCount() > AutoResizeTextView.this.getMaxLines()) {
                        return 1;
                    }
                    this.textRect.bottom = (float) staticLayout.getHeight();
                    int lineCount = staticLayout.getLineCount();
                    int i2 = -1;
                    for (int i3 = 0; i3 < lineCount; i3++) {
                        int lineEnd = staticLayout.getLineEnd(i3);
                        if (i3 < lineCount - 1 && lineEnd > 0 && !AutoResizeTextView.this.isValidWordWrap(charSequence.charAt(lineEnd - 1), charSequence.charAt(lineEnd))) {
                            return 1;
                        }
                        if (((float) i2) < staticLayout.getLineRight(i3) - staticLayout.getLineLeft(i3)) {
                            i2 = ((int) staticLayout.getLineRight(i3)) - ((int) staticLayout.getLineLeft(i3));
                        }
                    }
                    this.textRect.right = (float) i2;
                }
                this.textRect.offsetTo(0.0f, 0.0f);
                return rectF.contains(this.textRect) ? -1 : 1;
            }
        };
        this._initialized = true;
    }

    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        adjustTextSize();
    }

    public void setTypeface(Typeface typeface) {
        super.setTypeface(typeface);
        adjustTextSize();
    }

    public void setTextSize(float f) {
        this._maxTextSize = f;
        adjustTextSize();
    }

    public void setMaxLines(int i) {
        super.setMaxLines(i);
        this._maxLines = i;
        adjustTextSize();
    }

    public int getMaxLines() {
        return this._maxLines;
    }

    public void setSingleLine() {
        super.setSingleLine();
        this._maxLines = 1;
        adjustTextSize();
    }

    public void setSingleLine(boolean z) {
        super.setSingleLine(z);
        if (z) {
            this._maxLines = 1;
        } else {
            this._maxLines = -1;
        }
        adjustTextSize();
    }

    public void setLines(int i) {
        super.setLines(i);
        this._maxLines = i;
        adjustTextSize();
    }

    public void setTextSize(int i, float f) {
        Resources system;
        Context context = getContext();
        if (context == null) {
            system = Resources.getSystem();
        } else {
            system = context.getResources();
        }
        this._maxTextSize = TypedValue.applyDimension(i, f, system.getDisplayMetrics());
        adjustTextSize();
    }

    public void setLineSpacing(float f, float f2) {
        super.setLineSpacing(f, f2);
        this._spacingMult = f2;
        this._spacingAdd = f;
    }

    public void setMinTextSize(float f) {
        this._minTextSize = f;
        adjustTextSize();
    }

    private void adjustTextSize() {
        if (this._initialized) {
            int i = (int) this._minTextSize;
            int measuredHeight = (getMeasuredHeight() - getCompoundPaddingBottom()) - getCompoundPaddingTop();
            int measuredWidth = (getMeasuredWidth() - getCompoundPaddingLeft()) - getCompoundPaddingRight();
            this._widthLimit = measuredWidth;
            if (measuredWidth > 0) {
                this._paint = new TextPaint(getPaint());
                this._availableSpaceRect.right = (float) this._widthLimit;
                this._availableSpaceRect.bottom = (float) measuredHeight;
                superSetTextSize(i);
            }
        }
    }

    private void superSetTextSize(int i) {
        super.setTextSize(0, (float) binarySearch(i, (int) this._maxTextSize, this._sizeTester, this._availableSpaceRect));
    }

    private int binarySearch(int i, int i2, SizeTester sizeTester, RectF rectF) {
        int i3 = i2 - 1;
        i2 = i;
        while (i <= i3) {
            i2 = (i + i3) >>> 1;
            int onTestSize = sizeTester.onTestSize(i2, rectF);
            if (onTestSize < 0) {
                int i4 = i2 + 1;
                i2 = i;
                i = i4;
            } else if (onTestSize <= 0) {
                return i2;
            } else {
                i2--;
                i3 = i2;
            }
        }
        return i2;
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        adjustTextSize();
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3 || i2 != i4) {
            adjustTextSize();
        }
    }

    public static int dpToPx(Context context, int i) {
        float f = (float) i;
        context.getResources();
        return (int) (f * Resources.getSystem().getDisplayMetrics().density);
    }

    private void drawTextView(Canvas canvas) {
        this.sweepAngle = SubSamplingScaleImageView.ORIENTATION_180;
        this.startAngle = 270 - (SubSamplingScaleImageView.ORIENTATION_180 / 2);
        this.path = new Path();
        Paint paint = new Paint();
        paint.setColor(-16711936);
        String charSequence = getText().toString();
        getPaint().measureText(charSequence);
        RectF rectF = new RectF(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight());
        this.path.addArc(rectF, (float) this.startAngle, (float) this.sweepAngle);
        canvas.drawOval(rectF, paint);
        canvas.drawTextOnPath(charSequence, this.path, 0.0f, 0.0f, this.tPaint);
    }

    public void setCurvingAngle(int i, float f, float f2, String str) {
        this.drawTextBol = true;
        invalidate();
    }
}
