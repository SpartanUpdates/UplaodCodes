package flash.light.shine.com.billing;

import android.content.Context;
import io.branch.referral.util.BranchEvent;

public class NBranch {
    public static void Event(Context context, String str) {
        new BranchEvent(str).addCustomDataProperty("type", str).logEvent(context);
    }
}
