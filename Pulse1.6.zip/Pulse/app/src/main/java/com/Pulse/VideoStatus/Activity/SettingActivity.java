//package com.Pulse.VideoStatus.Activity;
//
//import android.app.Activity;
//import android.content.ActivityNotFoundException;
//import android.content.Intent;
//import android.content.pm.PackageInfo;
//import android.content.pm.PackageManager;
//import android.net.Uri;
//import android.os.Build;
//import android.os.Bundle;
//import android.support.v7.app.AlertDialog;
//import android.support.v7.app.AppCompatActivity;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.RatingBar;
//import android.widget.TextView;
//
//import com.Pulse.VideoStatus.R;
//import com.Pulse.VideoStatus.UnityPlayerActivity;
//import com.google.android.gms.ads.AdRequest;
//import com.google.android.gms.ads.AdView;
//
//public class SettingActivity extends AppCompatActivity implements View.OnClickListener {
//
//    Activity activity = SettingActivity.this;
//    TextView tvAppVersion;
//    AdRequest adRequest;
//    AdView adView;
//
//    //    private LinearLayout adContainer;
////    private AdView adView;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_setting);
//        BindView();
//        loadAd();
//    }
//
//    private void BindView() {
//        tvAppVersion = findViewById(R.id.tvAppVer);
//        findViewById(R.id.llFeedback).setOnClickListener(this);
//        findViewById(R.id.llRateUs).setOnClickListener(this);
//        findViewById(R.id.llInviteFriends).setOnClickListener(this);
//        findViewById(R.id.llPrivacy).setOnClickListener(this);
//        PackageManager manager = activity.getPackageManager();
//        PackageInfo info = null;
//        try {
//            info = manager.getPackageInfo(activity.getPackageName(), 0);
//        } catch (PackageManager.NameNotFoundException e) {
//            e.printStackTrace();
//        }
//        if (info != null) {
//            tvAppVersion.setText(info.versionName);
//        }
//    }
//
//    private void loadAd() {
//        adView = findViewById(R.id.adView);
//        adRequest = new AdRequest.Builder().build();
//        adView.loadAd(adRequest);
//
////        adContainer = findViewById(R.id.templateContainer);
////        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
////        adContainer.addView(adView);
////        adView.loadAd();
//    }
//
//    @Override
//    public void onClick(View view) {
//        switch (view.getId()) {
//            case R.id.llFeedback:
//                Intent intent2 = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", getResources().getString(R.string.feedback_email), null));
//                intent2.putExtra("android.intent.extra.SUBJECT", "Feedback");
//                intent2.putExtra("android.intent.extra.TEXT", "Write your feedback here");
//                startActivity(Intent.createChooser(intent2, "Send email..."));
//                return;
//            case R.id.llInviteFriends:
//                ShareAPP();
//                return;
//            case R.id.llPrivacy:
//                Intent intent1 = new Intent("android.intent.action.VIEW");
//                intent1.setData(Uri.parse(getResources().getString(R.string.privacy_link)));
//                return;
//            case R.id.llRateUs:
//                RateAppDialog();
//                return;
//            default:
//                break;
//        }
//    }
//
//    private void ShareAPP() {
//        try {
//            Intent shareIntent = new Intent(Intent.ACTION_SEND);
//            shareIntent.setType("text/plain");
//            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Pulse");
//            String shareMessage = "\nGet free Pulse at here:";
//            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
//            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
//            startActivity(Intent.createChooser(shareIntent, "choose one"));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    private void RateApp() {
//        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
//        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
//                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
//                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
//        }
//        try {
//            startActivity(goToMarket);
//        } catch (ActivityNotFoundException e) {
//            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
//        }
//    }
//
//    private void RateAppDialog() {
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity, R.style.AppImageAlertDialog);
//        ViewGroup viewGroup = findViewById(android.R.id.content);
//        final View dialogView = LayoutInflater.from(activity).inflate(R.layout.rate_us_dialog, viewGroup, false);
//        builder.setView(dialogView);
//        final AlertDialog alertDialog = builder.create();
//        alertDialog.show();
//        RatingBar ratingBar = dialogView.findViewById(R.id.rateBar);
//        dialogView.findViewById(R.id.ivCloseRate).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                alertDialog.dismiss();
//            }
//        });
//        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
//            @Override
//            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
//                if (fromUser) {
//                    if (rating < 5.0f) {
////                        CloseApp();
//                        alertDialog.dismiss();
//                    } else {
//                        alertDialog.dismiss();
//                        RateApp();
//                        ratingBar.setRating(0.0f);
//                    }
//                }
//            }
//        });
//    }
//
//    @Override
//    protected void onDestroy() {
//        this.adView.removeView(this.adView);
//        AdView adView = this.adView;
//        if (adView != null) {
//            adView.destroy();
//            this.adView = null;
//        }
//        super.onDestroy();
//    }
//
//    private void CloseApp() {
//        finishAffinity();
//        if (UnityPlayerActivity.mUnityPlayer != null) {
//            UnityPlayerActivity.mUnityPlayer.quit();
//        }
//    }
//
//    public void onBackPressed() {
//        super.onBackPressed();
//        startActivity(new Intent(this, HomeActivity.class));
//        finish();
//    }
//
//}
