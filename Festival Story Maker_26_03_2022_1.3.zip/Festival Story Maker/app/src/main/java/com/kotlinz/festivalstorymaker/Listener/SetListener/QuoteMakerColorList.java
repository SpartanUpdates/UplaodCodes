package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;

public class QuoteMakerColorList implements com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter.a {
    public final QuoteMakerDetailActivity e;

    public QuoteMakerColorList(QuoteMakerDetailActivity quoteMakerDetailActivity) {
        this.e = quoteMakerDetailActivity;
    }

    public final void D(int i) {
        this.e.D(i);
    }
}
