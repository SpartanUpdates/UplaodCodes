package com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.model.VehicleExpense;

import java.util.ArrayList;

public class ExpenseSqlite extends SQLiteOpenHelper {

    SQLiteDatabase database;

    public ExpenseSqlite(final Context context) {
        super(context, "Bill_reminder.db", null, 1);
        this.database = this.getWritableDatabase();
    }

    private VehicleExpense add(final Cursor cursor) {
        final VehicleExpense vehicleExpenseModel = new VehicleExpense("catname", "payee", "amount", "notes", "duedate", 1);
        vehicleExpenseModel.setBid((int) cursor.getLong(cursor.getColumnIndexOrThrow("bid")));
        vehicleExpenseModel.setCatname(cursor.getString(cursor.getColumnIndexOrThrow("catname")));
        vehicleExpenseModel.setPayee(cursor.getString(cursor.getColumnIndexOrThrow("payee")));
        vehicleExpenseModel.setAmount(cursor.getString(cursor.getColumnIndexOrThrow("amount")));
        vehicleExpenseModel.setNotes(cursor.getString(cursor.getColumnIndexOrThrow("notes")));
        vehicleExpenseModel.setDuedate(cursor.getString(cursor.getColumnIndexOrThrow("duedate")));
        vehicleExpenseModel.setCaticon(cursor.getInt(cursor.getColumnIndexOrThrow("caticon")));
        return vehicleExpenseModel;
    }

    private VehicleExpense set(final Cursor cursor) {
        final VehicleExpense vehicleExpenseModel = new VehicleExpense("catname", "payee", "amount", "notes", "duedate", 1);
        vehicleExpenseModel.setBid((int) cursor.getLong(cursor.getColumnIndexOrThrow("bid")));
        vehicleExpenseModel.setCatname(cursor.getString(cursor.getColumnIndexOrThrow("catname")));
        vehicleExpenseModel.setPayee(cursor.getString(cursor.getColumnIndexOrThrow("payee")));
        vehicleExpenseModel.setAmount(cursor.getString(cursor.getColumnIndexOrThrow("amount")));
        vehicleExpenseModel.setNotes(cursor.getString(cursor.getColumnIndexOrThrow("notes")));
        vehicleExpenseModel.setDuedate(cursor.getString(cursor.getColumnIndexOrThrow("duedate")));
        vehicleExpenseModel.setCaticon(cursor.getInt(cursor.getColumnIndexOrThrow("caticon")));
        vehicleExpenseModel.setTotalAmount(this.expensetotalModels(cursor.getString(cursor.getColumnIndexOrThrow("duedate"))));
        vehicleExpenseModel.setExpenseModels(this.expenseModels(cursor.getString(cursor.getColumnIndexOrThrow("duedate"))));
        return vehicleExpenseModel;
    }

    public int dlt(final int n) {
        return this.database.delete("bill", "bid = ?", new String[]{String.valueOf(n)});
    }

    ArrayList<VehicleExpense> expenseModels(final String s) {
        final Cursor query = this.database.query("bill", new String[]{"bid", "catname", "payee", "amount", "notes", "duedate", "caticon"}, "duedate=?", new String[]{s}, null, null, null);
        final ArrayList<VehicleExpense> list = new ArrayList<VehicleExpense>();
        if (query.moveToFirst()) {
            do {
                if (query.getString(query.getColumnIndexOrThrow("duedate")).equals(s)) {
                    list.add(this.add(query));
                }
            } while (query.moveToNext());
        }
        return list;
    }

    String expensetotalModels(final String s) {
        final Cursor query = this.database.query("bill", new String[]{"bid", "catname", "payee", "amount", "notes", "duedate", "caticon"}, "duedate=?", new String[]{s}, null, null, null);
        final boolean moveToFirst = query.moveToFirst();
        float n = 0.0f;
        float n2 = 0.0f;
        if (moveToFirst) {
            do {
                n = n2;
                if (query.getString(query.getColumnIndexOrThrow("duedate")).equals(s)) {
                    n = n2 + Float.parseFloat(query.getString(query.getColumnIndexOrThrow("amount")));
                }
                n2 = n;
            } while (query.moveToNext());
        }
        return String.valueOf(n);
    }

    public long insrt(final VehicleExpense vehicleExpenseModel) {
        final ContentValues contentValues = new ContentValues();
        contentValues.put("catname", vehicleExpenseModel.getCatname());
        contentValues.put("payee", vehicleExpenseModel.getPayee());
        contentValues.put("amount", vehicleExpenseModel.getAmount());
        contentValues.put("notes", vehicleExpenseModel.getNotes());
        contentValues.put("duedate", vehicleExpenseModel.getDuedate());
        contentValues.put("caticon", Integer.valueOf(vehicleExpenseModel.getCaticon()));
        return this.database.insert("bill", null, contentValues);
    }

    public ArrayList<VehicleExpense> list() {
        final Cursor query = this.database.query("bill", new String[]{"bid", "catname", "payee", "amount", "notes", "duedate", "caticon"}, null, null, "duedate", null, null);
        final ArrayList<VehicleExpense> list = new ArrayList<VehicleExpense>();
        if (query.moveToFirst()) {
            do {
                list.add(this.set(query));
            } while (query.moveToNext());
        }
        return list;
    }

    public void onCreate(final SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE bill (bid INTEGER PRIMARY KEY autoincrement, catname TEXT, payee TEXT, amount TEXT, notes TEXT, duedate TEXT, caticon INTEGER )");
        sqLiteDatabase.execSQL("CREATE TABLE mileage (id INTEGER PRIMARY KEY autoincrement, lreserve INTEGER, creserve INTEGER, price INTEGER, fuel INTEGER, date TEXT, km TEXT, inr TEXT )");
    }

    public void onUpgrade(final SQLiteDatabase sqLiteDatabase, final int n, final int n2) {
        this.onCreate(sqLiteDatabase);
    }

    public String rawQuery() {
        final SQLiteDatabase database = this.database;
        String string = null;
        final Cursor rawQuery = database.rawQuery("SELECT SUM(amount) AS total FROM bill", null);
        if (rawQuery.moveToFirst()) {
            string = rawQuery.getString(rawQuery.getColumnIndex("total"));
        }
        rawQuery.close();
        return string;
    }

    public int updt(final int n, final VehicleExpense vehicleExpenseModel) {
        final ContentValues contentValues = new ContentValues();
        contentValues.put("catname", vehicleExpenseModel.getCatname());
        contentValues.put("payee", vehicleExpenseModel.getPayee());
        contentValues.put("amount", vehicleExpenseModel.getAmount());
        contentValues.put("notes", vehicleExpenseModel.getNotes());
        contentValues.put("duedate", vehicleExpenseModel.getDuedate());
        contentValues.put("caticon", Integer.valueOf(vehicleExpenseModel.getCaticon()));
        return this.database.update("bill", contentValues, "bid = ?", new String[]{String.valueOf(n)});
    }
}
