package com.esc.phoneheart.utility;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.Environment;
import com.esc.phoneheart.R;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

public class MountPoints {

    public static ArrayList<String> returnMountPOints(Context context) {
        String deviceName = GlobalData.getDeviceName();
        ArrayList<String> arrayList = new ArrayList<>();
        int i = VERSION.SDK_INT;
        if (i >= 23) {
            Iterator it = StorageHelper.getStorages(true).iterator();
            while (it.hasNext()) {
                arrayList.add(((File) it.next()).toString());
            }
            return arrayList;
        } else if (i < 21 && !deviceName.contains("Xiaomi") && !deviceName.contains("HUAWEI")) {
            return GlobalData.mountPoints(context);
        } else {
            Boolean valueOf = Boolean.valueOf(Environment.getExternalStorageState().equals("mounted"));
            String str = System.getenv("PRIMARY_STORAGE");
            String str2 = System.getenv("SECONDARY_STORAGE");
            if (str2 == null || str2.length() == 0) {
                str2 = System.getenv("EXTERNAL_SDCARD_STORAGE");
            }
            if (str == null || str.length() == 0) {
                str = System.getenv("EXTERNAL_STORAGE");
            }
            if (str == null && str2 == null) {
                str2 = Environment.getExternalStorageDirectory().toString();
            }
            if (str2 == null) {
                str2 = System.getenv("PHONE_STORAGE");
            }
            arrayList.add(str);
            arrayList.add(str2);
            if (!valueOf.booleanValue() || str2 != null) {
                return arrayList;
            }
            arrayList.clear();
            Iterator it2 = StorageHelper.getStorages(true).iterator();
            ArrayList arrayList2 = new ArrayList();
            while (it2.hasNext()) {
                String file = ((File) it2.next()).toString();
                File file2 = new File(file);
                if (arrayList2.size() <= 0) {
                    arrayList2.add(Long.valueOf(DiskUtils.getTotalMemorySize(file2)));
                    arrayList.add(file);
                } else if (!arrayList2.contains(Long.valueOf(DiskUtils.getTotalMemorySize(file2)))) {
                    arrayList2.add(Long.valueOf(DiskUtils.getTotalMemorySize(file2)));
                    arrayList.add(file);
                }
            }
            Collections.reverse(arrayList);
            return arrayList;
        }
    }
}
