package com.esc.phoneheart.advancedclean;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings.Secure;
import android.provider.Settings.SettingNotFoundException;
import android.text.TextUtils.SimpleStringSplitter;
import android.util.Log;

import com.esc.phoneheart.advancedclean.BaseActivity.IPActivityListener;

public class StepCheckAccessPermission extends Step implements IPActivityListener {
    public static final String TAG = "StepCheckAccessPermis";
    public BaseActivity mActivity;

    public StepCheckAccessPermission(BaseActivity baseActivity) {
        this.mActivity = baseActivity;
    }

    private void afterSetting() {
        boolean isAccessibilitySettingsOn = isAccessibilitySettingsOn(this.mActivity);
        String str = TAG;
        if (isAccessibilitySettingsOn) {
            Log.i(str, "we grant to accessbility check next");
            doNext();
            return;
        }
        Log.i(str, "permission not grant yet,we can't step forward,finish it.");
        this.mActivity.finish();
    }

    private boolean isAccessibilitySettingsOn(Context context) {
        int i;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(context.getPackageName());
        stringBuilder.append("/");
        stringBuilder.append(CleanMasterAccessbilityService.class.getCanonicalName());
        String stringBuilder2 = stringBuilder.toString();
        try {
            i = Secure.getInt(context.getApplicationContext().getContentResolver(), "accessibility_enabled");
        } catch (SettingNotFoundException e) {
            e.printStackTrace();
            i = 0;
        }
        SimpleStringSplitter simpleStringSplitter = new SimpleStringSplitter(':');
        if (i == 1) {
            String string = Secure.getString(context.getApplicationContext().getContentResolver(), "enabled_accessibility_services");
            if (string != null) {
                simpleStringSplitter.setString(string);
                while (simpleStringSplitter.hasNext()) {
                    if (simpleStringSplitter.next().equalsIgnoreCase(stringBuilder2)) {
                        Log.v(TAG, "Our accessibility is switched on!");
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void doAction() {
        if (isAccessibilitySettingsOn(this.mActivity)) {
            doNext();
            return;
        }
        Log.i(TAG, "we have not permission yet,guide user to grant it.");
        this.mActivity.addResultListener(this);
        this.mActivity.startActivityForResult(new Intent("android.settings.ACCESSIBILITY_SETTINGS"), 1002, ActivityOptions.makeCustomAnimation(this.mActivity, 0, 0).toBundle());
    }

    public boolean onActivityResult(int i, int i2, Intent intent) {
        if (i != 1002) {
            return false;
        }
        Log.i(TAG, "onActivityResult");
        afterSetting();
        return true;
    }

    public void onRestart() {
        afterSetting();
    }
}
