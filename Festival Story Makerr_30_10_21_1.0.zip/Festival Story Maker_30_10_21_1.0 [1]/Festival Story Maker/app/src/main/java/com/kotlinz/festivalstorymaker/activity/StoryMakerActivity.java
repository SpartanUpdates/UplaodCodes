package com.kotlinz.festivalstorymaker.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.Story.StoryCategoryAdapter;
import com.kotlinz.festivalstorymaker.Adapter.Story.StorySubCategoryAdapter;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Model.StoryMaker.CategoryWiseData.StoryCategoryWiseData;
import com.kotlinz.festivalstorymaker.Model.StoryMaker.CategoryWiseData.StoryCategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.StoryMaker.StoryMainCategory;
import com.kotlinz.festivalstorymaker.Model.StoryMaker.StoryMakerResponse;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StoryMakerActivity extends AppCompatActivity {

    Activity activity = StoryMakerActivity.this;

    @BindView(R.id.tv_title)
    TextView tvtitle;

    @BindView(R.id.rv_story_category)
    RecyclerView rvStoryCategory;

    @BindView(R.id.rv_story_subcategory)
    public RecyclerView rvStorySubCategory;

    @BindView(R.id.rl_main_data)
    public RelativeLayout rlMainData;

    @BindView(R.id.llRetry)
    public LinearLayout llRetry;

    private ProgressDialog progressDialog;
    APIInterface apiInterface;


    ArrayList<StoryMainCategory> storyCategoriesList;
    StoryCategoryAdapter storyCategoryAdapter;

    public ArrayList<StoryCategoryWiseData> storySubCategoryList;
    public StorySubCategoryAdapter storySubCategoryAdapter;
    public RecyclerView.LayoutManager mLayoutManager;

    private ArrayList<Image> images = new ArrayList<>();
    ArrayList<String> arrayList = new ArrayList<String>();

    private int ModuleId;

    public String IsFrom;

    Gson gson = new Gson();

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_maker);
        ButterKnife.bind(activity);
        IsFrom = getIntent().getStringExtra("IsForm");
        storyCategoriesList = new ArrayList<>();
        storySubCategoryList = new ArrayList<>();
        ModuleId = getIntent().getIntExtra("moduleid", 0);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        PutAnalyticsEvent();
        InitProgressDialog();
        BannerAds();
        if (IsFrom.equals("Story Maker")) {
            tvtitle.setText("Story Maker");
            SetStoryMainCategoryData();
        } else if (IsFrom.equals("PreDesign ArtBord")) {
            tvtitle.setText("PreDesign ArtBord");
            SetStoryMainCategoryData();
        } else if (IsFrom.equals("Thematic Template")) {
            tvtitle.setText("Thematic Template");
            SetStoryMainCategoryData();
        } else if (IsFrom.equals("Wish Maker")) {
            tvtitle.setText("Wish Maker");
            SetStoryMainCategoryData();
        } else if (IsFrom.equals("Offer Poster")) {
            tvtitle.setText("Offer Poster");
            SetStoryMainCategoryData();
        } else if (IsFrom.equals("Festival")) {
            tvtitle.setText("Festival");
            SetStoryMainCategoryData();
        } else {
            Toast.makeText(activity, "No Module Found ", Toast.LENGTH_SHORT).show();
        }

    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "StoryMakerActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @OnClick(R.id.llRetry)
    public void RetryData() {
        if (Utils.checkConnectivity(activity, false)) {
            rlMainData.setVisibility(View.VISIBLE);
            llRetry.setVisibility(View.GONE);
            GetStoryCategory(ModuleId);
        } else {
            Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
        }
    }


    private void SetStoryMainCategoryData() {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMaker + IsFrom).equalsIgnoreCase("")) {
                GetStoryCategory(ModuleId);

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.StoryMakerResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetStoryCategory(ModuleId);

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMaker + IsFrom).equalsIgnoreCase("")) {

                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMaker + IsFrom));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMaker + IsFrom).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMaker + IsFrom));
            }
        }
    }

    private void GetStoryCategory(int ModuleId) {
        progressDialog.show();
        Call<StoryMakerResponse> call = apiInterface.getStoryModuleWiseCategory(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<StoryMakerResponse>() {
            @Override
            public void onResponse(Call<StoryMakerResponse> call, Response<StoryMakerResponse> response) {
                if (response.isSuccessful()) {

                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.StoryMaker + IsFrom);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.StoryMakerResponseTime);
                    SetOfflineDataMainCategory(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<StoryMakerResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMaker + IsFrom).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineDataMainCategory(String response) {
        StoryMakerResponse storyMakerResponse = gson.fromJson(response, StoryMakerResponse.class);
        storyCategoriesList = storyMakerResponse.getData();

        storyCategoryAdapter = new StoryCategoryAdapter(activity, storyCategoriesList);
        mLayoutManager = new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false);
        rvStoryCategory.setLayoutManager(mLayoutManager);
        rvStoryCategory.setAdapter(storyCategoryAdapter);

        SetStoryThemeData(0, storyCategoriesList);
        progressDialog.dismiss();

    }

    public void SetStoryThemeData(int Position, ArrayList<StoryMainCategory> storyCategoryList) {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMakerTheme + IsFrom + storyCategoryList.get(Position).getCatId() + storyCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                GetStoryCategoryDataByID(String.valueOf(storyCategoryList.get(Position).getCatId()), String.valueOf(storyCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.StoryMakerThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetStoryCategoryDataByID(String.valueOf(storyCategoryList.get(Position).getCatId()), String.valueOf(storyCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMakerTheme + IsFrom + storyCategoryList.get(Position).getCatId() + storyCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {

                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMakerTheme + IsFrom + storyCategoryList.get(Position).getCatId() + storyCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMakerTheme + IsFrom + storyCategoryList.get(Position).getCatId() + storyCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMakerTheme + IsFrom + storyCategoryList.get(Position).getCatId() + storyCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));
            }
        }
    }

    public void GetStoryCategoryDataByID(String ParentCatId, String ChildCatId) {
        progressDialog.show();
        Call<StoryCategoryWiseResponse> call = apiInterface.getStoryCategoryWiseData(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId), "0", ParentCatId, ChildCatId);
        call.enqueue(new Callback<StoryCategoryWiseResponse>() {
            @Override
            public void onResponse(Call<StoryCategoryWiseResponse> call, Response<StoryCategoryWiseResponse> response) {
                if (response.isSuccessful()) {

                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.StoryMakerTheme + IsFrom + ParentCatId + ChildCatId);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.StoryMakerThemeResponseTime);
                    SetOfflineThemeData(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<StoryCategoryWiseResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.StoryMakerTheme + IsFrom + ParentCatId + ChildCatId).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineThemeData(String response) {
        StoryCategoryWiseResponse storyCategoryWiseResponse = gson.fromJson(response, StoryCategoryWiseResponse.class);
        storySubCategoryList = storyCategoryWiseResponse.getData();
        storySubCategoryAdapter = new StorySubCategoryAdapter(activity, storySubCategoryList);
        rvStorySubCategory.setLayoutManager(new GridLayoutManager(activity, 2));
        rvStorySubCategory.setAdapter(storySubCategoryAdapter);
        progressDialog.dismiss();
    }


    public void ShowImageDialog(String IsFrom) {
        Dialog dialog = new Dialog(activity, R.style.AppImageAlertDialog);
        dialog.setContentView(R.layout.dialog_select_imagevideo);
        LinearLayout llImageSelector = dialog.findViewById(R.id.ll_ImageSelector);
        LinearLayout llCamera = dialog.findViewById(R.id.llCamera);
        LinearLayout llGallery = dialog.findViewById(R.id.llGallery);
        llCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenCamera();
                dialog.dismiss();
            }
        });
        llGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenGallery();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void OpenGallery() {
        final ImagePicker.ImagePickerWithActivity a = new ImagePicker.ImagePickerWithActivity(this);
        final ImagePickerConfig a2 = a.config;
        a2.folderMode = true;
        a2.theme = 10;
        a2.showCamera = false;
        a2.limit = Constant.NoofImage;
        a.start(0);
    }


    private void OpenCamera() {
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        startActivityForResult(intent, Constant.Camera);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0 && resultCode == -1) {
            images = (ArrayList<Image>) ImagePicker.getImages(data);
            if (images != null) {
                if (images.size() == Constant.NoofImage) {
                    for (int i = 0; i < images.size(); i++) {
                        arrayList.add(images.get(i).getPath());
                    }
                    Intent intent = new Intent(activity, CanvasEditorActivity.class);
                    intent.putExtra("images", arrayList);
                    intent.putExtra("FilePath", Constant.TextFilePath);
                    intent.putExtra("IsFrom", Constant.IsFromStory);
                    startActivity(intent);
                    finish();
                }
            } else {
                Toast.makeText(activity, "Please select " + Constant.NoofImage + "Images", Toast.LENGTH_SHORT).show();
            }
        }

    }


    @OnClick(R.id.iv_my_creation)
    public void MyCreation() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, MyPostActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 20;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(activity, MyPostActivity.class));
                finish();
            }
        }
    }

    @OnClick(R.id.iv_back)
    public void Back(View view) {
        onBackPressed();
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, DashBordActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 19;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(activity, DashBordActivity.class));
                finish();
            }
        }
    }
}