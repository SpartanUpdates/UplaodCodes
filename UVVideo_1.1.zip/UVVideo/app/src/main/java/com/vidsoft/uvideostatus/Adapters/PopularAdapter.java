package com.vidsoft.uvideostatus.Adapters;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.vidsoft.uvideostatus.Fragments.PopularFragment;
import com.vidsoft.uvideostatus.Models.VideoData;
import com.vidsoft.uvideostatus.R;
import com.vidsoft.uvideostatus.Utility.FontTextView;
import com.vidsoft.uvideostatus.Utility.Utility;
import java.util.ArrayList;
import java.util.List;

public class PopularAdapter extends Adapter<RecyclerView.ViewHolder> {
    public List<VideoData> VideoList = new ArrayList();
    public Activity context;
    private boolean isLoading;
    public int like_total;
    private boolean loading;
    PopularFragment popularFragment;

    public class ViewHolder extends RecyclerView.ViewHolder {
        public FontTextView duration;
        LottieAnimationView icon_like;
        public ImageView icon_like_main;
        public RelativeLayout llVideoList;
        public FontTextView tvVideoListingDuration;
        public FontTextView tvVideoListingName;
        public FontTextView tvVideoListingSize;
        public ImageView tvVideoListingThumbnail;
        public FontTextView tvlike;
        public FontTextView tvtitle;

        public ViewHolder(View view) {
            super(view);
            this.tvVideoListingName = view.findViewById(R.id.tvVideoListingName);
            this.llVideoList = view.findViewById(R.id.llVideoList);
            this.tvVideoListingThumbnail = view.findViewById(R.id.tvVideoListingThumbnail);
            this.tvVideoListingSize = view.findViewById(R.id.tvVideoListingSize);
            this.tvVideoListingDuration = view.findViewById(R.id.tvVideoListingDuration);
            this.duration = view.findViewById(R.id.duration);
            this.tvtitle = view.findViewById(R.id.tvtitle);
            this.tvlike = view.findViewById(R.id.tvlike);
            this.icon_like_main = view.findViewById(R.id.icon_like_main);
            this.icon_like = view.findViewById(R.id.icon_like);
            this.llVideoList.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    try {
                        if (PopularAdapter.this.VideoList != null && ViewHolder.this.getAdapterPosition() != -1 && ViewHolder.this.getAdapterPosition() < PopularAdapter.this.VideoList.size()) {
                            PopularAdapter.this.popularFragment.playVideo(PopularAdapter.this.VideoList.get(ViewHolder.this.getAdapterPosition()));
                        }
                    } catch (Exception unused) {
                    }
                }
            });
        }
    }

    public PopularAdapter(Activity activity, ArrayList<VideoData> arrayList, PopularFragment popularFragment2) {
        this.VideoList = arrayList;
        this.context = activity;
        this.popularFragment = popularFragment2;
        notifyDataSetChanged();
        this.isLoading = false;
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());

        return new ViewHolder(from.inflate(R.layout.multi_item, viewGroup, false));
    }

    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder viewHolder, final int i) {

        VideoData videoData = this.VideoList.get(i);
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        viewHolder2.tvVideoListingName.setText(videoData.getTitle());
        viewHolder2.tvVideoListingSize.setText(videoData.getLikes());
        FontTextView fontTextView = viewHolder2.tvVideoListingDuration;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Utility.getViews(Double.parseDouble(videoData.getViews())));
//            Log.e("getView",""+videoData.getViews());
            stringBuilder.append(" views");
            fontTextView.setText(stringBuilder.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        viewHolder2.tvlike.setText(videoData.getLikes());
        viewHolder2.tvtitle.setText(videoData.getCatagory());
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.video_placeholder);
        requestOptions.error(R.drawable.video_placeholder);
        requestOptions.override(Callback.DEFAULT_SWIPE_ANIMATION_DURATION, Callback.DEFAULT_SWIPE_ANIMATION_DURATION);
        Glide.with(this.context).load(videoData.getThumbnail()).apply(requestOptions).into(viewHolder2.tvVideoListingThumbnail);
        viewHolder2.icon_like_main.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                PopularAdapter popularAdapter = PopularAdapter.this;
                popularAdapter.like_total = Integer.parseInt(popularAdapter.VideoList.get(i).getLikes()) + 1;
                FontTextView fontTextView = ((ViewHolder) viewHolder).tvlike;
                StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(PopularAdapter.this.like_total);
                fontTextView.setText(sb.toString());
                ((ViewHolder) viewHolder).icon_like_main.setVisibility(View.GONE);
                ((ViewHolder) viewHolder).icon_like.setVisibility(View.VISIBLE);
                ((ViewHolder) viewHolder).icon_like.playAnimation();
                ((ViewHolder) viewHolder).icon_like.loop(false);
            }
        });
    }

    public void setLoaded() {
        this.loading = false;
    }

    public void addAll(List<VideoData> list) {
        StringBuilder sb = new StringBuilder();
        sb.append("addAll12346: ");
        sb.append(this.VideoList.size());
        Log.d("TAG", sb.toString());
        int i = 2;
        for (int i2 = 0; i2 < list.size(); i2++) {
            if (i == i2) {
                i += 10;
                VideoData videoData = new VideoData();
                videoData.setType(3);
                this.VideoList.add(videoData);
                this.VideoList.add(list.get(i2));
            } else {
                this.VideoList.add(list.get(i2));
            }
        }
        notifyDataSetChanged();
    }

    public int getItemCount() {
        StringBuilder sb = new StringBuilder();
        sb.append("getItemCount: ");
        sb.append(this.VideoList.size());
        Log.d("TAG", sb.toString());
        return this.VideoList.size();
    }

    public int getItemViewType(int i) {

        return this.VideoList.get(i).getType();
    }
}
