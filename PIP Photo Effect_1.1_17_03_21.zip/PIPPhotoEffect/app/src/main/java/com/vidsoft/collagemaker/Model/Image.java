package com.vidsoft.collagemaker.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class Image implements Parcelable {
    public static final Creator<Image> CREATOR;
    public long id;
    public boolean isSelected;
    public String name;
    public String path;

    public Image(long id, String name, String path, boolean isSelected) {
        this.id = id;
        this.name = name;
        this.path = path;
        this.isSelected = isSelected;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.id);
        dest.writeString(this.name);
        dest.writeString(this.path);
    }

    static {
        CREATOR = new Creator<Image>() {
            public Image createFromParcel(Parcel source) {
                return new Image(null);
            }

            public Image[] newArray(int size) {
                return new Image[size];
            }
        };
    }

    private Image(Parcel in) {
        this.id = in.readLong();
        this.name = in.readString();
        this.path = in.readString();
    }
}