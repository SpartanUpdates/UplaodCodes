package com.esc.gesturelockscreen.View;

import android.os.Build;
import android.widget.*;
import android.content.*;
import android.util.*;
import android.view.*;
import com.esc.gesturelockscreen.R;
import androidx.annotation.RequiresApi;

public class ClockView extends FrameLayout
{
  private ClockTextView tvAm;
  private ClockTextView tvDate;
  private ClockTextView tvDay;
  private ClockTextView tvTimeH;
  private ClockTextView tvTimeM;

  public ClockView(final Context context) {
    super(context);
  }

  public ClockView(final Context context, final AttributeSet set) {
    super(context, set);
  }

  public ClockView(final Context context, final AttributeSet set, final int n) {
    super(context, set, n);
  }

  @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
  public ClockView(final Context context, final AttributeSet set, final int n, final int n2) {
    super(context, set, n, n2);
  }

  public static ClockView getView(final Context context, final int n) {
    return (ClockView)LayoutInflater.from(context).inflate(n, (ViewGroup)null);
  }

  public void handleTimeUpdate() {
    if (this.tvTimeH != null) {
      this.tvTimeH.updateValue();
      this.tvTimeM.updateValue();
      this.tvDate.updateValue();
      this.tvAm.updateValue();
      this.tvDay.updateValue();
    }
  }

  protected void onFinishInflate() {
    super.onFinishInflate();
    this.tvTimeH = (ClockTextView)this.findViewById(R.id.timeh_view);
    this.tvTimeM = (ClockTextView)this.findViewById(R.id.timem_view);
    this.tvDate = (ClockTextView)this.findViewById(R.id.date_view);
    this.tvAm = (ClockTextView)this.findViewById(R.id.am_view);
    this.tvDay = (ClockTextView)this.findViewById(R.id.day_view);
  }
}
