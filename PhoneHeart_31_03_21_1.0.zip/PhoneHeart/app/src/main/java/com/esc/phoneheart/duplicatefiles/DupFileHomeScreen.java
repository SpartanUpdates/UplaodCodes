package com.esc.phoneheart.duplicatefiles;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.esc.phoneheart.activity.DupFileScanScreen;
import com.esc.phoneheart.activity.HomeActivity;
import com.esc.phoneheart.R;
import com.esc.phoneheart.kprogresshud.KProgressHUD;
import com.esc.phoneheart.utility.PermitionActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

public class DupFileHomeScreen extends PermitionActivity {
    private Activity activity = DupFileHomeScreen.this;
    public static boolean all = false;
    public static boolean aud = false;
    public static boolean doc = false;
    public static ArrayList<String> extToScan = null;
    public static boolean img = false;
    public static boolean scanHidden = false;
    public static boolean vid = false;
    public List<String> arrExtensionAudio = Arrays.asList(new String[]{"mp3", "mpa", "aac", "oga"});
    public List<String> arrExtensionImage = Arrays.asList(new String[]{"jpeg", "jpg", "JPEG", "JPG", "png", "gif", "tiff", "tif", "bmp", "svg", "webp"});
    public List<String> arrExtensionVideo = Arrays.asList(new String[]{"mp4", "3gp", "avi", "mpeg", "webm", "flv", "wmv", "mkv", "m4a", "wav", "wma", "mmf", "mp2", "flac", "au", "ac3", "mpg", "mov", "mpv", "mpe", "ogg"});
    public CheckBox checkHidden;
    public CheckBox chkAll;
    public CheckBox chkAud;
    public CheckBox chkDoc;
    public CheckBox chkImg;
    public CheckBox chkVid;
    public RelativeLayout hiddenPermissionLayout;
    public List<String> textFileExtensions = Arrays.asList(new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"});
    private ImageView iv_back;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitialAd;
    private int id;
    private KProgressHUD hud;

    public DupFileHomeScreen() {
    }

    private void performScan() {
        img = this.chkImg.isChecked();
        aud = this.chkAud.isChecked();
        vid = this.chkVid.isChecked();
        doc = this.chkDoc.isChecked();
        all = this.chkAll.isChecked();
        scanHidden = this.checkHidden.isChecked();
        if (this.chkAll.isChecked()) {
            all = true;
            startActivity(new Intent(this, DupFileScanScreen.class));
            return;
        }
        ArrayList arrayList = new ArrayList();
        extToScan = arrayList;
        arrayList.clear();
        if (this.chkImg.isChecked()) {
            extToScan.addAll(this.arrExtensionImage);
        }
        if (this.chkVid.isChecked()) {
            extToScan.addAll(this.arrExtensionVideo);
        }
        if (this.chkAud.isChecked()) {
            extToScan.addAll(this.arrExtensionAudio);
        }
        if (this.chkDoc.isChecked()) {
            extToScan.addAll(this.textFileExtensions);
        }
        if (img || all || vid || aud || doc) {
            startActivity(new Intent(this, DupFileScanScreen.class));
        } else {
            Toast.makeText(this, "Select Something to Scan", Toast.LENGTH_LONG).show();
        }
    }

    private boolean permissionForStorageGiven() {
        if (VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == 0) {
            return true;
        }
        return false;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_dup_file_home_screen);

        this.hiddenPermissionLayout = (RelativeLayout) findViewById(R.id.hiddenpermissionlayout);
        this.chkImg = (CheckBox) findViewById(R.id.chk_img);
        this.chkVid = (CheckBox) findViewById(R.id.chk_vid);
        this.chkAud = (CheckBox) findViewById(R.id.chk_audios);
        this.chkDoc = (CheckBox) findViewById(R.id.chk_doc);
        this.chkAll = (CheckBox) findViewById(R.id.chk_allfiles);
        this.checkHidden = (CheckBox) findViewById(R.id.check_hidden);
        iv_back = findViewById(R.id.iv_back);

        loadAd();
        BannerAds();

        this.chkAll.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    chkImg.setChecked(true);
                    chkDoc.setChecked(true);
                    chkAud.setChecked(true);
                    chkVid.setChecked(true);
                    return;
                }
                chkImg.setChecked(false);
                chkAud.setChecked(false);
                chkDoc.setChecked(false);
                chkVid.setChecked(false);
            }
        });
        findViewById(R.id.btn_scan).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (DupFileHomeScreen.this.permissionForStorageGiven()) {
                    DupFileHomeScreen.this.performScan();
                } else {
                    DupFileHomeScreen.this.requestAppPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, R.string.pcl_sdcard_permission, 20);
                }
            }
        });

        iv_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitialAd !=null && interstitialAd.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 100;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                }else {
                    startActivity(new Intent(DupFileHomeScreen.this, HomeActivity.class));
                    finish();
                }
            }
        });
    }

    private void loadAd()
    {
        //InterstitialAd
        interstitialAd = new InterstitialAd(DupFileHomeScreen.this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        startActivity(new Intent(DupFileHomeScreen.this, HomeActivity.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitialAd = new InterstitialAd(activity);
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        menuItem.getItemId();
        onBackPressed();
        return super.onOptionsItemSelected(menuItem);
    }

    public void onPermissionsGranted(int i) {
        RelativeLayout relativeLayout = this.hiddenPermissionLayout;
        if (relativeLayout != null) {
            relativeLayout.setVisibility(View.GONE);
            performScan();
        }
    }
}
