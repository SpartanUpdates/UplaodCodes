package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Download.ZoomCollageThemeDownload;
import com.kotlinz.festivalstorymaker.Model.ZoomCollage.CategoryWiseData.ZoomCollageCategoryWiseData;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailActivity;
import java.io.File;
import java.util.ArrayList;
import butterknife.BindView;
import butterknife.ButterKnife;

public class HighlightFrameListAdapter extends RecyclerView.Adapter<HighlightFrameListAdapter.ViewHolder> {


    public HighlightDetailActivity highlightDetailMakerActivity;
    public ArrayList<ZoomCollageCategoryWiseData> categoryWiseCollageList;
    String DataFileName;
    String[] SplitName;

    public HighlightFrameListAdapter(Context activity, ArrayList<ZoomCollageCategoryWiseData> arrayList) {
        this.highlightDetailMakerActivity = (HighlightDetailActivity) activity;
        this.categoryWiseCollageList = arrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_highlight_bg_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        ZoomCollageCategoryWiseData collageCategoryWiseData = categoryWiseCollageList.get(position);
        if ( this.categoryWiseCollageList.get(position).getThemeThumbnail().length() > 0) {
            Glide.with(highlightDetailMakerActivity).load(categoryWiseCollageList.get(position).getThemeThumbnail()).placeholder(R.drawable.ic_placehoder).into(holder.img);
        }
        holder.img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DownloadFile(position, collageCategoryWiseData);
            }
        });
    }

    private void DownloadFile(int Position, ZoomCollageCategoryWiseData categoryWiseData) {
        DataFileName = categoryWiseData.getDatafile().substring(categoryWiseData.getDatafile().lastIndexOf('/') + 1);
        if (DataFileName.indexOf(".") > 0)
            DataFileName = DataFileName.substring(0, DataFileName.lastIndexOf(".")).replaceAll("[0-9]+", "");
        SplitName = DataFileName.split("Theme");
        String SplitFileName = "Theme" + " " + SplitName[1];
        String TextFileName = "Theme" + "_" + SplitName[1];

        Constant.TextFilePath = Utils.INSTANCE.getThemeFolderPath(highlightDetailMakerActivity) + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + SplitFileName + File.separator + TextFileName + ".txt";
        Constant.FolderPath = Utils.INSTANCE.getThemeFolderPath(highlightDetailMakerActivity) + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + SplitFileName;

        if (new File(Utils.INSTANCE.getThemeFolderPath(highlightDetailMakerActivity) + File.separator + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + DataFileName).exists()) {
            Constant.NoofImage = Integer.parseInt(categoryWiseCollageList.get(Position).getIsImageCount());
            Constant.ImageFrame = categoryWiseCollageList.get(Position).getThemeThumbnail();
            highlightDetailMakerActivity.OpenGallery();
            MyApplication.getInstance().CatItemPosition = Position;
        } else {
            new ZoomCollageThemeDownload(highlightDetailMakerActivity, categoryWiseCollageList.get(Position).getDatafile(), DataFileName, categoryWiseData);
        }
    }

    @Override
    public int getItemCount() {
        return categoryWiseCollageList.size();

    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.imgBg)
        public ImageView img;
        @BindView(R.id.imgLock)
        public ImageView imgLock;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
