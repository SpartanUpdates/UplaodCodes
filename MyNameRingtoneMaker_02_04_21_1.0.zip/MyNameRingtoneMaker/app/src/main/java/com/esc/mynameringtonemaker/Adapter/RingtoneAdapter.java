package com.esc.mynameringtonemaker.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.esc.mynameringtonemaker.Activity.RingtonePlayerActivity;
import com.esc.mynameringtonemaker.Model.RingtoneModel;
import com.esc.mynameringtonemaker.R;
import java.util.ArrayList;

public class RingtoneAdapter extends Adapter<ViewHolder> {
    private int ITEM_DATA = 0;
    private Context mcontext;
    private ArrayList<RingtoneModel> list;

    public class ItemHolder extends ViewHolder {
        private LinearLayout llMain;
        private TextView tvName;

        public ItemHolder(View view) {
            super(view);
            this.llMain = (LinearLayout) view.findViewById(R.id.llMain);
            this.tvName = (TextView) view.findViewById(R.id.tvName);
        }
    }

    public RingtoneAdapter(Context context, ArrayList<RingtoneModel> arrayList) {
        this.mcontext = context;
        this.list = arrayList;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return i == this.ITEM_DATA ? new ItemHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_ringtone, viewGroup, false)) : null;
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        RingtoneModel ringtoneModel = (RingtoneModel) this.list.get(i);
        if (getItemViewType(i) == this.ITEM_DATA) {
            ItemHolder itemHolder = (ItemHolder) viewHolder;
            itemHolder.tvName.setText(ringtoneModel.getName().replace("%20", " "));
            itemHolder.llMain.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Intent intent = new Intent(mcontext, RingtonePlayerActivity.class);
                    intent.putExtra("list", RingtoneAdapter.this.list);
                    intent.putExtra("selectedPos", i);
                    mcontext.startActivity(intent);
                }
            });
        }
    }

    public int getItemCount() {
        return this.list.size();
    }

    public int getItemViewType(int i) {
        return this.ITEM_DATA;
    }
}
