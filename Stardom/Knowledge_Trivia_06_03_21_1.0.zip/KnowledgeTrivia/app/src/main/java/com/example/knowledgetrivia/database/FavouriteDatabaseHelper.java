package com.example.knowledgetrivia.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class FavouriteDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABSE_NAME = "generalKnowlegeFav";
    private static final String FAV_QUESTION_ID = "favid";
    private static final String FAV_TABLE_NAME = "favQuestion";
    private SQLiteDatabase sqLiteDatabase = getReadableDatabase();

    public FavouriteDatabaseHelper(Context context) {
        super(context, DATABSE_NAME, null, 1);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS favQuestion ( favid INTEGER PRIMARY KEY)");
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS favQuestion");
        onCreate(sQLiteDatabase);
    }

    public long insertDataInFavouriteTable(int i) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(FAV_QUESTION_ID, Integer.valueOf(i));
        return this.sqLiteDatabase.insert(FAV_TABLE_NAME, null, contentValues);
    }

    public void removeFromFavouriteTable(int i) {
        SQLiteDatabase sQLiteDatabase = this.sqLiteDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("favid=");
        stringBuilder.append(i);
        sQLiteDatabase.delete(FAV_TABLE_NAME, stringBuilder.toString(), null);
    }

    public ArrayList<Integer> getFavouriteQuestions() {
        ArrayList arrayList = new ArrayList();
        Cursor rawQuery = this.sqLiteDatabase.rawQuery("select * from favQuestion", null);
        if (rawQuery.moveToFirst()) {
            do {
                arrayList.add(Integer.valueOf(rawQuery.getInt(0)));
            } while (rawQuery.moveToNext());
        }
        return arrayList;
    }
}
