package com.kotlinz.videoCollage.flying.poiphoto.ui.adapter;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.kotlinz.videoCollage.flying.poiphoto.Util;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Photo;
import com.kotlinz.videoeditor.R;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class PhotoAdapter extends Adapter<PhotoAdapter.PhotoViewHolder> {
    private final String TAG;
    private Context context;
    private String from;
    private int height;
    private List<Photo> mData;
    private int mMaxCount;
    private OnPhotoSelectedListener mOnPhotoSelectedListener;
    private OnPhotoUnSelectedListener mOnPhotoUnSelectedListener;
    private OnSelectedMaxListener mOnSelectedMaxListener;
    private OnSelectedTotalListener mOnSelectedTotalListener;
    private Set<Integer> mSelectedPhotoPositions;
    private ArrayList<Photo> mSelectedPhotos;
    private int mSelectedResId;
    private boolean temp1;
    private boolean temp2;
    private int width;

    public interface OnPhotoSelectedListener {
        void onPhotoSelected(Photo photo, int i);
    }

    public interface OnPhotoUnSelectedListener {
        void onPhotoUnSelected(Photo photo, int i);
    }

    public interface OnSelectedMaxListener {
        void onSelectedMax();
    }

    public interface OnSelectedTotalListener {
        void onSelectedTotal();
    }

    public static class PhotoViewHolder extends ViewHolder {
        ImageView mIvPhoto;
        FrameLayout mMain;
        FrameLayout mShadow;

        public PhotoViewHolder(View view) {
            super(view);
            this.mIvPhoto = (ImageView) view.findViewById(R.id.iv_photo);
            this.mMain = (FrameLayout) view.findViewById(R.id.photo_container);
            this.mShadow = (FrameLayout) view.findViewById(R.id.shadow);
        }
    }

    public PhotoAdapter() {
        this.TAG = PhotoAdapter.class.getSimpleName();
        this.mMaxCount = 10;
        this.mSelectedResId = R.color.photo_selected_shadow;
        this.temp1 = true;
        this.temp2 = true;
        this.mSelectedPhotos = new ArrayList();
        this.mSelectedPhotoPositions = new HashSet();
    }

    public PhotoAdapter(Context context, String str) {
        this.TAG = PhotoAdapter.class.getSimpleName();
        this.mMaxCount = 10;
        this.mSelectedResId = R.color.photo_selected_shadow;
        this.temp1 = true;
        this.temp2 = true;
        this.context = context;
        this.from = str;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.height = displayMetrics.heightPixels;
        this.width = displayMetrics.widthPixels;
        this.mSelectedPhotos = new ArrayList();
        this.mSelectedPhotoPositions = new HashSet();
    }

    public List<Photo> getData() {
        return this.mData;
    }

    public void setData(List<Photo> list) {
        this.mData = list;
    }

    public int getMaxCount() {
        return this.mMaxCount;
    }

    public void setMaxCount(int i) {
        this.mMaxCount = i;
    }

    public void setOnSelectedTotalListener(OnSelectedTotalListener onSelectedTotalListener) {
        this.mOnSelectedTotalListener = onSelectedTotalListener;
    }

    public void setOnSelectedMaxListener(OnSelectedMaxListener onSelectedMaxListener) {
        this.mOnSelectedMaxListener = onSelectedMaxListener;
    }

    public void setOnPhotoSelectedListener(OnPhotoSelectedListener onPhotoSelectedListener) {
        this.mOnPhotoSelectedListener = onPhotoSelectedListener;
    }

    public void setOnPhotoUnSelectedListener(OnPhotoUnSelectedListener onPhotoUnSelectedListener) {
        this.mOnPhotoUnSelectedListener = onPhotoUnSelectedListener;
    }

    public ArrayList<Photo> getSelectedPhotos() {
        return this.mSelectedPhotos;
    }

    public ArrayList<String> getSelectedPhotoPaths() {
        ArrayList arrayList = new ArrayList();
        Iterator it = this.mSelectedPhotos.iterator();
        while (it.hasNext()) {
            arrayList.add(((Photo) it.next()).getPath());
        }
        return arrayList;
    }

    public void refreshData(List<Photo> list) {
        this.mData = list;
        this.mSelectedPhotos.clear();
        notifyDataSetChanged();
    }

    public void reset() {
        this.mSelectedPhotos.clear();
        this.mSelectedPhotoPositions.clear();
        notifyDataSetChanged();
    }

    public PhotoViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new PhotoViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.poiphoto_item_photo, viewGroup, false));
    }

    public void onBindViewHolder(final PhotoViewHolder photoViewHolder, int i) {
        LayoutParams layoutParams = photoViewHolder.mMain.getLayoutParams();
        if (this.from.equalsIgnoreCase("select")) {
            layoutParams.height = this.width / 4;
        } else {
            layoutParams.height = this.width / 3;
        }
        photoViewHolder.mMain.setLayoutParams(layoutParams);
        if (!this.mSelectedPhotoPositions.contains(Integer.valueOf(i)) && photoViewHolder.mShadow.getVisibility() == View.VISIBLE) {
            photoViewHolder.mShadow.setVisibility(View.GONE);
        } else if (this.mSelectedPhotoPositions.contains(Integer.valueOf(i)) && photoViewHolder.mShadow.getVisibility() != View.VISIBLE) {
            photoViewHolder.mShadow.setVisibility(View.VISIBLE);
        }
        ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load(((Photo) this.mData.get(i)).getPath()).centerCrop()).skipMemoryCache(true)).placeholder(R.drawable.ic_baseline_image_24)).error(R.drawable.ic_baseline_image_24)).into(photoViewHolder.mIvPhoto);
        photoViewHolder.itemView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                int adapterPosition = photoViewHolder.getAdapterPosition();
                if (PhotoAdapter.this.mSelectedPhotoPositions.contains(Integer.valueOf(adapterPosition))) {
                    if (PhotoAdapter.this.temp1) {
                        PhotoAdapter.this.temp1 = false;
                        PhotoAdapter.this.mSelectedPhotoPositions.remove(Integer.valueOf(adapterPosition));
                        PhotoAdapter.this.mSelectedPhotos.remove(PhotoAdapter.this.mData.get(adapterPosition));
                        Util.selectedItemsCount--;
                        if (PhotoAdapter.this.mOnPhotoUnSelectedListener != null) {
                            PhotoAdapter.this.mOnPhotoUnSelectedListener.onPhotoUnSelected((Photo) PhotoAdapter.this.mData.get(adapterPosition), adapterPosition);
                        }
                        photoViewHolder.mShadow.setVisibility(View.GONE);
                    }
                    new Handler().postDelayed(new Runnable() {
                        public void run() {
                            PhotoAdapter.this.temp1 = true;
                        }
                    }, 300);
                } else if (PhotoAdapter.this.from.equalsIgnoreCase("select")) {
                    if (Util.selectedItemsCount < 4) {
                        if (PhotoAdapter.this.mSelectedPhotoPositions.size() < PhotoAdapter.this.mMaxCount) {
                            if (PhotoAdapter.this.temp2) {
                                PhotoAdapter.this.temp2 = false;
                                PhotoAdapter.this.mSelectedPhotoPositions.add(Integer.valueOf(adapterPosition));
                                PhotoAdapter.this.mSelectedPhotos.add(PhotoAdapter.this.mData.get(adapterPosition));
                                if (PhotoAdapter.this.mOnPhotoSelectedListener != null) {
                                    PhotoAdapter.this.mOnPhotoSelectedListener.onPhotoSelected((Photo) PhotoAdapter.this.mData.get(adapterPosition), adapterPosition);
                                }
                                Util.selectedItemsCount++;
                                photoViewHolder.mShadow.setVisibility(View.VISIBLE);
                            }
                            new Handler().postDelayed(new Runnable() {
                                public void run() {
                                    PhotoAdapter.this.temp2 = true;
                                }
                            }, 300);
                        } else if (PhotoAdapter.this.mOnSelectedMaxListener != null) {
                            PhotoAdapter.this.mOnSelectedMaxListener.onSelectedMax();
                        }
                    } else if (PhotoAdapter.this.mOnSelectedTotalListener != null) {
                        PhotoAdapter.this.mOnSelectedTotalListener.onSelectedTotal();
                    }
                } else if (PhotoAdapter.this.mSelectedPhotoPositions.size() < PhotoAdapter.this.mMaxCount) {
                    if (PhotoAdapter.this.temp2) {
                        PhotoAdapter.this.temp2 = false;
                        PhotoAdapter.this.mSelectedPhotoPositions.add(Integer.valueOf(adapterPosition));
                        PhotoAdapter.this.mSelectedPhotos.add(PhotoAdapter.this.mData.get(adapterPosition));
                        if (PhotoAdapter.this.mOnPhotoSelectedListener != null) {
                            PhotoAdapter.this.mOnPhotoSelectedListener.onPhotoSelected((Photo) PhotoAdapter.this.mData.get(adapterPosition), adapterPosition);
                        }
                        photoViewHolder.mShadow.setVisibility(View.VISIBLE);
                    }
                    new Handler().postDelayed(new Runnable() {
                        public void run() {
                            PhotoAdapter.this.temp2 = true;
                        }
                    }, 300);
                } else if (PhotoAdapter.this.mOnSelectedMaxListener != null) {
                    PhotoAdapter.this.mOnSelectedMaxListener.onSelectedMax();
                }
            }
        });
    }

    public int getItemCount() {
        List list = this.mData;
        return list == null ? 0 : list.size();
    }

    public void setSelectedResId(int i) {
        this.mSelectedResId = i;
    }
}
