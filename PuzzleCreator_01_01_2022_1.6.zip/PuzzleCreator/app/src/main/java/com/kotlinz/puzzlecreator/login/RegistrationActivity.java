package com.kotlinz.puzzlecreator.login;

import android.app.ActivityOptions;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.puzzlecreator.activity.BaseActivity;
import com.kotlinz.puzzlecreator.AppConstant.DataManager;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.model.Credentials;
import com.kotlinz.puzzlecreator.retrofit.APIClient;
import com.kotlinz.puzzlecreator.retrofit.APIInterface;
import com.skydoves.balloon.ArrowOrientation;
import com.skydoves.balloon.Balloon;
import com.skydoves.balloon.BalloonAnimation;
import com.skydoves.balloon.OnBalloonDismissListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.view.View.VISIBLE;

public class RegistrationActivity extends BaseActivity {
    EditText edtname, edtpass, edtrepass, edtmobile, edtreferal, edtlevel;
    TextInputLayout fieldreferal, tname, tmnumber, tpass, trepass;
    TextView txtloginhere;
    AutoCompleteTextView spinutype;
    Button btnsubmit;
    String utype = "";
    LinearLayout lreferal;
    CheckBox chkbReferal;
    String first = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        setarrawToolbar();

        edtname = (EditText) findViewById(R.id.edtname);
        edtmobile = (EditText) findViewById(R.id.edtmobile);
        edtpass = (EditText) findViewById(R.id.edtPassword);
        edtrepass = (EditText) findViewById(R.id.edtRePassword);
        edtreferal = (EditText) findViewById(R.id.edtRefaral);

        lreferal = (LinearLayout) findViewById(R.id.lreferal);
        chkbReferal = (CheckBox) findViewById(R.id.chkb_referal);

        fieldreferal = (TextInputLayout) findViewById(R.id.fieldreferal);
        tname = (TextInputLayout) findViewById(R.id.tname);
        tpass = (TextInputLayout) findViewById(R.id.tpass);
        trepass = (TextInputLayout) findViewById(R.id.trepass);
        tmnumber = (TextInputLayout) findViewById(R.id.tmnumber);

        txtloginhere = (TextView) findViewById(R.id.txtloginhere);

        btnsubmit = (Button) findViewById(R.id.btnSubmit);

        txtloginhere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(RegistrationActivity.this, LoginActivity.class);
                startActivity(i);
                finish();
            }
        });

        setUserSpinner();
        Balloon balloon = new Balloon.Builder(RegistrationActivity.this)
                .setLayout(R.layout.guide_layout)
                .setArrowSize(10)
                .setOnBalloonDismissListener(new OnBalloonDismissListener() {
                    @Override
                    public void onBalloonDismiss() {
                        if (first.equalsIgnoreCase("")) {
                            first = "false";
                        }
                    }
                })
                .setArrowOrientation(ArrowOrientation.TOP)
                .setArrowPosition(0.5f)
                .setWidth(350)
                .setHeight(200)
                .setCornerRadius(4f)
                .setBackgroundColor(ContextCompat.getColor(this, R.color.colorPrimaryDark))
                .setBalloonAnimation(BalloonAnimation.CIRCULAR)
                .build();

        TextView button = balloon.getContentView().findViewById(R.id.btnok);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                balloon.dismiss();
            }
        });

        spinutype.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                first = "true";
                balloon.showAlignTop(spinutype);
            }
        });

        spinutype.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (parent.getItemAtPosition(position).toString().equalsIgnoreCase(getResources().getString(R.string.reviewer))) {
                    utype = DataManager.reviewer;
                } else {
                    utype = DataManager.creator;
                }
            }
        });

        chkbReferal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (chkbReferal.isChecked()) {
                    lreferal.setVisibility(VISIBLE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        chkbReferal.setButtonTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimaryDark)));
                        chkbReferal.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                    }
                } else {
                    lreferal.setVisibility(View.GONE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        chkbReferal.setButtonTintList(ColorStateList.valueOf(getResources().getColor(R.color.hint_color)));
                        chkbReferal.setTextColor(getResources().getColor(R.color.hint_color));
                    }
                }
            }
        });

        edtname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tname.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edtmobile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tmnumber.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edtpass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tpass.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edtreferal.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                fieldreferal.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edtrepass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void
            afterTextChanged(Editable s) {
                if (!edtpass.getText().toString().equalsIgnoreCase(edtrepass.getText().toString())) {
                    trepass.setErrorEnabled(true);
                    trepass.setErrorIconDrawable(null);
                    trepass.setError("Both Password Not Match");
                } else {
                    trepass.setErrorEnabled(false);
                    if (first.equalsIgnoreCase("")) {
                        balloon.showAlignTop(spinutype);
                    }
                }
            }
        });

        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtname.getText().toString().equalsIgnoreCase("")) {
                    tname.setErrorEnabled(true);
                    tname.setError("Enter Name");
                } else if (edtmobile.getText().toString().equalsIgnoreCase("")) {
                    tmnumber.setErrorEnabled(true);
                    tmnumber.setError("Enter Mobile");
                } else if (edtmobile.getText().toString().length() != 10) {
                    tmnumber.setErrorEnabled(true);
                    tmnumber.setError("Enter 10 Digit Mobile Number");
                } else if (edtpass.getText().toString().equalsIgnoreCase("")) {
                    tpass.setErrorEnabled(true);
                    tpass.setErrorIconDrawable(null);
                    tpass.setError("Enter Password");
                } else if (edtrepass.getText().toString().equalsIgnoreCase("")) {
                    trepass.setErrorEnabled(true);
                    trepass.setError("Enter Re-password");
                } else if (utype.equalsIgnoreCase("") || utype.equalsIgnoreCase(getResources().getString(R.string.select_type))) {
                    Toast.makeText(RegistrationActivity.this, "Select User Type", Toast.LENGTH_LONG).show();
                } else if (chkbReferal.isChecked() && edtreferal.getText().toString().equalsIgnoreCase("")) {
                    fieldreferal.setErrorEnabled(true);
                    fieldreferal.setError("Enter Referal");
                } else {
                    Register_user(edtname.getText().toString(), edtmobile.getText().toString(), utype, edtpass.getText().toString(), edtreferal.getText().toString());
                }
            }
        });
    }

    public void setUserSpinner() {
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        R.layout.dropdown_menu_popup_item,
                        getResources().getStringArray(R.array.usertype));

        spinutype = findViewById(R.id.textspin);
        spinutype.setText(adapter.getItem(0));
        utype = DataManager.creator;
        Log.e("Utype", ".........." + utype);
        spinutype.setAdapter(adapter);
    }

    private void Register_user(String name, String number, String usertype, String password, String referal) {
        showProgressDialog();
        Credentials registration = new Credentials();
        registration.name = name;
        registration.mobile_number = number;
        registration.user_type = usertype;
        registration.password = password;
        registration.referal_code = referal;
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).RegisterUser(registration);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> res) {
                if (res.code() == 200) {
                    try {
                        String result = res.body().string();
                        Log.e("Responce", "........" + result);
                        JSONObject jsonObject = new JSONObject(result);
                        JSONObject obj = new JSONObject(result);
                        if (obj.getBoolean("status")) {
                            Toast.makeText(RegistrationActivity.this, "Register Successfully", Toast.LENGTH_LONG).show();
                            Bundle params = new Bundle();
                            params.putString("User_type", usertype);
                            if (!referal.equalsIgnoreCase("")) {
                                params.putString("Referal_Used", "Yes");
                            } else {
                                params.putString("Referal_Used", "No");
                            }
                            mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SIGN_UP, params);
                            cancel_dialog();
                            Intent i = new Intent(RegistrationActivity.this, TransitAnimationActivity.class);
                            if (Build.VERSION.SDK_INT > 20) {
                                ActivityOptions options =
                                        ActivityOptions.makeSceneTransitionAnimation(RegistrationActivity.this);
                                startActivity(i, options.toBundle());
                                finish();
                            } else {
                                startActivity(i);
                                finish();
                            }
                        } else {
                            cancel_dialog();
                            showerrorDialog("Failed", obj.getString("message"));
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                    cancel_dialog();
                } else {
                    try {
                        JSONObject obj = new JSONObject(res.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }

}
