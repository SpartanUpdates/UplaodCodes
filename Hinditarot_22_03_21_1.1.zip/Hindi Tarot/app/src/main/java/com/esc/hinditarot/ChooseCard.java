package com.esc.hinditarot;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.PorterDuff.Mode;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.DragShadowBuilder;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.ironsource.mediationsdk.IronSource;

public class ChooseCard extends AppCompatActivity implements AnimationListener {
    Activity activity = ChooseCard.this;
    static boolean backpressed = false;
    static final String[] cardnames = new String[]{"ACE OF CUPS", "TWO OF CUPS", "THREE OF CUPS", "FOUR OF CUPS", "FIVE OF CUPS", "SIX OF CUPS", "SEVEN OF CUPS", "EIGHT OF CUPS", "NINE OF CUPS", "TEN OF CUPS", "PAGE OF CUPS", "KNIGHT OF CUPS", "QUEEN OF CUPS", "KING OF CUPS", "ACE OF WANDS", "TWO OF WANDS", "THREE OF WANDS", "FOUR OF WANDS", "FIVE OF WANDS", "SIX OF WANDS", "SEVEN OF WANDS", "EIGHT OF WANDS", "NINE OF WANDS", "TEN OF WANDS", "PAGE OF WANDS", "KNIGHT OF WANDS", "QUEEN OF WANDS", "KING OF WANDS", "ACE OF SWORDS", "TWO OF SWORDS", "THREE OF SWORDS", "FOUR OF SWORDS", "FIVE OF SWORDS", "SIX OF SWORDS", "SEVEN OF SWORDS", "EIGHT OF SWORDS", "NINE OF SWORDS", "TEN OF SWORDS", "PAGE OF SWORDS", "KNIGHT OF SWORDS", "QUEEN OF SWORDS", "KING OF SWORDS", "ACE OF PENTACLES", "TWO OF PENTACLES", "THREE OF PENTACLES", "FOUR OF PENTACLES", "FIVE OF PENTACLES", "SIX OF PENTACLES", "SEVEN OF PENTACLES", "EIGHT OF PENTACLES", "NINE OF PENTACLES", "TEN OF PENTACLES", "PAGE OF PENTACLES", "KNIGHT OF PENTACLES", "QUEEN OF PENTACLES", "KING OF PENTACLES", "DEATH", "JUDGEMENT", "JUSTICE", "STRENGTH", "TEMPERANCE", "THE CHARIOT", "THE DEVIL", "THE EMPEROR", "THE EMPRESS", "THE FOOL", "THE HANGED MAN", "THE HERMIT", "THE HIEROPHANT", "THE HIGH PRIESTESS", "THE LOVERS", "THE MAGICIAN", "THE MOON", "THE STAR", "THE SUN", "THE TOWER", "THE WORLD", "WHEEL OF FORTUNE"};
    static final String[] cardnames2 = new String[78];
    static String category;
    public static Editor editor;
    public static Typeface georgiar;
    public static int height;
    static ImageView[] img_row1;
    static ImageView[] img_row2;
    static ImageView[] img_row3;
    static ImageView selectedcard1;
    public static SharedPreferences sharedPreferences;
    static ImageView[] shuufelimg;
    static ImageView[] shuufelimg1;
    static ImageView[] shuufelimg2;
    public static String trans;
    public static int width;
    Animation animation;
    final int[] cardint;
    String cardname1;
    String category_en;
    String[] cdnames;
    String cname1;
    DisplayMetrics displayMetrics;
    Boolean dragdropped;
    Boolean dragentered;
    LinearLayout dropimgs;
    TextView droptxt;
    Boolean firstcardtap;
    Handler handler;
    int numeric_count;
    RelativeLayout relativeLayout;
    Boolean secondcardtap;
    Button shuffle;
    int shuffle_flag = 1;
    int tapcardcount;
    Boolean thirdcardtap;
    ImageView transimg1;
    ImageView transimg11;
    TextView txt1;
    TextView txtcardname;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    class MyDragListener implements OnDragListener {
        MyDragListener() {
        }

        public boolean onDrag(View view, DragEvent dragEvent) {
            int action = dragEvent.getAction();
            String str = "ondrag";
            if (action != 1) {
                int i = 0;
                if (action == 3) {
                    ChooseCard.this.dragdropped = Boolean.valueOf(true);
                    view = (View) dragEvent.getLocalState();
                    RelativeLayout relativeLayout = ChooseCard.this.findViewById(R.id.cardimages);
                    if (ChooseCard.this.dragentered.booleanValue()) {
                        relativeLayout.removeView(view);
                        ChooseCard.this.shuffle.setVisibility(View.INVISIBLE);
                        ChooseCard.this.shuffle.getLayoutParams().height = 0;
                        ChooseCard.this.transimg11.setVisibility(View.VISIBLE);
                        ChooseCard.this.transimg1.setVisibility(View.INVISIBLE);
                        ChooseCard.this.txt1.setVisibility(View.INVISIBLE);
                        ChooseCard.this.transimg11.setAnimation(ChooseCard.this.animation);
                        ChooseCard.this.transimg11.startAnimation(ChooseCard.this.animation);
                        ChooseCard.this.shuffle.getLayoutParams().height = 0;
                        ChooseCard.this.droptxt.getLayoutParams().height = 0;
                        ChooseCard.this.firstcardtap = Boolean.valueOf(true);
                        ChooseCard.this.secondcardtap = Boolean.valueOf(false);
                        ChooseCard.this.thirdcardtap = Boolean.valueOf(false);
                        while (i < 26) {
                            ChooseCard.img_row1[i].setOnTouchListener(null);
                            ChooseCard.img_row2[i].setOnTouchListener(null);
                            ChooseCard.img_row3[i].setOnTouchListener(null);
                            relativeLayout.removeView(view);
                            i++;
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("****** ");
                        stringBuilder.append(ChooseCard.backpressed);
                        String stringBuilder2 = stringBuilder.toString();
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("Selected card Nmame ");
                        stringBuilder3.append(ChooseCard.this.cardname1);
                        Log.e(stringBuilder2, stringBuilder3.toString());
                        ChooseCard.this.handler.postDelayed(new Runnable() {
                            public void run() {
                                ChooseCard.this.finish();
                                Intent intent = new Intent(ChooseCard.this.getApplicationContext(), DisplayResult.class);
                                intent.putExtra("SELECTED_CARD", ChooseCard.this.txtcardname.getText().toString());
                                intent.putExtra("SELECTED_CATEGORY", ChooseCard.category);
                                intent.putExtra("SELECTED_CARD_E", ChooseCard.this.cname1);
                                intent.putExtra("SELECTED_CATEGORY_EN", ChooseCard.this.category_en);
                                ChooseCard.this.startActivity(intent);
                            }
                        }, 2000);
                    }
                } else if (action == 4) {
                    ChooseCard.selectedcard1.setColorFilter(0, Mode.OVERLAY);
                } else if (action == 5) {
                    Log.e(str, "ACTION_DRAG_ENTERED");
                    ChooseCard.this.dragentered = Boolean.valueOf(true);
                    if (!ChooseCard.this.dragdropped.booleanValue()) {
                        while (i < 26) {
                            ChooseCard.img_row1[i].setOnTouchListener(new MyTouchListener1());
                            ChooseCard.img_row2[i].setOnTouchListener(new MyTouchListener1());
                            ChooseCard.img_row3[i].setOnTouchListener(new MyTouchListener1());
                            i++;
                        }
                    }
                } else if (action == 6) {
                    Log.e(str, "ACTION_DRAG_EXITED");
                }
            } else {
                Log.e(str, "ACTION_DRAG_STARTED");
            }
            return true;
        }
    }

    class MyTouchListener1 implements OnTouchListener {
        MyTouchListener1() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (action != 0) {
                String str = "ontouch";
                if (action == 1) {
                    Log.e(str, "ACTION_UP");
                } else if (action == 2) {
                    Log.e(str, "ACTION_MOVE");
                }
            } else {
                String str2 = "";
                view.startDrag(ClipData.newPlainText(str2, str2), new DragShadowBuilder(view), view, 0);
                ChooseCard.selectedcard1 = (ImageView) view;
                ChooseCard.selectedcard1.setColorFilter(R.color.colorPrimaryDark, Mode.DARKEN);
                ChooseCard.this.cname1 = (String) ChooseCard.selectedcard1.getTag();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("///////");
                stringBuilder.append(ChooseCard.this.cname1);
                stringBuilder.append("..........");
                ChooseCard.selectedcard1.setVisibility(View.GONE);
                for (int i = 0; i < ChooseCard.this.cdnames.length; i++) {
                    if (ChooseCard.this.cname1.equals(ChooseCard.this.cdnames[i])) {
                        ChooseCard.this.cardname1 = ChooseCard.cardnames2[i];
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(str2);
                        stringBuilder2.append(ChooseCard.this.cardname1);
                        stringBuilder2.append("........");
                        Log.e("one card name", stringBuilder2.toString());
                    }
                }
            }
            if (!ChooseCard.this.secondcardtap.booleanValue() && !ChooseCard.this.thirdcardtap.booleanValue()) {
                view.setVisibility(View.VISIBLE);
                view.invalidate();
            } else if (ChooseCard.this.dragentered.booleanValue() && ChooseCard.this.dragdropped.booleanValue()) {
                view.setVisibility(View.VISIBLE);
                view.invalidate();
            } else {
                view.setVisibility(View.VISIBLE);
                view.invalidate();
            }
            return true;
        }
    }

    public void onAnimationRepeat(Animation animation) {
    }

    public void onAnimationStart(Animation animation) {
    }

    public ChooseCard() {
        Boolean valueOf = Boolean.valueOf(false);
        this.firstcardtap = valueOf;
        this.secondcardtap = valueOf;
        this.thirdcardtap = valueOf;
        this.numeric_count = 0;
        this.tapcardcount = 0;
        this.dragentered = valueOf;
        this.dragdropped = valueOf;
        this.handler = new Handler();
        this.cardint = new int[]{R.string.aceofcups, R.string.twoofcups, R.string.threeofcups, R.string.fourofcups, R.string.fiveofcups, R.string.sixofcups, R.string.sevenofcups, R.string.eightofcups, R.string.nineofcups, R.string.tenofcups, R.string.pageofcups, R.string.knightofcups, R.string.queenofcups, R.string.kingofcups, R.string.aceofwands, R.string.twoofwands, R.string.threeofwands, R.string.fourofwands, R.string.fiveofwands, R.string.sixofwands, R.string.sevenofwands, R.string.eightofwands, R.string.nineofwands, R.string.tenofwands, R.string.pageofwands, R.string.knightofwands, R.string.queenofwands, R.string.kingofwands, R.string.aceofswords, R.string.twoofswords, R.string.threeofswords, R.string.fourofswords, R.string.fiveofswords, R.string.sixofswords, R.string.sevenofswords, R.string.eightofswords, R.string.nineofswords, R.string.tenofswords, R.string.pageofswords, R.string.knightofswords, R.string.queenofswords, R.string.kingofswords, R.string.aceofpentacles, R.string.twoofpentacles, R.string.threeofpentacles, R.string.fourofpentacles, R.string.fiveofpentacles, R.string.sixofpentacles, R.string.sevenofpentacles, R.string.eightofpentacles, R.string.nineofpentacles, R.string.tenofpentacles, R.string.pageofpentacles, R.string.knightofpentacles, R.string.queenofpentacles, R.string.kingofpentacles, R.string.death, R.string.judgement, R.string.justice, R.string.strength, R.string.temperance, R.string.thechariot, R.string.thedevil, R.string.theemperor, R.string.theempress, R.string.thefool, R.string.thehangedman, R.string.thehermit, R.string.thehierophant, R.string.thehighpriestress, R.string.thelovers, R.string.themagician, R.string.themoon, R.string.thestar, R.string.thesun, R.string.thetower, R.string.theworld, R.string.wheeloffortune};
    }


    public void onCreate(Bundle bundle) {
        int i;
        int i2;
        StringBuilder stringBuilder;
        super.onCreate(bundle);
        setContentView(R.layout.activity_choose_card);
        int i3 = 0;
        backpressed = false;
        Intent intent = getIntent();
        category = intent.getStringExtra(MainActivity.SELECTED_CATEGORY);
        this.category_en = intent.getStringExtra("SELECTED_CATEGORY_EN");
        setTitle(category);
        this.animation = AnimationUtils.loadAnimation(this, R.anim.from_middle);
        this.animation.setAnimationListener(this);
        georgiar = Typeface.createFromAsset(getAssets(), "fonts/georgiar.ttf");
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("");
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.custom_actionbar_layout, null);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        TextView textView = inflate.findViewById(R.id.action_bar_title);
        textView.setText(category);
        setTitle(category);
        textView.setTypeface(georgiar);
        sharedPreferences = getSharedPreferences("MYPREF", 0);
        editor = sharedPreferences.edit();
        this.shuffle = findViewById(R.id.shuffle);
        this.droptxt = findViewById(R.id.droptxt);
        this.transimg1 = findViewById(R.id.transimg1);
        this.txtcardname = findViewById(R.id.txtcardname);
        this.transimg11 = findViewById(R.id.transimg11);
        this.txt1 = findViewById(R.id.txt1);
        this.relativeLayout = findViewById(R.id.cardimages);
        this.relativeLayout.setOnDragListener(null);
        this.relativeLayout.setOnTouchListener(null);
        this.dropimgs = findViewById(R.id.dropimgs);
        this.shuffle.setTypeface(georgiar);
        this.droptxt.setTypeface(georgiar);
        this.txtcardname.setTypeface(georgiar);
        this.droptxt.setTypeface(georgiar);
        this.txt1.setTypeface(georgiar);
        BannerAds();
        for (i = 0; i < 78; i++) {
            cardnames2[i] = getResources().getString(this.cardint[i]);
        }
        this.cdnames = new String[]{"ACE OF CUPS", "TWO OF CUPS", "THREE OF CUPS", "FOUR OF CUPS", "FIVE OF CUPS", "SIX OF CUPS", "SEVEN OF CUPS", "EIGHT OF CUPS", "NINE OF CUPS", "TEN OF CUPS", "PAGE OF CUPS", "KNIGHT OF CUPS", "QUEEN OF CUPS", "KING OF CUPS", "ACE OF WANDS", "TWO OF WANDS", "THREE OF WANDS", "FOUR OF WANDS", "FIVE OF WANDS", "SIX OF WANDS", "SEVEN OF WANDS", "EIGHT OF WANDS", "NINE OF WANDS", "TEN OF WANDS", "PAGE OF WANDS", "KNIGHT OF WANDS", "QUEEN OF WANDS", "KING OF WANDS", "ACE OF SWORDS", "TWO OF SWORDS", "THREE OF SWORDS", "FOUR OF SWORDS", "FIVE OF SWORDS", "SIX OF SWORDS", "SEVEN OF SWORDS", "EIGHT OF SWORDS", "NINE OF SWORDS", "TEN OF SWORDS", "PAGE OF SWORDS", "KNIGHT OF SWORDS", "QUEEN OF SWORDS", "KING OF SWORDS", "ACE OF PENTACLES", "TWO OF PENTACLES", "THREE OF PENTACLES", "FOUR OF PENTACLES", "FIVE OF PENTACLES", "SIX OF PENTACLES", "SEVEN OF PENTACLES", "EIGHT OF PENTACLES", "NINE OF PENTACLES", "TEN OF PENTACLES", "PAGE OF PENTACLES", "KNIGHT OF PENTACLES", "QUEEN OF PENTACLES", "KING OF PENTACLES", "DEATH", "JUDGEMENT", "JUSTICE", "STRENGTH", "TEMPERANCE", "THE CHARIOT", "THE DEVIL", "THE EMPEROR", "THE EMPRESS", "THE FOOL", "THE HANGED MAN", "THE HERMIT", "THE HIEROPHANT", "THE HIGH PRIESTESS", "THE LOVERS", "THE MAGICIAN", "THE MOON", "THE STAR", "THE SUN", "THE TOWER", "THE WORLD", "WHEEL OF FORTUNE"};
        for (i = 0; i < 78; i++) {
            cardnames2[i] = getResources().getString(this.cardint[i]);
        }
        this.numeric_count = 1;
        img_row1 = new ImageView[26];
        img_row2 = new ImageView[26];
        img_row3 = new ImageView[26];
        img_row1[0] = findViewById(R.id.card1);
        img_row1[1] = findViewById(R.id.card2);
        img_row1[2] = findViewById(R.id.card3);
        img_row1[3] = findViewById(R.id.card4);
        img_row1[4] = findViewById(R.id.card5);
        img_row1[5] = findViewById(R.id.card6);
        img_row1[6] = findViewById(R.id.card7);
        img_row1[7] = findViewById(R.id.card8);
        img_row1[8] = findViewById(R.id.card9);
        img_row1[9] = findViewById(R.id.card10);
        img_row1[10] = findViewById(R.id.card11);
        img_row1[11] = findViewById(R.id.card12);
        img_row1[12] = findViewById(R.id.card13);
        img_row1[13] = findViewById(R.id.card14);
        img_row1[14] = findViewById(R.id.card15);
        img_row1[15] = findViewById(R.id.card16);
        img_row1[16] = findViewById(R.id.card17);
        img_row1[17] = findViewById(R.id.card18);
        img_row1[18] = findViewById(R.id.card19);
        img_row1[19] = findViewById(R.id.card20);
        img_row1[20] = findViewById(R.id.card21);
        img_row1[21] = findViewById(R.id.card22);
        img_row1[22] = findViewById(R.id.card23);
        img_row1[23] = findViewById(R.id.card24);
        img_row1[24] = findViewById(R.id.card25);
        img_row1[25] = findViewById(R.id.card26);
        img_row2[0] = findViewById(R.id.card27);
        img_row2[1] = findViewById(R.id.card28);
        img_row2[2] = findViewById(R.id.card29);
        img_row2[3] = findViewById(R.id.card30);
        img_row2[4] = findViewById(R.id.card31);
        img_row2[5] = findViewById(R.id.card32);
        img_row2[6] = findViewById(R.id.card33);
        img_row2[7] = findViewById(R.id.card34);
        img_row2[8] = findViewById(R.id.card35);
        img_row2[9] = findViewById(R.id.card36);
        img_row2[10] = findViewById(R.id.card37);
        img_row2[11] = findViewById(R.id.card38);
        img_row2[12] = findViewById(R.id.card39);
        img_row2[13] = findViewById(R.id.card40);
        img_row2[14] = findViewById(R.id.card41);
        img_row2[15] = findViewById(R.id.card42);
        img_row2[16] = findViewById(R.id.card43);
        img_row2[17] = findViewById(R.id.card44);
        img_row2[18] = findViewById(R.id.card45);
        img_row2[19] = findViewById(R.id.card46);
        img_row2[20] = findViewById(R.id.card47);
        img_row2[21] = findViewById(R.id.card48);
        img_row2[22] = findViewById(R.id.card49);
        img_row2[23] = findViewById(R.id.card50);
        img_row2[24] = findViewById(R.id.card51);
        img_row2[25] = findViewById(R.id.card52);
        img_row3[0] = findViewById(R.id.card53);
        img_row3[1] = findViewById(R.id.card54);
        img_row3[2] = findViewById(R.id.card55);
        img_row3[3] = findViewById(R.id.card56);
        img_row3[4] = findViewById(R.id.card57);
        img_row3[5] = findViewById(R.id.card58);
        img_row3[6] = findViewById(R.id.card59);
        img_row3[7] = findViewById(R.id.card60);
        img_row3[8] = findViewById(R.id.card61);
        img_row3[9] = findViewById(R.id.card62);
        img_row3[10] = findViewById(R.id.card63);
        img_row3[11] = findViewById(R.id.card64);
        img_row3[12] = findViewById(R.id.card65);
        img_row3[13] = findViewById(R.id.card66);
        img_row3[14] = findViewById(R.id.card67);
        img_row3[15] = findViewById(R.id.card68);
        img_row3[16] = findViewById(R.id.card69);
        img_row3[17] = findViewById(R.id.card70);
        img_row3[18] = findViewById(R.id.card71);
        img_row3[19] = findViewById(R.id.card72);
        img_row3[20] = findViewById(R.id.card73);
        img_row3[21] = findViewById(R.id.card74);
        img_row3[22] = findViewById(R.id.card75);
        img_row3[23] = findViewById(R.id.card76);
        img_row3[24] = findViewById(R.id.card77);
        img_row3[25] = findViewById(R.id.card78);
        for (i = 0; i < 26; i++) {
            img_row1[i].setId(i);
            img_row1[i].setTag(cardnames[i]);
            img_row1[i].setClickable(false);
            img_row1[i].setOnClickListener(null);
            img_row1[i].setOnTouchListener(new MyTouchListener1());
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("cardname");
            stringBuilder2.append(i);
            stringBuilder2.append(".........");
            stringBuilder2.append(cardnames[i]);
        }
        for (i = 0; i < 26; i++) {
            i2 = i + 26;
            img_row2[i].setId(i2);
            img_row2[i].setTag(cardnames[i2]);
            img_row2[i].setClickable(false);
            img_row2[i].setOnClickListener(null);
            img_row2[i].setOnTouchListener(new MyTouchListener1());
            stringBuilder = new StringBuilder();
            stringBuilder.append("cardname");
            stringBuilder.append(i2);
            stringBuilder.append(".........");
            stringBuilder.append(cardnames[i2]);
        }
        for (i = 0; i < 26; i++) {
            i2 = i + 52;
            img_row3[i].setId(i2);
            img_row3[i].setTag(cardnames[i2]);
            img_row3[i].setClickable(false);
            img_row3[i].setOnClickListener(null);
            img_row3[i].setOnTouchListener(new MyTouchListener1());
            stringBuilder = new StringBuilder();
            stringBuilder.append("cardname");
            stringBuilder.append(i2);
            stringBuilder.append(".........");
            stringBuilder.append(cardnames[i2]);
        }
        shuufelimg = img_row1;
        shuufelimg1 = img_row2;
        shuufelimg2 = img_row3;
        shuffelcards();
        this.shuffle.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ChooseCard.this.shuffelcards();
                ChooseCard.this.animate();
            }
        });
        this.dropimgs.setOnDragListener(new MyDragListener());
        animate();
        this.displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(this.displayMetrics);
        height = this.displayMetrics.heightPixels;
        width = this.displayMetrics.widthPixels;
        trans = getResources().getConfiguration().locale.getLanguage();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("");
        stringBuilder3.append(height);
        stringBuilder3.append("   ");
        stringBuilder3.append(width);
        double d = width;
        Double.isNaN(d);
        int floor = (int) Math.floor((d * 0.98d) / 29.0d);
        int i4 = 0;
        while (i3 < 26) {
            ((MarginLayoutParams) img_row1[i3].getLayoutParams()).leftMargin = i4;
            ((MarginLayoutParams) img_row2[i3].getLayoutParams()).leftMargin = i4;
            ((MarginLayoutParams) img_row3[i3].getLayoutParams()).leftMargin = i4;
            i4 += floor;
            i3++;
        }
        LayoutParams layoutParams;
        double d2;
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            this.droptxt.setTextSize(32.0f);
            this.txt1.setTextSize(30.0f);
            this.shuffle.setTextSize(30.0f);
            this.txtcardname.setTextSize(28.0f);
            layoutParams = this.transimg1.getLayoutParams();
            d2 = width;
            Double.isNaN(d2);
            layoutParams.width = (int) (d2 * 0.29d);
            layoutParams = this.transimg1.getLayoutParams();
            d2 = height;
            Double.isNaN(d2);
            layoutParams.height = (int) (d2 * 0.21d);
            this.txt1.getLayoutParams().width = this.transimg1.getLayoutParams().width;
            this.txt1.getLayoutParams().height = this.transimg1.getLayoutParams().height;
            layoutParams = this.transimg11.getLayoutParams();
            d2 = width;
            Double.isNaN(d2);
            layoutParams.width = (int) (d2 * 0.33d);
            layoutParams = this.transimg11.getLayoutParams();
            d2 = height;
            Double.isNaN(d2);
            layoutParams.height = (int) (d2 * 0.27d);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            this.droptxt.setTextSize(28.0f);
            this.shuffle.setTextSize(29.0f);
            this.txt1.setTextSize(24.0f);
            textView.setTextSize(30.0f);
            this.txtcardname.setTextSize(28.0f);
            layoutParams = this.transimg1.getLayoutParams();
            d2 = width;
            Double.isNaN(d2);
            layoutParams.width = (int) (d2 * 0.29d);
            layoutParams = this.transimg1.getLayoutParams();
            d2 = height;
            Double.isNaN(d2);
            layoutParams.height = (int) (d2 * 0.21d);
            this.txt1.getLayoutParams().width = this.transimg1.getLayoutParams().width;
            this.txt1.getLayoutParams().height = this.transimg1.getLayoutParams().height;
            layoutParams = this.transimg11.getLayoutParams();
            d2 = width;
            Double.isNaN(d2);
            layoutParams.width = (int) (d2 * 0.33d);
            layoutParams = this.transimg11.getLayoutParams();
            d2 = height;
            Double.isNaN(d2);
            layoutParams.height = (int) (d2 * 0.27d);
        } else {
            this.droptxt.setTextSize(17.0f);
            this.shuffle.setTextSize(17.0f);
            this.txtcardname.setTextSize(18.0f);
            layoutParams = this.transimg1.getLayoutParams();
            d2 = width;
            Double.isNaN(d2);
            layoutParams.width = (int) (d2 * 0.29d);
            layoutParams = this.transimg1.getLayoutParams();
            d2 = height;
            Double.isNaN(d2);
            layoutParams.height = (int) (d2 * 0.21d);
            this.txt1.getLayoutParams().width = this.transimg1.getLayoutParams().width;
            this.txt1.getLayoutParams().height = this.transimg1.getLayoutParams().height;
            layoutParams = this.transimg11.getLayoutParams();
            d2 = width;
            Double.isNaN(d2);
            layoutParams.width = (int) (d2 * 0.33d);
            layoutParams = this.transimg11.getLayoutParams();
            d2 = height;
            Double.isNaN(d2);
            layoutParams.height = (int) (d2 * 0.27d);
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean shuffelcards() {
        if (this.shuffle_flag == 1) {
            newshuffel4();
            this.shuffle_flag++;
        }
        if (this.shuffle_flag == 2) {
            newshuffel5();
            this.shuffle_flag = 1;
        }
        return true;
    }

    public void newshuffel4() {
        int i = 0;
        String str = cardnames[0];
        for (int i2 = 0; i2 < 78; i2++) {
            if (i2 != 77) {
                String[] strArr = cardnames;
                strArr[i2] = strArr[i2 + 1];
            } else {
                cardnames[77] = str;
            }
        }
        while (i < 26) {
            img_row1[i].setTag(cardnames[i]);
            img_row2[i].setTag(cardnames[i + 26]);
            img_row3[i].setTag(cardnames[i + 52]);
            i++;
        }
    }

    public void newshuffel5() {
        String[] strArr = cardnames;
        int i = 0;
        String str = strArr[0];
        String str2 = strArr[1];
        for (int i2 = 0; i2 < 78; i2++) {
            if (i2 < 76) {
                String[] strArr2 = cardnames;
                strArr2[i2] = strArr2[i2 + 2];
            } else if (i2 == 76) {
                cardnames[76] = str;
            } else if (i2 == 77) {
                cardnames[77] = str2;
            }
        }
        while (i < 26) {
            img_row1[i].setTag(cardnames[i]);
            img_row2[i].setTag(cardnames[i + 26]);
            img_row3[i].setTag(cardnames[i + 52]);
            i++;
        }
    }

    private void animate() {
        int i = 10;
        for (int i2 = 0; i2 < 26; i2++) {
            TranslateAnimation translateAnimation = new TranslateAnimation(700.0f, 0.0f, 700.0f, 0.0f);
            translateAnimation.setDuration(750);
            translateAnimation.setStartOffset(i);
            img_row1[i2].startAnimation(translateAnimation);
            img_row2[i2].startAnimation(translateAnimation);
            img_row3[i2].startAnimation(translateAnimation);
            i += 20;
        }
    }

    public void onAnimationEnd(Animation animation) {
        if (this.firstcardtap.booleanValue()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("???????....>>>>");
            stringBuilder.append(this.cname1);
            String str = "";
            this.transimg11.setImageResource(getResources().getIdentifier(this.cname1.toLowerCase().replaceAll(" ", str).replaceAll("-", str), "drawable", getPackageName()));
            this.transimg11.setOnClickListener(null);
            this.txtcardname.setText(this.cardname1);
            this.tapcardcount++;
            System.gc();
        }
        if (this.tapcardcount == 1) {
            this.droptxt.setVisibility(View.INVISIBLE);
            this.droptxt.getLayoutParams().height = 0;
        }
    }

    private boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public void onBackPressed() {
        super.onBackPressed();
        this.handler.removeCallbacksAndMessages(null);
    }


    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

}
