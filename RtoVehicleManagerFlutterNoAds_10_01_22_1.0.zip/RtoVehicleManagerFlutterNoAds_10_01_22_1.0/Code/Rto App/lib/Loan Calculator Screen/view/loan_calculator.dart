import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:rto_app/Loan%20Calculator%20Screen/controller/loan_calculator_controller.dart';
import 'package:velocity_x/src/extensions/string_ext.dart';
import 'package:velocity_x/src/flutter/center.dart';
import 'package:velocity_x/src/flutter/padding.dart';
import 'package:velocity_x/src/flutter/widgets.dart';

class LoanCalculator extends StatefulWidget {
  const LoanCalculator({Key? key}) : super(key: key);

  @override
  _LoanCalculatorState createState() => _LoanCalculatorState();
}

class _LoanCalculatorState extends State<LoanCalculator> {
  LoanCalcController controller = Get.put(LoanCalcController());
  String? amount = null;
  String? interest = null;
  String? year = null;
  String? month = null;
  TextEditingController amountController = TextEditingController();
  TextEditingController interestController = TextEditingController();
  TextEditingController yearController = TextEditingController();
  TextEditingController monthController = TextEditingController();
  bool isCalculatedData = false;
  String selectedDate = DateTime.now().toString();
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Future.delayed(const Duration(milliseconds: 350), () {
          Navigator.pop(context);
        });
        return Future.value(false);
      },
      child: Material(
        child: SafeArea(
          child: Scaffold(
            backgroundColor: Theme.of(context).primaryColor,
            body: NestedScrollView(
              physics: BouncingScrollPhysics(),
              floatHeaderSlivers: true,
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return <Widget>[
                  SliverAppBar(
                    backgroundColor: Theme.of(context).primaryColor,
                    title: Text(
                      "Loan Calculator",
                      style: TextStyle(
                          fontSize: 15.5,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Bold"),
                    ).centered(),
                    leading: Container(
                      padding: EdgeInsets.all(10),
                      child: Material(
                        color: Colors.transparent,
                        shape: CircleBorder(),
                        clipBehavior: Clip.hardEdge,
                        child: IconButton(
                            padding: EdgeInsets.zero,
                            onPressed: () {
                              Future.delayed(const Duration(milliseconds: 350),
                                  () {
                                Navigator.pop(context);
                              });
                            },
                            icon: Hero(
                              tag: "loan",
                              transitionOnUserGestures: true,
                              child: Icon(
                                Icons.arrow_back_ios_rounded,
                                color: Theme.of(context).accentColor,
                                size: 20,
                              ).pOnly(left: 5),
                            )),
                      ),
                    ),
                    actions: [
                      IconButton(
                        onPressed: () {
                          Future.delayed(const Duration(milliseconds: 350), () {
                            Navigator.pop(context);
                          });
                        },
                        icon: Hero(
                            tag: "loan",
                            transitionOnUserGestures: true,
                            child: (Icon(
                              CupertinoIcons.home,
                              color: Theme.of(context).accentColor,
                              size: 24,
                            ))),
                        iconSize: 30,
                      ).pOnly(right: 8),
                    ],
                  )
                ];
              },
              body: Column(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      physics: BouncingScrollPhysics(),
                      child: Container(
                        color: Theme.of(context).primaryColor,
                        child: Container(
                            color: Theme.of(context).primaryColor,
                            child: Column(
                              children: [
                                SizedBox(
                                  child: Card(
                                    color: Theme.of(context).splashColor,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: GetBuilder<LoanCalcController>(
                                      builder: (controller) {
                                        return SizedBox(
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                  child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Expanded(
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsets.all(10),
                                                      child: Column(
                                                        children: [
                                                          SizedBox(
                                                            child: Text(
                                                              controller
                                                                  .monthlyEmi
                                                                  .toString(),
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                  fontSize: 15,
                                                                  color: Theme.of(
                                                                          context)
                                                                      .hintColor,
                                                                  fontFamily:
                                                                      "Circular Medium"),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            child: Text(
                                                              "Monthly EMI",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                  fontSize: 11,
                                                                  color: Color(
                                                                      0xff757381),
                                                                  fontFamily:
                                                                      "Circular Medium"),
                                                            ),
                                                          ).pOnly(top: 5)
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Align(
                                                    alignment: Alignment.center,
                                                    child: Container(
                                                      color: Colors.blueGrey,
                                                      height: 30,
                                                      width: 0.2,
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsets.all(10),
                                                      child: Column(
                                                        children: [
                                                          SizedBox(
                                                            child: Text(
                                                              controller
                                                                  .totalInterest
                                                                  .toString(),
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                  fontSize: 15,
                                                                  color: Theme.of(
                                                                          context)
                                                                      .hintColor,
                                                                  fontFamily:
                                                                      "Circular Medium"),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            child: Text(
                                                              "Total Interest",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                  fontSize: 11,
                                                                  color: Color(
                                                                      0xff757381),
                                                                  fontFamily:
                                                                      "Circular Medium"),
                                                            ),
                                                          ).pOnly(top: 5)
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Align(
                                                    alignment: Alignment.center,
                                                    child: Container(
                                                      color: Colors.blueGrey,
                                                      height: 30,
                                                      width: 0.2,
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsets.all(10),
                                                      child: Column(
                                                        children: [
                                                          SizedBox(
                                                            child: Text(
                                                              controller
                                                                  .totalPayble
                                                                  .toString(),
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                  fontSize: 15,
                                                                  color: Theme.of(
                                                                          context)
                                                                      .hintColor,
                                                                  fontFamily:
                                                                      "Circular Medium"),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            child: Text(
                                                              "Total Payble",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                  fontSize: 11,
                                                                  color: Color(
                                                                      0xff757381),
                                                                  fontFamily:
                                                                      "Circular Medium"),
                                                            ),
                                                          ).pOnly(top: 5)
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              )),
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ).pOnly(bottom: 15),
                                TextField(
                                  cursorColor: Color(0xff14835E),
                                  style: TextStyle(
                                      fontFamily: "Circular Medium",
                                      fontSize: 20,
                                      color: Theme.of(context).accentColor),
                                  autofocus: false,
                                  controller: amountController,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    WhitelistingTextInputFormatter.digitsOnly
                                  ],
                                  onChanged: (value) {
                                    setState(() {
                                      if (value.isEmpty) {
                                        amount = 'This should not be empty';
                                      } else {
                                        amount = null;
                                      }
                                    });
                                  },
                                  decoration: InputDecoration(
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Color(0xff14835E),
                                            width: 0.3),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Color(0xff14835E),
                                            width: 0.3),
                                      ),
                                      border: const OutlineInputBorder(),
                                      labelText: " Loan Amount ",
                                      labelStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 17,
                                          color:
                                              Theme.of(context).indicatorColor),
                                      hintStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 20,
                                          color:
                                              Theme.of(context).indicatorColor),
                                      hintText: "ex : 12,0000",
                                      errorStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 10,
                                          color: Colors.redAccent),
                                      errorText:
                                          amount /*controllers.lastReserve*/),
                                ).px(5).pOnly(top: 5),
                                TextField(
                                  cursorColor: Color(0xff14835E),
                                  style: TextStyle(
                                      fontFamily: "Circular Medium",
                                      fontSize: 20,
                                      color: Theme.of(context).accentColor),
                                  autofocus: false,
                                  controller: interestController,
                                  keyboardType: TextInputType.numberWithOptions(
                                      signed: true, decimal: true),
                                  onChanged: (value) {
                                    setState(() {
                                      if (value.isEmpty) {
                                        interest = 'This should not be empty';
                                      } else {
                                        interest = null;
                                      }
                                    });
                                  },
                                  decoration: InputDecoration(
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Color(0xff14835E),
                                            width: 0.3),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Color(0xff14835E),
                                            width: 0.3),
                                      ),
                                      border: OutlineInputBorder(),
                                      labelText: " Annual Interest Rate ( % ) ",
                                      labelStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 17,
                                          color:
                                              Theme.of(context).indicatorColor),
                                      hintStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 20,
                                          color:
                                              Theme.of(context).indicatorColor),
                                      hintText: "ex : 12.5",
                                      errorStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 10,
                                          color: Colors.redAccent),
                                      errorText:
                                          interest /*controllers.currentReserve*/),
                                  //controller: controller,
                                ).px(5).py(15),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      child: Padding(
                                        padding: EdgeInsets.all(5),
                                        child: TextField(
                                          cursorColor: Color(0xff14835E),
                                          style: TextStyle(
                                              fontFamily: "Circular Medium",
                                              fontSize: 20,
                                              color: Theme.of(context)
                                                  .accentColor),
                                          autofocus: false,
                                          controller: yearController,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: [
                                            WhitelistingTextInputFormatter
                                                .digitsOnly
                                          ],
                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Color(0xff14835E),
                                                  width: 0.3),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Color(0xff14835E),
                                                  width: 0.3),
                                            ),
                                            border: const OutlineInputBorder(),
                                            labelText: " Loan Period [ Year ] ",
                                            labelStyle: TextStyle(
                                                fontFamily: "Circular Medium",
                                                fontSize: 13,
                                                color: Theme.of(context)
                                                    .indicatorColor),
                                            hintStyle: TextStyle(
                                                fontFamily: "Circular Medium",
                                                fontSize: 20,
                                                color: Theme.of(context)
                                                    .indicatorColor),
                                            hintText:
                                                "ex : 2", /*controllers.totalPrice*/
                                          ),
                                          //controller: controller,
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: Padding(
                                        padding: EdgeInsets.all(5),
                                        child: TextField(
                                          cursorColor: Color(0xff14835E),
                                          style: TextStyle(
                                              fontFamily: "Circular Medium",
                                              fontSize: 20,
                                              color: Theme.of(context)
                                                  .accentColor),
                                          autofocus: false,
                                          controller: monthController,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: [
                                            WhitelistingTextInputFormatter
                                                .digitsOnly
                                          ],
                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Color(0xff14835E),
                                                  width: 0.3),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Color(0xff14835E),
                                                  width: 0.3),
                                            ),
                                            border: const OutlineInputBorder(),
                                            labelText:
                                                " Loan Period [ Month ] ",
                                            labelStyle: TextStyle(
                                                fontFamily: "Circular Medium",
                                                fontSize: 13,
                                                color: Theme.of(context)
                                                    .indicatorColor),
                                            hintStyle: TextStyle(
                                                fontFamily: "Circular Medium",
                                                fontSize: 20,
                                                color: Theme.of(context)
                                                    .indicatorColor),
                                            hintText: "ex : 16",
                                            //controller: controller,
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ).pOnly(bottom: 5),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 45,
                                      width: 130,
                                      child: Material(
                                        color: Theme.of(context).splashColor,
                                        child: Ink(
                                          decoration: BoxDecoration(),
                                          child: InkWell(
                                            customBorder:
                                                RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.only(
                                                            topRight: Radius
                                                                .circular(8),
                                                            bottomRight:
                                                                Radius.circular(
                                                                    8))),
                                            splashColor: Colors.black,
                                            onTap: () {
                                              FocusScope.of(context).unfocus();
                                              if (amountController
                                                  .text.isEmpty) {
                                                setState(() {
                                                  amount =
                                                      "This should not be empty";
                                                });
                                              }
                                              if (interestController
                                                  .text.isEmpty) {
                                                setState(() {
                                                  interest =
                                                      "This should not be empty";
                                                });
                                              }
                                              if (yearController.text.isEmpty &&
                                                  monthController
                                                      .text.isNotEmpty) {
                                                controller.calculation(
                                                    amountController.text,
                                                    interestController.text,
                                                    "0",
                                                    monthController.text);
                                              }
                                              if (monthController
                                                      .text.isEmpty &&
                                                  yearController
                                                      .text.isNotEmpty) {
                                                controller.calculation(
                                                    amountController.text,
                                                    interestController.text,
                                                    yearController.text,
                                                    "0");
                                              }

                                              if (yearController.text.isEmpty &&
                                                  monthController
                                                      .text.isEmpty) {
                                                ScaffoldMessenger.of(context)
                                                    .showSnackBar(SnackBar(
                                                        backgroundColor:
                                                            Theme.of(
                                                                    context)
                                                                .focusColor,
                                                        content:
                                                            "Please enter year or months !"
                                                                .text
                                                                .color(Colors
                                                                    .white)
                                                                .make(),
                                                        behavior:
                                                            SnackBarBehavior
                                                                .floating,
                                                        duration: Duration(
                                                            milliseconds:
                                                                500)));
                                              }

                                              if (amountController
                                                      .text.isNotEmpty &&
                                                  interestController
                                                      .text.isNotEmpty &&
                                                  yearController
                                                      .text.isNotEmpty &&
                                                  monthController
                                                      .text.isNotEmpty) {
                                                controller.calculation(
                                                    amountController.text,
                                                    interestController.text,
                                                    yearController.text,
                                                    monthController.text);
                                              }
                                            },
                                            child: Center(
                                              child: Text(
                                                "Calculate",
                                                style: TextStyle(
                                                    color: Theme.of(context)
                                                        .accentColor,
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                        .cornerRadius(8)
                                        .pOnly(left: 10, right: 10)
                                        .py(15),
                                    Container(
                                      height: 45,
                                      width: 130,
                                      child: Material(
                                        color: Theme.of(context).splashColor,
                                        child: Ink(
                                          decoration: BoxDecoration(),
                                          child: InkWell(
                                            customBorder:
                                                RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.only(
                                                            topRight: Radius
                                                                .circular(8),
                                                            bottomRight:
                                                                Radius.circular(
                                                                    8))),
                                            splashColor: Colors.black,
                                            onTap: () {
                                              setState(() {
                                                amountController.text = "";
                                                interestController.text = "";
                                                yearController.text = "";
                                                monthController.text = "";
                                                controller.monthlyEmi = "00";
                                                controller.totalInterest = "00";
                                                controller.totalPayble = "00";
                                              });
                                            },
                                            child: Center(
                                              child: Text(
                                                "Clear",
                                                style: TextStyle(
                                                    color: Theme.of(context)
                                                        .accentColor,
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                        .cornerRadius(8)
                                        .pOnly(left: 10, right: 10)
                                        .py(15)
                                  ],
                                ),
                              ],
                            )).px(20).py(20),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
