package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.View;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

public class x5  implements View.OnClickListener
{
    public final FestivalDetailActivity_New n;

    public x5(final FestivalDetailActivity_New n) {
        this.n = n;
    }

    public void onClick(final View view) {
        this.n.imgBlur.setVisibility(View.GONE);
        this.n.m1.dismiss();
    }
}
