package com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.Room.MileageDatabase;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.adapter.VehicleMileageAdapter;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.model.Mileage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import org.jetbrains.annotations.NotNull;

public class VehicleMileageActivity extends AppCompatActivity implements View.OnClickListener {
    private Activity activity=VehicleMileageActivity.this;
    private ImageView iv_addmileage;
    private LinearLayout ll_empty;
    private RecyclerView rvmileage;
    private ImageView iv_back;
    private VehicleMileageAdapter vehicleMileageAdapter;
    private List<Mileage> mileagelist=new ArrayList<>();
    private TextView title_tv;
    private MileageDatabase mileageDatabase;
    private Boolean darkMode=false;

    GGAdview gg_banner;

    private int id;
    public GGInterstitialAd interstitialAd;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_mileage);
        mileagelist = new ArrayList<>();
        mileageDatabase = Room.databaseBuilder(VehicleMileageActivity.this, MileageDatabase.class, "MileageDatabase").allowMainThreadQueries().build();
        BindView();
        SetData();
        BannerAds();
        InterAds();
        DarkTheame darkTheame=new DarkTheame(VehicleMileageActivity.this);
        if(darkTheame.modeData().equals("nightMode"))
        {
            darkMode=true;
            setupDarkMode();
        }
    }

    private void BannerAds() {
        gg_banner= findViewById(R.id.ggAdView_banner);
        gg_banner.setUnitId(getResources().getString(R.string.BannerAd));
        gg_banner.loadAd(new AdLoadCallback(){
                             @Override
                             public void onReadyForRefresh() {

                             }
                             @Override
                             public void onUiiClosed() {

                             }
                             @Override
                             public void onUiiOpened() {

                             }
                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds(){
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity,getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 1:
                        startActivity(new Intent(VehicleMileageActivity.this, MainActivity.class));
                        finish();
                        break;
                    case 2:
                        startActivity(new Intent(VehicleMileageActivity.this, VehicleMilageDetailActivity.class));
                        finish();
                        break;
                }
            }
            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed (AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }

    private void setupDarkMode() {
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        ll_empty.setBackgroundResource(R.drawable.ic_vehicle_mileage_bg_dark);
    }

    private void SetData() {
        mileagelist=mileageDatabase.mileageDao().getMileageData();
        Collections.reverse(mileagelist);
        vehicleMileageAdapter = new VehicleMileageAdapter(VehicleMileageActivity.this,darkMode, mileagelist);
        rvmileage.setLayoutManager(new GridLayoutManager(this, 1));
        rvmileage.setAdapter(vehicleMileageAdapter);
        if (mileagelist != null && !mileagelist.isEmpty())
        {
            ll_empty.setVisibility(View.GONE);
            rvmileage.setVisibility(View.VISIBLE);
        } else
        {
            rvmileage.setVisibility(View.GONE);
            ll_empty.setVisibility(View.VISIBLE);
        }
    }

    private void BindView() {
        iv_addmileage = findViewById(R.id.iv_addmileage);
        ll_empty = findViewById(R.id.ll_emptyLayout);
        rvmileage = findViewById(R.id.recyclerview_mileage);
        iv_back = findViewById(R.id.iv_back);
        title_tv=findViewById(R.id.title_tv);

        iv_addmileage.setOnClickListener(this);
        iv_back.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_addmileage:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 2;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(VehicleMileageActivity.this, VehicleMilageDetailActivity.class));
                    finish();
                }
                break;

            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 1;
            interstitialAd.show();
        } else {
            startActivity(new Intent(VehicleMileageActivity.this, MainActivity.class));
            finish();
            super.onBackPressed();
        }
    }
}