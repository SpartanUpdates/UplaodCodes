package com.esc.photoslideshow.util;

public class AsynkModel {
    public String DisplayName;
    public String Uri;
    public ConcDownloadTask mTask;
    public String pos;
}
