package com.kotlinz.festivalstorymaker.Listener.festival;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

public class w5 implements View.OnClickListener {
    public final EditText n;
    public final EditText o;
    public final EditText p;
    public final EditText q;
    public final EditText r;
    public final FestivalDetailActivity_New s;

    public w5(final FestivalDetailActivity_New s, final EditText n, final EditText o, final EditText p6, final EditText q, final EditText r) {
        this.s = s;
        this.n = n;
        this.o = o;
        this.p = p6;
        this.q = q;
        this.r = r;
    }

    public void onClick(final View view) {
        EditText p = null;
        String string = null;
        EditText editText;
        Toast.makeText(s, "Business Details Called", Toast.LENGTH_SHORT).show();
        if (Utils.p0(this.n) <= 0) {
            editText = this.n;
        } else if (Utils.p0(this.o) <= 0) {
            editText = this.o;
        } else if (Utils.p0(this.p) <= 0) {
            editText = this.p;
        } else {
            if (!Utils.l0(this.p)) {
                p = this.p;
                string = this.s.getResources().getString(R.string.enter_valid_email);
//                    break Label_0132;
            }
            if (Utils.p0(this.q) <= 0) {
                editText = this.q;
            } else {
                if (Utils.p0(this.r) > 0) {
                    Utils.L((Context) this.s, this.o);
                    FestivalDetailActivity_New.y0(this.s, this.n.getText().toString(), this.o.getText().toString(), this.p.getText().toString(), this.q.getText().toString(), this.r.getText().toString());
                    return;
                }
                editText = this.r;
            }
        }
        final String string2 = editText.getHint().toString();
        p = editText;
        string = string2;
        p.setError(string);

    }
}
