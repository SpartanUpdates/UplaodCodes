package com.root.bridge;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.View;

import com.Pulse.VideoStatus.Activity.CustomizeTextActivity;
import com.Pulse.VideoStatus.Activity.HomeActivity;
import com.Pulse.VideoStatus.Activity.ImageSelectActivity;
import com.Pulse.VideoStatus.Activity.OnlineSongActivity;
import com.Pulse.VideoStatus.Activity.VideoPlayerActivity;
import com.Pulse.VideoStatus.AllData.GetUrl;
import com.Pulse.VideoStatus.Extra.Utils;
import com.Pulse.VideoStatus.UnityPlayerActivity;
import com.Pulse.VideoStatus.application.MyApplication;

import java.io.File;

public class AndroidPluginClass {

    public static void LuanchApp(Context context) {
        if (UnityPlayerActivity.alertDialog != null && UnityPlayerActivity.alertDialog.isShowing()) {
            UnityPlayerActivity.alertDialog.dismiss();
        }
        Intent intent = new Intent(context, HomeActivity.class);
        context.startActivity(intent);
    }

    public static void AddSound(Context context) {
        context.startActivity(new Intent(context, OnlineSongActivity.class));
    }

    public static void CallGallery(Context context, String str) {
        MyApplication.IsSelectImageFrom = false;
        MyApplication.IS_EDITIMAGE = 0;
        MyApplication.TotalSelectedImage = Integer.parseInt(str);
        MyApplication.getInstance().getSelectedImageslist().clear();
        MyApplication.getInstance().getCropImages().clear();
        Intent intent = new Intent(context, ImageSelectActivity.class);
        intent.putExtra("NoofImage", Integer.parseInt(str));
        context.startActivity(intent);
    }

    public static void EditInput(Context context, String str) {
        Intent intent = new Intent(context, CustomizeTextActivity.class);
        intent.putExtra("JsonStr", str);
        context.startActivity(intent);
    }


    public static void AfterAdsDoneAction(Context context) {
        Intent intent = new Intent(context, VideoPlayerActivity.class);
        intent.putExtra("VideoUrl", AppUsages.VideoOutputFullPath);
        intent.putExtra("VideoPosition", 0);
        intent.putExtra("AllVideoList", Utils.getAllCreatedVideoList(context));
        intent.putExtra("IsVideoFromAndroidList", false);
        context.startActivity(intent);
        RefereshVideoList(context, AppUsages.VideoOutputFullPath);
        AppUsages.LastTime = 0.0f;
        DeleteCropImages();
    }


    public static void LoadVideo(Context context) {
        AfterAdsDoneAction(context);
    }

    public static void DeleteCropImages() {
        Utils util = new Utils();
        String path = util.getOutputPath() + "CropTempImg" + File.separator;
        File folder = new File(path);
        util.deleteRecursive(folder);
    }

    public static void RefereshVideoList(Context cntx, String path) {
        try {
            android.media.MediaScannerConnection.scanFile(cntx,
                    new String[]{path},
                    new String[]{"video/mp4"},
                    new android.media.MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void createVideo(Context context, String videoInputName, String VideoOutputName) {
        AppUsages.AudioVideoShort(context, videoInputName, VideoOutputName);
    }

    public static void prepareSongForCreateVideo(Context context, String VideoOutNameMute, String fromSdcard, String AudioInputpath, String VideoInputNameUnited) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.GONE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        AppUsages.AddSongTOVideo(context, VideoOutNameMute, fromSdcard, AudioInputpath, VideoInputNameUnited);
    }

}
