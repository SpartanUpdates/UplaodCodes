package com.vidsoft.videostatusmaker.Others.gallery;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.vidsoft.videostatusmaker.kprogresshud.KProgressHUD;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.vidsoft.videostatusmaker.Activity.ActivityViewAlImages;
import com.vidsoft.videostatusmaker.Utils.RoundedImageView;
import com.vidsoft.videostatusmaker.Utils.Utils;
import com.vidsoft.videostatusmaker.adapter.GridViewAdapter;

public class ActivityAllPhotos extends Activity {

    LinearLayout AddLinearLayout;
    Typeface typeface1;
    TextView tvTitle;
    ImageView ivBack;
    TextView tvDone;
    Typeface typeface;
    public static Activity activity;
    private GridView gridView;
    ImageLoader imageLoader;
    int intPosition;
    TextView tvListtotal;
    GridViewAdapter gridViewAdapter;

    private KProgressHUD hud;
    public InterstitialAd mInterstitialAd;

    private void initImageLoader() {
        (this.imageLoader = ImageLoader.getInstance()).init(new ImageLoaderConfiguration.Builder(this).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).build()).build());
    }

    void layoutAdd(final String s) {
        final View inflate = LayoutInflater.from(this.getApplicationContext()).inflate(R.layout.trail, null, false);
        final RoundedImageView roundedImageView = inflate.findViewById(R.id.imgtrail);
        final ImageView imageView = inflate.findViewById(R.id.closetrail);
        final DisplayImageOptions build = new DisplayImageOptions.Builder().build();
        final ImageLoader instance = ImageLoader.getInstance();
        final StringBuilder sb = new StringBuilder();
        sb.append("file:///");
        sb.append(s);
        instance.displayImage(sb.toString(), roundedImageView, build);
        roundedImageView.setCornerRadius(this.getResources().getDisplayMetrics().widthPixels * 25 / 1080);
        roundedImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(this.getResources().getDisplayMetrics().widthPixels * 60 / 1080, this.getResources().getDisplayMetrics().heightPixels * 60 / 1920);
        layoutParams.addRule(11);
        imageView.setLayoutParams(layoutParams);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                Utils.photos.remove(ActivityAllPhotos.this.AddLinearLayout.indexOfChild(inflate));
                ActivityAllPhotos.this.gridViewAdapter.notifyDataSetChanged();
                final TextView listtotal = ActivityAllPhotos.this.tvListtotal;
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(Utils.photos.size());
                sb.append("");
                listtotal.setText(sb.toString());
                ActivityAllPhotos.this.AddLinearLayout.removeView(inflate);
            }
        });
        this.AddLinearLayout.addView(inflate, 0);
        final TextView listtotal = this.tvListtotal;
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(Utils.photos.size());
        sb2.append("");
        listtotal.setText(sb2.toString());
    }



    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitialAdmob));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                startActivity(new Intent(ActivityAllPhotos.this.getApplicationContext(), ActivityViewAlImages.class));
                RequestInterstitial();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.interstitialAdmob));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_folder);
        this.getWindow().addFlags(1024);
        this.initImageLoader();
        ActivityAllPhotos.activity = this;
        this.ivBack = this.findViewById(R.id.back);
        this.gridView = this.findViewById(R.id.gv_folder);
        this.intPosition = this.getIntent().getIntExtra("value", 0);
        this.gridViewAdapter = new GridViewAdapter(this, ActivityImageFolder.AllFolderImages, this.intPosition);
        this.gridView.setNumColumns(3);
        this.gridView.setAdapter(this.gridViewAdapter);
        this.AddLinearLayout = this.findViewById(R.id.addlay);
        this.tvDone = this.findViewById(R.id.done);
        this.tvListtotal = this.findViewById(R.id.listtotal);
        (this.tvTitle = this.findViewById(R.id.title)).setText(ActivityImageFolder.AllFolderImages.get(this.intPosition).getStr_folder());
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.typeface1 = Typeface.createFromAsset(this.getAssets(), "Montserrat-Light_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        this.tvTitle.setTextSize(18.0f);
        this.tvListtotal.setTypeface(this.typeface1);
        interstitialAd();
        clickEvents();
    }

    private void clickEvents() {
        this.gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                final String s = ActivityImageFolder.AllFolderImages.get(ActivityAllPhotos.this.intPosition).getAl_imagepath().get(n);
                int i = 0;
                boolean b = false;
                while (i < Utils.photos.size()) {
                    if (Utils.photos.get(i).equals(ActivityImageFolder.AllFolderImages.get(ActivityAllPhotos.this.intPosition).getAl_imagepath().get(n))) {
                        Utils.photos.remove(i);
                        ActivityAllPhotos.this.AddLinearLayout.removeViewAt(i);
                        final TextView listtotal = ActivityAllPhotos.this.tvListtotal;
                        final StringBuilder sb = new StringBuilder();
                        sb.append("");
                        sb.append(Utils.photos.size());
                        sb.append("");
                        listtotal.setText(sb.toString());
                        b = true;
                    }
                    ++i;
                }
                if (!b) {
                    if (Utils.photos.size() < 8) {
                        Utils.photos.add(0, s);
                        ActivityAllPhotos.this.layoutAdd(s);
                    } else {
                        Toast.makeText(ActivityAllPhotos.this, "Max 8 Images", Toast.LENGTH_SHORT).show();
                    }
                }
                ActivityAllPhotos.this.gridViewAdapter.notifyDataSetChanged();
            }
        });
        this.tvDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (Utils.photos.size() == 8) {
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        try {
                            hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                            hud.show();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();
                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    hud.dismiss();
                                } catch (IllegalArgumentException e) {
                                    e.printStackTrace();

                                } catch (NullPointerException e2) {
                                    e2.printStackTrace();
                                } catch (Exception e3) {
                                    e3.printStackTrace();
                                }
                                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                    mInterstitialAd.show();
                                }
                            }
                        }, 2000);
                    } else {
                        ActivityAllPhotos.this.startActivity(new Intent(ActivityAllPhotos.this.getApplicationContext(), ActivityViewAlImages.class));
                    }

                    return;
                }
                Toast.makeText(ActivityAllPhotos.this.getApplicationContext(), "Add 8 pics", Toast.LENGTH_SHORT).show();
            }
        });
        this.ivBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityAllPhotos.this.onBackPressed();
            }
        });
    }


    protected void onResume() {
        this.AddLinearLayout.removeAllViews();
        final TextView listtotal = this.tvListtotal;
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(Utils.photos.size());
        sb.append("");
        listtotal.setText(sb.toString());
        for (int i = Utils.photos.size() - 1; i >= 0; --i) {
            this.layoutAdd(Utils.photos.get(i));
        }
        super.onResume();
    }
}
