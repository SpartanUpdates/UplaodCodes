package com.vidsoft.collagemaker.Utils;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.OnItemTouchListener;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;

public class RecyclerItemClickListener
  implements OnItemTouchListener
{
  GestureDetector mGestureDetector;
  private OnItemClickListener mListener;

  public RecyclerItemClickListener(Context paramContext, OnItemClickListener paramOnItemClickListener)
  {
    this.mListener = paramOnItemClickListener;
    this.mGestureDetector = new GestureDetector(paramContext, new SimpleOnGestureListener()
    {
      public boolean onSingleTapUp(MotionEvent paramMotionEvent)
      {
        return true;
      }
    });
  }

  public boolean onInterceptTouchEvent(RecyclerView paramRecyclerView, MotionEvent paramMotionEvent)
  {
    View localView = paramRecyclerView.findChildViewUnder(paramMotionEvent.getX(), paramMotionEvent.getY());
    if ((localView != null) && (this.mListener != null) && (this.mGestureDetector.onTouchEvent(paramMotionEvent)))
      this.mListener.onItemClick(localView, paramRecyclerView.getChildAdapterPosition(localView));
    return false;
  }

  public void onRequestDisallowInterceptTouchEvent(boolean paramBoolean)
  {
  }

  public void onTouchEvent(RecyclerView paramRecyclerView, MotionEvent paramMotionEvent)
  {
  }

  public static abstract interface OnItemClickListener
  {
    public abstract void onItemClick(View paramView, int paramInt);
  }
}