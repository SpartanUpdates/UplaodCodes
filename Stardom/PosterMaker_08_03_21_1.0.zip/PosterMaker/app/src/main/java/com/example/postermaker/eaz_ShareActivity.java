package com.example.postermaker;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.example.postermaker.kprogresshud.KProgressHUD;
import com.example.postermaker.savelayout.eaz_Save;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.util.List;

public class eaz_ShareActivity extends AppCompatActivity implements OnClickListener {

    Activity activity = eaz_ShareActivity.this;
    Button btn_feedback;
    Button btn_ratenow;
    ImageView facebook;
    ImageView imageView;
    ImageView imghome;
    ImageView instagram;
    ImageView more;

    ImageView whatsapp;
    ImageView img_back;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.eaz_activity_share);

        ImageView imageView = (ImageView) findViewById(R.id.img);
        this.imageView = imageView;
        imageView.setImageURI(Uri.parse(String.valueOf(new File(eaz_Save.fileTosave.toString()))));
        this.facebook = (ImageView) findViewById(R.id.facebook);
        this.instagram = (ImageView) findViewById(R.id.instagram);
        this.whatsapp = (ImageView) findViewById(R.id.whatsapp);
        this.more = (ImageView) findViewById(R.id.more);
        this.imghome = (ImageView) findViewById(R.id.imghome);
        img_back = findViewById(R.id.img_back);
        this.facebook.setOnClickListener(this);
        this.instagram.setOnClickListener(this);
        this.whatsapp.setOnClickListener(this);
        this.more.setOnClickListener(this);
        this.imghome.setOnClickListener(this);
        this.img_back.setOnClickListener(this);
        interstitialAd();
        BannerAds();
    }

    public void onClick(View view) {

        StringBuilder stringBuilder;

        switch (view.getId()) {

            case R.id.facebook:

                Intent facebookIntent = new Intent(Intent.ACTION_SEND);
                facebookIntent.setType("image/*");
                facebookIntent.setPackage("com.facebook.katana");
                facebookIntent.putExtra(Intent.EXTRA_TEXT, "The text you wanted to share");
                facebookIntent.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(eaz_ShareActivity.this, getPackageName()+".provider", eaz_Save.fileTosave));
                facebookIntent.setType("image/*");
                facebookIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivity(facebookIntent);
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(eaz_ShareActivity.this, "Facebook have not been installed", Toast.LENGTH_LONG).show();
                }

                return;
            case R.id.imghome:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                   GotoHome();
                }
                return;
            case R.id.img_back:
                GotoHome();
                return;
            case R.id.instagram:

                Intent instagramIntent = new Intent(Intent.ACTION_SEND);
                instagramIntent.setType("image/*");
                instagramIntent.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(eaz_ShareActivity.this, getPackageName()+".provider", eaz_Save.fileTosave));
                instagramIntent.setPackage("com.instagram.android");
                PackageManager packManager = getPackageManager();
                List<ResolveInfo> resolvedInfoList = packManager.queryIntentActivities(instagramIntent, PackageManager.MATCH_DEFAULT_ONLY);

                boolean resolved = false;
                for (ResolveInfo resolveInfo : resolvedInfoList) {
                    if (resolveInfo.activityInfo.packageName.startsWith("com.instagram.android")) {
                        instagramIntent.setClassName(
                                resolveInfo.activityInfo.packageName,
                                resolveInfo.activityInfo.name);
                        resolved = true;
                        break;
                    }
                }
                if (resolved) {
                    startActivity(instagramIntent);
                } else {
                    Toast.makeText(eaz_ShareActivity.this, "Instagram App is not installed", Toast.LENGTH_LONG).show();
                }

               /* intent = new Intent();
                intent.setAction(str10);
                intent.putExtra(str9, str8);
                stringBuilder = new StringBuilder();
                stringBuilder.append(str6);
                stringBuilder.append(getString(R.string.app_name));
                stringBuilder.append(str5);
                stringBuilder.append(getPackageName());
                intent.putExtra(str7, stringBuilder.toString());
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(getApplicationContext().getPackageName());
                stringBuilder2.append(str4);
                intent.putExtra(str3, FileProvider.getUriForFile(this, stringBuilder2.toString(), eaz_Save.fileTosave));
                intent.setType(str2);
                intent.setPackage("com.instagram.android");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(Intent.createChooser(intent, str));*/

                return;
            case R.id.more:

                eaz_ShareActivity eaz_galleryadapter = eaz_ShareActivity.this;
                stringBuilder = new StringBuilder();
                stringBuilder.append(eaz_ShareActivity.this.getResources().getString(R.string.app_name));
                stringBuilder.append(" Created By :\"https://play.google.com/store/apps/details?id="+getPackageName());
                eaz_galleryadapter.shareImage(stringBuilder.toString(), String.valueOf(eaz_Save.fileTosave));

                return;
            case R.id.whatsapp:

                Intent whatsappIntent = new Intent(Intent.ACTION_SEND);
                whatsappIntent.setType("image/*");
                whatsappIntent.setPackage("com.whatsapp");
                whatsappIntent.putExtra(Intent.EXTRA_TEXT, "The text you wanted to share");
                whatsappIntent.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(eaz_ShareActivity.this, getPackageName()+".provider", eaz_Save.fileTosave));
                whatsappIntent.setType("image/*");
                whatsappIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivity(whatsappIntent);
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(eaz_ShareActivity.this, "Whatsapp have not been installed", Toast.LENGTH_LONG).show();
                }


                return;
            default:
                return;
        }
    }

    private void GotoHome()
    {
        startActivity(new Intent(eaz_ShareActivity.this, eaz_MainActivity.class));
        finish();
    }

    public static String getDeviceName() {
        String str = Build.MANUFACTURER;
        String str2 = Build.MODEL;
        if (str2.startsWith(str)) {
            return capitalize(str2);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(capitalize(str));
        stringBuilder.append(" ");
        stringBuilder.append(str2);
        return stringBuilder.toString();
    }

    private static String capitalize(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        String str2 = "";
        Object obj = 1;
        for (char c : str.toCharArray()) {
            if (obj == null || !Character.isLetter(c)) {
                if (Character.isWhitespace(c)) {
                    obj = 1;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str2);
                stringBuilder.append(c);
                str2 = stringBuilder.toString();
            } else {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str2);
                stringBuilder2.append(Character.toUpperCase(c));
                str2 = stringBuilder2.toString();
                obj = null;
            }
        }

        return str2;
    }


    public void onBackPressed() {
        finish();
    }

    public void shareImage(final String str, String str2) {
        MediaScannerConnection.scanFile(eaz_ShareActivity.this, new String[]{str2}, null, new MediaScannerConnection.OnScanCompletedListener() {
            public void onScanCompleted(String str, Uri uri) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_TEXT, str);
                intent.putExtra(Intent.EXTRA_STREAM, uri);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                eaz_ShareActivity.this.startActivity(Intent.createChooser(intent, "Share Image"));
            }
        });
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdmobInterstitialId));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        GotoHome();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdmobInterstitialId));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdmobBannerId));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
