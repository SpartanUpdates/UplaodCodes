package com.kotlinz.festivalstorymaker.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kotlinz.festivalstorymaker.R;

public class VideoPlayerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);
    }
}