package com.kotlinz.festivalstorymaker.Download;


import android.content.Context;
import android.os.Environment;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Model.ZoomCollage.CategoryWiseData.ZoomCollageCategoryWiseData;
import com.liulishuo.okdownload.DownloadTask;
import com.liulishuo.okdownload.SpeedCalculator;
import com.liulishuo.okdownload.StatusUtil;
import com.liulishuo.okdownload.core.Util;
import com.liulishuo.okdownload.core.breakpoint.BlockInfo;
import com.liulishuo.okdownload.core.breakpoint.BreakpointInfo;
import com.liulishuo.okdownload.core.cause.EndCause;
import com.liulishuo.okdownload.core.listener.DownloadListener4WithSpeed;
import com.liulishuo.okdownload.core.listener.assist.Listener4SpeedAssistExtend;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;


public class ZoomCollageThemeDownload {
    public static DownloadTask SongDownloadTask;
    private Context context;
    ZoomCollageCategoryWiseData categoryWiseData;
    private String ThemeName;


    public ZoomCollageThemeDownload(Context context, String ThemeUrl, String ThemeName, ZoomCollageCategoryWiseData categoryWiseData) {
        this.context = context;
        this.ThemeName = ThemeName;
        this.categoryWiseData = categoryWiseData;
        initTaskTheme(ThemeUrl);
        initStatusTheme();
        initActionTheme();
    }

    private void initTaskTheme(String URL) {
        final File parentFile = new File(Utils.INSTANCE.getThemeFolderPath(context) + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory());
        SongDownloadTask = new DownloadTask.Builder(URL, parentFile)
                .setFilename(ThemeName)
                .setMinIntervalMillisCallbackProcess(16)
                .setPassIfAlreadyCompleted(false)
                .build();
    }

    private void initStatusTheme() {
        final StatusUtil.Status status = StatusUtil.getStatus(SongDownloadTask);
        if (status == StatusUtil.Status.COMPLETED) {
        }

        final BreakpointInfo info = StatusUtil.getCurrentInfo(SongDownloadTask);
        if (info != null) {

        }
    }

    private void initActionTheme() {
        final boolean started = SongDownloadTask.getTag() != null;
        if (started) {
            SongDownloadTask.cancel();
        } else {
            startTask();
            SongDownloadTask.setTag("mark-SongDownloadTask-started");
        }
    }

    private void startTask() {
        SongDownloadTask.enqueue(new DownloadListener4WithSpeed() {
            private long totalLength;
            private String readableTotalLength;

            @Override
            public void taskStart(@NonNull DownloadTask task) {
            }

            @Override
            public void infoReady(@NonNull DownloadTask task, @NonNull BreakpointInfo info,
                                  boolean fromBreakpoint,
                                  @NonNull Listener4SpeedAssistExtend.Listener4SpeedModel model) {
                totalLength = info.getTotalLength();
                readableTotalLength = Util.humanReadableBytes(totalLength, true);
            }

            @Override
            public void connectStart(@NonNull DownloadTask task, int blockIndex,
                                     @NonNull Map<String, List<String>> requestHeaders) {
            }

            @Override
            public void connectEnd(@NonNull DownloadTask task, int blockIndex, int responseCode,
                                   @NonNull Map<String, List<String>> responseHeaders) {
            }

            @Override
            public void progressBlock(@NonNull DownloadTask task, int blockIndex,
                                      long currentBlockOffset,
                                      @NonNull SpeedCalculator blockSpeed) {

            }

            @Override
            public void progress(@NonNull DownloadTask task, long currentOffset,
                                 @NonNull SpeedCalculator taskSpeed) {
                int percentage = (int) (currentOffset * 100 / totalLength);
            }

            @Override
            public void blockEnd(@NonNull DownloadTask task, int blockIndex, BlockInfo info,
                                 @NonNull SpeedCalculator blockSpeed) {
            }

            @Override
            public void taskEnd(@NonNull DownloadTask task, @NonNull EndCause cause,
                                @Nullable Exception realCause,
                                @NonNull SpeedCalculator taskSpeed) {
                task.setTag(null);
                if (cause == EndCause.CANCELED) {
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath(context) + File.separator + task.getFilename());
                } else if (cause == EndCause.ERROR) {
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath(context) + File.separator + task.getFilename());
                }
                if (cause == EndCause.COMPLETED) {
                    try {
                        unzipTheme(Utils.INSTANCE.getThemeFolderPath(context) + File.separator + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + task.getFilename(), Utils.INSTANCE.getThemeFolderPath(context) + File.separator + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    public void unzipTheme(String zipFilePath, String destDirectory) throws IOException {
        File destDir = new File(destDirectory);
        if (!destDir.exists()) {
            destDir.mkdir();
        }
        ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
        ZipEntry entry = zipIn.getNextEntry();
        // iterates over entries in the zip filePath
        while (entry != null) {
            String filePath = destDirectory + File.separator + entry.getName();
            if (!entry.isDirectory()) {
                // if the entry is a filePath, extracts it
                extractFile(zipIn, filePath);
            } else {
                // if the entry is a directory, make the directory
                File dir = new File(filePath);
                dir.mkdir();
            }
            zipIn.closeEntry();
            entry = zipIn.getNextEntry();
        }
        zipIn.close();
    }

    private static final int BUFFER_SIZE = 4096;

    private void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
        byte[] bytesIn = new byte[BUFFER_SIZE];
        int read = 0;
        while ((read = zipIn.read(bytesIn)) != -1) {
            bos.write(bytesIn, 0, read);
        }
        bos.close();
    }

    private void DeleteFileIfInterupt(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            file.delete();
        }
    }
}
