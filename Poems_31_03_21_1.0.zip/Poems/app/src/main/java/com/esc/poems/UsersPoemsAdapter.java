package com.esc.poems;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsersPoemsAdapter extends RecyclerView.Adapter<UsersPoemsAdapter.ViewHolder> {
    private final Context context;
    private Editor editor1;
    private final List<Object> mRecyclerViewItems_v;
    private String msg2;
    private int nooftimes_resultviewd = 0;
    private final ArrayList<Integer> pid;
    private final ArrayList<String> poems;
    private final SharedPreferences sharedPreferences1;
    private final Typeface type1;
    private final ArrayList<String> userslocation;
    private final ArrayList<String> usersname;
    private final int ww;

    public class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public Button copytxtbtn;
        public TextView location;
        public TextView name;
        public TextView poemtxt;
        public Button sharetxtbtn;

        public ViewHolder(View view) {
            super(view);
            this.poemtxt = view.findViewById(R.id.poemstxt);
            this.name = view.findViewById(R.id.username);
            this.location = view.findViewById(R.id.userlocation);
            this.sharetxtbtn = view.findViewById(R.id.sharetxt);
            this.copytxtbtn = view.findViewById(R.id.copytxt);
        }
    }

    public UsersPoemsAdapter(Context context, int i, ArrayList<String> arrayList, ArrayList<Integer> arrayList2, ArrayList<String> arrayList3, ArrayList<String> arrayList4, List<Object> list) {
        this.mRecyclerViewItems_v = list;
        this.ww = i;
        this.poems = arrayList;
        this.pid = arrayList2;
        this.usersname = arrayList3;
        this.userslocation = arrayList4;
        this.type1 = Typeface.createFromAsset(context.getAssets(), "fonts/roboto_light.ttf");
        this.context = context;
        this.sharedPreferences1 = context.getSharedPreferences("MYPREFERENCE", 0);
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        return new ViewHolder(from.inflate(R.layout.userspoems_list, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        this.editor1 = this.sharedPreferences1.edit();
        viewHolder.poemtxt.setTypeface(this.type1);
        viewHolder.poemtxt.setText(Html.fromHtml(this.poems.get(i)));
        viewHolder.poemtxt.setTag(Integer.valueOf(i));
        viewHolder.name.setTypeface(this.type1, Typeface.ITALIC);
        TextView textView4 = viewHolder.name;
        StringBuilder stringBuilder2 = new StringBuilder();
        String str = "++++++++++";
        str = "- ";
        stringBuilder2.append(str);
        stringBuilder2.append(this.usersname.get(i));
        textView4.setText(Html.fromHtml(stringBuilder2.toString()));
        viewHolder.name.setTag(Integer.valueOf(i));
        viewHolder.location.setTypeface(this.type1, Typeface.ITALIC);
        textView4 = viewHolder.location;
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str);
        stringBuilder2.append(this.userslocation.get(i));
        textView4.setText(Html.fromHtml(stringBuilder2.toString()));
        viewHolder.location.setTag(Integer.valueOf(i));
        viewHolder.sharetxtbtn.setTag(Integer.valueOf(i));
        viewHolder.copytxtbtn.setTag(Integer.valueOf(i));
        viewHolder.sharetxtbtn.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = "firstvisit";
                if (UsersPoemsAdapter.this.sharedPreferences1.getInt(str, 0) == 0) {
                    UsersPoemsAdapter.this.editor1.putInt(str, 0);
                    UsersPoemsAdapter.this.editor1.apply();
                }
                UsersPoemsAdapter usersPoemsAdapter = UsersPoemsAdapter.this;
                String str2 = "count";
                usersPoemsAdapter.nooftimes_resultviewd = usersPoemsAdapter.sharedPreferences1.getInt(str2, 0);
                UsersPoemsAdapter.this.editor1.putInt(str2, UsersPoemsAdapter.this.nooftimes_resultviewd + 1);
                UsersPoemsAdapter.this.editor1.apply();
                Bundle bundle = new Bundle();
                bundle.putString("ShareText", "UsersPoems");
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(UsersPoemsAdapter.this.poems.get(i));
                stringBuilder.append("<br><br>- ");
                stringBuilder.append(UsersPoemsAdapter.this.usersname.get(i));
                stringBuilder.append("<br>- ");
                stringBuilder.append(UsersPoemsAdapter.this.userslocation.get(i));
                String obj = Html.fromHtml(stringBuilder.toString()).toString();
                UsersPoemsAdapter usersPoemsAdapter2 = UsersPoemsAdapter.this;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(obj);
                stringBuilder2.append("\n");
                stringBuilder = new StringBuilder();
                stringBuilder.append("<br>Do read this poem. I found it at <br>");
                stringBuilder.append(MyApplication.appLink);
                stringBuilder.append(context.getPackageName());
                stringBuilder2.append(Html.fromHtml(stringBuilder.toString()));
                usersPoemsAdapter2.msg2 = stringBuilder2.toString();
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", "Poems For All Occasions");
                intent.putExtra("android.intent.extra.TEXT", UsersPoemsAdapter.this.msg2);
                UsersPoemsAdapter.this.context.startActivity(Intent.createChooser(intent, "Share via"));
                UsersPoemsAdapter.this.copyText();
            }
        });
        viewHolder.copytxtbtn.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = "firstvisit";
                if (UsersPoemsAdapter.this.sharedPreferences1.getInt(str, 0) == 0) {
                    UsersPoemsAdapter.this.editor1.putInt(str, 0);
                    UsersPoemsAdapter.this.editor1.apply();
                }
                UsersPoemsAdapter usersPoemsAdapter = UsersPoemsAdapter.this;
                String str2 = "count";
                usersPoemsAdapter.nooftimes_resultviewd = usersPoemsAdapter.sharedPreferences1.getInt(str2, 0);
                UsersPoemsAdapter.this.editor1.putInt(str2, UsersPoemsAdapter.this.nooftimes_resultviewd + 1);
                UsersPoemsAdapter.this.editor1.commit();
                Bundle bundle = new Bundle();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("tracker -copy ");
                stringBuilder.append(TopMessagesActivity.catname);
                bundle.putString("CopyText", TopMessagesActivity.catname);
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(UsersPoemsAdapter.this.poems.get(i));
                stringBuilder2.append("<br><br>- ");
                stringBuilder2.append(UsersPoemsAdapter.this.usersname.get(i));
                stringBuilder2.append("<br>- ");
                stringBuilder2.append(UsersPoemsAdapter.this.userslocation.get(i));
                String obj = Html.fromHtml(stringBuilder2.toString()).toString();
                UsersPoemsAdapter usersPoemsAdapter2 = UsersPoemsAdapter.this;
                stringBuilder = new StringBuilder();
                stringBuilder.append(obj);
                stringBuilder.append("\n");
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("<br>Do read this poem. I found it at <br>");
                stringBuilder2.append(MyApplication.appLink);
                stringBuilder2.append(context.getPackageName());
                stringBuilder.append(Html.fromHtml(stringBuilder2.toString()));
                usersPoemsAdapter2.msg2 = stringBuilder.toString();
                UsersPoemsAdapter.this.copyText();
            }
        });
    }

    public int getItemCount() {
        return this.mRecyclerViewItems_v.size();
    }


    public void copyText() {
        ClipboardManager clipboardManager = (ClipboardManager) this.context.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData newPlainText = ClipData.newPlainText("label", Html.fromHtml(this.msg2));
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(newPlainText);
        }
        Toast.makeText(this.context, "Copied to Clipboard", Toast.LENGTH_SHORT).show();
    }
}
