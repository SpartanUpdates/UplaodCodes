package com.esc.gesturelockscreen.Other;

public interface SettingsKeys {
  public static final String ENABLE_GESTURE = "ENABLE_GESTURE";
  public static final String KEY_CUSTOM_WALLPAPER = "KEY_CUSTOM_WALLPAPER";
  public static final String KEY_ENABLE_LOCKSCREEN = "KEY_ENABLE_LOCKSCREEN";
  public static final String KEY_ENABLE_SOUND = "KEY_ENABLE_SOUND";
  public static final String KEY_ENABLE_VIBRATION = "KEY_ENABLE_VIBRATION";
  public static final String KEY_GESTURE_COLOR = "KEY_GESTURE_COLOR";
  public static final String KEY_GESTURE_LEVEL = "KEY_GESTURE_LEVEL";
  public static final String KEY_HIDE_GESTURE = "KEY_HIDE_GESTURE";
  public static final String KEY_INDEX_CLOCK = "KEY_INDEX_CLOCK";
  public static final String KEY_INDEX_WALLPAPER = "KEY_INDEX_WALLPAPER";
  public static final String KEY_PASSCODE_LENGTH = "PASSCODE_LENGTH";
  public static final String KEY_QUICK_UNLOCK = "KEY_QUICK_UNLOCK";
  public static final String KEY_SHOW_LIVEWALLPAPER = "KEY_SHOW_LIVEWALLPAPER";
  public static final String RANDOM_KEYBOARD = "RANDOM_KEYBOARD";
  public static final String SHOW_KEYBOARD_PASSCODE = "SHOW_KEYBOARD_PASSCODE";
}
