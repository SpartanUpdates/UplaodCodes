package com.kotlinz.festivalstorymaker.Models.festival;

import java.io.Serializable;

public class k implements Serializable {
    public String A;
    public String B;
    public String C;
    public String n;
    public String o;
    public String p;
    public String q;
    public String r;
    public String s;
    public String t;
    public String u;
    public String v;
    public String w;
    public String x;
    public String y;
    public String z;

    public k() {
        String str = "";
        this.n = str;
        this.o = str;
        this.p = str;
        this.r = str;
        this.s = str;
        this.t = str;
        this.v = str;
        this.w = str;
        this.x = str;
        this.y = str;
        this.z = str;
        this.A = str;
        this.B = str;
        this.C = str;
    }

}
