package com.xyz.vehiclemanager.history.Room;

import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.xyz.vehiclemanager.history.Model.LicenseHistory;
import com.xyz.vehiclemanager.history.Model.OwnerHistory;

import java.util.ArrayList;
import java.util.List;

@androidx.room.Dao
public interface OwnerHistoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertOwnerData(OwnerHistory history);

    @Query("select * from OwnerHistory")
    List<OwnerHistory> getOwnerHistory();

    @Query(" Delete from OwnerHistory where registrationNo=:registrationNo")
    void  deleteOwnerDetails(String registrationNo);


}