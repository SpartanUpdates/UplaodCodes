import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class MyThemes {
  static ThemeData lightTheme(BuildContext context) => ThemeData(

      //ownerInfo
      focusColor: blueLight,
      disabledColor: Colors.white,
      errorColor: subLightBlue,
      dividerColor: darkPink,
      dialogTheme: DialogTheme(backgroundColor: brownish),
      shadowColor: lowLightHint,
      dialogBackgroundColor: yelloish,
      hintColor: Colors.black,
      hoverColor: Colors.black,
      highlightColor: drawerColor,
      cursorColor: Colors.black,
      indicatorColor: doubleLowLight,
      primaryColor: Colors.white,
      primarySwatch: Colors.deepPurple,
      accentColor: Colors.black,
      brightness: Brightness.light,
      cardColor: yellowLight,
      canvasColor: lightPink,
      buttonColor: blueLight,
      splashColor: lightGreen,
      backgroundColor: Colors.white,
      appBarTheme: AppBarTheme(
        color: Colors.white,
        elevation: 0.0,
        iconTheme: IconThemeData(
          color: Colors.black,
        ),
        textTheme: Theme.of(context).textTheme,
      )
      // primaryTextTheme: GoogleFonts.latoTextTheme()
      );

  static ThemeData darkTheme(BuildContext context) => ThemeData(
        focusColor: fulldark,
        disabledColor: lightDark,
        errorColor: subLightDark,
        dividerColor: Colors.white,
        dialogTheme: DialogTheme(backgroundColor: subLightDark),
        dialogBackgroundColor: lightDark,
        hintColor: skyBlue,
        hoverColor: skyBlue,
        shadowColor: subLightDark,
        highlightColor: lightDark,
        cursorColor: creamColor,
        indicatorColor: subTextDark,
        primaryColor: fulldark,
        accentColor: Colors.white,
        brightness: Brightness.dark,
        cardColor: lightDark,
        canvasColor: lightDark,
        splashColor: lightDark,
        buttonColor: lightDark,
        backgroundColor: subLightDark,
        appBarTheme: AppBarTheme(
          color: Colors.black,
          elevation: 0.0,
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
          textTheme: Theme.of(context).textTheme,
        ),
      );

  //static Color lightPink = Color(0xffF6EBFA);
  static Color creamColor = Colors.blueGrey;
  static Color darkCreamColor = Vx.gray800;
  static Color bluishColor = Color(0xff403b58);
  static Color lightBluishColor = Vx.indigo500;

  //static Color skyBlue = Color(0xff9AB0DB);
  static Color lightBlue = Color(0xffE5FAFF);
  static Color lightYellow = Color(0xffFFF6DD);

  //static Color lightPink = Color(0xffFFF6DD);
  //static Color lightGreen = Color(0xffACF1C4);
  static Color statucBar = Color(0xff05103A);
  static Color yellowLight = Color(0xffFFF6DD);
  static Color blueLight = Color(0xffBFF6F7);
  static Color lightPink = Color(0xffFAE1F9);
  static Color lightGreen = Color(0xffB5F1DD);
  static Color drawerColor = Color(0xffF7EAFC);
  static Color yelloish = Color(0xffFFF6DD);
  static Color brownish = Color(0xff60024D);
  static Color darkPink = Color(0xffCA0E5D);
  static Color subLightBlue = Color(0xffDEEFCFC);
  static Color lowLightHint = Color(0xffA7CDCF);
  static Color doubleLowLight = Color(0xffC9DEDF);

  //dark Colors
  static Color fulldark = Color(0xff05103A);
  static Color lightDark = Color(0xff172144);
  static Color subLightDark = Color(0xff2D3758);
  static Color textDark = Color(0xff58AABC);
  static Color skyBlue = Color(0xff9AB0DB);
  static Color subTextDark = Color(0xff3F8290);
}
