package com.esc.palmreadingfuture.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.esc.palmreadingfuture.R;
import com.esc.palmreadingfuture.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class ShowResult extends AppCompatActivity {
    private Activity activity = ShowResult.this;
    static Editor editor = null;
    static SharedPreferences sharedpreferences = null;
    private String line;
    private String line_eng;
    private String msg2;
    private int nooftimes_resultviewd = 0;
    private String res = "";
    private int resoid;
    private TextView txt_result;
    private ImageView share;
    private Boolean sharerateusclicked = Boolean.valueOf(false);
    private TextView txt_share;
    public String trans;
    private TextView txt_title;
    private ImageView iv_back;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int Adid;

    OnClickListener listenshare = new OnClickListener() {
        public void onClick(View view) {
            String str = "text/plain";
            ShowResult.this.sharerateusclicked = Boolean.valueOf(true);
            Log.e("22", "tracker share button ");
            try {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType(str);
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{""});
                intent.setType(str);
                intent.putExtra(Intent.EXTRA_SUBJECT, ShowResult.this.getResources().getString(R.string.app_name));
                intent.putExtra(Intent.EXTRA_TEXT, ShowResult.this.msg2);
                ShowResult.this.startActivity(Intent.createChooser(intent, "Send via..."));
                ShowResult.this.copyText();
            } catch (Exception e) {
                e.printStackTrace();
            }
            ShowResult.this.AddRateClicks();
        }
    };

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.show_result);
        Log.e("activity", "show result");
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("palmreading", 0);
        sharedpreferences = sharedPreferences;
        editor = sharedPreferences.edit();
        String str = "firstvisit";
        if (sharedpreferences.getInt(str, 0) == 0) {
            editor.putInt(str, 0);
            editor.commit();
        }
        str = "count";
        int i = sharedpreferences.getInt(str, 0);
        this.nooftimes_resultviewd = i;
        editor.putInt(str, i + 1);
        editor.commit();
        this.trans = Locale.getDefault().getLanguage();
        bundle = getIntent().getExtras();
        this.res = bundle.getString("finalresult");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("res   ");
        stringBuilder.append(this.res);
        Log.e("QQQQ ", stringBuilder.toString());
        this.line = bundle.getString("line");
        this.line_eng = bundle.getString("line_eng");
        this.resoid = bundle.getInt("resid");

        txt_title = findViewById(R.id.txt_title);
        stringBuilder = new StringBuilder();
        String str2 = "";
        stringBuilder.append(str2);
        stringBuilder.append(this.line);
        txt_title.setText(stringBuilder.toString());
        txt_result = findViewById(R.id.resulttext);
        share = findViewById(R.id.imageView2);
        txt_share = findViewById(R.id.txt_share);
        stringBuilder = new StringBuilder();
        stringBuilder.append(str2);
        stringBuilder.append(res);
        txt_result.setText(stringBuilder.toString());
        share.setOnClickListener(listenshare);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(getResources().getString(R.string.share1));
        str = "\n\n";
        stringBuilder2.append(str);
        stringBuilder2.append(this.res);
        stringBuilder2.append(str);
        stringBuilder2.append(getResources().getString(R.string.share2));
        stringBuilder2.append("\n");
        stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
        msg2 = stringBuilder2.toString();
        txt_result.setMovementMethod(new ScrollingMovementMethod());

        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitial !=null &&  interstitial.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                Adid = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                }else {
                    startActivity(new Intent(ShowResult.this, SelectLine.class));
                    finish();
                }
            }
        });
        loadAd();
        BannerAds();
    }

    public void AddRateClicks() {
        Log.e("22", "AddrateClicks ");
        String str = "rateagain";
        if (sharedpreferences.getInt(str, 8) < 8) {
            int i = sharedpreferences.getInt(str, 8) + 1;
            editor.putInt(str, i);
            editor.commit();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(i);
            Log.e("clicks ", stringBuilder.toString());
        }
    }

    @SuppressLint("WrongConstant")
    public void copyText() {
        String str = "clipboard";
        if (VERSION.SDK_INT >= 11) {
            ((ClipboardManager) getSystemService(str)).setPrimaryClip(ClipData.newPlainText("label", this.msg2));
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.copytxt), Toast.LENGTH_LONG).show();
            return;
        }
        ((android.text.ClipboardManager) getSystemService(str)).setText(Html.fromHtml(this.msg2));
        Toast.makeText(getApplicationContext(), getResources().getString(R.string.copytxt), Toast.LENGTH_LONG).show();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }

    private void loadAd() {

        //InterstitialAd
        interstitial = new InterstitialAd(ShowResult.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        startActivity(new Intent(ShowResult.this, SelectLine.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(activity);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial    .loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(ShowResult.this, SelectLine.class));
        finish();
    }
}
