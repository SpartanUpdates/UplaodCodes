package com.example.lyricsvideo.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.lyricsvideo.Model.MytemplateModel;

import java.util.ArrayList;
import java.util.List;


public class DatabaseHelper extends SQLiteOpenHelper {


    public static String DATABASE = "database.db";
    public static String TABLE = "mytable";
    public static String VIDEO_NAME = "videoname";
    public static String SMALL_IMAGE = "smallimage";
    public static String PREVIEW_VIDEO_URL = "previewvideourl";
    public static String NUMBER_OF_IMAGE = "noofimage";
    public static String DATA_FOLDER_NAME = "datafoldername";

    String br;
    public DatabaseHelper(Context context) {
        super(context, DATABASE, null, 2);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        br = "CREATE TABLE "+TABLE+"("+VIDEO_NAME+ " Text, "+SMALL_IMAGE+ " Text, "+PREVIEW_VIDEO_URL+ " Text, "+NUMBER_OF_IMAGE+ " Text,"+DATA_FOLDER_NAME+ " Text);";
        db.execSQL(br);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE + " ;");
    }


    public void insertdata(String VideoName, String SmallImage, String PreviewvideoUrl, String NoogImage, String DataFolderName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(VIDEO_NAME, VideoName);
        contentValues.put(SMALL_IMAGE, SmallImage);
        contentValues.put(PREVIEW_VIDEO_URL, PreviewvideoUrl);
        contentValues.put(NUMBER_OF_IMAGE, NoogImage);
        contentValues.put(DATA_FOLDER_NAME, DataFolderName);
        db.insert(TABLE, null, contentValues);

    }

    public List<MytemplateModel> getdata() {
        List<MytemplateModel> data = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE + " ;", null);
        StringBuffer stringBuffer = new StringBuffer();
        MytemplateModel dataModel = null;
        while (cursor.moveToNext()) {
            dataModel = new MytemplateModel();
            dataModel.setVideoName(cursor.getString(cursor.getColumnIndexOrThrow("videoname")));
            dataModel.setSmallThemeImage(cursor.getString(cursor.getColumnIndexOrThrow("smallimage")));
            dataModel.setPreviewVideoUrl(cursor.getString(cursor.getColumnIndexOrThrow("previewvideourl")));
            dataModel.setNoOfImages(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("noofimage"))));
            dataModel.setContentZipFolderName(cursor.getString(cursor.getColumnIndexOrThrow("datafoldername")));
            stringBuffer.append(dataModel);
            data.add(dataModel);
        }
        for (MytemplateModel mo : data) {
            Log.e("Video Name", "" + mo.getVideoName());
        }
        return data;
    }

}
