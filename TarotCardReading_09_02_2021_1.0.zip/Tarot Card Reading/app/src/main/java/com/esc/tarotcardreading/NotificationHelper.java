package com.esc.tarotcardreading;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Vibrator;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationCompat.Builder;
import java.util.Locale;
import java.util.Random;

public class NotificationHelper {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final String NOTIFICATION_CHANNEL_ID = "10001";
    private static final int NOTIFICATION_ID = 1;
    public static final String PRIMARY_CHANNEL = "default";
    public static Editor editor;
    public static SharedPreferences sharedPreferences;
    String currentDayAndMonth1;
    String locale;
    Builder mBuilder;
    Context mContext;
    NotificationManager mNotificationManager;
    int random_eleven;
    int random_three;
    int random_two;
    Intent resultIntent;
    PendingIntent resultPendingIntent;

    NotificationHelper(Context context) {
        this.mContext = context;
    }


    public void createNotification() {
        String str;
        String str2;
        Bitmap decodeResource;
        String str3;
        SharedPreferences sharedPreferences2 = this.mContext.getSharedPreferences("MyPref", 0);
        sharedPreferences = sharedPreferences2;
        this.locale = sharedPreferences2.getString("languagetoload", "en");
        Locale locale2 = new Locale(this.locale);
        Locale.setDefault(locale2);
        Configuration configuration = new Configuration();
        configuration.locale = locale2;
        this.mContext.getResources().updateConfiguration(configuration, this.mContext.getResources().getDisplayMetrics());
        String str4 = "tr";
        if (!this.locale.contains(str4)) {
            int[] iArr = {R.string.ntcd0, R.string.ntcd1, R.string.ntcd2, R.string.ntcd3, R.string.ntcd4, R.string.ntcd5, R.string.ntcd6, R.string.ntcd7, R.string.ntcd8, R.string.ntcd9, R.string.ntcd10};
            String[] strArr = new String[11];
            int[] iArr2 = {R.string.ntcl0, R.string.ntcl1, R.string.ntcl2, R.string.ntcl3};
            String[] strArr2 = new String[4];
            int[] iArr3 = {R.string.ntclove0, R.string.ntclove1, R.string.ntclove2, R.string.ntclove3};
            String[] strArr3 = new String[4];
            int[] iArr4 = {R.string.ntcf0, R.string.ntcf1, R.string.ntcf2, R.string.ntcf3};
            String[] strArr4 = new String[4];
            int[] iArr5 = {R.string.ntcmoney0, R.string.ntcmoney1, R.string.ntcmoney2, R.string.ntcmoney3};
            String[] strArr5 = new String[4];
            int[] iArr6 = {R.string.ntcdreams0, R.string.ntcdreams1, R.string.ntcdreams2};
            String str5 = str4;
            String[] strArr6 = new String[3];
            int[] iArr7 = {R.string.ntct0, R.string.ntct1, R.string.ntct2};
            String[] strArr7 = new String[3];
            int[] iArr8 = {R.string.ntcw0, R.string.ntcw1, R.string.ntcw2, R.string.ntcw3};
            int[] iArr9 = {R.string.ntch0, R.string.ntch1, R.string.ntch2};
            String[] strArr8 = new String[4];
            String[] strArr9 = new String[3];
            int[] iArr10 = {R.string.ntcfocus0, R.string.ntcfocus1, R.string.ntcfocus2};
            String[] strArr10 = new String[3];
            int[] iArr11 = {R.string.ntcs0, R.string.ntcs1, R.string.ntcs2};
            String[] strArr11 = new String[3];
            int[] iArr12 = {R.string.ntcluck0, R.string.ntcluck1, R.string.ntcluck2};
            String[] strArr12 = new String[3];
            int[] iArr13 = {R.string.ntce0, R.string.ntce1, R.string.ntce2};
            String[] strArr13 = new String[3];
            int[] iArr14 = {R.string.ntcm0, R.string.ntcm1, R.string.ntcm2};
            String[] strArr14 = new String[3];
            int[] iArr15 = {R.string.ntcp0, R.string.ntcp1, R.string.ntcp2};
            String[] strArr15 = new String[3];
            StringBuilder sb = new StringBuilder();
            String[] strArr16 = strArr15;
            sb.append("notification....>");
            sb.append(this.locale);
            String sb2 = sb.toString();
            String str6 = "locale";
            Log.e(str6, sb2);
            String str7 = str6;
            int i = 0;
            while (i < 11) {
                int[] iArr16 = iArr6;
                strArr[i] = this.mContext.getResources().getString(iArr[i]);
                i++;
                iArr6 = iArr16;
            }
            int[] iArr17 = iArr6;
            for (int i2 = 0; i2 < 4; i2++) {
                strArr2[i2] = this.mContext.getResources().getString(iArr2[i2]);
                strArr3[i2] = this.mContext.getResources().getString(iArr3[i2]);
                strArr4[i2] = this.mContext.getResources().getString(iArr4[i2]);
                strArr5[i2] = this.mContext.getResources().getString(iArr5[i2]);
                strArr8[i2] = this.mContext.getResources().getString(iArr8[i2]);
            }
            for (int i3 = 0; i3 < 3; i3++) {
                strArr9[i3] = this.mContext.getResources().getString(iArr17[i3]);
                strArr13[i3] = this.mContext.getResources().getString(iArr13[i3]);
                strArr6[i3] = this.mContext.getResources().getString(iArr9[i3]);
                strArr12[i3] = this.mContext.getResources().getString(iArr12[i3]);
                strArr14[i3] = this.mContext.getResources().getString(iArr14[i3]);
                strArr16[i3] = this.mContext.getResources().getString(iArr15[i3]);
                strArr11[i3] = this.mContext.getResources().getString(iArr11[i3]);
                strArr7[i3] = this.mContext.getResources().getString(iArr7[i3]);
                strArr10[i3] = this.mContext.getResources().getString(iArr10[i3]);
            }
            this.random_eleven = new Random().nextInt(10) + 1;
            this.random_three = new Random().nextInt(3) + 1;
            this.random_two = new Random().nextInt(2) + 1;
            AlarmReceiver.random = new Random().nextInt(19) + 1;
            AlarmReceiver.randomlang = new Random().nextInt(5) + 1;
            StringBuilder sb3 = new StringBuilder();
            String str8 = "";
            sb3.append(str8);
            sb3.append(AlarmReceiver.random);
            Log.e("random", sb3.toString());
            int i4 = this.random_eleven;
            int i5 = this.random_three;
            int i6 = this.random_two;
            String[] strArr17 = {str8, strArr[i4], strArr2[i5], strArr3[i5], strArr4[i5], strArr5[i6], strArr6[i6], strArr9[i6], strArr7[i6], strArr8[i5], strArr10[i6], strArr11[i6], strArr12[i6], strArr13[i6], strArr14[i6], strArr16[i6], strArr[i4], strArr[i4], strArr[i4], strArr[i4]};
            String[] strArr18 = {str8, strArr2[i5], strArr3[i5], strArr4[i5], strArr5[i6], strArr6[i6]};
            if (this.locale.contains("ja") || this.locale.contains("th")) {
                str2 = str5;
            } else {
                str2 = str5;
                if (!this.locale.contains(str2) && !this.locale.contains("zh") && !this.locale.contains("ko") && !this.locale.contains("da") && !this.locale.contains("pl") && !this.locale.contains("es") && !this.locale.contains("fr") && !this.locale.contains("hi") && !this.locale.contains("nb") && !this.locale.contains("sv") && !this.locale.contains("de") && !this.locale.contains("it") && !this.locale.contains("ms") && !this.locale.contains("ru") && !this.locale.contains("nl") && !this.locale.contains("fi") && !this.locale.contains("el") && !this.locale.contains("in") && !this.locale.contains("vi") && !this.locale.contains("tl")) {
                    str = str7;
                    Log.e(str, "inside else");
                    if (AlarmReceiver.random == 1 || AlarmReceiver.random == 16 || AlarmReceiver.random == 17 || AlarmReceiver.random == 18 || AlarmReceiver.random == 19) {
                        this.resultIntent = new Intent(this.mContext, TaroCardsQuestionActivity.class);
                    } else {
                        this.resultIntent = new Intent(this.mContext, TaroQuestionsActivity.class);
                    }
                    decodeResource = BitmapFactory.decodeResource(this.mContext.getResources(), R.drawable.ic_launcher_background);
                    this.mNotificationManager = (NotificationManager) this.mContext.getSystemService(Context.NOTIFICATION_SERVICE);
                    this.resultPendingIntent = PendingIntent.getActivity(this.mContext, 0, this.resultIntent, 134217728);
                    Context context = this.mContext;
                    String str9 = NOTIFICATION_CHANNEL_ID;
                    this.mBuilder = new Builder(context, str9);
                    str3 = "notify";
                    if (!this.locale.contains("ja") || this.locale.contains("th") || this.locale.contains(str2) || this.locale.contains("zh") || this.locale.contains("ko") || this.locale.contains("da") || this.locale.contains("pl") || this.locale.contains("es") || this.locale.contains("fr") || this.locale.contains("hi") || this.locale.contains("nb") || this.locale.contains("sv") || this.locale.contains("de") || this.locale.contains("it") || this.locale.contains("ms") || this.locale.contains("ru") || this.locale.contains("nl") || this.locale.contains("fi") || this.locale.contains("el") || this.locale.contains("in") || this.locale.contains("vi") || this.locale.contains("tl")) {
                        StringBuilder sb4 = new StringBuilder();
                        sb4.append(">>>>>>>>");
                        sb4.append(AlarmReceiver.randomlang);
                        Log.e("Random...", sb4.toString());
                        Log.e(str3, str3);
                        Log.e(str, "inside ifff");
                        this.mBuilder.setContentTitle(this.mContext.getResources().getString(R.string.app_name)).setSmallIcon(R.drawable.smallicon).setLargeIcon(decodeResource).setStyle(new NotificationCompat.BigTextStyle().bigText(strArr18[AlarmReceiver.randomlang])).setContentText(strArr18[AlarmReceiver.randomlang]);
                    } else {
                        Log.e(str3, str3);
                        Log.e(str, "inside elseeee");
                        this.mBuilder.setLargeIcon(decodeResource).setSmallIcon(R.drawable.smallicon).setLargeIcon(decodeResource).setContentTitle(this.mContext.getResources().getString(R.string.app_name)).setStyle(new NotificationCompat.BigTextStyle().bigText(strArr17[AlarmReceiver.random])).setContentText(strArr17[AlarmReceiver.random]);
                    }
                    if (Build.VERSION.SDK_INT >= 26) {
                        NotificationChannel notificationChannel = new NotificationChannel(str9, "TAROT_CARD_READINGS", NotificationManager.IMPORTANCE_HIGH);
                        notificationChannel.enableLights(true);
                        notificationChannel.setLightColor(-16711936);
                        notificationChannel.enableVibration(true);
                        notificationChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
                        this.mBuilder.setChannelId(str9);
                        this.mNotificationManager.createNotificationChannel(notificationChannel);
                        this.mNotificationManager.notify(0, this.mBuilder.build());
                    }
                    this.mBuilder.setContentIntent(this.resultPendingIntent);
                    this.mBuilder.setAutoCancel(true);
                    this.mNotificationManager.notify(0, this.mBuilder.build());
                    ((Vibrator) this.mContext.getSystemService(Context.VIBRATOR_SERVICE)).vibrate(300);
                }
            }
            str = str7;
            Log.e(str, "inside if");
            Intent intent = new Intent(this.mContext, TaroCardsQuestionActivity.class);
            this.resultIntent = intent;
            intent.putExtra("type", "one");
            String str10 = "ccc2";
            String str11 = "ccc";
            String str12 = "head";
            if (AlarmReceiver.randomlang == 1) {
                this.resultIntent.putExtra(str12, this.mContext.getResources().getString(R.string.life));
                this.resultIntent.putExtra(str11, "Life");
                this.resultIntent.putExtra(str10, this.mContext.getResources().getString(R.string.life));
            } else if (AlarmReceiver.randomlang == 2) {
                this.resultIntent.putExtra(str12, this.mContext.getResources().getString(R.string.loveNrel));
                this.resultIntent.putExtra(str11, "Love & Relationships");
                this.resultIntent.putExtra(str10, this.mContext.getResources().getString(R.string.loveNrel));
            } else if (AlarmReceiver.randomlang == 3) {
                this.resultIntent.putExtra(str12, this.mContext.getResources().getString(R.string.familyNfriends));
                this.resultIntent.putExtra(str11, "Family & Friends");
                this.resultIntent.putExtra(str10, this.mContext.getResources().getString(R.string.familyNfriends));
            } else if (AlarmReceiver.randomlang == 4) {
                this.resultIntent.putExtra(str12, this.mContext.getResources().getString(R.string.money));
                this.resultIntent.putExtra(str11, "Money");
                this.resultIntent.putExtra(str10, this.mContext.getResources().getString(R.string.money));
            } else if (AlarmReceiver.randomlang == 5) {
                this.resultIntent.putExtra(str12, this.mContext.getResources().getString(R.string.health));
                this.resultIntent.putExtra(str11, "Health");
                this.resultIntent.putExtra(str10, this.mContext.getResources().getString(R.string.health));
            }
            decodeResource = BitmapFactory.decodeResource(this.mContext.getResources(), R.drawable.ic_launcher_background);
            this.mNotificationManager = (NotificationManager) this.mContext.getSystemService(Context.NOTIFICATION_SERVICE);
            this.resultPendingIntent = PendingIntent.getActivity(this.mContext, 0, this.resultIntent, 134217728);
            Context context2 = this.mContext;
            String str92 = NOTIFICATION_CHANNEL_ID;
            this.mBuilder = new Builder(context2, str92);
            str3 = "notify";
            if (!this.locale.contains("ja")) {
            }
            StringBuilder sb42 = new StringBuilder();
            sb42.append(">>>>>>>>");
            sb42.append(AlarmReceiver.randomlang);
            Log.e("Random...", sb42.toString());
            Log.e(str3, str3);
            Log.e(str, "inside ifff");
            this.mBuilder.setContentTitle(this.mContext.getResources().getString(R.string.app_name)).setSmallIcon(R.drawable.smallicon).setLargeIcon(decodeResource).setStyle(new NotificationCompat.BigTextStyle().bigText(strArr18[AlarmReceiver.randomlang])).setContentText(strArr18[AlarmReceiver.randomlang]);
            if (Build.VERSION.SDK_INT >= 26) {
            }
            this.mBuilder.setContentIntent(this.resultPendingIntent);
            this.mBuilder.setAutoCancel(true);
            this.mNotificationManager.notify(0, this.mBuilder.build());
            ((Vibrator) this.mContext.getSystemService(Context.VIBRATOR_SERVICE)).vibrate(300);
        }
    }
}
