package com.esc.lovemessages;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class GifSubCategoryAdapter extends RecyclerView.Adapter<GifSubCategoryAdapter.SubCategoryViewHolder> {
    Context mContext;
    ArrayList<String> subcategory;
    ArrayList<String> subcategorycount;
    Typeface typeface = Typeface.createFromAsset(this.mContext.getAssets(), "fonts/CormorantGaramond-Bold.ttf");

    public class SubCategoryViewHolder extends ViewHolder {
        public TextView subcategory_textView;
        public TextView subcategorycount_textView;

        public SubCategoryViewHolder(View view) {
            super(view);
            this.subcategory_textView = (TextView) view.findViewById(R.id.subcategory_textview);
            this.subcategorycount_textView = (TextView) view.findViewById(R.id.subcategorycount_textview);
            this.subcategory_textView.setTypeface(GifSubCategoryAdapter.this.typeface);
            this.subcategorycount_textView.setTypeface(GifSubCategoryAdapter.this.typeface);
        }
    }

    public GifSubCategoryAdapter(Context context, ArrayList<String> arrayList, ArrayList<String> arrayList2) {
        this.subcategory = arrayList;
        this.subcategorycount = arrayList2;
        this.mContext = context;
    }

    public SubCategoryViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new SubCategoryViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.gifsubcategory_view, viewGroup, false));
    }

    public void onBindViewHolder(SubCategoryViewHolder subCategoryViewHolder, final int i) {
        subCategoryViewHolder.subcategory_textView.setText((CharSequence) this.subcategory.get(i));
        subCategoryViewHolder.subcategorycount_textView.setText((CharSequence) this.subcategorycount.get(i));
        subCategoryViewHolder.subcategory_textView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                hashMap.put("Subcategory", GifSubCategoryAdapter.this.subcategory.get(i));
                Intent intent = new Intent(GifSubCategoryAdapter.this.mContext, GifViewActivity.class);
                intent.putExtra("subcategory", (String) GifSubCategoryAdapter.this.subcategory.get(i));
                GifSubCategoryAdapter.this.mContext.startActivity(intent);
            }
        });
    }

    public int getItemCount() {
        return this.subcategory.size();
    }
}
