package com.kotlinz.puzzlecreator.solver;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.airbnb.lottie.LottieAnimationView;
import com.kotlinz.puzzlecreator.Database.CreatorDB;
import com.kotlinz.puzzlecreator.Download.DownloadPuzzleImage;
import com.kotlinz.puzzlecreator.Utils.Utils;
import com.kotlinz.puzzlecreator.activity.BaseFragment;
import com.kotlinz.puzzlecreator.AppConstant.DataManager;
import com.kotlinz.puzzlecreator.activity.MainActivity;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.model.Credentials;
import com.kotlinz.puzzlecreator.model.DB_Pojo;
import com.kotlinz.puzzlecreator.model.puzzle_get_set;
import com.kotlinz.puzzlecreator.retrofit.APIClient;
import com.kotlinz.puzzlecreator.retrofit.APIInterface;
import com.squareup.picasso.Picasso;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import nl.dionsegijn.konfetti.models.Shape;
import nl.dionsegijn.konfetti.models.Size;
import okhttp3.ResponseBody;
import pl.droidsonroids.gif.GifImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static com.kotlinz.puzzlecreator.activity.MainActivity.konfettiView;
import static com.kotlinz.puzzlecreator.activity.MainActivity.txtwalletpoint;

public class SolverAllFragment extends BaseFragment {
    RecyclerView recyclerView;
    PuzzleAdapter adapter;
    ArrayList<puzzle_get_set> PuzzleList = new ArrayList<puzzle_get_set>();
    private ProgressBar loadingPB;
    private NestedScrollView nestedSV;
    int page = 1, lastpage = 0;
    SwipeRefreshLayout swipeRefreshLayout;
    LottieAnimationView anim_nodata;
    CreatorDB db;
    LinearLayoutManager linearLayoutManager;
    private final ScaleAnimation anim_card_flip = new ScaleAnimation(1, 0, 1, 1,
            Animation.RELATIVE_TO_PARENT, 0.5f, Animation.RELATIVE_TO_PARENT,
            0.5f);

    public SolverAllFragment() {
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (isNetworkAvailable()) {
            page = 1;
            getPuzzle();
        } else {
            noNetworkDialog();
        }
        linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        adapter = new PuzzleAdapter(getContext(), PuzzleList);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (isNetworkAvailable()) {
                    page = 1;
                    getPuzzle();
                } else {
                    noNetworkDialog();
                }
                swipeRefreshLayout.setRefreshing(false);
                swipeRefreshLayout.setEnabled(false);
            }
        });

        nestedSV.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (scrollY == v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight()) {
                    if (isNetworkAvailable()) {
                        if (page <= lastpage) {
                            page++;
                            loadingPB.setVisibility(View.VISIBLE);
                            getPuzzle();
                        } else {
                            loadingPB.setVisibility(View.GONE);
                        }
                    } else {
                        noNetworkDialog();
                        loadingPB.setVisibility(View.GONE);
                    }
                }
            }
        });

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup tv_ans,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_solverall, tv_ans, false);
        anim_card_flip.setDuration(500);
        recyclerView = view.findViewById(R.id.recyclerpuzzle);
        loadingPB = view.findViewById(R.id.idPBLoading);
        nestedSV = view.findViewById(R.id.idNestedSV);
        swipeRefreshLayout = view.findViewById(R.id.swiperefresh);
        anim_nodata = view.findViewById(R.id.anim_nodata);
        db = new CreatorDB(getContext());
        return view;
    }



    public class PuzzleAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
//        private final int ITEM_TYPE_DATA = 0;
//        public final int ITEM_TYPE_AD = 1;
        private final ArrayList<puzzle_get_set> listdata;
        Context context;
        String ansstatus;
//        private int AdsIndex = 0;


        public PuzzleAdapter(Context context, ArrayList<puzzle_get_set> plistdata) {
            this.listdata = plistdata;
            this.context = context;
        }


        @NotNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            /*if (viewType == ITEM_TYPE_AD) {
                return new NativeAdViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_coustomads, parent, false));
            } else {*/
                View listItem = LayoutInflater.from(parent.getContext()).inflate(R.layout.solver_puzzleview_layout, parent, false);
                return new ViewHolder(listItem);
//            }
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            /*if (getItemViewType(position) == ITEM_TYPE_AD) {
                NativeAdViewHolder nativeAdViewHolder = (NativeAdViewHolder) holder;
                if (MyApplication.getInstance().mNativeAds != null) {
                    if (AdsIndex < MyApplication.getInstance().mNativeAds.size()) {
                        NativeAd nativeAd = MyApplication.getInstance().mNativeAds.get(AdsIndex);
                        //Native Ads Not Loaded View Display First
                        View NativeAdsLoading = getLayoutInflater().inflate(R.layout.layout_nativeads_loding, null);
                        nativeAdViewHolder.frameLayout.addView(NativeAdsLoading);

                        //Native Ads Loaded Show Ads With Content
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.row_native_ad_item, null);
                        populateUnifiedNativeAdViewbig(nativeAd, adView);
                        nativeAdViewHolder.frameLayout.removeAllViews();
                        nativeAdViewHolder.frameLayout.addView(adView);
                        AdsIndex++;
                        if (AdsIndex >= MyApplication.getInstance().mNativeAds.size()) {
                            AdsIndex = 0;
                        }
                    }
                }

            } else {*/
                if (holder instanceof ViewHolder) {
                    ViewHolder PuzzleViewHolder = (ViewHolder) holder;
                    puzzle_get_set puzzle = listdata.get(position);

                    if (puzzle.getPuzzleimg() == null || puzzle.getPuzzleimg().equalsIgnoreCase("null") || puzzle.getPuzzleimg().equalsIgnoreCase("")) {
                        PuzzleViewHolder.puzzleimg.setVisibility(View.GONE);
                    } else {
                        PuzzleViewHolder.puzzleimg.setVisibility(View.VISIBLE);
                        Picasso.with(getActivity()).load(puzzle.getPuzzleimg()).into(PuzzleViewHolder.puzzleimg);
                    }

                    if (puzzle.getPuzzletype().equalsIgnoreCase("manual")) {
                        PuzzleViewHolder.lans.setVisibility(View.GONE);
                        PuzzleViewHolder.lmenual.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.addans.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (PuzzleViewHolder.edtans.getText().toString().equalsIgnoreCase("")) {
                                    PuzzleViewHolder.edtans.setError("Enter Answer");
                                } else {
                                    if (isNetworkAvailable()) {
                                        PuzzleViewHolder.addans.setVisibility(View.GONE);
                                        if (PuzzleViewHolder.edtans.getText().toString().equalsIgnoreCase(puzzle.getTrueans())) {
                                            PuzzleViewHolder.edtans.setTextColor(Color.GREEN);
                                            PuzzleViewHolder.edtans.setEnabled(false);
                                            PuzzleViewHolder.lhint.setEnabled(false);
                                            PuzzleViewHolder.imghint.setImageDrawable(getResources().getDrawable(R.drawable.hint_disable_selector));
                                            PuzzleViewHolder.lshowans.setEnabled(false);
                                            PuzzleViewHolder.imgshowans.setImageDrawable(getResources().getDrawable(R.drawable.showans_disable_selector));
                                            ansstatus = "success";
                                        } else {
                                            PuzzleViewHolder.edtans.setTextColor(Color.RED);
                                            PuzzleViewHolder.edtans.setEnabled(false);
                                            PuzzleViewHolder.lhint.setEnabled(false);
                                            PuzzleViewHolder.imghint.setImageDrawable(getResources().getDrawable(R.drawable.hint_disable_selector));
                                            ansstatus = "failed";
                                        }

                                        Bundle params = new Bundle();
                                        params.putString("Difficulty_Level", puzzle.getLevel());
                                        params.putString("Question_Type", puzzle.getPuzzletype());
                                        params.putString("Attemp_Type", "Answered");
                                        mFirebaseAnalytics.logEvent("Total_Question_Attempt", params);

                                        if (puzzle.getLevel().equalsIgnoreCase("high")) {
                                            AnsPuzzle(puzzle.getId(), ansstatus, DataManager.high_point);
                                        } else if (puzzle.getLevel().equalsIgnoreCase("medium")) {
                                            AnsPuzzle(puzzle.getId(), ansstatus, DataManager.medium_point);
                                        } else {
                                            AnsPuzzle(puzzle.getId(), ansstatus, DataManager.low_point);
                                        }
                                    } else {
                                        noNetworkDialog();
                                    }
                                }
                            }
                        });
                        PuzzleViewHolder.edtans.setOnKeyListener(new View.OnKeyListener() {
                            public boolean onKey(View v, int keyCode, KeyEvent event) {
                                // If the event is a key-down event on the "enter" button
                                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                                    PuzzleViewHolder.addans.callOnClick();
                                    return true;
                                }
                                return false;
                            }
                        });
                    } else {
                        PuzzleViewHolder.lans.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.lmenual.setVisibility(View.GONE);
                        PuzzleViewHolder.lans.removeAllViews();

                        for (int i = 0; i < puzzle.getOptions().size(); i++) {

                            TextView textView = new TextView(context);
                            textView.setText(puzzle.getOptions().get(i));
                            textView.setBackground(getResources().getDrawable(R.drawable.eclips));

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                textView.setTypeface(getResources().getFont(R.font.poppins_medium));
                            }

                            textView.setPadding(10, 20, 10, 20);
                            textView.setTextColor(getResources().getColor(R.color.mcq_color));
                            textView.setTextSize(15);
                            textView.setGravity(Gravity.CENTER);

                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT
                            );

                            params.setMargins(15, 5, 15, 5);
                            textView.setLayoutParams(params);
                            PuzzleViewHolder.lans.addView(textView);
                        }
                    }

                    PuzzleViewHolder.txtquestion.setText(puzzle.getQuestion());

                    if (puzzle.getHint() == null || puzzle.getHint().equalsIgnoreCase("null") || puzzle.getHint().equalsIgnoreCase("")) {
                        PuzzleViewHolder.lhint.setVisibility(View.GONE);
                    }

                    PuzzleViewHolder.lhint.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (isNetworkAvailable()) {
                                if (!db.IfHintView(puzzle.getId())) {

                                    if (Integer.parseInt(sessionManager.getUserPoints()) <= 0) {

                                        showerrorDialog("opps!!", "You don't have valid points");

                                    } else if (puzzle.getLevel().equalsIgnoreCase("high")
                                            && Integer.parseInt(sessionManager.getUserPoints()) < Integer.parseInt(DataManager.high_ans_point)) {

                                        showerrorDialog("opps!!", "You don't have valid points");

                                    } else if (puzzle.getLevel().equalsIgnoreCase("medium")
                                            && Integer.parseInt(sessionManager.getUserPoints()) < Integer.parseInt(DataManager.medium_ans_point)) {

                                        showerrorDialog("opps!!", "You don't have valid points");

                                    } else if (puzzle.getLevel().equalsIgnoreCase("low")
                                            && Integer.parseInt(sessionManager.getUserPoints()) < Integer.parseInt(DataManager.low_ans_point)) {

                                        showerrorDialog("opps!!", "You don't have valid points");

                                    } else {
                                        db.addHintData(new DB_Pojo(puzzle.getId()));
                                        Bundle params = new Bundle();
                                        mFirebaseAnalytics.logEvent("Total_Hint_View", params);
                                        if (puzzle.getLevel().equalsIgnoreCase("high")) {
                                            ManagePoints(puzzle.getId(), "2", DataManager.high_hint_point, puzzle.getHint(), "Hint");
                                        } else if (puzzle.getLevel().equalsIgnoreCase("medium")) {
                                            ManagePoints(puzzle.getId(), "2", DataManager.medium_hint_point, puzzle.getHint(), "Hint");
                                        } else {
                                            ManagePoints(puzzle.getId(), "2", DataManager.low_hint_point, puzzle.getHint(), "Hint");
                                        }
                                    }
                                } else {
                                    showhintDialog("Hint", puzzle.getHint());
                                }
                            } else {
                                noNetworkDialog();
                            }
                        }
                    });

                    PuzzleViewHolder.lshare.setOnClickListener(new View.OnClickListener() {
                        @RequiresApi(api = Build.VERSION_CODES.O)
                        @Override
                        public void onClick(View view) {
                            Bundle params = new Bundle();
                            params.putString("User_Type", sessionManager.getUserType());
                            params.putString("Share_Type", "Puzzle");
                            mFirebaseAnalytics.logEvent("Share_Puzzle", params);
                            if (puzzle.getPuzzleimg().equals("null")) {
                                String ans;
                                if (puzzle.getPuzzletype().equalsIgnoreCase("manual")) {
                                    ans = "Type Answer manually";
                                } else {
                                    ans = String.join("\n=> ", puzzle.getOptions());
                                }
                                String text = "Hey ! \n" +
                                        "\n" +
                                        "Solve this puzzle\n "
                                        + "----------------------------\n"
                                        + puzzle.getQuestion() + "\n"
                                        + "----------------------------\n=> "
                                        + ans
                                        + "\n----------------------------\n" +
                                        " from  https://play.google.com/store/apps/details?id=" + getActivity().getPackageName() + " and earn points";
                                Intent shareIntent = new Intent();
                                shareIntent.setAction(Intent.ACTION_SEND);
                                shareIntent.setType("text/*");
                                shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                startActivity(Intent.createChooser(shareIntent, "Share Puzzle..."));
                            } else {
                                String PuzzleImageSaveFileName = puzzle.getPuzzleimg().substring(puzzle.getPuzzleimg().lastIndexOf("/") + 1);
                                File PuzzleShareFile = new File(Utils.INSTANCE.getPuzzleImage() + PuzzleImageSaveFileName);
                                if (!new File(Utils.INSTANCE.getPuzzleImage() + PuzzleImageSaveFileName).exists()) {
                                    new DownloadPuzzleImage(getActivity(), puzzle.getPuzzleimg(), PuzzleImageSaveFileName, puzzle);
                                } else {
                                    String ans;
                                    if (puzzle.getPuzzletype().equalsIgnoreCase("manual")) {
                                        ans = "Type Answer manually";
                                    } else {
                                        ans = String.join("\n=> ", puzzle.getOptions());
                                    }
                                    String text = "Hey ! \n" +
                                            "\n" +
                                            "Solve this puzzle\n "
                                            + "----------------------------\n"
                                            + puzzle.getQuestion() + "\n"
                                            + "----------------------------\n=> "
                                            + ans
                                            + "\n----------------------------\n" +
                                            " from  https://play.google.com/store/apps/details?id=" + getActivity().getPackageName() + " and earn points";
                                    Intent shareIntent = new Intent();
                                    shareIntent.setAction(Intent.ACTION_SEND);
                                    shareIntent.setType("image/*");
                                    final Uri ShareUri = FileProvider.getUriForFile(getActivity(), String.valueOf(getActivity().getPackageName()) + ".provider", PuzzleShareFile);
                                    shareIntent.putExtra(Intent.EXTRA_STREAM, ShareUri);
                                    shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    startActivity(Intent.createChooser(shareIntent, "Share Puzzle..."));
                                }
                            }
                        }
                    });

                    PuzzleViewHolder.lshowans.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (Integer.parseInt(sessionManager.getUserPoints()) <= 0) {
                                showerrorDialog("opps!!", "You don't have valid points");
                            } else if (puzzle.getLevel().equalsIgnoreCase("high") && Integer.parseInt(sessionManager.getUserPoints()) < Integer.parseInt(DataManager.high_ans_point)) {
                                showerrorDialog("opps!!", "You don't have valid points");
                            } else if (puzzle.getLevel().equalsIgnoreCase("medium") && Integer.parseInt(sessionManager.getUserPoints()) < Integer.parseInt(DataManager.medium_ans_point)) {
                                showerrorDialog("opps!!", "You don't have valid points");
                            } else if (puzzle.getLevel().equalsIgnoreCase("low") && Integer.parseInt(sessionManager.getUserPoints()) < Integer.parseInt(DataManager.low_ans_point)) {
                                showerrorDialog("opps!!", "You don't have valid points");
                            } else {
                                if (isNetworkAvailable()) {
                                    if (puzzle.getPuzzletype().equalsIgnoreCase("manual")) {
                                        PuzzleViewHolder.addans.setVisibility(View.GONE);
                                        PuzzleViewHolder.edtans.setText(puzzle.getTrueans());
                                        PuzzleViewHolder.edtans.setTextColor(Color.GREEN);
                                        PuzzleViewHolder.edtans.setEnabled(false);
                                        PuzzleViewHolder.lshowans.setEnabled(false);
                                        PuzzleViewHolder.imgshowans.setImageDrawable(getResources().getDrawable(R.drawable.showans_disable_selector));

                                    } else {
                                        int childCount = PuzzleViewHolder.lans.getChildCount();
                                        for (int i = 0; i < childCount; i++) {
                                            TextView tv_ans = (TextView) PuzzleViewHolder.lans.getChildAt(i);
                                            if (tv_ans.getText().toString().equalsIgnoreCase(puzzle.getTrueans())) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                                    endanimate(tv_ans, getResources().getColor(R.color.green));
                                                    PuzzleViewHolder.lshowans.setEnabled(false);
                                                    PuzzleViewHolder.imgshowans.setImageDrawable(getResources().getDrawable(R.drawable.showans_disable_selector));
                                                }
                                            }
                                            tv_ans.setEnabled(false);
                                        }
                                    }

                                    Bundle params = new Bundle();
                                    mFirebaseAnalytics.logEvent("Total_" + puzzle.getPuzzletype() + "_Attempt_Question", params);
                                    mFirebaseAnalytics.logEvent("Total_" + puzzle.getLevel() + "_Level_Puzzle_Attempt", params);
                                    mFirebaseAnalytics.logEvent("Total_Show_Answer", params);


                                    if (puzzle.getLevel().equalsIgnoreCase("high")) {
                                        ManagePoints(puzzle.getId(), "2", DataManager.high_ans_point, puzzle.getTrueans(), "Answer");
                                    } else if (puzzle.getLevel().equalsIgnoreCase("medium")) {
                                        ManagePoints(puzzle.getId(), "2", DataManager.medium_ans_point, puzzle.getTrueans(), "Answer");
                                    } else {
                                        ManagePoints(puzzle.getId(), "2", DataManager.low_ans_point, puzzle.getTrueans(), "Answer");
                                    }
                                    PuzzleViewHolder.lhint.setEnabled(false);
                                    PuzzleViewHolder.imghint.setImageDrawable(getResources().getDrawable(R.drawable.hint_disable_selector));
                                    PuzzleViewHolder.lans.setEnabled(false);
                                } else {
                                    noNetworkDialog();
                                }
                            }
                        }
                    });

                    int childCount = PuzzleViewHolder.lans.getChildCount();
                    for (int i = 0; i < childCount; i++) {
                        TextView tv_ans = (TextView) PuzzleViewHolder.lans.getChildAt(i);
                        tv_ans.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                if (isNetworkAvailable()) {
                                    if (tv_ans.getText().toString().equalsIgnoreCase(puzzle.getTrueans())) {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                            endanimate(tv_ans, getResources().getColor(R.color.green));
                                            PuzzleViewHolder.lshowans.setEnabled(false);
                                            PuzzleViewHolder.imgshowans.setImageDrawable(getResources().getDrawable(R.drawable.showans_disable_selector));
                                        }
                                        ansstatus = "success";
                                    } else {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                            endanimate(tv_ans, getResources().getColor(R.color.red));
                                        }
                                        ansstatus = "failed";
                                    }
                                    for (int i = 0; i < childCount; i++) {
                                        TextView tv_ans = (TextView) PuzzleViewHolder.lans.getChildAt(i);
                                        tv_ans.setEnabled(false);
                                    }

                                    PuzzleViewHolder.lhint.setEnabled(false);
                                    PuzzleViewHolder.imghint.setImageDrawable(getResources().getDrawable(R.drawable.hint_disable_selector));
                                    PuzzleViewHolder.lans.setEnabled(false);

                                    Bundle params = new Bundle();
                                    mFirebaseAnalytics.logEvent("Total_" + puzzle.getPuzzletype() + "_Attempt_Question", params);
                                    mFirebaseAnalytics.logEvent("Total_" + puzzle.getLevel() + "_Level_Puzzle_Attempt", params);
                                    mFirebaseAnalytics.logEvent("Total_Answered_Puzzle", params);

                                    if (puzzle.getLevel().equalsIgnoreCase("high")) {
                                        AnsPuzzle(puzzle.getId(), ansstatus, DataManager.high_point);
                                    } else if (puzzle.getLevel().equalsIgnoreCase("medium")) {
                                        AnsPuzzle(puzzle.getId(), ansstatus, DataManager.medium_point);
                                    } else {
                                        AnsPuzzle(puzzle.getId(), ansstatus, DataManager.low_point);
                                    }
                                } else {
                                    noNetworkDialog();
                                }
                            }
                        });
                    }

                    if (puzzle.getLevel().equalsIgnoreCase("high")) {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.high));
                    } else if (puzzle.getLevel().equalsIgnoreCase("medium")) {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.medium));
                    } else {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.low));
                    }
                }
            }
//        }

       /* @Override
        public int getItemViewType(int position) {
            if ((position > 0) && ((position + 1) % 4 == 0) && MyApplication.getInstance().IsNativeAdsLoaded) {
                return ITEM_TYPE_AD;
            } else {
                return ITEM_TYPE_DATA;
            }
        }*/

        @Override
        public int getItemCount() {
            return listdata.size();
        }

       /* public class NativeAdViewHolder extends RecyclerView.ViewHolder {
            FrameLayout frameLayout;


            public NativeAdViewHolder(View view) {
                super(view);
                frameLayout = view.findViewById(R.id.fl_adplaceholder);
            }
        }*/

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ImageView puzzleimg, imglevel, addans, imghint, imgshowans;
            public TextView txtquestion, txtansstatus, txthintclick;
            EditText edtans;
            public LinearLayout lhint, lshare, lshowans, lmenual;
            CardView cardimg;
            GridLayout lans;

            public ViewHolder(View itemView) {
                super(itemView);

                puzzleimg = itemView.findViewById(R.id.img);
                imghint = itemView.findViewById(R.id.imghint);
                imgshowans = itemView.findViewById(R.id.imgshowans);

                lans = itemView.findViewById(R.id.lans);

                cardimg = itemView.findViewById(R.id.cardimg);

                txtquestion = itemView.findViewById(R.id.txtquestion);
                txthintclick = itemView.findViewById(R.id.txthintclick);

                imglevel = itemView.findViewById(R.id.imglevel);
                addans = itemView.findViewById(R.id.addans);

                edtans = itemView.findViewById(R.id.edtans);
                txtansstatus = itemView.findViewById(R.id.textansstatus);

                lhint = itemView.findViewById(R.id.lhint);
                lshare = itemView.findViewById(R.id.lshare);
                lshowans = itemView.findViewById(R.id.lshowans);
                lmenual = itemView.findViewById(R.id.lmenual);

            }
        }

    }


    public void endanimate(TextView tv_ans, int color) {

        final int from, mid;
        if (color == ContextCompat.getColor(getActivity(), R.color.green)) {
            from = ContextCompat.getColor(getActivity(), R.color.startgreen);
            mid = ContextCompat.getColor(getActivity(), R.color.middlegreen);
        } else {
            from = ContextCompat.getColor(getActivity(), R.color.startred);
            mid = ContextCompat.getColor(getActivity(), R.color.middlered);
        }

        ValueAnimator anim = new ValueAnimator();
        anim.setIntValues(from, mid, color);
        anim.setEvaluator(new ArgbEvaluator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    tv_ans.setBackgroundTintList(ColorStateList.valueOf((Integer) valueAnimator.getAnimatedValue()));
                    tv_ans.setTextColor(Color.WHITE);
                }
            }
        });
        anim.setDuration(1000);
        anim.start();
    }

    private void getPuzzle() {
        if (page == 1) {
            PuzzleList.clear();
            showProgressDialog();
        }
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).GetSolverPuzzle(sessionManager.getToken(), page);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            JSONObject resp = jsonObject.getJSONObject("response");
                            JSONArray puzzleData = resp.getJSONArray("puzzle_data");
                            if (page == 1 && puzzleData.length() == 0) {
                                cancel_dialog();
                                swipeRefreshLayout.setVisibility(View.GONE);
                                anim_nodata.setVisibility(View.VISIBLE);
                            } else {
                                anim_nodata.setVisibility(View.GONE);
                                swipeRefreshLayout.setVisibility(View.VISIBLE);
                                for (int i = 0; i < puzzleData.length(); i++) {
                                    JSONObject pzl = puzzleData.getJSONObject(i);
                                    puzzle_get_set puzzle = new puzzle_get_set();
                                    puzzle.setId(pzl.getString("puzzle_id"));
                                    puzzle.setQuestion(pzl.getString("question"));
                                    puzzle.setPuzzletype(pzl.getString("question_type"));
                                    puzzle.setPuzzleimg(pzl.getString("image"));
                                    puzzle.setTrueans(pzl.getString("true_answer"));
                                    puzzle.setHint(pzl.getString("hint"));
                                    puzzle.setLevel(pzl.getString("difficulty_level"));
                                    JSONArray option = pzl.getJSONArray("options");
                                    List<String> opt = new ArrayList<>();
                                    for (int j = 0; j < option.length(); j++) {
                                        opt.add(option.getString(j));
                                    }
                                    puzzle.setOptions(opt);
                                    PuzzleList.add(puzzle);
                                    /*if (isNetworkAvailable() && MyApplication.getInstance().IsNativeAdsLoaded) {
                                        if ((PuzzleList.size() + 1) % 4 == 0) {
                                            puzzle.setNativeAds(true);
                                            PuzzleList.add(null);
                                        }
                                    }*/
                                    adapter.notifyDataSetChanged();
                                }
                                swipeRefreshLayout.setEnabled(true);
                                cancel_dialog();
                                lastpage = resp.getInt("last_page");
                                if (page > lastpage) {
                                    cancel_dialog();
                                    Toast.makeText(getContext(), "No more data..", Toast.LENGTH_SHORT).show();
                                    loadingPB.setVisibility(View.GONE);
                                    return;
                                }
                            }
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        swipeRefreshLayout.setEnabled(true);
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
                noNetworkDialog();
            }
        });
    }

    public void showhintDialog(String main, String Msg) {
        Dialog dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_layout);

        TextView txtmain = dialog.findViewById(R.id.txtmain);
        TextView txtmsg = dialog.findViewById(R.id.text_dialog);
        GifImageView gimg = dialog.findViewById(R.id.anim_tryagain);
        ImageView btnok = dialog.findViewById(R.id.btn_dialog);

        gimg.setImageResource(R.drawable.hint_anim);
        txtmain.setText(main);
        txtmain.setVisibility(View.GONE);
        txtmsg.setText(Msg);

        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void AnsPuzzle(String puzzleid, String status, String points) {

        Credentials ans = new Credentials();
        ans.puzzle_id = puzzleid;
        ans.status = status;
        ans.points = points;

        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).Answer_Puzzle(sessionManager.getToken(), ans);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> res) {
                if (res.code() == 200) {
                    try {
                        String result = res.body().string();
                        Log.e("Responce", "........" + result);
                        JSONObject obj = new JSONObject(result);
                        if (obj.getBoolean("status")) {
                            cancel_dialog();
                            if (status.equalsIgnoreCase("success")) {
                                ManagePoints(puzzleid, "1", points, "", "");
                            }
                        } else {
                            showerrorDialog("Failed", obj.getString("message"));
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(res.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        if (points.equalsIgnoreCase("Answer")) {
                        } else {
                            showerrorDialog("Failed", error.getString(0));
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                showerrorDialog("Failed", "Try Again");
            }
        });
    }

    private void ManagePoints(String puzzleid, String status, String points, String msg, String title) {
        Credentials manage = new Credentials();
        manage.status = status;
        manage.points = points;

        Call<ResponseBody> call = APIClient.getClient()
                .create(APIInterface.class)
                .Manage_Points(sessionManager.getToken(), manage);

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> res) {

                if (res.code() == 200) {
                    try {
                        String result = res.body().string();
                        Log.e("Responce", "........" + result);
                        JSONObject obj = new JSONObject(result);
                        if (obj.getBoolean("status")) {
                            cancel_dialog();

                            if (title.equalsIgnoreCase("Answer")) {
                                AnsPuzzle(puzzleid, "failed", "Answer");
                            } else if (title.equalsIgnoreCase("Hint")) {
                                Log.e("title", "..");
                                showhintDialog(title, msg);
                            } else {
                                if (status.equalsIgnoreCase("1")) {
                                    konfettiView.build()
                                            .addColors(Color.YELLOW, Color.GREEN, Color.MAGENTA)
                                            .setDirection(0.0, 359.0)
                                            .setSpeed(1f, 5f)
                                            .setFadeOutEnabled(true)
                                            .setTimeToLive(1000L)
                                            .addShapes(Shape.Circle.INSTANCE, Shape.Square.INSTANCE)
                                            .addSizes(new Size(12, 5f))
                                            .setPosition(konfettiView.getX() + konfettiView.getWidth() / 2
                                                    , konfettiView.getY() + konfettiView.getHeight() / 3)
                                            .burst(500);

                                    MainActivity.coincollect.setVisibility(View.VISIBLE);
                                    MainActivity.coincollect.playAnimation();
                                }
                            }
                            sessionManager.setUserPoints(obj.getJSONObject("response").getString("user_points"));
                            MainActivity.txtpoint.setText(sessionManager.getUserPoints() + " Points");
                            txtwalletpoint.setText(sessionManager.getUserPoints() + " Points");

                        } else {
                            cancel_dialog();
                            showerrorDialog("Failed", obj.getString("message"));
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                    cancel_dialog();
                } else {
                    try {
                        JSONObject obj = new JSONObject(res.errorBody().string());
                        cancel_dialog();
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }
}