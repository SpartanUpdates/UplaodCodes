package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.View;
import android.widget.FrameLayout;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class f5  implements TextStickerViewNew1.a
{
    public final  FrameLayout a;
    public final  TextStickerViewNew1 b;
    public final  FestivalDetailActivity_New c;

    public f5(final FestivalDetailActivity_New c, final FrameLayout a, final TextStickerViewNew1 b) {
        this.c = c;
        this.a = a;
        this.b = b;
    }

    @Override
    public void a(final TextStickerViewNew1 a1) {
        this.c.scroll.requestDisallowInterceptTouchEvent(true);
        final TextStickerViewNew1 a2 = this.c.a1;
        if (a2 != null) {
            a2.setInEdit(false);
            this.c.a1.setShowHelpBox(false);
        }
        (this.c.a1 = a1).setInEdit(true);
        this.c.a1.setShowHelpBox(true);
    }

    @Override
    public void b(final TextStickerViewNew1 textStickerViewNew1) {
        this.c.u0(this.a, this.b);
    }

    @Override
    public void c(final TextStickerViewNew1 textStickerViewNew1) {
        if (this.c.a1 != null && textStickerViewNew1.getTag().equals(this.c.a1.getTag()) && textStickerViewNew1.u) {
            this.a.removeView(textStickerViewNew1);
        }

    }

    @Override
    public void d(final TextStickerViewNew1 a1) {
        final FestivalDetailActivity_New c = this.c;
        c.S = true;
        c.a1 = a1;
        c.H0(c.imgFont);
        final FestivalDetailActivity_New c2 = this.c;
        final com.kotlinz.festivalstorymaker.Models.festival.f0.c c3 = c2.h1.get((int)c2.a1.getTag());
        final FestivalDetailActivity_New c4 = this.c;
        c4.f1 = c3.d;
        c4.g1 = c3.f;
        c4.seekBarFontSpacing.setProgress(c3.a);
        this.c.seekBarFontHeight.setProgress(c3.b);
        final FestivalDetailActivity_New c5 = this.c;
        c5.e1.k(c5.f1);
        final FestivalDetailActivity_New c6 = this.c;
        c6.d1.k(c6.g1);
        this.c.E0(c3.c);
        this.c.F0(c3.e);
        this.c.U0(true);
    }
}
