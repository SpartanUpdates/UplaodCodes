package com.unitedvideos;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.root.unity.AndroidUnityCall;
import com.root.unity.AppUsages;
import com.unitedvideos.NativeAds.NativeAdvanceAds;
import com.unitedvideos.Preferences.LanguagePref;
import com.unitedvideos.R;
import com.unitedvideos.Utils.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.unity3d.player.UnityPlayer;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;


public class UnityPlayerActivity extends Activity implements View.OnClickListener {
    private static final int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    public static UnityPlayer mUnityPlayer; // don't change the name of this variable; referenced from native code
    public static FrameLayout layoutAdView;
    public static InterstitialAd mInterstitialAd;
    public static AlertDialog alertDialog;
    public static String m;
    public static String n;
    public static UnityPlayerActivity unityPlayeractivity;
    Activity activity = UnityPlayerActivity.this;
    int AdsCount = 0;
    AdRequest adRequest;
    AdView adView;

    LinearLayout llBottomView;
    LinearLayout llImage;
    //    LinearLayout llArrange;
    LinearLayout llSong;
    LinearLayout llText;
//    LinearLayout llSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        View view;
        int systemUiVisibility;
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            view = this.getWindow().getDecorView();
            systemUiVisibility = 8;
        } else {
            if (Build.VERSION.SDK_INT < 19) {
            }
            view = this.getWindow().getDecorView();
            systemUiVisibility = 4102;
        }
        view.setSystemUiVisibility(systemUiVisibility);
        this.getWindow().setFlags(1024, 1024);
        super.onCreate(savedInstanceState);
        getWindow().setFormat(PixelFormat.RGBX_8888); // <--- This makes xperia play happy
        unityPlayeractivity = this;
        if (mInterstitialAd != null) {
            mInterstitialAd = null;
        }
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                mInterstitialAd = null;
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                AdsCount++;
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
                if (mInterstitialAd != null) {
                    mInterstitialAd = null;
                }
                if (AdsCount <= 2) {
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                }

            }
        });
        mUnityPlayer = new UnityPlayer(this);
        setContentView(R.layout.unity_ui);
        ((FrameLayout) findViewById(R.id.layout_unity_main)).addView(mUnityPlayer, 0);
        layoutAdView = findViewById(R.id.llBanner_unity);
        mUnityPlayer.requestFocus();
        if (Build.VERSION.SDK_INT < 23) {
            UnityPlayer.UnitySendMessage("GetPermission", "IsCallHomeActivity", "ok");
            Utils.CreateDirectory();
            AppUsages.loadFFMpeg(this);
            Log.e("TAG", "On Resume SDK23");
        } else {
            RequestPermission(false, true);
        }
        BindView();
        BannerAds();
    }

    private void BindView() {
        llBottomView = findViewById(R.id.llBottomView);
        llImage = findViewById(R.id.llImage);
//        llArrange = findViewById(R.id.llArrange);
        llSong = findViewById(R.id.llSong);
        llText = findViewById(R.id.llText);
//        llSave = findViewById(R.id.llSave);

        findViewById(R.id.llImage).setOnClickListener(this);
//        findViewById(R.id.llArrange).setOnClickListener(this);
        findViewById(R.id.llSong).setOnClickListener(this);
        findViewById(R.id.llText).setOnClickListener(this);
//        findViewById(R.id.llSave).setOnClickListener(this);
    }

    public final void showBottom() {
        if (llBottomView != null) {
            llBottomView.setVisibility(View.VISIBLE);
        }
    }

    public final void hideBottom() {
        if (llBottomView != null) {
            llBottomView.setVisibility(View.GONE);
        }
    }



    private void RequestPermission(boolean z, boolean isFromFirst) {
        if ((ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            if (isFromFirst) {
                UnityPlayer.UnitySendMessage("GetPermission", "IsCallHomeActivity", "ok");
                Log.e("TAG", "Premission Allready Granted");
                Utils.CreateDirectory();
                AppUsages.loadFFMpeg(activity);
            }
        } else if (z) {
            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
            alertDialogBuilder.setTitle("Necessary permission");
            alertDialogBuilder.setMessage("Allow Required Permission");
            alertDialogBuilder.setCancelable(false);
            alertDialogBuilder.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                    PremissionFromSetting(UnityPlayerActivity.this);
                }
            });

            alertDialogBuilder.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        } else {
            ActivityCompat.requestPermissions(activity, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                UnityPlayer.UnitySendMessage("GetPermission", "IsCallHomeActivity", "ok");
                Log.e("TAG", "Premission From Setting Granted");
                Utils.CreateDirectory();
                AppUsages.loadFFMpeg(activity);
            } else {
                RequestPermission(true, true);
            }
        }
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        if (i == EXTERNAL_STORAGE_PERMISSION_CONSTANT) {
            if (iArr.length > 0) {
                if (iArr[0] == 0 && iArr[1] == PackageManager.PERMISSION_GRANTED) {
                    UnityPlayer.UnitySendMessage("GetPermission", "IsCallHomeActivity", "ok");
                    Log.e("TAG", "Premission Granted");
                    Utils.CreateDirectory();
                    AppUsages.loadFFMpeg(activity);
                } else if ((iArr[0] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) || (iArr[1] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.READ_EXTERNAL_STORAGE))) {
                    RequestPermission(true, true);
                }
            }
        }
    }

    public void PremissionFromSetting(UnityPlayerActivity unityPlayerActivity) {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", unityPlayerActivity.getPackageName(), null);
        intent.setData(uri);
        unityPlayerActivity.startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
    }

    private void BannerAds() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }


    // Quit Unity
    @Override
    protected void onDestroy() {
        mUnityPlayer.quit();
        super.onDestroy();
    }


    // Pause Unity
    @Override
    protected void onPause() {
        super.onPause();
        mUnityPlayer.pause();
    }

    // Resume Unity
    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT < 23) {
//            UnityPlayer.UnitySendMessage("GetPermission", "IsCallHomeActivity", "ok");
            Utils.CreateDirectory();
            AppUsages.loadFFMpeg(this);
            Log.e("TAG", "On Resume SDK23");
        } else {
            Log.e("TAG", "On Resume Called...");
            RequestPermission(false, false);
        }
        mUnityPlayer.resume();
    }

    // This ensures the layout will be correct.
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mUnityPlayer.configurationChanged(newConfig);
    }

    // Notify Unity of the focus change.
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        mUnityPlayer.windowFocusChanged(hasFocus);
    }

    // For some reason the multiple keyevent type is not supported by the ndk.
    // Force event injection by overriding dispatchKeyEvent().
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_MULTIPLE)
            return mUnityPlayer.injectEvent(event);
        return super.dispatchKeyEvent(event);
    }

    // Pass any events not handled by (unfocused) views straight to UnityPlayer
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    /*API12*/
    public boolean onGenericMotionEvent(MotionEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    private void SaveVideoOpenDilaog() {
        final androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this, R.style.AdsDialog);
        final View inflate = LayoutInflater.from(this).inflate(R.layout.export_dialog, null);
        builder.setView(inflate);
        final androidx.appcompat.app.AlertDialog dialog = builder.create();
        AdLoader.Builder Adbuilder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        Adbuilder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                FrameLayout frameLayout = inflate.findViewById(R.id.fl_adplaceholder);
                inflate.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                NativeAdvanceAds.populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        Adbuilder.withNativeAdOptions(adOptions);
        AdLoader adLoader = Adbuilder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        inflate.findViewById(R.id.btnNormal).setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "360");
                AndroidUnityCall.HideBannerAds(activity);
                AndroidUnityCall.HideBottomData(activity);
                LanguagePref.a(UnityPlayerActivity.this).b("pref_key_export_quality", "Low");
                dialog.dismiss();
            }
        });
        inflate.findViewById(R.id.btnHd).setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "480");
                AndroidUnityCall.HideBannerAds(activity);
                AndroidUnityCall.HideBottomData(activity);
                LanguagePref.a(UnityPlayerActivity.this).b("pref_key_export_quality", "Medium");
                dialog.dismiss();
            }
        });
        inflate.findViewById(R.id.btnFullHd).setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "720");
                AndroidUnityCall.HideBannerAds(activity);
                AndroidUnityCall.HideBottomData(activity);
                LanguagePref.a(UnityPlayerActivity.this).b("pref_key_export_quality", "High");
                dialog.dismiss();
            }
        });
        ((CheckBox) inflate.findViewById(R.id.cbDoNotAsk)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                LanguagePref languagePref;
                String str;
                String str2;
                if (z) {
                    languagePref = LanguagePref.a(UnityPlayerActivity.this);
                    str = "pref_last_load_time_ads";
                    str2 = "0";
                } else {
                    languagePref = LanguagePref.a(UnityPlayerActivity.this);
                    str = "pref_last_load_time_ads";
                    str2 = "1";
                }
                languagePref.b(str, str2);
            }
        });
        dialog.show();
    }

    public void SaveVideo() {
        String str;
        if (LanguagePref.a(this).a("pref_last_load_time_ads", "1").equals("1")) {
            SaveVideoOpenDilaog();
        } else {
            str = LanguagePref.a(this).a("pref_key_export_quality", "Medium");
            AndroidUnityCall.HideBannerAds(activity);
            AndroidUnityCall.HideBottomData(activity);
            if (str.equals("Low")) {
                UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "360");
//                return;
            } else if (str.equals("Medium")) {
                UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "480");
//                return;
            } else if (str.equals("High")) {
                UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "720");
//                return;
            } else {
                UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "480");
//                return;
            }
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llImage:
                UnityPlayer.UnitySendMessage("UserData", "GeneralMethodCall", "");
                AndroidUnityCall.ImageSelection(this, AndroidUnityCall.ImageWidth, AndroidUnityCall.ImageHeight, AndroidUnityCall.NoofImage, AndroidUnityCall.VideoType, true, "unity");
                break;
//            case R.id.llArrange:
//                UnityPlayer.UnitySendMessage("UserData", "GeneralMethodCall", "");
//                AndroidUnityCall.ArrangeActivity(activity, true);
//                break;
            case R.id.llSong:
                UnityPlayer.UnitySendMessage("UserData", "GeneralMethodCall", "");
                AndroidUnityCall.SongSelection(activity);
                break;
            case R.id.llText:
                UnityPlayer.UnitySendMessage("UserData", "EditText", "");
                break;
//            case R.id.llSave:
//                String str;
//                if (LanguagePref.a(this).a("pref_last_load_time_ads", "1").equals("1")) {
//                SaveVideoOpenDilaog();
//                } else {
//                    str = LanguagePref.a(this).a("pref_key_export_quality", "Medium");
//                    AndroidUnityCall.HideBannerAds(activity);
//                    AndroidUnityCall.HideBottomData(activity);
//                    if (str.equals("Low")) {
//                        UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "360");
//                        return;
//                    } else if (str.equals("Medium")) {
//                        UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "480");
//                        return;
//                    } else if (str.equals("High")) {
//                        UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "720");
//                        return;
//                    } else {
//                        UnityPlayer.UnitySendMessage("UserData", "SaveVideo", "480");
//                        return;
//                    }
//                }
//                break;
        }
    }
}
