package com.example.womenabsworkout.adapters;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.kprogresshud.KProgressHUD;
import com.example.womenabsworkout.utils.MealsItemObject;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.util.List;


public class MealsAdapter extends RecyclerView.Adapter<MealsAdapter.MealsRecyclerViewHolders> {
    public Context context;
    public List<MealsItemObject> itemList;
    public SharedPreferences mSharedPreferences;

    class MealsRecyclerViewHolders extends ViewHolder {
        public TextView countryName;

        public MealsRecyclerViewHolders(View view) {
            super(view);
            LayoutParams layoutParams = new LayoutParams(-1, -2);
            layoutParams.setMargins(5, 5, 5, 5);
            layoutParams.weight = 1.0f;
            this.countryName = (TextView) view.findViewById(R.id.row_day);
        }
    }

    public MealsAdapter(Context context, List<MealsItemObject> list) {
        this.itemList = list;
        this.context = context;
        this.mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);

    }

    public int getItemCount() {
        return this.itemList.size();
    }

    public void onBindViewHolder(MealsRecyclerViewHolders mealsRecyclerViewHolders, int i) {
        mealsRecyclerViewHolders.countryName.setText(((MealsItemObject) this.itemList.get(i)).getName());
        SharedPreferences sharedPreferences = this.mSharedPreferences;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DAY_");
        stringBuilder.append(i + 1);
        stringBuilder.append("_CHECKED");
        Boolean.valueOf(sharedPreferences.getBoolean(stringBuilder.toString(), false)).booleanValue();

    }

    public MealsRecyclerViewHolders onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MealsRecyclerViewHolders(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.meals_days_row, (ViewGroup) null));
    }
}
