package com.kotlinz.festivalstorymaker.sticker;

import android.view.MotionEvent;

public interface f {
    void a(final StickerView p0, final MotionEvent p1);

    void b(final StickerView p0, final MotionEvent p1);

    void c(final StickerView p0, final MotionEvent p1);
}
