package com.esc.photoslideshow.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

import com.esc.photoslideshow.R;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.Timer;
import java.util.TimerTask;

public class SplashscreenActivity extends AppCompatActivity {
    Timer myTimer;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.splashscreen_copy);

        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.bottom_up_splash);
        ImageView image1 = (ImageView) findViewById(R.id.imgArrow1);
        image1.startAnimation(animation);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                loadNextActivity();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        PutAnalyticsEvent();
    }

    private void loadNextActivity() {
        this.myTimer = new Timer();
        this.myTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> {
                    myTimer.cancel();
                    SplashscreenActivity.this.startActivity(new Intent(SplashscreenActivity.this.getApplicationContext(), MainActivity.class));
                    SplashscreenActivity.this.finish();
                });
            }
        }, 0, 3000);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SplashscreenActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

}