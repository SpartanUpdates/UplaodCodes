package com.xyz.vehiclemanager.model;

import com.google.gson.annotations.SerializedName;

public class CityList {
    @SerializedName("id")
    public String cityId;
    @SerializedName("stateName")
    public String stateName;
    @SerializedName("cityName")
    public String cityName;

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
}
