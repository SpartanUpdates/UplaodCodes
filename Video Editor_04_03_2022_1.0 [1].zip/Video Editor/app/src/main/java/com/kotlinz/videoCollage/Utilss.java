package com.kotlinz.videoCollage;

import com.kotlinz.videoeditor.R;

public class Utilss {
    public static final Utilss INSTANCE;

    static {
        INSTANCE = new Utilss();
    }

    public int CatThumb(String str) {
        str = str.toLowerCase();
        return str.contains("1:1") ? R.drawable.ic_1_1_unpress : str.contains("4:5") ? R.drawable.ic_ratio_4_5_unpress : str.contains("9:16") ? R.drawable.ic_ratio_9_6_unpress : str.contains("3:4") ? R.drawable.ic_ratio_3_4_unpress : str.contains("16:9") ? R.drawable.youtube_16by9_unpress : str.contains("4:3") ? R.drawable.facebook_4by3_unpress : str.contains("fbcover") ? R.drawable.fb_cover_unpress : str.contains("post") ? R.drawable.post_unpress : str.contains("5:7") ? R.drawable.ic_5by7_unpress : str.contains("7:5") ? R.drawable.ic_7by5_unpress : str.contains("5:4") ? R.drawable.ic_5by4_unpress : str.contains("3:5") ? R.drawable.ic_3by5_unpress : str.contains("5:3") ? R.drawable.ic_5by3_unpress : str.contains("2:3") ? R.drawable.ic_2by3_unpess : str.contains("3:2") ? R.drawable.ic_3by2_unpess : str.contains("cover") ? R.drawable.twitter_cover_u : str.contains("1:1.91") ? R.drawable.ic_11by91_unpress : R.mipmap.ic_launcher;
    }

    public int CatThumbPress(String str) {
        str = str.toLowerCase();
        return str.contains("1:1") ? R.drawable.ic_1_1_press : str.contains("4:5") ? R.drawable.ic_ratio_4_5_press : str.contains("9:16") ? R.drawable.ic_ratio_9_6_press : str.contains("3:4") ? R.drawable.ic_ratio_3_4_press : str.contains("16:9") ? R.drawable.youtube_16by9_press : str.contains("4:3") ? R.drawable.facebook_4by3_press : str.contains("fbcover") ? R.drawable.fb_cover_press : str.contains("post") ? R.drawable.post_press : str.contains("5:7") ? R.drawable.ic_5by7_press : str.contains("7:5") ? R.drawable.ic_7by5_press : str.contains("5:4") ? R.drawable.ic_5by4_press : str.contains("3:5") ? R.drawable.ic_3by5_press : str.contains("5:3") ? R.drawable.ic_5by3_press : str.contains("2:3") ? R.drawable.ic_2by3_pess : str.contains("3:2") ? R.drawable.ic_3by2_pess : str.contains("cover") ? R.drawable.twitter_cover_p : str.contains("1:1.91") ? R.drawable.ic_11by91_press : R.mipmap.ic_launcher;
    }

}
