package com.mbit.VideoMaker.Activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.mbit.VideoMaker.Adapter.VideoAlbumAdapter;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Model.VideoData;
import com.mbit.VideoMaker.R;

import java.io.File;
import java.util.ArrayList;

public class MyVideoActivity extends AppCompatActivity {

    public ArrayList<VideoData> mVideoDatas;
    Activity activity = MyVideoActivity.this;
    LinearLayout llcreatevideo;
    ImageView ivBack;
    TextView txtMainTitle;
    String from = "";
    Button btncreatevideo;
    RecyclerView rvVideoList;
    VideoAlbumAdapter mVideoAlbumAdapter;
    private StaggeredGridLayoutManager gaggeredGridLayoutManager;
    private LinearLayout adContainer;
    private AdView adView;

//    AdRequest adRequest;
//    AdView adView;
//    private NativeBannerAd nativeBannerAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myvideo);
        from = getIntent().getStringExtra("from");
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MyVideoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        bindView();
        init();
        loadAd();
//        loadNativeAds();
        setupRecyclerFeed();
        addListener();

    }

    private void loadAd() {
        adContainer = findViewById(R.id.templateContainer);
        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
        adContainer.addView(adView);
        adView.loadAd();
    }

    @Override
    protected void onDestroy() {
        this.adView.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        super.onDestroy();
    }
//    private void loadNativeAds() {
//        nativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_nativebanner));
//        nativeBannerAd.setAdListener(new NativeAdListener() {
//            @Override
//            public void onMediaDownloaded(Ad ad) {
//
//            }
//
//            @Override
//            public void onError(Ad ad, AdError adError) {
//                findViewById(R.id.banner_container).setVisibility(View.GONE);
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
//                LinearLayout nativeBannerAdContainer = findViewById(R.id.banner_container);
//                nativeBannerAdContainer.addView(adView);
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//
//            }
//        });
//        if (Utils.checkConnectivity(activity, false)) {
//            nativeBannerAd.loadAd();
//        } else {
//            findViewById(R.id.banner_container).setVisibility(View.GONE);
//        }
//
//    }

    private void bindView() {
        ivBack = findViewById(R.id.ivBack);
        txtMainTitle = findViewById(R.id.tv_name);
        llcreatevideo = findViewById(R.id.ll_novideo);
        btncreatevideo = findViewById(R.id.iv_create_now);
        rvVideoList = findViewById(R.id.rvAlubmPhotos);
    }


    private void addListener() {
        ivBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                if (from != null && from.equalsIgnoreCase("unity")) {
                    finish();
                } else {
                    onBackPressed();
                }
            }

        });
        btncreatevideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity, HomeActivity.class));
                finish();
            }
        });
    }

    private void init() {
        getVideoList();
        if (mVideoDatas.size() > 0) {
            llcreatevideo.setVisibility(View.GONE);
        } else {
            llcreatevideo.setVisibility(View.VISIBLE);
        }
    }


    private void getVideoList() {
        this.mVideoDatas = new ArrayList<VideoData>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "datetaken";
        final Cursor cur = getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getAPP_FOLDER() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final VideoData videoData = new VideoData();
                videoData.videoDuration = cur.getLong(bucketColumn);
                videoData.videoFullPath = cur.getString(data);
                videoData.videoName = cur.getString(name);
                videoData.dateTaken = cur.getLong(dateTaken);
                if (new File(videoData.videoFullPath).exists()) {
                    this.mVideoDatas.add(videoData);
                }
            } while (cur.moveToNext());
        }
    }

    private void setupRecyclerFeed() {
        if (mVideoDatas.size() <= 0) {
            rvVideoList.setVisibility(View.GONE);
        } else {
            rvVideoList.setVisibility(View.VISIBLE);
        }
        mVideoAlbumAdapter = new VideoAlbumAdapter(activity, mVideoDatas);
        gaggeredGridLayoutManager = new StaggeredGridLayoutManager(2, 1);
        gaggeredGridLayoutManager.setAutoMeasureEnabled(true);
        rvVideoList.setLayoutManager(gaggeredGridLayoutManager);
        rvVideoList.setAdapter(mVideoAlbumAdapter);
        mVideoAlbumAdapter.notifyDataSetChanged();

    }

    public void onBackPressed() {
        Intent intent = new Intent(activity, HomeActivity.class);
        startActivity(intent);
        finish();
    }

    public void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }
}
