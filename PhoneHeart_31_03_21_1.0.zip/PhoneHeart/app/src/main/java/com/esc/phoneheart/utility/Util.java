package com.esc.phoneheart.utility;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.provider.DocumentsContract;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Patterns;
import android.util.TypedValue;
import android.webkit.MimeTypeMap;
import com.esc.phoneheart.pref.MySharedPreference;
import com.esc.phoneheart.pref.SharedPrefUtil;
import org.apache.commons.io.IOUtils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import androidx.appcompat.app.AppCompatActivity;

public class Util {
    public static boolean a = false;
    public static boolean isHome = false;


    public static int actionbarsize(Context context) {
        int complexToDimensionPixelSize;
        TypedValue typedValue = new TypedValue();
        try {
            complexToDimensionPixelSize = context.getTheme().resolveAttribute(16843499, typedValue, true) ? TypedValue.complexToDimensionPixelSize(typedValue.data, context.getResources().getDisplayMetrics()) + 10 : 0;
        } catch (Exception e) {
            e.printStackTrace();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            ((AppCompatActivity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            complexToDimensionPixelSize = (displayMetrics.heightPixels * 12) / 100;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(complexToDimensionPixelSize);
        return complexToDimensionPixelSize;
    }

    public static void appendLog(String str, String str2) {
        if (GlobalData.isDebug) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStorageDirectory());
            stringBuilder.append("/");
            stringBuilder.append(str2);
            File file = new File(stringBuilder.toString());
            if (!file.exists()) {
                try {
                    file.createNewFile();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            try {
                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
                bufferedWriter.append(str);
                bufferedWriter.newLine();
                bufferedWriter.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    public static void appendLogphonecleaner(String str, String str2, String str3) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStorageDirectory());
        stringBuilder.append("/cleaner.txt");
        File file = new File(stringBuilder.toString());
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str);
            stringBuilder2.append(" == ");
            stringBuilder2.append(str2);
            stringBuilder2.append(IOUtils.LINE_SEPARATOR_UNIX);
            bufferedWriter.append(stringBuilder2.toString());
            bufferedWriter.newLine();
            bufferedWriter.close();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public static void appendLogphonecleanerTest(String str, String str2, String str3) {
        if (GlobalData.isDebug) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            String str4 = " == ";
            stringBuilder.append(str4);
            stringBuilder.append(str2);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(Environment.getExternalStorageDirectory());
            stringBuilder2.append("/");
            stringBuilder2.append(str3);
            File file = new File(stringBuilder2.toString());
            if (!file.exists()) {
                try {
                    file.createNewFile();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            try {
                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
                stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(str4);
                stringBuilder.append(str2);
                stringBuilder.append(IOUtils.LINE_SEPARATOR_UNIX);
                bufferedWriter.append(stringBuilder.toString());
                bufferedWriter.newLine();
                bufferedWriter.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    public static void appendLogphonecleanerbug(String str, String str2) {
        if (GlobalData.isDebug) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStorageDirectory());
            stringBuilder.append("/bug.txt");
            File file = new File(stringBuilder.toString());
            if (!file.exists()) {
                try {
                    file.createNewFile();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            try {
                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(" == ");
                stringBuilder2.append(str2);
                stringBuilder2.append(IOUtils.LINE_SEPARATOR_UNIX);
                bufferedWriter.append(stringBuilder2.toString());
                bufferedWriter.newLine();
                bufferedWriter.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    public static String capitalizeFirstLetter(String str) {
        String stringBuilder;
        try {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str.substring(0, 1).toUpperCase());
            stringBuilder2.append(str.substring(1));
            stringBuilder = stringBuilder2.toString();
        } catch (Exception e) {
            e.printStackTrace();
            stringBuilder = null;
        }
        return stringBuilder == null ? str : stringBuilder;
    }

    public static boolean checkEmail(String str) {
        return (str == null || TextUtils.isEmpty(str) || !Patterns.EMAIL_ADDRESS.matcher(str).matches()) ? false : true;
    }

    public static boolean checkStorageAccessPermissions(Context context) {
        if (VERSION.SDK_INT < 23) {
            return true;
        }
        int checkCallingOrSelfPermission = context.checkCallingOrSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
        int checkCallingOrSelfPermission2 = context.checkCallingOrSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (checkCallingOrSelfPermission == 0 || checkCallingOrSelfPermission2 == 0) {
            return true;
        }
        return false;
    }

    public static long checkTimeDifference(String str, String str2) {
        if (!(str == null || str2 == null)) {
            long parseLong = Long.parseLong(str);
            long parseLong2 = Long.parseLong(str2);
            if (parseLong >= 0 && parseLong2 >= 0) {
                long time;
                Date date = new Date(parseLong);
                Date date2 = new Date(parseLong2);
                if (parseLong > parseLong2) {
                    parseLong2 = date.getTime();
                    time = date2.getTime();
                } else {
                    parseLong2 = date2.getTime();
                    time = date2.getTime();
                }
                return TimeUnit.SECONDS.toSeconds(parseLong2 - time);
            }
        }
        return 900000000;
    }

    public static String convertBytes(long j) {
        if (j <= 0) {
            return "0 B";
        }
        String[] strArr = {"B", "KB", "MB", "GB", "TB"};
        double d = (double) j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder sb = new StringBuilder();
        sb.append(new DecimalFormat("#,##0.##").format(d / Math.pow(1024.0d, (double) log10)));
        sb.append(" ");
        sb.append(strArr[log10]);
        return sb.toString();
    }

    public static String convertBytesJunk(long j) {
        if (j <= 0) {
            return "0 B";
        }
        String[] strArr = new String[]{"B", "KB", "MB", "GB", "TB"};
        double d = (double) j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(new DecimalFormat("#,##0").format(d / Math.pow(1024.0d, (double) log10)));
        stringBuilder.append(" ");
        stringBuilder.append(strArr[log10]);
        return stringBuilder.toString();
    }

    public static String convertBytes_only(long j) {
        if (j <= 0) {
            return "0";
        }
        double d = (double) j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
//        FilesListScreen.exten_type = new String[]{"B", "KB", "MB", "GB", "TB"}[log10];
        return new DecimalFormat("###0.##").format(d / Math.pow(1024.0d, (double) log10));
    }

    public static String convertBytes_unit(long j) {
        String str = "B";
        if (j <= 0) {
            return str;
        }
        return new String[]{str, "KB", "MB", "GB", "TB"}[(int) (Math.log10((double) j) / Math.log10(1024.0d))];
    }

    public static String convertToPath(Uri uri, Context context) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String treeDocumentId = null;
        if (VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            treeDocumentId = DocumentsContract.getTreeDocumentId(uri);
        }
        if (treeDocumentId != null) {
            String[] split = treeDocumentId.split(":");
            Object obj = split.length > 0 ? split[0] : null;
            Map secondaryMountedVolumesMap = getSecondaryMountedVolumesMap(context);
            String str = (secondaryMountedVolumesMap == null || obj == null) ? null : (String) secondaryMountedVolumesMap.get(obj);
            if (str != null) {
                StringBuilder stringBuilder;
                if (split.length == 2) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("/");
                    stringBuilder.append(split[1]);
                    treeDocumentId = stringBuilder.toString();
                } else {
                    treeDocumentId = "";
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(treeDocumentId);
                return stringBuilder.toString();
            }
        }
        return null;
    }

    public static boolean copyFile(String str, String str2) {
        String str3 = "/";
        String str4 = "EXCEPTIONNNNN";
        try {
            File file = new File(str2);
            if (!file.exists()) {
                file.mkdirs();
            }
            FileInputStream fileInputStream = new FileInputStream(str);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str2);
            stringBuilder.append(str3);
            stringBuilder.append(str.substring(str.lastIndexOf(str3)));
            FileOutputStream fileOutputStream = new FileOutputStream(stringBuilder.toString());
            byte[] bArr = new byte[1024];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read != -1) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    fileInputStream.close();
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return true;
                }
            }
        } catch (FileNotFoundException e) {
            return false;
        } catch (Exception e2) {
            return false;
        }
    }

    public static void deleteFileFromInternal(Context context, String str) {
        new File(context.getCacheDir(), str).delete();
    }

    public static int dpToPx(int i) {
        return (int) (((float) i) * Resources.getSystem().getDisplayMetrics().density);
    }

    public static double getBatteryCapacity(Context context) {
        Object newInstance;
        String str = "com.android.internal.os.PowerProfile";
        try {
            newInstance = Class.forName(str).getConstructor(new Class[]{Context.class}).newInstance(new Object[]{context});
        } catch (Exception e) {
            e.printStackTrace();
            newInstance = null;
        }
        try {
            return ((Double) Class.forName(str).getMethod("getAveragePower", new Class[]{String.class}).invoke(newInstance, new Object[]{"battery.capacity"})).doubleValue();
        } catch (Exception e2) {
            e2.printStackTrace();
            return 0.0d;
        }
    }

    public static String getMimeType(String str) {
        str = MimeTypeMap.getFileExtensionFromUrl(str);
        return str != null ? MimeTypeMap.getSingleton().getMimeTypeFromExtension(str) : null;
    }

    public static Map<String, String> getSecondaryMountedVolumesMap(Context context) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        @SuppressLint("WrongConstant") StorageManager storageManager = (StorageManager) context.getSystemService("storage");
        Object[] objArr = (Object[]) storageManager.getClass().getMethod("getVolumeList", new Class[0]).invoke(storageManager, new Object[0]);
        HashMap hashMap = new HashMap();
        for (Object obj : objArr) {
            String str = (String) obj.getClass().getMethod("getState", new Class[0]).invoke(obj, new Object[0]);
            if (!((Boolean) obj.getClass().getMethod("isPrimary", new Class[0]).invoke(obj, new Object[0])).booleanValue() && str.equals("mounted")) {
                str = (String) obj.getClass().getMethod("getPath", new Class[0]).invoke(obj, new Object[0]);
                String str2 = (String) obj.getClass().getMethod("getUuid", new Class[0]).invoke(obj, new Object[0]);
                if (!(str2 == null || str == null)) {
                    hashMap.put(str2, str);
                }
            }
        }
        return hashMap;
    }

    public static String getToday(String str) {
        return new SimpleDateFormat(str).format(new Date());
    }

    public static boolean hasFroyo() {
        return false;
    }

    public static boolean hasGingerbread() {
        return VERSION.SDK_INT >= 9;
    }

    public static boolean hasHoneycomb() {
        return VERSION.SDK_INT >= 11;
    }

    public static boolean hasHoneycombMR1() {
        return VERSION.SDK_INT >= 12;
    }

    public static boolean hasJellyBean() {
        return VERSION.SDK_INT >= 16;
    }

    public static boolean hasKitKat() {
        return VERSION.SDK_INT >= 19;
    }

    public static boolean isAVFree(Context context) {
        if (isAdsFree(context)) {
            return true;
        }
        return MySharedPreference.isAVFree(context);
    }

    public static boolean isAdsFree(Context context) {
        return MySharedPreference.isAdsFree(context) || MySharedPreference.isAllInOne(context);
    }

    public static boolean isConnectingToInternet(Context context) {
        @SuppressLint("WrongConstant") ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivityManager != null) {
            NetworkInfo[] allNetworkInfo = connectivityManager.getAllNetworkInfo();
            if (allNetworkInfo != null) {
                for (NetworkInfo state : allNetworkInfo) {
                    if (state.getState() == State.CONNECTED) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static boolean isExpire(String str) {
        if (!(str.isEmpty() || str.trim().equals(""))) {
            String str2 = "MMM-dd-yyyy hh:mm:ss a";
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str2);
            str2 = getToday(str2);
            try {
                Date parse = simpleDateFormat.parse(str);
                Date parse2 = simpleDateFormat.parse(str2);
                if (parse2.compareTo(parse) < 0) {
                    return false;
                }
                if (parse.compareTo(parse2) == 0) {
                    if (parse.getTime() < parse2.getTime()) {
                        return false;
                    }
                    if (parse.getTime() == parse2.getTime()) {
                    }
                }
                return true;
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean notInIgnoreList(String str) {
        String[] strArr = new String[]{"Facebook", "WhatsApp", "Amazon", "Twitter", "Instagram", "Linkedin", "Gmail", "Messenger", "Hike", "Hangouts", "Youtube", "Truecaller", "Google+"};
        for (int i = 0; i < 13; i++) {
            String str2 = strArr[i];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(str);
            if (str2.equalsIgnoreCase(stringBuilder.toString())) {
                return false;
            }
        }
        return true;
    }

    public static String readFromFile(Context context, String str) {
        String str2 = "login activity";
        String str3 = "";
        StringBuilder stringBuilder;
        try {
            FileInputStream openFileInput = context.openFileInput(str);
            if (openFileInput == null) {
                return str3;
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(openFileInput));
            stringBuilder = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine != null) {
                    stringBuilder.append(readLine);
                } else {
                    openFileInput.close();
                    return stringBuilder.toString();
                }
            }
        } catch (FileNotFoundException e) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("File not found: ");
            stringBuilder.append(e.toString());
            return str3;
        } catch (IOException e2) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Can not read file: ");
            stringBuilder.append(e2.toString());
            return str3;
        }
    }

    public static float round2(float f, int i) {
        int i2 = 10;
        for (int i3 = 1; i3 < i; i3++) {
            i2 *= 10;
        }
        float f2 = (float) i2;
        f *= f2;
        if (f - ((float) ((int) f)) >= 0.5f) {
            f += 1.0f;
        }
        return ((float) ((int) f)) / f2;
    }

    public static void saveScreen(String str, Context context) {
        String str2 = "";
        String str3 = ".";
        try {
            if (str.contains(str3)) {
                str = str.substring(str.lastIndexOf(str3) + 1, str.length());
            }
            str3 = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US).format(Calendar.getInstance().getTime());
            SharedPrefUtil sharedPrefUtil = new SharedPrefUtil(context);
            String str4 = SharedPrefUtil.LAST_SCREEN;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str2);
            stringBuilder.append(str);
            sharedPrefUtil.saveString(str4, stringBuilder.toString());
            str = SharedPrefUtil.LAST_TIME_VISIT;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str2);
            stringBuilder2.append(str3);
            sharedPrefUtil.saveString(str, stringBuilder2.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setSavedPreferences(Context context) {
        SharedPrefUtil sharedPrefUtil = new SharedPrefUtil(context);
        try {
            if (sharedPrefUtil.getString("IMAGE_SETTING") != null) {
                GlobalData.imageCriteia = 0;
            }
            if (sharedPrefUtil.getString("VIDEO_SETTING") != null) {
                GlobalData.videoCriteia = 0;
            }
            if (sharedPrefUtil.getString("AUDIO_SETTING") != null) {
                GlobalData.audioCriteia = 0;
            }
            if (sharedPrefUtil.getString("FILE_SETTING") != null) {
                GlobalData.fileCriteia = 0;
            }
            if (sharedPrefUtil.getString("OTHER_SETTING") != null) {
                GlobalData.otherCriteia = 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
