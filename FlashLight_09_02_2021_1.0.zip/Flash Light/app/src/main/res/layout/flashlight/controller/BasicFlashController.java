package flash.light.shine.com.flashlight.controller;

public class BasicFlashController extends BaseFlashController {
    private static BasicFlashController mBack;
    private static BasicFlashController mFront;

    /* Access modifiers changed, original: protected */
    public void afterCameraOpen() {
    }

    /* Access modifiers changed, original: protected */
    public void beforeCameraRelease() {
    }

    /* Access modifiers changed, original: protected */
    public void onStartUse() {
    }

    public static BasicFlashController getInstanceBack() {
        BasicFlashController basicFlashController = mBack;
        if (basicFlashController == null && basicFlashController == null) {
            mBack = new BasicFlashController(-1);
        }
        return mBack;
    }

    public static BasicFlashController getInstanceFront(int i) {
        BasicFlashController basicFlashController = mFront;
        if (basicFlashController == null && basicFlashController == null) {
            mFront = new BasicFlashController(i);
        }
        return mFront;
    }

    private BasicFlashController(int i) {
        super(i);
    }
}
