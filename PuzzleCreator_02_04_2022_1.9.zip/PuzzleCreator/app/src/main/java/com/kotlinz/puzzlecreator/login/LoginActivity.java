package com.kotlinz.puzzlecreator.login;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.puzzlecreator.activity.BaseActivity;
import com.kotlinz.puzzlecreator.activity.MainActivity;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.model.Credentials;
import com.kotlinz.puzzlecreator.retrofit.APIClient;
import com.kotlinz.puzzlecreator.retrofit.APIInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class LoginActivity extends BaseActivity {
    TextInputLayout tmobile, tpass;
    EditText edtmobile, edtpass;
    Button btnlogin;
    TextView txtclickhere, txtforgot;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtpass = (EditText) findViewById(R.id.edtpass);
        edtmobile = (EditText) findViewById(R.id.edtmobile);

        tpass = (TextInputLayout) findViewById(R.id.tpass);
        tmobile = (TextInputLayout) findViewById(R.id.tmobile);
        sessionManager.setFirstTimeLaunch(false);

        txtclickhere = (TextView) findViewById(R.id.txtclickhere);
        txtforgot = (TextView) findViewById(R.id.txtforgot);
        btnlogin = (Button) findViewById(R.id.btnlogin);

        txtclickhere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegistrationActivity.class);
                startActivity(intent);
            }
        });

        txtforgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
                startActivity(intent);
            }
        });

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtmobile.getText().toString().equalsIgnoreCase("")) {
                    tmobile.setErrorEnabled(true);
                    tmobile.setError("Enter Mobile Number");
                } else if (edtmobile.getText().toString().length() != 10) {
                    tmobile.setErrorEnabled(true);
                    tmobile.setError("Enter 10 Digit Mobile Number");
                } else if (edtpass.getText().toString().equalsIgnoreCase("")) {
                    tpass.setErrorEnabled(true);
                    tpass.setError("Enter Password");
                } else {
                    Login_user(edtmobile.getText().toString(), edtpass.getText().toString());
                }
            }
        });
    }

    private void Login_user(String number, String password) {
        showProgressDialog();
        Credentials loginCredentials = new Credentials();
        loginCredentials.mobile_number = number;
        loginCredentials.password = password;
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).loginUser(loginCredentials);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> res) {
                if (res.code() == 200) {
                    try {
                        String result = res.body().string();
                        Log.e("Responce", "........" + result);
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.getBoolean("status")) {
                            JSONObject response = jsonObject.getJSONObject("response");
                            sessionManager.setUserId(response.getString("user_id"));
                            sessionManager.setReferalCode(response.getString("referal_code"));
                            sessionManager.setUserName(response.getString("name"));
                            sessionManager.setUserPoints(response.getString("user_points"));
                            sessionManager.setUserType(response.getString("user_type"));
                            sessionManager.setToken("Bearer " + response.getString("token"));
                            sessionManager.createLoginSession(response.getString("mobile_number"));

                            Bundle params = new Bundle();
                            params.putString("User_type", sessionManager.getUserType());
                            mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.LOGIN, params);

                            cancel_dialog();

                            Intent i = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(i);
                            finish();

                        } else {
                            cancel_dialog();
                            showerrorDialog("Failed", jsonObject.getString("message"));
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                    cancel_dialog();
                } else {
                    try {
                        JSONObject obj = new JSONObject(res.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }
}