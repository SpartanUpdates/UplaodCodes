package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.activity.CollageMakerDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;

public class CollageImageSticker implements ImageStickerViewNew.c {
    public final  ImageStickerViewNew a;
    public final  CollageMakerDetailActivity b;

    public CollageImageSticker(CollageMakerDetailActivity collageMakerDetailActivity, ImageStickerViewNew imageStickerViewNew) {
        this.b = collageMakerDetailActivity;
        this.a = imageStickerViewNew;
    }

    public void a(ImageStickerViewNew imageStickerViewNew) {
        this.b.SvScroll.requestDisallowInterceptTouchEvent(true);
        ImageStickerViewNew imageStickerViewNew2 = this.b.p0;
        if (imageStickerViewNew2 != null) {
            imageStickerViewNew2.setInEdit(false);
        }
        imageStickerViewNew.setInEdit(true);
        this.b.p0 = imageStickerViewNew;
    }

    public void b(ImageStickerViewNew imageStickerViewNew) {
        this.b.flElements.removeView(imageStickerViewNew);
    }

    public void c(Boolean bool) {
        this.b.SvScroll.requestDisallowInterceptTouchEvent(bool.booleanValue());
        if (bool.booleanValue()) {
            this.b.p0 = this.a;
        }
    }

    public void d(ImageStickerViewNew imageStickerViewNew) {
    }
}
