package com.vidsoft.uvideostatus.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.vidsoft.uvideostatus.Activity.SearchActivity;
import com.vidsoft.uvideostatus.Models.VideoData;
import com.vidsoft.uvideostatus.R;
import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter<VideoData> implements OnClickListener {
    public ArrayList<VideoData> dataSet;
    private int lastPosition = -1;
    Context mContext;
    SearchActivity searchActivity;

    private static class ViewHolder {
        TextView txtName;

        private ViewHolder() {
        }
    }

    public CustomAdapter(ArrayList<VideoData> arrayList, Context context, SearchActivity searchActivity2) {
        super(context, R.layout.mylist, arrayList);
        this.dataSet = arrayList;
        this.mContext = context;
        this.searchActivity = searchActivity2;
    }

    public void onClick(View view) {
        VideoData videoData = (VideoData) getItem(((Integer) view.getTag()).intValue());
        view.getId();
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        View view2;
        ViewHolder viewHolder;
        VideoData videoData = (VideoData) getItem(i);
        if (view == null) {
            viewHolder = new ViewHolder();
            view2 = LayoutInflater.from(getContext()).inflate(R.layout.mylist, viewGroup, false);
            viewHolder.txtName = (TextView) view2.findViewById(R.id.title);
            view2.setTag(viewHolder);
        } else {
            view2 = view;
            viewHolder = (ViewHolder) view.getTag();
        }
        this.lastPosition = i;
        viewHolder.txtName.setText(videoData.getTitle());
        viewHolder.txtName.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CustomAdapter.this.searchActivity.searchitem(((VideoData) CustomAdapter.this.dataSet.get(i)).getTitle());
            }
        });
        return view2;
    }
}
