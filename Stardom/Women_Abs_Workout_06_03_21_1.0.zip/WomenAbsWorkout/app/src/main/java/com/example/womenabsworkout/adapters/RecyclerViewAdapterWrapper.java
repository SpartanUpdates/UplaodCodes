package com.example.womenabsworkout.adapters;

import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.AdapterDataObserver;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

public class RecyclerViewAdapterWrapper extends Adapter {
    public final Adapter<ViewHolder> wrapped;

    public RecyclerViewAdapterWrapper(Adapter adapter) {
        this.wrapped = adapter;
        adapter.registerAdapterDataObserver(new AdapterDataObserver() {
            public void onChanged() {
                RecyclerViewAdapterWrapper.this.notifyDataSetChanged();
            }

            public void onItemRangeChanged(int i, int i2) {
                RecyclerViewAdapterWrapper.this.notifyItemRangeChanged(i, i2);
            }

            public void onItemRangeInserted(int i, int i2) {
                RecyclerViewAdapterWrapper.this.notifyItemRangeInserted(i, i2);
            }

            public void onItemRangeMoved(int i, int i2, int i3) {
                RecyclerViewAdapterWrapper.this.notifyItemMoved(i, i2);
            }

            public void onItemRangeRemoved(int i, int i2) {
                RecyclerViewAdapterWrapper.this.notifyItemRangeRemoved(i, i2);
            }
        });
    }

    public int getItemCount() {
        return this.wrapped.getItemCount();
    }

    public long getItemId(int i) {
        return this.wrapped.getItemId(i);
    }

    public int getItemViewType(int i) {
        return this.wrapped.getItemViewType(i);
    }

    public Adapter<ViewHolder> getWrappedAdapter() {
        return this.wrapped;
    }

    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        this.wrapped.onAttachedToRecyclerView(recyclerView);
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        this.wrapped.onBindViewHolder(viewHolder, i);
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return this.wrapped.onCreateViewHolder(viewGroup, i);
    }

    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        this.wrapped.onDetachedFromRecyclerView(recyclerView);
    }

    public boolean onFailedToRecycleView(ViewHolder viewHolder) {
        return this.wrapped.onFailedToRecycleView(viewHolder);
    }

    public void onViewAttachedToWindow(ViewHolder viewHolder) {
        this.wrapped.onViewAttachedToWindow(viewHolder);
    }

    public void onViewDetachedFromWindow(ViewHolder viewHolder) {
        this.wrapped.onViewDetachedFromWindow(viewHolder);
    }

    public void onViewRecycled(ViewHolder viewHolder) {
        this.wrapped.onViewRecycled(viewHolder);
    }

    public void registerAdapterDataObserver(AdapterDataObserver adapterDataObserver) {
        this.wrapped.registerAdapterDataObserver(adapterDataObserver);
    }

    public void setHasStableIds(boolean z) {
        this.wrapped.setHasStableIds(z);
    }

    public void unregisterAdapterDataObserver(AdapterDataObserver adapterDataObserver) {
        this.wrapped.unregisterAdapterDataObserver(adapterDataObserver);
    }
}
