package com.esc.gesturelockscreen.Other;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.esc.gesturelockscreen.Other.PINLayout.IOnPadButtonClickListener;
import com.esc.gesturelockscreen.R;

public class PINLockLayout extends LinearLayout {
    private static int[] padDotIds = new int[]{R.id.passcode_dot1, R.id.passcode_dot2, R.id.passcode_dot3, R.id.passcode_dot4, R.id.passcode_dot5, R.id.passcode_dot6};
    private boolean enable = true;
    private IPasscodeListener mListener;
    private MODE myMode = MODE.MODE_VERIFY;
    private PINLayout padLayout;
    private String savedPassword = "";

    public interface IPasscodeListener {
        void onPasscodeCancel();

        void onPasscodeDot(MODE mode);

        void onPasscodeSuccess(MODE mode);

        void onPasscodeWrong(MODE mode);
    }

    public enum MODE {
        MODE_CREATE(R.string.passcode_title_create),
        MODE_CONFIRM(R.string.passcode_title_confirm),
        MODE_VERIFY(R.string.passcode_title_verify),
        MODE_WAIT(R.string.wait_sec);

        int textId;

        private MODE(int textId) {
            this.textId = textId;
        }
    }

    public PINLockLayout(Context context) {
        super(context);
        init();
    }

    public PINLockLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    @SuppressLint({"NewApi"})
    public PINLockLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @SuppressLint({"NewApi"})
    public PINLockLayout(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
    }

    private void init() {
        addView(LayoutInflater.from(getContext()).inflate(R.layout.layout_passcodelock, this, false));
        this.padLayout = (PINLayout) findViewById(R.id.passcode_layout);
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
        this.padLayout.setEnabled(enable);
    }

    public void init(MODE mode) {
        init(mode, SettingsUtils.getPasscodeLengthValue());
    }

    public void setEnabled(boolean enabled) {
        this.padLayout.setEnabled(enabled);
    }

    public void init(MODE mode, final int number) {
        setNewMode(mode);
        final String mypassword = SettingsUtils.getRecoveryPasscode();
        if (mypassword == null) {
            setNewMode(MODE.MODE_CREATE);
        }
        if (number < 6) {
            for (int i = number; i < padDotIds.length; i++) {
                findViewById(padDotIds[i]).setVisibility(GONE);
            }
        }
        findViewById(R.id.passcode_btn_clear).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                PINLockLayout.this.padLayout.onClearClicked();
            }
        });
        this.padLayout.setPadButtonListener(new IOnPadButtonClickListener() {
            public void onPadInput(String password) {
                if (PINLockLayout.this.mListener != null) {
                    PINLockLayout.this.onDotInput(password.length());
                    if (number == password.length()) {
                        if (PINLockLayout.this.myMode == MODE.MODE_CREATE) {
                            PINLockLayout.this.savedPassword = password;
                            PINLockLayout.this.setNewMode(MODE.MODE_CONFIRM);
                            PINLockLayout.this.animateToLeft();
                        } else if (PINLockLayout.this.myMode == MODE.MODE_CONFIRM) {
                            if (PINLockLayout.this.savedPassword.equals(password)) {
                                SettingsUtils.saveRecoveryPasscode(password, number);
                                PINLockLayout.this.mListener.onPasscodeSuccess(PINLockLayout.this.myMode);
                                return;
                            }
                            ((TextView) PINLockLayout.this.findViewById(R.id.passcode_lock_title)).setText(R.string.passcode_title_confirm_wrong);
                            PINLockLayout.this.switchToCreateMode(number);
                        } else if (PINLockLayout.this.myMode == MODE.MODE_VERIFY && mypassword != null) {
                            if (mypassword.equals(password)) {
                                PINLockLayout.this.mListener.onPasscodeSuccess(PINLockLayout.this.myMode);
                                PINLockLayout.this.mListener.onPasscodeDot(PINLockLayout.this.myMode);
                                return;
                            }
                            ((TextView) PINLockLayout.this.findViewById(R.id.passcode_lock_title)).setText(R.string.passcode_title_verify_wrong);
                            PINLockLayout.this.mListener.onPasscodeWrong(PINLockLayout.this.myMode);
                            PINLockLayout.this.shake();
                        }
                    } else if (password.length() > 0) {
                        PINLockLayout.this.mListener.onPasscodeDot(PINLockLayout.this.myMode);
                    }
                }
            }

            public void onCancel() {
                PINLockLayout.this.onDotInput(0);
                if (PINLockLayout.this.mListener != null) {
                    PINLockLayout.this.mListener.onPasscodeCancel();
                }
            }

            public int getMaxInputLimit() {
                return number;
            }

            public boolean isButtonEnable() {
                return PINLockLayout.this.enable && PINLockLayout.this.myMode != MODE.MODE_WAIT;
            }
        });
    }

    public void setNewMode(MODE mode) {
        if (this.myMode != mode) {
            this.myMode = mode;
            if (findViewById(R.id.passcode_lock_title) != null) {
                ((TextView) findViewById(R.id.passcode_lock_title)).setText(mode.textId);
            }
        }
    }

    private void animateFromRight() {
        onDotInput(0);
        Animation anim = new TranslateAnimation(2, 1.0f, 2, 0.0f, 1, 0.0f, 1, 0.0f);
        anim.setDuration(400);
        anim.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation arg0) {
            }

            @Override
            public void onAnimationRepeat(Animation arg0) {
            }

            @Override
            public void onAnimationEnd(Animation arg0) {
                ((TextView) PINLockLayout.this.findViewById(R.id.passcode_lock_title)).setText(PINLockLayout.this.myMode.textId);
                PINLockLayout.this.padLayout.reset(false);
                PINLockLayout.this.enable = true;
            }
        });
        findViewById(R.id.passcode_dot_parent).clearAnimation();
        findViewById(R.id.passcode_dot_parent).startAnimation(anim);
    }

    private void animateToLeft() {
        this.enable = false;
        Animation anim = new TranslateAnimation(2, 0.0f, 2, -1.0f, 1, 0.0f, 1, 0.0f);
        anim.setDuration(400);
        anim.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                PINLockLayout.this.animateFromRight();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        findViewById(R.id.passcode_dot_parent).clearAnimation();
        findViewById(R.id.passcode_dot_parent).startAnimation(anim);
    }

    private void shake() {
        this.enable = false;
        ObjectAnimator anim = ObjectAnimator.ofFloat(findViewById(R.id.passcode_dot_parent), "translationX", new float[]{0.0f, 30.0f, -28.0f, 25.0f, -25.0f, 15.0f, -15.0f, 6.0f, -6.0f, 0.0f}).setDuration(800);
        anim.addListener(new AnimatorListener() {
            @Override
            public void onAnimationStart(Animator arg0) {
            }

            @Override
            public void onAnimationRepeat(Animator arg0) {
            }

            @Override
            public void onAnimationEnd(Animator arg0) {
                ((TextView) PINLockLayout.this.findViewById(R.id.passcode_lock_title)).setText(PINLockLayout.this.myMode.textId);
                PINLockLayout.this.padLayout.reset(false);
                PINLockLayout.this.onDotInput(0);
                PINLockLayout.this.enable = true;
            }

            @Override
            public void onAnimationCancel(Animator arg0) {
                ((TextView) PINLockLayout.this.findViewById(R.id.passcode_lock_title)).setText(PINLockLayout.this.myMode.textId);
                PINLockLayout.this.padLayout.reset(false);
                PINLockLayout.this.onDotInput(0);
                PINLockLayout.this.enable = true;
            }
        });
        anim.start();
    }

    private void onDotInput(int size) {
        int i = 0;
        while (i < padDotIds.length) {
            View v = findViewById(padDotIds[i]);
            if (v.isSelected() || i >= size) {
                if (v.isSelected() && i >= size) {
                    v.setSelected(false);
                    v.clearAnimation();
                }
                i++;
            } else {
                v.setSelected(true);
                return;
            }
        }
    }

    public void setListener(IPasscodeListener l) {
        this.mListener = l;
    }

    private void close() {
        this.padLayout.pause();
        onDotInput(0);
    }

    public void switchToCreateMode(int number) {
        init(MODE.MODE_CREATE, number);
        this.padLayout.reset(false);
        animateToLeft();
    }

    public boolean initUserImage() {
        boolean random = SettingsUtils.getBoolean(SettingsKeys.RANDOM_KEYBOARD, false);
        if (random) {
            this.padLayout.onRandom(random);
        }
        return false;
    }

    public void setMessage(String message) {
        ((TextView) findViewById(R.id.passcode_lock_title)).setText(message);
    }

    public void setVisibility(int visibility) {
        super.setVisibility(visibility);
        if (visibility == 0) {
            this.padLayout.resume();
        } else {
            close();
        }
    }
}
