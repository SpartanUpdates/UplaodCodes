package com.esc.tarotcardreading;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SplashActivity extends AppCompatActivity implements View.OnClickListener {


    public static Boolean applaunched;
    public static Boolean call_to_main_frm_splash;
    private static boolean showIconAds = false;
    public static Boolean showanimation = Boolean.valueOf(true);
    boolean asdsad;
    private Runnable changeAdBool = new Runnable() {
        public void run() {
            SplashActivity.this.mHandler.postDelayed(SplashActivity.this.changeAdBool, 200);
            SplashActivity.showIconAds = false;
        }
    };
    ConsentInformation consentInformation;
    Dialog dialogD;
    SharedPreferences.Editor editor;
    SharedPreferences.Editor editor1;
//    LinearLayout exitlayout;
    TextView exittext;
    private ArrayList<String> icon_name = new ArrayList();
    public String locale = "";
    private Handler mHandler = new Handler();
    private String mediumicon = "Moreapps_AppIcons";
    Button nobtn;
    String[] publisherIds;
    Button rateusbtn;
    ImageButton settingsbtn;
    int sh;
    SharedPreferences sharedPreferences;
    SharedPreferences sharedPreferences1;
    private String source = "Tarot_Card_Reading";
    private boolean startbool = false;
//    Button startbtn;
    int sw;
    TextView[] textView = new TextView[6];
//    TextView titletxt;
//    Button yesbtn;

    static {
        Boolean valueOf = Boolean.valueOf(false);
        call_to_main_frm_splash = valueOf;
        applaunched = valueOf;
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash);
        showIconAds = false;
        String language = getResources().getConfiguration().locale.getLanguage();
        this.locale = language;
        if (language.contains("hi")) {

        } else {
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.sw = displayMetrics.widthPixels;
        this.sh = displayMetrics.heightPixels;
        SharedPreferences sharedPreferences = getSharedPreferences("MyPref", 0);
        this.sharedPreferences = sharedPreferences;
        this.editor = sharedPreferences.edit();
        sharedPreferences = getSharedPreferences(TaroQuestionsActivity.MyPREFERENCES, 0);
        this.sharedPreferences1 = sharedPreferences;
        this.editor1 = sharedPreferences.edit();
        if (!applaunched) {
            applaunched = Boolean.TRUE;
            String str = "applaunched";
            this.editor1.putInt(str, this.sharedPreferences1.getInt(str, 0) + 1);
            this.editor1.apply();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" Applaunched value ->");
            stringBuilder.append(this.sharedPreferences1.getInt(str, 0));
            Log.e("interstitial", stringBuilder.toString());
        }
        ImageButton imageButton = findViewById(R.id.settingsbtn);
        this.settingsbtn = imageButton;
        imageButton.setOnClickListener(this);
        ConsentInformation instance = ConsentInformation.getInstance(getApplicationContext());
        this.consentInformation = instance;
        this.publisherIds = new String[]{"pub-4933880264960213"};
        this.asdsad = instance.isRequestLocationInEeaOrUnknown();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("***********");
        stringBuilder2.append(this.asdsad);
        Log.e("AAAAAAAAAAAA", stringBuilder2.toString());
        stopRunnable();
        startActivity(new Intent(this, TaroQuestionsActivity.class));
        call_to_main_frm_splash = Boolean.TRUE;
        EUCONSENT_DEMO1();
    }

    public void EUCONSENT_DEMO1() {
        this.consentInformation.requestConsentInfoUpdate(this.publisherIds, new ConsentInfoUpdateListener() {
            public void onFailedToUpdateConsentInfo(String str) {
            }

            public void onConsentInfoUpdated(ConsentStatus consentStatus) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("consentStatus = '");
                stringBuilder.append(consentStatus);
                stringBuilder.append("\n");
                String str = "googleads_consent_np";
                stringBuilder.append(SplashActivity.this.sharedPreferences.getBoolean(str, false));
                String str2 = "AAAAAAAAAAAA";
                Log.e(str2, stringBuilder.toString());
                String str3 = "***********";
                String str4 = "googleads_consent";
                SplashActivity splashActivity;
                StringBuilder stringBuilder2;
                if (consentStatus.equals(ConsentStatus.UNKNOWN)) {
                    if (SplashActivity.this.consentInformation.isRequestLocationInEeaOrUnknown()) {
                        SplashActivity.this.editor.putBoolean(str4, false);
                        SplashActivity.this.editor.commit();
                        SplashActivity.this.EUCONSENT_DEMO();
                        splashActivity = SplashActivity.this;
                        splashActivity.asdsad = splashActivity.consentInformation.isRequestLocationInEeaOrUnknown();
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(str3);
                        stringBuilder2.append(SplashActivity.this.asdsad);
                        Log.e(str2, stringBuilder2.toString());
                        SplashActivity.this.settingsbtn.setVisibility(View.VISIBLE);
                        return;
                    }
                    SplashActivity.this.settingsbtn.setVisibility(View.GONE);
                    SplashActivity.this.editor.putBoolean(str, false);
                    SplashActivity.this.editor.commit();
                } else if (!SplashActivity.this.consentInformation.isRequestLocationInEeaOrUnknown()) {
                } else {
                    if (consentStatus.equals(ConsentStatus.PERSONALIZED) || consentStatus.equals(ConsentStatus.NON_PERSONALIZED)) {
                        splashActivity = SplashActivity.this;
                        splashActivity.asdsad = splashActivity.consentInformation.isRequestLocationInEeaOrUnknown();
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(str3);
                        stringBuilder2.append(SplashActivity.this.asdsad);
                        Log.e(str2, stringBuilder2.toString());
                        SplashActivity.this.settingsbtn.setVisibility(View.VISIBLE);
                        if (!SplashActivity.this.sharedPreferences.getBoolean(str4, false)) {
                            SplashActivity.this.editor.putBoolean(str4, false);
                            SplashActivity.this.editor.commit();
                            SplashActivity.this.EUCONSENT_DEMO();
                        }
                    }
                }
            }
        });
        if (this.sharedPreferences.getBoolean("googleads_consent", false)) {
            this.settingsbtn.setVisibility(View.VISIBLE);
        }
    }

    public void EUCONSENT_DEMO() {
        Dialog dialog = this.dialogD;
        if (dialog == null || !dialog.isShowing()) {
            View inflate = View.inflate(this, R.layout.consent_iagree, null);
            Dialog dialog2 = new Dialog(this);
            this.dialogD = dialog2;
            dialog2.getWindow();
            dialog2.requestWindowFeature(1);
            this.dialogD.setContentView(inflate);
            this.dialogD.setCancelable(false);
            TextView textView = this.dialogD.findViewById(R.id.displayads_text);
            textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            textView.setText(getResources().getString(R.string.msg));
            Button button = this.dialogD.findViewById(R.id.btn_agree);
            button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    SplashActivity.this.editor.putBoolean("googleads_consent", true);
                    SplashActivity.this.editor.commit();
                    SplashActivity.this.editor.putBoolean("googleads_consent_np", true);
                    SplashActivity.this.editor.commit();
                    SplashActivity.this.consentInformation.setConsentStatus(ConsentStatus.NON_PERSONALIZED);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("consentStatus = '");
                    stringBuilder.append(SplashActivity.this.consentInformation.getConsentStatus());
                    Log.e("AAAAAAAAAAAA", stringBuilder.toString());
                    SplashActivity.this.dialogD.cancel();
                }
            });
            TextView textView2 = this.dialogD.findViewById(R.id.displayads_text2);
            textView2.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            textView2.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    SplashActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://www.touchzing.com/privacy/")));
                }
            });
            ViewGroup.LayoutParams layoutParams;
            double d;
            if ((getResources().getConfiguration().screenLayout & 15) == 4) {
                textView.setTextSize(32.0f);
                textView2.setTextSize(28.0f);
                button.setTextSize(36.0f);
                layoutParams = button.getLayoutParams();
                d = this.sw;
                Double.isNaN(d);
                layoutParams.height = (int) (d * 0.11d);
            } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
                textView.setTextSize(28.0f);
                textView2.setTextSize(24.0f);
                button.setTextSize(30.0f);
                layoutParams = button.getLayoutParams();
                d = this.sw;
                Double.isNaN(d);
                layoutParams.height = (int) (d * 0.13d);
            } else {
                textView.setTextSize(18.0f);
                textView2.setTextSize(16.0f);
                button.setTextSize(22.0f);
                layoutParams = button.getLayoutParams();
                d = this.sw;
                Double.isNaN(d);
                layoutParams.height = (int) (d * 0.15d);
            }
            if (!isFinishing()) {
                this.dialogD.show();
            }
        }
    }

    public void onClick(View view) {
        int id = view.getId();
        String str4 = "android.intent.action.VIEW";
        switch (id) {

            case R.id.settingsbtn:
                stopRunnable();
                startActivity(new Intent(this, SettingsActivity.class));
                return;

            default:
                return;
        }
    }

    public void onBackPressed() {

    }


    public void onDestroy() {
        super.onDestroy();
    }


    public void onResume() {
        super.onResume();
        if (TaroQuestionsActivity.exitbool) {
            TaroQuestionsActivity.exitbool = false;
        } else if (showanimation) {
            TranslateAnimation translateAnimation = new TranslateAnimation(-1000.0f, 0.0f, 0.0f, 0.0f);
            translateAnimation.setStartTime(1500);
            translateAnimation.setDuration(2000);
            showanimation = Boolean.FALSE;
        }
        EUCONSENT_DEMO1();
    }


    private boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    private void stopRunnable() {
        if (this.startbool) {
            Log.e("AAAAA", "Moreapps getData  stoprunnable   SA");
            this.mHandler.removeCallbacks(this.changeAdBool);
            this.startbool = false;
        }
    }

    private void startRunnable() {
        if (!this.startbool) {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());
            this.startbool = true;
            this.changeAdBool.run();
            Log.e("AAAAA", "Moreapps getData startrunnable   SA");
        }
    }

    public void attachBaseContext(Context context) {
        super.attachBaseContext(Utils.changeLang(context, context.getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE).getString("languagetoload", "en")));
    }
}