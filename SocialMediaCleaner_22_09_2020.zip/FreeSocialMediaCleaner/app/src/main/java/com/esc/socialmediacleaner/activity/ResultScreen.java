package com.esc.socialmediacleaner.activity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.drawable.Animatable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.kprogresshud.KProgressHUD;
import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.util.SavedData;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class ResultScreen extends ShareAppScreen implements OnClickListener {
    private boolean dialogShown = false;
    private long lastClickedTime = 0;
    private int vcount;
    private ImageView iv_back;

    public int getFacePosition() {
        return super.getFacePosition();
    }

    public void hideKeyboard() {
        super.hideKeyboard();
    }

    public boolean isEmailValid(String str) {
        return super.isEmailValid(str);
    }

    public void setFacePosition(int i) {
        super.setFacePosition(i);
    }

    public void shareApp() {
        super.shareApp();
    }


    public void toast(String str) {
        super.toast(str);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_result_screen);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle((CharSequence) "");
        track("RESULT_VISIT");

        MyApplication.getInstance().allData.dataDeleted = true;
        iv_back = findViewById(R.id.iv_back);
        TextView textView = (TextView) findViewById(R.id.tv_resmsg);
        TextView textView2 = (TextView) findViewById(R.id.tv_title);
        findViewById(R.id.iv_rate).setOnClickListener(this);
        findViewById(R.id.iv_share).setOnClickListener(this);
        String stringExtra = getIntent().getStringExtra("MESSAGE");
        String stringExtra2 = getIntent().getStringExtra("TITLE");
        textView.setText(stringExtra);
        textView2.setText(stringExtra2);
        ((Animatable) ((ImageView) findViewById(R.id.img)).getDrawable()).start();
        loadAd();
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_rate:
                try {
                    startActivity(new Intent(
                            "android.intent.action.VIEW",
                            Uri.parse(getResources().getString(R.string.rate_us)
                                    + getPackageName())));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(ResultScreen.this, "You don't have Google Play installed",
                            Toast.LENGTH_SHORT).show();
                }
                return;
            case R.id.iv_share:
                if (!doubleClicked()) {
                    shareApp();
                    break;
                }
                return;

            case R.id.iv_back:
                id = 100;
                if (interstitial !=null && interstitial.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    onBackPressed();
                }
                break;
        }
    }

    private boolean checkDialogCondition() {
        return this.vcount == 0 && !new SavedData(this).getBoolean(SavedData.RATED);
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    public boolean doubleClicked() {
        long elapsedRealtime = SystemClock.elapsedRealtime() - this.lastClickedTime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("diff ");
        stringBuilder.append(elapsedRealtime);
        Log.e("TTTTTTTTT", stringBuilder.toString());
        this.lastClickedTime = SystemClock.elapsedRealtime();
        return elapsedRealtime < 600;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        finish();
        return super.onOptionsItemSelected(menuItem);
    }

    private FrameLayout adContainerView;
    private InterstitialAd interstitial;
    private AdView adView;
    private int id;
    private KProgressHUD hud;

    private void loadAd()
    {
        //AdaptiveBannerAd
        adContainerView = findViewById(R.id.ad_view_container);
        adView = new AdView(this);
        adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
        adContainerView.addView(adView);

        AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();

        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(adRequest);

        //InterstitialAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(ResultScreen.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {

                switch (id)
                {
                    case 100:
                        onBackPressed();
                        break;

                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ResultScreen.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
