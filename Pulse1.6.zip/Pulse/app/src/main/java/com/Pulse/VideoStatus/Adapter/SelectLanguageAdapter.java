package com.Pulse.VideoStatus.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.Pulse.VideoStatus.Model.LanguageModel;
import com.Pulse.VideoStatus.R;

import java.util.ArrayList;


public class SelectLanguageAdapter extends RecyclerView.Adapter<SelectLanguageAdapter.VideoHolder> {

    Context context;
    private ArrayList<LanguageModel> languageList;

    public SelectLanguageAdapter(Context context, ArrayList<LanguageModel> languageList) {
        this.context = context;
        this.languageList = languageList;
    }

    @NonNull
    @Override
    public VideoHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.select_country_language_item, viewGroup, false);
        return new VideoHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final VideoHolder videoHolder, int position) {
        final LanguageModel languageModel = languageList.get(position);
        videoHolder.tvlanguageName.setText(languageModel.getLanName());
        videoHolder.Ivcaticon.setImageResource(getCatIcon(languageList.get(position).getLanName()));
        videoHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videoHolder.cblanguage.toggle();
            }
        });
        videoHolder.cblanguage.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                languageModel.d = isChecked;
            }
        });
        videoHolder.cblanguage.setChecked(languageModel.d);
    }

    @Override
    public int getItemCount() {
        return languageList.size();
    }

    private int getCatIcon(String str) {
        str = str.toLowerCase();
//        return str.contains("love") ? R.drawable.icon_love : str.contains("Rajashthahni") ? R.drawable.icon_love : str.contains("festival") ? R.drawable.icon_festival : str.contains("krishna") ? R.drawable.icon_radhe_krishna : str.contains("ganesha") ? R.drawable.icon_ganesha : str.contains("balaji") ? R.drawable.icon_jay_balaji : str.contains("mahadev") ? R.drawable.icon_mahadev : str.contains("premium") ? R.drawable.icon_premium : str.contains("birthday") ? R.drawable.icon_birthday : str.contains("god") ? R.drawable.icon_gods : str.contains("shree ram") ? R.drawable.icon_shree_ram : str.contains("wedding") ? R.drawable.icon_wedding : str.contains("wish") ? R.drawable.icon_wish : str.contains("popular") ? R.drawable.icon_premium : str.contains("telugu") ? R.drawable.icon_telugu : str.contains("tamil") ? R.drawable.icon_tamil : str.contains("bhojpuri") ? R.drawable.icon_bhojpuri : str.contains("diwali") ? R.drawable.icon_diwali : str.contains("english") ? R.drawable.icon_eng : str.contains("friendship") ? R.drawable.icon_friendship : str.contains("gujarati") ? R.drawable.icon_gujarati : str.contains("hindi") ? R.drawable.icon_hindi : str.contains("kannada") ? R.drawable.icon_kannada : str.contains("malayalam") ? R.drawable.icon_malayalam : str.contains("marathi") ? R.drawable.icon_marathi : str.contains("navratri") ? R.drawable.icon_navratri : str.contains("sad") ? R.drawable.icon_sad : str.contains("day events") ? R.drawable.icon_dayevents : str.contains("patriotic") ? R.drawable.icon_patriotic : str.contains("christmas") ? R.drawable.icon_christmas : str.contains("rockstar") ? R.drawable.icon_rockstar : str.contains("islamic") ? R.drawable.icon_islamic : str.contains("bengali") ? R.drawable.icon_bengali : str.contains("punjabi") ? R.drawable.icon_punjabi : str.contains("tiktok") ? R.drawable.icon_tiktok : R.drawable.icon_defualt;
        return 0;
    }

    public class VideoHolder extends RecyclerView.ViewHolder {

        CheckBox cblanguage;
        ImageView Ivcaticon;
        TextView tvlanguageName;

        private VideoHolder(@NonNull View itemView) {
            super(itemView);
            cblanguage = itemView.findViewById(R.id.cbLanguage);
            Ivcaticon = itemView.findViewById(R.id.ivImage);
            tvlanguageName = itemView.findViewById(R.id.tvName);
        }
    }
}
