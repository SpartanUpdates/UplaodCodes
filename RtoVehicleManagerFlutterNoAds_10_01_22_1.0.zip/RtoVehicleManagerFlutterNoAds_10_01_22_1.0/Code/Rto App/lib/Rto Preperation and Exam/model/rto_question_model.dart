// To parse this JSON data, do
//
//     final rtoQuestionModel = rtoQuestionModelFromJson(jsonString);

import 'dart:convert';

List<RtoQuestionModel> rtoQuestionModelFromJson(String str) =>
    List<RtoQuestionModel>.from(
        json.decode(str).map((x) => RtoQuestionModel.fromJson(x)));

String rtoQuestionModelToJson(List<RtoQuestionModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class RtoQuestionModel {
  RtoQuestionModel({
    required this.questionNo,
    required this.question,
    required this.optionA,
    required this.optionB,
    required this.optionC,
    required this.answer,
  });

  int questionNo;
  String question;
  String optionA;
  String optionB;
  String optionC;
  String answer;

  factory RtoQuestionModel.fromJson(Map<String, dynamic> json) =>
      RtoQuestionModel(
        questionNo: json["questionNo"],
        question: json["question"],
        optionA: json["optionA"],
        optionB: json["optionB"],
        optionC: json["optionC"],
        answer: json["answer"],
      );

  Map<String, dynamic> toJson() => {
        "questionNo": questionNo,
        "question": question,
        "optionA": optionA,
        "optionB": optionB,
        "optionC": optionC,
        "answer": answer,
      };
}
