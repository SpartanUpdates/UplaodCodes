package com.kotlinz.videoCollage.crop;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Pair;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;

public class CropOverlayView extends View {
    private static final float DEFAULT_CORNER_EXTENSION_DP;
    private static final float DEFAULT_CORNER_LENGTH_DP = 20.0f;
    private static final float DEFAULT_CORNER_OFFSET_DP;
    private static final float DEFAULT_CORNER_THICKNESS_DP = PaintUtil.getCornerThickness();
    private static final float DEFAULT_LINE_THICKNESS_DP;
    private static final float DEFAULT_SHOW_GUIDELINES_LIMIT = 100.0f;
    private static final int GUIDELINES_OFF = 0;
    private static final int GUIDELINES_ON = 2;
    private static final int GUIDELINES_ON_TOUCH = 1;
    private static final int SNAP_RADIUS_DP = 6;
    private boolean initializedCropWindow = false;
    private int mAspectRatioX = 1;
    private int mAspectRatioY = 1;
    private Paint mBackgroundPaint;
    private Rect mBitmapRect;
    private Paint mBorderPaint;
    private float mCornerExtension;
    private float mCornerLength;
    private float mCornerOffset;
    private Paint mCornerPaint;
    private boolean mFixAspectRatio = false;
    private Paint mGuidelinePaint;
    private int mGuidelines;
    private float mHandleRadius;
    private Handle mPressedHandle;
    private float mSnapRadius;
    private float mTargetAspectRatio = (((float) 1) / ((float) 1));
    private Pair<Float, Float> mTouchOffset;

    static {
        float lineThickness = PaintUtil.getLineThickness();
        DEFAULT_LINE_THICKNESS_DP = lineThickness;
        float f = DEFAULT_CORNER_THICKNESS_DP;
        float f2 = (f / 2.0f) - (lineThickness / 2.0f);
        DEFAULT_CORNER_OFFSET_DP = f2;
        DEFAULT_CORNER_EXTENSION_DP = (f / 2.0f) + f2;
    }

    public CropOverlayView(Context context) {
        super(context);
        init(context);
    }

    public CropOverlayView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        initCropWindow(this.mBitmapRect);
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawBackground(canvas, this.mBitmapRect);
        if (showGuidelines()) {
            int i = this.mGuidelines;
            if (i == 2) {
                drawRuleOfThirdsGuidelines(canvas);
            } else if (i == 1 && this.mPressedHandle != null) {
                drawRuleOfThirdsGuidelines(canvas);
            }
        }
        canvas.drawRect(Edge.LEFT.getCoordinate(), Edge.TOP.getCoordinate(), Edge.RIGHT.getCoordinate(), Edge.BOTTOM.getCoordinate(), this.mBorderPaint);
        drawCorners(canvas);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!isEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 0) {
            if (action != 1) {
                if (action == 2) {
                    onActionMove(motionEvent.getX(), motionEvent.getY());
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                } else if (action != 3) {
                    return false;
                }
            }
            getParent().requestDisallowInterceptTouchEvent(false);
            onActionUp();
            return true;
        }
        onActionDown(motionEvent.getX(), motionEvent.getY());
        return true;
    }

    public void setBitmapRect(Rect rect) {
        this.mBitmapRect = rect;
        initCropWindow(rect);
    }

    public void resetCropOverlayView() {
        if (this.initializedCropWindow) {
            initCropWindow(this.mBitmapRect);
            invalidate();
        }
    }

    public void setGuidelines(int i) {
        if (i < 0 || i > 2) {
            throw new IllegalArgumentException("Guideline value must be set between 0 and 2. See documentation.");
        }
        this.mGuidelines = i;
        if (this.initializedCropWindow) {
            initCropWindow(this.mBitmapRect);
            invalidate();
        }
    }

    public void setFixedAspectRatio(boolean z) {
        this.mFixAspectRatio = z;
        if (this.initializedCropWindow) {
            initCropWindow(this.mBitmapRect);
            invalidate();
        }
    }

    public void setAspectRatioX(int i) {
        if (i > 0) {
            this.mAspectRatioX = i;
            this.mTargetAspectRatio = ((float) i) / ((float) this.mAspectRatioY);
            if (this.initializedCropWindow) {
                initCropWindow(this.mBitmapRect);
                invalidate();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Cannot set aspect ratio value to a number less than or equal to 0.");
    }

    public void setAspectRatioY(int i) {
        if (i > 0) {
            this.mAspectRatioY = i;
            this.mTargetAspectRatio = ((float) this.mAspectRatioX) / ((float) i);
            if (this.initializedCropWindow) {
                initCropWindow(this.mBitmapRect);
                invalidate();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Cannot set aspect ratio value to a number less than or equal to 0.");
    }

    public void setInitialAttributeValues(int i, boolean z, int i2, int i3) {
        if (i < 0 || i > 2) {
            throw new IllegalArgumentException("Guideline value must be set between 0 and 2. See documentation.");
        }
        this.mGuidelines = i;
        this.mFixAspectRatio = z;
        String str = "Cannot set aspect ratio value to a number less than or equal to 0.";
        if (i2 > 0) {
            this.mAspectRatioX = i2;
            this.mTargetAspectRatio = ((float) i2) / ((float) this.mAspectRatioY);
            if (i3 > 0) {
                this.mAspectRatioY = i3;
                this.mTargetAspectRatio = ((float) i2) / ((float) i3);
                return;
            }
            throw new IllegalArgumentException(str);
        }
        throw new IllegalArgumentException(str);
    }

    private void init(Context context) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        this.mHandleRadius = HandleUtil.getTargetRadius(context);
        this.mSnapRadius = TypedValue.applyDimension(1, 6.0f, displayMetrics);
        this.mBorderPaint = PaintUtil.newBorderPaint(context);
        this.mGuidelinePaint = PaintUtil.newGuidelinePaint();
        this.mBackgroundPaint = PaintUtil.newBackgroundPaint(context);
        this.mCornerPaint = PaintUtil.newCornerPaint(context);
        this.mCornerOffset = TypedValue.applyDimension(1, DEFAULT_CORNER_OFFSET_DP, displayMetrics);
        this.mCornerExtension = TypedValue.applyDimension(1, DEFAULT_CORNER_EXTENSION_DP, displayMetrics);
        this.mCornerLength = TypedValue.applyDimension(1, DEFAULT_CORNER_LENGTH_DP, displayMetrics);
        this.mGuidelines = 1;
    }

    private void initCropWindow(Rect rect) {
        if (!this.initializedCropWindow) {
            this.initializedCropWindow = true;
        }
        float width;
        float width2;
        if (!this.mFixAspectRatio) {
            width = ((float) rect.width()) * 0.1f;
            float height = ((float) rect.height()) * 0.1f;
            Edge.LEFT.setCoordinate(((float) rect.left) + width);
            Edge.TOP.setCoordinate(((float) rect.top) + height);
            Edge.RIGHT.setCoordinate(((float) rect.right) - width);
            Edge.BOTTOM.setCoordinate(((float) rect.bottom) - height);
        } else if (AspectRatioUtil.calculateAspectRatio(rect) > this.mTargetAspectRatio) {
            Edge.TOP.setCoordinate((float) rect.top);
            Edge.BOTTOM.setCoordinate((float) rect.bottom);
            width2 = ((float) getWidth()) / 2.0f;
            width = Math.max(40.0f, AspectRatioUtil.calculateWidth(Edge.TOP.getCoordinate(), Edge.BOTTOM.getCoordinate(), this.mTargetAspectRatio));
            if (width == 40.0f) {
                this.mTargetAspectRatio = 40.0f / (Edge.BOTTOM.getCoordinate() - Edge.TOP.getCoordinate());
            }
            width /= 2.0f;
            Edge.LEFT.setCoordinate(width2 - width);
            Edge.RIGHT.setCoordinate(width2 + width);
        } else {
            Edge.LEFT.setCoordinate((float) rect.left);
            Edge.RIGHT.setCoordinate((float) rect.right);
            width2 = ((float) getHeight()) / 2.0f;
            width = Math.max(40.0f, AspectRatioUtil.calculateHeight(Edge.LEFT.getCoordinate(), Edge.RIGHT.getCoordinate(), this.mTargetAspectRatio));
            if (width == 40.0f) {
                this.mTargetAspectRatio = (Edge.RIGHT.getCoordinate() - Edge.LEFT.getCoordinate()) / 40.0f;
            }
            width /= 2.0f;
            Edge.TOP.setCoordinate(width2 - width);
            Edge.BOTTOM.setCoordinate(width2 + width);
        }
    }

    public static boolean showGuidelines() {
        return Math.abs(Edge.LEFT.getCoordinate() - Edge.RIGHT.getCoordinate()) >= DEFAULT_SHOW_GUIDELINES_LIMIT && Math.abs(Edge.TOP.getCoordinate() - Edge.BOTTOM.getCoordinate()) >= DEFAULT_SHOW_GUIDELINES_LIMIT;
    }

    private void drawRuleOfThirdsGuidelines(Canvas canvas) {
        float coordinate = Edge.LEFT.getCoordinate();
        float coordinate2 = Edge.TOP.getCoordinate();
        float coordinate3 = Edge.RIGHT.getCoordinate();
        float coordinate4 = Edge.BOTTOM.getCoordinate();
        float width = Edge.getWidth() / 3.0f;
        float f = coordinate + width;
        Canvas canvas2 = canvas;
        float f2 = coordinate2;
        float f3 = coordinate4;
        canvas2.drawLine(f, f2, f, f3, this.mGuidelinePaint);
        f = coordinate3 - width;
        canvas2.drawLine(f, f2, f, f3, this.mGuidelinePaint);
        float height = Edge.getHeight() / 3.0f;
        f = coordinate2 + height;
        Canvas canvas3 = canvas;
        float f4 = coordinate;
        f2 = coordinate3;
        canvas3.drawLine(f4, f, f2, f, this.mGuidelinePaint);
        f = coordinate4 - height;
        canvas3.drawLine(f4, f, f2, f, this.mGuidelinePaint);
    }

    private void drawBackground(Canvas canvas, Rect rect) {
        float coordinate = Edge.LEFT.getCoordinate();
        float coordinate2 = Edge.TOP.getCoordinate();
        float coordinate3 = Edge.RIGHT.getCoordinate();
        float coordinate4 = Edge.BOTTOM.getCoordinate();
        Canvas canvas2 = canvas;
        canvas2.drawRect((float) rect.left, (float) rect.top, (float) rect.right, coordinate2, this.mBackgroundPaint);
        canvas2.drawRect((float) rect.left, coordinate4, (float) rect.right, (float) rect.bottom, this.mBackgroundPaint);
        canvas.drawRect((float) rect.left, coordinate2, coordinate, coordinate4, this.mBackgroundPaint);
        canvas.drawRect(coordinate3, coordinate2, (float) rect.right, coordinate4, this.mBackgroundPaint);
    }

    private void drawCorners(Canvas canvas) {
        float coordinate = Edge.LEFT.getCoordinate();
        float coordinate2 = Edge.TOP.getCoordinate();
        float coordinate3 = Edge.RIGHT.getCoordinate();
        float coordinate4 = Edge.BOTTOM.getCoordinate();
        float f = this.mCornerOffset;
        Canvas canvas2 = canvas;
        canvas2.drawLine(coordinate - f, coordinate2 - this.mCornerExtension, coordinate - f, coordinate2 + this.mCornerLength, this.mCornerPaint);
        f = this.mCornerOffset;
        canvas.drawLine(coordinate, coordinate2 - f, coordinate + this.mCornerLength, coordinate2 - f, this.mCornerPaint);
        f = this.mCornerOffset;
        canvas2.drawLine(coordinate3 + f, coordinate2 - this.mCornerExtension, coordinate3 + f, coordinate2 + this.mCornerLength, this.mCornerPaint);
        f = this.mCornerOffset;
        float f2 = coordinate3;
        canvas2.drawLine(f2, coordinate2 - f, coordinate3 - this.mCornerLength, coordinate2 - f, this.mCornerPaint);
        f = this.mCornerOffset;
        canvas.drawLine(coordinate - f, coordinate4 + this.mCornerExtension, coordinate - f, coordinate4 - this.mCornerLength, this.mCornerPaint);
        f = this.mCornerOffset;
        canvas.drawLine(coordinate, coordinate4 + f, coordinate + this.mCornerLength, coordinate4 + f, this.mCornerPaint);
        coordinate = this.mCornerOffset;
        canvas.drawLine(coordinate3 + coordinate, coordinate4 + this.mCornerExtension, coordinate3 + coordinate, coordinate4 - this.mCornerLength, this.mCornerPaint);
        coordinate = this.mCornerOffset;
        canvas2.drawLine(f2, coordinate4 + coordinate, coordinate3 - this.mCornerLength, coordinate4 + coordinate, this.mCornerPaint);
    }

    private void onActionDown(float f, float f2) {
        float coordinate = Edge.LEFT.getCoordinate();
        float coordinate2 = Edge.TOP.getCoordinate();
        float coordinate3 = Edge.RIGHT.getCoordinate();
        float coordinate4 = Edge.BOTTOM.getCoordinate();
        Handle pressedHandle = HandleUtil.getPressedHandle(f, f2, coordinate, coordinate2, coordinate3, coordinate4, this.mHandleRadius);
        this.mPressedHandle = pressedHandle;
        if (pressedHandle != null) {
            this.mTouchOffset = HandleUtil.getOffset(pressedHandle, f, f2, coordinate, coordinate2, coordinate3, coordinate4);
            invalidate();
        }
    }

    private void onActionUp() {
        if (this.mPressedHandle != null) {
            this.mPressedHandle = null;
            invalidate();
        }
    }

    private void onActionMove(float f, float f2) {
        if (this.mPressedHandle != null) {
            float floatValue = f + ((Float) this.mTouchOffset.first).floatValue();
            float floatValue2 = f2 + ((Float) this.mTouchOffset.second).floatValue();
            if (this.mFixAspectRatio) {
                this.mPressedHandle.updateCropWindow(floatValue, floatValue2, this.mTargetAspectRatio, this.mBitmapRect, this.mSnapRadius);
            } else {
                this.mPressedHandle.updateCropWindow(floatValue, floatValue2, this.mBitmapRect, this.mSnapRadius);
            }
            invalidate();
        }
    }
}
