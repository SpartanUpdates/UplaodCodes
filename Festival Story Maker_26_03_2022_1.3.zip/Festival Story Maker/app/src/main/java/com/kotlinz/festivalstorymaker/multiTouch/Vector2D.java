package com.kotlinz.festivalstorymaker.multiTouch;

import android.graphics.PointF;

public class Vector2D extends PointF
{
    public static float a(final Vector2D vector2D, final Vector2D vector2D2) {
        vector2D.b();
        vector2D2.b();
        return (float)((Math.atan2(vector2D2.y, vector2D2.x) - Math.atan2(vector2D.y, vector2D.x)) * 57.29577951308232);
    }

    public void b() {
        final float x = super.x;
        final float y = super.y;
        final float n = (float)Math.sqrt(y * y + x * x);
        super.x /= n;
        super.y /= n;
    }
}
