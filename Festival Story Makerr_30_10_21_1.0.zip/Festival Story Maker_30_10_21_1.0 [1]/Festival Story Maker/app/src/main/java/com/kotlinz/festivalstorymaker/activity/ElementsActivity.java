package com.kotlinz.festivalstorymaker.activity;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.ElementCategoryListAdapter;
import com.kotlinz.festivalstorymaker.Adapter.ElementsCatImageListAdapter;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.Element.ElementMainResponse;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.Element.ElementResponse;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ElementsActivity extends BaseActivity {

    Activity activity = ElementsActivity.this;

    @BindView(R.id.listBackgroundCat)
    public RecyclerView rvElementCategory;
    @BindView(R.id.listBackgroundCatImage)
    public RecyclerView rvElementImage;


    private ProgressDialog progressDialog;
    APIInterface apiInterface;

    ArrayList<ElementMainResponse> elementMainResponseArrayList = new ArrayList<>();
    ElementCategoryListAdapter elementCategoryListAdapter;
    ElementsCatImageListAdapter elementsCatImageListAdapter;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private int ModuleId;


    public class b implements ElementsCatImageListAdapter.a {
        public final int a;

        public b(int i) {
            this.a = i;
        }

        public void a(int i) {
            Intent intent = new Intent();
            intent.putExtra("element", elementMainResponseArrayList.get(a).getElementImages().get(i).getThemeThumbnail());
            ElementsActivity.this.setResult(45, intent);
            ElementsActivity.this.finish();
        }
    }

    public final void GetCategoryWiseElementData(int i) {
        elementsCatImageListAdapter = new ElementsCatImageListAdapter(activity, elementMainResponseArrayList.get(i).getElementImages(), new b(i));
        rvElementImage.setLayoutManager(new GridLayoutManager(activity, 3, RecyclerView.VERTICAL, false));
        rvElementImage.setAdapter(elementsCatImageListAdapter);
    }

    @OnClick(R.id.iv_back)
    public void onClick(View view) {
        if (MyApplication.isShowAd == 1) {
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 15;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                finish();
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elements);
        ButterKnife.bind(this);
        PutAnalyticsEvent();
        ModuleId = getIntent().getIntExtra("moduleid", 0);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        InitProgressDialog();
        BannerAds();
        if (Utils.x(this)) {
            GetElementData(ModuleId);
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ElementsActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void GetElementData(int ModuleId) {
        progressDialog.show();
        Call<ElementResponse> call = apiInterface.getElementDetails(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<ElementResponse>() {
            @Override
            public void onResponse(Call<ElementResponse> call, Response<ElementResponse> response) {
                if (response.isSuccessful()) {
                    elementMainResponseArrayList = response.body().getData();
                    elementCategoryListAdapter = new ElementCategoryListAdapter(activity, elementMainResponseArrayList);
                    rvElementCategory.setLayoutManager(new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false));
                    rvElementCategory.setAdapter(elementCategoryListAdapter);
                    GetCategoryWiseElementData(0);
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<ElementResponse> call, Throwable t) {

            }
        });
    }
}