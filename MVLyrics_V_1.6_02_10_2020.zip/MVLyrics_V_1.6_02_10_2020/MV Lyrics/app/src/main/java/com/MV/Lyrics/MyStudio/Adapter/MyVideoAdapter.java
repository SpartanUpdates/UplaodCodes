package com.MV.Lyrics.MyStudio.Adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import com.bumptech.glide.Glide;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.MyStudio.Model.MyVideoModel;
import com.MV.Lyrics.MyStudio.activity.YourVideoActivity;
import com.MV.Lyrics.R;
import com.MV.Lyrics.VideoPlay.activity.VideoPlayActivity;
import java.io.File;
import java.util.ArrayList;

public class MyVideoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private ArrayList<MyVideoModel> mVideoDatas;
    private YourVideoActivity ActivityOfVideo;

    public MyVideoAdapter(Context mContext, ArrayList<MyVideoModel> mVideoDatas) {
        this.mContext = mContext;
        this.ActivityOfVideo = (YourVideoActivity) mContext;
        this.mVideoDatas = mVideoDatas;
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_mycreation_video, parent, false);
        return new MyViewHolder(v);
    }

    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final MyViewHolder myViewHolder = (MyViewHolder) holder;
        final StaggeredGridLayoutManager.LayoutParams layoutParams = new StaggeredGridLayoutManager.LayoutParams(myViewHolder.itemView.getLayoutParams());
        layoutParams.setFullSpan(false);
        myViewHolder.itemView.setLayoutParams(layoutParams);

        Glide.with(this.mContext).load(mVideoDatas.get(position).videoFullPath).into(myViewHolder.ivVideoThumb);
        myViewHolder.tvVideoName.setText(mVideoDatas.get(position).videoName);
        myViewHolder.tvVideoName.setSelected(true);
        myViewHolder.ivPlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                Intent intent = new Intent(mContext, VideoPlayActivity.class);
                intent.putExtra("VideoUrl", mVideoDatas.get(position).getVideoFullPath());
                intent.putExtra("VideoName", mVideoDatas.get(position).getVideoName());
                intent.putExtra("VideoPosition", position);
                intent.putExtra("IsVideoFromAndroidList", true);
                intent.putExtra("VideoDuration", Utils.INSTANCE.TimeCaculate(mVideoDatas.get(position).getVideoDuration()));
                ActivityOfVideo.startActivity(intent);
                ActivityOfVideo.finish();

            }
        });
        myViewHolder.ivDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                try {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AppDialog);
                    builder.setTitle(R.string.deletetitle);
                    builder.setMessage(String.valueOf(mContext.getResources().getString(R.string.deleteMessage)) + " " + mVideoDatas.get(position).videoName + ".mp4" + " ?");
                    builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        public void onClick(final DialogInterface dialog, final int which) {
                            try {
                                Utils.deleteFile(new File(mVideoDatas.get(position).videoFullPath));
                                itemRemoved(position);
                                notifyDataSetChanged();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    builder.setNegativeButton("Cancel", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(mContext.getResources().getColor(R.color.bg_main_color));
                    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(mContext.getResources().getColor(R.color.bg_main_color));
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(mContext.getResources().getColor(R.color.bg_main_color));
                } catch (Resources.NotFoundException e) {
                    e.printStackTrace();
                }
            }
        });
        myViewHolder.ivShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                final File file = new File(mVideoDatas.get(position).videoFullPath);
                final Intent shareIntent = new Intent("android.intent.action.SEND");
                shareIntent.setType("video/*");
                shareIntent.putExtra("android.intent.extra.SUBJECT", mContext.getString(R.string.app_name));
                shareIntent.putExtra("android.intent.extra.TEXT", String.valueOf(mContext.getString(R.string.get_free)) + mContext.getString(R.string.app_name) + " at here : " + "https://play.google.com/store/apps/details?id=" + mContext.getPackageName());
                shareIntent.putExtra("android.intent.extra.TITLE", mVideoDatas.get(position).videoName);
                final Uri ShareUri = FileProvider.getUriForFile(mContext, String.valueOf(mContext.getPackageName()) + ".provider", file);
                shareIntent.putExtra("android.intent.extra.STREAM", ShareUri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                mContext.startActivity(Intent.createChooser(shareIntent, "Share Video"));
            }
        });
    }


    public void itemRemoved(int pos) {
        if ((mVideoDatas != null) && (mVideoDatas.size() > 0)) {
            mVideoDatas.remove(pos);
        }
    }

    public int getItemCount() {
        return mVideoDatas.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView ivVideoThumb;
        ImageView ivPlay;
        TextView tvVideoName;
        ImageView ivShare;
        ImageView ivDelete;

        public MyViewHolder(View v) {
            super(v);
            ivVideoThumb = v.findViewById(R.id.iv_videoplayer_thumb);
            tvVideoName = v.findViewById(R.id.tv_videoName);
            ivShare = v.findViewById(R.id.ivShare);
            ivDelete = v.findViewById(R.id.ivDelete);
            ivPlay = v.findViewById(R.id.ivPlay_vc);
        }
    }

}
