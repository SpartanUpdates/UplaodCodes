package com.vidsoft.collagemaker.Utils.Stickers;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

public class TouchImageView extends ImageView {
	static final int CLICK = 3;
	static final int DRAG = 1;
	static final int NONE = 0;
	static final int ZOOM = 2;
	Context context;
	float d;
	PointF last;
	float[] lastEvent;
	float[] m;
	ScaleGestureDetector mScaleDetector;
	Matrix matrix;
	float maxScale;
	PointF mid;
	float minScale;
	int mode;
	float newRot;
	float oldDist;
	int oldMeasuredHeight;
	int oldMeasuredWidth;
	protected float origHeight;
	protected float origWidth;
	float saveScale;
	Matrix savedMatrix;
	PointF start;
	int viewHeight;
	int viewWidth;

	public TouchImageView(final Context context) {
		super(context);
		this.mode = 0;
		this.last = new PointF();
		this.start = new PointF();
		this.minScale = 1.0f;
		this.maxScale = 3.0f;
		this.mid = new PointF();
		this.saveScale = 1.0f;
		this.savedMatrix = new Matrix();
		this.lastEvent = null;
		this.d = 0.0f;
		this.newRot = 0.0f;
		this.oldDist = 1.0f;
		this.sharedConstructing(context);
	}

	public TouchImageView(final Context context, final AttributeSet set) {
		super(context, set);
		this.mode = 0;
		this.last = new PointF();
		this.start = new PointF();
		this.minScale = 1.0f;
		this.maxScale = 3.0f;
		this.mid = new PointF();
		this.saveScale = 1.0f;
		this.savedMatrix = new Matrix();
		this.lastEvent = null;
		this.d = 0.0f;
		this.newRot = 0.0f;
		this.oldDist = 1.0f;
		this.sharedConstructing(context);
	}

	private void dumpEvent(final WrapMotionEvent wrapMotionEvent) {
		final StringBuilder sb = new StringBuilder();
		final int action = wrapMotionEvent.getAction();
		final int n = action & 0xFF;
		sb.append("event ACTION_").append(
				(new String[] { "DOWN", "UP", "MOVE", "CANCEL", "OUTSIDE",
						"POINTER_DOWN", "POINTER_UP", "7?", "8?", "9?" })[n]);
		if (n == 5 || n == 6) {
			sb.append("(pid ").append(action >> 8);
			sb.append(")");
		}
		sb.append("[");
		for (int i = 0; i < wrapMotionEvent.getPointerCount(); ++i) {
			sb.append("#").append(i);
			sb.append("(pid ").append(wrapMotionEvent.getPointerId(i));
			sb.append(")=").append((int) wrapMotionEvent.getX(i));
			sb.append(",").append((int) wrapMotionEvent.getY(i));
			if (i + 1 < wrapMotionEvent.getPointerCount()) {
				sb.append(";");
			}
		}
		sb.append("]");
	}

	private void midPoint(final PointF pointF,
			final WrapMotionEvent wrapMotionEvent) {
		pointF.set((wrapMotionEvent.getX(0) + wrapMotionEvent.getX(1)) / 2.0f,
				(wrapMotionEvent.getY(0) + wrapMotionEvent.getY(1)) / 2.0f);
	}

	private float rotation(final MotionEvent motionEvent) {
		return (float) Math.toDegrees(Math.atan2(motionEvent.getY(0)
				- motionEvent.getY(1),
				motionEvent.getX(0) - motionEvent.getX(1)));
	}

	private void sharedConstructing(final Context context) {
		super.setClickable(true);
		this.context = context;
		this.mScaleDetector = new ScaleGestureDetector(
				(ScaleGestureDetector.OnScaleGestureListener) new ScaleListener());
		this.matrix = new Matrix();
		this.m = new float[9];
		this.setImageMatrix(this.matrix);
		this.setScaleType(ScaleType.MATRIX);
		this.setOnTouchListener((OnTouchListener) new OnTouchListener() {
			public boolean onTouch(final View view,
					final MotionEvent motionEvent) {
				final WrapMotionEvent wrap = WrapMotionEvent.wrap(motionEvent);
				final ImageView imageView = (ImageView) view;
				TouchImageView.this.dumpEvent(wrap);
				switch (wrap.getAction() & 0xFF) {
				case 0: {
					TouchImageView.this.savedMatrix
							.set(TouchImageView.this.matrix);
					TouchImageView.this.start.set(wrap.getX(), wrap.getY());
					TouchImageView.this.mode = 1;
					break;
				}
				case 5: {
					TouchImageView.this.oldDist = TouchImageView.this
							.spacing(wrap);
					if (TouchImageView.this.oldDist > 10.0f) {
						TouchImageView.this.savedMatrix
								.set(TouchImageView.this.matrix);
						TouchImageView.this.midPoint(TouchImageView.this.mid,
								wrap);
						TouchImageView.this.mode = 2;
					}
					(TouchImageView.this.lastEvent = new float[4])[0] = wrap
							.getX(0);
					TouchImageView.this.lastEvent[1] = wrap.getX(1);
					TouchImageView.this.lastEvent[2] = wrap.getY(0);
					TouchImageView.this.lastEvent[3] = wrap.getY(1);
					TouchImageView.this.d = TouchImageView.this
							.rotation(motionEvent);
					break;
				}
				case 6: {
					TouchImageView.this.mode = 0;
					TouchImageView.this.lastEvent = null;
					break;
				}
				case 2: {
					if (TouchImageView.this.mode == 1) {
						TouchImageView.this.matrix
								.set(TouchImageView.this.savedMatrix);
						TouchImageView.this.matrix.postTranslate(wrap.getX()
								- TouchImageView.this.start.x, wrap.getY()
								- TouchImageView.this.start.y);
						break;
					}
					if (TouchImageView.this.mode != 2) {
						break;
					}
					final float access$1 = TouchImageView.this.spacing(wrap);
					if (access$1 > 10.0f) {
						TouchImageView.this.matrix
								.set(TouchImageView.this.savedMatrix);
						final float n = access$1 / TouchImageView.this.oldDist;
						TouchImageView.this.matrix.postScale(n, n,
								TouchImageView.this.mid.x,
								TouchImageView.this.mid.y);
					}
					if (TouchImageView.this.lastEvent != null) {
						TouchImageView.this.newRot = TouchImageView.this
								.rotation(motionEvent);
						TouchImageView.this.matrix.postRotate(
								TouchImageView.this.newRot
										- TouchImageView.this.d,
								(float) (imageView.getMeasuredWidth() / 2),
								(float) (imageView.getMeasuredHeight() / 2));
						break;
					}
					break;
				}
				}
				TouchImageView.this.setImageMatrix(TouchImageView.this.matrix);
				TouchImageView.this.invalidate();
				return true;
			}
		});
	}

	private float spacing(final WrapMotionEvent wrapMotionEvent) {
		final float n = wrapMotionEvent.getX(0) - wrapMotionEvent.getX(1);
		final float n2 = wrapMotionEvent.getY(0) - wrapMotionEvent.getY(1);
		return (float) Math.sqrt(n * n + n2 * n2);
	}

	void fixTrans() {
		this.matrix.getValues(this.m);
		final float n = this.m[2];
		final float n2 = this.m[5];
		final float fixTrans = this.getFixTrans(n, this.viewWidth,
				this.origWidth * this.saveScale);
		final float fixTrans2 = this.getFixTrans(n2, this.viewHeight,
				this.origHeight * this.saveScale);
		if (fixTrans != 0.0f || fixTrans2 != 0.0f) {
			this.matrix.postTranslate(fixTrans, fixTrans2);
		}
	}

	float getFixDragTrans(float n, final float n2, final float n3) {
		if (n3 <= n2) {
			n = 0.0f;
		}
		return n;
	}

	float getFixTrans(final float n, float n2, float n3) {
		if (n3 <= n2) {
			final float n4 = 0.0f;
			n2 -= n3;
			n3 = n4;
		} else {
			n3 = n2 - n3;
			n2 = 0.0f;
		}
		if (n < n3) {
			return -n + n3;
		}
		if (n > n2) {
			return -n + n2;
		}
		return 0.0f;
	}

	protected void onMeasure(int intrinsicWidth, int intrinsicHeight) {
		super.onMeasure(intrinsicWidth, intrinsicHeight);
		this.viewWidth = MeasureSpec.getSize(intrinsicWidth);
		this.viewHeight = MeasureSpec.getSize(intrinsicHeight);
		if ((this.oldMeasuredHeight != this.viewWidth || this.oldMeasuredHeight != this.viewHeight)
				&& this.viewWidth != 0 && this.viewHeight != 0) {
			this.oldMeasuredHeight = this.viewHeight;
			this.oldMeasuredWidth = this.viewWidth;
			if (this.saveScale == 1.0f) {
				final Drawable drawable = this.getDrawable();
				if (drawable == null || drawable.getIntrinsicWidth() == 0
						|| drawable.getIntrinsicHeight() == 0) {
					return;
				}
				intrinsicWidth = drawable.getIntrinsicWidth();
				intrinsicHeight = drawable.getIntrinsicHeight();
				Log.d("bmSize", "bmWidth: " + intrinsicWidth + " bmHeight : "
						+ intrinsicHeight);
				final float min = Math.min(this.viewWidth / intrinsicWidth,
						this.viewHeight / intrinsicHeight);
				this.matrix.setScale(min, min);
				final float n = this.viewHeight;
				final float n2 = intrinsicHeight;
				final float n3 = this.viewWidth;
				final float n4 = intrinsicWidth;
				final float n5 = (n - n2 * min) / 2.0f;
				final float n6 = (n3 - n4 * min) / 2.0f;
				this.matrix.postTranslate(n6, n5);
				this.origWidth = this.viewWidth - 2.0f * n6;
				this.origHeight = this.viewHeight - 2.0f * n5;
				this.setImageMatrix(this.matrix);
			}
			this.fixTrans();
		}
	}

	public void setMaxZoom(final float maxScale) {
		this.maxScale = maxScale;
	}

	private class ScaleListener extends
			ScaleGestureDetector.SimpleOnScaleGestureListener {
		public boolean onScale(final ScaleGestureDetector scaleGestureDetector) {
			float scaleFactor = scaleGestureDetector.getScaleFactor();
			final float saveScale = TouchImageView.this.saveScale;
			final TouchImageView this$0 = TouchImageView.this;
			this$0.saveScale *= scaleFactor;
			if (TouchImageView.this.saveScale > TouchImageView.this.maxScale) {
				TouchImageView.this.saveScale = TouchImageView.this.maxScale;
				scaleFactor = TouchImageView.this.maxScale / saveScale;
			} else if (TouchImageView.this.saveScale < TouchImageView.this.minScale) {
				TouchImageView.this.saveScale = TouchImageView.this.minScale;
				scaleFactor = TouchImageView.this.minScale / saveScale;
			}
			if (TouchImageView.this.origWidth * TouchImageView.this.saveScale <= TouchImageView.this.viewWidth
					|| TouchImageView.this.origHeight
							* TouchImageView.this.saveScale <= TouchImageView.this.viewHeight) {
				TouchImageView.this.matrix.postScale(scaleFactor, scaleFactor,
						(float) (TouchImageView.this.viewWidth / 2),
						(float) (TouchImageView.this.viewHeight / 2));
			} else {
				TouchImageView.this.matrix.postScale(scaleFactor, scaleFactor,
						scaleGestureDetector.getFocusX(),
						scaleGestureDetector.getFocusY());
			}
			TouchImageView.this.fixTrans();
			return true;
		}

		public boolean onScaleBegin(
				final ScaleGestureDetector scaleGestureDetector) {
			TouchImageView.this.mode = 2;
			return true;
		}
	}
}
