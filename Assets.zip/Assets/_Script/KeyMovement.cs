﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyMovement : MonoBehaviour
{
    public GameObject keyMain, breakKey, particleEffect;

    void OnTriggerEnter(Collider target)
    {
        if (target.CompareTag("Player"))
        {
            particleEffect.SetActive(true);
            keyMain.SetActive(false);
            breakKey.SetActive(true);
            Destroy(this.transform.parent.gameObject,2);
        }
    }
}
