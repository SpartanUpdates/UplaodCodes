package com.example.womenabsworkout.activities;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.preference.PreferenceManager;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.NotificationCompat;

import com.akexorcist.roundcornerprogressbar.RoundCornerProgressBar;
import com.example.womenabsworkout.R;
import com.example.womenabsworkout.adapters.WorkoutData;
import com.example.womenabsworkout.database.DatabaseOperations;
import com.example.womenabsworkout.newscreen.Library;
import com.example.womenabsworkout.utils.AbsWomenApplication;
import com.example.womenabsworkout.utils.AppUtils;
import com.google.gson.Gson;
import com.travijuu.numberpicker.library.Enums.ActionEnum;
import com.travijuu.numberpicker.library.Interface.ValueChangedListener;
import com.travijuu.numberpicker.library.NumberPicker;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

import kr.pe.burt.android.lib.faimageview.FAImageView;

import com.example.womenabsworkout.utils.Constants;

public class MainExcerciseActivity extends AppCompatActivity {
    public int A;
    public boolean B = false;
    public boolean C;
    public boolean D;
    public boolean E;
    public boolean F;
    public String[] G;
    public String H;
    public Toolbar I;
    public Library K;
    public Boolean L;
    public Boolean M;
    public long REST_TIME_IN_MS;
    public FAImageView animImageFull;
    public Context context;
    public TextView count;
    public TextView countRestTimer;
    public DatabaseOperations databaseOperations;
    public String day;
    public int excCouner;
    public TextView excDescInReadyToGo;
    public long excDurGlobal;
    public TextView excName;
    public TextView excNameInReadyToGo;
    public CountDownTimer excersiseTimer;
    public int i;
    public int k;
    public int l;
    public LinearLayout layoutprogress;
    public AbsWomenApplication m;
    public int mainExcCounter;
    public float mainExcProgress;
    public int n;
    public FAImageView nextExerciseAnimation;
    public TextView nextExerciseCycles;
    public TextView nextExerciseName;
    public int o;
    public String packageName;
    public ImageView pauseMainExcersise;
    public ImageView pauseRestTime;
    public ImageView playPause;
    public double progress;
    public RoundCornerProgressBar progressbar;
    public CountDownTimer readyToGoTimer;
    public CoordinatorLayout readytogo_layout;
    public CoordinatorLayout restScreen;
    public CountDownTimer restTimer;
    public ProgressBar restTimerprogress;
    public ImageView resumRestTime;
    public ImageView resumeMainExcersise;
    public long s1;

    public TextView timerTop;
    public ProgressBar timerprogress;
    public ProgressBar topProgressBar;
    public TextView tvProgress;
    public TextView tvProgressMax;
    public String u;
    public int v;
    public String w;
    public ArrayList<WorkoutData> workoutDataList;
    public NumberPicker x;
    public SharedPreferences y;
    public String z;

    public void a(View view, int i) {
    }

    public MainExcerciseActivity() {
        Boolean valueOf = Boolean.valueOf(false);
        this.L = valueOf;
        this.M = valueOf;
        this.REST_TIME_IN_MS = 25000;
        this.i = 0;
        this.mainExcCounter = 1;
        this.mainExcProgress = 1.0f;
    }

    public static int b(MainExcerciseActivity mainExcerciseActivity) {
        int i = mainExcerciseActivity.excCouner;
        mainExcerciseActivity.excCouner = i + 1;
        return i;
    }

    private void excinfo() {
        Dialog dialog = new Dialog(this.context, R.style.AppTheme);
        int i = 0;
        try {
            ((Window) Objects.requireNonNull(dialog.getWindow())).getAttributes().windowAnimations = R.style.PauseDialogAnimation;
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        } catch (Exception e) {
            e.printStackTrace();
        }
        dialog.setContentView(R.layout.activity_excinfodialog);
        ((Window) Objects.requireNonNull(dialog.getWindow())).setLayout(-1, -1);
        dialog.setCancelable(true);
        dialog.getWindow().setFlags(1024, 1024);
        FAImageView fAImageView = (FAImageView) dialog.findViewById(R.id.animation_exDetail);
        TextView textView = (TextView) dialog.findViewById(R.id.description_exDetail);
        ((TextView) dialog.findViewById(R.id.dialogexcName)).setText(this.z);
        fAImageView.setInterval(1000);
        fAImageView.setLoop(true);
        fAImageView.reset();
        int[] imageIdList = ((WorkoutData) this.workoutDataList.get(this.excCouner)).getImageIdList();
        int length = imageIdList.length;
        while (i < length) {
            fAImageView.addImageFrame(imageIdList[i]);
            i++;
        }
        fAImageView.startAnimation();
        i = ((WorkoutData) this.workoutDataList.get(this.excCouner)).getExcDescResId();
        this.A = i;
        textView.setText(i);
        dialog.show();
    }

    private void exitConfirmDialog(boolean z) {
        Dialog dialog = new Dialog(this.context, R.style.Theme_Dialog);
        try {
            ((Window) Objects.requireNonNull(dialog.getWindow())).getAttributes().windowAnimations = R.style.PauseDialogAnimation;
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        } catch (Exception e) {
            e.printStackTrace();
        }
        dialog.setContentView(R.layout.exit_confirm_addialog_layout);
        ((Window) Objects.requireNonNull(dialog.getWindow())).setLayout(-1, -2);
        dialog.setCancelable(true);
        String[] strArr = new String[]{getResources().getString(R.string.quit1), getResources().getString(R.string.quit2), getResources().getString(R.string.quit3), getResources().getString(R.string.quit4), getResources().getString(R.string.quit5)};
        this.G = strArr;
        this.H = strArr[new Random().nextInt(this.G.length)];
        ((TextView) dialog.findViewById(R.id.quit_text)).setText(this.H);

        ((TextView) dialog.findViewById(R.id.btnYes)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                b(dialog, v);
            }
        });
        ((TextView) dialog.findViewById(R.id.btnNo)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        LinearLayout linearLayout = (LinearLayout) dialog.findViewById(R.id.layoutContainer_dialog);
        dialog.show();
    }

    private void getScreenHeightWidth() {
        this.context = this;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.k = displayMetrics.heightPixels;
        this.l = displayMetrics.widthPixels;
    }

    public void mainExcTimer(long j, int i, float f) {
        this.animImageFull.reset();
        for (int addImageFrame : ((WorkoutData) this.workoutDataList.get(this.excCouner)).getImageIdList()) {
            this.animImageFull.addImageFrame(addImageFrame);
        }
        this.restScreen.setVisibility(View.GONE);
        this.animImageFull.startAnimation();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("progressbar: ");
        stringBuilder.append(this.excDurGlobal / 1000);
        Log.i("setMax", stringBuilder.toString());
        this.progressbar.setMax((float) ((this.excDurGlobal / 1000) - 1));
        ProgressBar progressBar = (ProgressBar) this.layoutprogress.findViewById(this.excCouner);
        this.topProgressBar = progressBar;
        progressBar.setProgressDrawable(getResources().getDrawable(R.drawable.launch_progressbar));
        this.topProgressBar.setMax((((int) this.excDurGlobal) / 1000) - 1);
        this.m.addEarCorn(this.v);
        stringBuilder = new StringBuilder();
        stringBuilder.append("setMax: ");
        stringBuilder.append(j / 1000);
        Log.i("mainExcTimer", stringBuilder.toString());
        final float f2 = f;
        final int i2 = i;
        this.excersiseTimer = new CountDownTimer(j, 1000) {
            public int b = i2;
            public int c;
            public float f863a = f2;

            public void onFinish() {
                int i = 0;
                MainExcerciseActivity.this.C = false;
                RoundCornerProgressBar roundCornerProgressBar = MainExcerciseActivity.this.progressbar;
                float f = this.f863a;
                this.f863a = f + 1.0f;
                roundCornerProgressBar.setProgress(f);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("count: ");
                stringBuilder.append(this.b);
                stringBuilder.append("f ");
                stringBuilder.append(this.f863a);
                Log.i("onTick onFinish", stringBuilder.toString());
                MainExcerciseActivity.this.topProgressBar.setProgress((((int) MainExcerciseActivity.this.excDurGlobal) / 1000) - 1);
                MainExcerciseActivity.b(MainExcerciseActivity.this);
                MainExcerciseActivity.this.animImageFull.stopAnimation();
                String str = "MainExcerciseActivity";
                String str2 = "beginner";
                double size;
                double d;
                Intent intent;
                if (MainExcerciseActivity.this.excCouner < MainExcerciseActivity.this.workoutDataList.size()) {
                    MainExcerciseActivity.this.restScreen.setVisibility(View.VISIBLE);
                    MainExcerciseActivity.this.progressbar.setMax((float) ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles());
                    TextView textView = MainExcerciseActivity.this.tvProgress;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    int i2 = this.b;
                    this.b = i2 + 1;
                    stringBuilder2.append(i2);
                    String str3 = "";
                    stringBuilder2.append(str3);
                    textView.setText(stringBuilder2.toString());
                    textView = MainExcerciseActivity.this.tvProgressMax;
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles());
                    stringBuilder2.append(str3);
                    textView.setText(stringBuilder2.toString());
                    this.f863a = 1.0f;
                    this.b = 1;
                    size = (double) ((float) MainExcerciseActivity.this.workoutDataList.size());
                    Double.isNaN(size);
                    MainExcerciseActivity.this.progress = 100.0d / size;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("progress: ");
                    stringBuilder.append(MainExcerciseActivity.this.progress);
                    Log.i(str, stringBuilder.toString());
                    if (MainExcerciseActivity.this.u.equalsIgnoreCase(str2)) {
                        size = (double) MainExcerciseActivity.this.databaseOperations.getExcDayProgress(MainExcerciseActivity.this.day);
                        d = MainExcerciseActivity.this.progress;
                        Double.isNaN(size);
                        MainExcerciseActivity.this.progress = size + d;
                        if (MainExcerciseActivity.this.progress <= 100.0d) {
                            MainExcerciseActivity.this.databaseOperations.insertExcDayData(MainExcerciseActivity.this.day, (float) MainExcerciseActivity.this.progress);
                        }
                        if (MainExcerciseActivity.this.excCouner <= MainExcerciseActivity.this.workoutDataList.size()) {
                            MainExcerciseActivity.this.databaseOperations.insertExcCounter(MainExcerciseActivity.this.day, MainExcerciseActivity.this.excCouner);
                        }
                    } else {
                        size = (double) MainExcerciseActivity.this.databaseOperations.getExcDayProgressAdv(MainExcerciseActivity.this.day);
                        d = MainExcerciseActivity.this.progress;
                        Double.isNaN(size);
                        MainExcerciseActivity.this.progress = size + d;
                        if (MainExcerciseActivity.this.progress <= 100.0d) {
                            MainExcerciseActivity.this.databaseOperations.insertExcDayDataAdv(MainExcerciseActivity.this.day, (float) MainExcerciseActivity.this.progress);
                        }
                        if (MainExcerciseActivity.this.excCouner <= MainExcerciseActivity.this.workoutDataList.size()) {
                            MainExcerciseActivity.this.databaseOperations.insertExcCounterAdv(MainExcerciseActivity.this.day, MainExcerciseActivity.this.excCouner);
                        }
                    }
                    try {
                        intent = new Intent(AppUtils.WORKOUT_BROADCAST_FILTER);
                        intent.putExtra(AppUtils.KEY_PROGRESS, MainExcerciseActivity.this.progress);
                        MainExcerciseActivity.this.sendBroadcast(intent);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e("Failed update progress", e.getMessage());
                    }
                    MainExcerciseActivity.this.pauseRestTime.setVisibility(View.VISIBLE);
                    MainExcerciseActivity.this.resumRestTime.setVisibility(View.GONE);
                    if (!MainExcerciseActivity.this.D) {
                        MainExcerciseActivity mainExcerciseActivity = MainExcerciseActivity.this;
                        mainExcerciseActivity.a(mainExcerciseActivity.REST_TIME_IN_MS);
                    }
                } else {
                    size = (double) ((float) MainExcerciseActivity.this.workoutDataList.size());
                    Double.isNaN(size);
                    MainExcerciseActivity.this.progress = 100.0d / size;
                    double d2;
                    if (MainExcerciseActivity.this.u.equalsIgnoreCase(str2)) {
                        d = (double) MainExcerciseActivity.this.databaseOperations.getExcDayProgress(MainExcerciseActivity.this.day);
                        d2 = MainExcerciseActivity.this.progress;
                        Double.isNaN(d);
                        MainExcerciseActivity.this.progress = d + d2;
                        if (((int) MainExcerciseActivity.this.progress) <= 100 && MainExcerciseActivity.this.progress >= 98.0d) {
                            MainExcerciseActivity.this.databaseOperations.insertExcDayData(MainExcerciseActivity.this.day, 100.0f);
                        } else if (((int) MainExcerciseActivity.this.progress) <= 100) {
                            MainExcerciseActivity.this.databaseOperations.insertExcDayData(MainExcerciseActivity.this.day, (float) MainExcerciseActivity.this.progress);
                        }
                        if (MainExcerciseActivity.this.excCouner <= MainExcerciseActivity.this.workoutDataList.size()) {
                            MainExcerciseActivity.this.databaseOperations.insertExcCounter(MainExcerciseActivity.this.day, MainExcerciseActivity.this.excCouner);
                        }
                    } else {
                        d2 = (double) MainExcerciseActivity.this.databaseOperations.getExcDayProgressAdv(MainExcerciseActivity.this.day);
                        d = MainExcerciseActivity.this.progress;
                        Double.isNaN(d2);
                        MainExcerciseActivity.this.progress = d2 + d;
                        if (((int) MainExcerciseActivity.this.progress) <= 100 && MainExcerciseActivity.this.progress >= 98.0d) {
                            MainExcerciseActivity.this.databaseOperations.insertExcDayDataAdv(MainExcerciseActivity.this.day, 100.0f);
                        } else if (((int) MainExcerciseActivity.this.progress) <= 100) {
                            MainExcerciseActivity.this.databaseOperations.insertExcDayDataAdv(MainExcerciseActivity.this.day, (float) MainExcerciseActivity.this.progress);
                        }
                        if (MainExcerciseActivity.this.excCouner <= MainExcerciseActivity.this.workoutDataList.size()) {
                            MainExcerciseActivity.this.databaseOperations.insertExcCounterAdv(MainExcerciseActivity.this.day, MainExcerciseActivity.this.excCouner);
                        }
                    }
                    try {
                        intent = new Intent(AppUtils.WORKOUT_BROADCAST_FILTER);
                        if (MainExcerciseActivity.this.progress >= 98.0d) {
                            intent.putExtra(AppUtils.KEY_PROGRESS, 100.0d);
                        } else {
                            intent.putExtra(AppUtils.KEY_PROGRESS, MainExcerciseActivity.this.progress);
                        }
                        MainExcerciseActivity.this.sendBroadcast(intent);
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                    MainExcerciseActivity.this.restScreen.setVisibility(View.GONE);
                    intent = new Intent(MainExcerciseActivity.this.getApplicationContext(), CompletionExcActivity.class);
                    intent.putExtra("day", MainExcerciseActivity.this.day);
                    int i3 = 0;
                    int i4 = i3;
                    while (i < MainExcerciseActivity.this.workoutDataList.size()) {
                        i3 += ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(i)).getExcCycles();
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("totalExc MainExceActivity ");
                        stringBuilder3.append(i3);
                        Log.d("TAG", stringBuilder3.toString());
                        i4 = (i4 + ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(i)).getImageIdList().length) + Constants.REST_TIME;
                        i++;
                    }
                    intent.putExtra("totalExc", i3);
                    intent.putExtra("totalTime", i4);
                    MainExcerciseActivity.this.startActivity(intent);

                }
                stringBuilder = new StringBuilder();
                stringBuilder.append("excCouner: ");
                stringBuilder.append(MainExcerciseActivity.this.excCouner);
                Log.i(str, stringBuilder.toString());
                MainExcerciseActivity.this.mainExcProgress = 1.0f;
                MainExcerciseActivity.this.mainExcCounter = 1;
            }

            public void onTick(long j) {
                StringBuilder stringBuilder;
                int i;
                TextView textView;
                Exception e;
                TextView textView2;
                CharSequence charSequence;
                RoundCornerProgressBar roundCornerProgressBar;
                float f;
                String str;
                TextView textView3;
                long j2 = j;
                String str2 = "plank";
                String str3 = " ";
                String str4 = "_";
                String str5 = "mycount";
                String str6 = "           ";
                String str7 = "      ";
                String str8 = "onTick: ";
                String str9 = "";
                StringBuilder stringBuilder2 = new StringBuilder();
                String str10 = "millisUntilFinished: ";
                stringBuilder2.append(str10);
                stringBuilder2.append(j2);
                Log.i("millisUntilFinished", stringBuilder2.toString());
                MainExcerciseActivity.this.C = true;
                MainExcerciseActivity.this.E = false;
                try {
                    TextView textView4;
                    CharSequence stringBuilder3;
                    StringBuilder stringBuilder4;
                    if (((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getImageIdList().length <= 2) {
                        TextView textView5;
                        try {
                            if (this.b <= ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles()) {
                                textView4 = MainExcerciseActivity.this.tvProgress;
                                stringBuilder = new StringBuilder();
                                i = this.b;
                                this.b = i + 1;
                                stringBuilder.append(i);
                                stringBuilder.append(str9);
                                stringBuilder3 = stringBuilder.toString();
                            } else {
                                textView4 = null;
                                stringBuilder3 = null;
                            }
                            RoundCornerProgressBar roundCornerProgressBar2 = MainExcerciseActivity.this.progressbar;
                            float f2 = this.f863a;
                            textView5 = textView4;
                            this.f863a = f2 + 1.0f;
                            roundCornerProgressBar2.setProgress(f2);
                            MainExcerciseActivity.this.topProgressBar.setProgress((int) this.f863a);
                            textView4 = MainExcerciseActivity.this.timerTop;
                            stringBuilder4 = new StringBuilder();
                            stringBuilder4.append(this.b);
                            stringBuilder4.append(str9);
                            textView4.setText(stringBuilder4.toString());
                            MainExcerciseActivity.this.z = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcName().replace(str4, str3);
                            MainExcerciseActivity.this.z = MainExcerciseActivity.this.z.toUpperCase();
                            MainExcerciseActivity.this.excName.setText(MainExcerciseActivity.this.z);
                            MainExcerciseActivity.this.z.equalsIgnoreCase(str2);
                            textView = null;
                        } catch (Exception e2) {
                            e = e2;
                            textView = null;
                            textView2 = textView;
                            i = 0;
                            e.printStackTrace();
                            // charSequence = textView2;
                            roundCornerProgressBar = MainExcerciseActivity.this.progressbar;
                            f = this.f863a;
                            str = str5;
                            this.f863a = f + 1.0f;
                            roundCornerProgressBar.setProgress(f);
                            MainExcerciseActivity.this.topProgressBar.setProgress((int) this.f863a);
                            textView3 = MainExcerciseActivity.this.timerTop;
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(this.b);
                            stringBuilder.append(str9);
                            textView3.setText(stringBuilder.toString());
                            MainExcerciseActivity.this.z = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcName().replace(str4, str3);
                            MainExcerciseActivity.this.z = MainExcerciseActivity.this.z.toUpperCase();
                            MainExcerciseActivity.this.excName.setText(MainExcerciseActivity.this.z);
                            MainExcerciseActivity.this.z.equalsIgnoreCase(str2);
                            // textView.setText(charSequence);
                            MainExcerciseActivity.this.s1 = j2;
                            MainExcerciseActivity.this.mainExcCounter = this.b;
                            MainExcerciseActivity.this.mainExcProgress = this.f863a;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str8);
                            stringBuilder2.append(this.b);
                            stringBuilder2.append(str7);
                            stringBuilder2.append(this.c);
                            stringBuilder2.append(str6);
                            stringBuilder2.append(i);
                            Log.d(str, stringBuilder2.toString());
                        }
                        try {
                            //    textView.setText(textView);
                            MainExcerciseActivity.this.s1 = j2;
                            MainExcerciseActivity.this.mainExcCounter = this.b;
                            MainExcerciseActivity.this.mainExcProgress = this.f863a;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str8);
                            stringBuilder2.append(this.b);
                            stringBuilder2.append(str7);
                            stringBuilder2.append(this.c);
                            stringBuilder2.append(str6);
                            stringBuilder2.append(0);
                            Log.d(str5, stringBuilder2.toString());
                            // textView4 = textView5;
                        } catch (Exception e3) {
                            e = e3;
                            textView2 = textView;
                            i = 0;
                            e.printStackTrace();
                            //  charSequence = textView2;
                            roundCornerProgressBar = MainExcerciseActivity.this.progressbar;
                            f = this.f863a;
                            str = str5;
                            this.f863a = f + 1.0f;
                            roundCornerProgressBar.setProgress(f);
                            MainExcerciseActivity.this.topProgressBar.setProgress((int) this.f863a);
                            textView3 = MainExcerciseActivity.this.timerTop;
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(this.b);
                            stringBuilder.append(str9);
                            textView3.setText(stringBuilder.toString());
                            MainExcerciseActivity.this.z = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcName().replace(str4, str3);
                            MainExcerciseActivity.this.z = MainExcerciseActivity.this.z.toUpperCase();
                            MainExcerciseActivity.this.excName.setText(MainExcerciseActivity.this.z);
                            MainExcerciseActivity.this.z.equalsIgnoreCase(str2);
                            //textView.setText(charSequence);
                            MainExcerciseActivity.this.s1 = j2;
                            MainExcerciseActivity.this.mainExcCounter = this.b;
                            MainExcerciseActivity.this.mainExcProgress = this.f863a;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str8);
                            stringBuilder2.append(this.b);
                            stringBuilder2.append(str7);
                            stringBuilder2.append(this.c);
                            stringBuilder2.append(str6);
                            stringBuilder2.append(i);
                            Log.d(str, stringBuilder2.toString());
                        }
                    }
                    textView = null;
                    if (this.f863a == 1.0f) {
                        textView4 = MainExcerciseActivity.this.tvProgress;
                        stringBuilder3 = "1";
                    } else {
                        String stringBuilder5;
                        if (this.f863a % ((float) ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getImageIdList().length) == 0.0f) {
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str10);
                            stringBuilder2.append(this.f863a % ((float) ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getImageIdList().length));
                            Log.i("mainExce", stringBuilder2.toString());
                            textView4 = MainExcerciseActivity.this.tvProgress;
                            this.b++;
                        }
                        roundCornerProgressBar = MainExcerciseActivity.this.progressbar;
                        float f3 = this.f863a;
                        this.f863a = f3 + 1.0f;
                        roundCornerProgressBar.setProgress(f3);
                        MainExcerciseActivity.this.topProgressBar.setProgress((int) this.f863a);
                        TextView textView6 = MainExcerciseActivity.this.timerTop;
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append(this.b);
                        stringBuilder4.append(str9);
                        textView6.setText(stringBuilder4.toString());
                        MainExcerciseActivity.this.z = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcName().replace(str4, str3);
                        MainExcerciseActivity.this.z = MainExcerciseActivity.this.z.toUpperCase();
                        MainExcerciseActivity.this.excName.setText(MainExcerciseActivity.this.z);
                        str10 = "/";
                        if (MainExcerciseActivity.this.z.equalsIgnoreCase(str2)) {
                            textView = MainExcerciseActivity.this.tvProgressMax;
                            try {
                                StringBuilder stringBuilder6 = new StringBuilder();
                                stringBuilder6.append(str10);
                                stringBuilder6.append(((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles());
                                stringBuilder6.append("s");
                                stringBuilder5 = stringBuilder6.toString();
                            } catch (Exception e4) {
                                e = e4;
                            }
                        } else {
                            textView = MainExcerciseActivity.this.tvProgressMax;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str10);
                            stringBuilder2.append(((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles());
                            stringBuilder5 = stringBuilder2.toString();
                        }
                        // textView6 = stringBuilder5;
                        try {
                            // textView.setText(textView6);
                            MainExcerciseActivity.this.s1 = j2;
                            MainExcerciseActivity.this.mainExcCounter = this.b;
                            MainExcerciseActivity.this.mainExcProgress = this.f863a;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str8);
                            stringBuilder2.append(this.b);
                            stringBuilder2.append(str7);
                            stringBuilder2.append(this.c);
                            stringBuilder2.append(str6);
                            stringBuilder2.append(0);
                            Log.d(str5, stringBuilder2.toString());
                            int i2 = this.c;
                            i = this.b;
                            if (i2 == i) {
                                MainExcerciseActivity.this.m.playEarCorn(MainExcerciseActivity.this.v);
                                return;
                            }
                            this.c = i;
                            if (i == 1) {
                                return;
                            }
                            if (i > ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles() || MainExcerciseActivity.this.v != 1) {
                                textView2 = textView6;
                                try {
                                    if (MainExcerciseActivity.this.v == 1) {
                                        AbsWomenApplication absWomenApplication = MainExcerciseActivity.this.m;
                                        stringBuilder = new StringBuilder();
                                        stringBuilder.append(str9);
                                        i = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles();
                                        try {
                                            stringBuilder.append(i);
                                            absWomenApplication.speak(stringBuilder.toString());
                                            return;
                                        } catch (Exception e5) {
                                            e = e5;
                                            e.printStackTrace();
                                            //charSequence = textView2;
                                            roundCornerProgressBar = MainExcerciseActivity.this.progressbar;
                                            f = this.f863a;
                                            str = str5;
                                            this.f863a = f + 1.0f;
                                            roundCornerProgressBar.setProgress(f);
                                            MainExcerciseActivity.this.topProgressBar.setProgress((int) this.f863a);
                                            textView3 = MainExcerciseActivity.this.timerTop;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append(this.b);
                                            stringBuilder.append(str9);
                                            textView3.setText(stringBuilder.toString());
                                            MainExcerciseActivity.this.z = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcName().replace(str4, str3);
                                            MainExcerciseActivity.this.z = MainExcerciseActivity.this.z.toUpperCase();
                                            MainExcerciseActivity.this.excName.setText(MainExcerciseActivity.this.z);
                                            MainExcerciseActivity.this.z.equalsIgnoreCase(str2);
                                            // textView.setText(charSequence);
                                            MainExcerciseActivity.this.s1 = j2;
                                            MainExcerciseActivity.this.mainExcCounter = this.b;
                                            MainExcerciseActivity.this.mainExcProgress = this.f863a;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(str8);
                                            stringBuilder2.append(this.b);
                                            stringBuilder2.append(str7);
                                            stringBuilder2.append(this.c);
                                            stringBuilder2.append(str6);
                                            stringBuilder2.append(i);
                                            Log.d(str, stringBuilder2.toString());
                                        }
                                    }
                                    MainExcerciseActivity.this.m.speak(str9);
                                    return;
                                } catch (Exception e6) {
                                    e = e6;
                                    i = 0;
                                    e.printStackTrace();
                                    /// charSequence = textView2;
                                    roundCornerProgressBar = MainExcerciseActivity.this.progressbar;
                                    f = this.f863a;
                                    str = str5;
                                    this.f863a = f + 1.0f;
                                    roundCornerProgressBar.setProgress(f);
                                    MainExcerciseActivity.this.topProgressBar.setProgress((int) this.f863a);
                                    textView3 = MainExcerciseActivity.this.timerTop;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append(this.b);
                                    stringBuilder.append(str9);
                                    textView3.setText(stringBuilder.toString());
                                    MainExcerciseActivity.this.z = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcName().replace(str4, str3);
                                    MainExcerciseActivity.this.z = MainExcerciseActivity.this.z.toUpperCase();
                                    MainExcerciseActivity.this.excName.setText(MainExcerciseActivity.this.z);
                                    MainExcerciseActivity.this.z.equalsIgnoreCase(str2);
                                    //textView.setText(charSequence);
                                    MainExcerciseActivity.this.s1 = j2;
                                    MainExcerciseActivity.this.mainExcCounter = this.b;
                                    MainExcerciseActivity.this.mainExcProgress = this.f863a;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append(str8);
                                    stringBuilder2.append(this.b);
                                    stringBuilder2.append(str7);
                                    stringBuilder2.append(this.c);
                                    stringBuilder2.append(str6);
                                    stringBuilder2.append(i);
                                    Log.d(str, stringBuilder2.toString());
                                }
                            }
                            AbsWomenApplication absWomenApplication2 = MainExcerciseActivity.this.m;
                            StringBuilder stringBuilder7 = new StringBuilder();
                            stringBuilder7.append(str9);
                            textView2 = textView6;
                            int i3 = this.c - 1;
                            try {
                                stringBuilder7.append(i3);
                                absWomenApplication2.speak(stringBuilder7.toString());
                                return;
                            } catch (Exception e7) {
                                e = e7;
                                i = i3;
                                e.printStackTrace();
                                //charSequence = textView2;
                                roundCornerProgressBar = MainExcerciseActivity.this.progressbar;
                                f = this.f863a;
                                str = str5;
                                this.f863a = f + 1.0f;
                                roundCornerProgressBar.setProgress(f);
                                MainExcerciseActivity.this.topProgressBar.setProgress((int) this.f863a);
                                textView3 = MainExcerciseActivity.this.timerTop;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(this.b);
                                stringBuilder.append(str9);
                                textView3.setText(stringBuilder.toString());
                                MainExcerciseActivity.this.z = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcName().replace(str4, str3);
                                MainExcerciseActivity.this.z = MainExcerciseActivity.this.z.toUpperCase();
                                MainExcerciseActivity.this.excName.setText(MainExcerciseActivity.this.z);
                                MainExcerciseActivity.this.z.equalsIgnoreCase(str2);
                                //     textView.setText(charSequence);
                                MainExcerciseActivity.this.s1 = j2;
                                MainExcerciseActivity.this.mainExcCounter = this.b;
                                MainExcerciseActivity.this.mainExcProgress = this.f863a;
                                stringBuilder2 = new StringBuilder();
                                stringBuilder2.append(str8);
                                stringBuilder2.append(this.b);
                                stringBuilder2.append(str7);
                                stringBuilder2.append(this.c);
                                stringBuilder2.append(str6);
                                stringBuilder2.append(i);
                                Log.d(str, stringBuilder2.toString());
                            }
                        } catch (Exception e8) {
                            e = e8;
                            textView2 = textView6;
                            i = 0;
                            e.printStackTrace();
                            //  charSequence = textView2;
                            roundCornerProgressBar = MainExcerciseActivity.this.progressbar;
                            f = this.f863a;
                            str = str5;
                            this.f863a = f + 1.0f;
                            roundCornerProgressBar.setProgress(f);
                            MainExcerciseActivity.this.topProgressBar.setProgress((int) this.f863a);
                            textView3 = MainExcerciseActivity.this.timerTop;
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(this.b);
                            stringBuilder.append(str9);
                            textView3.setText(stringBuilder.toString());
                            MainExcerciseActivity.this.z = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcName().replace(str4, str3);
                            MainExcerciseActivity.this.z = MainExcerciseActivity.this.z.toUpperCase();
                            MainExcerciseActivity.this.excName.setText(MainExcerciseActivity.this.z);
                            MainExcerciseActivity.this.z.equalsIgnoreCase(str2);
                            //  textView.setText(charSequence);
                            MainExcerciseActivity.this.s1 = j2;
                            MainExcerciseActivity.this.mainExcCounter = this.b;
                            MainExcerciseActivity.this.mainExcProgress = this.f863a;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str8);
                            stringBuilder2.append(this.b);
                            stringBuilder2.append(str7);
                            stringBuilder2.append(this.c);
                            stringBuilder2.append(str6);
                            stringBuilder2.append(i);
                            Log.d(str, stringBuilder2.toString());
                        }
                    }
                    // textView4.setText(stringBuilder3);
                    //charSequence = textView;
                    i = 0;
                } catch (Exception e9) {
                    e = e9;
                    textView = null;
                }
                roundCornerProgressBar = MainExcerciseActivity.this.progressbar;
                f = this.f863a;
                str = str5;
                this.f863a = f + 1.0f;
                roundCornerProgressBar.setProgress(f);
                MainExcerciseActivity.this.topProgressBar.setProgress((int) this.f863a);
                textView3 = MainExcerciseActivity.this.timerTop;
                stringBuilder = new StringBuilder();
                stringBuilder.append(this.b);
                stringBuilder.append(str9);
                textView3.setText(stringBuilder.toString());
                try {
                    MainExcerciseActivity.this.z = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcName().replace(str4, str3);
                    MainExcerciseActivity.this.z = MainExcerciseActivity.this.z.toUpperCase();
                    MainExcerciseActivity.this.excName.setText(MainExcerciseActivity.this.z);
                    MainExcerciseActivity.this.z.equalsIgnoreCase(str2);
                    // textView.setText(charSequence);
                } catch (Exception e10) {
                    e10.printStackTrace();
                }
                MainExcerciseActivity.this.s1 = j2;
                MainExcerciseActivity.this.mainExcCounter = this.b;
                MainExcerciseActivity.this.mainExcProgress = this.f863a;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str8);
                stringBuilder2.append(this.b);
                stringBuilder2.append(str7);
                stringBuilder2.append(this.c);
                stringBuilder2.append(str6);
                // stringBuilder2.append(i);
                Log.d(str, stringBuilder2.toString());
                i = 0;
                textView2 = null;
                //e10.printStackTrace();
                //  charSequence = textView2;
                roundCornerProgressBar = MainExcerciseActivity.this.progressbar;
                f = this.f863a;
                str = str5;
                this.f863a = f + 1.0f;
                roundCornerProgressBar.setProgress(f);
                MainExcerciseActivity.this.topProgressBar.setProgress((int) this.f863a);
                textView3 = MainExcerciseActivity.this.timerTop;
                stringBuilder = new StringBuilder();
                stringBuilder.append(this.b);
                stringBuilder.append(str9);
                textView3.setText(stringBuilder.toString());
                MainExcerciseActivity.this.z = ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcName().replace(str4, str3);
                MainExcerciseActivity.this.z = MainExcerciseActivity.this.z.toUpperCase();
                MainExcerciseActivity.this.excName.setText(MainExcerciseActivity.this.z);
                MainExcerciseActivity.this.z.equalsIgnoreCase(str2);
                //     textView.setText(charSequence);
                MainExcerciseActivity.this.s1 = j2;
                MainExcerciseActivity.this.mainExcCounter = this.b;
                MainExcerciseActivity.this.mainExcProgress = this.f863a;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str8);
                stringBuilder2.append(this.b);
                stringBuilder2.append(str7);
                stringBuilder2.append(this.c);
                stringBuilder2.append(str6);
                stringBuilder2.append(i);
                Log.d(str, stringBuilder2.toString());
            }
        }.start();
    }


    public void a(int i, ActionEnum actionEnum) {
        this.o = i;
    }

    public void a(long j) {
        String toUpperCase = ((WorkoutData) this.workoutDataList.get(this.excCouner)).getExcName().replace("_", " ").toUpperCase();
        this.nextExerciseName.setText(toUpperCase);
        TextView textView = this.nextExerciseCycles;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("x");
        stringBuilder.append(((WorkoutData) this.workoutDataList.get(this.excCouner)).getExcCycles());
        textView.setText(stringBuilder.toString());
        this.nextExerciseAnimation.reset();
        for (int addImageFrame : ((WorkoutData) this.workoutDataList.get(this.excCouner)).getImageIdList()) {
            this.nextExerciseAnimation.addImageFrame(addImageFrame);
        }
        this.nextExerciseAnimation.startAnimation();
        this.restTimerprogress.setMax((int) (this.REST_TIME_IN_MS / 1000));
        if (j == this.REST_TIME_IN_MS && this.v == 1) {
            this.m.speak("Take rest");
            AbsWomenApplication absWomenApplication = this.m;
            stringBuilder = new StringBuilder();
            stringBuilder.append("the next exercise is ");
            stringBuilder.append(toUpperCase);
            absWomenApplication.speak(stringBuilder.toString());
        }
        this.restTimer = new CountDownTimer(j, 1000) {
            public void onFinish() {
                MainExcerciseActivity.this.D = false;
                MainExcerciseActivity.this.restScreen.setVisibility(View.GONE);
                MainExcerciseActivity.this.L = Boolean.valueOf(false);
                try {
                    long length = (long) (((((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getImageIdList().length > 2 ? ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getImageIdList().length * ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles() : ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles()) + 1) * 1000);
                    MainExcerciseActivity.this.excDurGlobal = length;
                    MainExcerciseActivity.this.pauseMainExcersise.setVisibility(View.VISIBLE);
                    MainExcerciseActivity.this.resumeMainExcersise.setVisibility(View.GONE);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("exc duration");
                    stringBuilder.append(length);
                    stringBuilder.append("mainExcCounter");
                    stringBuilder.append(MainExcerciseActivity.this.mainExcCounter);
                    stringBuilder.append("mainExcProgress ");
                    stringBuilder.append(MainExcerciseActivity.this.mainExcProgress);
                    Log.i("restscreen", stringBuilder.toString());
                    if (!MainExcerciseActivity.this.C) {
                        MainExcerciseActivity.this.mainExcTimer(length, MainExcerciseActivity.this.mainExcCounter, MainExcerciseActivity.this.mainExcProgress);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            public void onTick(long j) {
                MainExcerciseActivity.this.F = false;
                MainExcerciseActivity.this.D = true;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(NotificationCompat.CATEGORY_MESSAGE);
                stringBuilder.append(j);
                Log.i("debashish", stringBuilder.toString());
                long j2 = (j - 1000) / 1000;
                MainExcerciseActivity.this.restTimerprogress.setProgress((int) j2);
                TextView textView = MainExcerciseActivity.this.countRestTimer;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(j2);
                stringBuilder2.append("");
                textView.setText(stringBuilder2.toString());
                MainExcerciseActivity.this.s1 = j;
                if (j2 >= 4 || MainExcerciseActivity.this.v != 1) {
                    if (!MainExcerciseActivity.this.m.isSpeaking().booleanValue()) {
                        MainExcerciseActivity.this.m.playEarCorn(MainExcerciseActivity.this.v);
                    }
                    return;
                }
                if (j2 == 3) {
                    MainExcerciseActivity.this.m.speak("three ");
                }
                if (j2 == 2) {
                    MainExcerciseActivity.this.m.speak("two ");
                }
                if (j2 == 1) {
                    MainExcerciseActivity.this.m.speak("one ");
                }
                if (j2 == 0 && !MainExcerciseActivity.this.L.booleanValue()) {
                    //MainExcerciseActivity.this.m.speak(TtmlNode.START);
                    MainExcerciseActivity.this.L = Boolean.valueOf(true);
                }
            }
        }.start();
    }

    public void a(Dialog dialog, View view) {
        this.REST_TIME_IN_MS = (long) ((this.o * 1000) + 2000);
        Editor edit = this.y.edit();
        edit.putInt("resttime", this.o);
        edit.apply();
        dialog.dismiss();
    }

    public void a(View view) {
        finish();
    }

    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    public void b() {
        Dialog dialog = new Dialog(this.context, R.style.AppTheme);
        ((Window) Objects.requireNonNull(dialog.getWindow())).getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        dialog.getWindow().setLayout(-1, -2);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setFlags(1024, 1024);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setContentView(R.layout.activity_customdialog_cycles);
        dialog.setCancelable(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.setCancelable(true);
        this.x = (NumberPicker) dialog.findViewById(R.id.countdownNumberPicker);
        int i = this.y.getInt("resttime", 25);
        this.o = i;
        this.x.setValue(i);
        this.x.setValueChangedListener(new ValueChangedListener() {
            @Override
            public void valueChanged(int value, ActionEnum action) {
                a(value, action);
            }
        });
        ((Button) dialog.findViewById(R.id.calculate)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a(dialog, v);
            }
        });
        dialog.show();
    }

    public void b(Dialog dialog, View view) {
        cancelTimers();
        dialog.dismiss();
        try {
            dialog.dismiss();
            Intent intent = new Intent(this, After_Main_Activity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            onSuperBackPressed();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public long calculateExTime(int i) {
        return ((WorkoutData) this.workoutDataList.get(i)).getImageIdList().length > 2 ? (long) (((((WorkoutData) this.workoutDataList.get(i)).getImageIdList().length * ((WorkoutData) this.workoutDataList.get(i)).getExcCycles()) + 1) * 1000) : (long) ((((WorkoutData) this.workoutDataList.get(i)).getExcCycles() + 1) * 1000);
    }

    public void cancelTimers() {
        try {
            if (this.readyToGoTimer != null) {
                this.readyToGoTimer.cancel();
            }
            if (this.excersiseTimer != null) {
                this.excersiseTimer.cancel();
                this.C = false;
            }
            if (this.restTimer != null) {
                this.restTimer.cancel();
                this.D = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void d(View view) {
        CountDownTimer countDownTimer = this.excersiseTimer;
        if (countDownTimer != null) {
            countDownTimer.cancel();
            this.C = false;
        }
        this.resumeMainExcersise.setVisibility(View.VISIBLE);
        this.pauseMainExcersise.setVisibility(View.GONE);
        b();
    }

    public void dataBaseProgressUpdate(double d) {
        if (this.u.equalsIgnoreCase("beginner")) {
            this.databaseOperations.insertExcDayData(this.day, (float) d);
            this.databaseOperations.insertExcCounter(this.day, this.excCouner);
        } else {
            this.databaseOperations.insertExcDayDataAdv(this.day, (float) d);
            this.databaseOperations.insertExcCounterAdv(this.day, this.excCouner);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.excCouner);
        stringBuilder.append("");
        Log.d("CounterValue", stringBuilder.toString());
        try {
            Intent intent = new Intent(AppUtils.WORKOUT_BROADCAST_FILTER);
            intent.putExtra(AppUtils.KEY_PROGRESS, d);
            sendBroadcast(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void e(View view) {
        if (this.m.isSpeaking().booleanValue()) {
            this.m.stop();
        }
        if (!this.F) {
            this.F = true;
            this.restTimer.cancel();
            this.restTimer.onFinish();
            this.pauseRestTime.setVisibility(View.VISIBLE);
            this.resumRestTime.setVisibility(View.GONE);
        }
    }

    public void f(View view) {
        this.readyToGoTimer.cancel();
        this.readyToGoTimer.onFinish();
    }

    public void g(View view) {
        if (this.i % 2 == 0) {
            this.playPause.setBackgroundResource(R.drawable.play);
            this.B = true;
            this.readyToGoTimer.cancel();
        } else {
            this.B = false;
            this.playPause.setBackgroundResource(R.drawable.pause);
            readyToGoFun(this.s1);
        }
        this.i++;
    }

    public void h(View view) {
        this.pauseRestTime.setVisibility(View.GONE);
        this.resumRestTime.setVisibility(View.VISIBLE);
        this.restTimer.cancel();
        this.D = false;
    }

    public void i(View view) {
        this.pauseRestTime.setVisibility(View.VISIBLE);
        this.resumRestTime.setVisibility(View.GONE);
        a(this.s1);
    }


    public void k(View view) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("mainExcCounter");
        stringBuilder.append(this.mainExcCounter);
        stringBuilder.append("mainExcProgress ");
        stringBuilder.append(this.mainExcProgress);
        Log.i("pauseMainExcersise", stringBuilder.toString());
        this.pauseMainExcersise.setVisibility(View.GONE);
        this.resumeMainExcersise.setVisibility(View.VISIBLE);
        this.excersiseTimer.cancel();
        this.animImageFull.stopAnimation();
        this.C = false;
    }

    public void l(View view) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("exc duration");
        stringBuilder.append(this.s1 - 1000);
        stringBuilder.append("mainExcCounter");
        stringBuilder.append(this.mainExcCounter);
        stringBuilder.append("mainExcProgress ");
        stringBuilder.append(this.mainExcProgress);
        Log.i("resumeMainExcersise", stringBuilder.toString());
        this.pauseMainExcersise.setVisibility(View.VISIBLE);
        this.resumeMainExcersise.setVisibility(View.GONE);
        mainExcTimer(this.s1 - 1000, this.mainExcCounter, this.mainExcProgress);
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        this.context = this;
        this.K = new Library(this.context);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String str = "";
        String string = defaultSharedPreferences.getString("languageToLoad", str);
        this.w = string;
        this.K.updateLocale(string);
        int i = 0;
        SharedPreferences sharedPreferences = getSharedPreferences(getResources().getString(R.string.timer_fref_file_name), 0);
        this.y = sharedPreferences;
        this.v = sharedPreferences.getInt("sound", 1);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("size of text");
        stringBuilder.append(this.w);
        Log.i("Debasish", stringBuilder.toString());
        getWindow().addFlags(128);
        setContentView(R.layout.mainexcercise_layout);
        this.databaseOperations = new DatabaseOperations(this);
        this.I = (Toolbar) findViewById(R.id.toolbarrest);
        ((Toolbar) findViewById(R.id.mtoolbar)).setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a(v);
            }
        });
        this.readytogo_layout = (CoordinatorLayout) findViewById(R.id.readytogo_layout);
        int i2 = this.y.getInt("resttime", 25);
        this.o = i2;
        this.REST_TIME_IN_MS = (long) ((i2 * 1000) + 2000);
        i2 = this.y.getInt("readytimer", 15);
        this.n = i2;
        long j = (long) ((i2 * 1000) + 2000);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            this.workoutDataList = (ArrayList) extras.getSerializable("workoutDataList");
        }

        this.packageName = getApplicationContext().getPackageName();
        this.day = ((Bundle) Objects.requireNonNull(getIntent().getExtras())).getString("day");
        this.m = AbsWomenApplication.getInstance();
        string = "beginner";
        String string2 = defaultSharedPreferences.getString("yoga_type", string);
        this.u = string2;
        if (string2 != null) {
            this.excCouner = string2.equalsIgnoreCase(string) ? this.databaseOperations.getDayExcCounter(this.day) : this.databaseOperations.getDayExcCounterAdv(this.day);
        }
        this.progressbar = (RoundCornerProgressBar) findViewById(R.id.progress_one);
        this.animImageFull = (FAImageView) findViewById(R.id.animImageFull);
        this.tvProgress = (TextView) findViewById(R.id.tv_progress);
        this.tvProgressMax = (TextView) findViewById(R.id.tv_progress_max);
        this.timerTop = (TextView) findViewById(R.id.timerTop);
        this.restScreen = (CoordinatorLayout) findViewById(R.id.restScreen);
        this.excName = (TextView) findViewById(R.id.excName);
        this.pauseMainExcersise = (ImageView) findViewById(R.id.pauseMainExcersise);
        this.resumeMainExcersise = (ImageView) findViewById(R.id.resumeMainExcersise);
        ImageView imageView = (ImageView) findViewById(R.id.skip_exc);
        ImageView imageView2 = (ImageView) findViewById(R.id.previous_exc);
        ImageView imageView3 = (ImageView) findViewById(R.id.countdown);
        ImageView imageView4 = (ImageView) findViewById(R.id.help);
        TextView textView = (TextView) findViewById(R.id.skip);
        TextView textView2 = (TextView) findViewById(R.id.skipRestTime);

        if (this.w.equalsIgnoreCase("ru") || this.w.equalsIgnoreCase("de") || this.w.equalsIgnoreCase("nl")) {
            textView2.setTextSize(0, getResources().getDimension(R.dimen.text_medium));
        }
        this.timerprogress = (ProgressBar) findViewById(R.id.timer);
        this.count = (TextView) findViewById(R.id.counting);
        this.playPause = (ImageView) findViewById(R.id.floatingPlay);
        this.excDescInReadyToGo = (TextView) findViewById(R.id.excDescInReadyToGo);
        this.excNameInReadyToGo = (TextView) findViewById(R.id.excNameInReadyToGo);
        this.pauseRestTime = (ImageView) findViewById(R.id.pauseRestTime);
        this.resumRestTime = (ImageView) findViewById(R.id.resumeRestTime);
        this.restTimerprogress = (ProgressBar) findViewById(R.id.rest_timer);
        this.countRestTimer = (TextView) findViewById(R.id.rest_counting);
        this.nextExerciseName = (TextView) findViewById(R.id.nextExerciseName);
        this.nextExerciseCycles = (TextView) findViewById(R.id.nextExerciseCycles);
        this.nextExerciseAnimation = (FAImageView) findViewById(R.id.nextExercisAnimation);
        this.layoutprogress = (LinearLayout) findViewById(R.id.hLayoutprogress);
        SharedPreferences sharedPreferences2 = getSharedPreferences("user", 0);
        Gson gson = new Gson();
        sharedPreferences2.getString("json_string", str);
        this.progressbar.setMax(10.0f);
        this.animImageFull.setInterval(1000);
        this.animImageFull.setLoop(true);
        this.animImageFull.reset();
        try {
            for (int addImageFrame : ((WorkoutData) this.workoutDataList.get(this.excCouner)).getImageIdList()) {
                this.animImageFull.addImageFrame(addImageFrame);
            }
        } catch (IndexOutOfBoundsException unused) {
            int size = this.workoutDataList.size() - 1;
            this.excCouner = size;
            for (int addImageFrame2 : ((WorkoutData) this.workoutDataList.get(size)).getImageIdList()) {
                this.animImageFull.addImageFrame(addImageFrame2);
            }
        }
        this.animImageFull.startAnimation();

        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e(v);
            }
        });

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                f(v);
            }
        });

        this.playPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g(v);
            }
        });

        this.pauseRestTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                h(v);
            }
        });

        this.resumRestTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i(v);
            }
        });

        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CountDownTimer countDownTimer = excersiseTimer;
                if (countDownTimer != null) {
                    countDownTimer.cancel();
                    C = false;
                }
                resumeMainExcersise.setVisibility(View.VISIBLE);
                pauseMainExcersise.setVisibility(View.GONE);
                excinfo();
            }
        });

        this.pauseMainExcersise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                k(v);
            }
        });

        this.resumeMainExcersise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                l(v);
            }
        });

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = "progressvalue";
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("mainExcCounter");
                stringBuilder.append(mainExcCounter);
                Log.i("mainexc", stringBuilder.toString());
                try {
                    if (!E) {
                        E = true;
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("progressvalueofimageid");
                        stringBuilder2.append(((WorkoutData) workoutDataList.get(excCouner)).getExcCycles());
                        Log.i(str, stringBuilder2.toString());
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("progressvalueofcounter");
                        stringBuilder2.append(((WorkoutData) workoutDataList.get(excCouner)).getImageIdList().length);
                        Log.i(str, stringBuilder2.toString());
                        topProgressBar.setProgress((((int) excDurGlobal) / 1000) - 1);
                        excersiseTimer.cancel();
                        excersiseTimer.onFinish();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (m.isSpeaking().booleanValue()) {
                    m.stop();
                }
                if (excCouner > 0) {
                    topProgressBar.setProgress(0);
                    excersiseTimer.cancel();
                    int i = excCouner - 1;
                    excCouner = i;
                    progressbar.setMax((float) ((WorkoutData) workoutDataList.get(i)).getExcCycles());
                    tvProgressMax.setText(String.valueOf(((WorkoutData) workoutDataList.get(excCouner)).getExcCycles()));
                    long calculateExTime = calculateExTime(excCouner);
                    excDurGlobal = calculateExTime;
                    pauseMainExcersise.setVisibility(View.VISIBLE);
                    resumeMainExcersise.setVisibility(View.GONE);
                    double excDayProgress = (double) (u.equalsIgnoreCase("beginner") ? databaseOperations.getExcDayProgress(day) : databaseOperations.getExcDayProgressAdv(day));
                    double size = (double) ((float) workoutDataList.size());
                    Double.isNaN(size);
                    Double.isNaN(excDayProgress);
                    progress = excDayProgress - (100.0d / size);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("value of progress");
                    stringBuilder.append(databaseOperations.getExcDayProgress(day));
                    stringBuilder.append(" ");
                    excDayProgress = (double) ((float) workoutDataList.size());
                    Double.isNaN(excDayProgress);
                    stringBuilder.append(100.0d / excDayProgress);
                    Log.i("dev", stringBuilder.toString());
                    dataBaseProgressUpdate(progress);
                    mainExcTimer(calculateExTime, 1, 1.0f);
                    return;
                }
                Toast.makeText(m, "This is first exercise", Toast.LENGTH_SHORT).show();
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d(v);
            }
        });

        readyToGoFun(j);
        LayoutParams layoutParams = new LayoutParams(-1, -2, 1.0f);
        for (int i3 = 0; i3 < this.workoutDataList.size(); i3++) {
            this.topProgressBar = new ProgressBar(this, (AttributeSet) null, 16842872);
            layoutParams.rightMargin = 2;
            layoutParams.leftMargin = 2;
            this.topProgressBar.setPadding(0, 0, 0, -8);
            this.topProgressBar.setLayoutParams(layoutParams);
            this.topProgressBar.setId(i3);
            this.topProgressBar.setScaleY(2.5f);
            this.topProgressBar.setProgressDrawable(getResources().getDrawable(R.drawable.launch_progressbar));
            this.layoutprogress.addView(this.topProgressBar);
            this.topProgressBar.setMax(0);
        }
        while (i < this.excCouner) {
            ProgressBar progressBar = (ProgressBar) this.layoutprogress.findViewById(i);
            this.topProgressBar = progressBar;
            progressBar.setMax(((WorkoutData) this.workoutDataList.get(this.excCouner)).getImageIdList().length * ((WorkoutData) this.workoutDataList.get(this.excCouner)).getExcCycles());
            this.topProgressBar.setProgress(((WorkoutData) this.workoutDataList.get(this.excCouner)).getImageIdList().length * ((WorkoutData) this.workoutDataList.get(this.excCouner)).getExcCycles());
            i++;
        }
        getScreenHeightWidth();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finish();
        return true;
    }

    public void onPause() {
        super.onPause();
        cancelTimers();
        if (!this.B) {
            this.i--;
        }
        this.playPause.setBackgroundResource(R.drawable.play);
        this.resumeMainExcersise.setVisibility(View.VISIBLE);
        this.pauseMainExcersise.setVisibility(View.GONE);
        this.resumRestTime.setVisibility(View.VISIBLE);
        this.pauseRestTime.setVisibility(View.GONE);
        this.animImageFull.stopAnimation();
    }

    public void onResume() {
        super.onResume();
        this.pauseMainExcersise.setVisibility(View.GONE);
        this.resumeMainExcersise.setVisibility(View.VISIBLE);
    }

    public void onSuperBackPressed() {
        super.onBackPressed();
    }

    public void readyToGoFun(long j) {
        this.excDescInReadyToGo.setText(((WorkoutData) this.workoutDataList.get(this.excCouner)).getExcDescResId());
        String toUpperCase = ((WorkoutData) this.workoutDataList.get(this.excCouner)).getExcName().replace("_", " ").toUpperCase();
        this.excNameInReadyToGo.setText(toUpperCase);
        toUpperCase = toUpperCase.toLowerCase();
        if (j == 10000 && this.v == 1) {
            this.m.speak("ready to go ");
            AbsWomenApplication absWomenApplication = this.m;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("the exercise is ");
            stringBuilder.append(toUpperCase);
            absWomenApplication.speak(stringBuilder.toString());
        } else {
            String str = "";
            this.m.speak(str);
            this.m.speak(str);
        }
        this.timerprogress.setMax(this.n);
        this.readyToGoTimer = new CountDownTimer(j, 1000) {
            public void onFinish() {
                Log.i("readyToGoTimer", "onFinish: ");
                MainExcerciseActivity.this.M = Boolean.valueOf(false);
                MainExcerciseActivity.this.timerprogress.setProgress(0);
                MainExcerciseActivity.this.readytogo_layout.setVisibility(View.GONE);
                long length = (long) (((((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getImageIdList().length > 2 ? ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getImageIdList().length * ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles() : ((WorkoutData) MainExcerciseActivity.this.workoutDataList.get(MainExcerciseActivity.this.excCouner)).getExcCycles()) + 1) * 1000);
                MainExcerciseActivity.this.excDurGlobal = length;
                MainExcerciseActivity.this.pauseMainExcersise.setVisibility(View.VISIBLE);
                MainExcerciseActivity.this.resumeMainExcersise.setVisibility(View.GONE);
                MainExcerciseActivity mainExcerciseActivity = MainExcerciseActivity.this;
                mainExcerciseActivity.mainExcTimer(length, mainExcerciseActivity.mainExcCounter, MainExcerciseActivity.this.mainExcProgress);
            }

            public void onTick(long j) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("progressbar: ");
                stringBuilder.append(((int) j) / 1000);
                Log.i("readyToGoTimer", stringBuilder.toString());
                long j2 = j - 1000;
                MainExcerciseActivity.this.timerprogress.setProgress(((int) j2) / 1000);
                TextView textView = MainExcerciseActivity.this.count;
                StringBuilder stringBuilder2 = new StringBuilder();
                j2 /= 1000;
                stringBuilder2.append(j2);
                stringBuilder2.append("");
                textView.setText(stringBuilder2.toString());
                MainExcerciseActivity.this.s1 = j;
                if (j2 >= 4 || MainExcerciseActivity.this.v != 1) {
                    if (!MainExcerciseActivity.this.m.isSpeaking().booleanValue()) {
                        MainExcerciseActivity.this.m.playEarCorn(MainExcerciseActivity.this.v);
                    }
                    return;
                }
                if (j2 == 3) {
                    MainExcerciseActivity.this.m.speak("three ");
                }
                if (j2 == 2) {
                    MainExcerciseActivity.this.m.speak("two ");
                }
                if (j2 == 1) {
                    MainExcerciseActivity.this.m.speak("one ");
                }
                if (j2 == 0 && !MainExcerciseActivity.this.M.booleanValue()) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("onTick: ");
                    stringBuilder.append(j);
                    Log.d("TAG", stringBuilder.toString());
                    MainExcerciseActivity.this.m.speak("let's start");
                    MainExcerciseActivity.this.M = Boolean.valueOf(true);
                }
            }
        }.start();
    }
}
