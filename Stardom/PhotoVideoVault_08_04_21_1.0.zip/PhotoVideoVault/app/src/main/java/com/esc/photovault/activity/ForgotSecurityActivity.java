package com.esc.photovault.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.esc.photovault.R;
import com.esc.photovault.pref.SharedPreference;
import com.esc.photovault.util.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import java.util.ArrayList;
import java.util.List;

public class ForgotSecurityActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{
    private Activity activity = ForgotSecurityActivity.this;
    private ImageView back_icon, done_icon;
    private EditText editText;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_security);

        BannerAds();

        back_icon = (ImageView) findViewById(R.id.back);
        done_icon = (ImageView) findViewById(R.id.done_next);
        editText = (EditText) findViewById(R.id.ans_edt_text);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) ForgotSecurityActivity.this);
        List<String> categories = new ArrayList<String>();
        categories.add("Favourite Movie");
        categories.add("Favourite Football Player");
        categories.add("Favourite Actore");
        categories.add("Pet Name");
        categories.add("Favourite Teacher");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, R.layout.spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);

        back_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        done_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreference.storeSecurity(ForgotSecurityActivity.this, Utils.SECOND_TIME_SELECT_ANSWER, editText.getText().toString());
                String first_time_que = SharedPreference.getSecurity(ForgotSecurityActivity.this, Utils.FIRST_TIME_SELECT_QUESTION);
                String second_time_que = SharedPreference.getSecurity(ForgotSecurityActivity.this, Utils.SECOND_TIME_SELECT_QUESTION);
                String first_time_ans = SharedPreference.getSecurity(ForgotSecurityActivity.this, Utils.FIRST_TIME_SELECT_ANSWER);
                if (first_time_que.equalsIgnoreCase(second_time_que)) {
                    if (first_time_ans.equalsIgnoreCase(editText.getText().toString())) {
                        Intent intent1 = new Intent(ForgotSecurityActivity.this, LockScreenActivity.class);
                        intent1.putExtra("forgot", "forgot");
                        startActivity(intent1);
                        finish();
                    } else {
                        Toast.makeText(getApplicationContext(), "Answer does not Match!!", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Plese select correct Question!!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView parent, View view, int position, long id) {
        String item = parent.getItemAtPosition(position).toString();
        SharedPreference.storeSecurity(ForgotSecurityActivity.this, Utils.SECOND_TIME_SELECT_QUESTION, item);
    }

    public void onNothingSelected(AdapterView arg0) {

    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
