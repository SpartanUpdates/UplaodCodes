package com.kotlinz.vehiclemanager.history.Room;

import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.kotlinz.vehiclemanager.history.Model.OwnerHistoryPaidModel;

import java.util.List;

@androidx.room.Dao
public interface OwnerHistoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertOwnerData(OwnerHistoryPaidModel history);

    @Query("select * from OwnerHistoryPaid")
    List<OwnerHistoryPaidModel> getOwnerHistory();

    @Query("Delete from OwnerHistoryPaid where registrationNo=:registrationNo")
    void  deleteOwnerDetails(String registrationNo);


}