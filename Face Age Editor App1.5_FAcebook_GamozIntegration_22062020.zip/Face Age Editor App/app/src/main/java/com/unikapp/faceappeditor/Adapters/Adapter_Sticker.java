package com.unikapp.faceappeditor.Adapters;

import android.content.*;
import android.widget.*;
import java.util.*;
import android.view.*;
import com.bumptech.glide.*;
import com.unikapp.faceage.editorapp.R;

public class Adapter_Sticker extends BaseAdapter {
	Context context;
	ImageView img_editing;
	private LayoutInflater inflater;
	ArrayList<Integer> stickers;

	public Adapter_Sticker(final Context context,
			final ArrayList<Integer> stickers) {
		this.context = context;
		this.stickers = stickers;
		this.inflater = (LayoutInflater) this.context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	public int getCount() {
		return this.stickers.size();
	}

	public Object getItem(final int n) {
		return this.stickers.get(n);
	}

	public long getItemId(final int n) {
		return n;
	}

	public View getView(int intValue, final View view, final ViewGroup viewGroup) {
		View inflate = view;
		if (view == null) {
			inflate = this.inflater.inflate(R.layout.sticker_item,
					(ViewGroup) null);
		}
		this.img_editing = (ImageView) inflate
				.findViewById(R.id.img_sticker_item);
		intValue = this.stickers.get(intValue);
		Glide.with(this.context).load(Integer.valueOf(intValue))
				.into(this.img_editing);
		System.gc();
		return inflate;
	}

	public class ViewHolder {
	}
}
