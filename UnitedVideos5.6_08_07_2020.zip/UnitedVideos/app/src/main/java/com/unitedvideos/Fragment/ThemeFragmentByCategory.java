package com.unitedvideos.Fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.unitedvideos.Adapter.ThemeCategoryAdapter;
import com.unitedvideos.Model.ThemeHorizontalModel;
import com.unitedvideos.R;
import com.unitedvideos.Retrofit.APIClient;
import com.unitedvideos.Retrofit.APIInterface;
import com.unitedvideos.Retrofit.AppConstant;
import com.unitedvideos.UnityPlayerActivity;
import com.unitedvideos.Utils.Utils;
import com.unitedvideos.activity.HomeActivity;
import com.unitedvideos.application.MyApplication;
import com.unitedvideos.kprogresshud.KProgressHUD;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThemeFragmentByCategory extends Fragment {

    public int id;
    public Handler i;
    LinearLayout llInternetCheck;
    Button btnRetry;
    RelativeLayout rlLoadingTheme;
    //    RelativeLayout rlLoadingThemeMore;
    RecyclerView rvVideos;
    String offlineThemeData;
    int CategoryId = -1;
    String CatId;
    SharedPreferences pref;
    GridLayoutManager gridLayoutManager;
    KProgressHUD hud;
    //    SwipeRefreshLayout mSwipeRefreshLayout;
    private ArrayList<ThemeHorizontalModel> ThemeListCategoryWise = new ArrayList<>();
    public static ThemeCategoryAdapter themeAdapter;
    APIInterface apiInterface;
    public int ThemeLoadMoreLength;
    private boolean isLoading = false;
    private int PageId = 1;

    public static ThemeFragmentByCategory newInstance(int catid) {
        ThemeFragmentByCategory fragment = new ThemeFragmentByCategory();
        Bundle bundle = new Bundle();
        bundle.putInt("CategoryId", catid);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            CategoryId = getArguments().getInt("CategoryId");
            CatId = String.valueOf(CategoryId);
        }
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_theme, container, false);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        apiInterface = APIClient.getClient().create(APIInterface.class);
        BindView(view);
        SetListener();
        if (ThemeListCategoryWise != null && ThemeListCategoryWise.size() == 0) {
            SetThemeData();
            Log.e("TAG", "SetThemData");
        } else {
            SetUpAdapter();
        }
        return view;
    }


    private void SetThemeData() {
        Log.e("TAG", "SetThemData");
        String id = pref.getString(CatId, null);
        if (id != null && !id.equals("")) {
            getOfflineCategory(getActivity(), CatId);
            if (offlineThemeData != null) {
                new GetofflineThemeData().execute();
            } else {
                llInternetCheck.setVisibility(View.VISIBLE);
                rlLoadingTheme.setVisibility(View.GONE);
                Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void BindView(View view) {
//        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
        rvVideos = view.findViewById(R.id.rvVideos);
        llInternetCheck = view.findViewById(R.id.llRetry);
        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
        rlLoadingTheme = view.findViewById(R.id.rl_loading_pager);
//        rlLoadingThemeMore=view.findViewById(R.id.rl_loading_pager_bottom);
        rvVideos.setNestedScrollingEnabled(false);
        rvVideos.setHasFixedSize(true);
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    startActivity(new Intent(getActivity(), HomeActivity.class));
                    getActivity().finish();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
//        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                if (Utils.checkConnectivity(getActivity(), false)) {
//                    llInternetCheck.setVisibility(View.GONE);
//                    ThemeListCategoryWise.clear();
//                    GetCategoryOfTheme();
//                    mSwipeRefreshLayout.setRefreshing(false);
//                } else {
//                    mSwipeRefreshLayout.setRefreshing(false);
//                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });

    }


    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlineThemeData = pref.getString(key, null);
    }


    public void SetUpAdapter() {
        Log.e("TAG", "SetUpAdapter");
        RecyclerView recyclerView;
        int i2 = 0;
        gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        themeAdapter = new ThemeCategoryAdapter(getActivity(), ThemeListCategoryWise);
        rvVideos.setLayoutManager(gridLayoutManager);
        rvVideos.setItemAnimator(new DefaultItemAnimator());
        rvVideos.setAdapter(themeAdapter);
        if (MyApplication.ThemePosition == -1) {
            recyclerView = this.rvVideos;
        } else {
            recyclerView = this.rvVideos;
            i2 = MyApplication.ThemePosition;
        }
        recyclerView.scrollToPosition(i2);
        rvVideos.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(gridLayoutManager.findFirstVisibleItemPosition());
                stringBuilder.append("");
                MyApplication.ThemePosition = gridLayoutManager.findFirstVisibleItemPosition();

                GridLayoutManager linearLayoutManager = (GridLayoutManager) recyclerView.getLayoutManager();
                if (!isLoading) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == ThemeListCategoryWise.size() - 1) {
                        //bottom of list!
                        LoadMoreTheme();
                        isLoading = true;
                    }
                }
            }
        });
        themeAdapter.notifyDataSetChanged();
        /*if (!MyApplication.IsHomeAdsDisplay && UnityPlayerActivity.mInterstitialAd != null && UnityPlayerActivity.mInterstitialAd.isLoaded()) {
            MyApplication.IsHomeAdsDisplay = true;
            UnityPlayerActivity.mInterstitialAd.show();
//            try {
//                hud = KProgressHUD.create(getActivity())
//                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
//                        .setLabel("Showing Ads")
//                        .setDetailsLabel("Please Wait...");
//                hud.show();
//            } catch (IllegalArgumentException e) {
//                e.printStackTrace();
//            } catch (NullPointerException e2) {
//                e2.printStackTrace();
//            } catch (Exception e3) {
//                e3.printStackTrace();
//            }
//            Handler handler = new Handler();
//            handler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    try {
//                        hud.dismiss();
//                    } catch (IllegalArgumentException e) {
//                        e.printStackTrace();
//                    } catch (NullPointerException e2) {
//                        e2.printStackTrace();
//                    } catch (Exception e3) {
//                        e3.printStackTrace();
//                    }
//                    if (UnityPlayerActivity.mInterstitialAd != null && UnityPlayerActivity.mInterstitialAd.isLoaded()) {
//                        MyApplication.IsHomeAdsDisplay = true;
//                        UnityPlayerActivity.mInterstitialAd.show();
//                    }
//                }
//            }, 2000);
        }*/
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

    private void LoadMoreTheme() {
        PageId++;
        ThemeLoadMoreLength = 0;
        GetLoadMoreTheme();
    }

    private void GetLoadMoreTheme() {
//        rlLoadingThemeMore.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.GetMoreTheme(AppConstant.Token, AppConstant.ApplicationId, CatId, String.valueOf(PageId));
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject themeJSONObject = jsonArray.getJSONObject(i);
//                            int Catid = Integer.parseInt(themeJSONObject.getString("id"));
//                            if (CategoryId == Catid) {
                            JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                            for (int j = 0; j < jSONArray4.length(); j++) {
                                ThemeLoadMoreLength = jsonArray.length();
                                ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                                JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                                themeModel.setThemeid(jsonobjecttheme.getString("theme_id"));
                                themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                themeModel.setVideoType(jsonobjecttheme.getString("video_type"));
                                themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                themeModel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                                themeModel.setBundelUrl(jsonobjecttheme.getString("animation_file"));
                                themeModel.setBundelName(jsonobjecttheme.getString("animation_file_name") + ".unity3d");
                                themeModel.setPrefebName(jsonobjecttheme.getString("animation_file_name"));
                                themeModel.setBundelPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getBundelName());
                                themeModel.setBundelSize(jsonobjecttheme.getString("animation_file_size"));
                                themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_file_name") + ".mp3");
                                themeModel.setAnimSoundPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                                themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_file_size")));
                                themeModel.setImageWidht(Integer.parseInt(jsonobjecttheme.getString("width")));
                                themeModel.setImageHeight(Integer.parseInt(jsonobjecttheme.getString("height")));
                                themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + themeModel.getBundelName());
                                themeModel.setImg_no_of(Integer.parseInt(jsonobjecttheme.getString("number_of_images")));
                                themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                themeModel.setIsNewRealise(jsonobjecttheme.getString("is_release"));
                                ThemeListCategoryWise.add(themeModel);
                            }

//                            }
                        }
                        if (ThemeLoadMoreLength != 0) {
                            SetUpAdapter();
                        }
//                        rlLoadingThemeMore.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
//                rlLoadingThemeMore.setVisibility(View.GONE);
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    public class GetofflineThemeData extends AsyncTask<Void, Void, Void> {

        protected void onPreExecute() {
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlineThemeData);
//                int Catid = Integer.parseInt(jsonObj.getString("id"));
                JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
                for (int j = 0; j < jSONArray4.length(); j++) {
                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                    themeModel.setThemeid(jsonobjecttheme.getString("theme_id"));
                    themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                    themeModel.setVideoType(jsonobjecttheme.getString("video_type"));
                    themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                    themeModel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                    themeModel.setBundelUrl(jsonobjecttheme.getString("animation_file"));
                    themeModel.setBundelName(jsonobjecttheme.getString("animation_file_name") + ".unity3d");
                    themeModel.setPrefebName(jsonobjecttheme.getString("animation_file_name"));
                    themeModel.setBundelPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getBundelName());
                    themeModel.setBundelSize(jsonobjecttheme.getString("animation_file_size"));
                    themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                    themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_file_name") + ".mp3");
                    themeModel.setAnimSoundPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                    themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_file_size")));
                    themeModel.setImageWidht(Integer.parseInt(jsonobjecttheme.getString("width")));
                    themeModel.setImageHeight(Integer.parseInt(jsonobjecttheme.getString("height")));
                    themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + themeModel.getBundelName());
                    themeModel.setImg_no_of(Integer.parseInt(jsonobjecttheme.getString("number_of_images")));
                    themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                    themeModel.setIsNewRealise(jsonobjecttheme.getString("is_release"));
                    ThemeListCategoryWise.add(themeModel);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(Void result) {
            rlLoadingTheme.setVisibility(View.GONE);
            SetUpAdapter();
        }
    }
}
