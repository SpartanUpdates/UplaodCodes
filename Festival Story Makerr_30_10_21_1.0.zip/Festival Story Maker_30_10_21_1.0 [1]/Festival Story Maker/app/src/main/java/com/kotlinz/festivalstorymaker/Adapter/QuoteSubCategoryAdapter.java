package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.CategoryWiseData.QuoteCategoryWiseData;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.QuoteMakerActivity;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class QuoteSubCategoryAdapter extends RecyclerView.Adapter<QuoteSubCategoryAdapter.MyViewHolder> {

    public QuoteMakerActivity quoteMakerActivity;
    public int position = -1;
    public ArrayList<QuoteCategoryWiseData> quoteCategoryWiseData;

    public QuoteSubCategoryAdapter(Context context, ArrayList<QuoteCategoryWiseData> quoteCategoryWiseData) {
        this.quoteMakerActivity = (QuoteMakerActivity) context;
        this.quoteCategoryWiseData = quoteCategoryWiseData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_quote_item, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(quoteMakerActivity).load(quoteCategoryWiseData.get(position).getThemeThumbnail()).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivThumbImage);
        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        holder.ivShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        holder.ivDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return quoteCategoryWiseData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.llMain)
        public LinearLayout llMain;

        @BindView(R.id.ivThumbImage)
        public ImageView ivThumbImage;

        @BindView(R.id.iV_share)
        public ImageView ivShare;

        @BindView(R.id.iv_download)
        public ImageView ivDownload;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
