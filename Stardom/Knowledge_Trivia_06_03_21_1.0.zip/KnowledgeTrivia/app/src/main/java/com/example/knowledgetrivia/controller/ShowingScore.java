package com.example.knowledgetrivia.controller;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.example.knowledgetrivia.R;
import com.example.knowledgetrivia.database.DatabaseHelper;
import com.example.knowledgetrivia.kprogresshud.KProgressHUD;
import com.example.knowledgetrivia.manager.QuestionManager;
import com.example.knowledgetrivia.models.LevelScore;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.LineDataSet.Mode;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;
import java.util.List;

public class ShowingScore extends AppCompatActivity {
    Activity activity=ShowingScore.this;
    private MediaPlayer tick;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public void onCreate(Bundle bundle) {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_showing_score);
        this.tick = MediaPlayer.create(this, R.raw.tick);


        BannerAds();

        interstitialAd();

        int i = 0;
        if (getIntent().getBooleanExtra("frommenu", false)) {
            findViewById(R.id.next_lay_ss).setVisibility(View.GONE);
        }
        ListView listView = (ListView) findViewById(R.id.listView);
        TextView textView = (TextView) findViewById(R.id.lay_ss_score);
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        ArrayList dataOfScoreTable = new DatabaseHelper(this).getDataOfScoreTable();
        int total = LevelScore.getTotal(dataOfScoreTable);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Scores: ");
        stringBuilder.append(String.valueOf(total));
        textView.setText(stringBuilder.toString());
        for (int size = dataOfScoreTable.size() - 1; size >= 0; size--) {
            LevelScore levelScore = (LevelScore) dataOfScoreTable.get(size);
            stringBuilder = new StringBuilder();
            stringBuilder.append("Level ");
            stringBuilder.append(levelScore.getLevel());
            arrayList.add(stringBuilder.toString());
            arrayList2.add(String.valueOf(levelScore.getScore()));
        }
        while (i < dataOfScoreTable.size()) {
            total = i + 1;
            arrayList3.add(new Entry((float) total, (float) ((LevelScore) dataOfScoreTable.get(i)).getScore()));
            i = total;
        }
        LineChart lineChart = (LineChart) findViewById(R.id.lineChart_scores);
        LineDataSet lineDataSet = new LineDataSet(arrayList3, "Scores in each level");
        lineDataSet.setMode(Mode.CUBIC_BEZIER);
        lineDataSet.setDrawFilled(true);
        lineDataSet.setValueTextColor(-1);
        lineDataSet.setValueFormatter(new ValueFormatter() {
            public String getFormattedValue(float f, Entry entry, int i, ViewPortHandler viewPortHandler)
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append((int) f);
                return stringBuilder.toString();
            }
        });
        lineDataSet.setValueTextSize(10.0f);
        List arrayList4 = new ArrayList();
        arrayList4.add(lineDataSet);
        if (arrayList3.isEmpty()) {
            lineChart.clear();
            findViewById(R.id.level_chart_name).setVisibility(View.INVISIBLE);
        } else {
            lineChart.setData(new LineData(arrayList4));
        }
        Description description = new Description();
        description.setText("");
        lineChart.setDescription(description);
        lineChart.getAxisLeft().setTextColor(-1);
        lineChart.getAxisRight().setTextColor(-1);
        lineChart.getXAxis().setTextColor(-1);
        lineChart.getLegend().setTextColor(-1);
        lineChart.setNoDataText("No Any Score Data Found.");
        lineChart.setNoDataTextColor(-1);
        lineChart.invalidate();
        listView.setAdapter(new SSAdapter(this, arrayList, arrayList2));
    }

    public void onClickShareBtn(View view) {
        this.tick.start();
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.SUBJECT", "Knowledge Trivia");
        intent.putExtra("android.intent.extra.TEXT", "Check out the Latest General Knowledge Quiz App to Evaluate & Enhance your Knowledge https://play.google.com/store/apps/details?id="+getPackageName());
        startActivity(Intent.createChooser(intent, "share using"));
    }

    public void clickNextBtn(View view)
    {
        this.tick.start();
        int intExtra = getIntent().getIntExtra("currentlevel", 0);


        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            try {
                hud = KProgressHUD.create(activity)
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Showing Ads")
                        .setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        id = 100;
                        mInterstitialAd.show();
                    }
                }
            }, 2000);
        } else {
            if (intExtra != 0) {
                intExtra++;
                if (!QuestionManager.getInstance(this).isExist(intExtra)) {
                    intExtra--;
                }
                Intent intent = new Intent(this, ShowingQuestion.class);
                intent.putExtra("level", intExtra);
                startActivity(intent);
                finish();
            }
        }

    }

    public void onclickrating(View view) {
        this.tick.start();
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=pk.apricotacademyit.gkapp")));
    }

    public void finish() {
        super.finish();
        overridePendingTransition(17432576, 17432577);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdmobBannerId));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdmobInterstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        tick.start();
                        int intExtra = getIntent().getIntExtra("currentlevel", 0);
                        if (intExtra != 0) {
                            intExtra++;
                            if (!QuestionManager.getInstance(ShowingScore.this).isExist(intExtra)) {
                                intExtra--;
                            }
                            Intent intent = new Intent(ShowingScore.this, ShowingQuestion.class);
                            intent.putExtra("level", intExtra);
                            startActivity(intent);
                            finish();
                        }
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdmobInterstitial));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
