package com.esc.socialmediacleaner.datastructure;

import java.util.ArrayList;

public class AllData {
    public ArrayList<AppData> allDataList = new ArrayList();
    public ArrayList<FileDataWrapper> appList;
    public ArrayList<FileDataWrapper> audList = new ArrayList();
    public long audSize = 0;
    public boolean dataDeleted = false;
    public ArrayList<FileDataWrapper> docList = new ArrayList();
    public long docSize = 0;
    public ArrayList<FileDataWrapper> gifList = new ArrayList();
    public long gifSize = 0;
    public ArrayList<FileDataWrapper> imgList = new ArrayList();
    public long imgSize = 0;
    public boolean redirectHome = false;
    public ArrayList<SocialAppType> tabList;
    public int totFiles;
    public int totSelectedItem;
    public long totSelectedSize;
    public long totSize;
    public int total_filetype;
    public ArrayList<FileDataWrapper> vidList = new ArrayList();
    public long vidSize = 0;

    public void fillDataAsPerMediaType() {
        for (int i = 0; i < this.allDataList.size(); i++) {
            AppData appData = (AppData) this.allDataList.get(i);
            for (int i2 = 0; i2 < appData.list.size(); i2++) {
                MediaTypeList mediaTypeList = (MediaTypeList) appData.list.get(i2);
                int i3;
                if (mediaTypeList.mediaType == MediaType.IMAGES) {
                    for (i3 = 0; i3 < mediaTypeList.list.size(); i3++) {
                        this.imgList.add(mediaTypeList.list.get(i3));
                        this.imgSize += ((FileDataWrapper) mediaTypeList.list.get(i3)).size;
                    }
                } else if (mediaTypeList.mediaType == MediaType.VIDEOS) {
                    for (i3 = 0; i3 < mediaTypeList.list.size(); i3++) {
                        this.vidList.add(mediaTypeList.list.get(i3));
                        this.vidSize += ((FileDataWrapper) mediaTypeList.list.get(i3)).size;
                    }
                } else if (mediaTypeList.mediaType == MediaType.AUDIOS) {
                    for (i3 = 0; i3 < mediaTypeList.list.size(); i3++) {
                        this.audList.add(mediaTypeList.list.get(i3));
                        this.audSize += ((FileDataWrapper) mediaTypeList.list.get(i3)).size;
                    }
                } else if (mediaTypeList.mediaType == MediaType.GIFS) {
                    for (i3 = 0; i3 < mediaTypeList.list.size(); i3++) {
                        this.gifList.add(mediaTypeList.list.get(i3));
                        this.gifSize += ((FileDataWrapper) mediaTypeList.list.get(i3)).size;
                    }
                } else {
                    for (i3 = 0; i3 < mediaTypeList.list.size(); i3++) {
                        this.docList.add(mediaTypeList.list.get(i3));
                        this.docSize += ((FileDataWrapper) mediaTypeList.list.get(i3)).size;
                    }
                }
            }
        }
        this.totFiles = (((this.imgList.size() + this.vidList.size()) + this.audList.size()) + this.docList.size()) + this.gifList.size();
        this.totSize = (((this.imgSize + this.audSize) + this.vidSize) + this.docSize) + this.gifSize;
    }

    public void unCheckItem(FileDataWrapper fileDataWrapper) {
        if (fileDataWrapper.ischecked) {
            fileDataWrapper.ischecked = false;
            this.totSelectedItem--;
            this.totSelectedSize -= fileDataWrapper.size;
        }
    }

    public void checkItem(FileDataWrapper fileDataWrapper) {
        if (!fileDataWrapper.ischecked) {
            fileDataWrapper.ischecked = true;
            this.totSelectedItem++;
            this.totSelectedSize += fileDataWrapper.size;
        }
    }

    public void uncheckAll(ArrayList<FileDataWrapper> arrayList) {
        for (int i = 0; i < arrayList.size(); i++) {
            ((FileDataWrapper) arrayList.get(i)).ischecked = false;
        }
        this.totSelectedSize = 0;
        this.totSelectedItem = 0;
    }

    public void setAppSpecificList(ArrayList<FileDataWrapper> arrayList, int i) {
        this.appList = new ArrayList();
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            FileDataWrapper fileDataWrapper = (FileDataWrapper) arrayList.get(i2);
            if (fileDataWrapper.socialAppType == this.tabList.get(i)) {
                this.appList.add(fileDataWrapper);
            }
        }
    }
}
