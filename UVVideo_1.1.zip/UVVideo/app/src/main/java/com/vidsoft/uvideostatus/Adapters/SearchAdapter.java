package com.vidsoft.uvideostatus.Adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.vidsoft.uvideostatus.Activity.SearchActivity;
import com.vidsoft.uvideostatus.Models.VideoData;
import com.vidsoft.uvideostatus.R;
import com.vidsoft.uvideostatus.Utility.FontTextView;
import com.vidsoft.uvideostatus.Utility.Utility;
import com.wang.avi.AVLoadingIndicatorView;
import java.util.ArrayList;
import java.util.List;

public class SearchAdapter extends Adapter<RecyclerView.ViewHolder> {
    public List<VideoData> VideoList = new ArrayList();
    private Context context;
    private boolean isLoading;
    private boolean loading;
    SearchActivity searchActivity;

    public static class ProgressViewHolder extends RecyclerView.ViewHolder {
        public AVLoadingIndicatorView progressBar;

        public ProgressViewHolder(View view) {
            super(view);
            this.progressBar = view.findViewById(R.id.progressBar1);
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public FontTextView duration;
        LottieAnimationView icon_like;
        public ImageView icon_like_main;
        public RelativeLayout llVideoList;
        public FontTextView tvVideoListingDuration;
        public FontTextView tvVideoListingName;
        public FontTextView tvVideoListingSize;
        public ImageView tvVideoListingThumbnail;
        public FontTextView tvlike;
        public FontTextView tvtitle;

        public ViewHolder(View view) {
            super(view);
            this.tvVideoListingName = view.findViewById(R.id.tvVideoListingName);
            this.llVideoList = view.findViewById(R.id.llVideoList);
            this.tvVideoListingThumbnail = view.findViewById(R.id.tvVideoListingThumbnail);
            this.tvVideoListingSize = view.findViewById(R.id.tvVideoListingSize);
            this.tvVideoListingDuration = view.findViewById(R.id.tvVideoListingDuration);
            this.duration = view.findViewById(R.id.duration);
            this.icon_like_main = view.findViewById(R.id.icon_like_main);
            this.icon_like = view.findViewById(R.id.icon_like);
            this.tvtitle = view.findViewById(R.id.tvtitle);
            this.tvlike = view.findViewById(R.id.tvlike);
            this.icon_like_main.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ViewHolder.this.icon_like_main.setVisibility(View.GONE);
                    ViewHolder.this.icon_like.setVisibility(View.VISIBLE);
                    ViewHolder.this.icon_like.playAnimation();
                    ViewHolder.this.icon_like.loop(false);
                }
            });
            this.llVideoList.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    SearchAdapter.this.searchActivity.playVideo(SearchAdapter.this.VideoList.get(ViewHolder.this.getAdapterPosition()));
                }
            });
        }
    }

    public SearchAdapter(Context context2, ArrayList<VideoData> arrayList, SearchActivity searchActivity2, RecyclerView recyclerView) {
        this.VideoList = arrayList;
        this.context = context2;
        this.searchActivity = searchActivity2;
        notifyDataSetChanged();
        this.isLoading = false;
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        if (i == 1) {
            return new ViewHolder(from.inflate(R.layout.multi_item, viewGroup, false));
        }
        return new ProgressViewHolder(from.inflate(R.layout.progress_item, viewGroup, false));
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ProgressViewHolder) {
            ProgressViewHolder progressViewHolder = (ProgressViewHolder) viewHolder;
            progressViewHolder.progressBar.setVisibility(View.VISIBLE);
            progressViewHolder.progressBar.show();
            return;
        }
        VideoData videoData = this.VideoList.get(i);
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        viewHolder2.tvVideoListingName.setText(videoData.getTitle());
        viewHolder2.tvVideoListingSize.setText(videoData.getLikes());
        FontTextView fontTextView = viewHolder2.tvVideoListingDuration;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Utility.getViews(Double.parseDouble(videoData.getViews())));
//            Log.e("getView",""+videoData.getViews());
            stringBuilder.append(" views");
            fontTextView.setText(stringBuilder.toString());
        }catch (Exception e){
            e.printStackTrace();
        }
        viewHolder2.tvlike.setText(videoData.getLikes());
        viewHolder2.tvtitle.setText(videoData.getCatagory());
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.video_placeholder);
        requestOptions.error(R.drawable.video_placeholder);
        Glide.with(this.context).load(videoData.getThumbnail()).apply(requestOptions).into(viewHolder2.tvVideoListingThumbnail);
    }

    public void setLoaded() {
        this.loading = false;
    }

    public void addAll(List<VideoData> list) {
        this.VideoList = new ArrayList();
        this.VideoList.size();
        this.VideoList.addAll(list);
        notifyDataSetChanged();
    }

    public int getItemCount() {
        StringBuilder sb = new StringBuilder();
        sb.append("getItemCount: ");
        sb.append(this.VideoList.size());
        Log.d("TAG", sb.toString());
        return this.VideoList.size();
    }

    public int getItemViewType(int i) {
        return this.VideoList.get(i).getType();
    }
}
