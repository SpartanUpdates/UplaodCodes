package com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Download.DownloadTemplateImage;
import com.kotlinz.festivalstorymaker.Model.FestivalPoster.categoryWiseData.CategoryWiseData;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;
import com.kotlinz.festivalstorymaker.activity.FestivalTemplateActivity;

import java.io.File;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FestivalCategoryRlatedAdapter extends RecyclerView.Adapter<FestivalCategoryRlatedAdapter.MyViewHolder> {

    public FestivalDetailActivity_New festivalActivity;
    public int position = -1;
    public ArrayList<CategoryWiseData> festivalsubCategoryList;
    public a r;
    public int t = 0;
    public int s;

    public FestivalCategoryRlatedAdapter(Context context, ArrayList<CategoryWiseData> storysubCategoryList, a aVar, int i) {
        this.festivalActivity = (FestivalDetailActivity_New) context;
        this.festivalsubCategoryList = storysubCategoryList;
        this.r = aVar;
        this.s = i;
    }

    public interface a {
        void a(int i, int i2);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_festival_frame_list_item, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        CategoryWiseData festivalCategoryWiseData = festivalsubCategoryList.get(position);
        holder.llMain.setCardElevation(t == position ? 5.0f : 0.0f);
        Glide.with(festivalActivity).load(festivalCategoryWiseData.getThemeThumbnail()).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivCategoryThumb);
        holder.ivCategoryThumb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t = position;
                notifyDataSetChanged();
                r.a(position, s);
            }
        });
    }

    @Override
    public int getItemCount() {
        return festivalsubCategoryList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.cardMain)
        public CardView llMain;

        @BindView(R.id.imgBg)
        public ImageView ivCategoryThumb;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}

