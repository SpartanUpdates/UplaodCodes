package com.kotlinz.festivalstorymaker.Utils.a;

import android.app.Activity;
import android.content.Context;
import android.os.Build;

import androidx.appcompat.app.AlertDialog;

import java.util.Date;

public class a {

    public static a g;
    public final Context a;
    public final e b;
    public int c;
    public int d;
    public int e;
    public boolean f;

    public a(final Context context) {
        this.b = new e();
        this.c = 10;
        this.d = 10;
        this.e = 1;
        this.f = false;
        this.a = context.getApplicationContext();
    }

    public static boolean a(final long n, final int n2) {
        return new Date().getTime() - n >= n2 * 24 * 60 * 60 * 1000;
    }

    public static a c(final Context context) {
        if (com.kotlinz.festivalstorymaker.Utils.a.a.g == null) {
            synchronized (a.class) {
                if (com.kotlinz.festivalstorymaker.Utils.a.a.g == null) {
                    com.kotlinz.festivalstorymaker.Utils.a.a.g = new a(context);
                }
            }
        }
        return com.kotlinz.festivalstorymaker.Utils.a.a.g;
    }

    public void b(final Activity activity) {
        if (!activity.isFinishing()) {
            final e b = this.b;
            final int sdk_INT = Build.VERSION.SDK_INT;
            int customLollipopDialogStyle = 0;
            if (sdk_INT == 21 || sdk_INT == 22) {
            }
            final AlertDialog.Builder alertDialog$Builder = new AlertDialog.Builder(activity, customLollipopDialogStyle);
            String message;
            if ((message = b.l) == null) {
                message = activity.getString(b.g);
            }
            alertDialog$Builder.setMessage(message);
            if (b.c) {
                String title;
                if ((title = b.k) == null) {
                    title = activity.getString(b.f);
                }
                alertDialog$Builder.setTitle(title);
            }
            alertDialog$Builder.setCancelable(b.d);
            String s;
            if ((s = b.m) == null) {
                s = activity.getString(b.h);
            }
           /* alertDialog$Builder.setPositiveButton((CharSequence)s, (DialogInterface.OnClickListener)new b(b, (Context)activity, null));
            if (b.a) {
                String s2;
                if ((s2 = b.n) == null) {
                    s2 = ((Context)activity).getString(b.i);
                }
                alertDialog$Builder.setNeutralButton((CharSequence)s2, (DialogInterface.OnClickListener)new c((Context)activity, null));
            }
            if (b.b) {
                String s3;
                if ((s3 = b.o) == null) {
                    s3 = ((Context)activity).getString(b.j);
                }
                alertDialog$Builder.setNegativeButton((CharSequence)s3, (DialogInterface.OnClickListener)new d((Context)activity, null));
            }*/
            alertDialog$Builder.create().show();
        }
    }
}
