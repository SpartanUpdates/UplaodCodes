package com.esc.motivationquotes.activity;

import android.content.Context;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.esc.motivationquotes.Quotes;
import com.esc.motivationquotes.R;
import com.esc.motivationquotes.managers.SettingsManager;
import com.zeugmasolutions.localehelper.LocaleHelperActivityDelegateImpl;
import java.util.Locale;

public class BaseActivity extends AppCompatActivity {
    private LocaleHelperActivityDelegateImpl localeDelegate = Quotes.getLocaleDelegate();

    public void attachBaseContext(Context context) {
        super.attachBaseContext(this.localeDelegate.attachBaseContext(context));
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.localeDelegate.onCreate(this);
    }

    public void onResume() {
        super.onResume();
        this.localeDelegate.onResumed(this);
    }

    public void onPause() {
        super.onPause();
        this.localeDelegate.onPaused();
    }

    public void updateLocale(Locale locale) {
        this.localeDelegate.setLocale(this, locale);
    }
}
