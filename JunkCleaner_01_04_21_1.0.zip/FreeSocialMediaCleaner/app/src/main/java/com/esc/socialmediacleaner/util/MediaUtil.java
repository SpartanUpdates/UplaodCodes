package com.esc.socialmediacleaner.util;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore.Files;
import android.provider.MediaStore.Images.Media;

public class MediaUtil {

    private static final class ImageNotFoundException extends Exception {
        private static final long serialVersionUID = 1;

        private ImageNotFoundException() {
        }

        private ImageNotFoundException(Throwable th) {
            super(th);
        }
    }

    private MediaUtil() {
        throw new UnsupportedOperationException();
    }

    public static String getRealPathFromUri(Context context, Uri uri) {
        Cursor cursor;
        String str = "_data";

        cursor = context.getContentResolver().query(uri, new String[]{str}, null, null, null);
        if (cursor == null) {
            if (cursor != null) {
                cursor.close();
            }
            return null;
        }
        int columnIndexOrThrow = cursor.getColumnIndexOrThrow(str);
        cursor.moveToFirst();
        String string = cursor.getString(columnIndexOrThrow);
        if (cursor != null) {
            cursor.close();
        }
        return string;
    }

    private static int getImageId(Context context, String str) throws ImageNotFoundException {
        String str2 = "_id";
        try {
            Cursor query = context.getContentResolver().query(Media.EXTERNAL_CONTENT_URI, new String[]{str2}, "_data = ?", new String[]{str}, "date_added desc");
            if (query != null) {
                query.moveToFirst();
                if (query.isAfterLast()) {
                    query.close();
                    throw new ImageNotFoundException();
                }
                int i = query.getInt(query.getColumnIndex(str2));
                query.close();
                return i;
            }
            throw new ImageNotFoundException();
        } catch (Exception e) {
            throw new ImageNotFoundException(e);
        }
    }

    public static Uri getUriFromFile(Context context, String str) {
        ContentResolver contentResolver = context.getContentResolver();
        String str2 = "external";
        String str3 = "_id";
        ContentResolver contentResolver2 = contentResolver;
        Cursor query = contentResolver2.query(Files.getContentUri(str2), new String[]{str3}, "_data = ?", new String[]{str}, "date_added desc");
        if (query == null) {
            return null;
        }
        query.moveToFirst();
        if (query.isAfterLast()) {
            query.close();
            ContentValues contentValues = new ContentValues();
            contentValues.put("_data", str);
            return contentResolver.insert(Files.getContentUri(str2), contentValues);
        }
        Uri build = Files.getContentUri(str2).buildUpon().appendPath(Integer.toString(query.getInt(query.getColumnIndex(str3)))).build();
        query.close();
        return build;
    }
}
