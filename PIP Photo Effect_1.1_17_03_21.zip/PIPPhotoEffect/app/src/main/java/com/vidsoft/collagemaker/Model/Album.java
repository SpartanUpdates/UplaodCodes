package com.vidsoft.collagemaker.Model;

public class Album
{
  String count;
  String cover;
  String name;

  public Album(String paramString1, String paramString2, String paramString3)
  {
    this.name = paramString1;
    this.cover = paramString2;
    this.count = paramString3;
  }

  public String getCount()
  {
    return this.count;
  }

  public String getCover()
  {
    return this.cover;
  }

  public String getName()
  {
    return this.name;
  }

  public void setCount(String paramString)
  {
    this.count = paramString;
  }

  public void setCover(String paramString)
  {
    this.cover = paramString;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }
}