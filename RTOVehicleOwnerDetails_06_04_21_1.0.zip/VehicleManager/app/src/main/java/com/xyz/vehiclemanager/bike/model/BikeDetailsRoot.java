package com.xyz.vehiclemanager.bike.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class BikeDetailsRoot
{
    @SerializedName("statusCode")
    public int statusCode;
    @SerializedName("statusMessage")
    public String statusMessage;
    @SerializedName("details")
    public Details details;

    public class Details
    {
        @SerializedName("id")
        public int id;
        @SerializedName("brandId")
        public String brandId;
        @SerializedName("brandName")
        public String brandName;
        @SerializedName("bikeModelName")
        public String bikeModelName;
        @SerializedName("bikeModelSlug")
        public String bikeModelSlug;
        @SerializedName("exShowroomPrice")
        public String exShowroomPrice;
        @SerializedName("imageUrl")
        public String imageUrl;
        @SerializedName("colors")
        public ArrayList<Color> colors;
        @SerializedName("variants")
        public ArrayList<Variant> variants;
        @SerializedName("isDiscontinued")
        public boolean isDiscontinued;
        @SerializedName("isBS6Compliant")
        public boolean isBS6Compliant;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getBrandId() {
            return brandId;
        }

        public void setBrandId(String brandId) {
            this.brandId = brandId;
        }

        public String getBrandName() {
            return brandName;
        }

        public void setBrandName(String brandName) {
            this.brandName = brandName;
        }

        public String getBikeModelName() {
            return bikeModelName;
        }

        public void setBikeModelName(String bikeModelName) {
            this.bikeModelName = bikeModelName;
        }

        public String getBikeModelSlug() {
            return bikeModelSlug;
        }

        public void setBikeModelSlug(String bikeModelSlug) {
            this.bikeModelSlug = bikeModelSlug;
        }

        public String getExShowroomPrice() {
            return exShowroomPrice;
        }

        public void setExShowroomPrice(String exShowroomPrice) {
            this.exShowroomPrice = exShowroomPrice;
        }

        public String getImageUrl() {
            return imageUrl;
        }

        public void setImageUrl(String imageUrl) {
            this.imageUrl = imageUrl;
        }

        public ArrayList<Color> getColors() {
            return colors;
        }

        public void setColors(ArrayList<Color> colors) {
            this.colors = colors;
        }

        public ArrayList<Variant> getVariants() {
            return variants;
        }

        public void setVariants(ArrayList<Variant> variants) {
            this.variants = variants;
        }

        public boolean isDiscontinued() {
            return isDiscontinued;
        }

        public void setDiscontinued(boolean discontinued) {
            isDiscontinued = discontinued;
        }

        public boolean isBS6Compliant() {
            return isBS6Compliant;
        }

        public void setBS6Compliant(boolean BS6Compliant) {
            isBS6Compliant = BS6Compliant;
        }

        public class Color
        {
            @SerializedName("id")
            public int id;
            @SerializedName("colorName")
            public String colorName;
            @SerializedName("backgroundName")
            public String backgroundName;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getColorName() {
                return colorName;
            }

            public void setColorName(String colorName) {
                this.colorName = colorName;
            }

            public String getBackgroundName() {
                return backgroundName;
            }

            public void setBackgroundName(String backgroundName) {
                this.backgroundName = backgroundName;
            }
        }

        public class Variant
        {
            @SerializedName("id")
            public int id;
            @SerializedName("variantName")
            public String variantName;
            @SerializedName("variantSlug")
            public String variantSlug;
            @SerializedName("variantSpecs")
            public String variantSpecs;
            @SerializedName("engineDisplacement")
            public String engineDisplacement;
            @SerializedName("mileage")
            public String mileage;
            @SerializedName("maxPower")
            public String maxPower;
            @SerializedName("kerbWeight")
            public String kerbWeight;
            @SerializedName("variantPrice")
            public String variantPrice;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getVariantName() {
                return variantName;
            }

            public void setVariantName(String variantName) {
                this.variantName = variantName;
            }

            public String getVariantSlug() {
                return variantSlug;
            }

            public void setVariantSlug(String variantSlug) {
                this.variantSlug = variantSlug;
            }

            public String getVariantSpecs() {
                return variantSpecs;
            }

            public void setVariantSpecs(String variantSpecs) {
                this.variantSpecs = variantSpecs;
            }

            public String getEngineDisplacement() {
                return engineDisplacement;
            }

            public void setEngineDisplacement(String engineDisplacement) {
                this.engineDisplacement = engineDisplacement;
            }

            public String getMileage() {
                return mileage;
            }

            public void setMileage(String mileage) {
                this.mileage = mileage;
            }

            public String getMaxPower() {
                return maxPower;
            }

            public void setMaxPower(String maxPower) {
                this.maxPower = maxPower;
            }

            public String getKerbWeight() {
                return kerbWeight;
            }

            public void setKerbWeight(String kerbWeight) {
                this.kerbWeight = kerbWeight;
            }

            public String getVariantPrice() {
                return variantPrice;
            }

            public void setVariantPrice(String variantPrice) {
                this.variantPrice = variantPrice;
            }
        }
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public Details getDetails() {
        return details;
    }

    public void setDetails(Details details) {
        this.details = details;
    }
}

