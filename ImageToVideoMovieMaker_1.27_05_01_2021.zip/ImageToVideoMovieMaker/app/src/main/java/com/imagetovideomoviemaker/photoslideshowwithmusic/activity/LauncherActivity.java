package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.photoslideshowwithmusic.MyApplication;
import com.imagetovideomoviemaker.photoslideshowwithmusic.ProgressBar.kprogresshud.KProgressHUD;
import com.imagetovideomoviemaker.photoslideshowwithmusic.service.CreateVideoService;
import com.imagetovideomoviemaker.photoslideshowwithmusic.service.ImageCreatorService;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.ActivityAnimUtil;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.EPreferences;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.PermissionModelUtil;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;
import com.org.codechimp.apprater.AppRater;
import com.xyz.imagetovideomoviewmaker.R;

import java.util.ArrayList;
import java.util.List;

public class LauncherActivity extends AppCompatActivity implements OnClickListener {
    Activity activity = LauncherActivity.this;
    private static final int RequestPermissionCode = 222;
    static int f37i;
    public static LauncherActivity MainActivity;
    ComponentName SecurityComponentName = null;
    private DrawerLayout drawerLayout;
    EPreferences ePref;
    PermissionModelUtil modelUtil;
    View view;
    public KProgressHUD hud;
    //    private Dialog dialogAd;
    Toolbar toolbar;
    TextView tvToolbarTitle;

    private NativeBannerAd nativeBannerAd;


    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (isVideoInprocess()) {
            startActivity(new Intent(this, ProgressActivity.class));
            overridePendingTransition(0, 0);
            finish();
            return;
        }
        setContentView(R.layout.activity_home_main);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "LauncherActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        ePref = EPreferences.getInstance(this);
        setActionBar();
        init();
        addListener();
        LoadNativeAds();
        MyApplication.getInstance().setAutostartAppName();
        if (MyApplication.getInstance().runApp(Utils.autostart_app_name, 0) && !this.check_permission()) {
            this.permissionDialog();
        }
        AppRater.setPackageName(this.getPackageName());
        AppRater.app_launched(this);
    }

//    private void setAdDialog() {
//        dialogAd = new Dialog(LauncherActivity.this);
//        dialogAd.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialogAd.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
//        dialogAd.getWindow().setGravity(Gravity.CENTER);
//        dialogAd.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
//        dialogAd.setContentView(R.layout.dialog_layout_ads);
//        dialogAd.setCanceledOnTouchOutside(false);
//    }


    public boolean check_permission() {
        return this.ePref.getBoolean("HasAutoStartPermission", false);
    }


    private void permissionDialog() {
        String str = Build.MANUFACTURER;
        if (str.equals("Xiaomi")) {
            SecurityComponentName = new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity");
            Utils.autostart_app_name = "Security";
        } else if (str.equals("asus")) {
            SecurityComponentName = new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity");
            Utils.autostart_app_name = "Auto-start Manager";
        }
        Intent intent = new Intent(this, CustomPermissionActivity.class);
        intent.putExtra("PACKAGE", this.SecurityComponentName);
        intent.putExtra("APPNAME", Utils.autostart_app_name);
        startActivity(intent);
    }


    private boolean isVideoInprocess() {
        return MyApplication.isMyServiceRunning(this, CreateVideoService.class) || MyApplication.isMyServiceRunning(this, ImageCreatorService.class);
    }

    private void init() {
        MainActivity = this;
        Utils.isVideoCreationRunning = true;
        if (Utils.checkPermission(this)) {
            MyApplication.getInstance().getFolderList();
        } else {
            Utils.requestPermission(this);
        }
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(307);
    }

    protected void onResume() {
        super.onResume();
        if (f37i == 1) {
            f37i = 0;
            if (Utils.checkPermission(this)) {
                onStart();
            } else {
                Utils.requestPermission(this);
            }
        }
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int n, @NonNull final String[] array, @NonNull final int[] array2) {
        if (n != 222) {
            return;
        }
        if (array2.length > 0) {
            boolean b = false;
            if (array2[0] == 0) {
                n = 1;
            } else {
                n = 0;
            }
            if (array2[1] == 0) {
                b = true;
            }
            if (n != 0 && b) {
                MyApplication.getInstance().getFolderList();
                return;
            }
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.READ_EXTERNAL_STORAGE") && !ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
                Utils.permissionDailog(this);
                return;
            }
            Utils.requestPermission(this);
        }
    }

    private void addListener() {
        findViewById(R.id.btnCreateVideo).setOnClickListener(this);
        findViewById(R.id.btnViewVideo).setOnClickListener(this);
        findViewById(R.id.btnChangeLang).setOnClickListener(this);
        findViewById(R.id.ivRateUs).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    startActivity(new Intent("android.intent.action.VIEW", Uri
                            .parse("market://details?id=" + getApplicationContext().getPackageName())));
                } catch (ActivityNotFoundException ex) {
                    startActivity(new Intent("android.intent.action.VIEW", Uri
                            .parse("http://play.google.com/store/apps/details?id="
                                    + getApplicationContext().getPackageName())));
                }
            }
        });
        findViewById(R.id.ivshare).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ShareAPP();
            }
        });
       /* findViewById(R.id.iv_feedback).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Feedback();
            }
        });*/
        findViewById(R.id.ivprivacy_policy).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
              /* MyApplication.id = 102;
                MyApplication.activityContext = LauncherActivity.this;
                MyApplication.view = view;
                ShowInterstitial();*/
                Intent intent1 = new Intent(Intent.ACTION_VIEW);
                intent1.setData(Uri.parse("https://sites.google.com/site/slideshowsolutionpolicy/home"));
                startActivity(intent1);
            }
        });

    }


    private void ShareAPP() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Wavy Music");
            String shareMessage = "\nGet free Image To Video Movie Maker at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void Feedback() {
        Intent intent2 = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", getResources().getString(R.string.feedback_email), null));
        intent2.putExtra("android.intent.extra.SUBJECT", "Feedback");
        intent2.putExtra("android.intent.extra.TEXT", "Write your feedback here");
        startActivity(Intent.createChooser(intent2, "Send email..."));
    }


    public void ShowInterstitial2() {
        if (MyApplication.interstitialAd2 != null) {
            if (MyApplication.interstitialAd2.isAdLoaded()) {
//                dialogAd.show();
                AdsDialogShow(2);
            } else {
                MyApplication.loadInterstitialNew2(LauncherActivity.this);
                switch (MyApplication.id) {
                    case 100:
                        ActivityAnimUtil.startActivitySafely(MyApplication.view, new Intent(this, VideoAlbumActivity.class));
                        break;
                    case 101:
                        ActivityAnimUtil.startActivitySafely(MyApplication.view, new Intent(this, ImageSelectionActivity.class));
                        break;
                    case 102:
                        Intent intent1 = new Intent(Intent.ACTION_VIEW);
                        intent1.setData(Uri.parse("https://sites.google.com/site/slideshowsolutionpolicy/home"));
                        startActivity(intent1);
                        break;
                }

            }
        } else {
            MyApplication.loadInterstitialAd2(LauncherActivity.this);
            switch (MyApplication.id) {
                case 100:
                    ActivityAnimUtil.startActivitySafely(MyApplication.view, new Intent(this, VideoAlbumActivity.class));
                    break;
                case 101:
                    ActivityAnimUtil.startActivitySafely(MyApplication.view, new Intent(this, ImageSelectionActivity.class));
                    break;
                case 102:
                    Intent intent1 = new Intent(Intent.ACTION_VIEW);
                    intent1.setData(Uri.parse("https://sites.google.com/site/slideshowsolutionpolicy/home"));
                    startActivity(intent1);
                    break;
            }
        }
    }

    public void ShowInterstitial() {
        if (MyApplication.interstitialAd != null) {
            if (MyApplication.interstitialAd.isAdLoaded()) {
//                dialogAd.show();
                AdsDialogShow(1);
            } else {
                MyApplication.loadInterstitialNew(LauncherActivity.this);
                ShowInterstitial2();
            }
        } else {
            MyApplication.loadInterstitialAd(LauncherActivity.this);
            ShowInterstitial2();
        }
    }


    public void onClick(View view) {
        this.view = view;
        int id = view.getId();
        if (id != R.id.btnChangeLang) {
            if (id != R.id.btnCreateVideo) {
                if (id == R.id.btnViewVideo) {
                    if (Utils.checkPermission(this)) {
                        MyApplication.id = 100;
                        MyApplication.activityContext = LauncherActivity.this;
                        MyApplication.view = view;
                        ShowInterstitial();
                    }
                    Utils.requestPermission(this);
                }
            } else if (Utils.checkPermission(this)) {
                init();
                MyApplication.id = 101;
                MyApplication.view = view;
                MyApplication.activityContext = LauncherActivity.this;
                MyApplication.getInstance().getFolderList();
                if (MyApplication.getInstance().getAllFolder().size() > 0) {
                    MyApplication.isStoryAdded = false;
                    MyApplication.isBreak = false;
                    MyApplication.getInstance().setMusicData(null);
                    ShowInterstitial();
                    return;
                } else {
                    Toast.makeText(getApplicationContext(), R.string.no_images_found_in_device_please_add_images_in_sdcard, Toast.LENGTH_SHORT).show();
                }
            } else {
                Utils.requestPermission(this);
            }
        } else if (Utils.checkPermission(this)) {
            loadLanguage(view);
        } else {
            this.modelUtil.showPermissionExplanationThenAuthorization();
        }
    }

    private void loadLanguage(View view) {
        ActivityAnimUtil.startActivitySafely(view, new Intent(this, LanguageActivity.class));
    }

    private void AdsDialogShow(final int ads) {
//        final Handler handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                dialogAd.dismiss();
//                if (ads == 2) {
//                    MyApplication.interstitialAd2.show();
//                } else {
//                    MyApplication.interstitialAd.show();
//                }
//            }
//        }, 2000L);
        try {
            hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    hud.dismiss();
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();

                } catch (NullPointerException e2) {
                    e2.printStackTrace();
                } catch (Exception e3) {
                    e3.printStackTrace();
                }
                if (ads == 2) {
                    MyApplication.interstitialAd2.show();
                } else {
                    MyApplication.interstitialAd.show();
                }
            }
        }, 2000);
    }

    public void onBackPressed() {
        if (this.ePref.getBoolean("pref_key_rate", false)) {
            BackDialog();
        } else {
            RateDialog();
        }
    }


    @SuppressLint("ClickableViewAccessibility")
    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(LauncherActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        TextView tvMessage;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        nativeBannerAd = new NativeBannerAd(this, getString(R.string.fb_nativeBanner));
        nativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = dialog.findViewById(R.id.banner_container);
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        nativeBannerAd.loadAd();
        tvMessage = dialog.findViewById(R.id.tvPro);
        Utils.setFont(activity, tvMessage);
        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);

        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePref.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    finishAffinity();
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    private void LoadNativeAds() {
        nativeBannerAd = new NativeBannerAd(this, getString(R.string.fb_nativeBanner));
        nativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e("TAG", "onError" + adError.getErrorMessage());

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = findViewById(R.id.banner_container);
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        nativeBannerAd.loadAd();
    }


    public void BackDialog() {
        final Dialog dialog = new Dialog(LauncherActivity.this);
        TextView tvMessage;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_back);
        dialog.setCanceledOnTouchOutside(false);
        nativeBannerAd = new NativeBannerAd(this, getString(R.string.fb_nativeBanner));
        nativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = dialog.findViewById(R.id.banner_container);
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        nativeBannerAd.loadAd();
        tvMessage = dialog.findViewById(R.id.tvPro);
        Utils.setFont(activity, tvMessage);
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.show();
    }

    private void setActionBar() {
        toolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.toolbar_title);
        tvToolbarTitle.setText(getString(R.string.app_name));
        Utils.setFont(activity, tvToolbarTitle);
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }


}
