package com.example.womenabsworkout.activities;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import com.example.womenabsworkout.R;
import com.example.womenabsworkout.utils.CustomSeekBar;
import com.example.womenabsworkout.utils.ProgressItem;

public class CalculateActivity extends Activity {
    public float Heightincms = 0.0f;

    public double bmiblueSpan = 4.0d;
    public double bmigreenSpan = 7.0d;
    public float bmiorangeSpan = 10.0f;
    public float bmiredSpan;
    public CustomSeekBar bmiseekBar;
    public float bmitotalSpan = 50.0f;
    public float bmivioletSpan = 15.0f;
    public float bmiyellowSpan = 5.0f;
    public RadioButton female;
    public EditText ft;
    public TextView height_desc;
    public double heightblueSpan = 16.0d;
    public double heightgreenSpan = 8.0d;
    public float heightorangeSpan = 7.0f;
    public float heightredSpan;
    public CustomSeekBar heightseekBar;
    public float heighttotalSpan = 213.0f;
    public float heightvioletSpan = 135.0f;
    public float heightyellowSpan = 12.0f;
    public TextView hght2;
    public TextView hght4;
    public EditText inches;
    public RadioButton kg;
    public RadioButton lbs;
    public ProgressItem mProgressItem;
    public SharedPreferences mSharedPreferences;
    public RadioButton male;
    public Editor prefsEditor;
    public ArrayList<ProgressItem> progressItemList;
    public EditText weight;
    public TextView wght2;
    public TextView wght4;
    public EditText year;

    private float calculateHeightinCentimeter(float f) {
        return (float) ((int) (f * 100.0f));
    }

    public int calculateBMI(float f, float f2) {
        return (int) (f2 / (f * f));
    }

    public void imageclick(View view) {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.layout_calculate);
        ((ImageView) findViewById(R.id.back_arrow)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CalculateActivity.this.onBackPressed();
            }
        });
        this.bmiseekBar = (CustomSeekBar) findViewById(R.id.bmiseekBar);
        this.heightseekBar = (CustomSeekBar) findViewById(R.id.heightseekBar);
        this.wght2 = (TextView) findViewById(R.id.wght2);
        this.wght4 = (TextView) findViewById(R.id.wght4);
        this.hght2 = (TextView) findViewById(R.id.hght2);
        this.hght4 = (TextView) findViewById(R.id.hght4);
        //this.height_desc = (TextView) findViewById(R.id.height_desc);
        initDataToSeekbar();
        this.mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        findViewById(R.id.edit).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CalculateActivity.this.a();
            }
        });
        findViewById(R.id.startexercise).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CalculateActivity.this.startActivity(new Intent(CalculateActivity.this.getApplicationContext(), MainActivity.class));
                CalculateActivity.this.finish();
            }
        });
    }

    public float calculateMetres(float f, float f2) {
        double d = (double) (f + (f2 / 12.0f));
        Double.isNaN(d);
        f = (float) (d / 3.28d);
        this.Heightincms = calculateHeightinCentimeter(f);
        return f;
    }

    public float calculateweight(float f) {
        if (!this.lbs.isChecked()) {
            return f;
        }
        double d = (double) f;
        Double.isNaN(d);
        return (float) (d * 0.453592d);
    }

    private void initDataToSeekbar() {
        TextView textView;
        CharSequence charSequence;
        double d;
        double d2;
        this.heightseekBar.setEnabled(true);
        this.bmiseekBar.setEnabled(true);
        this.progressItemList = new ArrayList();
        ProgressItem progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.bmivioletSpan / this.bmitotalSpan) * 100.0f;
        progressItem.color = R.color.violet;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        double d3 = this.bmiblueSpan;
        double d4 = (double) this.bmitotalSpan;
        Double.isNaN(d4);
        progressItem.progressItemPercentage = ((float) (d3 / d4)) * 100.0f;
        progressItem.color = R.color.blue;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        double d5 = this.bmigreenSpan;
        double d6 = (double) this.bmitotalSpan;
        Double.isNaN(d6);
        progressItem.progressItemPercentage = ((float) (d5 / d6)) * 100.0f;
        progressItem.color = R.color.green;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.bmiyellowSpan / this.bmitotalSpan) * 100.0f;
        progressItem.color = R.color.yellow;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.bmiorangeSpan / this.bmitotalSpan) * 100.0f;
        progressItem.color = R.color.orange;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.bmiredSpan / this.bmitotalSpan) * 100.0f;
        progressItem.color = R.color.red;
        this.progressItemList.add(progressItem);
        this.bmiseekBar.initData(this.progressItemList);
        float floatExtra = getIntent().getFloatExtra("BMI", 0.0f);
        this.bmiseekBar.setProgress((int) floatExtra);
        this.wght4.setText(String.valueOf(floatExtra));
        String str = "Extra Long Height";
        String str2 = "HEIGHT";
        if (floatExtra >= 0.0f && floatExtra <= 15.0f) {
            textView = this.wght2;
            charSequence = "Severely Underweight";
        } else if (floatExtra >= 16.0f && floatExtra <= 18.0f) {
            textView = this.wght2;
            charSequence = "Underweight";
        } else if (floatExtra >= 19.0f && floatExtra <= 25.0f) {
            textView = this.wght2;
            charSequence = "Normal (Healthy Weight)";
        } else if (floatExtra >= 26.0f && floatExtra <= 30.0f) {
            textView = this.wght2;
            charSequence = "Overweight";
        } else if (floatExtra < 31.0f || floatExtra > 40.0f) {
            String str3;
            TextView textView2;
            Resources resources;
            int i = 0;
            boolean z;
            int i2;
            if (floatExtra < 41.0f || floatExtra > 50.0f) {
                textView = null;
                str3 = null;
            } else {
                textView = this.wght2;
                str3 = "Severely Obese";
            }
            this.bmiseekBar.invalidate();
            this.progressItemList = new ArrayList();
            ProgressItem progressItem2 = new ProgressItem();
            this.mProgressItem = progressItem2;
            progressItem2.progressItemPercentage = (this.heightvioletSpan / this.heighttotalSpan) * 100.0f;
            progressItem2.color = R.color.violet;
            this.progressItemList.add(progressItem2);
            ProgressItem progressItem3 = new ProgressItem();
            this.mProgressItem = progressItem3;
            d = this.heightblueSpan;
            String str4 = str3;
            d2 = (double) this.heighttotalSpan;
            Double.isNaN(d2);
            progressItem3.progressItemPercentage = ((float) (d / d2)) * 100.0f;
            progressItem3.color = R.color.blue;
            this.progressItemList.add(progressItem3);
            ProgressItem progressItem4 = new ProgressItem();
            this.mProgressItem = progressItem4;
            d2 = this.heightgreenSpan;
            d = (double) this.heighttotalSpan;
            Double.isNaN(d);
            progressItem4.progressItemPercentage = ((float) (d2 / d)) * 100.0f;
            progressItem4.color = R.color.green;
            this.progressItemList.add(progressItem4);
            progressItem4 = new ProgressItem();
            this.mProgressItem = progressItem4;
            progressItem4.progressItemPercentage = (this.heightyellowSpan / this.heighttotalSpan) * 100.0f;
            progressItem4.color = R.color.yellow;
            this.progressItemList.add(progressItem4);
            progressItem4 = new ProgressItem();
            this.mProgressItem = progressItem4;
            progressItem4.progressItemPercentage = (this.heightorangeSpan / this.heighttotalSpan) * 100.0f;
            progressItem4.color = R.color.orange;
            this.progressItemList.add(progressItem4);
            progressItem4 = new ProgressItem();
            this.mProgressItem = progressItem4;
            progressItem4.progressItemPercentage = (this.heightredSpan / this.heighttotalSpan) * 100.0f;
            progressItem4.color = R.color.red;
            this.progressItemList.add(progressItem4);
            this.heightseekBar.initData(this.progressItemList);
            float floatExtra2 = getIntent().getFloatExtra(str2, 0.0f);
            this.heightseekBar.setProgress((int) floatExtra2);
            this.hght4.setText(String.valueOf(floatExtra2));
            if (floatExtra2 < 0.0f && floatExtra2 <= 135.0f) {
                this.hght2.setText("Very Short Height");
                textView2 = this.height_desc;
                resources = getResources();
                i = R.string.veryshortheight;
            } else if (floatExtra2 < 136.0f && floatExtra2 <= 150.0f) {
                this.hght2.setText("Too Short Height");
                textView2 = this.height_desc;
                resources = getResources();
                i = R.string.tooshortheight;
            } else if (floatExtra2 < 151.0f && floatExtra2 <= 158.0f) {
                this.hght2.setText("Below Average Height");
                textView2 = this.height_desc;
                resources = getResources();
                i = R.string.belowaveraheheight;
            } else if (floatExtra2 < 159.0f && floatExtra2 <= 170.0f) {
                this.hght2.setText("Average Height");
                textView2 = this.height_desc;
                resources = getResources();
                i = R.string.avgheight;
            } else if (floatExtra2 >= 171.0f || floatExtra2 > 178.0f) {
                int i3;
                TextView textView3;
                Resources resources2;
                if (floatExtra2 < 179.0f || floatExtra2 > 213.0f) {
                    i3 = 0;
                    textView3 = null;
                    resources2 = null;
                } else {
                    this.hght2.setText(str);
                    textView3 = this.height_desc;
                    resources2 = getResources();
                    i3 = R.string.extlongheight;
                }
                this.heightseekBar.invalidate();
                z = false;
                this.heightseekBar.setEnabled(false);
                this.bmiseekBar.setEnabled(false);
                i2 = i3;
                textView2 = textView3;
                resources = resources2;
                textView2.setText(resources.getString(i2));
                this.heightseekBar.invalidate();
                this.heightseekBar.setEnabled(z);
                this.bmiseekBar.setEnabled(z);
                charSequence = str4;
            } else {
                this.hght2.setText("Above Average Height");
                textView2 = this.height_desc;
                resources = getResources();
                i = R.string.abvavgheight;
            }
            i2 = i;
            z = false;
            textView2.setText(resources.getString(i2));
            this.heightseekBar.invalidate();
            this.heightseekBar.setEnabled(z);
            this.bmiseekBar.setEnabled(z);
            charSequence = str4;
        } else {
            textView = this.wght2;
            charSequence = "Obese";
        }
        textView.setText(charSequence);
        this.bmiseekBar.invalidate();
        this.progressItemList = new ArrayList();
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.heightvioletSpan / this.heighttotalSpan) * 100.0f;
        progressItem.color = R.color.violet;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        d2 = this.heightblueSpan;
        d = (double) this.heighttotalSpan;
        Double.isNaN(d);
        progressItem.progressItemPercentage = ((float) (d2 / d)) * 100.0f;
        progressItem.color = R.color.blue;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        d2 = this.heightgreenSpan;
        d = (double) this.heighttotalSpan;
        Double.isNaN(d);
        progressItem.progressItemPercentage = ((float) (d2 / d)) * 100.0f;
        progressItem.color = R.color.green;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.heightyellowSpan / this.heighttotalSpan) * 100.0f;
        progressItem.color = R.color.yellow;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.heightorangeSpan / this.heighttotalSpan) * 100.0f;
        progressItem.color = R.color.orange;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.heightredSpan / this.heighttotalSpan) * 100.0f;
        progressItem.color = R.color.red;
        this.progressItemList.add(progressItem);
        this.heightseekBar.initData(this.progressItemList);
        floatExtra = getIntent().getFloatExtra(str2, 0.0f);
        this.heightseekBar.setProgress((int) floatExtra);
        this.hght4.setText(String.valueOf(floatExtra));
        this.hght2.setText(str);
//        this.height_desc.setText(getResources().getString(R.string.extlongheight));
        this.heightseekBar.invalidate();
        this.heightseekBar.setEnabled(false);
        this.bmiseekBar.setEnabled(false);
    }

    public void initDataToSeekbar(float f, float f2) {
        TextView textView;
        CharSequence charSequence;
        double d;
        double d2;
        float f3 = f;
        float f4 = f2;
        this.heightseekBar.setEnabled(true);
        this.bmiseekBar.setEnabled(true);
        this.progressItemList = new ArrayList();
        ProgressItem progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.bmivioletSpan / this.bmitotalSpan) * 100.0f;
        progressItem.color = R.color.violet;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        double d3 = this.bmiblueSpan;
        double d4 = (double) this.bmitotalSpan;
        Double.isNaN(d4);
        progressItem.progressItemPercentage = ((float) (d3 / d4)) * 100.0f;
        progressItem.color = R.color.blue;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        double d5 = this.bmigreenSpan;
        double d6 = (double) this.bmitotalSpan;
        Double.isNaN(d6);
        progressItem.progressItemPercentage = ((float) (d5 / d6)) * 100.0f;
        progressItem.color = R.color.green;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.bmiyellowSpan / this.bmitotalSpan) * 100.0f;
        progressItem.color = R.color.yellow;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.bmiorangeSpan / this.bmitotalSpan) * 100.0f;
        progressItem.color = R.color.orange;
        this.progressItemList.add(progressItem);
        progressItem = new ProgressItem();
        this.mProgressItem = progressItem;
        progressItem.progressItemPercentage = (this.bmiredSpan / this.bmitotalSpan) * 100.0f;
        progressItem.color = R.color.red;
        this.progressItemList.add(progressItem);
        this.bmiseekBar.initData(this.progressItemList);
        this.bmiseekBar.setProgress((int) f3);
        this.wght4.setText(String.valueOf(f));
        String str = "Extra Long Height";
        if (f3 >= 0.0f && f3 <= 15.0f) {
            textView = this.wght2;
            charSequence = "Severely Underweight";
        } else if (f3 >= 16.0f && f3 <= 18.0f) {
            textView = this.wght2;
            charSequence = "Underweight";
        } else if (f3 >= 19.0f && f3 <= 25.0f) {
            textView = this.wght2;
            charSequence = "Normal (Healthy Weight)";
        } else if (f3 >= 26.0f && f3 <= 30.0f) {
            textView = this.wght2;
            charSequence = "Overweight";
        } else if (f3 < 31.0f || f3 > 40.0f) {
            String str2;
            TextView textView2;
            Resources resources;
            int i = 0;
            boolean z;
            int i2;
            if (f3 < 41.0f || f3 > 50.0f) {
                textView = null;
                str2 = null;
            } else {
                textView = this.wght2;
                str2 = "Severely Obese";
            }
            this.bmiseekBar.invalidate();
            this.progressItemList = new ArrayList();
            ProgressItem progressItem2 = new ProgressItem();
            this.mProgressItem = progressItem2;
            progressItem2.progressItemPercentage = (this.heightvioletSpan / this.heighttotalSpan) * 100.0f;
            progressItem2.color = R.color.violet;
            this.progressItemList.add(progressItem2);
            ProgressItem progressItem3 = new ProgressItem();
            this.mProgressItem = progressItem3;
            double d7 = this.heightblueSpan;
            d = (double) this.heighttotalSpan;
            Double.isNaN(d);
            progressItem3.progressItemPercentage = ((float) (d7 / d)) * 100.0f;
            progressItem3.color = R.color.blue;
            this.progressItemList.add(progressItem3);
            progressItem = new ProgressItem();
            this.mProgressItem = progressItem;
            d7 = this.heightgreenSpan;
            String str3 = str2;
            d2 = (double) this.heighttotalSpan;
            Double.isNaN(d2);
            progressItem.progressItemPercentage = ((float) (d7 / d2)) * 100.0f;
            progressItem.color = R.color.green;
            this.progressItemList.add(progressItem);
            progressItem = new ProgressItem();
            this.mProgressItem = progressItem;
            progressItem.progressItemPercentage = (this.heightyellowSpan / this.heighttotalSpan) * 100.0f;
            progressItem.color = R.color.yellow;
            this.progressItemList.add(progressItem);
            progressItem = new ProgressItem();
            this.mProgressItem = progressItem;
            progressItem.progressItemPercentage = (this.heightorangeSpan / this.heighttotalSpan) * 100.0f;
            progressItem.color = R.color.orange;
            this.progressItemList.add(progressItem);
            progressItem = new ProgressItem();
            this.mProgressItem = progressItem;
            progressItem.progressItemPercentage = (this.heightredSpan / this.heighttotalSpan) * 100.0f;
            progressItem.color = R.color.red;
            this.progressItemList.add(progressItem);
            this.heightseekBar.initData(this.progressItemList);
            this.heightseekBar.setProgress((int) f4);
            this.hght4.setText(String.valueOf(f2));
            if (f4 < 0.0f && f4 <= 135.0f) {
                this.hght2.setText("Very Short Height");
                textView2 = this.height_desc;
                resources = getResources();
                i = R.string.veryshortheight;
            } else if (f4 < 136.0f && f4 <= 150.0f) {
                this.hght2.setText("Too Short Height");
                textView2 = this.height_desc;
                resources = getResources();
                i = R.string.tooshortheight;
            } else if (f4 < 151.0f && f4 <= 158.0f) {
                this.hght2.setText("Below Average Height");
                textView2 = this.height_desc;
                resources = getResources();
                i = R.string.belowaveraheheight;
            } else if (f4 < 159.0f && f4 <= 170.0f) {
                this.hght2.setText("Average Height");
                textView2 = this.height_desc;
                resources = getResources();
                i = R.string.avgheight;
            } else if (f4 >= 171.0f || f4 > 178.0f) {
                int i3;
                TextView textView3;
                Resources resources2;
                if (f4 < 179.0f || f4 > 213.0f) {
                    i3 = 0;
                    textView3 = null;
                    resources2 = null;
                } else {
                    this.hght2.setText(str);
                    textView3 = this.height_desc;
                    resources2 = getResources();
                    i3 = R.string.extlongheight;
                }
                this.heightseekBar.invalidate();
                z = false;
                this.heightseekBar.setEnabled(false);
                this.bmiseekBar.setEnabled(false);
                i2 = i3;
                textView2 = textView3;
                resources = resources2;
                textView2.setText(resources.getString(i2));
                this.heightseekBar.invalidate();
                this.heightseekBar.setEnabled(z);
                this.bmiseekBar.setEnabled(z);
                charSequence = str3;
            } else {
                this.hght2.setText("Above Average Height");
                textView2 = this.height_desc;
                resources = getResources();
                i = R.string.abvavgheight;
            }
            i2 = i;
            z = false;
            textView2.setText(resources.getString(i2));
            this.heightseekBar.invalidate();
            this.heightseekBar.setEnabled(z);
            this.bmiseekBar.setEnabled(z);
            charSequence = str3;
        } else {
            textView = this.wght2;
            charSequence = "Obese";
        }
        textView.setText(charSequence);
        this.bmiseekBar.invalidate();
        this.progressItemList = new ArrayList();
        ProgressItem progressItem4 = new ProgressItem();
        this.mProgressItem = progressItem4;
        progressItem4.progressItemPercentage = (this.heightvioletSpan / this.heighttotalSpan) * 100.0f;
        progressItem4.color = R.color.violet;
        this.progressItemList.add(progressItem4);
        progressItem4 = new ProgressItem();
        this.mProgressItem = progressItem4;
        d = this.heightblueSpan;
        d2 = (double) this.heighttotalSpan;
        Double.isNaN(d2);
        progressItem4.progressItemPercentage = ((float) (d / d2)) * 100.0f;
        progressItem4.color = R.color.blue;
        this.progressItemList.add(progressItem4);
        progressItem4 = new ProgressItem();
        this.mProgressItem = progressItem4;
        d = this.heightgreenSpan;
        d2 = (double) this.heighttotalSpan;
        Double.isNaN(d2);
        progressItem4.progressItemPercentage = ((float) (d / d2)) * 100.0f;
        progressItem4.color = R.color.green;
        this.progressItemList.add(progressItem4);
        progressItem4 = new ProgressItem();
        this.mProgressItem = progressItem4;
        progressItem4.progressItemPercentage = (this.heightyellowSpan / this.heighttotalSpan) * 100.0f;
        progressItem4.color = R.color.yellow;
        this.progressItemList.add(progressItem4);
        progressItem4 = new ProgressItem();
        this.mProgressItem = progressItem4;
        progressItem4.progressItemPercentage = (this.heightorangeSpan / this.heighttotalSpan) * 100.0f;
        progressItem4.color = R.color.orange;
        this.progressItemList.add(progressItem4);
        progressItem4 = new ProgressItem();
        this.mProgressItem = progressItem4;
        progressItem4.progressItemPercentage = (this.heightredSpan / this.heighttotalSpan) * 100.0f;
        progressItem4.color = R.color.red;
        this.progressItemList.add(progressItem4);
        this.heightseekBar.initData(this.progressItemList);
        this.heightseekBar.setProgress((int) f4);
        this.hght4.setText(String.valueOf(f2));
        this.hght2.setText(str);
        this.height_desc.setText(getResources().getString(R.string.extlongheight));
        this.heightseekBar.invalidate();
        this.heightseekBar.setEnabled(false);
        this.bmiseekBar.setEnabled(false);
    }


    public void a() {
        final Dialog dialog = new Dialog(this, R.style.AppTheme);
        dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        dialog.getWindow().setLayout(-1, -1);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setFlags(1024, 1024);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setContentView(R.layout.activity_customdialog_heightcheckout);
        dialog.setCancelable(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.setCancelable(true);
        this.lbs = (RadioButton) dialog.findViewById(R.id.lbs);
        this.kg = (RadioButton) dialog.findViewById(R.id.kg);
        this.male = (RadioButton) dialog.findViewById(R.id.male);
        this.female = (RadioButton) dialog.findViewById(R.id.female);
        this.ft = (EditText) dialog.findViewById(R.id.feet);
        this.inches = (EditText) dialog.findViewById(R.id.inches);
        this.year = (EditText) dialog.findViewById(R.id.year);
        this.weight = (EditText) dialog.findViewById(R.id.weight);
        ((TextView) dialog.findViewById(R.id.calculate)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CharSequence charSequence;
                String str = "";
                if (CalculateActivity.this.year.getText().toString().equals(str) || CalculateActivity.this.ft.getText().toString().equals(str) || CalculateActivity.this.inches.getText().toString().equals(str) || CalculateActivity.this.weight.getText().toString().equals(str)) {
                    charSequence = "Please fill all the fields";
                } else if (Integer.parseInt(CalculateActivity.this.year.getText().toString()) < 5 || Integer.parseInt(CalculateActivity.this.year.getText().toString()) > 100) {
                    charSequence = "Age should be in range 5-100 years";
                } else if (Integer.parseInt(CalculateActivity.this.ft.getText().toString()) < 2 || Integer.parseInt(CalculateActivity.this.ft.getText().toString()) > 7) {
                    charSequence = "Feet should be in range 2-7";
                } else if (Integer.parseInt(CalculateActivity.this.inches.getText().toString()) < 0 || Integer.parseInt(CalculateActivity.this.inches.getText().toString()) > 12) {
                    charSequence = "Inches should be in range 0-12";
                } else {
                    String str2 = "HEIGHT";
                    String str3 = "BMI";
                    CalculateActivity calculateActivity;
                    float calculateMetres;
                    CalculateActivity calculateActivity2;
                    int calculateBMI;
                    CalculateActivity calculateActivity3;
                    if (CalculateActivity.this.kg.isChecked()) {
                        if (Integer.parseInt(CalculateActivity.this.weight.getText().toString()) >= 5 && Integer.parseInt(CalculateActivity.this.weight.getText().toString()) <= 100) {
                            calculateActivity = CalculateActivity.this;
                            calculateMetres = calculateActivity.calculateMetres(Float.parseFloat(calculateActivity.ft.getText().toString()), Float.parseFloat(CalculateActivity.this.inches.getText().toString()));
                            calculateActivity2 = CalculateActivity.this;
                            calculateBMI = calculateActivity2.calculateBMI(calculateMetres, calculateActivity2.calculateweight(Float.parseFloat(calculateActivity2.weight.getText().toString())));
                            calculateActivity2 = CalculateActivity.this;
                            calculateActivity2.prefsEditor = calculateActivity2.mSharedPreferences.edit();
                            calculateMetres = (float) calculateBMI;
                            CalculateActivity.this.prefsEditor.putFloat(str3, calculateMetres);
                            CalculateActivity.this.prefsEditor.putFloat(str2, CalculateActivity.this.Heightincms);
                            CalculateActivity.this.prefsEditor.apply();
                            calculateActivity3 = CalculateActivity.this;
                            calculateActivity3.initDataToSeekbar(calculateMetres, calculateActivity3.Heightincms);
                            dialog.dismiss();

                        }
                    } else if (!CalculateActivity.this.lbs.isChecked()) {
                        return;
                    } else {
                        if (Integer.parseInt(CalculateActivity.this.weight.getText().toString()) >= 11 && Integer.parseInt(CalculateActivity.this.weight.getText().toString()) <= 220) {
                            calculateActivity = CalculateActivity.this;
                            calculateMetres = calculateActivity.calculateMetres(Float.parseFloat(calculateActivity.ft.getText().toString()), Float.parseFloat(CalculateActivity.this.inches.getText().toString()));
                            calculateActivity2 = CalculateActivity.this;
                            calculateBMI = calculateActivity2.calculateBMI(calculateMetres, calculateActivity2.calculateweight(Float.parseFloat(calculateActivity2.weight.getText().toString())));
                            calculateActivity2 = CalculateActivity.this;
                            calculateActivity2.prefsEditor = calculateActivity2.mSharedPreferences.edit();
                            calculateMetres = (float) calculateBMI;
                            CalculateActivity.this.prefsEditor.putFloat(str3, calculateMetres);
                            CalculateActivity.this.prefsEditor.putFloat(str2, CalculateActivity.this.Heightincms);
                            CalculateActivity.this.prefsEditor.apply();
                            calculateActivity3 = CalculateActivity.this;
                            calculateActivity3.initDataToSeekbar(calculateMetres, calculateActivity3.Heightincms);
                            dialog.dismiss();

                        }
                    }
                    return;
                }
                Toast.makeText(CalculateActivity.this.getApplicationContext(), charSequence, Toast.LENGTH_SHORT).show();
            }
        });
        dialog.show();
    }

    public void onBackPressed() {
        startActivity(new Intent(this, After_Main_Activity.class));
        finish();
    }
}
