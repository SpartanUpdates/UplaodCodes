package com.kotlinz.videostatusmaker.Utils.gridview;

import android.content.*;
import java.util.*;

public abstract class BaseDynamicGridAdapter extends AbstractDynamicGridAdapter
{
  private int mColumnCount;
  private Context mContext;
  private ArrayList<Object> mItems;

  protected BaseDynamicGridAdapter(final Context mContext, final int mColumnCount) {
    this.mItems = new ArrayList<Object>();
    this.mContext = mContext;
    this.mColumnCount = mColumnCount;
  }

  public BaseDynamicGridAdapter(final Context mContext, final List<?> list, final int mColumnCount) {
    this.mItems = new ArrayList<Object>();
    this.mContext = mContext;
    this.mColumnCount = mColumnCount;
    this.init(list);
  }

  private void init(final List<?> list) {
    this.addAllStableId(list);
    this.mItems.addAll(list);
  }

  public void add(final int n, final Object o) {
    this.addStableId(o);
    this.mItems.add(n, o);
    this.notifyDataSetChanged();
  }

  public void add(final Object o) {
    this.addStableId(o);
    this.mItems.add(o);
    this.notifyDataSetChanged();
  }

  public void add(final List<?> list) {
    this.addAllStableId(list);
    this.mItems.addAll(list);
    this.notifyDataSetChanged();
  }

  public boolean canReorder(final int n) {
    return true;
  }

  public void clear() {
    this.clearStableIdMap();
    this.mItems.clear();
    this.notifyDataSetChanged();
  }

  public int getColumnCount() {
    return this.mColumnCount;
  }

  protected Context getContext() {
    return this.mContext;
  }

  public int getCount() {
    return this.mItems.size();
  }

  public Object getItem(final int n) {
    return this.mItems.get(n);
  }

  public List<Object> getItems() {
    return this.mItems;
  }

  public void remove(final Object o) {
    this.mItems.remove(o);
    this.removeStableID(o);
    this.notifyDataSetChanged();
  }

  public void reorderItems(final int n, final int n2) {
    if (n2 < this.getCount()) {
      DynamicGridUtils.reorder(this.mItems, n, n2);
      this.notifyDataSetChanged();
    }
  }

  public void set(final List<?> list) {
    this.clear();
    this.init(list);
    this.notifyDataSetChanged();
  }

  public void setColumnCount(final int mColumnCount) {
    this.mColumnCount = mColumnCount;
    this.notifyDataSetChanged();
  }
}
