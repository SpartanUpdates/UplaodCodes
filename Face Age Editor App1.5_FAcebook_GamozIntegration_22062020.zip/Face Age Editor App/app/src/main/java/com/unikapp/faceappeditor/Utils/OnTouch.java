package com.unikapp.faceappeditor.Utils;

public abstract interface OnTouch {
	public abstract void removeBorder();
}
