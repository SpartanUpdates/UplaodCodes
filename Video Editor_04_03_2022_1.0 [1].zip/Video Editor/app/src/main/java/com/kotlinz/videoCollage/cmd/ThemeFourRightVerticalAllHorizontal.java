package com.kotlinz.videoCollage.cmd;

import android.util.Log;

import java.util.ArrayList;

public class ThemeFourRightVerticalAllHorizontal {
    public static StringBuilder getOrderString(boolean z, ArrayList<Integer> arrayList, ArrayList<Integer> arrayList2, int i) {
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2;
        if (z) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("[scale1][scale2][scale3]vstack=inputs=3[ver];[ver]format=rgba,scale=-2:");
            stringBuilder2.append(i);
            stringBuilder2.append("[vertical];[scale0][vertical]hstack[vidCombine];");
            stringBuilder.append(stringBuilder2.toString());
        } else if (arrayList2.size() == 4) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("[scale1]split=3[scale1_1][scale1_2][scale1_3]; [scale3]split=3[scale3_1][scale3_2][scale3_3]; [scale5]split=3[scale5_1][scale5_2][scale5_3]; [scale7]split=3[scale7_1][scale7_2][scale7_3];[scale3_1][scale5_1][scale7_1]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
            stringBuilder2.append(i);
            stringBuilder2.append("[vertical1];[scale0][vertical1]hstack[vid1]; [scale2][scale5_2][scale7_2]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
            stringBuilder2.append(i);
            stringBuilder2.append("[vertical2];[scale1_1][vertical2]hstack[vid2]; [scale3_2][scale4][scale7_3]vstack=inputs=3[ver3];[ver3]format=rgba,scale=-2:");
            stringBuilder2.append(i);
            stringBuilder2.append("[vertical3];[scale1_2][vertical3]hstack[vid3]; [scale3_3][scale5_3][scale6]vstack=inputs=3[ver4];[ver4]format=rgba,scale=-2:");
            stringBuilder2.append(i);
            stringBuilder2.append("[vertical4];[scale1_3][vertical4]hstack[vid4]; [vid1][vid2][vid3][vid4] concat=n=4 [vidCombine];");
            stringBuilder.append(stringBuilder2.toString());
        } else {
            String str;
            ArrayList arrayList3 = new ArrayList();
            int i2 = 0;
            while (true) {
                str = "save";
                if (i2 >= arrayList.size()) {
                    break;
                }
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("stackCount.get(i) :: ");
                stringBuilder3.append(arrayList.get(i2));
                Log.e(str, stringBuilder3.toString());
                if (!arrayList2.contains(arrayList.get(i2))) {
                    arrayList3.add(arrayList.get(i2));
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("IMAGE stackCount.get(i) :: ");
                    stringBuilder3.append(arrayList.get(i2));
                    Log.e(str, stringBuilder3.toString());
                }
                i2++;
            }
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append("imagePos.size :: ");
            stringBuilder4.append(arrayList3.size());
            Log.e(str, stringBuilder4.toString());
            if (arrayList3.size() != 1) {
                String str2 = "[vertical2];[scale0_2][vertical2]hstack[vid2]; [vid1][vid2] concat=n=2 [vidCombine];";
                if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 1) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("[scale0]split[scale0_1][scale0_2];[scale1]split[scale1_1][scale1_2];[scale1_1][scale2][scale5]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append("[vertical1];[scale0_1][vertical1]hstack[vid1]; [scale1_2][scale3][scale4]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append(str2);
                    stringBuilder.append(stringBuilder2.toString());
                } else if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 3) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("[scale0]split[scale0_1][scale0_2];[scale3]split[scale3_1][scale3_2];[scale1][scale3_1][scale5]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append("[vertical1];[scale0_1][vertical1]hstack[vid1]; [scale2][scale3_2][scale4]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append(str2);
                    stringBuilder.append(stringBuilder2.toString());
                } else if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 5) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("[scale0]split[scale0_1][scale0_2];[scale5]split[scale5_1][scale5_2];[scale1][scale4][scale5_1]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append("[vertical1];[scale0_1][vertical1]hstack[vid1]; [scale2][scale3][scale5_2]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append(str2);
                    stringBuilder.append(stringBuilder2.toString());
                } else {
                    str2 = "[vertical2];[scale1][vertical2]hstack[vid2]; [vid1][vid2] concat=n=2 [vidCombine];";
                    if (((Integer) arrayList3.get(0)).intValue() == 2 && ((Integer) arrayList3.get(1)).intValue() == 3) {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("[scale2]split[scale2_1][scale2_2];[scale3]split[scale3_1][scale3_2];[scale2_1][scale3_1][scale5]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
                        stringBuilder2.append(i);
                        stringBuilder2.append("[vertical1];[scale0][vertical1]hstack[vid1]; [scale2_2][scale3_2][scale4]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
                        stringBuilder2.append(i);
                        stringBuilder2.append(str2);
                        stringBuilder.append(stringBuilder2.toString());
                    } else if (((Integer) arrayList3.get(0)).intValue() == 2 && ((Integer) arrayList3.get(1)).intValue() == 5) {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("[scale2]split[scale2_1][scale2_2];[scale5]split[scale5_1][scale5_2];[scale2_1][scale4][scale5_1]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
                        stringBuilder2.append(i);
                        stringBuilder2.append("[vertical1];[scale0][vertical1]hstack[vid1]; [scale2_2][scale3][scale5_2]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
                        stringBuilder2.append(i);
                        stringBuilder2.append(str2);
                        stringBuilder.append(stringBuilder2.toString());
                    } else {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("[scale4]split[scale4_1][scale4_2];[scale5]split[scale5_1][scale5_2];[scale3][scale4_1][scale5_1]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
                        stringBuilder2.append(i);
                        stringBuilder2.append("[vertical1];[scale0][vertical1]hstack[vid1]; [scale2][scale4_2][scale5_2]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
                        stringBuilder2.append(i);
                        stringBuilder2.append(str2);
                        stringBuilder.append(stringBuilder2.toString());
                    }
                }
            } else if (((Integer) arrayList3.get(0)).intValue() == 0) {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("[scale0]split=3[scale0_1][scale0_2][scale0_3];[scale2]split[scale2_1][scale2_2];[scale4]split[scale4_1][scale4_2];[scale6]split[scale6_1][scale6_2];[scale1][scale4_1][scale6_1]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
                stringBuilder2.append(i);
                stringBuilder2.append("[vertical1];[scale0_1][vertical1]hstack[vid1]; [scale2_1][scale3][scale6_2]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
                stringBuilder2.append(i);
                stringBuilder2.append("[vertical2];[scale0_2][vertical2]hstack[vid2]; [scale2_2][scale4_2][scale5]vstack=inputs=3[ver3];[ver3]format=rgba,scale=-2:");
                stringBuilder2.append(i);
                stringBuilder2.append("[vertical3];[scale0_3][vertical3]hstack[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                stringBuilder.append(stringBuilder2.toString());
            } else {
                String str3 = "[vertical3];[scale1_2][vertical3]hstack[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];";
                if (((Integer) arrayList3.get(0)).intValue() == 2) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("[scale1]split[scale1_1][scale1_2];[scale2]split=3[scale2_1][scale2_2][scale2_3];[scale4]split[scale4_1][scale4_2];[scale6]split[scale6_1][scale6_2];[scale2_1][scale4_1][scale6_1]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append("[vertical1];[scale0][vertical1]hstack[vid1]; [scale2_2][scale3][scale6_2]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append("[vertical2];[scale1_1][vertical2]hstack[vid2]; [scale2_3][scale4_2][scale5]vstack=inputs=3[ver3];[ver3]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append(str3);
                    stringBuilder.append(stringBuilder2.toString());
                } else if (((Integer) arrayList3.get(0)).intValue() == 4) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("[scale1]split[scale1_1][scale1_2];[scale3]split[scale3_1][scale3_2];[scale4]split=3[scale4_1][scale4_2][scale4_3];[scale6]split[scale6_1][scale6_2];[scale3_1][scale4_1][scale6_1]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append("[vertical1];[scale0][vertical1]hstack[vid1]; [scale2][scale4_2][scale6_2]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append("[vertical2];[scale1_1][vertical2]hstack[vid2]; [scale3_2][scale4_3][scale5]vstack=inputs=3[ver3];[ver3]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append(str3);
                    stringBuilder.append(stringBuilder2.toString());
                } else {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("[scale1]split[scale1_1][scale1_2];[scale3]split[scale3_1][scale3_2];[scale5]split[scale5_1][scale5_2];[scale6]split=3[scale6_1][scale6_2][scale6_3];[scale3_1][scale5_1][scale6_1]vstack=inputs=3[ver1];[ver1]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append("[vertical1];[scale0][vertical1]hstack[vid1]; [scale2][scale5_2][scale6_2]vstack=inputs=3[ver2];[ver2]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append("[vertical2];[scale1_1][vertical2]hstack[vid2]; [scale3_2][scale4][scale6_3]vstack=inputs=3[ver3];[ver3]format=rgba,scale=-2:");
                    stringBuilder2.append(i);
                    stringBuilder2.append(str3);
                    stringBuilder.append(stringBuilder2.toString());
                }
            }
        }
        return stringBuilder;
    }
}
