package flash.light.shine.com.appwidget.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;
import flash.light.shine.com.APP;
import flash.light.shine.com.service.ScreenOnOffService;
import flash.light.shine.com.util.FALib;
import flash.light.shine.com.util.FlashAlertUtil;
import flash.light.shine.com.util.PrefManager;

public class AppWidgetBroadcastReceiver extends BroadcastReceiver {
    public static final String ACTION = " flash.light.shine.appwidgetclick";
    private static final String TAG = "AppWidgetBroadcastReceiver";

    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, action);
        if (ACTION.equals(action)) {
            PrefManager prefManager = APP.getPrefManager();
            int useTotally = prefManager.getUseTotally() ^ 1;
            prefManager.setUseTotally(useTotally);
            if (!prefManager.getUseScreenOn()) {
                if (useTotally != 0) {
                    prefManager.setScreenOnTime(SystemClock.elapsedRealtime() - FlashAlertUtil.SCREEN_ON_SAFE_DELAY);
                    context.startService(new Intent(context, ScreenOnOffService.class));
                } else {
                    context.stopService(new Intent(context, ScreenOnOffService.class));
                }
            }
            FALib.sendBroadcastChangedTotallyUseState(context);
        }
    }
}
