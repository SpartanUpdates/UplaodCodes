package com.esc.dailyrandomfacts.helpers;

import android.os.AsyncTask;
import com.esc.dailyrandomfacts.managers.QuotesManager;

public class QuoteHelper {
    public static QuoteHelper INSTANCE;

    private class AddReadQuoteTask extends AsyncTask<String, Void, String> {
        private AddReadQuoteTask() {
        }

        public String doInBackground(String... strArr) {
            QuotesManager.addReadQuote(strArr[0]);
            return "";
        }
    }

    private QuoteHelper() {
    }

    public static QuoteHelper getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new QuoteHelper();
        }
        return INSTANCE;
    }

    public void addReadQuote(String str) {
        new AddReadQuoteTask().execute(new String[]{str});
    }
}
