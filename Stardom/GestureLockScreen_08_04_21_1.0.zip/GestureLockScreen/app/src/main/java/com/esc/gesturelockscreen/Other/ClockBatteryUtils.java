package com.esc.gesturelockscreen.Other;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.esc.gesturelockscreen.Activity.ClockActivity;
import com.esc.gesturelockscreen.View.ClockView;
import com.esc.gesturelockscreen.View.ServiceLayout;
import com.esc.gesturelockscreen.R;

public class ClockBatteryUtils {
    private static final int MSG_BATTERY_UPDATE = 302;
    private static final int MSG_TIME_UPDATE = 301;
    public static ClockBatteryUtils _instance = new ClockBatteryUtils();
    private static final Handler mHandler = new mhandlerclass();
    private ImageView imageBattery;
    private ClockView mClockView;
    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.intent.action.TIME_TICK".equals(action) || "android.intent.action.TIME_SET".equals(action) || "android.intent.action.TIMEZONE_CHANGED".equals(action)) {
                ClockBatteryUtils.mHandler.sendMessage(ClockBatteryUtils.mHandler.obtainMessage(ClockBatteryUtils.MSG_TIME_UPDATE));
            } else if ("android.intent.action.BATTERY_CHANGED".equals(action)) {
                ClockBatteryUtils.mHandler.sendMessage(ClockBatteryUtils.mHandler.obtainMessage(ClockBatteryUtils.MSG_BATTERY_UPDATE, intent.getIntExtra("status", 1), intent.getIntExtra("level", 0)));
            }
        }
    };
    private TextView tvBattery;

    static class mhandlerclass extends Handler {
        mhandlerclass() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case ClockBatteryUtils.MSG_TIME_UPDATE:
                    if (ClockBatteryUtils._instance.mClockView != null) {
                        ClockBatteryUtils._instance.mClockView.handleTimeUpdate();
                        return;
                    }
                    return;
                case ClockBatteryUtils.MSG_BATTERY_UPDATE:
                    ClockBatteryUtils._instance.handleBatteryUpdate(msg.arg1, msg.arg2);
                    return;
                default:
                    return;
            }
        }
    }


    private ClockBatteryUtils() {
    }

    protected void handleBatteryUpdate(int pluggedInStatus, int batteryLevel) {
        if (this.tvBattery != null) {
            this.tvBattery.setText(new StringBuilder(String.valueOf(batteryLevel)).append("%").toString());
            if (pluggedInStatus == 2) {
                this.imageBattery.setImageResource(R.drawable.icon_battery_charging);
            } else if (batteryLevel > 0 && batteryLevel <= 10) {
                this.imageBattery.setImageResource(R.drawable.icon_battery1);
            } else if (batteryLevel > 10 && batteryLevel <= 25) {
                this.imageBattery.setImageResource(R.drawable.icon_battery2);
            } else if (batteryLevel > 25 && batteryLevel <= 50) {
                this.imageBattery.setImageResource(R.drawable.icon_battery3);
            } else if (batteryLevel > 50 && batteryLevel <= 75) {
                this.imageBattery.setImageResource(R.drawable.icon_battery4);
            } else if (batteryLevel > 75) {
                this.imageBattery.setImageResource(R.drawable.icon_battery5);
            }
        }
    }

    public void onInit(Context context, ServiceLayout rootView) {
        this.mClockView = ClockView.getView(context, ClockActivity.clockStyles[SettingsUtils.getInt(SettingsKeys.KEY_INDEX_CLOCK, 0)]);
        ((FrameLayout) rootView.findViewById(R.id.frame_clock_container)).addView(this.mClockView);
        if (SettingsUtils.getBoolean(SettingsKeys.KEY_SHOW_LIVEWALLPAPER, false)) {
            rootView.findViewById(R.id.lin_battery).setVisibility(View.INVISIBLE);
        }
        this.tvBattery = (TextView) rootView.findViewById(R.id.tbattery_value);
        this.imageBattery = (ImageView) rootView.findViewById(R.id.battery_inidi);
        register(context);
    }

    public void register(Context context) {
        if (context != null && this.mClockView != null) {
            this.mClockView.handleTimeUpdate();
            IntentFilter mFilter = new IntentFilter();
            mFilter.addAction("android.intent.action.TIME_TICK");
            mFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            mFilter.addAction("android.intent.action.TIME_SET");
            if (!SettingsUtils.getBoolean(SettingsKeys.KEY_SHOW_LIVEWALLPAPER, false)) {
                mFilter.addAction("android.intent.action.BATTERY_CHANGED");
            }
            context.registerReceiver(this.mReceiver, mFilter);
        }
    }

    public void unRegister(Context context) {
        if (context != null && this.mClockView != null) {
            try {
                context.unregisterReceiver(this.mReceiver);
            } catch (Exception e) {
            }
        }
    }
}
