package com.example.lyricsvideo.activity;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.lyricsvideo.CallFromUnity;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.Utils.Utils;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeAdView;
import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProgressActivity extends AppCompatActivity {
    public float VideoProgress;
    Handler handler;
    int height;
    DisplayMetrics metrics;
    Runnable runnable;
    Float last;
    String timeRe;
    int width;
    String[] strCommand;
    String MuteVideoPath;
    String TransparentVideoPath;
    String outputVideoPath;
    String OutputVideoName;
    TextView txtPer;
    private ProgressActivity activity = ProgressActivity.this;
    private boolean isPause;
    private Float videoLengthInSec;
    private NativeAd mNativeBannerAd;

    public ProgressActivity() {
        this.handler = new Handler();
        this.last = 0.0f;
        this.timeRe = "\\btime=\\b\\d\\d:\\d\\d:\\d\\d.\\d\\d";
        this.isPause = false;
        this.runnable = new Runnable() {
            @Override
            public void run() {
                ProgressActivity.this.handler.removeCallbacks(ProgressActivity.this.runnable);
                final Intent intent = new Intent(ProgressActivity.this, MyCreationActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
                ProgressActivity.this.startActivity(intent);
            }
        };
    }

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_progress_video);
        getWindow().addFlags(128);
        txtPer = findViewById(R.id.tv_progress);
        metrics = getResources().getDisplayMetrics();
        height = metrics.heightPixels;
        width = metrics.widthPixels;
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ProgressActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
        MuteVideoPath = Utils.INSTANCE.getLyricsVideoStory() + getIntent().getStringExtra("MuteVideoName");
        outputVideoPath = Utils.INSTANCE.getLyricsVideoStory() + getIntent().getStringExtra("SaveVideoName");
        TransparentVideoPath = CallFromUnity.TransparantVideoPath;
        OutputVideoName = getIntent().getStringExtra("SaveVideoName");
        new ProcessVideoOverlapping().execute();
        loadAd();
    }

    protected void onPause() {
        isPause = true;
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
        isPause = false;
    }

    private void execFFmpegBinary(final String[] array) {
        try {
            MainActivity.ffmpeg.execute(array, new ExecuteBinaryResponseHandler() {
                @Override
                public void onFailure(final String s) {
                }

                @Override
                public void onFinish() {

                }

                @Override
                public void onProgress(final String s) {
                    final int durationVideo = Videoduration(TransparentVideoPath);
                    final Float seconds = durationVideo / 1000.0f;
                    videoLengthInSec = seconds;
                    VideoProgress = durationToprogtess(s);
                    ProgressActivity.this.runOnUiThread(new Runnable() {
                        @SuppressLint("SetTextI18n")
                        public void run() {
                            if (VideoProgress >= 100) {
                                txtPer.setText("100.00 %");
                            } else {
                                txtPer.setText(String.valueOf(VideoProgress) + " %");
                            }
                        }
                    });
                }

                @Override
                public void onStart() {
                }

                @Override
                public void onSuccess(String string) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append(Environment.getExternalStorageDirectory().getPath());
                    sb.append("/");
                    sb.append(ProgressActivity.this.getResources().getString(R.string.app_name));
                    string = sb.toString();
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append(string);
                    sb2.append("/temp");
                    removeFrameImage(sb2.toString());
                    MediaScannerConnection.scanFile(ProgressActivity.this.getApplicationContext(), new String[]{new File(outputVideoPath).getAbsolutePath()}, new String[]{"mp4"}, null);
                    ProgressActivity.this.buildNotification();
                    if (ProgressActivity.this.isPause) {
                        return;
                    }
                    final Intent intent = new Intent(ProgressActivity.this, FullVideoPlayActivity.class);
                    intent.putExtra("Url", outputVideoPath);
                    intent.putExtra("Name", OutputVideoName);
                    intent.putExtra("IsPlayVidoeFromHome", false);
                    intent.putExtra("IsVideoFromList", false);
                    intent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
                    startActivity(intent);
                    finish();
                }
            });
        } catch (FFmpegCommandAlreadyRunningException ex) {
            ex.printStackTrace();
        }
    }

    private Float durationToprogtess(final String input) {
        Float progress = 0.0f;
        final Matcher matcher = Pattern.compile(timeRe).matcher(input);
        final int SECOND = 1;
        final int MINUTE = SECOND * 60;
        final int HOUR = MINUTE * 60;
        if (TextUtils.isEmpty(input) || !input.contains("time=")) {
            return last;
        }
        while (matcher.find()) {
            String time = matcher.group();
            time = time.substring(time.lastIndexOf(61) + 1);
            final String[] splitTime = time.split(":");
            final float hour = Float.valueOf(splitTime[0]) * HOUR + Float.valueOf(splitTime[1]) * MINUTE + Float.valueOf(splitTime[2]);
            progress = (float) (int) (hour * 100.0f / videoLengthInSec);
        }
        return last = progress;
    }

    private int Videoduration(final String file) {
        MediaPlayer mp = MediaPlayer.create(ProgressActivity.this, Uri.parse(file));
        final int duration = mp.getDuration();
        mp.release();
        return duration;
    }

    private void buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            final NotificationManager notificationManager = (NotificationManager) this.getSystemService(NOTIFICATION_SERVICE);
            final Intent intent = new Intent(this, FullVideoPlayActivity.class);
            intent.putExtra("Url", outputVideoPath);
            intent.putExtra("Name", OutputVideoName);
            intent.putExtra("IsPlayVidoeFromHome", false);
            intent.putExtra("IsVideoFromList", false);
            intent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
            final NotificationChannel notificationChannel = new NotificationChannel("4565", this.getResources().getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.enableLights(true);
            notificationChannel.enableVibration(false);
            notificationManager.createNotificationChannel(notificationChannel);
            this.getResources();
            @SuppressLint("WrongConstant") final PendingIntent activity = PendingIntent.getActivity(this, 0, intent, View.MeasureSpec.EXACTLY);
            final NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "4565");
            builder.setContentTitle(this.getResources().getString(R.string.app_name)).setSmallIcon(R.mipmap.ic_launcher).setContentText(this.getString(R.string.video_msg)).setDefaults(-1).setWhen(System.currentTimeMillis()).setAutoCancel(true).setContentIntent(activity);
            ((NotificationManager) this.getSystemService(NOTIFICATION_SERVICE)).notify(1001, builder.build());
            return;
        }
        final Intent intent2 = new Intent(this, FullVideoPlayActivity.class);
        intent2.putExtra("Url", outputVideoPath);
        intent2.putExtra("Name", OutputVideoName);
        intent2.putExtra("IsPlayVidoeFromHome", false);
        intent2.putExtra("IsVideoFromList", false);
        intent2.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
        ((NotificationManager) this.getSystemService(NOTIFICATION_SERVICE)).notify(1001, new NotificationCompat.Builder(this).setContentTitle(this.getResources().getString(R.string.app_name)).setContentText(this.getString(R.string.video_msg)).setWhen(System.currentTimeMillis()).setAutoCancel(true).setColor(ContextCompat.getColor(this.getBaseContext(), R.color.colorPrimary)).setSmallIcon(this.getNotificationIcon()).setContentIntent(PendingIntent.getActivity(this, 0, intent2, PendingIntent.FLAG_ONE_SHOT)).setStyle(new NotificationCompat.BigTextStyle().setBigContentTitle(this.getResources().getString(R.string.app_name)).bigText(this.getString(R.string.video_msg))).build());
    }

    private int getNotificationIcon() {
        return R.mipmap.ic_launcher;
    }

    private void removeFrameImage(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            final File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (int length = listFiles.length, i = 0; i < length; ++i) {
                    final File file2 = listFiles[i];
                    if (file2.getName().endsWith(".jpg") || file2.getName().endsWith(".png")) {
                        file2.delete();
                    }
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        IsFinish(getResources().getString(R.string.cancel_video_procress_message));
    }

    public void IsFinish(String alertmessage) {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
//                        MainActivity.ffmpeg.killRunningProcesses();
                        startActivity(new Intent(activity, MainActivity.class));
                        finish();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        dialog.dismiss();
                        break;
                }
            }
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, R.style.AppDialog);
        builder.setTitle(R.string.cancel_video);
        builder.setMessage(alertmessage)
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }

    private void loadAd() {
        mNativeBannerAd = new NativeAd(this, getString(R.string.FB_nativebanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeAdView.render(ProgressActivity.this, mNativeBannerAd, NativeAdView.Type.HEIGHT_300);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });

        mNativeBannerAd.loadAd();
    }

    @SuppressLint("StaticFieldLeak")
    private class ProcessVideoOverlapping extends AsyncTask<Integer, Integer, List<String>> {
        protected List<String> doInBackground(final Integer... array) {
            ProgressActivity.this.getWindowManager().getDefaultDisplay().getMetrics(new DisplayMetrics());
            strCommand = new String[]{
                    "-i",
                    String.valueOf(Uri.parse(MuteVideoPath)),
                    "-i",
                    String.valueOf(Uri.parse(TransparentVideoPath)),
                    "-filter_complex",
                    "[1:v]colorkey=0x000000:0.5:0.5[colorOverlay];[0:v][colorOverlay]overlay[v_out]",
                    "-map",
                    "[v_out]",
                    "-map",
                    "1:a",
                    "-strict",
                    "-2",
                    "-preset",
                    "veryfast",
                    "-g",
                    "120",
                    outputVideoPath};
            ProgressActivity.this.execFFmpegBinary(strCommand);
            return null;
        }

        protected void onPostExecute(final List<String> list) {
        }

        protected void onPreExecute() {
        }
    }

}
