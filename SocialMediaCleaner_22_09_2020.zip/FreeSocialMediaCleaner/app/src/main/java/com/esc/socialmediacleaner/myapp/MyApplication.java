package com.esc.socialmediacleaner.myapp;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.StrictMode;
import android.text.TextUtils;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.esc.socialmediacleaner.datastructure.AllData;
import com.google.android.gms.ads.MobileAds;

public class MyApplication extends Application {
    private static MyApplication mInstance;
    public AllData allData;
    public boolean isSelecting = false;
    public boolean view_enlarged = false;

    public static synchronized MyApplication getInstance() {
        MyApplication app;
        synchronized (MyApplication.class) {
            if (mInstance == null) {
                mInstance = new MyApplication();
            }
            app = mInstance;
        }
        return app;
    }

    public void onCreate() {
        super.onCreate();
        mInstance = this;
        context = getApplicationContext();

        MobileAds.initialize(getApplicationContext());
        if (Build.VERSION.SDK_INT >= 24) {
            final StrictMode.VmPolicy.Builder strictModeVmPolicyBuilder = new StrictMode.VmPolicy.Builder();
            strictModeVmPolicyBuilder.detectFileUriExposure();
            StrictMode.setVmPolicy(strictModeVmPolicyBuilder.build());
        }
    }

    public static final String TAG = MyApplication.class.getSimpleName();

    private RequestQueue mRequestQueue;
    private static Context context;

    public static Context getContext() {
        return context;
    }

    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }

        return mRequestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req, String tag) {
        req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
        getRequestQueue().add(req);
    }
}
