package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.kotlinz.videoCollage.interfaces.FilterAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class FilterAdapter extends Adapter<FilterAdapter.ViewHolder> {
    private Context context;
    private ArrayList<String> listThumb;
    private FilterAdapterCallBackInterface listener;
    private int pos = 0;

    class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        ImageView imageIcon;
        LinearLayout mainLin;

        ViewHolder(View view) {
            super(view);
            this.imageIcon = (ImageView) view.findViewById(R.id.ratio_icon_image);
            this.mainLin = (LinearLayout) view.findViewById(R.id.main_filter_lin);
        }
    }

    public FilterAdapter(ArrayList<String> arrayList, Context context, FilterAdapterCallBackInterface filterAdapterCallBackInterface) {
        this.context = context;
        this.listThumb = arrayList;
        this.listener = filterAdapterCallBackInterface;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_filters, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        InputStream open;
        String str = (String) this.listThumb.get(i);
        try {
            AssetManager assets = this.context.getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("effectthumb/");
            stringBuilder.append(str);
            open = assets.open(stringBuilder.toString());
        } catch (IOException e) {
            e.printStackTrace();
            open = null;
        }
        viewHolder.imageIcon.setImageBitmap(BitmapFactory.decodeStream(open));
        viewHolder.mainLin.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                FilterAdapter.this.pos = i;
                FilterAdapter.this.listener.itemClick(i);
                FilterAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewHolder.imageIcon.setBackgroundColor(this.context.getResources().getColor(R.color.textAndSelectorColor));
        } else {
            viewHolder.imageIcon.setBackgroundColor(this.context.getResources().getColor(R.color.transparent));
        }
    }

    public int getItemCount() {
        return this.listThumb.size();
    }
}
