package com.esc.gesturelockscreen.Activity;

import android.app.Activity;
import android.content.Intent;
import android.gesture.GestureLibraries;
import android.os.Bundle;
import com.esc.gesturelockscreen.Other.SettingsKeys;
import com.esc.gesturelockscreen.Other.SettingsUtils;
import java.io.File;

public class SplashActivity extends Activity {
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    SettingsUtils.init(getApplicationContext());
    if (!GestureLibraries.fromFile(new File(getFilesDir(), "gesture.lock")).load()) {
      startActivityForResult(new Intent(this, GestureLockActivity.class), 2);
    } else if (SettingsUtils.getRecoveryPasscode() == null) {
      startActivityForResult(new Intent(this, PINActivity.class), 3);
    } else {
      startActivity(new Intent(this, SettingsActivity.class));
      finish();
    }
  }

  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == 3) {
      if (resultCode == -1) {
        SettingsUtils.putBoolean(SettingsKeys.KEY_ENABLE_LOCKSCREEN, true);
        startActivity(new Intent(this, SettingsActivity.class));
      }
      finish();
    } else if (requestCode != 2) {
    } else {
      if (resultCode == -1) {
        startActivityForResult(new Intent(this, PINActivity.class), 3);
      } else {
        finish();
      }
    }
  }
}
