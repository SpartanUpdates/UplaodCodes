package com.jenilcreation.photomusicvideo.util;

import android.widget.*;
import android.content.*;
import android.util.*;
import android.graphics.*;

public class CircularTextView extends TextView
{
    int solidColor;
    int strokeColor;
    private float strokeWidth;

    public CircularTextView(final Context context) {
        super(context);
    }

    public CircularTextView(final Context context, final AttributeSet set) {
        super(context, set);
    }

    public CircularTextView(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
    }

    public void draw(final Canvas canvas) {
        final Paint paint = new Paint();
        paint.setColor(this.solidColor);
        paint.setFlags(1);
        final Paint paint2 = new Paint();
        paint2.setColor(this.strokeColor);
        paint2.setFlags(1);
        int height = this.getHeight();
        final int width = this.getWidth();
        if (height <= width) {
            height = width;
        }
        final int n = height / 2;
        this.setHeight(height);
        this.setWidth(height);
        canvas.drawCircle((float)(height / 2), (float)(height / 2), (float)n, paint2);
        canvas.drawCircle((float)(height / 2), (float)(height / 2), n - this.strokeWidth, paint);
        super.draw(canvas);
    }

    public void setSolidColor(final String s) {
        this.solidColor = Color.parseColor(s);
    }

    public void setStrokeColor(final String s) {
        this.strokeColor = Color.parseColor(s);
    }

    public void setStrokeWidth(final int n) {
        this.strokeWidth = n * this.getContext().getResources().getDisplayMetrics().density;
    }
}
