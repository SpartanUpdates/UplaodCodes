package com.esc.tarotcardreading;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy.Builder;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import java.util.ArrayList;

public class SettingsActivity extends AppCompatActivity {
    public static Typeface faceg;
    Activity activity;
    ConsentInformation consentInformation;
    Editor editor;
    private MoviesAdapter mAdapter;
    String[] publisherIds;
    private RecyclerView recyclerView;
    int sh;
    SharedPreferences sharedPreferences;
    int sw;
    Typeface typeface;
    public ArrayList<String> v;

    public class MoviesAdapter extends Adapter<MoviesAdapter.MyViewHolder> {
        private ArrayList<String> arrlist;

        public class MyViewHolder extends ViewHolder {
            public TextView list;

            public MyViewHolder(View view) {
                super(view);
                this.list = (TextView) view.findViewById(R.id.textsettings);
            }
        }

        public MoviesAdapter(ArrayList<String> arrayList) {
            this.arrlist = arrayList;
        }

        public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.settings_items, viewGroup, false));
        }

        public void onBindViewHolder(MyViewHolder myViewHolder, final int i) {
            myViewHolder.list.setText((CharSequence) this.arrlist.get(i));
            if ((SettingsActivity.this.getResources().getConfiguration().screenLayout & 15) == 4) {
                myViewHolder.list.setTypeface(SettingsActivity.this.typeface);
                myViewHolder.list.setTextSize(34.0f);
            } else if ((SettingsActivity.this.getResources().getConfiguration().screenLayout & 15) == 3) {
                myViewHolder.list.setTypeface(SettingsActivity.this.typeface);
                myViewHolder.list.setTextSize(26.0f);
            } else {
                myViewHolder.list.setTypeface(SettingsActivity.this.typeface);
                myViewHolder.list.setTextSize(18.0f);
            }
            myViewHolder.list.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    int i = 0;
                    if (i == 0) {
                        SettingsActivity.this.activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://www.touchzing.com/privacy/")));
                    } else if (i == 1) {
                        view = View.inflate(SettingsActivity.this.activity, R.layout.consent_dialog, null);
                        final Dialog dialog = new Dialog(SettingsActivity.this.activity);
                        dialog.getWindow();
                        dialog.requestWindowFeature(1);
                        dialog.setContentView(view);
                        dialog.setCancelable(true);
                        TextView textView = (TextView) dialog.findViewById(R.id.displayads_text);
                        textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                        textView.setVisibility(View.GONE);
                        Button button = (Button) dialog.findViewById(R.id.btn_lmore);
                        button.setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                SettingsActivity.this.activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://www.touchzing.com/privacy/")));
                            }
                        });
                        button.setVisibility(View.GONE);
                        button = (Button) dialog.findViewById(R.id.btn_np);
                        button.setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                SettingsActivity.this.consentInformation.setConsentStatus(ConsentStatus.NON_PERSONALIZED);
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("");
                                stringBuilder.append(SettingsActivity.this.consentInformation.getConsentStatus());
                                Log.e("AAAAAAAAAAAA", stringBuilder.toString());
                                SettingsActivity.this.consentInformation.requestConsentInfoUpdate(SettingsActivity.this.publisherIds, new ConsentInfoUpdateListener() {
                                    public void onConsentInfoUpdated(ConsentStatus consentStatus) {
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("consentStatus = '");
                                        stringBuilder.append(consentStatus);
                                        Log.e("AAAAAAAAAAAA", stringBuilder.toString());
                                        SettingsActivity.this.editor.putBoolean("googleads_consent_np", true);
                                        SettingsActivity.this.editor.commit();
                                        SettingsActivity.this.editor.putBoolean("googleads_consent", true);
                                        SettingsActivity.this.editor.commit();
                                        dialog.cancel();
                                    }

                                    public void onFailedToUpdateConsentInfo(String str) {
                                        Toast.makeText(SettingsActivity.this.getApplicationContext(), SettingsActivity.this.getResources().getString(R.string.interneterror), Toast.LENGTH_LONG).show();
                                        dialog.cancel();
                                    }
                                });
                            }
                        });
                        Button button2 = (Button) dialog.findViewById(R.id.btn_p);
                        button2.setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                SettingsActivity.this.consentInformation.setConsentStatus(ConsentStatus.PERSONALIZED);
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("");
                                stringBuilder.append(SettingsActivity.this.consentInformation.getConsentStatus());
                                Log.e("AAAAAAAAAAAA", stringBuilder.toString());
                                SettingsActivity.this.consentInformation.requestConsentInfoUpdate(SettingsActivity.this.publisherIds, new ConsentInfoUpdateListener() {
                                    public void onConsentInfoUpdated(ConsentStatus consentStatus) {
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("consentStatus = '");
                                        stringBuilder.append(consentStatus);
                                        Log.e("AAAAAAAAAAAA", stringBuilder.toString());
                                        SettingsActivity.this.editor.putBoolean("googleads_consent", true);
                                        SettingsActivity.this.editor.commit();
                                        SettingsActivity.this.editor.putBoolean("googleads_consent_np", false);
                                        SettingsActivity.this.editor.commit();
                                        dialog.cancel();
                                    }

                                    public void onFailedToUpdateConsentInfo(String str) {
                                        Toast.makeText(SettingsActivity.this.getApplicationContext(), SettingsActivity.this.getResources().getString(R.string.interneterror), Toast.LENGTH_LONG).show();
                                        dialog.cancel();
                                    }
                                });
                            }
                        });
                        if ((SettingsActivity.this.getResources().getConfiguration().screenLayout & 15) == 4) {
                            button.setTypeface(SettingsActivity.this.typeface);
                            button.setTextSize(32.0f);
                            button2.setTypeface(SettingsActivity.this.typeface);
                            button2.setTextSize(32.0f);
                        } else if ((SettingsActivity.this.getResources().getConfiguration().screenLayout & 15) == 3) {
                            button.setTypeface(SettingsActivity.this.typeface);
                            button.setTextSize(24.0f);
                            button2.setTypeface(SettingsActivity.this.typeface);
                            button2.setTextSize(24.0f);
                        } else {
                            button.setTypeface(SettingsActivity.this.typeface);
                            button.setTextSize(18.0f);
                            button2.setTypeface(SettingsActivity.this.typeface);
                            button2.setTextSize(18.0f);
                        }
                        double d = (double) SettingsActivity.this.sw;
                        Double.isNaN(d);
                        int i2 = (int) (d * 0.07d);
                        double d2 = (double) SettingsActivity.this.sw;
                        Double.isNaN(d2);
                        int i3 = (int) (d2 * 0.07d);
                        d2 = (double) SettingsActivity.this.sw;
                        Double.isNaN(d2);
                        int i4 = (int) (d2 * 0.07d);
                        double d3 = (double) SettingsActivity.this.sw;
                        Double.isNaN(d3);
                        button2.setPadding(i2, i3, i4, (int) (d3 * 0.07d));
                        d = (double) SettingsActivity.this.sw;
                        Double.isNaN(d);
                        i2 = (int) (d * 0.07d);
                        d2 = (double) SettingsActivity.this.sw;
                        Double.isNaN(d2);
                        i3 = (int) (d2 * 0.07d);
                        d2 = (double) SettingsActivity.this.sw;
                        Double.isNaN(d2);
                        i4 = (int) (d2 * 0.07d);
                        d3 = (double) SettingsActivity.this.sw;
                        Double.isNaN(d3);
                        button.setPadding(i2, i3, i4, (int) (d3 * 0.07d));
                        if (SettingsActivity.this.sharedPreferences.getBoolean("googleads_consent_np", false)) {
                            button.setBackgroundResource(R.drawable.bgsettingsconsentads);
                        } else {
                            button2.setBackgroundResource(R.drawable.bgsettingsconsentads);
                        }
                        if (!SettingsActivity.this.activity.isFinishing()) {
                            dialog.show();
                        }
                    }
                }
            });
        }

        public int getItemCount() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(this.arrlist.size());
            Log.e("AAAAAAAAAAAA", stringBuilder.toString());
            return this.arrlist.size();
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_settings);
        this.activity = this;
        if (VERSION.SDK_INT > 9) {
            StrictMode.setThreadPolicy(new Builder().permitAll().build());
        }
        ArrayList arrayList = new ArrayList();
        this.v = arrayList;
        arrayList.add(getResources().getString(R.string.pp));
        this.v.add(getResources().getString(R.string.up_cs));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.v);
        String str = "AAAAAAAAAAAA";
        Log.e(str, stringBuilder.toString());
        SharedPreferences sharedPreferences = getSharedPreferences("MyPref", 0);
        this.sharedPreferences = sharedPreferences;
        this.editor = sharedPreferences.edit();
        String str2 = "fonts/georgiar.ttf";
        this.typeface = Typeface.createFromAsset(getAssets(), str2);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.sw = displayMetrics.widthPixels;
        this.sh = displayMetrics.heightPixels;
        ConsentInformation instance = ConsentInformation.getInstance(getApplicationContext());
        this.consentInformation = instance;
        this.publisherIds = new String[]{"pub-4933880264960213"};
        boolean isRequestLocationInEeaOrUnknown = instance.isRequestLocationInEeaOrUnknown();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("***********");
        stringBuilder2.append(isRequestLocationInEeaOrUnknown);
        Log.e(str, stringBuilder2.toString());
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        this.mAdapter = new MoviesAdapter(this.v);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        this.recyclerView.addItemDecoration(new DividerItemDecoration(this, 1));
        this.recyclerView.setAdapter(this.mAdapter);
        faceg = Typeface.createFromAsset(getAssets(), str2);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        View inflate = LayoutInflater.from(this).inflate(R.layout.titleview, null);
        ((TextView) inflate.findViewById(R.id.title)).setTypeface(faceg);
        getSupportActionBar().setCustomView(inflate);
    }
}
