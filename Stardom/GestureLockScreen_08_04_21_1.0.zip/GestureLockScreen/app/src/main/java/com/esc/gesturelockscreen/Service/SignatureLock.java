package com.esc.gesturelockscreen.Service;

import android.content.*;
import android.app.*;

public interface SignatureLock
{
  void hide();

  void onScreenOff();

  void onScreenOn();

  void onStart(final Intent p0);

  void onStop(final boolean p0);

  void setPendingIntent(final PendingIntent p0);

  void show();
}
