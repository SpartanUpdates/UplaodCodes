﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Manager : MonoBehaviour
{
    public static Manager instance;

    [HideInInspector]
    public bool isNetWorkOn = false;

    public string strLike = "market://details?id=com.example.android";

    public string strPrivacyPolicy = "http://google.com/";

    public string strShareApp = "http://google.com/";

    public string interstitialId = "ca-app-pub-3940256099942544/1033173712";

    public string bannerID = "ca-app-pub-3940256099942544/6300978111";

    public string RewardID = "ca-app-pub-3940256099942544/5224354917";

    [HideInInspector]
    public int restartLevel = 0;

    public bool isOneTimePlay = false;
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            Destroy(this.gameObject);
        }

        if (Application.internetReachability != NetworkReachability.NotReachable)
        {
            isNetWorkOn = true;
        }
        else
        {
            isNetWorkOn = false;
        }
    }
}
