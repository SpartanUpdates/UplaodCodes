package com.kotlinz.festivalstorymaker.Model.ThemeEdit;


public class EditDataItem {
    public String type;
    public String ImagePath;
    public String Name;
    public String X;
    public String Y;
    public String Width;
    public String Height;
    public String FontName;
    public String FontSpacing;
    public String Spacing;
    public String IsLock;
    public String IsColor;
    public String IsHue;
    public String IsMask;
    public String IsShape;
    public String IsObject;
    public String IsLogo;
    public String IsZoom;
    public String IsSt;
    public String IsBt;
    public String IsWt;
    public String IsPt;
    public String Justification;
    public String LineHeight;
    public String Color;
    public String Size;
    public String Text;
    public String BorderSize;
    public String BorderColor;
    public String Rotation;
    public String Position;


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImagePath() {
        return ImagePath;
    }

    public void setImagePath(String imagePath) {
        ImagePath = imagePath;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getX() {
        return X;
    }

    public void setX(String x) {
        X = x;
    }

    public String getY() {
        return Y;
    }

    public void setY(String y) {
        Y = y;
    }

    public String getWidth() {
        return Width;
    }

    public void setWidth(String width) {
        Width = width;
    }

    public String getHeight() {
        return Height;
    }

    public void setHeight(String height) {
        Height = height;
    }

    public String getFontName() {
        return FontName;
    }

    public void setFontName(String fontName) {
        FontName = fontName;
    }

    public String getFontSpacing() {
        return FontSpacing;
    }

    public void setFontSpacing(String fontSpacing) {
        FontSpacing = fontSpacing;
    }

    public String getSpacing() {
        return Spacing;
    }

    public void setSpacing(String spacing) {
        Spacing = spacing;
    }

    public String getIsLock() {
        return IsLock;
    }

    public void setIsLock(String isLock) {
        IsLock = isLock;
    }

    public String getIsColor() {
        return IsColor;
    }

    public void setIsColor(String isColor) {
        IsColor = isColor;
    }

    public String getIsHue() {
        return IsHue;
    }

    public void setIsHue(String isHue) {
        IsHue = isHue;
    }

    public String getIsMask() {
        return IsMask;
    }

    public void setIsMask(String isMask) {
        IsMask = isMask;
    }

    public String getIsShape() {
        return IsShape;
    }

    public void setIsShape(String isShape) {
        IsShape = isShape;
    }

    public String getIsObject() {
        return IsObject;
    }

    public void setIsObject(String isObject) {
        IsObject = isObject;
    }

    public String getIsLogo() {
        return IsLogo;
    }

    public void setIsLogo(String isLogo) {
        IsLogo = isLogo;
    }

    public String getIsZoom() {
        return IsZoom;
    }

    public void setIsZoom(String isZoom) {
        IsZoom = isZoom;
    }

    public String getIsSt() {
        return IsSt;
    }

    public void setIsSt(String isSt) {
        IsSt = isSt;
    }

    public String getIsBt() {
        return IsBt;
    }

    public void setIsBt(String isBt) {
        IsBt = isBt;
    }

    public String getIsWt() {
        return IsWt;
    }

    public void setIsWt(String isWt) {
        IsWt = isWt;
    }

    public String getIsPt() {
        return IsPt;
    }

    public void setIsPt(String isPt) {
        IsPt = isPt;
    }

    public String getJustification() {
        return Justification;
    }

    public void setJustification(String justification) {
        Justification = justification;
    }

    public String getLineHeight() {
        return LineHeight;
    }

    public void setLineHeight(String lineHeight) {
        LineHeight = lineHeight;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String color) {
        Color = color;
    }

    public String getSize() {
        return Size;
    }

    public void setSize(String size) {
        Size = size;
    }

    public String getText() {
        return Text;
    }

    public void setText(String text) {
        Text = text;
    }

    public String getBorderSize() {
        return BorderSize;
    }

    public void setBorderSize(String borderSize) {
        BorderSize = borderSize;
    }

    public String getBorderColor() {
        return BorderColor;
    }

    public void setBorderColor(String borderColor) {
        BorderColor = borderColor;
    }

    public String getRotation() {
        return Rotation;
    }

    public void setRotation(String rotation) {
        Rotation = rotation;
    }

    public String getPosition() {
        return Position;
    }

    public void setPosition(String position) {
        Position = position;
    }
}