package com.kotlinz.puzzlecreator.solver;

import static com.kotlinz.puzzlecreator.NativeAds.CustomNativeAd.populateUnifiedNativeAdViewbig;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.facebook.ads.Ad;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.kotlinz.puzzlecreator.App.MyApplication;
import com.kotlinz.puzzlecreator.activity.BaseFragment;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.model.puzzle_get_set;
import com.kotlinz.puzzlecreator.retrofit.APIClient;
import com.kotlinz.puzzlecreator.retrofit.APIInterface;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SolverAnsweredFragment extends BaseFragment {

    RecyclerView recyclerView;
    PuzzleAnsAdapter adapter;
    ArrayList<puzzle_get_set> PuzzleList = new ArrayList<puzzle_get_set>();
    private ProgressBar loadingPB;
    private NestedScrollView nestedSV;
    int page = 1, lastpage = 0;
    SwipeRefreshLayout swipeRefreshLayout;
    LottieAnimationView anim_nodata;


    public SolverAnsweredFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_solver_answered, container, false);
        recyclerView = view.findViewById(R.id.recyclersolvepuzzle);
        loadingPB = view.findViewById(R.id.idPBLoading);
        nestedSV = view.findViewById(R.id.idNestedSV);
        swipeRefreshLayout = view.findViewById(R.id.swiperefresh);
        anim_nodata = view.findViewById(R.id.anim_nodata);
        adapter = new PuzzleAnsAdapter(getContext(), PuzzleList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (isNetworkAvailable()) {
                    page = 1;
                    getPuzzle();
                } else {
                    noNetworkDialog();
                }
                swipeRefreshLayout.setRefreshing(false);
                swipeRefreshLayout.setEnabled(false);

            }
        });
        nestedSV.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (scrollY == v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight()) {
                    if (isNetworkAvailable()) {
                        if (page <= lastpage) {
                            page++;
                            loadingPB.setVisibility(View.VISIBLE);
                            getPuzzle();
                        } else {
                            loadingPB.setVisibility(View.GONE);
                        }
                    } else {
                        noNetworkDialog();
                    }
                }
            }
        });

        if (isNetworkAvailable()) {
            getPuzzle();
        } else {
            noNetworkDialog();
        }
        return view;
    }


    public class PuzzleAnsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private final int ITEM_TYPE_DATA = 0;
        public final int ITEM_TYPE_AD = 1;
        private final ArrayList<puzzle_get_set> listdata;
        Context context;
        private int AdsIndex = 0;

        public PuzzleAnsAdapter(Context context, ArrayList<puzzle_get_set> listdata) {
            this.listdata = listdata;
            this.context = context;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == ITEM_TYPE_AD) {
                return new NativeAdViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_coustomads, parent, false));
            } else {
                LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
                View listItem = layoutInflater.inflate(R.layout.solver_puzzleview_layout, parent, false);
                ViewHolder viewHolder = new ViewHolder(listItem);
                return viewHolder;
            }

        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (getItemViewType(position) == ITEM_TYPE_AD) {
                NativeAdViewHolder nativeAdViewHolder = (NativeAdViewHolder) holder;
                if (MyApplication.getInstance().mNativeAds != null) {
                    if (AdsIndex < MyApplication.getInstance().mNativeAds.size()) {
                        NativeAd nativeAd = MyApplication.getInstance().mNativeAds.get(AdsIndex);

                        //Native Ads Not Loaded View Display First
                        View NativeAdsLoading = getLayoutInflater().inflate(R.layout.layout_nativeads_loding, null);
                        nativeAdViewHolder.frameLayout.addView(NativeAdsLoading);

                        //Native Ads Loaded Show Ads With Content
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.row_native_ad_item, null);
                        populateUnifiedNativeAdViewbig(nativeAd, adView);
                        nativeAdViewHolder.frameLayout.removeAllViews();
                        nativeAdViewHolder.frameLayout.addView(adView);
                        AdsIndex++;
                        if (AdsIndex >= MyApplication.getInstance().mNativeAds.size()) {
                            AdsIndex = 0;
                        }
                    }
                }
            } else {
                if (holder instanceof ViewHolder) {
                    ViewHolder PuzzleViewHolder = (ViewHolder) holder;
                    final puzzle_get_set puzzle = listdata.get(position);
                    if (puzzle.getPuzzleimg() == null || puzzle.getPuzzleimg().equalsIgnoreCase("null") || puzzle.getPuzzleimg().equalsIgnoreCase("")) {
                        PuzzleViewHolder.puzzleimg.setVisibility(View.GONE);
                    } else {
                        PuzzleViewHolder.puzzleimg.setVisibility(View.VISIBLE);
                        Picasso.with(getActivity()).load(puzzle.getPuzzleimg()).into(PuzzleViewHolder.puzzleimg);
                    }

                    PuzzleViewHolder.lans.removeAllViews();

                    PuzzleViewHolder.lans.setVisibility(View.VISIBLE);
                    if (puzzle.getPuzzletype().equalsIgnoreCase("manual")) {
                        PuzzleViewHolder.lans.setVisibility(View.GONE);
                        PuzzleViewHolder.lmenual.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.edtans.setEnabled(false);
                    } else {
                        PuzzleViewHolder.lmenual.setVisibility(View.GONE);
                        for (int i = 0; i < puzzle.getOptions().size(); i++) {
                            TextView textView = new TextView(context);
                            textView.setText(puzzle.getOptions().get(i));
                            textView.setBackground(getResources().getDrawable(R.drawable.eclips));
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                textView.setTypeface(getResources().getFont(R.font.poppins_medium));
                            }
                            textView.setPadding(10, 20, 10, 20);
                            textView.setTextColor(getResources().getColor(R.color.mcq_color));
                            textView.setTextSize(15);
                            textView.setGravity(Gravity.CENTER);

                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT);

                            params.setMargins(15, 5, 15, 5);

                            textView.setLayoutParams(params);
                            PuzzleViewHolder.lans.addView(textView);
                        }
                    }
                    PuzzleViewHolder.txtquestion.setText(puzzle.getQuestion());

                    if (puzzle.getAnsstatus().equalsIgnoreCase("")) {
                        PuzzleViewHolder.txtansstatus.setVisibility(View.GONE);
                    } else if (puzzle.getAnsstatus().equalsIgnoreCase("success")) {
                        PuzzleViewHolder.txtansstatus.setVisibility(View.VISIBLE);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            PuzzleViewHolder.txtansstatus.setTextColor(ColorStateList.valueOf(getResources().getColor(R.color.green)));
                            PuzzleViewHolder.txtansstatus.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.trans_green)));
                        }
                        PuzzleViewHolder.txtansstatus.setText(puzzle.getAnsstatus());
                    } else {
                        PuzzleViewHolder.txtansstatus.setVisibility(View.VISIBLE);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            PuzzleViewHolder.txtansstatus.setTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
                            PuzzleViewHolder.txtansstatus.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.trans_red)));
                        }
                        PuzzleViewHolder.txtansstatus.setText(puzzle.getAnsstatus());
                    }
                    PuzzleViewHolder.lhint.setVisibility(View.GONE);
                    PuzzleViewHolder.lshowans.setVisibility(View.GONE);
                    PuzzleViewHolder.lshare.setVisibility(View.GONE);
                    if (puzzle.getLevel().equalsIgnoreCase("high")) {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.high));
                    } else if (puzzle.getLevel().equalsIgnoreCase("medium")) {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.medium));
                    } else {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.low));
                    }
                }
            }
        }


        @Override
        public int getItemViewType(int position) {
            if ((position > 0) && ((position + 1) % 4 == 0) && MyApplication.getInstance().IsNativeAdsLoaded) {
                return ITEM_TYPE_AD;
            } else {
                return ITEM_TYPE_DATA;
            }
        }

        @Override
        public int getItemCount() {
            return listdata.size();
        }

        public class NativeAdViewHolder extends RecyclerView.ViewHolder {
            FrameLayout frameLayout;

            public NativeAdViewHolder(View view) {
                super(view);
                frameLayout = view.findViewById(R.id.fl_adplaceholder);
            }
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ImageView puzzleimg, imglevel;
            public TextView txtquestion, txtansstatus;
            EditText edtans;
            public LinearLayout lhint, lshare, lshowans, lmenual;
            CardView cardimg;
            GridLayout lans;

            public ViewHolder(View itemView) {
                super(itemView);
                puzzleimg = itemView.findViewById(R.id.img);
                lans = itemView.findViewById(R.id.lans);

                cardimg = itemView.findViewById(R.id.cardimg);
                imglevel = itemView.findViewById(R.id.imglevel);

                txtquestion = itemView.findViewById(R.id.txtquestion);
                txtansstatus = itemView.findViewById(R.id.textansstatus);

                edtans = itemView.findViewById(R.id.edtans);

                lhint = itemView.findViewById(R.id.lhint);
                lshare = itemView.findViewById(R.id.lshare);
                lshowans = itemView.findViewById(R.id.lshowans);
                lmenual = itemView.findViewById(R.id.lmenual);
            }
        }
    }


    private void getPuzzle() {
        if (page == 1) {
            PuzzleList.clear();
            showProgressDialog();
        }
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).GetSolveransPuzzle(sessionManager.getToken(), page, true);
        call.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            JSONObject resp = jsonObject.getJSONObject("response");
                            JSONArray puzzleData = resp.getJSONArray("puzzle_data");
                            if (page == 1 && puzzleData.length() == 0) {
                                cancel_dialog();
                                swipeRefreshLayout.setVisibility(View.GONE);
                                anim_nodata.setVisibility(View.VISIBLE);

                            } else {
                                anim_nodata.setVisibility(View.GONE);
                                swipeRefreshLayout.setVisibility(View.VISIBLE);
                                for (int i = 0; i < puzzleData.length(); i++) {
                                    JSONObject pzl = puzzleData.getJSONObject(i);
                                    puzzle_get_set puzzle = new puzzle_get_set();
                                    puzzle.setId(pzl.getString("puzzle_id"));
                                    puzzle.setQuestion(pzl.getString("question"));
                                    puzzle.setPuzzletype(pzl.getString("question_type"));
                                    puzzle.setPuzzleimg(pzl.getString("image"));
                                    puzzle.setTrueans(pzl.getString("true_answer"));
                                    puzzle.setHint(pzl.getString("hint"));
                                    puzzle.setLevel(pzl.getString("difficulty_level"));
                                    JSONArray option = pzl.getJSONArray("options");
                                    List<String> opt = new ArrayList<>();
                                    for (int j = 0; j < option.length(); j++) {
                                        opt.add(option.getString(j));
                                    }
                                    puzzle.setOptions(opt);
                                    puzzle.setAnsstatus(pzl.getString("answer_status"));
                                    PuzzleList.add(puzzle);
                                    if (isNetworkAvailable() && MyApplication.getInstance().IsNativeAdsLoaded) {
                                        if ((PuzzleList.size() + 1) % 4 == 0) {
                                            Log.e("TAG", "Ads Position Added");
                                            puzzle.setNativeAds(true);
                                            PuzzleList.add(null);
                                        }
                                    }
                                }
                                adapter.notifyDataSetChanged();

                                cancel_dialog();

                                swipeRefreshLayout.setEnabled(true);
                                lastpage = resp.getInt("last_page");
                                if (page > lastpage) {
                                    cancel_dialog();
                                    Toast.makeText(getActivity(), "No more data..", Toast.LENGTH_SHORT).show();
                                    loadingPB.setVisibility(View.GONE);
                                    return;
                                }
                            }
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        swipeRefreshLayout.setEnabled(true);
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }

}