package com.esc.socialmediacleaner.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.viewpager.widget.ViewPager;

import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.activity.FileTabsScreen;
import com.esc.socialmediacleaner.adapter.CategoryPagerAdapter;
import com.esc.socialmediacleaner.datastructure.FileDataWrapper;
import com.esc.socialmediacleaner.util.Util;
import com.google.android.material.tabs.TabLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class FileFragment extends Fragment {
    private Button btnDelete;
    private AppCompatCheckBox cheSlectAll;
    private final Context context;
    private final ArrayList<FileDataWrapper> dataList;
    private int deviceHeight;
    private int deviceWidth;
    private boolean fromTouch = false;
    private View root;
    private TabLayout tabsCategory;
    private TextView tv_all_selection;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public void onResume() {
        super.onResume();
        if (MyApplication.getInstance().allData.dataDeleted) {
            int size = this.dataList.size();
            int i = 0;
            while (i < size) {
                if (new File(((FileDataWrapper) this.dataList.get(i)).path).exists()) {
                    i++;
                } else {
                    this.dataList.remove(i);
                    size--;
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.dataList.size());
            stringBuilder.append("");
            Log.d("SIZE", stringBuilder.toString());
        }
        ArrayList arrayList = this.dataList;
        if (arrayList != null && arrayList.size() == 0) {
            this.root.findViewById(R.id.tv_empty).setVisibility(View.VISIBLE);
            ((View) this.cheSlectAll.getParent()).setVisibility(View.GONE);
        }
    }

    public FileFragment(Context context, ArrayList<FileDataWrapper> arrayList) {
        this.context = context;
        this.dataList = arrayList;
        setDeviceDimensions();
        sortBySize();
    }

    private void sortBySize() {
        Collections.sort(this.dataList, new Comparator<FileDataWrapper>() {
            public int compare(FileDataWrapper fileDataWrapper, FileDataWrapper fileDataWrapper2) {
                return Long.compare(fileDataWrapper2.size, fileDataWrapper.size);
            }
        });
    }

    private void sortByDate() {
        Collections.sort(this.dataList, new Comparator<FileDataWrapper>() {
            public int compare(FileDataWrapper fileDataWrapper, FileDataWrapper fileDataWrapper2) {
                return Long.compare(fileDataWrapper2.lastModified, fileDataWrapper.lastModified);
            }
        });
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.root = layoutInflater.inflate(R.layout.activity_file_view_screen, viewGroup, false);
        this.btnDelete = (Button) getActivity().findViewById(R.id.btn_delete);
        this.tv_all_selection = (TextView) getActivity().findViewById(R.id.tv_all_selection);
        this.cheSlectAll = (AppCompatCheckBox) this.root.findViewById(R.id.ch_selectall);
        this.tabsCategory = (TabLayout) this.root.findViewById(R.id.tab_category);
        this.cheSlectAll.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                FileFragment.this.fromTouch = true;
                return false;
            }
        });
        this.cheSlectAll.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (FileFragment.this.fromTouch) {
                    ((TextView) ((FileTabsScreen) FileFragment.this.context).findViewById(R.id.tv_select_toggle)).setText(FileFragment.this.getString(z ? R.string.str_selecton : R.string.str_selectoff));
                    MyApplication.getInstance().isSelecting = true;
                    int i;
                    if (z) {
                        MyApplication.getInstance().isSelecting = true;
                        for (i = 0; i < FileFragment.this.dataList.size(); i++) {
                            MyApplication.getInstance().allData.checkItem((FileDataWrapper) FileFragment.this.dataList.get(i));
                        }
                    } else {
                        MyApplication.getInstance().isSelecting = false;
                        for (i = 0; i < FileFragment.this.dataList.size(); i++) {
                            MyApplication.getInstance().allData.unCheckItem((FileDataWrapper) FileFragment.this.dataList.get(i));
                        }
                    }
                    if (MyApplication.getInstance().allData.totSelectedItem == 0) {
                        FileFragment.this.btnDelete.setText(FileFragment.this.getString(R.string.str_delete));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            FileFragment.this.btnDelete.setBackground(FileFragment.this.context.getDrawable(R.drawable.btn_gray_round));
                        }
//                        FileFragment.this.btnDelete.setTextColor(Color.parseColor("#909090"));
                    } else {
                        Button access$300 = FileFragment.this.btnDelete;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(FileFragment.this.getString(R.string.str_delete));
                        stringBuilder.append(" ");
                        stringBuilder.append(Util.convertBytes(MyApplication.getInstance().allData.totSelectedSize));
                        access$300.setText(stringBuilder.toString());
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            FileFragment.this.btnDelete.setBackground(FileFragment.this.context.getDrawable(R.drawable.btn_bg_round));
                        }
//                        FileFragment.this.btnDelete.setTextColor(Color.parseColor("#000000"));
                    }
                    TextView access$400 = FileFragment.this.tv_all_selection;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(MyApplication.getInstance().allData.totSelectedItem);
                    stringBuilder2.append("/");
                    stringBuilder2.append(MyApplication.getInstance().allData.total_filetype);
                    access$400.setText(stringBuilder2.toString());
                    FileFragment.this.fromTouch = false;
                    ((FileTabsScreen) FileFragment.this.getActivity()).sendMessage();
                }
            }
        });

        ArrayAdapter createFromResource = ArrayAdapter.createFromResource(getActivity(), R.array.sort_array, android.R.layout.simple_spinner_dropdown_item);
        createFromResource.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = (Spinner) this.root.findViewById(R.id.sorttype_sppiner);
        spinner.setAdapter(createFromResource);
        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                if (i == 0) {
                    FileFragment.this.sortByDate();
                } else {
                    FileFragment.this.sortBySize();
                }
                ((TextView) adapterView.getChildAt(0)).setTextColor(getResources().getColor(R.color.color_bg));
                Intent intent = new Intent("back.pressed.selecting");
                intent.putExtra("SORT", i + 1);
                LocalBroadcastManager.getInstance(FileFragment.this.getActivity()).sendBroadcast(intent);
            }
        });
        ViewPager viewPager = (ViewPager) this.root.findViewById(R.id.view_pager_category);
        CategoryPagerAdapter categoryPagerAdapter = new CategoryPagerAdapter(getActivity(), getChildFragmentManager(), this.dataList, this.cheSlectAll, this.tabsCategory);
        viewPager.setAdapter(categoryPagerAdapter);
        categoryPagerAdapter.notifyDataSetChanged();
        this.tabsCategory.setupWithViewPager(null);
        this.tabsCategory.setupWithViewPager(viewPager);
        return this.root;
    }

    private void setDeviceDimensions() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) this.context.getSystemService("window");
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        }
        this.deviceHeight = displayMetrics.heightPixels;
        this.deviceWidth = displayMetrics.widthPixels;
    }
}
