package com.hiddencamera.config;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class CameraImageFormat {
    public static final int FORMAT_JPEG = 849;
    public static final int FORMAT_WEBP = 563;

    private CameraImageFormat() {
        super();
        throw new RuntimeException("Cannot initialize CameraImageFormat.");
    }

    @Retention(RetentionPolicy.SOURCE)
    public @interface SupportedImageFormat {
    }
}
