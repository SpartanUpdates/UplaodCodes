package com.mbit.VideoMaker.View;

public class a {
    public static String ThemeCategoryUrl = "http://pkmaster.in/master/api/v1/getAllCategoryOfFullScreenTheme";
    public static String ThemeCategoryWiseDataUrl = "http://pkmaster.in/master/api/v1/GetAllFullScreenTheme";
//    public static String DownloadCountUrl = "http://trendinganimations.com/api/download/theme";
}
