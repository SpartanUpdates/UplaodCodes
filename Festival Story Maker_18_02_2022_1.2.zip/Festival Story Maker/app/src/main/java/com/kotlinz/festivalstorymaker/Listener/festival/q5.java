package com.kotlinz.festivalstorymaker.Listener.festival;

import android.widget.SeekBar;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

public class q5 implements SeekBar.OnSeekBarChangeListener {
    public final FestivalDetailActivity_New n;

    public q5(FestivalDetailActivity_New festivalDetailActivity_New) {
        this.n = festivalDetailActivity_New;
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        if (z) {
            this.n.a1.setLineSpacing((float) i);
            this.n.a1.requestLayout();
            FestivalDetailActivity_New festivalDetailActivity_New = this.n;
            com.kotlinz.festivalstorymaker.Models.festival.f0.c cVar = (com.kotlinz.festivalstorymaker.Models.festival.f0.c) festivalDetailActivity_New.h1.get(((Integer) festivalDetailActivity_New.a1.getTag()).intValue());
            cVar.b = i + 5;
            FestivalDetailActivity_New festivalDetailActivity_New2 = this.n;
            festivalDetailActivity_New2.h1.set(((Integer) festivalDetailActivity_New2.a1.getTag()).intValue(), cVar);
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }

}
