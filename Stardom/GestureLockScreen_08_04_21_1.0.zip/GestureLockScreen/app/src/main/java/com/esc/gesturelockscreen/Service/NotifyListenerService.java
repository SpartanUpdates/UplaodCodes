package com.esc.gesturelockscreen.Service;

import android.service.notification.*;
import android.os.*;
import android.app.*;
import android.annotation.*;
import com.esc.gesturelockscreen.Other.*;
import android.content.*;

@TargetApi(18)
public class NotifyListenerService extends NotificationListenerService
{
  private BroadcastReceiver nlservicereciver;

  @SuppressLint({ "NewApi" })
  private void onPosted(final StatusBarNotification statusBarNotification) {
    final Notification notification = statusBarNotification.getNotification();
    if (notification.priority != -2) {
      final Intent intent = new Intent("ADD_NOTIFICATION");
      intent.putExtra("notification_ID", statusBarNotification.getId());
      intent.putExtra("notification_cancelable", statusBarNotification.isClearable());
      String s;
      if (Build.VERSION.SDK_INT >= 21) {
        s = statusBarNotification.getKey();
      }
      else {
        s = statusBarNotification.getTag();
      }
      intent.putExtra("notification_KEY", s);
      intent.putExtra("notification_package", statusBarNotification.getPackageName());
      intent.putExtra("view_small", (Parcelable)notification.contentView);
      intent.putExtra("view_large", (Parcelable)notification.bigContentView);
      intent.putExtra("view_pendingintent", (Parcelable)notification.contentIntent);
      intent.setPackage(this.getPackageName());
      this.sendBroadcast(intent);
    }
  }

  @SuppressLint({ "NewApi" })
  public void doRemove(final String s) {
    try {
      this.cancelNotification(s);
    }
    catch (SecurityException ex) {
      ex.printStackTrace();
    }
  }

  public void doRemove(final String s, final String s2, final int n) {
    try {
      this.cancelNotification(s, s2, n);
    }
    catch (SecurityException ex) {
      ex.printStackTrace();
    }
  }

  public void onCreate() {
    super.onCreate();
    SettingsUtils.init(this.getApplicationContext());
    if (SettingsUtils.getBoolean("KEY_ENABLE_LOCKSCREEN", false)) {
      LockStateService.checkAndStartService(this.getApplicationContext(), LockStateService.class);
    }
    this.nlservicereciver = new BroadcastReceiver() {
      public void onReceive(final Context context, final Intent intent) {
        int i = 0;
        final String action = intent.getAction();
        if (action.equals("CLEAR_ALL_NOTIFICATION")) {
          NotifyListenerService.this.cancelAllNotifications();
        }
        else if (action.equals("CLEAR_NOTIFICATION")) {
          final String stringExtra = intent.getStringExtra("notification_KEY");
          final int intExtra = intent.getIntExtra("notification_ID", 0);
          final String stringExtra2 = intent.getStringExtra("notification_package");
          if (Build.VERSION.SDK_INT >= 21) {
            NotifyListenerService.this.doRemove(stringExtra);
            return;
          }
          NotifyListenerService.this.doRemove(stringExtra2, stringExtra, intExtra);
        }
        else if (action.equals("SHOW_ALL_NOTIFICATION")) {
          final Intent intent2 = new Intent("UPDATE_NOTIFICATION");
          intent2.setPackage(NotifyListenerService.this.getPackageName());
          NotifyListenerService.this.sendBroadcast(intent2);
          for (StatusBarNotification[] activeNotifications = NotifyListenerService.this.getActiveNotifications(); i < activeNotifications.length; ++i) {
            NotifyListenerService.this.onPosted(activeNotifications[i]);
          }
        }
      }
    };
    final IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("CLEAR_NOTIFICATION");
    intentFilter.addAction("SHOW_ALL_NOTIFICATION");
    intentFilter.addAction("CLEAR_ALL_NOTIFICATION");
    this.registerReceiver(this.nlservicereciver, intentFilter);
  }

  public void onDestroy() {
    super.onDestroy();
    this.unregisterReceiver(this.nlservicereciver);
  }

  public void onNotificationPosted(final StatusBarNotification statusBarNotification) {
    this.onPosted(statusBarNotification);
  }

  public void onNotificationRemoved(final StatusBarNotification statusBarNotification) {
    final Intent intent = new Intent("REMOVED_NOTIFICATION");
    intent.putExtra("notification_ID", statusBarNotification.getId());
    intent.putExtra("notification_package", statusBarNotification.getPackageName());
    intent.setPackage(this.getPackageName());
    this.sendBroadcast(intent);
  }
}
