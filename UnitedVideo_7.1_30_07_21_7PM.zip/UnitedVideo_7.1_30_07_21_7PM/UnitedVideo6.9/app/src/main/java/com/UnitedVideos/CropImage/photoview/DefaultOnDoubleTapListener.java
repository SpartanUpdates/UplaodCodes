package com.UnitedVideos.CropImage.photoview;

import android.graphics.RectF;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

public class DefaultOnDoubleTapListener implements GestureDetector.OnDoubleTapListener {
    private PhotoViewAttacher photoViewAttacher;

    public DefaultOnDoubleTapListener(final PhotoViewAttacher photoViewAttacher) {
        this.setPhotoViewAttacher(photoViewAttacher);
    }

    public void setPhotoViewAttacher(final PhotoViewAttacher newPhotoViewAttacher) {
        this.photoViewAttacher = newPhotoViewAttacher;
    }

    public boolean onSingleTapConfirmed(final MotionEvent e) {
        if (this.photoViewAttacher == null) {
            return false;
        }
        final ImageView imageView = this.photoViewAttacher.getImageView();
        if (this.photoViewAttacher.getOnPhotoTapListener() != null) {
            final RectF displayRect = this.photoViewAttacher.getDisplayRect();
            if (displayRect != null) {
                final float x = e.getX();
                final float y = e.getY();
                if (displayRect.contains(x, y)) {
                    final float xResult = (x - displayRect.left) / displayRect.width();
                    final float yResult = (y - displayRect.top) / displayRect.height();
                    this.photoViewAttacher.getOnPhotoTapListener().onPhotoTap((View) imageView, xResult, yResult);
                    return true;
                }
            }
        }
        if (this.photoViewAttacher.getOnViewTapListener() != null) {
            this.photoViewAttacher.getOnViewTapListener().onViewTap((View) imageView, e.getX(), e.getY());
        }
        return false;
    }

    public boolean onDoubleTap(final MotionEvent ev) {
        if (this.photoViewAttacher == null) {
            return false;
        }
        try {
            final float scale = this.photoViewAttacher.getScale();
            final float x = ev.getX();
            final float y = ev.getY();
            if (scale < this.photoViewAttacher.getMediumScale()) {
                this.photoViewAttacher.setScale(this.photoViewAttacher.getMediumScale(), x, y, true);
            } else if (scale >= this.photoViewAttacher.getMediumScale() && scale < this.photoViewAttacher.getMaximumScale()) {
                this.photoViewAttacher.setScale(this.photoViewAttacher.getMaximumScale(), x, y, true);
            } else {
                this.photoViewAttacher.setScale(this.photoViewAttacher.getMinimumScale(), x, y, true);
            }
        } catch (ArrayIndexOutOfBoundsException ex) {
        }
        return true;
    }

    public boolean onDoubleTapEvent(final MotionEvent e) {
        return false;
    }
}
