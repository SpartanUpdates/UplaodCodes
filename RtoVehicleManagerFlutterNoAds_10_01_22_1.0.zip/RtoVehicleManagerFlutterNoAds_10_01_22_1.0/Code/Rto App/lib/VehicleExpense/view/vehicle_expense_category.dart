import 'dart:math';
import 'package:date_picker_timeline/date_picker_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:rto_app/Home%20Screen/themes.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:rto_app/Utils/utils.dart';
import 'package:rto_app/VehicleExpense/controller/vehicle_expense_controller.dart';
import 'package:rto_app/VehicleExpense/model/vehicle_expense_model.dart';
import 'package:velocity_x/src/flutter/center.dart';
import 'package:velocity_x/src/flutter/padding.dart';
import 'package:velocity_x/src/flutter/widgets.dart';

class VehicleExpenseCategory extends StatelessWidget {
  static bool assesoriesSelected = true;
  static bool cleaningSelected = false;
  static bool carFuleSelected = false;
  static bool maintenanceSelected = false;
  static bool otherSelected = false;
  VehicleExpenseController controller = Get.put(VehicleExpenseController());

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Future.delayed(const Duration(milliseconds: 350), () {
          Navigator.pop(context);
        });
        return Future.value(false);
      },
      child: Material(
        child: SafeArea(
          child: Scaffold(
            body: NestedScrollView(
              physics: BouncingScrollPhysics(),
              floatHeaderSlivers: true,
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return <Widget>[
                  SliverAppBar(
                    backgroundColor: Theme.of(context).primaryColor,
                    title: Text(
                      "Expense Calculator",
                      style: TextStyle(
                          fontSize: 16.5,
                          color: MyThemes.bluishColor,
                          fontFamily: "Circular Bold"),
                    ).centered(),
                    leading: Container(
                      padding: EdgeInsets.all(10),
                      child: Material(
                        color: Colors.transparent,
                        shape: CircleBorder(),
                        clipBehavior: Clip.hardEdge,
                        child: IconButton(
                            padding: EdgeInsets.zero,
                            onPressed: () {
                              Future.delayed(const Duration(milliseconds: 350),
                                  () {
                                Navigator.pop(context);
                              });
                            },
                            icon: Hero(
                              tag: "vehicleexpense",
                              transitionOnUserGestures: true,
                              child: Icon(
                                Icons.arrow_back_ios_rounded,
                                color: Theme.of(context).dividerColor,
                                size: 20,
                              ).pOnly(left: 5),
                            )),
                      ),
                    ),
                    actions: [
                      IconButton(
                        onPressed: () {
                          Future.delayed(const Duration(milliseconds: 350), () {
                            Navigator.pop(context);
                            Navigator.pop(context);
                          });
                        },
                        icon: Hero(
                            tag: "rtooffice",
                            transitionOnUserGestures: true,
                            child: (Icon(
                              CupertinoIcons.home,
                              color: Theme.of(context).dividerColor,
                              size: 24,
                            ))),
                        iconSize: 30,
                      ).pOnly(right: 8),
                    ],
                  )
                ];
              },
              body: Column(
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.only(top: 15),
                      color: Theme.of(context).primaryColor,
                      child: Column(
                        children: [
                          SingleChildScrollView(
                            physics: BouncingScrollPhysics(),
                            scrollDirection: Axis.horizontal,
                            child: GetBuilder<VehicleExpenseController>(
                              builder: (controller) {
                                return Row(
                                  children: [
                                    Column(
                                      children: [
                                        SizedBox(
                                          child: Card(
                                            color:
                                                Theme.of(context).canvasColor,
                                            elevation: 0,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(35),
                                                side: BorderSide(
                                                    width: 1.5,
                                                    color: assesoriesSelected
                                                        ? Color(0xff6C629F)
                                                        : Theme.of(context)
                                                            .primaryColor)),
                                            child: InkWell(
                                              customBorder:
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              35)),
                                              onTap: () {
                                                controller.selectionMethod(1);
                                              },
                                              splashColor: Colors.black,
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    padding: EdgeInsets.all(10),
                                                    height: 65,
                                                    width: 65,
                                                    child: Image.asset(
                                                      "assets/images/assesories.png",
                                                      height: 25,
                                                      width: 25,
                                                    ).pOnly(right: 3),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ).px(10),
                                        ),
                                        Text("Assesorries\n& tunning",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontFamily:
                                                        "Circular Medium",
                                                    fontSize: 10,
                                                    color: Color(0xff6C629F)))
                                            .py(10)
                                      ],
                                    ).pOnly(left: 10),
                                    Column(
                                      children: [
                                        SizedBox(
                                          child: Card(
                                            color:
                                                Theme.of(context).canvasColor,
                                            elevation: 0,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(35),
                                                side: BorderSide(
                                                    width: 1.5,
                                                    color: cleaningSelected
                                                        ? Color(0xff6C629F)
                                                        : Theme.of(context)
                                                            .primaryColor)),
                                            child: InkWell(
                                              customBorder:
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              35)),
                                              onTap: () {
                                                controller.selectionMethod(2);
                                              },
                                              splashColor: Colors.black,
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    padding: EdgeInsets.all(10),
                                                    height: 65,
                                                    width: 65,
                                                    child: Image.asset(
                                                      "assets/images/cleaning.png",
                                                      height: 25,
                                                      width: 25,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ).px(10),
                                        ),
                                        Text("Cleaning\n& Comfort",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontFamily:
                                                        "Circular Medium",
                                                    fontSize: 10,
                                                    color: Color(0xff6C629F)))
                                            .py(10)
                                      ],
                                    ),
                                    Column(
                                      children: [
                                        SizedBox(
                                          child: Card(
                                            color:
                                                Theme.of(context).canvasColor,
                                            elevation: 0,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(35),
                                                side: BorderSide(
                                                    width: 1.5,
                                                    color: carFuleSelected
                                                        ? Color(0xff6C629F)
                                                        : Theme.of(context)
                                                            .primaryColor)),
                                            child: InkWell(
                                              customBorder:
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              35)),
                                              onTap: () {
                                                controller.selectionMethod(3);
                                              },
                                              splashColor: Colors.black,
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    padding: EdgeInsets.all(12),
                                                    height: 65,
                                                    width: 65,
                                                    child: Image.asset(
                                                      "assets/images/car_fuel.png",
                                                      height: 25,
                                                      width: 25,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ).px(10),
                                        ),
                                        Text("Car\nFuel",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontFamily:
                                                        "Circular Medium",
                                                    fontSize: 10,
                                                    color: Color(0xff6C629F)))
                                            .py(10)
                                      ],
                                    ),
                                    Column(
                                      children: [
                                        SizedBox(
                                          child: Card(
                                            color:
                                                Theme.of(context).canvasColor,
                                            elevation: 0,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(35),
                                                side: BorderSide(
                                                    width: 1.5,
                                                    color: maintenanceSelected
                                                        ? Color(0xff6C629F)
                                                        : Theme.of(context)
                                                            .primaryColor)),
                                            child: InkWell(
                                              customBorder:
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              35)),
                                              onTap: () {
                                                controller.selectionMethod(4);
                                              },
                                              splashColor: Colors.black,
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    padding: EdgeInsets.all(12),
                                                    height: 65,
                                                    width: 65,
                                                    child: Image.asset(
                                                      "assets/images/maintenance.png",
                                                      height: 25,
                                                      width: 25,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ).px(10),
                                        ),
                                        Text("Vehicle\nMaintenance",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontFamily:
                                                        "Circular Medium",
                                                    fontSize: 10,
                                                    color: Color(0xff6C629F)))
                                            .py(10)
                                      ],
                                    ),
                                    Column(
                                      children: [
                                        SizedBox(
                                          child: Card(
                                            color:
                                                Theme.of(context).canvasColor,
                                            elevation: 0,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(35),
                                                side: BorderSide(
                                                    width: 1.5,
                                                    color: otherSelected
                                                        ? Color(0xff6C629F)
                                                        : Theme.of(context)
                                                            .primaryColor)),
                                            child: InkWell(
                                              customBorder:
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              35)),
                                              onTap: () {
                                                controller.selectionMethod(5);
                                              },
                                              splashColor: Colors.black,
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    padding: EdgeInsets.all(8),
                                                    height: 65,
                                                    width: 65,
                                                    child: Image.asset(
                                                      "assets/images/other.png",
                                                      height: 25,
                                                      width: 25,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ).px(10),
                                        ),
                                        Text("Other\nExpense",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontFamily:
                                                        "Circular Medium",
                                                    fontSize: 10,
                                                    color: Color(0xff6C629F)))
                                            .py(10)
                                      ],
                                    ),
                                  ],
                                );
                              },
                            ),
                          ),
                          Calculator()
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class Calculator extends StatelessWidget {
  VehicleExpenseController controller = Get.put(VehicleExpenseController());
  TextEditingController itemController = TextEditingController();
  TextEditingController noteController = TextEditingController();
  TextEditingController amountController = TextEditingController();
  String selectedDate = DateTime.now().toString();
  DateTime preDate = DateTime.now().subtract(Duration(days: 2));
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
          child: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: GetBuilder<VehicleExpenseController>(
          builder: (controller) {
            return Column(
              children: [
                TextField(
                  cursorColor: Color(0xff6C629F),
                  style: TextStyle(
                      fontFamily: "Circular Medium",
                      fontSize: 20,
                      color: Theme.of(context).accentColor),
                  autofocus: false,
                  controller: itemController,
                  onChanged: (value) {
                    if (value.isEmpty) {
                      controller.itemValidation(true);
                    } else {
                      controller.itemValidation(false);
                    }
                  },
                  decoration: InputDecoration(
                      focusedBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Color(0xff6C629F), width: 0.3),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Color(0xff6C629F), width: 0.3),
                      ),
                      border: const OutlineInputBorder(),
                      labelText: " Payee / Item Name ",
                      labelStyle: TextStyle(
                          fontFamily: "Circular Medium",
                          fontSize: 17,
                          color: Theme.of(context).indicatorColor),
                      hintStyle: TextStyle(
                          fontFamily: "Circular Medium",
                          fontSize: 20,
                          color: Theme.of(context).indicatorColor),
                      hintText: "example : new car tyre",
                      errorStyle: TextStyle(
                          fontFamily: "Circular Medium",
                          fontSize: 10,
                          color: Colors.redAccent),
                      errorText: controller.itemError),
                  //controller: controller,
                ).px(5).pOnly(top: 5),
                TextField(
                  cursorColor: Color(0xff6C629F),
                  style: TextStyle(
                      fontFamily: "Circular Medium",
                      fontSize: 20,
                      color: Theme.of(context).accentColor),
                  autofocus: false,
                  controller: noteController,
                  onChanged: (value) {
                    if (value.isEmpty) {
                      controller.noteValidation(true);
                    } else {
                      controller.noteValidation(false);
                    }
                  },
                  decoration: InputDecoration(
                      focusedBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Color(0xff6C629F), width: 0.3),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Color(0xff6C629F), width: 0.3),
                      ),
                      border: const OutlineInputBorder(),
                      labelText: " Write a note ",
                      labelStyle: TextStyle(
                          fontFamily: "Circular Medium",
                          fontSize: 17,
                          color: Theme.of(context).indicatorColor),
                      hintStyle: TextStyle(
                          fontFamily: "Circular Medium",
                          fontSize: 20,
                          color: Theme.of(context).indicatorColor),
                      hintText: "ex : bought tyre from MRF",
                      errorStyle: TextStyle(
                          fontFamily: "Circular Medium",
                          fontSize: 10,
                          color: Colors.redAccent),
                      errorText: controller.noteError),
                  //controller: controller,
                ).px(5).py(15),
                Container(
                  height: 100,
                  child: DatePicker(
                    preDate,
                    initialSelectedDate: DateTime.now(),
                    selectionColor: Theme.of(context).canvasColor,
                    selectedTextColor: Colors.blueGrey,
                    dayTextStyle: TextStyle(
                        color: Colors.grey, fontFamily: "Circular Medium"),
                    dateTextStyle: TextStyle(
                        color: Colors.grey, fontFamily: "Circular Medium"),
                    monthTextStyle: TextStyle(
                        color: Colors.grey, fontFamily: "Circular Medium"),
                    onDateChange: (date) {
                      selectedDate = date.toString();
                    },
                  ),
                ).px(2),
                TextField(
                  cursorColor: Color(0xff6C629F),
                  style: TextStyle(
                      fontFamily: "Circular Medium",
                      fontSize: 20,
                      color: Theme.of(context).accentColor),
                  autofocus: false,
                  keyboardType: TextInputType.number,
                  inputFormatters: [WhitelistingTextInputFormatter.digitsOnly],
                  controller: amountController,
                  onChanged: (value) {
                    if (value.isEmpty) {
                      controller.amountValidation(true);
                    } else {
                      controller.amountValidation(false);
                    }
                  },
                  decoration: InputDecoration(
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: Color(0xff6C629F), width: 0.3),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: Color(0xff6C629F), width: 0.3),
                    ),
                    border: const OutlineInputBorder(),
                    labelText: " Amount ",
                    labelStyle: TextStyle(
                        fontFamily: "Circular Medium",
                        fontSize: 17,
                        color: Theme.of(context).indicatorColor),
                    hintStyle: TextStyle(
                        fontFamily: "Circular Medium",
                        fontSize: 20,
                        color: Theme.of(context).indicatorColor),
                    hintText: "ex : 1200",
                    errorStyle: TextStyle(
                        fontFamily: "Circular Medium",
                        fontSize: 10,
                        color: Colors.redAccent),
                    errorText: controller.amountError,
                  ),
                  //controller: controller,
                ).px(5).pOnly(top: 15, bottom: 5),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 45,
                      width: 130,
                      child: Material(
                        color: Theme.of(context).canvasColor,
                        child: Ink(
                          decoration: BoxDecoration(),
                          child: InkWell(
                            customBorder: RoundedRectangleBorder(
                                borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(8),
                                    bottomRight: Radius.circular(8))),
                            splashColor: Colors.black,
                            onTap: () {
                              Random random = new Random();
                              int randomNumber = random.nextInt(1000);

                              String day = selectedDate.substring(8, 10);
                              String month = selectedDate.substring(5, 7);
                              String year = selectedDate.substring(0, 4);
                              int selected = controller.selectedType;

                              if (itemController.text.isEmpty) {
                                controller.itemValidation(true);
                              } else {
                                controller.itemValidation(false);
                              }

                              if (noteController.text.isEmpty) {
                                controller.noteValidation(true);
                              } else {
                                controller.noteValidation(false);
                              }

                              if (amountController.text.isEmpty) {
                                controller.amountValidation(true);
                              } else {
                                controller.amountValidation(false);
                              }

                              if (controller.itemError == null &&
                                  controller.noteError == null &&
                                  controller.amountError == null) {
                                FocusScope.of(context).unfocus();
                                controller
                                    .insert(VehicleExpenseModel(
                                        randomId: randomNumber.toString(),
                                        date: "${day} - ${month} - ${year}",
                                        itemName: itemController.text,
                                        note: noteController.text,
                                        amount: amountController.text,
                                        type: selected.toString()))
                                    .then((value) {})
                                    .onError((error, stackTrace) {});
                                controller.getDateWiseData();
                                controller.getAllData();
                                Navigator.pop(context);
                              }
                              if (Links.rateDialog) {
                                Links.rateDialog = false;
                                CommanDialog.showRatingDialog(context);
                              }
                            },
                            child: Center(
                              child: Text(
                                "Save",
                                style: TextStyle(
                                    color: Theme.of(context).accentColor,
                                    fontFamily: "Circular Medium"),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ).cornerRadius(8).pOnly(left: 10, right: 10).py(15),
                    Container(
                      height: 45,
                      width: 130,
                      child: Material(
                        color: Theme.of(context).canvasColor,
                        child: Ink(
                          decoration: BoxDecoration(),
                          child: InkWell(
                            customBorder: RoundedRectangleBorder(
                                borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(8),
                                    bottomRight: Radius.circular(8))),
                            splashColor: Colors.black,
                            onTap: () {
                              Get.back();
                            },
                            child: Center(
                              child: Text(
                                "Cancel",
                                style: TextStyle(
                                    color: Theme.of(context).accentColor,
                                    fontFamily: "Circular Medium"),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ).cornerRadius(8).pOnly(left: 10, right: 10).py(15),
                  ],
                )
              ],
            );
          },
        ),
      )).py(20).px(20),
    );
  }
}
