package com.kotlinz.vehiclemanager.history.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.history.Model.LicenseHistory;
import com.kotlinz.vehiclemanager.history.Room.HistoryDatabase;
import com.kotlinz.vehiclemanager.utils.DarkTheame;

import java.util.List;

public class LicenseHistoryAdapter extends RecyclerView.Adapter<LicenseHistoryAdapter.ViewHolder> {
    Context context;
    List<LicenseHistory> licenseHistoryList;
    DarkTheame darkTheame;

    public LicenseHistoryAdapter(Context context, List<LicenseHistory> licenseHistoryList) {
        this.context = context;
        this.licenseHistoryList = licenseHistoryList;
        this.darkTheame = new DarkTheame(context);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout ll_main;
        TextView tv_ownerName, tv_ownerVehicleNumber;
        ImageView iv_delete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ll_main = itemView.findViewById(R.id.ll_main);
            tv_ownerName = itemView.findViewById(R.id.tv_OwnerName);
            tv_ownerVehicleNumber = itemView.findViewById(R.id.tv_OwnerVehicleNumber);
            iv_delete = itemView.findViewById(R.id.iv_delete);
        }
    }

    private void deleteItem(int position2) {
        licenseHistoryList.remove(position2);
        notifyItemRemoved(position2);
        notifyItemRangeChanged(position2, licenseHistoryList.size());
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        int nightModeFlags = context.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            holder.ll_main.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
            holder.iv_delete.setImageResource(R.drawable.ic_delete_selector_dark);
        }
        if (darkTheame.modeData().equals("nightMode")) {
            holder.ll_main.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
            holder.iv_delete.setImageResource(R.drawable.ic_delete_selector_dark);
        }
        final LicenseHistory licenseHistory = licenseHistoryList.get(position);
        holder.tv_ownerVehicleNumber.setText(licenseHistory.getLicenseNo());
        holder.tv_ownerName.setText(licenseHistory.getHolderName());

        holder.iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem(position);
                HistoryDatabase.getDatabase(context).licenseHistoryDao().deleteOwnerDetails(licenseHistory.getLicenseNo());
            }
        });
        holder.ll_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  Intent intent = new Intent(context, VehicleLicenseActivity.class);
                intent.putExtra("licenseNumber", licenseHistory.getLicenseNo());
                intent.putExtra("licenseHolderName", licenseHistory.getHolderName());
                intent.putExtra("licenseDob", licenseHistory.getDob());
                intent.putExtra("dateOfIssue", licenseHistory.getDateOfIssue());
                intent.putExtra("currentStatus", licenseHistory.getCurrentStatus());
                intent.putExtra("lastTransactionAt", licenseHistory.getLastTransactionAt());
                intent.putExtra("validFrom", licenseHistory.getValidFrom());
                intent.putExtra("validTo", licenseHistory.getValidTo());
                intent.putExtra("vehicleClass", licenseHistory.getVehicleClass());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);*/
            }
        });
    }

    @Override
    public int getItemCount() {
        return licenseHistoryList.size();
    }
}
