package com.mbit.VideoMaker.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdsManager;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Fragment.CategoryWiseThemeFragment;
import com.mbit.VideoMaker.Model.CategoryModel;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.UnityPlayerActivity;
import com.mbit.VideoMaker.View.NonSwipeableViewPager;
import com.mbit.VideoMaker.application.MyApplication;
import com.root.bridge.AppUsages;
import com.unity3d.player.UnityPlayer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    public final String[] NECESSARY_PERMISSIONS = {
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",};
    private final long RIPPLE_DURATION = 250;
    private final int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
    private final int REQUEST_PERMISSION_SETTING = 101;
    public ActionBarDrawerToggle mDrawerToggle;
    public InterstitialAd mInterstitialAd;
    public int id;
    public String AllPath;
    public String ThemeCategoryWiseDataUrl = com.mbit.VideoMaker.View.a.ThemeCategoryWiseDataUrl;
    public String ThemeCategoryUrl = com.mbit.VideoMaker.View.a.ThemeCategoryUrl;
    public String DownloadCountUrl = com.mbit.VideoMaker.View.a.DownloadCountUrl;
    public NativeAdsManager mAdsManager;
    Activity activity = HomeActivity.this;
    Integer AppId = 49;
    ArrayList<CategoryModel> tabcategorylist = new ArrayList<>();
    String offlienResopnseData;
    SharedPreferences ThemeCategoryPreference;
    String MY_PREF = "Cat_home_preference";
    ImageView ivSetting, ivMycreation;
    RelativeLayout rlLoading;
    LinearLayout llRetry;
    LinearLayout layoutSetting, layoutMycreation;
    Button btnRetry;
    ImageView ivNavDrawer;
    TextView tvtitle;
    ImageButton ibCreate;
    PagerAdapterNew adp;
    private DrawerLayout mDrawerLayout;
    private TabLayout tabLayout;
    private NonSwipeableViewPager viewPager;
    private boolean sentToSettings = false;
    private SharedPreferences permissionStatus;
    private boolean IsofflineResopnse = false;
    private LinearLayout adContainer;
    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ThemeCategoryPreference = getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
        permissionStatus = getSharedPreferences("permissionStatus", MODE_PRIVATE);
        AppUsages.loadFFMpeg(activity);
        GetThemeUrl();
        loadAd();
        InterstitialAd();
        initNativeAds();
        BindView();
        SetListener();
        RuntimePremission();
        if (ThemeCategoryPreference.getBoolean("themecatfirsttime", true)) {
            if (Utils.checkConnectivity(activity, false)) {
                ThemeCategoryPreference.edit().putBoolean("themecatfirsttime", false).apply();
                new GetTabCategory().execute(ThemeCategoryUrl, String.valueOf(AppId));
            } else {
                llRetry.setVisibility(View.VISIBLE);
                Toast.makeText(activity, "No Internet Connecation !", Toast.LENGTH_LONG).show();
            }
        } else {
            if (Utils.checkConnectivity(activity, false)) {
                new GetTabCategory().execute(ThemeCategoryUrl, String.valueOf(AppId));
            } else {
                IsofflineResopnse = true;
                new GetTabCategory().execute(ThemeCategoryUrl, String.valueOf(AppId));
            }
        }
    }

    private void HideShowUnityBannerAds() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 3000);
    }

    private int getCatIcon(String str) {
        str = str.toLowerCase();
        return str.contains("love") ? R.drawable.icon_love : str.contains("festival") ? R.drawable.icon_festival : str.contains("krishna") ? R.drawable.icon_radhe_krishna : str.contains("ganesha") ? R.drawable.icon_ganesha : str.contains("balaji") ? R.drawable.icon_jay_balaji : str.contains("mahadev") ? R.drawable.icon_mahadev : str.contains("premium") ? R.drawable.icon_premium : str.contains("birthday") ? R.drawable.icon_birthday : str.contains("god") ? R.drawable.icon_gods : str.contains("shree ram") ? R.drawable.icon_shree_ram : str.contains("wedding") ? R.drawable.icon_wedding : str.contains("wish") ? R.drawable.icon_wish : str.contains("popular") ? R.drawable.icon_premium : str.contains("telugu") ? R.drawable.icon_telugu : str.contains("tamil") ? R.drawable.icon_tamil : str.contains("bhojpuri") ? R.drawable.icon_bhojpuri : str.contains("diwali") ? R.drawable.icon_diwali : str.contains("english") ? R.drawable.icon_eng : str.contains("friendship") ? R.drawable.icon_friendship : str.contains("gujarati") ? R.drawable.icon_gujarati : str.contains("hindi") ? R.drawable.icon_hindi : str.contains("kannada") ? R.drawable.icon_kannada : str.contains("malayalam") ? R.drawable.icon_malayalam : str.contains("marathi") ? R.drawable.icon_marathi : str.contains("navratri") ? R.drawable.icon_navratri : str.contains("sad") ? R.drawable.icon_sad : R.drawable.icon_defualt;
    }


    private void loadAd() {
        adContainer = findViewById(R.id.templateContainer);
        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
        adContainer.addView(adView);
        adView.loadAd();
    }


    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(this, getString(R.string.FB_inter));
        mInterstitialAd.setAdListener(new InterstitialAdListener() {

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }

            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                switch (id) {
                    case 100:
                        UnityPlayer.UnitySendMessage("CategoryManagement", "OnLoadUserData", AllPath);
                        HideShowUnityBannerAds();
                        finish();
                        break;
                    case 101:
                        GoToMyCreation();
                        break;
                }
            }
        });
        mInterstitialAd.loadAd();
    }

    public void initNativeAds() {
        mAdsManager = new NativeAdsManager(HomeActivity.this, getResources().getString(R.string.FB_Native), 8);
        mAdsManager.loadAds();
        mAdsManager.setListener(new NativeAdsManager.Listener() {
            @Override
            public void onAdsLoaded() {
                MyApplication.getInstance().IsNativeAdsLoaded = true;
            }

            @Override
            public void onAdError(AdError adError) {

            }
        });
    }

    private void BindView() {
        mDrawerLayout = findViewById(R.id.drawer_layout);
        ibCreate = findViewById(R.id.ibCreate);
        ivNavDrawer = findViewById(R.id.iv_navDrawer);
        tvtitle = findViewById(R.id.tvName);
        ivSetting = findViewById(R.id.ivSetting);
        ivMycreation = findViewById(R.id.ivMyCreation);
        rlLoading = findViewById(R.id.rl_loading_pager);
        layoutSetting = findViewById(R.id.layout_setting);
        layoutMycreation = findViewById(R.id.layout_mycreation);
        tabLayout = findViewById(R.id.mTabLayout);
        viewPager = findViewById(R.id.mViewPager);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);
        NavigationView navigationView = findViewById(R.id.nav_view);
        layoutSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.openDrawer(Gravity.START);
            }
        });
        layoutMycreation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mInterstitialAd != null && mInterstitialAd.isAdLoaded()) {
                    id = 101;
//                    MyApplication.ShowDialog(activity);
                    MyApplication.ShowDialog(activity, mInterstitialAd);
//                    mInterstitialAd.show();
                } else {
                    GoToMyCreation();
                }
            }
        });
        ivNavDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.openDrawer(Gravity.START);
            }
        });


        ibCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectImage(activity, 1);
            }
        });
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, null, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);

    }

    private void GoToMyCreation() {
        Intent intent = new Intent(activity, MyVideoActivity.class);
        startActivity(intent);
        finish();

    }

    private void GetThemeUrl() {
        if (ThemeCategoryPreference.getString("Themecat", "Themecatfirsttime").equals("Themecatfirsttime")) {
            SharedPreferences.Editor edit = ThemeCategoryPreference.edit();
            edit.putString("Themecat", "ok");
            edit.putString("caturl", ThemeCategoryUrl);
            edit.putString("catWiseDataurl", ThemeCategoryWiseDataUrl);
            edit.apply();
        } else if (ThemeCategoryPreference.getString("Themecat", null).equals("ok")) {
            ThemeCategoryUrl = (ThemeCategoryPreference.getString("caturl", ""));
            ThemeCategoryWiseDataUrl = (ThemeCategoryPreference.getString("catWiseDataurl", ""));
        }
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(activity, false)) {
                    llRetry.setVisibility(View.GONE);
                    startActivity(new Intent(activity, HomeActivity.class));
                    finish();
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    private void SetOfflineCategory(Context c, String userObject, String key) {
        SharedPreferences pref = PreferenceManager
                .getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    private void getOfflineCategory(Context ctx, String key) {
        SharedPreferences pref = PreferenceManager
                .getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
    }


    public void RequiredPermission(String alertmessage) {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        RuntimePremission();
                        break;
                    case DialogInterface.BUTTON_NEGATIVE:
                        dialog.dismiss();
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Allow Permission");
        builder.setMessage(alertmessage)
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }

    public void RuntimePremission() {
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("Need Storage Permission");
                builder.setMessage("This app needs storage permission.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            } else if (permissionStatus.getBoolean(Manifest.permission.WRITE_EXTERNAL_STORAGE, false)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("Need Storage Permission");
                builder.setMessage("Beats needs storage permission.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        sentToSettings = true;
                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        Uri uri = Uri.fromParts("package", activity.getPackageName(), null);
                        intent.setData(uri);
                        activity.startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            } else {
                //just request the permission
                ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
            }
            SharedPreferences.Editor editor = permissionStatus.edit();
            editor.putBoolean(Manifest.permission.WRITE_EXTERNAL_STORAGE, true);
            editor.apply();

        } else {
            Log.e("Permission", "You already have the permission, just go ahead.");
        }

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == EXTERNAL_STORAGE_PERMISSION_CONSTANT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Utils.CreateDirectory();
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    //Show Information about why you need the permission
                    AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                    builder.setTitle("Need Storage Permission");
                    builder.setMessage("Beats needs storage permission");
                    builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    builder.show();
                } else {
                    Toast.makeText(getBaseContext(), "Unable to get Permission", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Utils.CreateDirectory();
            }
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        displaySelectedScreen(menuItem.getItemId());
        return true;
    }

    private void displaySelectedScreen(int itemId) {
        switch (itemId) {
            case R.id.nav_my_movie:
                Intent intent = new Intent(activity, MyVideoActivity.class);
                startActivity(intent);
                finish();
                break;
            case R.id.nav_feddback:
                Intent intent2 = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", getResources().getString(R.string.feedback_email), null));
                intent2.putExtra("android.intent.extra.SUBJECT", "Feedback");
                intent2.putExtra("android.intent.extra.TEXT", "Write your feedback here");
                startActivity(Intent.createChooser(intent2, "Send email..."));
                break;
            case R.id.nav_rate_us:
                RateApp();
                break;
            case R.id.nav_invite:
                ShareAPP();
                break;
            case R.id.nav_privacy:
                Intent intent1 = new Intent("android.intent.action.VIEW");
                intent1.setData(Uri.parse(getResources().getString(R.string.privacy_link)));
                break;
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    public void SelectImage(Context cntx, int NoofImage) {
        MyApplication.IsSelectImageFrom = true;
        MyApplication.IS_EDITIMAGE = 0;
        MyApplication.TotalSelectedImage = NoofImage;
        MyApplication.getInstance().getSelectedImageslist().clear();
        MyApplication.getInstance().getCropImages().clear();
        Intent intent = new Intent(cntx, ImageSelectActivity.class);
        intent.putExtra("NoofImage", NoofImage);
        startActivity(intent);
        finish();
    }


    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    private void ShareAPP() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Beats");
            String shareMessage = "\nGet free Beats at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(this, ExitActivity.class));
        finish();
    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
            View customView = tab.getCustomView();
            if (tab.getPosition() == 0) {
                ((TextView) customView.findViewById(R.id.tvThemeName)).setTextColor(getResources().getColor(R.color.black));
            }
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.tvThemeName)).setTextColor(getResources().getColor(R.color.black));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.tvThemeName)).setTextColor(getResources().getColor(R.color.black));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    ((TextView) customView.findViewById(R.id.tvThemeName)).setTextColor(getResources().getColor(R.color.black));
                }
            }
        });
    }

    private void setUpPagerNew() {
        adp = new PagerAdapterNew(getSupportFragmentManager());
        for (int i = 0; i < tabcategorylist.size(); i++) {
            adp.addFrag(CategoryWiseThemeFragment.newInstance(Integer.parseInt(tabcategorylist.get(i).getThemeId()), Integer.parseInt(tabcategorylist.get(i).getAppid())), tabcategorylist.get(i).getName());
        }
        viewPager.setAdapter(adp);
        tabLayout.setupWithViewPager(viewPager);
    }

    private class PagerAdapterNew extends FragmentPagerAdapter {
        List<Fragment> fragList = new ArrayList<>();
        List<String> titleList = new ArrayList<>();

        public PagerAdapterNew(FragmentManager fm) {
            super(fm);
        }

        public void addFrag(Fragment f, String title) {
            fragList.add(f);
            titleList.add(title);
        }

        @Override
        public Fragment getItem(int position) {
            return fragList.get(position);
        }

        @Override
        public int getCount() {
            return fragList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titleList.get(position);
        }

        public View getTabView(int position) {
            View tabCatView = LayoutInflater.from(activity).inflate(
                    R.layout.row_category_item, null);
            TextView tv = tabCatView.findViewById(R.id.tvThemeName);
            ImageView ivIcon = tabCatView.findViewById(R.id.ivIcon);
            tv.setText(tabcategorylist.get(position).getName());
            ivIcon.setImageResource(tabcategorylist.get(position).getCatIcon());
            return tabCatView;
        }
    }

    @SuppressLint("StaticFieldLeak")
    public class GetTabCategory extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
            rlLoading.setVisibility(View.VISIBLE);
        }

        protected String doInBackground(String... arg0) {
            try {
                URL url = new URL(arg0[0]);
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("app_id", arg0[1]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(Utils.INSTANCE.getPostDataString(postDataParams));
                writer.flush();
                writer.close();
                os.close();
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuffer sb = new StringBuffer();
                    String line = "";
                    while ((line = in.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    in.close();
                    return sb.toString();
                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject jsonObj;
                    if (IsofflineResopnse) {
                        getOfflineCategory(activity, "ThemeCategory");
                        jsonObj = new JSONObject(offlienResopnseData);
                    } else {
                        jsonObj = new JSONObject(result);
                        SetOfflineCategory(activity, jsonObj.toString(), "ThemeCategory");
                    }
                    JSONArray tabcategory = jsonObj.getJSONArray("data");
                    for (int i = 0; i < tabcategory.length(); i++) {
                        JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                        CategoryModel categoryModel = new CategoryModel();
                        categoryModel.setThemeId(tabcategoryJSONObject.getString("main_id"));
                        categoryModel.setCatIcon(getCatIcon(tabcategoryJSONObject.getString("main_category_name")));
                        categoryModel.setName(tabcategoryJSONObject.getString("main_category_name"));
                        categoryModel.setAppid(tabcategoryJSONObject.getString("main_application_id"));
                        tabcategorylist.add(categoryModel);
                    }

                    setUpPagerNew();
                    SetTabLayout();
                    rlLoading.setVisibility(View.GONE);
                } catch (final JSONException e) {
                    e.printStackTrace();
                }
            } else {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(activity, "Couldn't get json from server. Check LogCat for possible errors!", Toast.LENGTH_LONG).show();
                    }
                });
            }
        }
    }
}
