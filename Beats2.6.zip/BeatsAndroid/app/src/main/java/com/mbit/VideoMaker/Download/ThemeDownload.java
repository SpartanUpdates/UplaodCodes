package com.mbit.VideoMaker.Download;


import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.liulishuo.okdownload.DownloadTask;
import com.liulishuo.okdownload.SpeedCalculator;
import com.liulishuo.okdownload.StatusUtil;
import com.liulishuo.okdownload.core.Util;
import com.liulishuo.okdownload.core.breakpoint.BlockInfo;
import com.liulishuo.okdownload.core.breakpoint.BreakpointInfo;
import com.liulishuo.okdownload.core.cause.EndCause;
import com.liulishuo.okdownload.core.listener.DownloadListener4WithSpeed;
import com.liulishuo.okdownload.core.listener.assist.Listener4SpeedAssistExtend;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Model.ThemelModel;

import java.io.File;
import java.util.List;
import java.util.Map;


public class ThemeDownload {
    public static DownloadTask ImageDownloadTask;
    public static DownloadTask SongDownloadTask;
    public static boolean IsAudioDownload = false;
    ImageView ivDownload;
    TextView tvUseTheme;
    LinearLayout llThemeProgress;
    RelativeLayout layoutInfo;
    TextView tvThemeDownProgress;
    ThemelModel themelModel;
    private Context context;
    private String ImageName;
    private String AudioName;


    public ThemeDownload(Context context, String AudioUrl, String AudioName, int Audiosize, String ImageUrl, String ImageName, ImageView ivDownload, TextView tvUseTheme, RelativeLayout layoutInfo, LinearLayout rlThemeProgress, TextView tvThemeDownProgress, ThemelModel themelModel) {
        this.context = context;
        this.ImageName = ImageName;
        this.tvUseTheme=tvUseTheme;
        this.layoutInfo=layoutInfo;
        this.tvThemeDownProgress = tvThemeDownProgress;
        this.AudioName = AudioName;
        this.themelModel = themelModel;
        this.ivDownload = ivDownload;
        this.llThemeProgress = rlThemeProgress;
        initTaskImage(ImageUrl);
        initStatusImage();
        initActionImage();
        String filename = AudioUrl.substring(AudioUrl.lastIndexOf('/') + 1);
        if (new File(Environment.getExternalStorageDirectory() + File.separator + "Beats" + File.separator + ".ThemeDownload" + File.separator + filename).exists()) {
            File file = new File(Environment.getExternalStorageDirectory() + File.separator + "Beats" + File.separator + ".ThemeDownload" + File.separator + filename);
            int filesize = Integer.parseInt(String.valueOf(file.length()));
            if (filesize == Audiosize) {
            } else {
                initTaskSong(AudioUrl);
                initStatusSong();
                initActionSong();
            }
        } else {
            initTaskSong(AudioUrl);
            initStatusSong();
            initActionSong();
        }
    }

    private void initTaskSong(String URL) {
        themelModel.isDownloading = true;
        themelModel.isAvailableOffline = false;
        final File parentFile = new File(Environment.getExternalStorageDirectory() + File.separator + "Beats" + File.separator + ".ThemeDownload");
        SongDownloadTask = new DownloadTask.Builder(URL, parentFile)
                .setFilename(AudioName)
                .setMinIntervalMillisCallbackProcess(16)
                .setPassIfAlreadyCompleted(false)
                .build();

    }

    private void initStatusSong() {
        final StatusUtil.Status status = StatusUtil.getStatus(SongDownloadTask);
        if (status == StatusUtil.Status.COMPLETED) {
        }

        final BreakpointInfo info = StatusUtil.getCurrentInfo(SongDownloadTask);
        if (info != null) {
            Log.d("TAG", "Song init status with: " + info.toString());
        }
    }

    private void initActionSong() {
        final boolean started = SongDownloadTask.getTag() != null;
        if (started) {
            SongDownloadTask.cancel();
        } else {
            startTask();
            SongDownloadTask.setTag("mark-SongDownloadTask-started");
        }
    }

    private void startTask() {
        SongDownloadTask.enqueue(new DownloadListener4WithSpeed() {
            private long totalLength;
            private String readableTotalLength;

            @Override
            public void taskStart(@NonNull DownloadTask task) {
            }

            @Override
            public void infoReady(@NonNull DownloadTask task, @NonNull BreakpointInfo info,
                                  boolean fromBreakpoint,
                                  @NonNull Listener4SpeedAssistExtend.Listener4SpeedModel model) {
                totalLength = info.getTotalLength();
                readableTotalLength = Util.humanReadableBytes(totalLength, true);
            }

            @Override
            public void connectStart(@NonNull DownloadTask task, int blockIndex,
                                     @NonNull Map<String, List<String>> requestHeaders) {
            }

            @Override
            public void connectEnd(@NonNull DownloadTask task, int blockIndex, int responseCode,
                                   @NonNull Map<String, List<String>> responseHeaders) {
            }

            @Override
            public void progressBlock(@NonNull DownloadTask task, int blockIndex,
                                      long currentBlockOffset,
                                      @NonNull SpeedCalculator blockSpeed) {

            }

            @Override
            public void progress(@NonNull DownloadTask task, long currentOffset,
                                 @NonNull SpeedCalculator taskSpeed) {
                int percentage = (int) (currentOffset * 100 / totalLength);
                tvThemeDownProgress.setText(String.valueOf(percentage + "%"));
            }

            @Override
            public void blockEnd(@NonNull DownloadTask task, int blockIndex, BlockInfo info,
                                 @NonNull SpeedCalculator blockSpeed) {
            }

            @Override
            public void taskEnd(@NonNull DownloadTask task, @NonNull EndCause cause,
                                @Nullable Exception realCause,
                                @NonNull SpeedCalculator taskSpeed) {
                task.setTag(null);
                if (cause == EndCause.CANCELED) {
                    themelModel.isDownloading = false;
                    themelModel.isAvailableOffline = false;
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + task.getFilename());
                } else if (cause == EndCause.ERROR) {
                    themelModel.isDownloading = false;
                    themelModel.isAvailableOffline = false;
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + task.getFilename());
                }
                if (AudioName.equals(task.getFilename())) {
                    if (cause == EndCause.COMPLETED) {
                        themelModel.isDownloading = false;
                        themelModel.isAvailableOffline = true;
                        ivDownload.setVisibility(View.GONE);
                        llThemeProgress.setVisibility(View.GONE);
                        tvUseTheme.setVisibility(View.VISIBLE);
                        layoutInfo.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
    }


    private void initTaskImage(String URL) {
        final File parentFile = new File(Environment.getExternalStorageDirectory() + File.separator + "Beats" + File.separator + ".ThemeDownload");
        ImageDownloadTask = new DownloadTask.Builder(URL, parentFile)
                .setFilename(ImageName)
                .setMinIntervalMillisCallbackProcess(16)
                .setPassIfAlreadyCompleted(false)
                .build();

    }

    private void initStatusImage() {
        final StatusUtil.Status status = StatusUtil.getStatus(ImageDownloadTask);
        if (status == StatusUtil.Status.COMPLETED) {
        }
        final BreakpointInfo info = StatusUtil.getCurrentInfo(ImageDownloadTask);
        if (info != null) {
        }
    }

    private void initActionImage() {
        final boolean started = ImageDownloadTask.getTag() != null;
        if (started) {
            ImageDownloadTask.cancel();
        } else {
            startTaskAudio();
            ImageDownloadTask.setTag("mark-ImageDownloadTask-started");
        }
    }

    private void startTaskAudio() {
        ImageDownloadTask.enqueue(new DownloadListener4WithSpeed() {
            private long totalLength;
            private String readableTotalLength;

            @Override
            public void taskStart(@NonNull DownloadTask task) {
            }

            @Override
            public void infoReady(@NonNull DownloadTask task, @NonNull BreakpointInfo info,
                                  boolean fromBreakpoint,
                                  @NonNull Listener4SpeedAssistExtend.Listener4SpeedModel model) {
                totalLength = info.getTotalLength();
                readableTotalLength = Util.humanReadableBytes(totalLength, true);
            }

            @Override
            public void connectStart(@NonNull DownloadTask task, int blockIndex,
                                     @NonNull Map<String, List<String>> requestHeaders) {
            }

            @Override
            public void connectEnd(@NonNull DownloadTask task, int blockIndex, int responseCode,
                                   @NonNull Map<String, List<String>> responseHeaders) {
            }

            @Override
            public void progressBlock(@NonNull DownloadTask task, int blockIndex,
                                      long currentBlockOffset,
                                      @NonNull SpeedCalculator blockSpeed) {

            }

            @Override
            public void progress(@NonNull DownloadTask task, long currentOffset,
                                 @NonNull SpeedCalculator taskSpeed) {
                int percentage = (int) (currentOffset * 100 / totalLength);
                Intent broadcastIntent = new Intent();
                broadcastIntent.setAction("Image");
                broadcastIntent.putExtra("progress", (int) percentage);
                context.sendBroadcast(broadcastIntent);
                if (percentage == 100) {
                    IsAudioDownload = true;
                }
            }

            @Override
            public void blockEnd(@NonNull DownloadTask task, int blockIndex, BlockInfo info,
                                 @NonNull SpeedCalculator blockSpeed) {
            }

            @Override
            public void taskEnd(@NonNull DownloadTask task, @NonNull EndCause cause,
                                @Nullable Exception realCause,
                                @NonNull SpeedCalculator taskSpeed) {
                task.setTag(null);
                if (cause == EndCause.CANCELED) {
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + task.getFilename());
                } else if (cause == EndCause.ERROR) {
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + task.getFilename());
                }
                if (cause == EndCause.COMPLETED) {
                }
            }
        });
    }

    private void DeleteFileIfInterupt(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            file.delete();
        }
    }
}
