package com.olokobayusuf.natrender;

import java.nio.*;

public final class Unmanaged
{
    public static final native void copyFrame(final long p0, final int p1, final int p2, final int p3, final long p4);
    
    public static final native long baseAddress(final ByteBuffer p0);
    
    static {
        System.loadLibrary("NatRender");
    }
}
