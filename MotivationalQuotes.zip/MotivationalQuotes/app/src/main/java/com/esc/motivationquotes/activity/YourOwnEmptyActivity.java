package com.esc.motivationquotes.activity;

import android.content.res.ColorStateList;
import android.os.Bundle;
import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;

import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.esc.motivationquotes.R;
import com.esc.motivationquotes.managers.SettingsManager;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class YourOwnEmptyActivity extends BaseActivity {
    private ImageView ivClose;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_your_own_empty);
        bindUI();
        setListeners();
        setTheme();
        loadDarkMode();
        loadAd();
    }

    private void setTheme() {
        ImageViewCompat.setImageTintList(this.ivClose, ColorStateList.valueOf(ContextCompat.getColor(this, R.color.textColorDark)));
    }

    private void bindUI() {
        this.ivClose = (ImageView) findViewById(R.id.iv_back);
    }

    private void setListeners() {
        this.ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void loadDarkMode() {
        if (SettingsManager.isDarkMode().booleanValue()) {
            ImageViewCompat.setImageTintList(this.ivClose, ColorStateList.valueOf(ContextCompat.getColor(this, R.color.color_white)));
        }
    }

    private FrameLayout adContainerView;
    private AdView adView;

    private void loadAd() {
        //AdaptiveBannerAd
        adContainerView = findViewById(R.id.ad_view_container);
        adView = new AdView(this);
        adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
        adContainerView.addView(adView);

        AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();

        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(adRequest);
    }

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }
}
