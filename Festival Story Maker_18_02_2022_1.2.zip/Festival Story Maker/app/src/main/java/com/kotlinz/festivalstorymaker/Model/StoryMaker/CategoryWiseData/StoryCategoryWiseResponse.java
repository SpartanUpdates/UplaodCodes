package com.kotlinz.festivalstorymaker.Model.StoryMaker.CategoryWiseData;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class StoryCategoryWiseResponse {

	@SerializedName("data")
	private ArrayList<StoryCategoryWiseData> data;

	@SerializedName("total_records")
	private int totalRecords;

	@SerializedName("status")
	private String status;

	public ArrayList<StoryCategoryWiseData> getData(){
		return data;
	}

	public int getTotalRecords(){
		return totalRecords;
	}

	public String getStatus(){
		return status;
	}
}