package com.kotlinz.videoeditor.videocutter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.MediaScannerConnectionClient;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore.Images.Media;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.Utils.UtilCommand;
import com.kotlinz.videoeditor.activity.StartActivity;
import com.kotlinz.videoeditor.view.VideoPlayerState;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar;
import com.kotlinz.videoeditor.editvideo.activity.EditActivity;
import com.kotlinz.videoeditor.videojoiner.activity.VideoJoinerActivity;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;


@SuppressLint({"WrongConstant"})
public class VideoCutterActivity extends AppCompatActivity implements MediaScannerConnectionClient, OnClickListener {
    Activity activity = VideoCutterActivity.this;
    public static Context AppContext = null;
    static final boolean k = true;
    MediaScannerConnection a;
    int b = 0;
    int c = 0;
    TextView d;
    TextView e;
    TextView g;
    ImageView buttonply;
    VideoSliceSeekBar videoSliceSeekBar;
    VideoView videoView;
    private final String l = "";
    private String m;

    public String n;

    public VideoPlayerState o = new VideoPlayerState();
    private final a p = new a();

    ImageView ivback, ivDone;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    private class a extends Handler {
        private boolean b;
        private final Runnable runnable;

        private a() {
            this.b = false;
            this.runnable = new Runnable() {
                public void run() {
                    VideoCutterActivity.a.this.a();
                }
            };
        }


        public void a() {
            if (!this.b) {
                this.b = VideoCutterActivity.k;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            this.b = false;
            VideoCutterActivity.this.videoSliceSeekBar.videoPlayingProgress(VideoCutterActivity.this.videoView.getCurrentPosition());
            if (!VideoCutterActivity.this.videoView.isPlaying() || VideoCutterActivity.this.videoView.getCurrentPosition() >= VideoCutterActivity.this.videoSliceSeekBar.getRightProgress()) {
                if (VideoCutterActivity.this.videoView.isPlaying()) {
                    VideoCutterActivity.this.videoView.pause();
                    VideoCutterActivity.this.buttonply.setBackgroundResource(R.drawable.ic_play_upress);
                }
                VideoCutterActivity.this.videoSliceSeekBar.setSliceBlocked(false);
                VideoCutterActivity.this.videoSliceSeekBar.removeVideoStatusThumb();
                return;
            }
            postDelayed(this.runnable, 50);
        }
    }


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.videocutteractivity);
        MyApplication.getInstance().KeepScreenOn(activity);
        PutAnalyticsEvent();
        BannerAds();
        AppContext = this;
        ivback = findViewById(R.id.iv_back);
        ivDone = findViewById(R.id.iv_done);
        buttonply = findViewById(R.id.buttonply1);
        videoSliceSeekBar = findViewById(R.id.seek_bar1);
        d = findViewById(R.id.left_pointer);
        e = findViewById(R.id.right_pointer);
        videoView = findViewById(R.id.videoView1);
        buttonply.setOnClickListener(this);
        m = getIntent().getStringExtra("path");
        if (m == null) {
            finish();
        }
        videoView.setVideoPath(m);
        videoView.seekTo(100);
        e();
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (videoView.isPlaying()) {
                    videoView.pause();
                    buttonply.setBackgroundResource(R.drawable.ic_play_upress);
                }
                d();
            }
        });
        this.videoView.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                buttonply.setBackgroundResource(R.drawable.ic_play_upress);
            }
        });
        return;
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoCutterActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void c() {
        File file = new File(n);
        MediaScannerConnection.scanFile(this, new String[]{file.getPath()},
                null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {

                    }
                });
        Intent intent = new Intent(activity, EditActivity.class);
        intent.putExtra("videofilename", n);
        startActivity(intent);
        finish();
    }

    private void d() {
        String valueOf = String.valueOf(this.c);
        String.valueOf(this.b);
        String valueOf2 = String.valueOf(this.b - this.c);
        String format = new SimpleDateFormat("_HHmmss", Locale.US).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb.append("/");
        sb.append(getResources().getString(R.string.MainFolderName));
        sb.append("/");
        sb.append(getResources().getString(R.string.VideoCutter));
        File file = new File(sb.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb2.append("/");
        sb2.append(getResources().getString(R.string.MainFolderName));
        sb2.append("/");
        sb2.append(getResources().getString(R.string.VideoCutter));
        sb2.append("/videocutter");
        sb2.append(format);
        sb2.append(".mp4");
        this.n = sb2.toString();
        a(new String[]{"-ss", valueOf, "-y", "-i", this.m, "-t", valueOf2, "-vcodec", "mpeg4", "-b:v", "2097152", "-b:a", "48000", "-ac", "2", "-ar", "22050", this.n}, this.n);
    }


    private void a(String[] strArr, final String str) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();
        String ffmpegCommand = UtilCommand.main(strArr);
        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {

            @Override
            public void apply(final long executionId, final int returnCode) {
                Config.printLastCommandOutput(Log.INFO);
                progressDialog.dismiss();
                if (returnCode == RETURN_CODE_SUCCESS) {
                    progressDialog.dismiss();
                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(VideoCutterActivity.this.n)));
                    VideoCutterActivity.this.sendBroadcast(intent);
                    c();
                } else if (returnCode == RETURN_CODE_CANCEL) {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Log.e("TAG", "error Video Cancel" + returnCode);
                        Toast.makeText(VideoCutterActivity.this, "Error Creating Video", Toast.LENGTH_SHORT).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                } else {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Log.e("TAG", "error Video" + returnCode);
                        Toast.makeText(activity, "Error Creating Video", Toast.LENGTH_SHORT).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }
            }
        });
        getWindow().clearFlags(16);
    }

    private void e() {
        videoView.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                videoSliceSeekBar.setSeekBarChangeListener(new VideoSliceSeekBar.SeekBarChangeListener() {
                    public void SeekBarValueChanged(int i, int i2) {
                        if (videoSliceSeekBar.getSelectedThumb() == 1) {
                            videoView.seekTo(videoSliceSeekBar.getLeftProgress());
                        }
                        d.setText(VideoJoinerActivity.formatTimeUnit(i));
                        e.setText(VideoJoinerActivity.formatTimeUnit(i2));
                        o.setStart(i);
                        o.setStop(i2);
                        c = i / 1000;
                        b = i2 / 1000;
                    }
                });
                videoSliceSeekBar.setMaxValue(mediaPlayer.getDuration());
                videoSliceSeekBar.setLeftProgress(mediaPlayer.getDuration());
                videoSliceSeekBar.setRightProgress(mediaPlayer.getDuration());
                videoSliceSeekBar.setProgressMinDiff(0);
                videoView.seekTo(100);
            }
        });
    }

    private void f() {
        if (videoView.isPlaying()) {
            videoView.pause();
            videoSliceSeekBar.setSliceBlocked(false);
            buttonply.setBackgroundResource(R.drawable.ic_play_upress);
            videoSliceSeekBar.removeVideoStatusThumb();
            return;
        }
        videoView.seekTo(this.videoSliceSeekBar.getLeftProgress());
        videoView.start();
        videoSliceSeekBar.videoPlayingProgress(videoSliceSeekBar.getLeftProgress());
        buttonply.setBackgroundResource(R.drawable.ic_pause_unpresss);
        p.a();
    }

    @Override
    public void onClick(View view) {
        if (view == this.buttonply) {
            f();
        }
    }

    public void onMediaScannerConnected() {
        a.scanFile(this.l, "video/*");
    }

    public void onScanCompleted(String str, Uri uri) {
        a.disconnect();
    }


    @SuppressLint("ResourceType")
    public void h() {
        new AlertDialog.Builder(this).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        }).create().show();
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }


    private void ExitConfirmation() {
        new AlertDialog.Builder(this).setMessage("All changes will be discarded.").setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                if (MyApplication.isShowAd == 1) {
                    Intent intent = new Intent(activity, StartActivity.class);
                    startActivity(intent);
                    finish();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 8;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        Intent intent = new Intent(activity, StartActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }

    public void onBackPressed() {
        ExitConfirmation();
    }
}
