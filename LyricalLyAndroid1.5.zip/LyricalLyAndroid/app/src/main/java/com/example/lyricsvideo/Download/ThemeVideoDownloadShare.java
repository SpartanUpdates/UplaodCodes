package com.example.lyricsvideo.Download;


import android.content.Context;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.lyricsvideo.Model.VideoInfo;
import com.liulishuo.okdownload.DownloadTask;
import com.liulishuo.okdownload.SpeedCalculator;
import com.liulishuo.okdownload.StatusUtil;
import com.liulishuo.okdownload.core.Util;
import com.liulishuo.okdownload.core.breakpoint.BlockInfo;
import com.liulishuo.okdownload.core.breakpoint.BreakpointInfo;
import com.liulishuo.okdownload.core.cause.EndCause;
import com.liulishuo.okdownload.core.listener.DownloadListener4WithSpeed;
import com.liulishuo.okdownload.core.listener.assist.Listener4SpeedAssistExtend;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;


public class ThemeVideoDownloadShare {
    private final String absolute_hide_path = Environment.getExternalStorageDirectory() + File.separator + "Lyrics Video" + File.separator + ".PreviewVideo";
    private DownloadTask BundleDownloadTask;
    private ProgressBar donutProgress;
    private TextView tvprogress;
    private ImageView ivDownload;
    private AppCompatButton btnusenow;
    private RelativeLayout rlThemeProgress;
    private VideoInfo themelModel;
    private Context context;
    private String VideoName;


    public ThemeVideoDownloadShare(Context context, String BundleUrl, String BundleName, ProgressBar progressBar, TextView tvProgress, VideoInfo themelModel, ImageView ivDownload, AppCompatButton btnUseNow, RelativeLayout rlThemeProgress) {
        this.context = context;
        this.VideoName = BundleName;
        this.donutProgress = progressBar;
        this.btnusenow = btnUseNow;
        this.tvprogress = tvProgress;
        this.themelModel = themelModel;
        this.ivDownload = ivDownload;
        this.rlThemeProgress = rlThemeProgress;
        initTaskBundle(BundleUrl);
        initStatusBundle();
        initActionBundle();
    }

    private void initTaskBundle(String URL) {
        themelModel.isDownloadingshareVideo = true;
        themelModel.isAvailableOfflineShareVideo = false;
        final File parentFile = new File(Environment.getExternalStorageDirectory() + File.separator + "Lyrics Video" + File.separator + ".PreviewVideo");
        BundleDownloadTask = new DownloadTask.Builder(URL, parentFile)
                .setFilename(VideoName)
                .setMinIntervalMillisCallbackProcess(16)
                .setPassIfAlreadyCompleted(false)
                .build();

    }

    private void initStatusBundle() {
        final StatusUtil.Status status = StatusUtil.getStatus(BundleDownloadTask);
        if (status == StatusUtil.Status.COMPLETED) {
            Log.e("TAG", "Bundel Download Complated");
        }

        final BreakpointInfo info = StatusUtil.getCurrentInfo(BundleDownloadTask);
        if (info != null) {
            Log.d("TAG", "Bundel init status with: " + info.toString());
        }
    }

    private void initActionBundle() {
        final boolean started = BundleDownloadTask.getTag() != null;
        if (started) {
            BundleDownloadTask.cancel();
        } else {
            startTask();
            BundleDownloadTask.setTag("mark-BundleDownloadTask-started");
        }
    }

    private void startTask() {
        BundleDownloadTask.enqueue(new DownloadListener4WithSpeed() {
            private long totalLength;
            private String readableTotalLength;

            @Override
            public void taskStart(@NonNull DownloadTask task) {
            }

            @Override
            public void infoReady(@NonNull DownloadTask task, @NonNull BreakpointInfo info,
                                  boolean fromBreakpoint,
                                  @NonNull Listener4SpeedAssistExtend.Listener4SpeedModel model) {
                totalLength = info.getTotalLength();
                readableTotalLength = Util.humanReadableBytes(totalLength, true);
            }

            @Override
            public void connectStart(@NonNull DownloadTask task, int blockIndex,
                                     @NonNull Map<String, List<String>> requestHeaders) {
            }

            @Override
            public void connectEnd(@NonNull DownloadTask task, int blockIndex, int responseCode,
                                   @NonNull Map<String, List<String>> responseHeaders) {
            }

            @Override
            public void progressBlock(@NonNull DownloadTask task, int blockIndex,
                                      long currentBlockOffset,
                                      @NonNull SpeedCalculator blockSpeed) {

            }

            @Override
            public void progress(@NonNull DownloadTask task, long currentOffset,
                                 @NonNull SpeedCalculator taskSpeed) {
                int percentage = (int) (currentOffset * 100 / totalLength);
                donutProgress.setProgress(percentage);
                tvprogress.setText(String.valueOf(percentage) + "%");
            }

            @Override
            public void blockEnd(@NonNull DownloadTask task, int blockIndex, BlockInfo info,
                                 @NonNull SpeedCalculator blockSpeed) {
            }

            @Override
            public void taskEnd(@NonNull DownloadTask task, @NonNull EndCause cause,
                                @Nullable Exception realCause,
                                @NonNull SpeedCalculator taskSpeed) {
                task.setTag(null);
                if (cause == EndCause.CANCELED) {
                    themelModel.isDownloadingshareVideo = false;
                    themelModel.isAvailableOfflineShareVideo = false;
                    DeleteFileIfInterupt(new File(absolute_hide_path).getAbsolutePath() + File.separator + task.getFilename());
                } else if (cause == EndCause.ERROR) {
                    themelModel.isDownloadingshareVideo = false;
                    themelModel.isAvailableOfflineShareVideo = false;
                    DeleteFileIfInterupt(new File(absolute_hide_path).getAbsolutePath() + File.separator + task.getFilename());
                }
                if (VideoName.equals(task.getFilename())) {
                    if (cause == EndCause.COMPLETED) {
                        themelModel.isDownloadingshareVideo = false;
                        themelModel.isAvailableOfflineShareVideo = true;
                        btnusenow.setVisibility(View.VISIBLE);
                        ivDownload.setVisibility(View.GONE);
                        rlThemeProgress.setVisibility(View.GONE);
//                        unpackZip(new File(absolute_hide_path).getAbsolutePath() + File.separator + task.getFilename());
                    }
                }
            }
        });
    }

    private void DeleteFileIfInterupt(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            file.delete();
        }
    }

    private boolean unpackZip(String filePath) {
        InputStream is;
        ZipInputStream zis;
        try {
            File zipfile = new File(filePath);
            String parentFolder = zipfile.getParentFile().getPath();
            String filename;
            is = new FileInputStream(filePath);
            zis = new ZipInputStream(new BufferedInputStream(is));
            ZipEntry ze;
            byte[] buffer = new byte[1024];
            int count;
            while ((ze = zis.getNextEntry()) != null) {
                filename = ze.getName();
                if (ze.isDirectory()) {
                    File fmd = new File(parentFolder + "/" + filename);
                    fmd.mkdirs();
                    continue;
                }
                FileOutputStream fout = new FileOutputStream(parentFolder + "/" + filename);
                while ((count = zis.read(buffer)) != -1) {
                    fout.write(buffer, 0, count);
                }
                fout.close();
                zis.closeEntry();
            }
            zis.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
}
