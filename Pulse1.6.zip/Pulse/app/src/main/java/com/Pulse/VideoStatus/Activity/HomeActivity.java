package com.Pulse.VideoStatus.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.Pulse.VideoStatus.Extra.Utils;
import com.Pulse.VideoStatus.Extra.d;
import com.Pulse.VideoStatus.Extra.kprogresshud.KProgressHUD;
import com.Pulse.VideoStatus.Fragment.CategoryWiseThemeFragment;
import com.Pulse.VideoStatus.Handler.HttpHandler;
import com.Pulse.VideoStatus.Model.CategoryModel;
import com.Pulse.VideoStatus.R;
import com.Pulse.VideoStatus.UnityPlayerActivity;
import com.Pulse.VideoStatus.View.a;
import com.Pulse.VideoStatus.application.MyApplication;
import com.Pulse.VideoStatus.retrofit.APIClient;
import com.Pulse.VideoStatus.retrofit.ApiInterface;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.root.bridge.AppUsages;
import com.unity3d.player.UnityPlayer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    public static d sharedpreferences;
    private final int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
    private final int REQUEST_PERMISSION_SETTING = 101;
    public int id;
    public String AllPath;
    public String UpdateDataUrl = a.UpdateDataUrl;
    public InterstitialAd mInterstitialAd;
    public AdLoader adLoader;
    public List<UnifiedNativeAd> mNativeAds = new ArrayList<>();
    public MediaPlayer mediaPlayer;
    public ActionBarDrawerToggle mDrawerToggle;
    Activity activity = HomeActivity.this;
    ArrayList<CategoryModel> tabcategorylist = new ArrayList<>();
    String offlienResopnseData;
    Long timestamps;
    Date date = new Date();
    ImageView ivMycreation;
    RelativeLayout rlLoading;
    LinearLayout llRetry;
    LinearLayout layoutMycreation;
    Button btnRetry;
    TextView tvtitle;
    ImageButton ibCreate;
    PagerAdapterNew adp;
    int SelectedPosition = 0;
    //    private LinearLayout adContainer;
//    private AdView adView;
    AdRequest adRequest;
    AdView adView;
    ImageView ivNavDrawer;
    String[] split_AllLan;
    String[] split_selctedLan;
    LinearLayout llRate, llRingtone, llShare, llfeedback;
    TextView tvVersion;
    SharedPreferences pref;
    PackageInfo info = null;
    KProgressHUD hud;
    private ImageView ivClose;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private boolean B = false;
    private boolean C = false;
    private boolean D = false;
    private DrawerLayout mDrawerLayout;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        sharedpreferences = d.a(this);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        split_AllLan = ("63,55,62,61,57,60,58,59,56,52,50,53,64").split(",");
        split_selctedLan = d.a(activity).a("pref_key_language_list", "22").split(",");
        CategoryModel categoryModel = new CategoryModel();
        categoryModel.setCategoryId("111");
        categoryModel.setCatIcon(getCatIcon("New"));
        categoryModel.setCatSelectedIcon(getSelectedIcon("New"));
        categoryModel.setName("New");
        tabcategorylist.add(categoryModel);
        loadAd();
        loadNativeAds();
        InterstitialAd();
        BindView();
        SetListener();
        GetAppVersion();
        if (!pref.getBoolean("AppNewVersion", false) && info.versionName.equals("1.6")) {
            SharedPreferences.Editor editor = pref.edit();
            editor.putBoolean("AppNewVersion", true);
            editor.apply();
            ClearPrefTheme();
        }
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "HomeActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        SetUpdateData();
        if (Build.VERSION.SDK_INT < 23) {
            SetData();
        } else if (!this.B || this.C) {
            this.C = false;
            this.D = false;
            RequestPermission(false);
        }
        if (this.D) {
            this.C = true;
        }
    }

    public void PremissionFromSetting(HomeActivity homeActivity) {
        homeActivity.D = true;
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", homeActivity.getPackageName(), null);
        intent.setData(uri);
        homeActivity.startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
    }

    @Override
    protected void onResume() {
        super.onResume();
        SystemVisibility();
    }

    public void RequestPermission(boolean z) {
        if ((ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            Utils.CreateDirectory();
            AppUsages.loadFFMpeg(activity);
            SetData();
        } else if (z) {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setTitle("Necessary permission");
            builder.setMessage("Allow Required Permission");
            builder.setCancelable(false);
            builder.setPositiveButton("Settings", (dialog, which) -> {
                dialog.dismiss();
                PremissionFromSetting(HomeActivity.this);
            });
            builder.setNegativeButton("Exit", (dialog, which) -> {
                UnityPlayerActivity.mUnityPlayer.quit();
                finishAffinity();
                finish();
            });

            builder.show();
        } else {
            ActivityCompat.requestPermissions(activity, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Utils.CreateDirectory();
                AppUsages.loadFFMpeg(activity);
                SetData();

            } else {
                RequestPermission(true);
            }
        }
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        if (i == EXTERNAL_STORAGE_PERMISSION_CONSTANT) {
            if (iArr.length > 0) {
                if (iArr[0] == 0 && iArr[1] == PackageManager.PERMISSION_GRANTED) {
                    Utils.CreateDirectory();
                    AppUsages.loadFFMpeg(activity);
                    SetData();
                } else if ((iArr[0] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) || (iArr[1] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.READ_EXTERNAL_STORAGE))) {
                    this.B = true;
                    RequestPermission(true);
                }
            }
        }
    }

    private void SystemVisibility() {
        if (Build.VERSION.SDK_INT <= 11 || Build.VERSION.SDK_INT >= 19) {
            if (Build.VERSION.SDK_INT >= 19) {
                getWindow().getDecorView().setSystemUiVisibility(12288);
            }
            return;
        }
        getWindow().getDecorView().setSystemUiVisibility(8);
    }

    private void SetUpdateData() {
        if (Utils.checkConnectivity(activity, false)) {
            getOfflineCategory(activity, "UpdateData");
            if (offlienResopnseData != null && timestamps != null) {
                if (Math.abs(System.currentTimeMillis() - timestamps) > 300000) {
                    new GetData().execute(UpdateDataUrl);
                } else {
                    if (offlienResopnseData != null) {
                        UpdateOfflineData(offlienResopnseData);
                    }
                }
            } else {
                new GetData().execute(UpdateDataUrl);
            }
        } else {
            getOfflineCategory(activity, "UpdateData");
            if (offlienResopnseData != null) {
                UpdateOfflineData(offlienResopnseData);
            } else {
                llRetry.setVisibility(View.VISIBLE);
                Toast.makeText(activity, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void SetData() {
        if (Utils.checkConnectivity(activity, false)) {
            getOfflineCategory(activity, "ThemeCategory");
            if (offlienResopnseData != null && timestamps != null) {
                if (Math.abs(System.currentTimeMillis() - timestamps) > 900000) {
                    GetCategory();
                } else {
                    if (offlienResopnseData != null) {
                        new LoadOfflineData().execute();
                    }
                }
            } else {
                GetCategory();
            }
        } else {
            getOfflineCategory(activity, "ThemeCategory");
            if (offlienResopnseData != null) {
                new LoadOfflineData().execute();
            } else {
                llRetry.setVisibility(View.VISIBLE);
                rlLoading.setVisibility(View.GONE);
                Toast.makeText(activity, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void UpdateOfflineData(String result) {
        try {
            JSONObject jsonObj = new JSONObject(result);
            String status = jsonObj.getString("status");
            String versioncode = jsonObj.getString("versioncode");
//            String Url = jsonObj.getString("url");
//            String urlBigImageTo = jsonObj.getString("urlBigImageTo");
//            String urlBigImageFrom = jsonObj.getString("urlBigImageFrom");
//            String urlSoundTo = jsonObj.getString("urlSoundTo");
//            String urlSounfFrom = jsonObj.getString("urlSounfFrom");
            MyApplication.stringArrayList.add(0, status);
            MyApplication.stringArrayList.add(1, versioncode);
//            MyApplication.stringArrayList.add(2, Url);
//            MyApplication.stringArrayList.add(3, urlBigImageTo);
//            MyApplication.stringArrayList.add(4, urlBigImageFrom);
//            MyApplication.stringArrayList.add(5, urlSoundTo);
//            MyApplication.stringArrayList.add(6, urlSounfFrom);
            int VersionCode = 0;
            try {
                VersionCode = HomeActivity.this.getPackageManager().getPackageInfo(HomeActivity.this.getPackageName(), 0).versionCode;
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            if (MyApplication.stringArrayList.get(0).equalsIgnoreCase("true") && VersionCode < Integer.parseInt(MyApplication.stringArrayList.get(1))) {
                try {
                    IsUpdate();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        } catch (final JSONException e) {
            e.printStackTrace();
        }
    }

    public void IsUpdate() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(getResources().getString(R.string.update_title));
        builder.setMessage(getResources().getString(R.string.update_message));
        builder.setCancelable(false);
        builder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RateApp();
            }
        });
    }

   /* private void LoadOfflineData(String result) {
        try {
            JSONObject jsonObj = new JSONObject(result);
            JSONArray tabcategory = jsonObj.getJSONArray("category");
            for (int i = 0; i < tabcategory.length(); i++) {
                JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                CategoryModel categoryModel = new CategoryModel();
                categoryModel.setCategoryId(tabcategoryJSONObject.getString("id"));
                if (!Arrays.asList(split_AllLan).contains(String.valueOf(categoryModel.getCategoryId()))) {
                    categoryModel.setCatIcon(getCatIcon(tabcategoryJSONObject.getString("name")));
                    categoryModel.setCatSelectedIcon(getSelectedIcon(tabcategoryJSONObject.getString("name")));
                    categoryModel.setName(tabcategoryJSONObject.getString("name"));
                    tabcategorylist.add(categoryModel);
                } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(categoryModel.getCategoryId()))) {
                    categoryModel.setCatIcon(getCatIcon(tabcategoryJSONObject.getString("name")));
                    categoryModel.setCatSelectedIcon(getSelectedIcon(tabcategoryJSONObject.getString("name")));
                    categoryModel.setName(tabcategoryJSONObject.getString("name"));
                    tabcategorylist.add(categoryModel);
                }
            }
            setUpPagerNew();
            SetTabLayout();
        } catch (final JSONException e) {
            e.printStackTrace();
        }
    }*/

    private int getCatIcon(String str) {
        str = str.toLowerCase();
        return str.contains("love") ? R.drawable.icon_love : str.contains("festival") ? R.drawable.icon_festival : str.contains("krishna") ? R.drawable.icon_krishna : str.contains("ganesha") ? R.drawable.icon_ganesha : str.contains("balaji") ? R.drawable.icon_balaji : str.contains("mahadev") ? R.drawable.icon_mahadev : str.contains("premium") ? R.drawable.icon_premium : str.contains("birthday") ? R.drawable.icon_birthday : str.contains("god") ? R.drawable.icon_god : str.contains("shree ram") ? R.drawable.icon_shreeram : str.contains("wedding") ? R.drawable.icon_wedding : str.contains("wish") ? R.drawable.icon_wish : str.contains("popular") ? R.drawable.icon_premium : str.contains("telugu") ? R.drawable.icon_telugu : str.contains("tamil") ? R.drawable.icon_tamil : str.contains("bhojpuri") ? R.drawable.icon_bhojpuri : str.contains("diwali") ? R.drawable.icon_diwali : str.contains("english") ? R.drawable.icon_english : str.contains("friendship") ? R.drawable.icon_friends : str.contains("gujarati") ? R.drawable.icon_gujrati : str.contains("hindi") ? R.drawable.icon_hindi : str.contains("kannada") ? R.drawable.icon_kannada : str.contains("malayalam") ? R.drawable.icon_malayalam : str.contains("marathi") ? R.drawable.icon_marathi : str.contains("navratri") ? R.drawable.icon_navratri : str.contains("sad") ? R.drawable.icon_sad : str.contains("day events") ? R.drawable.icon_dayevents : str.contains("patriotic") ? R.drawable.icon_patriotic : str.contains("christmas") ? R.drawable.icon_christmas : str.contains("rockstar") ? R.drawable.icon_rockstar : str.contains("islamic") ? R.drawable.icon_islamic : str.contains("bengali") ? R.drawable.icon_bengali : str.contains("punjabi") ? R.drawable.icon_punjabi : str.contains("tiktok") ? R.drawable.icon_tiktok : str.contains("Rajashthahni") ? R.drawable.icon_rajstani : R.drawable.icon_defualt;
    }

    private int getSelectedIcon(String str) {
        str = str.toLowerCase();
        return str.contains("love") ? R.drawable.icon_love_select : str.contains("festival") ? R.drawable.icon_festival_select : str.contains("krishna") ? R.drawable.icon_krishna_select : str.contains("ganesha") ? R.drawable.icon_ganesha_select : str.contains("balaji") ? R.drawable.icon_balaji_select : str.contains("mahadev") ? R.drawable.icon_mahadev_select : str.contains("premium") ? R.drawable.icon_premium_select : str.contains("birthday") ? R.drawable.icon_birthday_select : str.contains("god") ? R.drawable.icon_god_select : str.contains("shree ram") ? R.drawable.icon_shreeram_select : str.contains("wedding") ? R.drawable.icon_wedding_select : str.contains("wish") ? R.drawable.icon_wish_select : str.contains("popular") ? R.drawable.icon_premium_select : str.contains("telugu") ? R.drawable.icon_telugu_select : str.contains("tamil") ? R.drawable.icon_tamil_select : str.contains("bhojpuri") ? R.drawable.icon_bhojpuri_select : str.contains("diwali") ? R.drawable.icon_diwali_select : str.contains("english") ? R.drawable.icon_english_select : str.contains("friendship") ? R.drawable.icon_friends_select : str.contains("gujarati") ? R.drawable.icon_gujrati_select : str.contains("hindi") ? R.drawable.icon_hindi_select : str.contains("kannada") ? R.drawable.icon_kannada_select : str.contains("malayalam") ? R.drawable.icon_malayalam_select : str.contains("marathi") ? R.drawable.icon_marathi_select : str.contains("navratri") ? R.drawable.icon_navratri_select : str.contains("sad") ? R.drawable.icon_sad_select : str.contains("day events") ? R.drawable.icon_dayevents_select : str.contains("patriotic") ? R.drawable.icon_patriotic_select : str.contains("christmas") ? R.drawable.icon_christmas_select : str.contains("rockstar") ? R.drawable.icon_rockstar_select : str.contains("islamic") ? R.drawable.icon_islamic_select : str.contains("bengali") ? R.drawable.icon_bengali_select : str.contains("punjabi") ? R.drawable.icon_punjabi_select : str.contains("tiktok") ? R.drawable.icon_tiktok_select : str.contains("Rajashthahni") ? R.drawable.icon_rajstani_select : R.drawable.icon_defualt_select;
    }

    private void loadAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100: {
                        UnityPlayer.UnitySendMessage("StaticThemeDataBase", "OnLoadUserData", AllPath);
                        HideShowUnityBannerAds();
                        finish();
                        break;
                    }
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    private void loadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getString(R.string.nativead));
        adLoader = builder.forUnifiedNativeAd(
                new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                    @Override
                    public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                        mNativeAds.add(unifiedNativeAd);
                        MyApplication.getInstance().IsNativeAdsLoaded = true;
//                        mNativeAds = unifiedNativeAd;
                    }
                }).withAdListener(
                new AdListener() {
                    @Override
                    public void onAdFailedToLoad(int errorCode) {
                        MyApplication.getInstance().IsNativeAdsLoaded = false;
                    }
                }).build();

        // Load the Native ads.
        adLoader.loadAds(new AdRequest.Builder().build(), 5);
    }

    private void HideShowUnityBannerAds() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 3000);
    }

    @Override
    protected void onDestroy() {
        adView.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        try {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.reset();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        super.onDestroy();
    }

    public void onPause() {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.reset();
            }
        } catch (IllegalStateException ex) {
            ex.printStackTrace();
        }
        super.onPause();
    }

    private void BindView() {
        mDrawerLayout = findViewById(R.id.drawer_layout);
        ibCreate = findViewById(R.id.ibCreate);
        ivNavDrawer = findViewById(R.id.iv_navDrawer);
        tvtitle = findViewById(R.id.tvName);
        ivMycreation = findViewById(R.id.ivMyCreation);
        rlLoading = findViewById(R.id.rl_loading_pager);
        layoutMycreation = findViewById(R.id.layout_mycreation);
        tabLayout = findViewById(R.id.mTabLayout);
        viewPager = findViewById(R.id.mViewPager);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);
        llRate = findViewById(R.id.ll_rate);
        llRingtone = findViewById(R.id.llRingtone);
        llShare = findViewById(R.id.llShare);
        llfeedback = findViewById(R.id.llFeedback);
        ivClose = findViewById(R.id.iv_close);
        tvVersion = findViewById(R.id.tv_version);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.closeDrawers();
            }
        });
        layoutMycreation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoToMyCreation();
            }
        });
        ivNavDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.openDrawer(Gravity.START);
            }
        });
        llRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RateApp();
            }
        });
        llRingtone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
                                MyApplication.ActContext = HomeActivity.this;
                                MyApplication.AdsId = 5;
                                MyApplication.mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    startActivity(new Intent(activity, RingtonSetActivity.class));
                    finish();
                }
            }
        });
        llShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShareAPP();
            }
        });
        llfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Feedback();
            }
        });
        ibCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectImage(activity, 6);
            }
        });
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, null, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);
    }

    private void GetAppVersion() {
        PackageManager manager = activity.getPackageManager();
        try {
            info = manager.getPackageInfo(activity.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (info != null) {
            tvVersion.setText("v" + info.versionName);
        }
    }

    private void ClearPrefTheme() {
        SharedPreferences.Editor editor = pref.edit();
        editor.remove("ThemeCategory");
        editor.remove("ThemeCategory_value");
        editor.apply();
    }

    private void GoToMyCreation() {
        Intent intent = new Intent(activity, MyVideoActivity.class);
        startActivity(intent);
        finish();
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(activity, false)) {
                    llRetry.setVisibility(View.GONE);
                    startActivity(new Intent(activity, HomeActivity.class));
                    finish();
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void SetOfflineCategory(Context c, String userObject, String key, final Date date) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.putLong(key + "_value", date.getTime());
        editor.apply();
    }

    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager
                .getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
        timestamps = pref.getLong(key + "_value", 0);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        displaySelectedScreen(menuItem.getItemId());
        return true;
    }

    private void displaySelectedScreen(int itemId) {
        switch (itemId) {
            case R.id.nav_my_movie:
                startActivity(new Intent(activity, MyVideoActivity.class));
                finish();
                break;
            case R.id.nav_ringtone:
                startActivity(new Intent(activity, RingtonSetActivity.class));
                finish();
                break;
            case R.id.nav_feddback:
                Feedback();
                break;
            case R.id.nav_Select_songlanguage:
                startActivity(new Intent(activity, LanguageActivity.class));
                finish();
                break;
            case R.id.nav_rate_us:
                RateApp();
                finish();
                break;
            case R.id.nav_invite:
                ShareAPP();
                break;
            case R.id.nav_privacy:
                Intent intent1 = new Intent("android.intent.action.VIEW");
                intent1.setData(Uri.parse(getResources().getString(R.string.privacy_link)));
                break;
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    private void Feedback() {
        Intent intent2 = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", getResources().getString(R.string.feedback_email), null));
        intent2.putExtra("android.intent.extra.SUBJECT", "Feedback");
        intent2.putExtra("android.intent.extra.TEXT", "Write your feedback here");
        startActivity(Intent.createChooser(intent2, "Send email..."));
    }

    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    private void ShareAPP() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Pulse");
            String shareMessage = "\nGet free Pulse at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SelectImage(Context cntx, int NoofImage) {
        MyApplication.IsSelectImageFrom = true;
        MyApplication.IS_EDITIMAGE = 0;
        MyApplication.TotalSelectedImage = NoofImage;
        MyApplication.getInstance().getCropImages().clear();
        Intent intent = new Intent(cntx, ImageSelectActivity.class);
        intent.putExtra("NoofImage", NoofImage);
        startActivity(intent);
        finish();
    }

    public void onBackPressed() {
        if (MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
//            id = 101;
            MyApplication.ActContext = HomeActivity.this;
            MyApplication.AdsId = 7;
            MyApplication.mInterstitialAd.show();
        } else {
            GoToExit();
        }
    }

    private void GoToExit() {
        startActivity(new Intent(activity, ExitActivity.class));
        finish();
    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
        }
        ImageView iv_cat;
        iv_cat = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getCustomView().findViewById(R.id.ivIcon);
        iv_cat.setImageResource(tabcategorylist.get(tabLayout.getSelectedTabPosition()).getCatSelectedIcon());
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.tvThemeName)).setTextColor(getResources().getColor(R.color.black));
                ImageView iv_cat = customView.findViewById(R.id.ivIcon);
                SelectedPosition = tab.getPosition();
                MyApplication.CatSelectedPosition = SelectedPosition;
                iv_cat.setImageResource(tabcategorylist.get(tab.getPosition()).getCatSelectedIcon());
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ImageView iv_cat = customView.findViewById(R.id.ivIcon);
                iv_cat.setImageResource(tabcategorylist.get(tab.getPosition()).getCatIcon());
                ((TextView) customView.findViewById(R.id.tvThemeName)).setTextColor(getResources().getColor(R.color.black));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    ImageView iv_cat = customView.findViewById(R.id.ivIcon);
                    iv_cat.setImageResource(tabcategorylist.get(tab.getPosition()).getCatIcon());
                    ((TextView) customView.findViewById(R.id.tvThemeName)).setTextColor(getResources().getColor(R.color.black));
                }
            }
        });
    }

    private void setUpPagerNew() {
        adp = new PagerAdapterNew(getSupportFragmentManager());
        for (int i = 0; i < tabcategorylist.size(); i++) {
            adp.addFrag(CategoryWiseThemeFragment.newInstance(Integer.parseInt(tabcategorylist.get(i).getCategoryId())), tabcategorylist.get(i).getName());
        }
        int i;
//        viewPager.setOffscreenPageLimit(0);
        viewPager.setAdapter(adp);
        if (MyApplication.CatSelectedPosition != -1) {
            i = MyApplication.CatSelectedPosition;
        } else {
            i = 0;
        }
        viewPager.setCurrentItem(i);
        tabLayout.setupWithViewPager(viewPager);
    }

    private void GetCategory() {
        rlLoading.setVisibility(View.VISIBLE);
        APIClient.getRetrofit().create(ApiInterface.class).GetAllTheme("aciativtyksdfhal5215ajal", "9").enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        SetOfflineCategory(activity, jsonObj.toString(), "ThemeCategory", date);
                        JSONArray tabcategory = jsonObj.getJSONArray("category");
                        for (int i = 0; i < tabcategory.length(); i++) {
                            JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                            CategoryModel categoryModel = new CategoryModel();
                            categoryModel.setCategoryId(tabcategoryJSONObject.getString("id"));
                            if (!Arrays.asList(split_AllLan).contains(categoryModel.getCategoryId())) {
                                categoryModel.setCatIcon(getCatIcon(tabcategoryJSONObject.getString("name")));
                                categoryModel.setCatSelectedIcon(getSelectedIcon(tabcategoryJSONObject.getString("name")));
                                categoryModel.setName(tabcategoryJSONObject.getString("name"));
                                tabcategorylist.add(categoryModel);
                            } else if (Arrays.asList(split_selctedLan).contains(categoryModel.getCategoryId())) {
                                categoryModel.setCatIcon(getCatIcon(tabcategoryJSONObject.getString("name")));
                                categoryModel.setCatSelectedIcon(getSelectedIcon(tabcategoryJSONObject.getString("name")));
                                categoryModel.setName(tabcategoryJSONObject.getString("name"));
                                tabcategorylist.add(categoryModel);
                            }
                        }
                        setUpPagerNew();
                        SetTabLayout();
                        rlLoading.setVisibility(View.GONE);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
                rlLoading.setVisibility(View.VISIBLE);
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    private class LoadOfflineData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            rlLoading.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlienResopnseData);
                JSONArray tabcategory = jsonObj.getJSONArray("category");
                for (int i = 0; i < tabcategory.length(); i++) {
                    JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                    CategoryModel categoryModel = new CategoryModel();
                    categoryModel.setCategoryId(tabcategoryJSONObject.getString("id"));
                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(categoryModel.getCategoryId()))) {
                        categoryModel.setCatIcon(getCatIcon(tabcategoryJSONObject.getString("name")));
                        categoryModel.setCatSelectedIcon(getSelectedIcon(tabcategoryJSONObject.getString("name")));
                        categoryModel.setName(tabcategoryJSONObject.getString("name"));
                        tabcategorylist.add(categoryModel);
                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(categoryModel.getCategoryId()))) {
                        categoryModel.setCatIcon(getCatIcon(tabcategoryJSONObject.getString("name")));
                        categoryModel.setCatSelectedIcon(getSelectedIcon(tabcategoryJSONObject.getString("name")));
                        categoryModel.setName(tabcategoryJSONObject.getString("name"));
                        tabcategorylist.add(categoryModel);
                    }
                }
            } catch (final JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            setUpPagerNew();
            SetTabLayout();
            rlLoading.setVisibility(View.GONE);
        }
    }

    private class PagerAdapterNew extends FragmentPagerAdapter {
        List<Fragment> fragList = new ArrayList<>();
        List<String> titleList = new ArrayList<>();

        public PagerAdapterNew(FragmentManager fm) {
            super(fm);
        }

        public void addFrag(Fragment f, String title) {
            fragList.add(f);
            titleList.add(title);
        }

        @Override
        public Fragment getItem(int position) {
            return fragList.get(position);
        }

        @Override
        public int getCount() {
            return fragList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titleList.get(position);
        }

        public View getTabView(int position) {
            View tabCatView = LayoutInflater.from(activity).inflate(
                    R.layout.row_category_item, null);
            TextView tv = tabCatView.findViewById(R.id.tvThemeName);
            ImageView ivIcon = tabCatView.findViewById(R.id.ivIcon);
            tv.setText(tabcategorylist.get(position).getName());
            ivIcon.setImageResource(tabcategorylist.get(position).getCatIcon());
            return tabCatView;
        }
    }


    @SuppressLint("StaticFieldLeak")
    public class GetData extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {

        }

        protected String doInBackground(String... arg0) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(arg0[0]);
            if (jsonStr != null) {
                System.out.println("success");
            } else {
                System.out.println("failed");
            }

            return jsonStr;

        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject jsonObj = new JSONObject(result);
                    SetOfflineCategory(activity, jsonObj.toString(), "UpdateData", date);
                    String status = jsonObj.getString("status");
                    String versioncode = jsonObj.getString("versioncode");
//                    String Url = jsonObj.getString("url");
//                    String urlBigImageTo = jsonObj.getString("urlBigImageTo");
//                    String urlBigImageFrom = jsonObj.getString("urlBigImageFrom");
//                    String urlSoundTo = jsonObj.getString("urlSoundTo");
//                    String urlSounfFrom = jsonObj.getString("urlSounfFrom");
                    MyApplication.stringArrayList.add(   0, status);
                    MyApplication.stringArrayList.add(1, versioncode);
//                    MyApplication.stringArrayList.add(2, Url);
//                    MyApplication.stringArrayList.add(3, urlBigImageTo);
//                    MyApplication.stringArrayList.add(4, urlBigImageFrom);
//                    MyApplication.stringArrayList.add(5, urlSoundTo);
//                    MyApplication.stringArrayList.add(6, urlSounfFrom);
                    int VersionCode = 0;
                    try {
                        VersionCode = HomeActivity.this.getPackageManager().getPackageInfo(HomeActivity.this.getPackageName(), 0).versionCode;
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }
                    if (MyApplication.stringArrayList.get(0).equalsIgnoreCase("true") && VersionCode < Integer.parseInt(MyApplication.stringArrayList.get(1))) {
                        try {
                            IsUpdate();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                } catch (final JSONException e) {
                    e.printStackTrace();
                }
            } else {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(activity, "Couldn't get json from server. Check LogCat for possible errors!", Toast.LENGTH_LONG).show();
                    }
                });
            }
        }
    }
}
