package com.esc.flashlight.util;

public class SoundSearcher {
    private static final char HANGUL_BASE_UNIT = 'Ɍ';
    private static final char HANGUL_BEGIN_UNICODE = '가';
    private static final char HANGUL_LAST_UNICODE = '힣';
    private static final char[] INITIAL_SOUND = new char[]{12593, 12594, 12596, 12599, 12600, 12601, 12609, 12610, 12611, 12613, 12614, 12615, 12616, 12617, 12618, 12619, 12620, 12621, 12622};

    private static boolean isHangul(char c) {
        return HANGUL_BEGIN_UNICODE <= c && c <= HANGUL_LAST_UNICODE;
    }

    private static boolean isInitialSound(char c) {
        for (char c2 : INITIAL_SOUND) {
            if (c2 == c) {
                return true;
            }
        }
        return false;
    }

    private static char getInitialSound(char c) {
        return INITIAL_SOUND[(c - 44032) / 588];
    }

    public static boolean matchString(String str, String str2) {
        int length = str.length() - str2.length();
        int length2 = str2.length();
        if (length < 0) {
            return false;
        }
        for (int i = 0; i <= length; i++) {
            int i2 = 0;
            while (i2 < length2) {
                if (isInitialSound(str2.charAt(i2))) {
                    int i3 = i + i2;
                    if (isHangul(str.charAt(i3))) {
                        if (getInitialSound(str.charAt(i3)) != str2.charAt(i2)) {
                            break;
                        }
                        i2++;
                    }
                }
                if (!String.valueOf(str.charAt(i + i2)).equalsIgnoreCase(String.valueOf(str2.charAt(i2)))) {
                    break;
                }
                i2++;
            }
            if (i2 == length2) {
                return true;
            }
        }
        return false;
    }
}
