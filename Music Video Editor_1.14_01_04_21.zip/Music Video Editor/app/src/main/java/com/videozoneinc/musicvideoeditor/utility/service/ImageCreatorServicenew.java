package com.videozoneinc.musicvideoeditor.utility.service;

import android.app.IntentService;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.NotificationCompat;
import com.bumptech.glide.Glide;
import com.videozoneinc.musicvideoeditor.MyApplication;
import com.videozoneinc.musicvideoeditor.OnProgressReceiver;
import com.videozoneinc.musicvideoeditor.R;
import com.videozoneinc.musicvideoeditor.modelclass.ImageData;
import com.videozoneinc.musicvideoeditor.utility.listeners.ScalingUtilitiesnew;
import com.videozoneinc.musicvideoeditor.utility.mask.MaskBitmap;
import com.videozoneinc.musicvideoeditor.video.FileUtils;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class ImageCreatorServicenew extends IntentService {
    public static final String ACTION_CREATE_NEW_THEME_IMAGES = "ACTION_CREATE_NEW_THEME_IMAGES";
    public static final String ACTION_UPDATE_THEME_IMAGES = "ACTION_UPDATE_THEME_IMAGES";
    public static final String EXTRA_SELECTED_THEME = "selected_theme";
    public static boolean isImageComplate;
    public static final Object lock;
    MyApplication application;
    ArrayList<ImageData> imgdata_arrayList;
    private NotificationCompat.Builder builder;
    private NotificationManager notify_manager;
    private String selecte_theme;
    int total_images;

    class samethemeProgress implements Runnable {
        private final int val$progress;

        samethemeProgress(int i) {
            this.val$progress = i;
        }

        public void run() {
            OnProgressReceiver receiver = ImageCreatorServicenew.this.application
                    .getOnProgressReceiver();
            if (receiver != null) {
                receiver.onImageProgressFrameUpdate(this.val$progress);
            }
        }
    }

    static {
        isImageComplate = false;
        lock = new Object();
    }

    public ImageCreatorServicenew() {
        this(ImageCreatorService.class.getName());
    }

    public ImageCreatorServicenew(String name) {
        super(name);
    }

    public void onCreate() {
        super.onCreate();
        this.application = MyApplication.getInstance();
    }

    @Deprecated
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    protected void onHandleIntent(Intent intent) {
        this.notify_manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        this.builder = new NotificationCompat.Builder(this);
        this.builder.setContentTitle("Preparing Video")
                .setContentText("Making in progress")
                .setSmallIcon(R.mipmap.ic_launchers);
        this.selecte_theme = intent.getStringExtra(EXTRA_SELECTED_THEME);
        this.imgdata_arrayList = this.application.getSelectedImages();
        this.application.initArray();
        isImageComplate = false;
        createImages();
    }

    private void createImages() {
        System.currentTimeMillis();
        Bitmap bitmap = null;
        this.total_images = this.imgdata_arrayList.size();

        int var3 = 0;
        for (int var1 = 0; var1 < this.imgdata_arrayList.size() - 1
                && this.isSameTheme() && !MyApplication.isBreak; var1 = var3 + 1) {
            File var7 = FileUtils.getImageDirectory(
                    this.application.selected_theme.toString(), var1);
            Bitmap newFirstBmp;
            Bitmap var8;
            if (var1 == 0) {
                var8 = ScalingUtilitiesnew
                        .checkBitmap(((ImageData) this.imgdata_arrayList
                                .get(var1)).imagePath);
                bitmap = ScalingUtilitiesnew.scaleCenterCrop(var8,
                        MyApplication.VIDEO_WIDTH, MyApplication.VIDEO_HEIGHT);
                newFirstBmp = ScalingUtilitiesnew.ConvetrSameSize(var8, bitmap,
                        MyApplication.VIDEO_WIDTH, MyApplication.VIDEO_HEIGHT,
                        1.0F, 0.0F);
                bitmap.recycle();
                var8.recycle();
                System.gc();
            } else {
                if (bitmap != null) {
                    newFirstBmp = bitmap;
                    if (!bitmap.isRecycled()) {
                    } else {
                        var8 = ScalingUtilitiesnew
                                .checkBitmap(((ImageData) this.imgdata_arrayList
                                        .get(var1)).imagePath);
                        bitmap = ScalingUtilitiesnew.scaleCenterCrop(var8,
                                MyApplication.VIDEO_WIDTH,
                                MyApplication.VIDEO_HEIGHT);
                        newFirstBmp = ScalingUtilitiesnew.ConvetrSameSize(var8, bitmap,
                                MyApplication.VIDEO_WIDTH,
                                MyApplication.VIDEO_HEIGHT, 1.0F, 0.0F);
                        bitmap.recycle();
                        var8.recycle();
                    }
                } else {
                    var8 = ScalingUtilitiesnew
                            .checkBitmap(((ImageData) this.imgdata_arrayList
                                    .get(var1)).imagePath);
                    bitmap = ScalingUtilitiesnew.scaleCenterCrop(var8,
                            MyApplication.VIDEO_WIDTH,
                            MyApplication.VIDEO_HEIGHT);
                    newFirstBmp = ScalingUtilitiesnew.ConvetrSameSize(var8, bitmap,
                            MyApplication.VIDEO_WIDTH,
                            MyApplication.VIDEO_HEIGHT, 1.0F, 0.0F);
                    bitmap.recycle();
                    var8.recycle();
                }

            }

            var8 = ScalingUtilitiesnew.checkBitmap(((ImageData) this.imgdata_arrayList
                    .get(var1 + 1)).imagePath);
            Bitmap var9 = ScalingUtilitiesnew.scaleCenterCrop(var8,
                    MyApplication.VIDEO_WIDTH, MyApplication.VIDEO_HEIGHT);
            bitmap = ScalingUtilitiesnew.ConvetrSameSize(var8, var9,
                    MyApplication.VIDEO_WIDTH, MyApplication.VIDEO_HEIGHT,
                    1.0F, 0.0F);
            var9.recycle();
            var8.recycle();
            System.gc();
            MaskBitmap.reintRect();
            MaskBitmap.EFFECT var15 = (MaskBitmap.EFFECT) this.application.selected_theme
                    .getTheme().get(
                            var1
                                    % this.application.selected_theme
                                    .getTheme().size());
            ((BitmapDrawable) this.getResources().getDrawable(R.mipmap.ic_launchers))
                    .getBitmap();

            for (int var2 = 0; (float) var2 < MaskBitmap.ANIMATED_FRAME; ++var2) {
                var3 = var1;
                if (!this.isSameTheme()) {
                    continue;
                }

                var3 = var1;

                if (MyApplication.isBreak) {
                    continue;
                }
                var9 = Bitmap.createBitmap(MyApplication.VIDEO_WIDTH,
                        MyApplication.VIDEO_HEIGHT, Bitmap.Config.ARGB_8888);
                Paint var11 = new Paint(1);
                var11.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
                Canvas var10 = new Canvas(var9);
                var10.drawBitmap(newFirstBmp, 0.0F, 0.0F, (Paint) null);
                var10.drawBitmap(var15.getMask(MyApplication.VIDEO_WIDTH,
                        MyApplication.VIDEO_HEIGHT, var2), 0.0F, 0.0F, var11);
                Bitmap var17 = Bitmap.createBitmap(MyApplication.VIDEO_WIDTH,
                        MyApplication.VIDEO_HEIGHT, Bitmap.Config.ARGB_8888);
                Canvas var19 = new Canvas(var17);
                var19.drawBitmap(bitmap, 0.0F, 0.0F, (Paint) null);
                var19.drawBitmap(var9, 0.0F, 0.0F, new Paint());
                var3 = var1;
                if (!this.isSameTheme()) {
                    continue;
                }

                File var16 = new File(var7, String.format("img%02d.jpg",
                        new Object[]{Integer.valueOf(var2)}));

                try {
                    if (var16.exists()) {
                        var16.delete();
                    }

                    FileOutputStream var20 = new FileOutputStream(var16);
                    var17.compress(CompressFormat.JPEG, 100, var20);
                    var20.close();
                } catch (FileNotFoundException var12) {
                    var12.printStackTrace();
                } catch (IOException var13) {
                    var13.printStackTrace();
                }

                boolean breakk = false;

                while (this.application.isEditModeEnable) {
                    if (this.application.min_pos != Integer.MAX_VALUE) {
                        var1 = this.application.min_pos;
                        breakk = true;
                    }

                    if (MyApplication.isBreak) {
                        isImageComplate = true;
                        this.stopSelf();
                        return;
                    }
                }

                if (breakk) {
                    ArrayList var18 = new ArrayList();
                    var18.addAll(this.application.videoImages);
                    this.application.videoImages.clear();
                    int var4 = Math.min(var18.size(),
                            Math.max(0, var1 - var1) * 30);

                    for (var3 = 0; var3 < var4; ++var3) {
                        this.application.videoImages.add((String) var18
                                .get(var3));
                    }

                    this.application.min_pos = Integer.MAX_VALUE;
                }

                if (!isSameTheme() || MyApplication.isBreak) {
                    break;
                }

                this.application.videoImages.add(var16.getAbsolutePath());
                if ((float) var2 == MaskBitmap.ANIMATED_FRAME - 1.0F) {
                    for (var3 = 0; var3 < 8 && this.isSameTheme()
                            && !MyApplication.isBreak; ++var3) {
                        this.application.videoImages.add(var16
                                .getAbsolutePath());
                    }
                }

                this.calculateProgress(var1, var2);
            }

            var3 = var1;
        }

        Glide.get(this).clearDiskCache();
        isImageComplate = true;
        this.stopSelf();
        this.isSameTheme();
    }

    private boolean isSameTheme() {
        return this.selecte_theme.equals(this.application.getCurrentTheme());
    }

    private void calculateProgress(int i, int j) {
        int progress = (int) ((100.0f * ((float) this.application.videoImages
                .size())) / ((float) ((this.total_images - 1) * 30)));
        updateNotification(progress);
        new Handler(Looper.getMainLooper())
                .post(new samethemeProgress(progress));
    }

    private void updateNotification(int progress) {
        this.builder.setProgress(100,
                (int) ((25.0f * ((float) progress)) / 100.0f), false);
        this.notify_manager.notify(1001,
                this.builder.build());
    }
}
