package com.example.womenabsworkout.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.activities.ExcDetailsActivity;

import java.util.ArrayList;
import java.util.HashMap;
import kr.pe.burt.android.lib.faimageview.FAImageView;


public class IndividualDayAdapter extends RecyclerView.Adapter<IndividualDayAdapter.ViewHolder> {
    public HashMap<String, ArrayList<Integer>> arrayListHashMap = this.arrayListHashMap;
    public Context context;
    public String day;
    public int screenWidth;
    public ArrayList<WorkoutData> workoutDataList;

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView b;
        public FAImageView c;
        public RelativeLayout d;
        public TextView f875a;

        public ViewHolder(View view) {
            super(view);
            this.f875a = (TextView) view.findViewById(R.id.exerciseName);
            this.b = (TextView) view.findViewById(R.id.rotation);
            this.c = (FAImageView) view.findViewById(R.id.animation);
            this.d = (RelativeLayout) view.findViewById(R.id.cardViewInRecycler);
        }
    }

    public IndividualDayAdapter(Context context, String str, ArrayList<WorkoutData> arrayList, int i) {
        this.context = context;
        this.screenWidth = i;
        this.day = str;
        this.workoutDataList = arrayList;
    }

    public int getItemCount() {
        return this.workoutDataList.size();
    }

    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        if (i < this.workoutDataList.size()) {
            TextView textView;
            StringBuilder stringBuilder;
            int i2 = 0;
            viewHolder.d.setVisibility(View.VISIBLE);
            viewHolder.c.setInterval(1000);
            viewHolder.c.setLoop(true);
            viewHolder.c.reset();
            int[] imageIdList = ((WorkoutData) this.workoutDataList.get(i)).getImageIdList();
            int length = imageIdList.length;
            while (i2 < length) {
                viewHolder.c.addImageFrame(imageIdList[i2]);
                i2++;
            }
            viewHolder.c.startAnimation();
            viewHolder.f875a.setText(((WorkoutData) this.workoutDataList.get(i)).getExcName().replace("_", " ").toUpperCase());
            if (((WorkoutData) this.workoutDataList.get(i)).getExcName().equals("plank")) {
                textView = viewHolder.b;
                stringBuilder = new StringBuilder();
                stringBuilder.append(((WorkoutData) this.workoutDataList.get(i)).getExcCycles());
                stringBuilder.append("s");
            } else {
                textView = viewHolder.b;
                stringBuilder = new StringBuilder();
                stringBuilder.append("x");
                stringBuilder.append(((WorkoutData) this.workoutDataList.get(i)).getExcCycles());
            }
            textView.setText(stringBuilder.toString());
        } else {
            viewHolder.d.setVisibility(View.GONE);
        }
        viewHolder.d.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(IndividualDayAdapter.this.context, ExcDetailsActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("day", IndividualDayAdapter.this.day);
                bundle.putIntArray("framesIdArray", ((WorkoutData) IndividualDayAdapter.this.workoutDataList.get(i)).getImageIdList());
                bundle.putString("excName", ((WorkoutData) IndividualDayAdapter.this.workoutDataList.get(i)).getExcName());
                bundle.putInt("excNameDescResId", ((WorkoutData) IndividualDayAdapter.this.workoutDataList.get(i)).getExcDescResId());
                bundle.putInt("excCycle", ((WorkoutData) IndividualDayAdapter.this.workoutDataList.get(i)).getExcCycles());
                bundle.putInt("excPosition", i);
                intent.putExtras(bundle);
                IndividualDayAdapter.this.context.startActivity(intent);
            }
        });
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_days, viewGroup, false));
    }
}
