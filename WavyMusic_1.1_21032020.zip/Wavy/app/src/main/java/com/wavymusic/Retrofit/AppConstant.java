package com.wavymusic.Retrofit;

public class AppConstant {
    public static String BASEURL ="http://beatsadmin.trendinganimations.com/public/api/";
    public static String Token = "aciativtyksdfhal5215ajal";
    public static String ApplicationId = "5";
}
