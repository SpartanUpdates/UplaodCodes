package com.kotlinz.festivalstorymaker.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.text.Layout;
import android.text.TextUtils;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.AlphaAnimation;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.kotlinz.festivalstorymaker.Interface.g;
import com.kotlinz.festivalstorymaker.Interface.x8;
import com.kotlinz.festivalstorymaker.Other.AppConstant;
import com.kotlinz.festivalstorymaker.Other.TextInputDilaog;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.Other.g.c;
import com.kotlinz.festivalstorymaker.Utils.BorderedTextView;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.Utils.MagnifierView;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerActivity;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerSavePath;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ReturnMode;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.cameraonly.CameraOnlyConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter;
import com.kotlinz.festivalstorymaker.texteditor.FontListAdapter;
import com.xiaopo.flying.sticker.Sticker;
import com.xiaopo.flying.sticker.StickerView;
import com.xiaopo.flying.sticker.TextSticker;
import com.yalantis.ucrop.UCropActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class FrameEditorNewDesign extends BaseActivity implements c, MagnifierView.c, FontListAdapter.a, ColorListAdapter.a, g, x8, ImageStickerViewNew.b {
    Activity activity = FrameEditorNewDesign.this;
    public static float A1 = -1.0f;
    public static float B1 = 0.0f;
    public static ArrayList<com.kotlinz.festivalstorymaker.Models.g> C1;
    public static ArrayList<com.kotlinz.festivalstorymaker.Models.g> D1;
    public static ArrayList<ImageView> E1;
    public static ImageView F1;
    public static RecyclerView G1;
    public static RecyclerView H1;
    public static RecyclerView I1;
    public static RecyclerView J1;
    public static String K1;
    public static boolean L1 = false;
    public static boolean M1 = false;
    public static boolean N1 = false;
    public static boolean O1 = false;
    public static boolean P1 = false;
    public static boolean Q1 = false;

    public static boolean R1 = false;
    public static boolean S1 = false;
    public static boolean T1 = false;
    public static boolean U1 = false;
    public static boolean V1 = false;
    public static MagnifierView.c W1;
    public static MagnifierView X1;
    public static RelativeLayout u1;
    public static ImageView v1;
    public static TextView w1;
    public static int x1;
    public static float y1;
    public static float z1;
    public int A0;
    public int B0;
    public int C0;
    public int D0;
    public int E0;
    public com.kotlinz.festivalstorymaker.Other.Utils F0;
    public int[][] I;
    public int[] J;
    public String J0;
    public ArrayList<Integer> K;
    public AppConstant K0;
    public CardView L;
    public boolean L0;
    public CardView M;
    public boolean M0;
    public x8 N;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.a> N0;
    public com.kotlinz.festivalstorymaker.Other.g.a O;
    public ArrayList<String> O0;
    public String P;
    public ArrayList<ImageView> P0;
    public ArrayList<Boolean> Q;
    public ArrayList<Integer> Q0;
    public ArrayList<Boolean> R;
    public ArrayList<Integer> R0;
    public ArrayList<ArrayList<ImageView>> S;
    public ArrayList<ArrayList<View>> T;
    public String T0;
    public ArrayList<ArrayList<View>> U;
    public boolean U0;
    public ArrayList<ArrayList<View>> V;
    public int V0;
    public ArrayList<ArrayList<View>> W;
    public boolean W0;
    public RelativeLayout X;
    public double X0;
    public ArrayList<ArrayList<com.kotlinz.festivalstorymaker.Models.g>> Y;
    public double Y0;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.g> Z;
    public float Z0;
    public FrameLayout a0;
    public float a1;
    public String b0;
    public boolean b1;
    public int c0;
    public boolean c1;
    public int d0;
    public boolean d1;
    public int e0;
    public View e1;
    public FrameLayout f0;
    public float f1;
    public FrameLayout g0;
    public float g1;
    public FrameLayout h0;
    public ImageStickerViewNew h1;
    public FrameLayout i0;
    public ImageStickerViewNew i1;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlign)
    public ImageView imgAlign;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignCenter)
    public ImageView imgAlignCenter;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignLeft)
    public ImageView imgAlignLeft;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignRight)
    public ImageView imgAlignRight;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAllCap)
    public ImageView imgAllCap;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgCaps)
    public ImageView imgCaps;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgColor)
    public ImageView imgColor;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFirstCap)
    public ImageView imgFirstCap;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFont)
    public ImageView imgFont;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgLine)
    public ImageView imgLine;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSmall)
    public ImageView imgSmall;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSpace)
    public ImageView imgSpace;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSquareSize)
    public ImageView imgSquareSize;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgStorySize)
    public ImageView imgStorySize;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgVerticalSize)
    public ImageView imgVerticalSize;
    public RelativeLayout j0;
    public ImageStickerViewNew j1;
    public ImageView k0;
    public ImageStickerViewNew.b k1;
    public List<String> l0;
    public boolean l1;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listColor)
    public RecyclerView listColor;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listFont)
    public RecyclerView listFont;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llAlign)
    public LinearLayout llAlign;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llCaps)
    public LinearLayout llCaps;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llChangeViewType)
    public LinearLayout llChangeViewType;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llColors)
    public LinearLayout llColors;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llFonts)
    public LinearLayout llFonts;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llLine)
    public LinearLayout llLine;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llList)
    public LinearLayout llList;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llSpacing)
    public LinearLayout llSpacing;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llTextEditor)
    public LinearLayout llTextEditor;
    public ArrayList<ArrayList<Integer>> m0;
    public Dialog m1;
    public ArrayList<Float> n0;
    public FontListAdapter n1;
    public ArrayList<Float> o0;
    public com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter o1;
    public ArrayList<Float> p0;
    public int p1;
    public ArrayList<ImageView> q0;
    public int q1;
    public ArrayList<View> r0;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.z.c> r1;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog)
    public RelativeLayout rlBottomMoveDeleteDialog;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rlFull)
    public RelativeLayout rlFull;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rlTop)
    public RelativeLayout rlTop;
    public ArrayList<View> s0;
    public TextStickerViewNew1 s1;

    @BindView(com.kotlinz.festivalstorymaker.R.id.scroll)
    public ScrollView scroll;

    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontHeight)
    public SeekBar seekBarFontHeight;
    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontSpacing)
    public SeekBar seekBarFontSpacing;

    public ArrayList<View> t0;
    public boolean t1;

    public ArrayList<View> u0;
    public ArrayList<FrameLayout> v0;
    public ArrayList<RelativeLayout> w0;
    public ArrayList<FrameLayout> x0;
    public ArrayList<String> y0;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.o> z0;


    StickerView stickerView;

    String FilePath;

    public String IsFrom;
    public String IsFromModule;

    private int ModuleId;


    public FrameEditorNewDesign() {
        this.b0 = "NEW_ARRIVAL_STICKER";
        this.c0 = 0;
        this.B0 = 0;
        this.C0 = 7;
        this.D0 = -1;
        this.E0 = -1;
        this.L0 = false;
        this.M0 = true;
        this.N0 = new ArrayList<com.kotlinz.festivalstorymaker.Models.a>();
        this.O0 = new ArrayList<String>();
        this.P0 = new ArrayList<ImageView>();
        this.Q0 = new ArrayList<Integer>();
        this.R0 = new ArrayList<Integer>();
        this.T0 = "";
        this.U0 = false;
        this.V0 = 0;
        this.W0 = false;
        this.b1 = false;
        this.c1 = false;
        this.d1 = false;
        this.l1 = false;
        this.p1 = -1;
        this.q1 = -1;
        this.r1 = new ArrayList<com.kotlinz.festivalstorymaker.Models.z.c>();
        this.t1 = false;
    }

    public static void j0(final FrameEditorNewDesign frameEditorNewDesign) {
        if (!frameEditorNewDesign.L0) {
            for (int i = 0; i < frameEditorNewDesign.x0.size(); ++i) {
                for (int j = 0; j < frameEditorNewDesign.x0.get(i).getChildCount(); ++j) {
                    if (frameEditorNewDesign.x0.get(i).getChildAt(j) instanceof ImageStickerViewNew) {
                        frameEditorNewDesign.x0.get(i).removeViewAt(j);
                    }
                }
                frameEditorNewDesign.x0.get(i).requestLayout();
            }
        }
    }

    public static void k0(final FrameEditorNewDesign frameEditorNewDesign, final View view) {
        if (frameEditorNewDesign != null) {
            final AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
            alphaAnimation.setDuration(700L);
            alphaAnimation.setStartOffset(100L);
            alphaAnimation.setRepeatMode(2);
            alphaAnimation.setRepeatCount(2);
            view.startAnimation(alphaAnimation);
            return;
        }
        throw null;
    }

    public final void A0(final FrameLayout frameLayout, final View view, final TextView textView) {
        this.u0();
        if (!this.l1) {
            TextInputDilaog.s0(this, textView.getText().toString(), false, "").m0 = new com.kotlinz.festivalstorymaker.Other.TextInputDilaog.d() {
                @Override
                public void a(final String text, final int n) {
                    textView.setBackground(null);
                    if (text.length() == 0) {
                        frameLayout.removeView(view);
                        frameLayout.requestLayout();
                        return;
                    }
                    textView.setText(text);
                }

                @Override
                public void b(final String text) {
                    textView.setBackground(null);
                    if (text.length() == 0) {
                        frameLayout.removeView(view);
                        frameLayout.requestLayout();
                        return;
                    }
                    textView.setText(text);
                }
            };
            return;
        }
        this.l1 = false;
    }

    @Override
    public void B(final Typeface c, final int f) {
        final com.kotlinz.festivalstorymaker.TypeFace.Font font = this.s1.getFont();
        font.c = c;
        this.s1.setFont(font);
        final com.kotlinz.festivalstorymaker.Models.z.c c2 = this.r1.get((int) this.s1.getTag());
        c2.f = f;
        this.r1.set((int) this.s1.getTag(), c2);
    }

    public final void B0(final boolean b) {
        final StringBuilder sb = new StringBuilder();
        sb.append(" openTextEditor:");
        sb.append(b);
        if (b) {
            this.p0(this.imgFont);
            final com.kotlinz.festivalstorymaker.Models.z.c c = this.r1.get((int) this.s1.getTag());
            this.p1 = c.d;
            this.q1 = c.f;
            this.seekBarFontSpacing.setProgress(c.a);
            this.seekBarFontHeight.setProgress(c.b);
            this.o1.k(this.p1);
            this.n1.k(this.q1);
            this.m0(c.c);
            this.n0(c.e);
        }
        final View viewById = this.findViewById(com.kotlinz.festivalstorymaker.R.id.llTextEditor);
        com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.B(80, 500L, 2131296874, this.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView));
        int visibility;
        if (b) {
            visibility = 0;
        } else {
            visibility = 8;
        }
        viewById.setVisibility(visibility);
    }


    @Override
    public void D(final int d) {
        final com.kotlinz.festivalstorymaker.TypeFace.Font font = this.s1.getFont();
        font.a = Color.parseColor(super.colorList[d]);
        this.s1.setFont(font);
        final com.kotlinz.festivalstorymaker.Models.z.c c = this.r1.get((int) this.s1.getTag());
        c.d = d;
        this.r1.set((int) this.s1.getTag(), c);
    }

    public final void D0(final String s, int size, final boolean b) {
        final Bitmap g = com.kotlinz.festivalstorymaker.Other.Utils.g(this, Uri.fromFile(new File(s)));
        if (g == null) {
            return;
        }
        g.compress(Bitmap.CompressFormat.PNG, 100, new ByteArrayOutputStream());
        final int[][] s2 = com.kotlinz.festivalstorymaker.Other.Utils.s(g);
        this.I = s2;
        this.J = com.kotlinz.festivalstorymaker.Other.l.n.a.a.a.aa.a(s2, 25);
        this.K = new ArrayList<Integer>();
        final int[] j = this.J;
        for (int length = j.length, i = 0; i < length; ++i) {
            this.K.add(j[i]);
        }
        this.K.add(-1);
        this.K.add(-16777216);
        this.K.add(null);
        final ArrayList<ArrayList<Integer>> m0 = this.m0;
        if (b) {
            size = m0.size();
            final int d0 = this.d0;
            if (size > d0) {
                this.m0.set(d0, this.K);
            } else {
                this.m0.add(this.K);
            }
            FrameEditorNewDesign.I1.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                public void onGlobalLayout() {
                    FrameEditorNewDesign.I1.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    FrameEditorNewDesign.I1.getLayoutParams().height = FrameEditorNewDesign.I1.getWidth();
                    FrameEditorNewDesign.I1.requestLayout();
                    final RecyclerView i1 = FrameEditorNewDesign.I1;
                    final FrameEditorNewDesign e = FrameEditorNewDesign.this;
                    i1.setAdapter(new com.kotlinz.festivalstorymaker.Adapter.a0(e, e.K, e.d0, e.N, false, i1.getWidth()));
                }
            });
            FrameEditorNewDesign.G1.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                public void onGlobalLayout() {
                    FrameEditorNewDesign.G1.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    FrameEditorNewDesign.G1.getLayoutParams().height = FrameEditorNewDesign.G1.getWidth();
                    FrameEditorNewDesign.G1.requestLayout();
                    final RecyclerView g1 = FrameEditorNewDesign.G1;
                    final FrameEditorNewDesign e = FrameEditorNewDesign.this;
                    g1.setAdapter((new com.kotlinz.festivalstorymaker.Adapter.a0(e, e.K, e.d0, e.N, true, g1.getWidth())));
                }
            });
            return;
        }
        m0.add(this.K);
        ++size;
        final List<String> l0 = this.l0;
        if (l0 != null && l0.size() > size) {
            com.kotlinz.festivalstorymaker.Other.Utils.d();
            this.D0(this.l0.get(size), size, false);
        }
    }

    public final void E0(int i, final boolean b) {
        final LayoutInflater layoutInflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
        int n;
        n = com.kotlinz.festivalstorymaker.R.layout.canvas_edit_list_item;
        final View inflate = layoutInflater.inflate(n, null);
        stickerView = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.sticker_view);
        final FrameLayout frameLayout = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMain);
        final FrameLayout frameLayout2 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.rlLogo);
        this.x0.add(frameLayout2);
        final FrameLayout frameLayout3 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.rlLabelLogo);
        final RelativeLayout relativeLayout = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView);
        final RelativeLayout relativeLayout2 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainFrameView);
        final ImageView imageView = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.imgWaterMark);
        final SeekBar seekBar = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.seekBar);
        final CardView cardView = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardPrice);
        final CardView cardView2 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardAddText);
        final CardView cardView3 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardLogo);
        final CardView cardView4 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardEditor);
        final CardView cardView5 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardWt);
        final CardView cardView6 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardBt);
        final CardView cardView8 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardShare);
        final CardView cardView9 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardDelete);
        inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardNewArrival).setVisibility(View.GONE);
        final RecyclerView recyclerView = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.rvPrimaryColor);
        final RecyclerView recyclerView2 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.rvSecondaryColor);
        final RelativeLayout relativeLayout3 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.rlSeekBar);
        final CardView cardView10 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.llTextGroup1);
        final CardView cardView11 = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.llTextGroup2);
        final StringBuilder sb = new StringBuilder();
        sb.append(10 - this.A0);
        sb.append(" FREE");
        int visibility2;
        if (com.kotlinz.festivalstorymaker.Other.Utils.y(this, false)) {
            visibility2 = 8;
        } else {
            visibility2 = 0;
        }
        imageView.setVisibility(visibility2);
        final ArrayList<ArrayList<Integer>> m0 = this.m0;
        if (m0 != null && m0.size() > i && this.m0.get(i) != null) {
            int finalI5 = i;
            recyclerView2.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                public void onGlobalLayout() {
                    recyclerView2.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    recyclerView2.getLayoutParams().height = recyclerView2.getWidth() + 10;
                    recyclerView2.requestLayout();
                    final RecyclerView e = recyclerView2;
                    final FrameEditorNewDesign g = FrameEditorNewDesign.this;
                    e.setAdapter(new com.kotlinz.festivalstorymaker.Adapter.a0(g, g.m0.get(finalI5), finalI5, FrameEditorNewDesign.this.N, false, recyclerView2.getWidth()));
                }
            });
            int finalI6 = i;
            recyclerView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                public void onGlobalLayout() {
                    recyclerView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    recyclerView.getLayoutParams().height = recyclerView.getWidth() + 10;
                    recyclerView.requestLayout();
                    final RecyclerView e = recyclerView;
                    final FrameEditorNewDesign g = FrameEditorNewDesign.this;
                    e.setAdapter(new com.kotlinz.festivalstorymaker.Adapter.a0(g, g.m0.get(finalI6), finalI6, FrameEditorNewDesign.this.N, true, recyclerView.getWidth()));
                }
            });
        }
        relativeLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                u0();
            }
        });
        cardView5.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                cardView5.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                cardView5.getLayoutParams().height = cardView5.getWidth();
                cardView5.requestLayout();
            }
        });
        cardView6.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                cardView6.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                cardView6.getLayoutParams().height = cardView6.getWidth();
                cardView6.requestLayout();
            }
        });
        if (this.b1) {
            int cardBackgroundColor;
            if (FrameEditorNewDesign.U1) {
                cardBackgroundColor = -16777216;
            } else {
                cardBackgroundColor = -1;
            }
            cardView5.setCardBackgroundColor(cardBackgroundColor);
        }
        int finalI = i;
        cardView5.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                FrameEditorNewDesign.U1 ^= true;
                FrameEditorNewDesign.this.u0();
                final FrameEditorNewDesign g = FrameEditorNewDesign.this;
                final int e = finalI;
                g.d0 = e;
                int n = 0;
                int n2;
                while (true) {
                    final int size = g.W.get(e).size();
                    n2 = -1;
                    if (n >= size) {
                        break;
                    }
                    if (g.W.get(e).get(n) instanceof ImageView) {
                        final ImageView imageView = (ImageView) g.W.get(e).get(n);
                        if (!g.Q.get(e)) {
                            n2 = -16777216;
                        }
                        imageView.setColorFilter(n2);
                    } else if (g.W.get(e).get(n) instanceof BorderedTextView) {
                        final BorderedTextView borderedTextView = (BorderedTextView) g.W.get(e).get(n);
                        if (!g.Q.get(e)) {
                            n2 = -16777216;
                        }
                        borderedTextView.setBorderedColor(n2);
                    } else {
                        final TextView textView = (TextView) g.W.get(e).get(n);
                        if (!g.Q.get(e)) {
                            n2 = -16777216;
                        }
                        textView.setTextColor(n2);
                    }
                    ++n;
                }
                final ArrayList<Boolean> q = FrameEditorNewDesign.this.Q;
                final int e2 = finalI;
                q.set(e2, q.get(e2) ^ true);
                final CardView f = cardView5;
                if (FrameEditorNewDesign.this.Q.get(finalI)) {
                    n2 = -16777216;
                }
                f.setCardBackgroundColor(n2);
            }
        });
        if (this.b1) {
            int cardBackgroundColor2;
            if (FrameEditorNewDesign.V1) {
                cardBackgroundColor2 = -1;
            } else {
                cardBackgroundColor2 = -16777216;
            }
            cardView6.setCardBackgroundColor(cardBackgroundColor2);
        }
        int finalI1 = i;
        cardView6.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                FrameEditorNewDesign.V1 ^= true;
                FrameEditorNewDesign.this.u0();
                final FrameEditorNewDesign g = FrameEditorNewDesign.this;
                final int e = finalI1;
                g.d0 = e;
                int n = 0;
                int n2;
                while (true) {
                    final int size = g.V.get(e).size();
                    n2 = -16777216;
                    if (n >= size) {
                        break;
                    }
                    if (g.V.get(e).get(n) instanceof ImageView) {
                        final ImageView imageView = (ImageView) g.V.get(e).get(n);
                        if (!g.R.get(e)) {
                            n2 = -1;
                        }
                        imageView.setColorFilter(n2);
                    } else if (g.V.get(e).get(n) instanceof BorderedTextView) {
                        final BorderedTextView borderedTextView = (BorderedTextView) g.V.get(e).get(n);
                        if (!g.R.get(e)) {
                            n2 = -1;
                        }
                        borderedTextView.setBorderedColor(n2);
                    } else {
                        final TextView textView = (TextView) g.V.get(e).get(n);
                        if (!g.R.get(e)) {
                            n2 = -1;
                        }
                        textView.setTextColor(n2);
                    }
                    ++n;
                }
                final ArrayList<Boolean> r = FrameEditorNewDesign.this.R;
                final int e2 = finalI1;
                r.set(e2, r.get(e2) ^ true);
                final CardView f = cardView6;
                if (FrameEditorNewDesign.this.R.get(finalI1)) {
                    n2 = -1;
                }
                f.setCardBackgroundColor(n2);
            }
        });
        int finalI9 = i;
        cardView3.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                FrameEditorNewDesign.this.u0();
                final FrameEditorNewDesign h = FrameEditorNewDesign.this;
                if (h.l1) {
                    h.l1 = false;
                    return;
                }
                h.d0 = finalI9;
                h.a0 = frameLayout;
                h.i0 = frameLayout2;
                if (h != null) {
                    final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    com.kotlinz.festivalstorymaker.Other.Utils.z(h).compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    final Intent putExtra = new Intent(h.getApplicationContext(), SelectLogoActivity.class).putExtra("image", byteArrayOutputStream.toByteArray());
                    h.startActivityForResult(putExtra, 7924);
                    return;
                }
                throw null;
            }
        });
        cardView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                View customLayout = getLayoutInflater().inflate(com.kotlinz.festivalstorymaker.R.layout.add_text_dialog, null);
                builder.setCancelable(false);
                builder.setView(customLayout);
                AlertDialog dialog = builder.create();
                EditText etText = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.add_text_edit_text);
                ImageView ivCancel = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.add_text_cancel_tv);
                ImageView ivDone = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.add_text_done_tv);
                ivCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                ivDone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TextSticker sticker = new TextSticker(activity);
                        if (etText.getText().toString().matches("")) {
                            Toast.makeText(activity, "Enter Text First", Toast.LENGTH_SHORT).show();
                        } else {
                            sticker.setText(etText.getText().toString());
                            sticker.setTextColor(Color.BLACK);
                            sticker.setTextAlign(Layout.Alignment.ALIGN_CENTER);
                            sticker.resizeText();
                            stickerView.addSticker(sticker);
                            dialog.dismiss();
                        }
                    }
                });
                dialog.show();
            }
        });
        imageView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        stickerView.setLocked(!stickerView.isLocked());
                        break;
                }
                return false;
            }
        });
        stickerView.setOnStickerOperationListener(new StickerView.OnStickerOperationListener() {
            @Override
            public void onStickerAdded(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerClicked(@NonNull Sticker sticker) {
                if (sticker instanceof TextSticker) {
                    ((TextSticker) sticker).setTextColor(Color.BLACK);
                    stickerView.replace(sticker);
                    stickerView.invalidate();
                }
            }

            @Override
            public void onStickerDeleted(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerDragFinished(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerTouchedDown(@NonNull Sticker sticker) {
                scroll.requestDisallowInterceptTouchEvent(true);
            }

            @Override
            public void onStickerZoomFinished(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerFlipped(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerDoubleTapped(@NonNull Sticker sticker) {

            }
        });
        int finalI8 = i;
        cardView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                FrameEditorNewDesign.this.u0();
                final FrameEditorNewDesign f = FrameEditorNewDesign.this;
                if (!f.l1) {
                    final int e = finalI8;
                    f.d0 = e;
                    final FrameLayout frameLayout = f.v0.get(e);
                    final View inflate = LayoutInflater.from(f).inflate(com.kotlinz.festivalstorymaker.R.layout.custom_price_tag_sticker, null);
                    final RelativeLayout relativeLayout = (RelativeLayout) com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.K(-2, -2, inflate, 2131297057);
                    final TextView textView = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.txtPrice);
                    textView.setBackground(null);
                    inflate.getViewTreeObserver().addOnGlobalLayoutListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.o5(f, inflate));
                    inflate.setOnTouchListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.q5(f, new GestureDetector((GestureDetector.OnGestureListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.p5(f, textView, frameLayout, inflate)), textView));
                    frameLayout.addView(inflate);
                    frameLayout.requestLayout();
                    final TextView w1 = FrameEditorNewDesign.w1;
                    if (w1 != null && w1 != textView) {
                        w1.setBackground(f.getResources().getDrawable(com.kotlinz.festivalstorymaker.R.drawable.rounded_corner_white));
                    }
                    f.A0(frameLayout, inflate, textView);
                    return;
                }
                f.l1 = false;
            }
        });
        int finalI3 = i;
        cardView8.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                u0();
                c0 = finalI3;
                final String d = com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(com.kotlinz.festivalstorymaker.Other.AppConstant.Categoryid, "");
//                com.kotlinz.festivalstorymaker.Other.Utils.J(d, y0.get(c0));
                final BaseActivity.b b = new b();
                b.execute(w0.get(c0));
            }
        });
        int finalI7 = i;
        cardView9.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                FrameEditorNewDesign.this.u0();
                FrameEditorNewDesign.this.l0.remove(finalI7);
                FrameEditorNewDesign.this.v0.remove(frameLayout);
                FrameEditorNewDesign.this.x0.remove(frameLayout2);
                FrameEditorNewDesign.this.llList.removeView(inflate);
                FrameEditorNewDesign.this.llList.requestLayout();
            }
        });
        Label_1149:
        {
            if (FrameEditorNewDesign.A1 == -1.0f) {
                int finalI4 = i;
                cardView4.getViewTreeObserver().addOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener) new ViewTreeObserver.OnGlobalLayoutListener() {
                    public void onGlobalLayout() {
                        if (cardView4.getViewTreeObserver().isAlive()) {
                            cardView4.getViewTreeObserver().removeOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener) this);
                        }
                        FrameEditorNewDesign.A1 = (float) cardView4.getWidth();
                        FrameEditorNewDesign.this.q0 = new ArrayList<ImageView>();
                        FrameEditorNewDesign.this.t0 = new ArrayList<View>();
                        FrameEditorNewDesign.this.u0 = new ArrayList<View>();
                        FrameEditorNewDesign.this.r0 = new ArrayList<View>();
                        FrameEditorNewDesign.this.s0 = new ArrayList<View>();
                        final RelativeLayout relativeLayout = new RelativeLayout((Context) FrameEditorNewDesign.this);
                        relativeLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));

                        if (Y.size() > finalI4) {
                            for (int j = 0; j < Y.get(finalI4).size(); j++) {
                                F0(imageView, relativeLayout2, relativeLayout, frameLayout2, frameLayout, j, finalI4, recyclerView, recyclerView2, cardView10, cardView11, b, frameLayout3);
                            }
                        }
                        frameLayout.addView((View) relativeLayout);
                        final FrameEditorNewDesign r = FrameEditorNewDesign.this;
                        r.V.add(r.t0);
                        final FrameEditorNewDesign r2 = FrameEditorNewDesign.this;
                        r2.W.add(r2.u0);
                        final FrameEditorNewDesign r3 = FrameEditorNewDesign.this;
                        r3.T.add(r3.s0);
                        final FrameEditorNewDesign r4 = FrameEditorNewDesign.this;
                        r4.U.add(r4.r0);
                        final FrameEditorNewDesign r5 = FrameEditorNewDesign.this;
                        r5.S.add(r5.q0);
                        final ArrayList<ArrayList<ImageView>> s = FrameEditorNewDesign.this.S;
                        RelativeLayout relativeLayout2 = null;
                        int visibility = 0;
                        Label_0391:
                        {
                            if (s != null) {
                                final int size = s.size();
                                final int f = finalI4;
                                if (size > f && FrameEditorNewDesign.this.S.get(f).size() > 0) {
                                    relativeLayout2 = relativeLayout3;
                                    visibility = 0;
                                    break Label_0391;
                                }
                            }
                            relativeLayout2 = relativeLayout3;
                            visibility = 8;
                        }
                        relativeLayout2.setVisibility(visibility);
                    }
                });
            } else {
                this.q0 = new ArrayList<ImageView>();
                this.t0 = new ArrayList<View>();
                this.u0 = new ArrayList<View>();
                this.r0 = new ArrayList<View>();
                this.s0 = new ArrayList<View>();
                final RelativeLayout relativeLayout4 = new RelativeLayout(this);
                relativeLayout4.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
                if (this.Y.size() > i) {
                    for (int j = 0; j < this.Y.get(i).size(); ++j) {
                        this.F0(imageView, relativeLayout2, relativeLayout4, frameLayout2, frameLayout, j, i, recyclerView, recyclerView2, cardView10, cardView11, b, frameLayout3);
                    }
                }
                frameLayout.addView(relativeLayout4);
                this.V.add(this.t0);
                this.W.add(this.u0);
                this.T.add(this.s0);
                this.U.add(this.r0);
                this.S.add(this.q0);
                final ArrayList<ArrayList<ImageView>> s = this.S;
                if (s != null) {
                    final int size = s.size();
                    final int n2 = i;
                    if (size > n2 && this.S.get(n2).size() > 0) {
                        relativeLayout3.setVisibility(View.VISIBLE);
                        break Label_1149;
                    }
                }
                relativeLayout3.setVisibility(View.GONE);
            }
        }
        seekBar.setMax(180);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
                for (int i = 0; i < FrameEditorNewDesign.this.S.get(i).size(); ++i) {
                    FrameEditorNewDesign.this.S.get(i).get(i).setColorFilter(new a().a((float) (n - 180)));
                }
            }

            public void onStartTrackingTouch(final SeekBar seekBar) {
            }

            public void onStopTrackingTouch(final SeekBar seekBar) {
            }
        });
        ArrayList<Boolean> list;
        Boolean b2;
        if (this.b1) {
            this.Q.add(FrameEditorNewDesign.U1);
            list = this.R;
            b2 = FrameEditorNewDesign.V1;
        } else {
            this.Q.add(Boolean.FALSE);
            list = this.R;
            b2 = Boolean.FALSE;
        }
        list.add(b2);
        this.llList.addView(inflate);
        this.w0.add(relativeLayout2);
        this.v0.add(frameLayout);
        this.llList.requestLayout();
        final List<String> l0 = this.l0;
        if (l0 != null) {
            final int size2 = l0.size();
            ++i;
            if (size2 > i) {
                this.E0(i, b);
                return;
            }
        }
        if (!com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.R1)) {
            if (this.v0.size() > this.B0) {
                final ImageStickerViewNew i2 = this.i1;
                if (i2 != null) {
                    this.G0(this.B0, this.i1.getStickerPath(), i2.getLayoutLastX() - (this.i1.getBitmaps().getWidth() - this.i1.getWidths()) / 2.0f, this.i1.getLayoutLastY() - (this.i1.getBitmaps().getHeight() - this.i1.getHeights()) / 2.0f, this.i1.getHeights(), true);
                }
            }
            if (this.b1 || this.c1) {
                ImageView imageView2;
                int colorFilter;
                BorderedTextView borderedTextView;
                int borderedColor;
                TextView textView2;
                int textColor;
                for (i = 0; i < this.W.get(0).size(); ++i) {
                    if (this.W.get(0).get(i) instanceof ImageView) {
                        imageView2 = (ImageView) this.W.get(0).get(i);
                        if (FrameEditorNewDesign.U1) {
                            colorFilter = -16777216;
                        } else {
                            colorFilter = -1;
                        }
                        imageView2.setColorFilter(colorFilter);
                    } else if (this.W.get(0).get(i) instanceof BorderedTextView) {
                        borderedTextView = (BorderedTextView) this.W.get(0).get(i);
                        if (FrameEditorNewDesign.U1) {
                            borderedColor = -16777216;
                        } else {
                            borderedColor = -1;
                        }
                        borderedTextView.setBorderedColor(borderedColor);
                    } else {
                        textView2 = (TextView) this.W.get(0).get(i);
                        if (FrameEditorNewDesign.U1) {
                            textColor = -16777216;
                        } else {
                            textColor = -1;
                        }
                        textView2.setTextColor(textColor);
                    }
                }
                ImageView imageView3;
                int colorFilter2;
                BorderedTextView borderedTextView2;
                int borderedColor2;
                TextView textView3;
                int textColor2;
                for (i = 0; i < this.V.get(0).size(); ++i) {
                    if (this.V.get(0).get(i) instanceof ImageView) {
                        imageView3 = (ImageView) this.V.get(0).get(i);
                        if (FrameEditorNewDesign.V1) {
                            colorFilter2 = -1;
                        } else {
                            colorFilter2 = -16777216;
                        }
                        imageView3.setColorFilter(colorFilter2);
                    } else if (this.V.get(0).get(i) instanceof BorderedTextView) {
                        borderedTextView2 = (BorderedTextView) this.V.get(0).get(i);
                        if (FrameEditorNewDesign.V1) {
                            borderedColor2 = -1;
                        } else {
                            borderedColor2 = -16777216;
                        }
                        borderedTextView2.setBorderedColor(borderedColor2);
                    } else {
                        textView3 = (TextView) this.V.get(0).get(i);
                        if (FrameEditorNewDesign.V1) {
                            textColor2 = -1;
                        } else {
                            textColor2 = -16777216;
                        }
                        textView3.setTextColor(textColor2);
                    }
                }
                i = this.D0;
                if (i != -1) {
                    this.s0(true, 0, i);
                }
                i = this.E0;
                if (i != -1) {
                    this.s0(false, 0, i);
                }
                this.b1 = false;
                this.c1 = false;
            }
        }
    }

    public final void F0(final ImageView imageView, final RelativeLayout relativeLayout, final RelativeLayout relativeLayout2, final FrameLayout frameLayout, final FrameLayout frameLayout2, int n, final int n2, final RecyclerView recyclerView, final RecyclerView recyclerView2, final CardView cardView, final CardView cardView2, final boolean b, final FrameLayout frameLayout3) {
        if (n == 0) {
            FrameEditorNewDesign.z1 = (float) (int) Float.parseFloat(this.Y.get(n2).get(n).j);
            FrameEditorNewDesign.B1 = (FrameEditorNewDesign.y1 = (float) (int) Float.parseFloat(this.Y.get(n2).get(n).k)) * FrameEditorNewDesign.A1 / FrameEditorNewDesign.z1;
            frameLayout2.getLayoutParams().width = (int) FrameEditorNewDesign.A1;
            frameLayout2.getLayoutParams().height = (int) FrameEditorNewDesign.B1;
            frameLayout2.requestLayout();
            frameLayout.getLayoutParams().width = (int) FrameEditorNewDesign.A1;
            frameLayout.getLayoutParams().height = (int) FrameEditorNewDesign.B1;
            frameLayout.requestLayout();
            relativeLayout.getLayoutParams().width = (int) FrameEditorNewDesign.A1;
            relativeLayout.getLayoutParams().height = (int) FrameEditorNewDesign.B1;
            relativeLayout.requestLayout();
        }
        if (this.Y.get(n2).get(n).e.equalsIgnoreCase("image")) {
            FrameEditorNewDesign.C1.add(this.Y.get(n2).get(n));
            n = FrameEditorNewDesign.C1.size();
            this.l0(imageView, FrameEditorNewDesign.C1.get(n - 1), frameLayout2, n2, recyclerView, recyclerView2, cardView, cardView2, frameLayout3);
            return;
        }
        if (this.Y.get(n2).get(n).e.equalsIgnoreCase("text")) {
            FrameEditorNewDesign.D1.add(this.Y.get(n2).get(n));
            n = FrameEditorNewDesign.D1.size() - 1;
            final float n3 = Float.parseFloat(FrameEditorNewDesign.D1.get(n).w) * FrameEditorNewDesign.A1 / FrameEditorNewDesign.z1;
            final com.kotlinz.festivalstorymaker.Models.g g = FrameEditorNewDesign.D1.get(n);
            final com.kotlinz.festivalstorymaker.TypeFace.Font a = new com.kotlinz.festivalstorymaker.TypeFace.Font();
            if (g.v.length() > 0) {
                a.a = Color.parseColor(g.v);
            }
            a.b = n3 / Resources.getSystem().getDisplayMetrics().density;
            final AssetManager assets = this.getAssets();
            final StringBuilder v = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.v("fonts/");
            v.append(com.kotlinz.festivalstorymaker.Other.Utils.k(this, FrameEditorNewDesign.D1.get(n).A));
            a.c = Typeface.createFromAsset(assets, v.toString());
            final com.kotlinz.festivalstorymaker.Models.g g2 = FrameEditorNewDesign.D1.get(n);
            this.Z0 = Float.parseFloat(g2.h) * FrameEditorNewDesign.A1 / FrameEditorNewDesign.z1;
            this.a1 = Float.parseFloat(g2.i) * FrameEditorNewDesign.A1 / FrameEditorNewDesign.z1;
            this.X0 = Double.parseDouble(g2.j) * FrameEditorNewDesign.A1 / FrameEditorNewDesign.z1;
            this.Y0 = Double.parseDouble(g2.k) * FrameEditorNewDesign.B1 / FrameEditorNewDesign.y1;
            n = g2.n.length();
            final float z0 = this.Z0;
            final float a2 = this.a1;
            final double x0 = this.X0;
            final double y0 = this.Y0;
            Object o = null;
            Label_1135:
            {
                if (n <= 0) {
                    final TextView f = com.kotlinz.festivalstorymaker.Other.Utils.f(this, g2, z0, a2, x0, y0, a, true, true);
                    f.setOnTouchListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.l5(this, new GestureDetector(new com.kotlinz.festivalstorymaker.Listener.SetListener.k5(this, f, g2, frameLayout2))));
                    if (g2.y.length() > 0 && Integer.parseInt(g2.y) > 0) {
                        f.setX((float) (this.X0 / 2.0 + (this.Z0 - this.Y0 / 2.0)));
                        f.setY((float) (this.Y0 / 2.0 + (this.a1 - this.X0 / 2.0)));
                        f.setRotation((float) Integer.parseInt(g2.y));
                        f.getLayoutParams().height = (int) this.X0;
                        f.getLayoutParams().width = (int) this.Y0;
                        f.requestLayout();
                    }
                    if (g2.E.equals("1")) {
                        this.t0.add(f);
                    }
                    if (g2.F.equals("1")) {
                        this.u0.add(f);
                    }
                    if (g2.G.equals("1")) {
                        this.r0.add(f);
                    }
                    o = f;
                    if (!g2.D.equals("1")) {
                        break Label_1135;
                    }
                    o = f;
                } else {
                    final BorderedTextView h = com.kotlinz.festivalstorymaker.Other.Utils.h(this, g2, z0, a2, x0, y0, a, true);
                    h.setOnTouchListener((View.OnTouchListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.n5(this, new GestureDetector((GestureDetector.OnGestureListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.m5(this, h, g2, frameLayout2))));
                    if (g2.y.length() > 0 && Integer.parseInt(g2.y) > 0) {
                        h.setX((float) (this.X0 / 2.0 + (this.Z0 - this.Y0 / 2.0)));
                        h.setY((float) (this.Y0 / 2.0 + (this.a1 - this.X0 / 2.0)));
                        h.setRotation((float) Integer.parseInt(g2.y));
                        h.getLayoutParams().height = (int) this.X0;
                        h.getLayoutParams().width = (int) this.Y0;
                        h.requestLayout();
                    }
                    if (g2.E.equals("1")) {
                        this.t0.add(h);
                    }
                    if (g2.F.equals("1")) {
                        this.u0.add(h);
                    }
                    if (g2.G.equals("1")) {
                        this.r0.add(h);
                    }
                    o = h;
                    if (!g2.D.equals("1")) {
                        break Label_1135;
                    }
                    o = h;
                }
                this.s0.add((View) o);
            }
            frameLayout2.addView((View) o);
            frameLayout2.requestLayout();
            ++FrameEditorNewDesign.x1;
        }
    }

    public void G0(int n, final String s, final float n2, final float n3, final float size, final boolean b) {
        final File file = new File(s);
        if (file.exists()) {
            int n4 = 0;
            Label_0325:
            {
                try {
                    final Bitmap decodeFile = BitmapFactory.decodeFile(file.getAbsolutePath());
                    final ImageStickerViewNew imageStickerViewNew = new ImageStickerViewNew(this, s, n2, n3, 1.0f, 0.0f, 2, true);
                    n4 = 0;
                    imageStickerViewNew.setGif(false);
                    imageStickerViewNew.setBitmap(decodeFile, Boolean.TRUE);
                    int finalN = n;
                    imageStickerViewNew.setOperationListener(new ImageStickerViewNew.c() {
                        @Override
                        public void a(final ImageStickerViewNew h1) {
                            final ImageStickerViewNew h2 = FrameEditorNewDesign.this.h1;
                            if (h2 != null) {
                                h2.setInEdit(false);
                            }
                            final FrameEditorNewDesign c = FrameEditorNewDesign.this;
                            c.h1 = h1;
                            if (finalN == 0) {
                                c.i1 = imageStickerViewNew;
                            }
                            FrameEditorNewDesign.this.h1.setInEdit(true);
                        }

                        @Override
                        public void b(final ImageStickerViewNew imageStickerViewNew) {
                            FrameEditorNewDesign.this.x0.get(finalN).removeView(FrameEditorNewDesign.this.h1);
                        }

                        @Override
                        public void c(final Boolean b) {
                            FrameEditorNewDesign.this.scroll.requestDisallowInterceptTouchEvent(b);
                            if (b) {
                                final FrameEditorNewDesign c = FrameEditorNewDesign.this;
                                final ImageStickerViewNew b2 = imageStickerViewNew;
                                c.h1 = b2;
                                if (finalN == 0) {
                                    c.i1 = b2;
                                }
                            }
                        }

                        @Override
                        public void d(final ImageStickerViewNew imageStickerViewNew) {
                        }
                    });
                    imageStickerViewNew.setInEdit(false);
                    imageStickerViewNew.setSize(size);
                    imageStickerViewNew.setListner(this.k1, "");
                    if (this.x0.size() > n) {
                        if (n4 < this.x0.get(n).getChildCount()) {
                            if (this.x0.get(n).getChildAt(n4) instanceof ImageStickerViewNew) {
                                FrameLayout frameLayout;
                                if (this.x0.get(n).getChildAt(n4).getTag() != null) {
                                    if (this.x0.get(n).getChildAt(n4).getTag().toString().equalsIgnoreCase(this.b0)) {
                                        break Label_0325;
                                    }
                                    frameLayout = this.x0.get(n);
                                } else {
                                    frameLayout = this.x0.get(n);
                                }
                                frameLayout.removeViewAt(n4);
                            }
                            break Label_0325;
                        } else {
                            this.x0.get(n).addView(imageStickerViewNew);
                            this.x0.get(n).requestLayout();
                        }
                    }
                    if (b) {
                        final int size2 = this.x0.size();
                        ++n;
                        if (size2 > n) {
                            this.G0(n, s, n2, n3, size, b);
                            return;
                        }
                    }
                } catch (OutOfMemoryError outOfMemoryError) {
                    outOfMemoryError.printStackTrace();
                }

                ++n4;

            }
        }
    }

    public final void H0(final boolean b) {
        int visibility = 0;
        if (!b) {
            final TextView w1 = FrameEditorNewDesign.w1;
            if (w1 != null) {
                w1.setBackground(null);
            }
            final ImageView f1 = FrameEditorNewDesign.F1;
            if (f1 != null) {
                f1.setBackground(null);
            }
        } else if (this.findViewById(com.kotlinz.festivalstorymaker.R.id.llTextEditor).isShown()) {
            this.B0(false);
        }
        final View viewById = this.findViewById(com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog);
        com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.B(80, 500L, 2131297044, this.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView));
        if (!b) {
            visibility = 8;
        }
        viewById.setVisibility(visibility);
    }

    @Override
    public void L(final int n, final String s) {
    }

    @Override
    public void N(final int n) {
    }

    @Override
    public void P(final float n) {
        FrameEditorNewDesign.X1 = null;
        this.rlFull.setVisibility(View.GONE);
        this.o0((int) n);
    }

    @Override
    public void Q(final int n, final int n2) {
        this.u0();
        if (!this.l1) {
            this.o0(n2);
            return;
        }
        this.l1 = false;
    }

    @Override
    public Bitmap e0(final View view) {
        final boolean b = view.getHeight() > 1000 || view.getWidth() > 1000;
        final int height = view.getHeight();
        final int n = 2;
        int n2;
        if (b) {
            n2 = 2;
        } else {
            n2 = 3;
        }
        final int n3 = height * n2;
        final int width = view.getWidth();
        int n4;
        if (b) {
            n4 = n;
        } else {
            n4 = 3;
        }
        final int n5 = width * n4;
        view.measure(View.MeasureSpec.makeMeasureSpec(n5, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(n3, View.MeasureSpec.UNSPECIFIED));
        Bitmap bitmap = null;
        try {
            final Bitmap bitmap2 = bitmap = Bitmap.createBitmap(n5, n3, Bitmap.Config.ARGB_8888);
            final Canvas canvas = new Canvas(bitmap2);
            bitmap = bitmap2;
            canvas.translate(0.0f, 0.0f);
            bitmap = bitmap2;
            canvas.drawColor(-1, PorterDuff.Mode.CLEAR);
            bitmap = bitmap2;
            canvas.scale((float) (n5 / view.getWidth()), (float) (n3 / view.getHeight()));
            bitmap = bitmap2;
            view.draw(canvas);
            return bitmap2;
        } catch (Exception ex) {
            ex.printStackTrace();
            return bitmap;
        }
    }

    public final void g0(final FrameLayout frameLayout, final TextStickerViewNew1 textStickerViewNew1) {
        com.kotlinz.festivalstorymaker.Other.TextInputDilaog.q0(this, textStickerViewNew1.getText(), false, "").m0 = new com.kotlinz.festivalstorymaker.Other.TextInputDilaog.d() {
            @Override
            public void a(final String text, final int n) {
                if (text.length() == 0) {
                    frameLayout.removeView(textStickerViewNew1);
                    frameLayout.requestLayout();
                    return;
                }
                textStickerViewNew1.setText(text);
            }

            @Override
            public void b(final String s) {
            }
        };
    }


    @Override
    public void h(final boolean b, final boolean b2, int n, final int n2) {
        this.u0();
        final boolean l1 = this.l1;
        final int n3 = 0;
        if (l1) {
            this.l1 = false;
            return;
        }
        FrameEditorNewDesign.R1 = false;
        FrameEditorNewDesign.S1 = false;
        FrameEditorNewDesign.T1 = false;
        if (b) {
            if (b2) {
                FrameEditorNewDesign.R1 = true;
            } else {
                FrameEditorNewDesign.S1 = true;
            }
            this.d0 = n;
            this.H0(true);
            ((RecyclerView) findViewById(com.kotlinz.festivalstorymaker.R.id.rlColor)).setAdapter(new ColorListAdapter(this, getResources().getStringArray(com.kotlinz.festivalstorymaker.R.array.colors_list)));
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableDelete).setVisibility(View.GONE);
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDelete).setVisibility(View.INVISIBLE);
            final View viewById = this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableMove);
            if (!FrameEditorNewDesign.M1) {
                n = n3;
            } else {
                n = 8;
            }
            viewById.setVisibility(n);
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableMove).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.d5(this));
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableDelete).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.e5(this));
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.txtCancel).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.f5(this));
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.txtDone).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.g5(this));
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.llColorPicker).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.h5(this));
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.llPickColor).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.i5(this));
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDelete).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.j5(this));
            return;
        }
        if (b2) {
            this.s0(true, n, n2);
            return;
        }
        this.s0(false, n, n2);
    }


    public final void l0(ImageView imageView, final com.kotlinz.festivalstorymaker.Models.g g, final FrameLayout frameLayout, final int n, final RecyclerView g2, final RecyclerView i1, final CardView cardView, final CardView cardView2, final FrameLayout ex) {
        final Float value = Float.parseFloat(g.h) * FrameEditorNewDesign.A1 / FrameEditorNewDesign.z1;
        final Float value2 = Float.parseFloat(g.i) * FrameEditorNewDesign.A1 / FrameEditorNewDesign.z1;
        final int n2 = (int) (Float.parseFloat(g.j) * FrameEditorNewDesign.A1 / FrameEditorNewDesign.z1);
        final int n3 = (int) (Float.parseFloat(g.k) * FrameEditorNewDesign.A1 / FrameEditorNewDesign.z1);
        final ImageView f1 = new ImageView(this);
        if (!g.B.equals("1") && !g.q.equals("1")) {
            f1.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            f1.setX(value);
            f1.setY(value2);
            f1.getLayoutParams().width = n2;
            f1.getLayoutParams().height = n3;
            f1.requestLayout();
            f1.setAdjustViewBounds(true);
            f1.setScaleType(ImageView.ScaleType.CENTER_CROP);
            f1.requestLayout();
            if (g.C.equalsIgnoreCase("1")) {
                f1.setOnClickListener((View.OnClickListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.a5(this, n, f1, g));
            }

            if (!g.f.isEmpty()) {
                Glide.with(activity).load(g.f).into(f1);
            }

            FrameEditorNewDesign.E1.add(f1);
            frameLayout.addView(f1);
            frameLayout.requestLayout();
        } else {
            f1.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
            f1.getLayoutParams().width = n2;
            f1.getLayoutParams().height = n3;
            f1.setX(value);
            f1.setY(value2);
            if (this.n0.size() > n) {
                this.p0.set(n, Float.valueOf(n3));
                this.n0.set(n, value);
                this.o0.set(n, value2);
            } else {
                this.p0.add(Float.valueOf(n3));
                this.n0.add(value);
                this.o0.add(value2);
                this.M0 = false;
            }
            f1.setAdjustViewBounds(true);
            f1.setScaleType(ImageView.ScaleType.CENTER_CROP);
            f1.setTag(this.l0.get(n));
            if (g.q.equals("0") /*&& (this.H0.equalsIgnoreCase(com.kotlinz.festivalstorymaker.Other.AppConstant.Q1) || this.H0.equalsIgnoreCase(com.kotlinz.festivalstorymaker.Other.AppConstant.K1))*/ && !com.kotlinz.festivalstorymaker.Other.Utils.y(this, false) && imageView != null) {
                imageView.getViewTreeObserver().addOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.y4(this, imageView, value, n2, value2, n3));
            }
            if (g.q.equalsIgnoreCase("1")) {
                com.kotlinz.festivalstorymaker.Other.Utils.O();
                if (this.U0) {
                    this.P0.add(f1);
                    this.R0.add(n2);
                    this.Q0.add(n3);
                    this.O0.add(g.f);
                } else {
                    this.U0 = true;
                    FrameEditorNewDesign.F1 = f1;
                    FrameEditorNewDesign.G1 = g2;
                    FrameEditorNewDesign.I1 = i1;
                    this.J0 = g.f;
                    this.v0(this.l0.get(n), n2, n3);
                }
            } else if (g.B.equals("1")) {
                final List<String> l0 = this.l0;
                if (l0 != null && l0.size() > n && this.l0.get(n) != null) {
                    f1.setImageBitmap(com.kotlinz.festivalstorymaker.Other.Utils.A(this.l0.get(n)));
                } else {
                    Glide.with(activity).load(com.kotlinz.festivalstorymaker.R.drawable.add_mask_image).into(f1);
                }
            }
            f1.requestLayout();
            f1.setOnTouchListener(new z(this, f1, n, g, g2, i1));
            frameLayout.addView(f1);
            frameLayout.requestLayout();
            if (!com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.R1)) {
                final List<String> n4 = Utils.n(this);
                if (n4.size() > 0) {
                    final Bitmap decodeFile = BitmapFactory.decodeFile(new File(n4.get(0)).getAbsolutePath());
                    if (decodeFile != null) {
                        this.G0(n, n4.get(0), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) decodeFile.getWidth(), decodeFile.getWidth() * 150.0f / decodeFile.getHeight(), 2.0f, value + decodeFile.getWidth() / 2, 20.0f), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) decodeFile.getHeight(), 150.0f, 2.0f, value2 + decodeFile.getHeight() / 2, 20.0f), 150.0f, false);
                    }
                }
            }
            if (Utils.y(this, false)) {
                final String d = com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.D1, "");
                if (com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.A1, "").equalsIgnoreCase("2") && d.length() > 0) {
                    try {
                        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());
                        final Bitmap decodeStream = BitmapFactory.decodeStream(new URL(d).openConnection().getInputStream());
                        final float n5 = decodeStream.getWidth() * 150.0f / decodeStream.getHeight();
                        final float floatValue = value;
                        final float n6 = (float) n2;
                        final float n7 = (float) (decodeStream.getWidth() / 2);
                        final float n8 = (decodeStream.getWidth() - n5) / 2.0f;
                        final float x = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) decodeStream.getHeight(), 150.0f, 2.0f, value2 + decodeStream.getHeight() / 2, 20.0f);
                        final ImageView imageView2 = imageView;
                        final ImageStickerViewNew imageStickerViewNew = new ImageStickerViewNew(this, d, floatValue + n6 - (n7 - n8) - 20.0f, x, 1.0f, 0.0f, 2, true);
                        imageStickerViewNew.setGif(false);
                        final float b1 = FrameEditorNewDesign.B1;
                        final float a1 = FrameEditorNewDesign.A1;
                        imageStickerViewNew.m0 = true;
                        imageStickerViewNew.n0 = b1;
                        imageStickerViewNew.o0 = a1;
                        imageStickerViewNew.setTag(this.b0);
                        imageStickerViewNew.setBitmap(decodeStream, Boolean.TRUE);
                        imageStickerViewNew.setSize(150.0f);
                        imageStickerViewNew.setOperationListener((ImageStickerViewNew.c) new com.kotlinz.festivalstorymaker.Listener.SetListener.z4(this));
                        imageStickerViewNew.setInEdit(false);
                        ex.addView(imageStickerViewNew);
                        ex.requestLayout();
                        imageView = imageView2;
                    } catch (IOException ex2) {
                        ex2.printStackTrace();
                    }
                }
            }
        }
        if (g.p.equals("1")) {
            this.q0.add(f1);
        }
        if (g.E.equals("1")) {
            this.t0.add(f1);
        }
        if (g.F.equals("1")) {
            this.u0.add(f1);
        }
        if (g.G.equals("1")) {
            this.r0.add(f1);
        }
        if (g.D.equals("1")) {
            this.s0.add(f1);
        }
        if (g.D.equals("1") || g.G.equals("1") || g.F.equals("1") || g.E.equals("1")) {
            f1.setOnClickListener((View.OnClickListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.b5(this, n, f1, g, cardView, cardView2, g2, i1));
        }
        if (!g.B.equals("1") || !g.q.equals("1")) {
            f1.setOnLongClickListener((View.OnLongClickListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.c5(this, frameLayout, f1));
        }
    }

    @SuppressLint({"NewApi"})
    public final void m0(final int c) {
        final ImageView imgAlignCenter = this.imgAlignCenter;
        final int n = -16777216;
        int color;
        if (c == 0) {
            color = -16777216;
        } else {
            color = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgAlignCenter.setColorFilter(color);
        final ImageView imgAlignLeft = this.imgAlignLeft;
        int color2;
        if (c == -1) {
            color2 = -16777216;
        } else {
            color2 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgAlignLeft.setColorFilter(color2);
        final ImageView imgAlignRight = this.imgAlignRight;
        int color3;
        if (c == 1) {
            color3 = n;
        } else {
            color3 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgAlignRight.setColorFilter(color3);
        final String string = this.s1.getText();
        final TextStickerViewNew1 s1 = this.s1;
        Layout.Alignment align;
        if (c == 0) {
            align = Layout.Alignment.ALIGN_CENTER;
        } else if (c == 1) {
            align = Layout.Alignment.ALIGN_OPPOSITE;
        } else {
            align = Layout.Alignment.ALIGN_NORMAL;
        }
        s1.setAlign(align);
        this.s1.setText(string);
        this.s1.requestLayout();
        final com.kotlinz.festivalstorymaker.Models.z.c c2 = this.r1.get((int) this.s1.getTag());
        c2.c = c;
        this.r1.set((int) this.s1.getTag(), c2);
    }

    public final void n0(final int e) {
        final ImageView imgFirstCap = this.imgFirstCap;
        final int n = -16777216;
        int color;
        if (e == 1) {
            color = -16777216;
        } else {
            color = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgFirstCap.setColorFilter(color);
        final ImageView imgAllCap = this.imgAllCap;
        int color2;
        if (e == 2) {
            color2 = -16777216;
        } else {
            color2 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgAllCap.setColorFilter(color2);
        final ImageView imgSmall = this.imgSmall;
        int color3;
        if (e == 0) {
            color3 = n;
        } else {
            color3 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgSmall.setColorFilter(color3);
        final String string = this.s1.getText();
        if (e != -1) {
            final TextStickerViewNew1 s1 = this.s1;
            String text;
            if (e == 2) {
                text = string.toUpperCase();
            } else if (e == 0) {
                text = string.toLowerCase();
            } else {
                text = this.f0(string);
            }
            s1.setText(text);
        }
        final com.kotlinz.festivalstorymaker.Models.z.c c = this.r1.get((int) this.s1.getTag());
        c.e = e;
        this.r1.set((int) this.s1.getTag(), c);
    }

    public final void o0(final int n) {
        final boolean t1 = FrameEditorNewDesign.T1;
        boolean b = false;
        final int n2 = 0;
        if (!t1) {
            int n3;
            if (FrameEditorNewDesign.R1) {
                n3 = this.d0;
                b = true;
            } else if (FrameEditorNewDesign.S1) {
                n3 = this.d0;
            } else {
                if (FrameEditorNewDesign.M1) {
                    FrameEditorNewDesign.w1.setTextColor(n);
                    return;
                }
                FrameEditorNewDesign.F1.setColorFilter(n);
                return;
            }
            this.s0(b, n3, n);
            return;
        }
        int n4 = 0;
        int i;
        while (true) {
            i = n2;
            if (n4 >= this.V.get(this.d0).size()) {
                break;
            }
            if (this.V.get(this.d0).get(n4) instanceof ImageView) {
                ((ImageView) this.V.get(this.d0).get(n4)).setColorFilter(n);
            } else {
                ((TextView) this.V.get(this.d0).get(n4)).setTextColor(n);
            }
            ++n4;
        }
        while (i < this.W.get(this.d0).size()) {
            if (this.W.get(this.d0).get(i) instanceof ImageView) {
                ((ImageView) this.W.get(this.d0).get(i)).setColorFilter(n);
            } else {
                ((TextView) this.W.get(this.d0).get(i)).setTextColor(n);
            }
            ++i;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onActivityResult(final int n, final int n2, final Intent intent) {
        final int k = AppConstant.K;
        Label_2138:
        {
            if (724 == n) {
                if (Utils.b) {
                    this.finish();
                }
            } else if (n == 90 && intent != null) {
                new y(intent.getStringExtra("url"), intent.getIntExtra("pos", 0)).execute();
            } else {
                final int h = AppConstant.H;
                if (n == 7924 && intent != null) {
                    final String stringExtra = intent.getStringExtra("path");
                    if (!stringExtra.isEmpty()) {
                        for (int i = 0; i < this.i0.getChildCount(); ++i) {
                            if (this.i0.getChildAt(i) instanceof ImageStickerViewNew && (this.i0.getChildAt(i).getTag() == null || !this.i0.getChildAt(i).getTag().toString().equalsIgnoreCase(this.b0))) {
                                this.i0.removeViewAt(i);
                            }
                        }
                        final Bitmap decodeFile = BitmapFactory.decodeFile(new File(stringExtra).getAbsolutePath());
                        final float x = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) decodeFile.getWidth(), decodeFile.getWidth() * 150.0f / decodeFile.getHeight(), 2.0f, this.n0.get(this.d0) + decodeFile.getWidth() / 2, 20.0f);
                        final float x2 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) decodeFile.getHeight(), 150.0f, 2.0f, this.o0.get(this.d0) + decodeFile.getHeight() / 2, 20.0f);
                        int d0;
                        boolean b;
                        if (this.M0) {
                            this.M0 = false;
                            d0 = 0;
                            b = true;
                        } else {
                            d0 = this.d0;
                            b = false;
                        }
                        this.G0(d0, stringExtra, x, x2, 150.0f, b);
                    }
                } else {
                    final int g = AppConstant.G;
                    if (624 == n && intent != null) {
                        this.c1 = true;
                        if (this.l0.size() == 1) {
                            this.t0();
                        }
                        final int intExtra = intent.getIntExtra("primaryColor", -1);
                        final int intExtra2 = intent.getIntExtra("secondaryColor", -1);
                        final String stringExtra2 = intent.getStringExtra("design_id");
                        final ArrayList z = (ArrayList) intent.getSerializableExtra("list");
                        final int size = this.y0.size();
                        final int e0 = this.e0;
                        if (size > e0) {
                            this.y0.set(e0, intent.getStringExtra("frame_id"));
                        } else {
                            this.y0.add(intent.getStringExtra("frame_id"));
                        }
                        final int size2 = this.Y.size();
                        final int e2 = this.e0;
                        if (size2 > e2) {
                            this.Y.set(e2, z);
                        } else {
                            this.Y.add(z);
                        }
                        if (this.e0 == 0) {
                            this.Z = (ArrayList<com.kotlinz.festivalstorymaker.Models.g>) z;
                        }
                        final FrameLayout f0 = this.f0;
                        if (f0 != null) {
                            f0.removeAllViews();
                        }
                        this.q0 = new ArrayList<ImageView>();
                        this.t0 = new ArrayList<View>();
                        this.u0 = new ArrayList<View>();
                        this.r0 = new ArrayList<View>();
                        this.s0 = new ArrayList<View>();
                        final FrameLayout g2 = this.g0;
                        if (g2 != null) {
                            g2.removeAllViews();
                        }
                        final FrameLayout h2 = this.h0;
                        if (h2 != null) {
                            h2.removeAllViews();
                        }
                        if (this.l0.size() < 2) {
                            this.w0(stringExtra2);
                        } else {
                            final RelativeLayout relativeLayout = new RelativeLayout(this);
                            relativeLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
                            final Paint layerPaint = new Paint();
                            layerPaint.setColor(-65536);
                            layerPaint.setAntiAlias(true);
                            layerPaint.setDither(true);
                            layerPaint.setStyle(Paint.Style.STROKE);
                            layerPaint.setStrokeWidth(3.0f);
                            layerPaint.setPathEffect(new DashPathEffect(new float[]{10.0f, 15.0f}, 0.0f));
                            relativeLayout.setLayerPaint(layerPaint);
                            for (int j = 0; j < this.Y.get(this.e0).size(); ++j) {
                                this.F0(this.k0, this.j0, relativeLayout, this.g0, this.f0, j, this.e0, FrameEditorNewDesign.H1, FrameEditorNewDesign.J1, this.L, this.M, false, this.h0);
                            }
                            this.f0.addView(relativeLayout);
                            this.V.set(this.e0, this.t0);
                            this.W.set(this.e0, this.u0);
                            this.T.set(this.e0, this.s0);
                            this.U.set(this.e0, this.r0);
                            this.S.set(this.e0, this.q0);
                            final RelativeLayout x3 = this.X;
                            int visibility;
                            if (this.q0.size() > 0) {
                                visibility = 0;
                            } else {
                                visibility = 8;
                            }
                            x3.setVisibility(visibility);
                            if (intExtra != -1) {
                                this.s0(true, this.e0, intExtra);
                            }
                            if (intExtra2 != -1) {
                                this.s0(false, this.e0, intExtra2);
                            }
                            this.llList.requestLayout();
                        }
                    } else {
                        this.B0 = this.l0.size();
                        if (ImagePicker.shouldHandle(n, n2, intent)) {
                            final Image b2 = ImagePicker.getFirstImageOrNull(intent);
                            if (FrameEditorNewDesign.Q1) {
                                FrameEditorNewDesign.Q1 = false;
                                final ArrayList<String> list = new ArrayList<String>();
                                final Iterator<Image> iterator = ImagePicker.getImages(intent).iterator();
                                while (iterator.hasNext()) {
                                    list.add(iterator.next().getPath());
                                    final ArrayList<ArrayList<com.kotlinz.festivalstorymaker.Models.g>> y = this.Y;
                                    y.add(y.get(0));
                                }
                                this.l0.addAll(list);
                                final LinearLayout llChangeViewType = this.llChangeViewType;
                                int visibility2;
                                if (this.l0.size() == 1) {
                                    visibility2 = 0;
                                } else {
                                    visibility2 = 8;
                                }
                                llChangeViewType.setVisibility(visibility2);
                                if (this.l0.size() > 0) {
                                    new x(true).execute();
                                }
                            } else {
                                FrameEditorNewDesign.F1.setTag((Object) b2.getPath());
                                int n3 = 0;
                                String s = null;
                                Label_1521:
                                {
                                    if (FrameEditorNewDesign.P1) {
                                        this.v0(b2.path, FrameEditorNewDesign.F1.getWidth(), FrameEditorNewDesign.F1.getHeight());
                                        Utils.d();
                                        final String g3 = b2.path;
                                        final int size3 = this.l0.size();
                                        n3 = this.d0;
                                        s = g3;
                                        if (size3 > n3) {
                                            s = g3;
                                            break Label_1521;
                                        }
                                    } else {
                                        FrameEditorNewDesign.F1.setImageBitmap(Utils.A(b2.path));
                                        FrameEditorNewDesign.F1.setBackgroundColor(this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
                                        final int size4 = this.l0.size();
                                        final int d2 = this.d0;
                                        if (size4 > d2) {
                                            this.l0.set(d2, b2.path);
                                        } else {
                                            this.l0.add(b2.path);
                                            final LinearLayout llChangeViewType2 = this.llChangeViewType;
                                            int visibility3;
                                            if (this.l0.size() == 1) {
                                                visibility3 = 0;
                                            } else {
                                                visibility3 = 8;
                                            }
                                            llChangeViewType2.setVisibility(visibility3);
                                            final ArrayList<ArrayList<com.kotlinz.festivalstorymaker.Models.g>> y2 = this.Y;
                                            y2.add(y2.get(0));
                                        }
                                        final String g4 = b2.path;
                                        final int size5 = this.l0.size();
                                        n3 = this.d0;
                                        s = g4;
                                        if (size5 > n3) {
                                            s = g4;
                                            break Label_1521;
                                        }
                                    }
                                    n3 = 0;
                                }
                                this.D0(s, n3, true);
                            }
                        } else {
                            int n4 = 0;
                            String s2 = null;
                            Label_1943:
                            {
                                if (n2 == -1 && n == 69) {
                                    final Uri imageURI = intent.getParcelableExtra("com.yalantis.ucrop.OutputUri");
                                    if (this.J0.length() > 0) {
                                        try {
                                            Utils.O();
                                            final HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(this.J0).openConnection();
                                            httpURLConnection.setDoInput(true);
                                            httpURLConnection.connect();
                                            this.y0(BitmapFactory.decodeStream(httpURLConnection.getInputStream()), MediaStore.Images.Media.getBitmap(this.getContentResolver(), Uri.fromFile(new File(imageURI.getPath()))), FrameEditorNewDesign.F1);
                                            if (this.O0.size() > 0 && this.O0.size() > this.V0) {
                                                this.U0 = true;
                                                FrameEditorNewDesign.F1 = this.P0.get(this.V0);
                                                this.J0 = this.O0.get(this.V0);
                                                this.v0(this.P0.get(this.V0).getTag().toString(), this.Q0.get(this.V0), this.R0.get(this.V0));
                                                ++this.V0;
                                            } else {
                                                this.U0 = false;
                                                this.J0 = "";
                                            }
                                        } catch (Exception ex) {
                                            ex.printStackTrace();
                                        }
                                        break Label_2138;
                                    }
                                    FrameEditorNewDesign.F1.setImageURI(imageURI);
                                    Utils.d();
                                    final String path = imageURI.getPath();
                                    final int size6 = this.l0.size();
                                    n4 = this.d0;
                                    s2 = path;
                                    if (size6 > n4) {
                                        s2 = path;
                                        break Label_1943;
                                    }
                                } else {
                                    final int l = AppConstant.L;
                                    if (n == 6709 && intent != null) {
                                        final Uri parse = Uri.parse(intent.getStringExtra("uri"));
                                        FrameEditorNewDesign.F1.setImageURI(parse);
                                        Utils.d();
                                        final String path2 = parse.getPath();
                                        final int size7 = this.l0.size();
                                        n4 = this.d0;
                                        s2 = path2;
                                        if (size7 > n4) {
                                            s2 = path2;
                                            break Label_1943;
                                        }
                                    } else {
                                        if (n == 1234) {
                                            final byte[] byteArrayExtra = this.getIntent().getByteArrayExtra("image");
                                            Utils.O();
                                            final ImageView f2 = FrameEditorNewDesign.F1;
                                            final Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArrayExtra, 0, byteArrayExtra.length);
                                            final String k2 = FrameEditorNewDesign.K1;
                                            Bitmap imageBitmap = null;
                                            try {
                                                Utils.O();
                                                final Bitmap decodeStream = BitmapFactory.decodeStream(((URLConnection) (new URL(k2).openConnection())).getInputStream());
                                                final Bitmap bitmap = Bitmap.createBitmap(decodeByteArray.getWidth(), decodeByteArray.getHeight(), Bitmap.Config.ARGB_8888);
                                                final Canvas canvas = new Canvas(bitmap);
                                                final Paint paint = new Paint(1);
                                                paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                                                canvas.drawBitmap(decodeByteArray, 0.0f, 0.0f, null);
                                                canvas.drawBitmap(decodeStream, 0.0f, 0.0f, paint);
                                                paint.setXfermode(null);
                                                imageBitmap = bitmap;
                                            } catch (IOException ex2) {
                                                System.out.println(ex2);
                                            }
                                            f2.setImageBitmap(imageBitmap);
                                        }
                                        break Label_2138;
                                    }
                                }
                                n4 = 0;
                            }
                            this.D0(s2, n4, true);
                        }
                    }
                }
            }
        }
        super.onActivityResult(n, n2, intent);
    }


    @Override
    public void onBackPressed() {
        if (IsFromModule.equals(Constant.IsFromPoster)) {
            startActivity(new Intent(activity, PosterMakerActivity.class).putExtra("moduleid", ModuleId));
        } else {
            startActivity(new Intent(activity, StoryMakerActivity.class).putExtra("IsFrom", IsFrom).putExtra("IsFromModule", IsFromModule).putExtra("moduleid", ModuleId));
        }
        finish();
        this.u0();
    }

    @OnClick
    public void onClick(final View view) {
        ImageView imageView = null;
        switch (view.getId()) {
            default: {
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgSpace: {
                imageView = this.imgSpace;
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgSmall: {
                this.n0(0);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgLine: {
                imageView = this.imgLine;
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgFont: {
                imageView = this.imgFont;
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgFirstCap: {
                this.n0(1);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgColor: {
                imageView = this.imgColor;
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgCaps: {
                imageView = this.imgCaps;
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgAllCap: {
                this.n0(2);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgAlignRight: {
                this.m0(1);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgAlignLeft: {
                this.m0(-1);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgAlignCenter: {
                this.m0(0);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgAlign: {
                imageView = this.imgAlign;
                break;
            }
        }
        this.p0(imageView);
    }

    @Override
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(com.kotlinz.festivalstorymaker.R.layout.activity_new_design_edit_frame);
        ButterKnife.bind(this);
        this.F0 = new Utils(this);
        com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b = getSharedPreferences("MyPREFERENCES", Context.MODE_PRIVATE);
        int visibility = 0;
        this.D0 = -1;
        this.E0 = -1;
        this.y0 = new ArrayList<String>();
        new ArrayList();
        this.w0 = new ArrayList<RelativeLayout>();
        this.Q = new ArrayList<Boolean>();
        this.R = new ArrayList<Boolean>();
        this.v0 = new ArrayList<FrameLayout>();
        this.x0 = new ArrayList<FrameLayout>();
        this.l0 = new ArrayList<String>();
        this.m0 = new ArrayList<ArrayList<Integer>>();
        this.Y = new ArrayList<ArrayList<com.kotlinz.festivalstorymaker.Models.g>>();
        this.q0 = new ArrayList<ImageView>();
        this.t0 = new ArrayList<View>();
        this.u0 = new ArrayList<View>();
        this.r0 = new ArrayList<View>();
        this.s0 = new ArrayList<View>();
        this.n0 = new ArrayList<Float>();
        this.o0 = new ArrayList<Float>();
        this.p0 = new ArrayList<Float>();
        C1 = new ArrayList<com.kotlinz.festivalstorymaker.Models.g>();
        D1 = new ArrayList<com.kotlinz.festivalstorymaker.Models.g>();
        E1 = new ArrayList<ImageView>();
        this.V = new ArrayList<ArrayList<View>>();
        this.W = new ArrayList<ArrayList<View>>();
        this.T = new ArrayList<ArrayList<View>>();
        this.U = new ArrayList<ArrayList<View>>();
        this.S = new ArrayList<ArrayList<ImageView>>();
        this.k1 = this;
        this.z0 = (ArrayList<com.kotlinz.festivalstorymaker.Models.o>) this.getIntent().getSerializableExtra("tutorialList");

        imgSquareSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_square_press);
        IsFrom = getIntent().getStringExtra("IsFrom");
        IsFromModule = getIntent().getStringExtra("IsFromModule");
        ModuleId = getIntent().getIntExtra("moduleid", 0);
        this.l0 = (List<String>) this.getIntent().getSerializableExtra("images");
        FilePath = getIntent().getStringExtra("FilePath");

        u1 = this.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView);
        this.K0 = new AppConstant();
        this.N = this;
        W1 = this;
        this.rlFull.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                FrameEditorNewDesign.this.u0();
            }
        });
        final LinearLayout llChangeViewType = this.llChangeViewType;
        if (this.l0.size() != 1) {
            visibility = 8;
        }
        llChangeViewType.setVisibility(visibility);
        this.w0("");
        this.imgFont.setColorFilter(-16777216);
        this.llFonts.bringToFront();
        final FontListAdapter fontListAdapter = new FontListAdapter(this, super.fontList, (FontListAdapter.a) new com.kotlinz.festivalstorymaker.Listener.SetListener.l(), this.q1);
        this.n1 = fontListAdapter;
        this.listFont.setAdapter(fontListAdapter);
        final com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter colorListAdapter = new com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter(this, super.colorList, new com.kotlinz.festivalstorymaker.Listener.SetListener.u(), this.q1);
        this.o1 = colorListAdapter;
        this.listColor.setAdapter(colorListAdapter);
        this.seekBarFontSpacing.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.t5(this));
        this.seekBarFontHeight.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.u5(this));

    }

    private void DownloadComplete() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        View customLayout = getLayoutInflater().inflate(com.kotlinz.festivalstorymaker.R.layout.layout_download_complete, null);
        builder.setView(customLayout);
        AlertDialog dialog = builder.create();
        ImageView ivOk = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.iv_ok);
        ivOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override
    public void onDestroy() {
        final LinearLayout llList = this.llList;
        if (llList != null) {
            llList.removeAllViews();
            this.llList.requestLayout();
        }
        super.onDestroy();
    }


    @OnClick({com.kotlinz.festivalstorymaker.R.id.cardCancelImage, com.kotlinz.festivalstorymaker.R.id.cardDeleteImage})
    public void onViewClick(View e1) {
        final int id = e1.getId();
        if (id != com.kotlinz.festivalstorymaker.R.id.cardCancelImage) {
            if (id != com.kotlinz.festivalstorymaker.R.id.cardDeleteImage) {
                return;
            }
            e1 = this.e1;
            if (e1 != null) {
                this.a0.removeView(e1);
                this.a0.requestLayout();
                this.e1 = null;
            } else {
                this.u0.remove(FrameEditorNewDesign.F1);
                this.t0.remove(FrameEditorNewDesign.F1);
                FrameEditorNewDesign.E1.remove(FrameEditorNewDesign.F1);
                this.a0.removeView(FrameEditorNewDesign.F1);
                this.a0.requestLayout();
            }
        }
        this.z0(false);
    }

    @OnClick({com.kotlinz.festivalstorymaker.R.id.iv_my_creation, com.kotlinz.festivalstorymaker.R.id.llVerticalSize, com.kotlinz.festivalstorymaker.R.id.llStorySize, com.kotlinz.festivalstorymaker.R.id.llSquareSize, com.kotlinz.festivalstorymaker.R.id.llScroll, com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog, com.kotlinz.festivalstorymaker.R.id.rlTop, com.kotlinz.festivalstorymaker.R.id.llGallery, com.kotlinz.festivalstorymaker.R.id.llCamera, com.kotlinz.festivalstorymaker.R.id.iv_back})
    public void onViewClicked(final View view) {
        final int id = view.getId();
        final int n = 1;
        switch (id) {
            default: {
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.iv_my_creation: {
                this.L0 = true;
                stickerView.setLocked(true);
                this.u0();
                new w().execute(new String[0]);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.llVerticalSize: {
                this.r0(2);
                imgSquareSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_square_unpress);
                imgVerticalSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_vertical_press);
                imgStorySize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_story_unpress);
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.llStorySize: {
                this.r0(3);
                imgSquareSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_square_unpress);
                imgVerticalSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_vertical_unpress);
                imgStorySize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_story_press);
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.llSquareSize: {
                this.r0(1);
                imgSquareSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_square_press);
                imgVerticalSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_vertical_unpress);
                imgStorySize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_story_unpress);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.llScroll:
            case com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog:
            case com.kotlinz.festivalstorymaker.R.id.rlTop: {
                this.u0();
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.llGallery: {
                final List<String> l0 = this.l0;
                if (l0 != null) {
                    this.B0 = l0.size();
                }
                FrameEditorNewDesign.Q1 = true;
                boolean b = false;
                Label_0231:
                {
                    if (this.Z != null) {
                        for (int i = 0; i < this.Z.size(); ++i) {
                            if (this.Z.get(i).q.equals("1")) {
                                b = true;
                                break Label_0231;
                            }
                        }
                    }
                    b = false;
                }
                final ImagePicker.ImagePickerWithActivity a = new ImagePicker.ImagePickerWithActivity(this);
                a.config.folderMode = true;
                int n3;
                if (b) {
                    n3 = n;
                } else {
                    n3 = 20;
                }
                final ImagePickerConfig a2 = a.config;
                a2.limit = n3;
                a2.showCamera = false;
                a.start();
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.llCamera: {
                final List<String> l2 = this.l0;
                if (l2 != null) {
                    this.B0 = l2.size();
                }
                FrameEditorNewDesign.Q1 = true;
                final CameraOnlyConfig cameraOnlyConfig = new CameraOnlyConfig();
                cameraOnlyConfig.savePath = ImagePickerSavePath.DEFAULT;
                cameraOnlyConfig.returnMode = ReturnMode.ALL;
                final Intent intent = new Intent(this, ImagePickerActivity.class);
                intent.putExtra(CameraOnlyConfig.class.getSimpleName(), cameraOnlyConfig);
                this.startActivityForResult(intent, 553);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.iv_back: {
                this.finish();
                return;
            }
        }
    }

    public final void p0(final ImageView imageView) {
        final ImageView imgFont = this.imgFont;
        final int n = -16777216;
        int color;
        if (imageView == imgFont) {
            color = -16777216;
        } else {
            color = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgFont.setColorFilter(color);
        final ImageView imgColor = this.imgColor;
        int color2;
        if (imageView == imgColor) {
            color2 = -16777216;
        } else {
            color2 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgColor.setColorFilter(color2);
        final ImageView imgAlign = this.imgAlign;
        int color3;
        if (imageView == imgAlign) {
            color3 = -16777216;
        } else {
            color3 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgAlign.setColorFilter(color3);
        final ImageView imgSpace = this.imgSpace;
        int color4;
        if (imageView == imgSpace) {
            color4 = -16777216;
        } else {
            color4 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgSpace.setColorFilter(color4);
        final ImageView imgLine = this.imgLine;
        int color5;
        if (imageView == imgLine) {
            color5 = -16777216;
        } else {
            color5 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgLine.setColorFilter(color5);
        final ImageView imgCaps = this.imgCaps;
        int color6;
        if (imageView == imgCaps) {
            color6 = n;
        } else {
            color6 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgCaps.setColorFilter(color6);
        LinearLayout linearLayout;
        if (imageView == this.imgFont) {
            linearLayout = this.llFonts;
        } else if (imageView == this.imgColor) {
            linearLayout = this.llColors;
        } else if (imageView == this.imgAlign) {
            linearLayout = this.llAlign;
        } else if (imageView == this.imgSpace) {
            linearLayout = this.llSpacing;
        } else if (imageView == this.imgLine) {
            linearLayout = this.llLine;
        } else {
            if (imageView != this.imgCaps) {
                return;
            }
            linearLayout = this.llCaps;
        }
        linearLayout.bringToFront();
    }


    public final void r0(int i) {
        this.b1 = true;
        this.t0();
        /*this.q0(i);*/
        final ArrayList<com.kotlinz.festivalstorymaker.Models.g> a = this.N0.get(i - 1).a;
        this.Z = a;
        if (a.size() > 0) {
            this.scroll.setVisibility(View.VISIBLE);
            for (i = 0; i < this.l0.size(); ++i) {
                this.Y.add(this.Z);
            }
            new x(false).execute();
            return;
        }
        this.scroll.setVisibility(View.GONE);
    }


    public final void s0(boolean z, int i, int i2) {
        if (z) {
            this.D0 = i2;
        } else {
            this.E0 = i2;
        }
        int i3 = 0;
        if (z && this.U.size() > i) {
            while (i3 < ((ArrayList) this.U.get(i)).size()) {
                if (((ArrayList) this.U.get(i)).get(i3) instanceof ImageView) {
                    ((ImageView) ((ArrayList) this.U.get(i)).get(i3)).setColorFilter(i2);
                } else if (((ArrayList) this.U.get(i)).get(i3) instanceof BorderedTextView) {
                    ((BorderedTextView) ((ArrayList) this.U.get(i)).get(i3)).setBorderedColor(i2);
                } else {
                    ((TextView) ((ArrayList) this.U.get(i)).get(i3)).setTextColor(i2);
                }
                i3++;
            }
        } else if (this.T.size() > i) {
            while (i3 < ((ArrayList) this.T.get(i)).size()) {
                if (((ArrayList) this.T.get(i)).get(i3) instanceof ImageView) {
                    ((ImageView) ((ArrayList) this.T.get(i)).get(i3)).setColorFilter(i2);
                } else if (((ArrayList) this.T.get(i)).get(i3) instanceof BorderedTextView) {
                    ((BorderedTextView) ((ArrayList) this.T.get(i)).get(i3)).setBorderedColor(i2);
                } else {
                    ((TextView) ((ArrayList) this.T.get(i)).get(i3)).setTextColor(i2);
                }
                i3++;
            }
        }
    }


    @Override
    public void t(final float n, final float n2, final Bitmap bitmap, final String s) {
        this.l1 = true;
        if (this.x0.size() > 1) {
            final float n3 = (bitmap.getWidth() - this.h1.getWidths()) / 2.0f;
            final float n4 = (bitmap.getHeight() - this.h1.getHeights()) / 2.0f;
            (this.m1 = new Dialog(this)).setContentView(com.kotlinz.festivalstorymaker.R.layout.dialog_apply_logo_conformation);
            this.m1.findViewById(com.kotlinz.festivalstorymaker.R.id.txtOnlythis).setOnClickListener((View.OnClickListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.r5(this));
            this.m1.findViewById(com.kotlinz.festivalstorymaker.R.id.txtAll).setOnClickListener((View.OnClickListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.s5(this, n - n3, n2 - n4));
            this.m1.show();
        }
    }

    public final void t0() {
        FrameEditorNewDesign.x1 = 0;
        this.w0.clear();
        this.Q.clear();
        this.R.clear();
        this.v0.clear();
        this.x0.clear();
        this.Y.clear();
        this.q0.clear();
        this.t0.clear();
        this.u0.clear();
        this.r0.clear();
        this.s0.clear();
        this.n0.clear();
        this.o0.clear();
        this.p0.clear();
        FrameEditorNewDesign.C1.clear();
        FrameEditorNewDesign.D1.clear();
        FrameEditorNewDesign.E1.clear();
        this.V.clear();
        this.W.clear();
        this.T.clear();
        this.U.clear();
        this.S.clear();
        this.llList.removeAllViews();
        this.llList.requestLayout();
        this.Y.clear();
        this.B0 = 0;
    }

    public void u0() {
        if (this.findViewById(com.kotlinz.festivalstorymaker.R.id.llDeleteImage).isShown()) {
            this.z0(false);
        }
        if (this.rlBottomMoveDeleteDialog.isShown()) {
            this.H0(false);
        }
        final TextStickerViewNew1 s1 = this.s1;
        if (s1 != null) {
            s1.setInEdit(false);
        }
        final ImageStickerViewNew h1 = this.h1;
        if (h1 != null) {
            h1.setInEdit(false);
        }
        final ImageStickerViewNew j1 = this.j1;
        if (j1 != null) {
            j1.setInEdit(false);
        }
        final TextView w1 = FrameEditorNewDesign.w1;
        if (w1 != null) {
            w1.setBackground(null);
        }
        if (this.findViewById(com.kotlinz.festivalstorymaker.R.id.llTextEditor).isShown()) {
            this.B0(false);
        }
    }

    public final void v0(final String s, final int n, final int n2) {
        Utils.d();
        final Bundle bundle = new Bundle();
        bundle.putString("com.yalantis.ucrop.CompressionFormatName", Bitmap.CompressFormat.JPEG.name());
        bundle.putInt("com.yalantis.ucrop.CompressionQuality", 100);
        bundle.putString("com.yalantis.ucrop.UcropToolbarTitleText", "Crop");
        bundle.putBoolean("com.yalantis.ucrop.HideBottomControls", true);
        bundle.putBoolean("com.yalantis.ucrop.FreeStyleCrop", false);
        final Uri fromFile = Uri.fromFile(new File(s));
        final File cacheDir = this.getCacheDir();
        final StringBuilder sb = new StringBuilder();
        sb.append(System.currentTimeMillis());
        sb.append(".png");
        final Uri fromFile2 = Uri.fromFile(new File(cacheDir, sb.toString()));
        final Intent intent = new Intent();
        final Bundle bundle2 = new Bundle();
        bundle2.putParcelable("com.yalantis.ucrop.InputUri", fromFile);
        bundle2.putParcelable("com.yalantis.ucrop.OutputUri", fromFile2);
        final float n3 = (float) n;
        final float n4 = (float) n2;
        bundle2.putFloat("com.yalantis.ucrop.AspectRatioX", n3);
        bundle2.putFloat("com.yalantis.ucrop.AspectRatioY", n4);
        bundle2.putInt("com.yalantis.ucrop.MaxSizeX", 2200);
        bundle2.putInt("com.yalantis.ucrop.MaxSizeY", 2200);
        bundle2.putAll(bundle);
        intent.setClass((Context) this, (Class) UCropActivity.class);
        intent.putExtras(bundle2);
        this.startActivityForResult(intent, 69);
    }

    public final void w0(String s) {
        this.O = new com.kotlinz.festivalstorymaker.Other.g.a(this, this);
        GetEditData();
    }


    private void GetEditData() {
        File fileEvents = new File(FilePath);
        StringBuilder text = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileEvents));
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
            String Response = text.toString();
            O.a.z(0, Response);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public File x0() {
        final String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "My Post" + File.separator + IsFrom;
        final String s = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.s(new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US));
        final File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(file);
        sb.append(File.separator);
        sb.append(s);
        sb.append(".jpg");
        final String string = sb.toString();
        if (TextUtils.isEmpty(string)) {
            return null;
        }
        return new File(string);
    }

    public void y0(final Bitmap bitmap, Bitmap scaledBitmap, final ImageView imageView) {
        scaledBitmap = Bitmap.createScaledBitmap(scaledBitmap, bitmap.getWidth(), bitmap.getHeight(), true);
        final Bitmap bitmap2 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        final Canvas canvas = new Canvas(bitmap2);
        final Paint paint = new Paint(1);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(scaledBitmap, 0.0f, 0.0f, paint);
        paint.setXfermode(null);
        imageView.setImageBitmap(bitmap2);
        imageView.requestLayout();
        imageView.invalidate();
    }

    @Override
    public void z(int i, final String p2) {
        final int c0 = this.C0;
        final int n = 0;
        if (i == c0) {
            this.z0.clear();
            try {
                final JSONObject jsonObject = new JSONObject(p2);
                if (jsonObject.getString(AppConstant.T0).equalsIgnoreCase("1")) {
                    JSONArray jsonArray;
                    JSONObject jsonObject2;
                    com.kotlinz.festivalstorymaker.Models.o o;
                    for (jsonArray = jsonObject.getJSONArray("response"), i = n; i < jsonArray.length(); ++i) {
                        jsonObject2 = jsonArray.getJSONObject(i);
                        o = new com.kotlinz.festivalstorymaker.Models.o();
                        o.e = jsonObject2.getString("category_id");
                        o.g = jsonObject2.getString("name");
                        o.i = jsonObject2.getString("video");
                        o.f = jsonObject2.getString("image");
                        jsonObject2.getString("youtube_url");
                        this.z0.add(o);
                    }
                    /* this.C0();*/
                }
                return;
            } catch (JSONException ex) {
                ex.printStackTrace();
                return;
            }
        }
        this.P = p2;
        FrameEditorNewDesign.C1.clear();
        FrameEditorNewDesign.D1.clear();
        FrameEditorNewDesign.E1.clear();
        this.llList.removeAllViews();
        this.llList.requestLayout();
        this.N0 = this.K0.getEditThemeFileData(this, this.P);
        Label_0518:
        {
            com.kotlinz.festivalstorymaker.Models.a a = null;
            Label_0507:
            {
                ArrayList<com.kotlinz.festivalstorymaker.Models.a> list;
                if (this.c1 && this.T0.length() > 0) {
                    list = this.N0;
                    i = Integer.parseInt(this.T0) - 1;
                } else {
                    final boolean equalsIgnoreCase = com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.Z1);
                    i = 2;
                    if (!equalsIgnoreCase && !com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.K1) && !com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.Y1) && !com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.R1) && !com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.X1) && !com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.Q1)) {
                        if (com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.H1)) {
                            if (this.N0.size() < 3) {
                                break Label_0518;
                            }
                            list = this.N0;
                        } else {
                            if (this.N0.size() >= 1) {
                                a = this.N0.get(0);
                                break Label_0507;
                            }
                            break Label_0518;
                        }
                    } else {
                        if (this.N0.size() >= 2) {
                            a = this.N0.get(1);
                            break Label_0507;
                        }
                        break Label_0518;
                    }
                }
                a = list.get(i);
            }
            this.Z = a.a;
        }
        final ArrayList<com.kotlinz.festivalstorymaker.Models.g> z = this.Z;
        if (z != null && z.size() > 0) {
            this.scroll.setVisibility(View.VISIBLE);
            for (i = 0; i < this.l0.size(); ++i) {
                this.Y.add(this.Z);
            }
            new x(false).execute();
            return;
        }
        this.scroll.setVisibility(View.GONE);
    }

    public final void z0(final boolean b) {
        final RelativeLayout rlFull = this.rlFull;
        final int n = 0;
        int visibility;
        if (b) {
            visibility = 0;
        } else {
            visibility = 8;
        }
        rlFull.setVisibility(visibility);
        final View viewById = this.findViewById(com.kotlinz.festivalstorymaker.R.id.llDeleteImage);
        com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.B(80, 500L, 2131296827, this.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView));
        int visibility2;
        if (b) {
            visibility2 = n;
        } else {
            visibility2 = 8;
        }
        viewById.setVisibility(visibility2);
    }

    public class ColorListAdapter extends RecyclerView.Adapter<ColorListAdapter.ViewHolder> {
        public Activity g;
        public String[] h;

        public ColorListAdapter(final Activity g, final String[] h) {
            this.g = g;
            this.h = h;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(com.kotlinz.festivalstorymaker.R.layout.adapter_color_list_item, viewGroup, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            final ViewHolder viewHolder = holder;
            viewHolder.card.setCardBackgroundColor(Color.parseColor(this.h[position]));
            LinearLayout linearLayout;
            Drawable drawable;
            if (this.h[position].contains("FFFFFF")) {
                linearLayout = viewHolder.llbg;
                drawable = this.g.getResources().getDrawable(com.kotlinz.festivalstorymaker.R.drawable.rounded_corner_black_border);
            } else {
                linearLayout = viewHolder.llbg;
                drawable = null;
            }
            linearLayout.setBackground(drawable);
            viewHolder.card.setOnClickListener((View.OnClickListener) new com.kotlinz.festivalstorymaker.Listener.SetListener.x5(FrameEditorNewDesign.this, this, position));
        }

        @Override
        public int getItemCount() {
            return this.h.length;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            @BindView(com.kotlinz.festivalstorymaker.R.id.card)
            public CardView card;
            @BindView(com.kotlinz.festivalstorymaker.R.id.llbg)
            public LinearLayout llbg;

            public ViewHolder(final View view) {
                super(view);
                ButterKnife.bind(this, view);
            }
        }
    }

    public static class v extends BottomSheetDialogFragment {
        public CoordinatorLayout.Behavior k0;

        @SuppressLint("RestrictedApi")
        @Override
        public void setupDialog(@NonNull Dialog dialog, int style) {
            super.setupDialog(dialog, style);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setDimAmount(0.0f);
            final View inflate = View.inflate(dialog.getOwnerActivity(), com.kotlinz.festivalstorymaker.R.layout.dialog_select_image, (ViewGroup) null);
            dialog.setContentView(inflate);
            final CoordinatorLayout.Behavior a = ((CoordinatorLayout.LayoutParams) ((View) inflate.getParent()).getLayoutParams()).getBehavior();
            this.k0 = a;
            if (a != null && a instanceof BottomSheetBehavior) {
                ((BottomSheetBehavior) a).setPeekHeight(3);
            }
            dialog.findViewById(com.kotlinz.festivalstorymaker.R.id.llCamera).setOnClickListener(new View.OnClickListener() {
                public void onClick(final View view) {
                    final CoordinatorLayout.Behavior k0 = v.this.k0;
                    if (k0 != null && k0 instanceof BottomSheetBehavior) {
                        ((BottomSheetBehavior) k0).setPeekHeight(5);
                    }
                    FrameEditorNewDesign.L1 = false;
                    final CameraOnlyConfig cameraOnlyConfig = new CameraOnlyConfig();
                    cameraOnlyConfig.savePath = ImagePickerSavePath.DEFAULT;
                    cameraOnlyConfig.returnMode = ReturnMode.CAMERA_ONLY;
                    final Intent intent = new Intent(getActivity(), ImagePickerActivity.class);
                    intent.putExtra(CameraOnlyConfig.class.getSimpleName(), cameraOnlyConfig);
                    getActivity().startActivityForResult(intent, 553);
                }
            });
            dialog.findViewById(com.kotlinz.festivalstorymaker.R.id.llGallery).setOnClickListener(new View.OnClickListener() {
                public void onClick(final View view) {
                    final CoordinatorLayout.Behavior k0 = v.this.k0;
                    if (k0 != null && k0 instanceof BottomSheetBehavior) {
                        ((BottomSheetBehavior) k0).setPeekHeight(5);
                    }
                    FrameEditorNewDesign.L1 = false;
                    final ImagePicker.ImagePickerWithActivity a = new ImagePicker.ImagePickerWithActivity(getActivity());
                    final ImagePickerConfig a2 = a.config;
                    a2.folderMode = true;
                    a2.returnMode = ReturnMode.GALLERY_ONLY;
                    /* a.f();*/
                    a.config.showCamera = false;
                    a.start();
                }
            });
        }

    }

    public class w extends AsyncTask<String, Boolean, File> {
        public final void a(int n) {
            try {
                final Bitmap e0 = FrameEditorNewDesign.this.e0(FrameEditorNewDesign.this.w0.get(n));
                final File x0 = x0();
                if (x0 != null) {
                    final FileOutputStream fileOutputStream = new FileOutputStream(x0.getAbsolutePath());
                    e0.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.close();
                    ++n;
                    Utils.K((Context) FrameEditorNewDesign.this, x0);
                    if (FrameEditorNewDesign.this.w0.size() > n) {
                        this.a(n);
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        public void onPostExecute(final File o) {
            final File file = o;
            L0 = false;
            F0.u();
            DownloadComplete();
        }

        @Override
        protected File doInBackground(String... strings) {
            final String[] array2 = strings;
            for (int i = 0; i < FrameEditorNewDesign.this.y0.size(); ++i) {
                Utils.J(com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, ""), FrameEditorNewDesign.this.y0.get(i));
            }
            this.a(0);
            return new File("");
        }

        public void onPreExecute() {
            super.onPreExecute();
            FrameEditorNewDesign.this.F0 = new Utils(FrameEditorNewDesign.this);
            final FrameEditorNewDesign a = FrameEditorNewDesign.this;
            a.F0.c(a.getResources().getString(com.kotlinz.festivalstorymaker.R.string.downloading));
            FrameEditorNewDesign.this.F0.m();
        }
    }

    public class x extends AsyncTask<URL, Integer, Bitmap> {
        public boolean a;

        public x(final boolean a) {
            this.a = a;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            final FrameEditorNewDesign b = FrameEditorNewDesign.this;
            b.E0(b.B0, this.a);
        }

        @Override
        protected Bitmap doInBackground(URL... urls) {
            final URL[] array2 = urls;
            final List<String> l0 = FrameEditorNewDesign.this.l0;
            if (l0 != null && l0.size() > FrameEditorNewDesign.this.B0) {
                Utils.d();
                final FrameEditorNewDesign b = FrameEditorNewDesign.this;
                b.D0(b.l0.get(b.B0), FrameEditorNewDesign.this.B0, false);
            }
            return null;
        }
    }

    public class y extends AsyncTask<Void, Void, Void> {
        public String a;
        public Bitmap b;

        public y(final String a, final int n) {
            this.a = a;
        }


        public void onPostExecute(Void unused) {
            super.onPostExecute((Void) unused);
            int n = 0;
            while (true) {
                final FrameEditorNewDesign c = FrameEditorNewDesign.this;
                if (n >= c.v0.get(c.d0).getChildCount()) {
                    break;
                }
                final FrameEditorNewDesign c2 = FrameEditorNewDesign.this;
                if (c2.v0.get(c2.d0).getChildAt(n) instanceof ImageStickerViewNew) {
                    final FrameEditorNewDesign c3 = FrameEditorNewDesign.this;
                    if (c3.v0.get(c3.d0).getChildAt(n).getTag() != null) {
                        final FrameEditorNewDesign c4 = FrameEditorNewDesign.this;
                        if (c4.v0.get(c4.d0).getChildAt(n).getTag().equals(FrameEditorNewDesign.this.b0)) {
                            final FrameEditorNewDesign c5 = FrameEditorNewDesign.this;
                            c5.v0.get(c5.d0).removeViewAt(n);
                            final FrameEditorNewDesign c6 = FrameEditorNewDesign.this;
                            c6.v0.get(c6.d0).requestLayout();
                        }
                    }
                }
                ++n;
            }
            ImageStickerViewNew o = new ImageStickerViewNew(FrameEditorNewDesign.this, this.a, FrameEditorNewDesign.A1 / 2.0f, (float) (this.b.getHeight() + 50), 1.0f, 0.0f, 2, true);
            ((ImageStickerViewNew) o).setGif(false);
            ((ImageView) o).setTag(FrameEditorNewDesign.this.b0);
            ((ImageStickerViewNew) o).setBitmap(this.b, Boolean.TRUE);
            ((ImageStickerViewNew) o).setSize(250.0f);
            ((ImageStickerViewNew) o).setOperationListener((ImageStickerViewNew.c) new com.kotlinz.festivalstorymaker.Listener.SetListener.y5(this));
            final FrameEditorNewDesign c7 = FrameEditorNewDesign.this;
            c7.v0.get(c7.d0).addView((View) o);
            final FrameEditorNewDesign c8 = FrameEditorNewDesign.this;
            c8.v0.get(c8.d0).requestLayout();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            final Void[] array2 = (Void[]) voids;
            Utils.O();
            try {
                this.b = BitmapFactory.decodeStream(((URLConnection) (new URL(this.a).openConnection())).getInputStream());
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            return null;
        }

        public void onPreExecute() {
            super.onPreExecute();
            FrameEditorNewDesign.this.F0 = new Utils(FrameEditorNewDesign.this);
            final FrameEditorNewDesign c = FrameEditorNewDesign.this;
            c.F0.c(c.getResources().getString(com.kotlinz.festivalstorymaker.R.string.loading));
            if (!FrameEditorNewDesign.this.isFinishing()) {
                FrameEditorNewDesign.this.F0.m();
            }
        }
    }

    public class z implements View.OnTouchListener {
        public GestureDetector e;
        public int f;
        public ImageView g;
        public RecyclerView h;
        public RecyclerView i;


        public z(final Activity activity, final ImageView g, final int f, final com.kotlinz.festivalstorymaker.Models.g g2, final RecyclerView h, final RecyclerView i) {
            this.h = h;
            this.i = i;
            this.g = g;
            this.f = f;
            this.e = new GestureDetector(activity, new a(g2));
        }

        public boolean onTouch(final View view, final MotionEvent motionEvent) {
            this.e.onTouchEvent(motionEvent);
            return true;
        }

        public class a extends GestureDetector.SimpleOnGestureListener {
            public com.kotlinz.festivalstorymaker.Models.g e;

            public a(final com.kotlinz.festivalstorymaker.Models.g e) {
                this.e = e;
            }

            public boolean onDoubleTap(final MotionEvent motionEvent) {
                final FrameEditorNewDesign j = FrameEditorNewDesign.this;
                if (j.t1) {
                    return j.t1 = false;
                }
                j.u0();
                final com.kotlinz.festivalstorymaker.Models.g e = this.e;
                FrameEditorNewDesign.K1 = e.f;
                final z f = z.this;
                FrameEditorNewDesign.F1 = f.g;
                FrameEditorNewDesign.G1 = f.h;
                FrameEditorNewDesign.I1 = f.i;
                d0 = f.f;
                String f2;
                if (e.q.equalsIgnoreCase("1")) {
                    f2 = this.e.f;
                } else {
                    f2 = "";
                }
                J0 = f2;
                if (FrameEditorNewDesign.F1.getTag() != null) {
                    FrameEditorNewDesign.this.v0(FrameEditorNewDesign.F1.getTag().toString(), FrameEditorNewDesign.F1.getWidth(), FrameEditorNewDesign.F1.getHeight());
                }
                return false;
            }

            public boolean onDoubleTapEvent(final MotionEvent motionEvent) {
                return false;
            }

            public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
                final FrameEditorNewDesign j = FrameEditorNewDesign.this;
                if (j.t1) {
                    return j.t1 = false;
                }
                j.u0();
                final z f = z.this;
                if (!l1) {
                    final com.kotlinz.festivalstorymaker.Models.g e = this.e;
                    FrameEditorNewDesign.K1 = e.f;
                    FrameEditorNewDesign.F1 = f.g;
                    FrameEditorNewDesign.G1 = f.h;
                    FrameEditorNewDesign.I1 = f.i;
                    d0 = f.f;
                    if (e.q.equalsIgnoreCase("1")) {
                        FrameEditorNewDesign.P1 = true;
                        FrameEditorNewDesign.this.J0 = this.e.f;
                        FrameEditorNewDesign.N1 = false;
                    } else {
                        FrameEditorNewDesign.P1 = false;
                        FrameEditorNewDesign.N1 = false;
                    }
                    /*   p0(FrameEditorNewDesign.this.ge, v.B);*/
                    return false;
                }
                return l1 = false;
            }
        }
    }
}