package api.natsuite.natcorder.utility;

import api.natsuite.natcorder.*;
import api.natsuite.natcorder.MediaRecorder;

import java.util.concurrent.*;
import android.os.*;
import java.io.*;
import java.nio.*;
import android.media.*;
import android.util.*;

public final class MediaWriter
{
    private final String recordingPath;
    private final MediaMuxer muxer;
    private final MediaRecorder.Callback completionHandler;
    private final Handler delegateHandler;
    private final Semaphore startToken;
    private final Semaphore appendToken;
    private int videoTrack;
    private int audioTrack;
    private int pendingTracks;
    
    public MediaWriter(final String recordingPath, final int tracks, final MediaRecorder.Callback completionHandler) throws IOException {
        this.videoTrack = -1;
        this.audioTrack = -1;
        this.recordingPath = recordingPath;
        this.muxer = new MediaMuxer(recordingPath, 0);
        this.completionHandler = completionHandler;
        this.delegateHandler = new Handler(Looper.myLooper());
        this.startToken = new Semaphore((tracks == 1) ? 1 : 0);
        this.appendToken = new Semaphore(0);
        this.pendingTracks = tracks;
    }
    
    public void appendVideoFrame(final MediaFormat format, final ByteBuffer buffer, final MediaCodec.BufferInfo bufferInfo) {
        if (bufferInfo.size == 0) {
            return;
        }
        this.videoTrack = ((this.videoTrack == -1) ? this.muxer.addTrack(format) : this.videoTrack);
        try {
            this.startToken.acquire();
        }
        catch (InterruptedException ex) {}
        try {
            this.muxer.start();
        }
        catch (IllegalStateException ex2) {}
        this.muxer.writeSampleData(this.videoTrack, buffer, bufferInfo);
        this.appendToken.release();
        this.startToken.release();
    }
    
    public void appendAudioFrame(final MediaFormat format, final ByteBuffer buffer, final MediaCodec.BufferInfo bufferInfo) {
        if (bufferInfo.size == 0) {
            return;
        }
        this.audioTrack = ((this.audioTrack == -1) ? this.muxer.addTrack(format) : this.audioTrack);
        this.startToken.release();
        try {
            this.appendToken.acquire();
        }
        catch (InterruptedException ex) {}
        this.muxer.writeSampleData(this.audioTrack, buffer, bufferInfo);
        this.appendToken.release();
    }
    
    public void finishWriting() {
        final int pendingTracks = this.pendingTracks - 1;
        this.pendingTracks = pendingTracks;
        if (pendingTracks > 0) {
            return;
        }
        try {
            this.muxer.stop();
            this.muxer.release();
            this.delegateHandler.post((Runnable)new Runnable() {
                @Override
                public void run() {
                    MediaWriter.this.completionHandler.onRecording(MediaWriter.this.recordingPath);
                }
            });
        }
        catch (IllegalStateException ex) {
            Log.e("Unity", "NatCorder Error: Failed to finish writing media", (Throwable)ex);
        }
    }
}
