package com.esc.socialmediacleaner.util;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.os.Build.VERSION;
import android.provider.MediaStore.Audio;
import android.provider.MediaStore.Files;
import android.provider.MediaStore.Images.Media;
import android.provider.MediaStore.Images.Thumbnails;
import android.util.Log;

import java.io.File;

public class MediaUtil {
    public static final int MINI_THUMB_SIZE = 512;

    private static final class ImageNotFoundException extends Exception {
        private static final long serialVersionUID = 1;

        private ImageNotFoundException() {
        }

        private ImageNotFoundException(Throwable th) {
            super(th);
        }
    }

    private MediaUtil() {
        throw new UnsupportedOperationException();
    }

    public static String getRealPathFromUri(Context context, Uri uri) {
        Cursor cursor;
        String str = "_data";

        cursor = context.getContentResolver().query(uri, new String[]{str}, null, null, null);
        if (cursor == null) {
            if (cursor != null) {
                cursor.close();
            }
            return null;
        }
        int columnIndexOrThrow = cursor.getColumnIndexOrThrow(str);
        cursor.moveToFirst();
        String string = cursor.getString(columnIndexOrThrow);
        if (cursor != null) {
            cursor.close();
        }
        return string;
    }

    private static int getImageId(Context context, String str) throws ImageNotFoundException {
        String str2 = "_id";
        try {
            Cursor query = context.getContentResolver().query(Media.EXTERNAL_CONTENT_URI, new String[]{str2}, "_data = ?", new String[]{str}, "date_added desc");
            if (query != null) {
                query.moveToFirst();
                if (query.isAfterLast()) {
                    query.close();
                    throw new ImageNotFoundException();
                }
                int i = query.getInt(query.getColumnIndex(str2));
                query.close();
                return i;
            }
            throw new ImageNotFoundException();
        } catch (Exception e) {
            throw new ImageNotFoundException(e);
        }
    }

    public static Uri getUriFromFile(Context context, String str) {
        ContentResolver contentResolver = context.getContentResolver();
        String str2 = "external";
        String str3 = "_id";
        ContentResolver contentResolver2 = contentResolver;
        Cursor query = contentResolver2.query(Files.getContentUri(str2), new String[]{str3}, "_data = ?", new String[]{str}, "date_added desc");
        if (query == null) {
            return null;
        }
        query.moveToFirst();
        if (query.isAfterLast()) {
            query.close();
            ContentValues contentValues = new ContentValues();
            contentValues.put("_data", str);
            return contentResolver.insert(Files.getContentUri(str2), contentValues);
        }
        Uri build = Files.getContentUri(str2).buildUpon().appendPath(Integer.toString(query.getInt(query.getColumnIndex(str3)))).build();
        query.close();
        return build;
    }

    public static int getAlbumIdFromAudioFile(Context context, File file) {
        ContentResolver contentResolver = context.getContentResolver();
        String str = "album_id";
        ContentResolver contentResolver2 = contentResolver;
        Cursor query = contentResolver2.query(Audio.Media.EXTERNAL_CONTENT_URI, new String[]{str}, "_data=?", new String[]{file.getAbsolutePath()}, null);
        if (query == null || !query.moveToFirst()) {
            if (query != null) {
                query.close();
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put("_data", file.getAbsolutePath());
            contentValues.put("title", "{MediaWrite Workaround}");
            contentValues.put("_size", Long.valueOf(file.length()));
            contentValues.put("mime_type", "audio/mpeg");
            contentValues.put("is_music", Boolean.valueOf(true));
            contentResolver.insert(Audio.Media.EXTERNAL_CONTENT_URI, contentValues);
        }
        contentResolver2 = contentResolver;
        Cursor query2 = contentResolver2.query(Audio.Media.EXTERNAL_CONTENT_URI, new String[]{str}, "_data=?", new String[]{file.getAbsolutePath()}, null);
        if (query2 == null) {
            return 0;
        }
        if (query2.moveToFirst()) {
            int i = query2.getInt(0);
            query2.close();
            return i;
        }
        query2.close();
        return 0;
    }

    public static void addFileToMediaStore(Context context, String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        context.sendBroadcast(intent);
    }

    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    public static android.graphics.Bitmap getThumbnailFromPath(Context r4, String r5, int r6) {
        /*
        r0 = r4.getContentResolver();
        r1 = 0;
        r4 = getImageId(r4, r5);	 Catch:{  }
        r5 = new android.graphics.BitmapFactory$Options;	 Catch:{  }
        r5.<init>();	 Catch:{  }
        r2 = 512; // 0x200 float:7.175E-43 double:2.53E-321;
        r2 = r2 / r6;
        r5.inSampleSize = r2;	 Catch:{  }
        setDither(r5);	 Catch:{  }
        r2 = (long) r4;
        r4 = 1;
        r4 = android.provider.MediaStore.Images.Thumbnails.getThumbnail(r0, r2, r4, r5);	 Catch:{ ImageNotFoundException -> 0x001d }
        return r4;
    L_0x001d:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.esc.socialmediacleaner.util.MediaUtil.getThumbnailFromPath(android.content.Context, java.lang.String, int):android.graphics.Bitmap");
    }

    private static void setDither(Options options) {
        if (VERSION.SDK_INT <= 23) {
            options.inDither = true;
        }
    }

    public static void addPictureToMediaStore(Context context, String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        context.sendBroadcast(intent);
    }

    public static void deleteThumbnail(Context context, String str) {
        ContentResolver contentResolver = context.getContentResolver();
        try {
            int imageId = getImageId(context, str);
            String[] strArr = new String[1];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(imageId);
            strArr[0] = stringBuilder.toString();
            contentResolver.delete(Thumbnails.EXTERNAL_CONTENT_URI, "image_id = ?", strArr);
        } catch (ImageNotFoundException unused) {
        }
    }
}
