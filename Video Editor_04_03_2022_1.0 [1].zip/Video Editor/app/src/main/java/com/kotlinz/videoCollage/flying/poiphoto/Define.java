package com.kotlinz.videoCollage.flying.poiphoto;

public interface Define {
    public static final String CONFIGURE = "configure";
    public static final String DEFAULT_ALBUM_TITLE = "Select Album";
    public static final String DEFAULT_MAX_NOTICE = "Only one selection allowed";
    public static final String DEFAULT_PHOTO_TITLE = "Select Photo";
    public static final String DEFAULT_VIDEO_TITLE = "Select Video";
    public static final String PATHS = "paths";
    public static final String PHOTOS = "photos";
}
