package com.claptoflashlightonoff.util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout.LayoutParams;
import com.example.speaktourchtight.R;

public class DragSwitch implements OnTouchListener {
    public ViewGroup backgroundImage;
    private int delY = 0;
    private int disableMargin;
    private boolean isEnable = false;
    private onDragSwitchChangeListener listener;
    LayoutParams params;
    View slider;
    private int sliderHeight;
    private int viewheight;

    public DragSwitch(Activity activity) {
        ViewGroup viewGroup = (ViewGroup) activity.findViewById(R.id.layoutSlider);
        this.backgroundImage = viewGroup;
        viewGroup.setOnTouchListener(this);
        View findViewById = activity.findViewById(R.id.slider);
        this.slider = findViewById;
        findViewById.setOnTouchListener(this);
        this.params = (LayoutParams) this.slider.getLayoutParams();
        this.disableMargin = this.params.topMargin;
        this.sliderHeight = 0;
        this.viewheight = 0;
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouch(View view, MotionEvent motionEvent) {
        int n = motionEvent.getAction() & 255;
        int startTouchY = (int) motionEvent.getRawY();
        if (this.sliderHeight == 0) {
            this.sliderHeight = this.slider.getHeight();
            this.viewheight = this.backgroundImage.getHeight();
        }
        switch (n) {
            case 0:
                if (view != this.slider) {
                    if (view == this.backgroundImage) {
                        this.params = (LayoutParams) this.slider.getLayoutParams();
                        break;
                    }
                }
                this.params = (LayoutParams) this.slider.getLayoutParams();
                this.delY = startTouchY - this.params.topMargin;
                break;
            case 1:
                if (view != this.slider) {
                    int n4 = (int) motionEvent.getY();
                    if (n4 <= 0 || n4 <= this.params.topMargin + this.sliderHeight) {
                        this.params.topMargin = 0;
                    } else {
                        this.params.topMargin = this.disableMargin;
                    }
                    this.slider.setLayoutParams(this.params);
                } else if (((float) startTouchY) != motionEvent.getY()) {
                    int n2 = this.params.topMargin + (this.sliderHeight / 2);
                    int n3 = this.viewheight / 2;
                    if (n2 < n3) {
                        this.params.topMargin = 0;
                    } else {
                        this.params.topMargin = this.disableMargin;
                    }
                    this.slider.setLayoutParams(this.params);
                }
                boolean isEnable = this.isEnable;
                if (this.params.topMargin < 10) {
                    this.isEnable = true;
                } else {
                    this.isEnable = false;
                }
                if (!(this.listener == null || isEnable == this.isEnable)) {
                    this.listener.switchChangeState(this.isEnable);
                    break;
                }
                break;
            case 2:
                if (view == this.slider) {
                    if (this.params.topMargin + this.sliderHeight <= this.viewheight && this.params.topMargin >= 0) {
                        this.params.topMargin = startTouchY - this.delY;
                    }
                    if (this.params.topMargin + this.sliderHeight > this.viewheight) {
                        this.params.topMargin = this.disableMargin;
                    }
                    if (this.params.topMargin < 0) {
                        this.params.topMargin = 0;
                    }
                    this.slider.setLayoutParams(this.params);
                    break;
                }
                break;
        }
        return true;
    }

    public void setEnable(boolean isEnable) {
        if (this.params == null) {
            this.params = (LayoutParams) this.slider.getLayoutParams();
            this.viewheight = this.backgroundImage.getHeight();
            this.sliderHeight = this.slider.getHeight();
        }
        if (isEnable) {
            this.params.topMargin = 0;
        } else {
            this.params.topMargin = this.disableMargin;
            this.slider.setLayoutParams(this.params);
        }
        this.isEnable = isEnable;
    }

    public void setHide(Boolean b) {
        if (b.booleanValue()) {
            this.backgroundImage.setVisibility(View.GONE);
            this.slider.setVisibility(View.GONE);
            return;
        }
        this.backgroundImage.setVisibility(View.VISIBLE);
        this.slider.setVisibility(View.VISIBLE);
    }

    public void setOnStateChangeListener(onDragSwitchChangeListener listener) {
        this.listener = listener;
    }
}
