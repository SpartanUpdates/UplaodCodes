package com.Pulse.VideoStatus.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.Pulse.VideoStatus.Activity.ImageSelectActivity;
import com.Pulse.VideoStatus.Interface.OnItemClickListner;
import com.Pulse.VideoStatus.Model.ImageInfo;
import com.Pulse.VideoStatus.R;
import com.Pulse.VideoStatus.application.MyApplication;
import com.bumptech.glide.Glide;
import com.github.siyamed.shapeimageview.RoundedImageView;

import java.util.ArrayList;

public class SelectedImageAdapter extends RecyclerView.Adapter<SelectedImageAdapter.MyViewHolder> {
    public MyApplication application;
    public LayoutInflater layoutInflater;
    public ImageSelectActivity activity;
    public Context context;
    //    public boolean e = false;
    int e = 0;
    private OnItemClickListner<Object> itemClickListner;

    public SelectedImageAdapter(Context context) {
        this.context = context;
        this.application = MyApplication.getInstance();
        this.activity = (ImageSelectActivity) context;
        this.application = MyApplication.e();
        this.layoutInflater = LayoutInflater.from(context);
    }

    public void setOnItemClickListner(final OnItemClickListner<Object> clickListner) {
        this.itemClickListner = clickListner;
    }


    @NonNull
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new MyViewHolder(this, this.layoutInflater.inflate(R.layout.recycler_selected_item_view, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final SelectedImageAdapter.MyViewHolder viewHolder, @SuppressLint("RecyclerView") final int pos) {
        viewHolder.view.setVisibility(View.VISIBLE);
        final ImageInfo imageInfo = getItem(pos);
        Glide.with(activity).load(imageInfo.getThumbbailImage()).placeholder(R.drawable.photo_mask).into(viewHolder.ivThumb);
        if (e == pos) {
            viewHolder.ivSelected.setSelected(true);
            viewHolder.ivRemove.setVisibility(View.VISIBLE);
        } else {
            viewHolder.ivSelected.setSelected(false);
            viewHolder.ivRemove.setVisibility(View.GONE);
        }
        if (pos == 0) {
            viewHolder.tvOptional.setVisibility(View.GONE);
        }
        viewHolder.ivThumb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e = pos;
                notifyDataSetChanged();
            }
        });
        viewHolder.ivRemove.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (activity.isFromPreview) {
                    application.MinimumPosition = Math.min(application.MinimumPosition, Math.max(0, pos - 1));
                }
                if (ImageSelectActivity.isFirstImage && pos <= ImageSelectActivity.tempImage.size() && application.getSelectedImageslist().contains(ImageSelectActivity.tempImage.get(pos).ImagePath)) {
                    ImageSelectActivity.tempImage.remove(pos);
                }
                if (application.getSelectedImageslist().size() > pos) {
                    application.removeSelectedImage(pos);
                }
                else {
                    Toast.makeText(application, "Please Select Image First", Toast.LENGTH_SHORT).show();
                }

                if (itemClickListner != null) {
                    itemClickListner.onItemClick(v, pos);
                }
                notifyDataSetChanged();
            }
        });
    }

    public int getItemCount() {
//        final ArrayList<ImageInfo> list = this.application.getSelectedImageslist();
//        return list.size();
        return 6;
    }


    public ImageInfo getItem(final int pos) {
        final ArrayList<ImageInfo> list = this.application.getSelectedImageslist();
        if (list.size() <= pos) {
            return new ImageInfo();
        }
        return list.get(pos);
    }


    public final boolean IsHideRemove() {
        return this.application.getSelectedImageslist().size() <= 3 && this.activity.v;
    }


    public int getItemViewType(int i) {
        super.getItemViewType(i);
        return i;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public View view;
        public ImageView ivRemove;
        public RoundedImageView ivThumb, ivSelected;
        public TextView tvOptional;

        public MyViewHolder(SelectedImageAdapter mVar, View view) {
            super(view);
            this.view = view;
            ivThumb = view.findViewById(R.id.ivThumb);
            ivSelected = view.findViewById(R.id.imageView);
            ivRemove = view.findViewById(R.id.ivRemove);
            ivRemove.setVisibility(View.GONE);
            tvOptional = itemView.findViewById(R.id.tvOptional);

        }

        public void onItemClick(final View view, final Object item) {
            if (SelectedImageAdapter.this.itemClickListner != null) {
                SelectedImageAdapter.this.itemClickListner.onItemClick(view, item);
            }
        }
    }
}
