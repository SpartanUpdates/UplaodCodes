package com.vidsoft.collagemaker.Utils;


import com.vidsoft.collagemaker.pipphotoeffect.R;

public class Const {
    public static String FAILURE = null;
    public static String INT_IMAGEPATH = null;
    public static String INT_STOREPATH = null;
    public static String PRFS_ADS1 = null;
    public static String PRFS_NAME = null;
    public static String SUCEESS;
    public static String currentGrid;
    public static String editedImagePath;
    public static String editedImg;
    public static int goneLayout;
    public static String imgId;
    public static String imgList;
    public static String imgSharePath;
    public static String imgSource;
    public static int normalColor;
    public static int selectedColor;
    public static int visibleLayout;

    static {
        INT_IMAGEPATH = "imagePath";
        INT_STOREPATH = "storePath";
        imgId = "imgId";
        imgSource = "imgSource";
        imgList = "imgList";
        currentGrid = "currentGrid";
        editedImg = "editedImg";
        imgSharePath = "imgSharePath";
        editedImagePath = "editedImagePath";
        normalColor = R.color.white;
        selectedColor = R.color.Button_Selected_Color;
        visibleLayout = 0;
        goneLayout = 8;
        SUCEESS = "1";
        FAILURE = "0";
        PRFS_NAME = "MyAppPrfs";
    }
}