package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.View;
import android.widget.FrameLayout;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;

public class a5 implements ImageStickerViewNew.c {
    public final FrameLayout a;
    public final FestivalDetailActivity_New b;

    public a5(final FestivalDetailActivity_New b, final FrameLayout a) {
        this.b = b;
        this.a = a;
    }

    @Override
    public void a(final ImageStickerViewNew imageStickerViewNew) {
        imageStickerViewNew.setInEdit(true);
    }

    @Override
    public void b(final ImageStickerViewNew imageStickerViewNew) {
        this.a.removeView((View) imageStickerViewNew);
    }

    @Override
    public void c(final Boolean b) {
        this.b.scroll.requestDisallowInterceptTouchEvent((boolean) b);
    }

    @Override
    public void d(final ImageStickerViewNew imageStickerViewNew) {
    }
}
