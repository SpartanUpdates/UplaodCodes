package com.claptoflashlightonoff.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager.LayoutParams;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.claptoflashlightonoff.kprogresshud.KProgressHUD;
import com.claptoflashlightonoff.util.SoundLevelView;
import com.claptoflashlightonoff.model.SoundMeter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.nineoldandroids.animation.ValueAnimator;
import com.nineoldandroids.animation.ValueAnimator.AnimatorUpdateListener;
import com.example.speaktourchtight.R;

public class ColorActivity extends Activity implements OnClickListener {
    private ValueAnimator anim;
    private int color;
    private Intent f4i;
    private boolean isBlinkOn = false;
    private LinearLayout llColour;
    private LinearLayout llGuide;
    private LinearLayout llHeader;
    private SoundLevelView mDisplay;
    private Handler mHandler = new Handler();
    private Runnable mPollTask = new Runnable() {
        @Override
        public void run() {
            double amplitude = ColorActivity.this.mSensor.getAmplitude();
            ColorActivity.this.updateDisplay("Monitoring Voice...", amplitude);
            if (amplitude > ((double) ColorActivity.this.mThreshold)) {
                ColorActivity.this.callForHelp();
                ColorActivity.this.llGuide.setVisibility(View.GONE);
            }
            ColorActivity.this.mHandler.postDelayed(ColorActivity.this.mPollTask, 300);
        }
    };
    private boolean mRunning = false;
    private SoundMeter mSensor;
    private Runnable mSleepTask = new Runnable() {
        @Override
        public void run() {
            ColorActivity.this.start();
        }
    };
    private TextView mStatusView;
    private int mThreshold;
    private WakeLock mWakeLock;
    private RelativeLayout rlMainLayout;
    private TextView tvGuide;
    private TextView tvHeader;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitialAd;
    private int Adid;
    private KProgressHUD hud;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color);
        this.f4i = getIntent();
        bindView();
        init();
        addListner();
        maxBrightness();
        loadAd();
        BannerAds();
    }

    private void bindView() {
        this.tvHeader = (TextView) findViewById(R.id.tvHeaderTitle);
        this.tvGuide = (TextView) findViewById(R.id.tvGuide);
        this.llGuide = (LinearLayout) findViewById(R.id.llGuide);
        this.llColour = (LinearLayout) findViewById(R.id.llColorIndicator);
        this.llHeader = (LinearLayout) findViewById(R.id.llHeader);
        this.rlMainLayout = (RelativeLayout) findViewById(R.id.rlMainLayout);
        this.mStatusView = (TextView) findViewById(R.id.status);
        this.mDisplay = (SoundLevelView) findViewById(R.id.volume);
    }

    private void init() {
        Typeface face = Typeface.createFromAsset(getAssets(), "majalla.ttf");
        this.tvGuide.setTypeface(face);
        this.tvHeader.setTypeface(face);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        if (prefs.getBoolean(getString(R.string.col), false)) {
            this.llGuide.setVisibility(View.GONE);
        } else {
            Editor edit = prefs.edit();
            edit.putBoolean(getString(R.string.col), Boolean.TRUE.booleanValue());
            edit.commit();
        }
        this.mSensor = new SoundMeter();
        this.mWakeLock = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(6, "NoiseAlert");
        start();
        initializeApplicationConstants();
        this.mDisplay.setLevel(0, this.mThreshold);
        if (!this.mRunning) {
            this.mRunning = true;
            start();
        }
    }

    private void addListner() {
        findViewById(R.id.rlwhite).setOnClickListener(this);
        findViewById(R.id.rlGreen).setOnClickListener(this);
        findViewById(R.id.rlSky).setOnClickListener(this);
        findViewById(R.id.rlYellow).setOnClickListener(this);
        findViewById(R.id.rlPink).setOnClickListener(this);
        findViewById(R.id.rlRed).setOnClickListener(this);
        this.llGuide.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rlwhite:

                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(ColorActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 100;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadWhite();
                }
                break;

            case R.id.rlGreen:

                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(ColorActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 101;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadGreen();
                }
                break;

            case R.id.rlSky:

                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(ColorActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 102;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadSky();
                }
                break;

            case R.id.rlYellow:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(ColorActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 103;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadYellow();
                }
                break;

            case R.id.rlPink:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(ColorActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 104;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadPink();
                }
                break;
            case R.id.rlRed:

                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(ColorActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 105;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadRed();
                }
                break;
            case R.id.llGuide:
                this.llGuide.setVisibility(View.GONE);
                break;
            default:
                return;
        }
    }

    private void loadAd() {
        //interstitial FullScreenAd
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        ColorActivity.this.loadWhite();
                        break;
                    case 101:
                        ColorActivity.this.loadGreen();
                        break;
                    case 102:
                        ColorActivity.this.loadSky();
                        break;
                    case 103:
                        ColorActivity.this.loadYellow();
                        break;
                    case 104:
                        ColorActivity.this.loadPink();
                        break;
                    case 105:
                        ColorActivity.this.loadRed();
                        break;
                    case 106:
                        if (f4i.getStringExtra("Act").equalsIgnoreCase("Tourch")) {
                            stop();
                            startActivity(new Intent(ColorActivity.this, TourchActivity.class));
                            finish();
                        } else {
                            stop();
                            startActivity(new Intent(ColorActivity.this, MainActivity.class));
                            finish();
                        }
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitialAd = new InterstitialAd(ColorActivity.this);
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(ColorActivity.this);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    protected void onDestroy() {
        super.onDestroy();
    }

    public void onStop() {
        super.onStop();
        stop();
    }

    private void callForHelp() {
        if (this.isBlinkOn) {
            this.anim.cancel();
            this.isBlinkOn = false;
            this.rlMainLayout.setBackgroundColor(this.color);
            this.llHeader.setVisibility(View.VISIBLE);
            this.llColour.setVisibility(View.VISIBLE);
            return;
        }
        this.llHeader.setVisibility(View.GONE);
        this.llColour.setVisibility(View.GONE);
        blink();
        this.isBlinkOn = true;
    }

    private void initializeApplicationConstants() {
        this.mThreshold = 8;
    }

    private void start() {
        this.mSensor.start();
        if (!this.mWakeLock.isHeld()) {
            this.mWakeLock.acquire();
        }
        this.mHandler.postDelayed(this.mPollTask, 300);
    }

    private void stop() {
        if (this.mWakeLock.isHeld()) {
            this.mWakeLock.release();
        }
        this.mHandler.removeCallbacks(this.mSleepTask);
        this.mHandler.removeCallbacks(this.mPollTask);
        this.mSensor.stop();
        this.mDisplay.setLevel(0, 0);
        updateDisplay("stopped...", 0.0d);
        this.mRunning = false;
    }

    private void updateDisplay(String text, double n) {
        this.mStatusView.setText(text);
        this.mDisplay.setLevel((int) n, this.mThreshold);
    }

    private void maxBrightness() {
        LayoutParams layoutParams = getWindow().getAttributes();
        layoutParams.screenBrightness = 1.0f;
        getWindow().setAttributes(layoutParams);
        getWindow().addFlags(128);
    }

    protected void onPause() {
        super.onPause();
    }

    public void onBackPressed() {

        if (interstitialAd !=null && interstitialAd.isLoaded()){
            try {
                hud = KProgressHUD.create(ColorActivity.this)
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Showing Ads")
                        .setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (interstitialAd != null && interstitialAd.isLoaded()) {
                        Adid = 106;
                        interstitialAd.show();
                    }
                }
            }, 2000);
        }else {
            if (this.f4i.getStringExtra("Act").equalsIgnoreCase("Tourch")) {
                stop();
                startActivity(new Intent(this, TourchActivity.class));
                finish();
            } else {
                stop();
                startActivity(new Intent(this, MainActivity.class));
                finish();
            }
        }

    }

    public void blink() {
        this.anim = ValueAnimator.ofInt(1, 0, 1, 0, 1, 0, 0, 0);
        this.anim.setDuration(1000);
        this.anim.setInterpolator(new LinearInterpolator());
        this.anim.setRepeatCount(-1);
        this.anim.setRepeatMode(2);
        this.anim.addUpdateListener(new AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator va) {
                if (((Integer) va.getAnimatedValue()).intValue() == 1) {
                    new Handler().post(new Runnable() {
                        @Override
                        public void run() {
                            ColorActivity.this.rlMainLayout.setBackgroundColor(ColorActivity.this.color);
                        }
                    });
                } else {
                    new Handler().post(new Runnable() {
                        @Override

                        public void run() {
                            ColorActivity.this.rlMainLayout.setBackgroundColor(ColorActivity.this.getResources().getColor(R.color.black));
                        }
                    });
                }
            }
        });
        this.anim.start();
    }

    private void loadRed() {
        this.rlMainLayout.setBackgroundResource(R.color.red_round);
        this.color = getResources().getColor(R.color.red_round);
    }

    private void loadPink() {
        this.rlMainLayout.setBackgroundResource(R.color.pink_round);
        this.color = getResources().getColor(R.color.pink_round);
    }

    private void loadYellow() {
        this.rlMainLayout.setBackgroundResource(R.color.yellow_round);
        this.color = getResources().getColor(R.color.yellow_round);
    }

    private void loadSky() {
        this.rlMainLayout.setBackgroundResource(R.color.sky_round);
        this.color = getResources().getColor(R.color.sky_round);
    }

    private void loadGreen() {
        this.rlMainLayout.setBackgroundResource(R.color.green_round);
        this.color = getResources().getColor(R.color.green_round);
    }

    private void loadWhite() {
        this.rlMainLayout.setBackgroundResource(R.color.white);
        this.color = getResources().getColor(R.color.white);
    }
}
