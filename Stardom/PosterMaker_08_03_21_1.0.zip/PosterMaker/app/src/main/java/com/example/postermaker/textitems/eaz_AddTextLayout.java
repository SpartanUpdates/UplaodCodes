package com.example.postermaker.textitems;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;
import com.example.postermaker.eaz_EditActivity;
import com.example.postermaker.myApp.MyApplication;


import static android.content.Context.INPUT_METHOD_SERVICE;

public class eaz_AddTextLayout implements OnClickListener
{
    Context context= MyApplication.getContext();

    public void showTextLayout()
    {
        eaz_EditActivity.addTextlayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.oktext.setOnClickListener(this);
        eaz_EditActivity.canceltext.setOnClickListener(this);
        eaz_EditActivity.logoText.setText("");
    }

    public void onClick(View view) {
        String str = "";
        if (view.equals(eaz_EditActivity.oktext)) {
            if (eaz_EditActivity.inputText.getText().toString().length() > 0)
            {
                eaz_EditActivity.logoText.setText(eaz_EditActivity.inputText.getText().toString());
                eaz_EditActivity.logoText.setTextColor(-16777216);
                eaz_EditActivity.addTextlayout.setVisibility(View.GONE);
                eaz_EditActivity.inputText.setText(str);

                InputMethodManager manager = (InputMethodManager)context.getSystemService(INPUT_METHOD_SERVICE);
                manager.hideSoftInputFromWindow(view.getWindowToken(), 0);

                return;
            }
            Toast.makeText(view.getContext(), "Sorry! No input", Toast.LENGTH_SHORT).show();
        } else if (view.equals(eaz_EditActivity.canceltext))
        {
            eaz_EditActivity.inputText.setText(str);
            eaz_EditActivity.addTextlayout.setVisibility(View.GONE);

            InputMethodManager manager = (InputMethodManager)context.getSystemService(INPUT_METHOD_SERVICE);
            manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
