package com.esc.poems;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy.Builder;
import android.text.Html;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.RelativeLayout;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NavigationDrawerFragment.NavigationDrawerCallbacks {
    Activity activity = MainActivity.this;
    protected static DataBaseHelper DBhelper;
    protected static GridAdapter adapter2;
    protected static ArrayList<String> categoryid;
    protected static String[] catt = new String[]{"Home", "Top 100", "Top Users Poems", "Submit Your Poems", "Missing You", "Friendship", "Love", "Poems", "Good Morning", "Good Night", "Anniversary", "Birthday", "Get Well Soon", "Sympathy", "Sorry", "Baby", "Easter", "Mother's Day", "Father's Day", "Valentine's Day", "Good Luck", "Graduation", "Wedding", "Halloween", "Thanks Giving", "Women's Day", "Christmas", "New Year"};
    private static Editor editor;
    protected static Editor editor1;
    protected static GridView gv;
    private static int[] icon = new int[]{R.drawable.toppoems, R.drawable.missingyou, R.drawable.friendship, R.drawable.love, R.drawable.poems, R.drawable.goodmorning, R.drawable.goodnight, R.drawable.anniversary, R.drawable.birthday, R.drawable.getwellsoon, R.drawable.sympathy, R.drawable.sorry, R.drawable.newbaby, R.drawable.easter, R.drawable.mothersday, R.drawable.fathersday, R.drawable.valentinesday, R.drawable.goodluck, R.drawable.gaduation, R.drawable.wedding, R.drawable.halloween, R.drawable.thanksgiving, R.drawable.women, R.drawable.christmas, R.drawable.newyear};
    public static boolean onback = false;
    protected static SharedPreferences prefs;
    protected static int sh;
    protected static int sw;
    private NavigationDrawerFragment mNavigationDrawerFragment;
    private CharSequence mTitle;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    public void onSectionAttached(int i) {

    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        StrictMode.setThreadPolicy(new Builder().permitAll().build());
        SharedPreferences sharedPreferences = getSharedPreferences("MYPREFERENCE", 0);
        sharedPreferences = sharedPreferences;
        editor = sharedPreferences.edit();
        SharedPreferences sharedPreferences2 = getApplicationContext().getSharedPreferences("bdaymsg", 0);
        prefs = sharedPreferences2;
        editor1 = sharedPreferences2.edit();
        this.mNavigationDrawerFragment = (NavigationDrawerFragment) getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);
        this.mTitle = Html.fromHtml("<font color='#ffffff'>Poems</font>");
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        sw = displayMetrics.widthPixels;
        sh = displayMetrics.heightPixels;
        this.mNavigationDrawerFragment.setUp(R.id.navigation_drawer, (DrawerLayout) findViewById(R.id.drawer_layout));
        DataBaseHelper dataBaseHelper = new DataBaseHelper(this);
        DBhelper = dataBaseHelper;
        try {
            dataBaseHelper.createDataBase();
        } catch (Exception unused) {
            unused.printStackTrace();
        }
        categoryid = DBhelper.getCategoryid(catt);
        adapter2 = new GridAdapter(getApplicationContext(), icon);
        GridView gridView = findViewById(R.id.gridView1);
        gv = gridView;
        gridView.setAdapter(adapter2);
        gv.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                onNavigationDrawerItemSelected(i + 1, "grid");
            }
        });
        BannerAds();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public void onNavigationDrawerItemSelected(int i, String str) {
        getSupportFragmentManager().beginTransaction().replace(R.id.container, PlaceholderFragment.newInstance(i, getApplicationContext(), str)).commitAllowingStateLoss();
    }

    public void restoreActionBar() {
        ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayShowTitleEnabled(true);
        supportActionBar.setTitle(this.mTitle);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        if (this.mNavigationDrawerFragment.isDrawerOpen()) {
            return super.onCreateOptionsMenu(menu);
        }
        getMenuInflater().inflate(R.menu.main, menu);
        restoreActionBar();
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.favmenu) {
            System.gc();
            startActivity(new Intent(this, FavoriteActivity.class));
        }
        return super.onOptionsItemSelected(menuItem);
    }


    public void onResume() {
        super.onResume();
        gv.setAdapter(new GridAdapter(getApplicationContext(), icon));
        mNavigationDrawerFragment.onHiddenChanged(false);
    }

    public void onBackPressed() {
        if (onback) {
            onback = false;
            super.onBackPressed();
            return;
        }
        onNavigationDrawerItemSelected(0, "grid");
        onback = true;
    }
}
