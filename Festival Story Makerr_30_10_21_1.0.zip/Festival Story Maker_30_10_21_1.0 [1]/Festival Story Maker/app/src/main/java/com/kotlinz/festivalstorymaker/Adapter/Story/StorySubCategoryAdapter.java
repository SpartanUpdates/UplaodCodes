package com.kotlinz.festivalstorymaker.Adapter.Story;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.AppUtils.View.AVLoadingView.AVLoadingIndicatorView;
import com.kotlinz.festivalstorymaker.Download.StoryThemeDownload;
import com.kotlinz.festivalstorymaker.Model.StoryMaker.CategoryWiseData.StoryCategoryWiseData;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.activity.StoryMakerActivity;

import java.io.File;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class StorySubCategoryAdapter extends RecyclerView.Adapter<StorySubCategoryAdapter.MyViewHolder> {

    public StoryMakerActivity storyActivity;
    public int position = -1;
    public ArrayList<StoryCategoryWiseData> storysubCategoryList;
    String DataFileName;
    String[] SplitName;

    public StorySubCategoryAdapter(Context context, ArrayList<StoryCategoryWiseData> storysubCategoryList) {
        this.storyActivity = (StoryMakerActivity) context;
        this.storysubCategoryList = storysubCategoryList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_story_subcategory, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        StoryCategoryWiseData storyCategoryWiseData = storysubCategoryList.get(position);
        String FileName = "";
        if (storyCategoryWiseData.getDatafile() != null) {
            FileName = storyCategoryWiseData.getDatafile().substring(storyCategoryWiseData.getDatafile().lastIndexOf('/') + 1);
        }
        if (FileName.indexOf(".") > 0)
            FileName = Utils.INSTANCE.getThemeFolderPath() + File.separator + storyCategoryWiseData.getModuleName() + File.separator + storyCategoryWiseData.getParentCategory() + File.separator + storyCategoryWiseData.getChildCategory() + File.separator + FileName.substring(0, FileName.lastIndexOf(".")).replaceAll("[0-9]+", "");
        if (new File(FileName).exists()) {
            holder.ThemeDownProgress.setVisibility(View.GONE);
            holder.ivDownload.setVisibility(View.GONE);
        } else {
            holder.ThemeDownProgress.setVisibility(View.GONE);
            holder.ivDownload.setVisibility(View.VISIBLE);
        }
        Glide.with(storyActivity).load(storysubCategoryList.get(position).getThemeThumbnail()).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivCategoryThumb);
        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DownloadFile(position, holder.ivDownload, holder.ThemeDownProgress, holder.indicatorThemeProgress, holder.tvThemeDownProgress, storyCategoryWiseData);
            }
        });
    }

    private void DownloadFile(int Position, ImageView ivDownload, LinearLayout themeDownProgress, AVLoadingIndicatorView avLoadingIndicatorView, TextView tvThemeDownprogress, StoryCategoryWiseData categoryWiseData) {
        DataFileName = categoryWiseData.getDatafile().substring(categoryWiseData.getDatafile().lastIndexOf('/') + 1);
        if (DataFileName.indexOf(".") > 0)
            DataFileName = DataFileName.substring(0, DataFileName.lastIndexOf(".")).replaceAll("[0-9]+", "");
        SplitName = DataFileName.split("Theme");
        String SplitFileName = "Theme" + " " + SplitName[1];

        Constant.TextFilePath = Utils.INSTANCE.getThemeFolderPath() + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + SplitFileName + File.separator + SplitFileName + ".txt";
        Constant.FolderPath = Utils.INSTANCE.getThemeFolderPath() + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + SplitFileName;

        if (new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + DataFileName).exists()) {
            if (MyApplication.isShowAd == 1) {
                Constant.NoofImage = Integer.parseInt(storysubCategoryList.get(Position).getIsImageCount());
                Constant.ImageFrame = storysubCategoryList.get(Position).getThemeThumbnail();
                storyActivity.ShowImageDialog("ImageSelect");
                MyApplication.getInstance().CatItemPosition = Position;
                MyApplication.isShowAd = 0;
            } else {
                if (MyApplication.mInterstitialAd != null) {
                    MyApplication.activity = storyActivity;
                    Constant.NoofImage = Integer.parseInt(storysubCategoryList.get(Position).getIsImageCount());
                    Constant.ImageFrame = storysubCategoryList.get(Position).getThemeThumbnail();
                    MyApplication.getInstance().CatItemPosition = Position;
                    MyApplication.AdsId = 27;
                    MyApplication.mInterstitialAd.show(storyActivity);
                    MyApplication.isShowAd = 1;
                } else {
                    Constant.NoofImage = Integer.parseInt(storysubCategoryList.get(Position).getIsImageCount());
                    Constant.ImageFrame = storysubCategoryList.get(Position).getThemeThumbnail();
                    storyActivity.ShowImageDialog("ImageSelect");
                    MyApplication.getInstance().CatItemPosition = Position;
                }
            }
        } else {
            if (Utils.checkConnectivity(storyActivity, false)) {
                ivDownload.setVisibility(View.GONE);
                themeDownProgress.setVisibility(View.VISIBLE);
                avLoadingIndicatorView.smoothToShow();
                new StoryThemeDownload(storyActivity, storysubCategoryList.get(Position).getDatafile(), DataFileName, ivDownload, themeDownProgress, avLoadingIndicatorView, tvThemeDownprogress, categoryWiseData);
            }
        }
    }


    @Override
    public int getItemCount() {
        return storysubCategoryList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.llMain)
        public CardView llMain;

        @BindView(R.id.ivCategoryThumb)
        public ImageView ivCategoryThumb;

        @BindView(R.id.ivThumbDownload)
        ImageView ivDownload;
        @BindView(R.id.indicator)
        AVLoadingIndicatorView indicatorThemeProgress;
        @BindView(R.id.ll_theme_down_progress)
        LinearLayout ThemeDownProgress;
        @BindView(R.id.tvCounter)
        TextView tvThemeDownProgress;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
