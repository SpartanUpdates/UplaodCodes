package com.wavymusic.SongCrop.controler;

import android.content.Context;
import android.content.res.AssetManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import com.wavymusic.Adapter.PhoneSongAdapter;


public class Mediacontroler {
    private AssetManager assetManager;
    private String b = null;
    public MediaPlayer mediaPlayer = new MediaPlayer();

    class musiclistener implements OnPreparedListener {
        final Mediacontroler mediacontroler;

        musiclistener(Mediacontroler mediacontroler) {
            this.mediacontroler = mediacontroler;
        }

        public void onPrepared(MediaPlayer mediaPlayer) {
            if (PhoneSongAdapter.IsSongPlay) {
                mediaPlayer.start();
            } else {
                PhoneSongAdapter.IsSongPlay = true;
            }
        }
    }

    public Mediacontroler(Context context) {
        this.assetManager = context.getAssets();
    }

    public String a() {
        return this.b;
    }

    public void a(long j) {
        this.mediaPlayer.seekTo((int) j);
    }

    public void a(String str) {
        this.b = str;
    }

    public void b() {
        this.mediaPlayer.reset();
        try {
            this.mediaPlayer.setDataSource(this.b);
            this.mediaPlayer.prepare();
            this.mediaPlayer.setOnPreparedListener(new musiclistener(this));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int c() {
        return this.mediaPlayer.getCurrentPosition();
    }

    public void d() {
        if (this.mediaPlayer.isPlaying()) {
            this.mediaPlayer.pause();
        }
    }

    public boolean e() {
        return this.mediaPlayer.isPlaying();
    }

    public void f() {
        if (!this.mediaPlayer.isPlaying()) {
            this.mediaPlayer.start();
        }
    }

    public void g() {
        if (this.mediaPlayer.isPlaying()) {
            this.mediaPlayer.stop();
        }
    }
}
