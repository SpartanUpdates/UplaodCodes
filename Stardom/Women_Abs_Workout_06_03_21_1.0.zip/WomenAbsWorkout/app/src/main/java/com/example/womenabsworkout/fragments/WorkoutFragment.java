package com.example.womenabsworkout.fragments;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

import com.thekhaeng.pushdownanim.PushDownAnim;
import java.util.ArrayList;
import java.util.List;
import com.example.womenabsworkout.R;
import com.example.womenabsworkout.activities.After_Main_Activity;
import com.example.womenabsworkout.activities.MainActivity;
import com.example.womenabsworkout.adapters.AllDayAdapter;
import com.example.womenabsworkout.adapters.WorkoutData;
import com.example.womenabsworkout.database.DatabaseHelper;
import com.example.womenabsworkout.database.DatabaseOperations;
import com.example.womenabsworkout.newscreen.Library;
import com.example.womenabsworkout.utils.AppUtils;
import com.example.womenabsworkout.utils.Constants;

public class WorkoutFragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public AllDayAdapter adapter;

    public ArrayList<String> arr = new ArrayList();
    public ImageView calculate;
    public DatabaseOperations databaseOperations;
    public TextView dayleft;
    public int daysCompletionConter = 0;
    public ImageView dietplan;
    public String exc_type;
    public String excercise_type;
    public TextView free_weight;
    public Library library;

    public SharedPreferences mSharedPreferences;
    After_Main_Activity mainAcdsctivity;
    public LinearLayout nativeAdContainer;
    public ImageView paid_weight;
    public TextView percentScore1;
    public Editor prefsEditor;
    public ProgressBar progressBar;

    WorkoutFragment workoutFragment;


    public BroadcastReceiver progressReceiver = new BroadcastReceiver()
    {
        public void onReceive(Context context, Intent intent)
        {
            double doubleExtra = intent.getDoubleExtra(AppUtils.KEY_PROGRESS, 0.0d);
            try
            {
                ((WorkoutData) WorkoutFragment.this.workoutDataList.get(WorkoutFragment.this.workoutPosition)).setProgress((float) doubleExtra);
                WorkoutFragment.this.total_progress = 0.0d;
                int i = 0;
                WorkoutFragment.this.daysCompletionConter = 0;
                while (true)
                {
                    String str = "dev";

                    if (i < Constants.TOTAL_DAYS)
                    {
                        double d = WorkoutFragment.this.total_progress;
                        double progress = (double) ((WorkoutData) WorkoutFragment.this.workoutDataList.get(i)).getProgress();
                        Double.isNaN(progress);
                        WorkoutFragment.this.total_progress = (double) ((float) (d + ((progress * 4.348d) / 100.0d)));
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("totalprogressreceiver");
                        stringBuilder.append(WorkoutFragment.this.total_progress);
                        Log.i(str, stringBuilder.toString());
                        if (((WorkoutData) WorkoutFragment.this.workoutDataList.get(i)).getProgress() >= 99.0f) {
                            WorkoutFragment.this.daysCompletionConter++;
                        }
                        i++;
                    }

                    else
                   {
                        WorkoutFragment.this.daysCompletionConter += WorkoutFragment.this.daysCompletionConter / 3;
                        WorkoutFragment.this.progressBar.setProgress((int) WorkoutFragment.this.total_progress);
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("totalprogressreceiver1");
                        stringBuilder2.append(WorkoutFragment.this.total_progress);
                        Log.i(str, stringBuilder2.toString());
                        TextView textView = WorkoutFragment.this.percentScore1;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append((int) WorkoutFragment.this.total_progress);
                        stringBuilder2.append("%");
                        textView.setText(stringBuilder2.toString());
                        textView = WorkoutFragment.this.dayleft;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(Constants.TOTAL_DAYS - WorkoutFragment.this.daysCompletionConter);
                        stringBuilder2.append(WorkoutFragment.this.getString(R.string.dayleft));
                        textView.setText(stringBuilder2.toString());
                        WorkoutFragment.this.adapter.notifyDataSetChanged();
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("");
                        stringBuilder3.append(doubleExtra);
                        Log.i("progress broadcast", stringBuilder3.toString());
                        return;
                   }
                }
            }

            catch (Exception e)
            {
                e.printStackTrace();
            }

        }
    };

    public double total_progress = 0.0d;
    public List<WorkoutData> workoutDataList;
    public int workoutPosition = -1;


    public WorkoutFragment(After_Main_Activity after_Main_Activity)
    {
        this.mainAcdsctivity = after_Main_Activity;
    }

    public static WorkoutFragment newInstance(String str, String str2, After_Main_Activity after_Main_Activity) {
        WorkoutFragment workoutFragment = new WorkoutFragment(after_Main_Activity);
        Bundle bundle = new Bundle();
        bundle.putString(ARG_PARAM1, str);
        bundle.putString(ARG_PARAM2, str2);
        workoutFragment.setArguments(bundle);
        return workoutFragment;
    }



    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i;
        View inflate = layoutInflater.inflate(R.layout.fragment_workout, viewGroup, false);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        this.mSharedPreferences = defaultSharedPreferences;
        this.prefsEditor = defaultSharedPreferences.edit();
        this.exc_type = this.mSharedPreferences.getString("yoga_type", "beginner");
        this.progressBar = (ProgressBar) inflate.findViewById(R.id.progress);
        this.percentScore1 = (TextView) inflate.findViewById(R.id.percentScore);
        this.dayleft = (TextView) inflate.findViewById(R.id.daysLeft);
        this.databaseOperations = new DatabaseOperations(getContext());
        String str = "thirtyday";
        boolean z = this.mSharedPreferences.getBoolean(str, false);
        String str2 = "daysInserted";
        if (!this.mSharedPreferences.getBoolean(str2, false) && this.databaseOperations.CheckDBEmpty(DatabaseHelper.EXC_DAY_TABLE) == 0) {
            this.databaseOperations.insertExcALLDayData();
            Editor edit = this.mSharedPreferences.edit();
            edit.putBoolean(str2, true);
            edit.apply();
        }
        List list = this.workoutDataList;
        if (list != null)
        {
            list.clear();
        }

        this.workoutDataList = this.databaseOperations.getAllDaysProgress();
        this.progressBar = (ProgressBar) inflate.findViewById(R.id.progress);
        for (i = 0; i < Constants.TOTAL_DAYS; i++)
        {
            double d = this.total_progress;
            double progress = (double) ((WorkoutData) this.workoutDataList.get(i)).getProgress();
            Double.isNaN(progress);
            this.total_progress = (double) ((float) (d + ((progress * 4.348d) / 100.0d)));
            if (((WorkoutData) this.workoutDataList.get(i)).getProgress() >= 99.0f) {
                this.daysCompletionConter++;
            }
        }
        i = this.daysCompletionConter;
        this.daysCompletionConter = i + (i / 3);
        this.progressBar.setProgress((int) this.total_progress);
        TextView textView = this.percentScore1;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((int) this.total_progress);
        stringBuilder.append("%");
        textView.setText(stringBuilder.toString());
        textView = this.dayleft;
        stringBuilder = new StringBuilder();
        stringBuilder.append(Constants.TOTAL_DAYS - this.daysCompletionConter);
        stringBuilder.append(getString(R.string.dayleft));
        textView.setText(stringBuilder.toString());

        if (z) {
            Editor edit2 = this.mSharedPreferences.edit();
            edit2.putBoolean(str, false);
            edit2.apply();
            this.daysCompletionConter = 0;
        }

        getActivity().registerReceiver(this.progressReceiver, new IntentFilter(AppUtils.WORKOUT_BROADCAST_FILTER));

        inflate.findViewById(R.id.calculate).setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {

                WorkoutFragment.this.mainAcdsctivity.loadFragment_Calculator(new Calculate_Fragment());
            }
        });

        inflate.findViewById(R.id.startdiet).setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {
                WorkoutFragment.this.mainAcdsctivity.loadFragment_Mealplan(new MealPlanFragment());
            }
        });

        this.library = new Library(getActivity());
        this.nativeAdContainer = (LinearLayout) inflate.findViewById(R.id.nativeAdContainer);

        this.free_weight = (TextView) inflate.findViewById(R.id.startexercise);
        this.calculate = (ImageView) inflate.findViewById(R.id.calculate);
        this.dietplan = (ImageView) inflate.findViewById(R.id.startdiet);

        PushDownAnim.setPushDownAnimTo(this.free_weight).setScale(1.0f).setDurationPush(50).setDurationRelease(50).setInterpolatorPush(PushDownAnim.DEFAULT_INTERPOLATOR).setInterpolatorRelease(PushDownAnim.DEFAULT_INTERPOLATOR).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), MainActivity.class));
                getActivity().finish();
            }
        });
        PushDownAnim.setPushDownAnimTo(this.paid_weight).setScale(1.0f).setDurationPush(50).setDurationRelease(50).setInterpolatorPush(PushDownAnim.DEFAULT_INTERPOLATOR).setInterpolatorRelease(PushDownAnim.DEFAULT_INTERPOLATOR).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), MainActivity.class));
                getActivity().finish();
            }
        });

        return inflate;
    }

    public void onResume() {

        PushDownAnim.setPushDownAnimTo(this.free_weight).setScale(1.0f).setDurationPush(50).setDurationRelease(50).setInterpolatorPush(PushDownAnim.DEFAULT_INTERPOLATOR).setInterpolatorRelease(PushDownAnim.DEFAULT_INTERPOLATOR).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), MainActivity.class));
                getActivity().finish();
            }
        });
        PushDownAnim.setPushDownAnimTo(this.paid_weight).setScale(1.0f).setDurationPush(50).setDurationRelease(50).setInterpolatorPush(PushDownAnim.DEFAULT_INTERPOLATOR).setInterpolatorRelease(PushDownAnim.DEFAULT_INTERPOLATOR).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), MainActivity.class));
                getActivity().finish();
            }
        });
        super.onResume();
    }

}
