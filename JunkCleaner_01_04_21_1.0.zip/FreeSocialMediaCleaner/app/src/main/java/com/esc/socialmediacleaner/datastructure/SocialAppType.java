package com.esc.socialmediacleaner.datastructure;

public enum SocialAppType {
    FACEBOOK,
    WHATSAPP,
    TWITTER,
    SKYPE,
    SNAPCHAT,
    INSTAGRAM,
    MESSANGER,
    TELEGRAM,
    HIKE
}
