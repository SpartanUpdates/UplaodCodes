package com.kotlinz.videostatusmaker.Activity;

import static com.kotlinz.videostatusmaker.NativeAds.CustomNativeAd.populateUnifiedNativeAdViewbig;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import java.io.File;
import com.kotlinz.videostatusmaker.Others.gallery.ActivityImageFolder;

public class MainActivity extends AppCompatActivity {
    public static int anInt;
    public static Activity activity;
    ImageView fullscreen;
    ImageView square1;

    private NativeAd nativeAd;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        activity = this;
        getWindow().addFlags(1024);
        square1 = findViewById(R.id.square1);
        fullscreen = findViewById(R.id.fullscreen);
        anInt = 0;
        PutAnalyticsEvent();
        LoadNativeAds();
        btnClick();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MainActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void btnClick() {
        square1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.isShowAd == 1) {
                    Square();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null ) {
                        MyApplication.activity = activity;
                        MainActivity.anInt = 0;
                        MyApplication.Variable_VIDEO_HEIGHT = 720;
                        MyApplication.Variable_VIDEO_WIDTH = 720;
                        MyApplication.AdsId = 25;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        Square();
                    }
                }
            }
        });
        fullscreen.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.isShowAd == 1) {
                    FullScreen();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null ) {
                        MyApplication.activity = activity;
                        MainActivity.anInt = 1;
                        MyApplication.Variable_VIDEO_WIDTH = 1080;
                        MyApplication.Variable_VIDEO_HEIGHT = 1920;
                        MyApplication.AdsId = 26;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        FullScreen();
                    }
                }
            }
        });
    }

    private void Square() {
        MainActivity.anInt = 0;
        MyApplication.Variable_VIDEO_HEIGHT = 720;
        MyApplication.Variable_VIDEO_WIDTH = 720;
        startActivity(new Intent(MainActivity.this.getApplicationContext(), ActivityImageFolder.class));
    }

    private void FullScreen() {
        MainActivity.anInt = 1;
        MyApplication.Variable_VIDEO_WIDTH = 1080;
        MyApplication.Variable_VIDEO_HEIGHT = 1920;
        startActivity(new Intent(MainActivity.this.getApplicationContext(), ActivityImageFolder.class));
    }


    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (MainActivity.this.nativeAd != null) {
                            MainActivity.this.nativeAd.destroy();
                        }
                        MainActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_native, null);
                        populateUnifiedNativeAdViewbig(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    protected void onResume() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
            stringBuilder.append("/");
            stringBuilder.append(getResources().getString(R.string.app_name));
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("/");
            stringBuilder3.append(getString(R.string.temp_folder));
            deleteRecursive(new File(stringBuilder3.toString()));
        }
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(MainActivity.this, FirstActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    public static void deleteRecursive(File file) {
        if (file.isDirectory()) {
            for (File deleteRecursive : file.listFiles()) {
                deleteRecursive(deleteRecursive);
            }
        }
        file.delete();
    }
}


