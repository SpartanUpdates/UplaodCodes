package com.esc.fontappstylish.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.Drawable;
import java.util.Date;

public class SharedPreferenceclass {
    private final SharedPreferences prefs;

    public SharedPreferenceclass(Context context) {
        String str = "com.esc.fontappstylish.PREFERENCE_FILE_KEY";

        getClass();
        SharedPreferences sharedPreferences = context.getSharedPreferences(str, 0);
        if (sharedPreferences != null) {
            this.prefs = sharedPreferences;
            return;
        }
        throw new NullPointerException(sharedPreferences.toString());
    }

    public final int getCurrentFontIndex() {
        SharedPreferences sharedPreferences = this.prefs;
        getClass();
        return sharedPreferences.getInt("current_font", 0);
    }

    public final void setCurrentFontIndex(int i) {
        Editor edit = this.prefs.edit();
        getClass();
        edit.putInt("current_font", i).apply();
    }

    public final void setCurrentEmojiArray(int i) {
        Editor edit = this.prefs.edit();
        getClass();
        edit.putInt("current_enoji", i).apply();
    }

    public final int getCurrentEmojiArray() {
        SharedPreferences sharedPreferences = this.prefs;
        getClass();
        return sharedPreferences.getInt("current_enoji", 0);
    }

    public final int getUsedKeyboardCount() {
        SharedPreferences sharedPreferences = this.prefs;
        getClass();
        return sharedPreferences.getInt("used_keyboard", 0);
    }

    public final void setUsedKeyboardCount(int i) {
        Editor edit = this.prefs.edit();
        getClass();
        edit.putInt("used_keyboard", i).apply();
    }

    public final Date getLastUsedDate() {
        SharedPreferences sharedPreferences = this.prefs;
        getClass();
        return new Date(sharedPreferences.getLong("last_used_date", -1));
    }

    public final void setLastUsedDate(Date date) {
        Editor edit = this.prefs.edit();
        getClass();
        edit.putLong("last_used_date", date.getTime()).apply();
    }

    public final String getLanguage() {
        this.prefs.getInt("pos", 0);
        return this.prefs.getString("lang", "eng");
    }

    public final void setImage(String str, String str2) {
        this.prefs.edit().putString(str, str2).apply();
    }

    public String getImage(String str, Drawable drawable) {
        return this.prefs.getString(str, String.valueOf(drawable));
    }

    public final Integer getLanguagepos() {
        return Integer.valueOf(this.prefs.getInt("pos", 0));
    }

    public final void isKeyboardChanged(boolean z) {
        this.prefs.edit().putBoolean("isKeyboardChanged", z).apply();
    }

    public final boolean getisKeyboardChanged() {
        return this.prefs.getBoolean("isKeyboardChanged", false);
    }

    public final void isKeyboardunlocked(boolean z) {
        this.prefs.edit().putBoolean("isKeyboardunlocked", z).apply();
    }
}
