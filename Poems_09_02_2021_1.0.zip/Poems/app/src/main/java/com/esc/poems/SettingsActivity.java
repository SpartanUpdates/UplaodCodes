package com.esc.poems;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy.Builder;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SettingsActivity extends AppCompatActivity {
    private String TAG = "SettingsActivity";
    private Activity activity;
    private ConsentInformation consentInformation;
    private Editor editor;
    private String[] publisherIds;
    private SharedPreferences sharedPreferences;
    private int sw;
    private Typeface typeface;

    public class RecyclerViewAdapter extends Adapter<RecyclerViewAdapter.MyViewHolder> {
        private ArrayList<String> arrlist;

        class MyViewHolder extends ViewHolder {
            TextView list;

            MyViewHolder(View view) {
                super(view);
                this.list = (TextView) view.findViewById(R.id.textsettings);
            }
        }

        RecyclerViewAdapter(ArrayList<String> arrayList) {
            this.arrlist = arrayList;
        }

        public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.settings_items, viewGroup, false));
        }

        public void onBindViewHolder(MyViewHolder myViewHolder, final int i) {
            myViewHolder.list.setText((CharSequence) this.arrlist.get(i));
            if ((SettingsActivity.this.getResources().getConfiguration().screenLayout & 15) == 4) {
                myViewHolder.list.setTypeface(SettingsActivity.this.typeface);
                myViewHolder.list.setTextSize(34.0f);
            } else if ((SettingsActivity.this.getResources().getConfiguration().screenLayout & 15) == 3) {
                myViewHolder.list.setTypeface(SettingsActivity.this.typeface);
                myViewHolder.list.setTextSize(26.0f);
            } else {
                myViewHolder.list.setTypeface(SettingsActivity.this.typeface);
                myViewHolder.list.setTextSize(18.0f);
            }
            myViewHolder.list.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (i == 0) {
                        try {
                            SettingsActivity.this.activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(MyApplication.privacyPolicy)));
                        } catch (ActivityNotFoundException e) {
                            e.printStackTrace();
                        }
                    } else if (i == 1) {
                        view = View.inflate(SettingsActivity.this.activity, R.layout.consent_dialog, null);
                        final Dialog dialog = new Dialog(SettingsActivity.this.activity);
                        dialog.getWindow();
                        dialog.requestWindowFeature(1);
                        dialog.setContentView(view);
                        dialog.setCancelable(true);
                        TextView textView = (TextView) dialog.findViewById(R.id.displayads_text);
                        textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                        textView.setVisibility(View.GONE);
                        Button button = (Button) dialog.findViewById(R.id.btn_lmore);
                        button.setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                SettingsActivity.this.activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(MyApplication.privacyPolicy)));
                            }
                        });
                        button.setVisibility(View.GONE);
                        button = (Button) dialog.findViewById(R.id.btn_p);
                        final Button button2 = (Button) dialog.findViewById(R.id.btn_np);
                        final Button finalButton = button;
                        button2.setOnClickListener(new OnClickListener() {
                            public void onClick(final View view) {
                                SettingsActivity.this.consentInformation.setConsentStatus(ConsentStatus.NON_PERSONALIZED);
                                String access$300 = SettingsActivity.this.TAG;
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("");
                                stringBuilder.append(SettingsActivity.this.consentInformation.getConsentStatus());
                                Log.e(access$300, stringBuilder.toString());
                                SettingsActivity.this.consentInformation.requestConsentInfoUpdate(SettingsActivity.this.publisherIds, new ConsentInfoUpdateListener() {
                                    public void onConsentInfoUpdated(ConsentStatus consentStatus) {
                                        String access$300 = SettingsActivity.this.TAG;
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("consentStatus = '");
                                        stringBuilder.append(consentStatus);
                                        Log.e(access$300, stringBuilder.toString());
                                        SettingsActivity.this.editor.putBoolean("googleads_consent_np", true);
                                        SettingsActivity.this.editor.commit();
                                        SettingsActivity.this.editor.putBoolean("googleads_consent", true);
                                        SettingsActivity.this.editor.commit();
                                        view.setBackgroundResource(R.drawable.bgsettingsconsentads);
                                        finalButton.setBackgroundColor(SettingsActivity.this.getResources().getColor(R.color.status_2));
                                        Map hashMap = new HashMap();
                                        hashMap.put("admobadsconsent", "Non-Personalised");
                                    }

                                    public void onFailedToUpdateConsentInfo(String str) {
                                        Toast.makeText(SettingsActivity.this.getApplicationContext(), "Please check your Internet Connection", Toast.LENGTH_LONG).show();
                                        dialog.cancel();
                                    }
                                });
                            }
                        });
                        button.setOnClickListener(new OnClickListener() {
                            public void onClick(final View view) {
                                SettingsActivity.this.consentInformation.setConsentStatus(ConsentStatus.PERSONALIZED);
                                String access$300 = SettingsActivity.this.TAG;
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("");
                                stringBuilder.append(SettingsActivity.this.consentInformation.getConsentStatus());
                                Log.e(access$300, stringBuilder.toString());
                                SettingsActivity.this.consentInformation.requestConsentInfoUpdate(SettingsActivity.this.publisherIds, new ConsentInfoUpdateListener() {
                                    public void onConsentInfoUpdated(ConsentStatus consentStatus) {
                                        String access$300 = SettingsActivity.this.TAG;
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("consentStatus = '");
                                        stringBuilder.append(consentStatus);
                                        Log.e(access$300, stringBuilder.toString());
                                        SettingsActivity.this.editor.putBoolean("googleads_consent", true);
                                        SettingsActivity.this.editor.commit();
                                        SettingsActivity.this.editor.putBoolean("googleads_consent_np", false);
                                        SettingsActivity.this.editor.commit();
                                        view.setBackgroundResource(R.drawable.bgsettingsconsentads);
                                        button2.setBackgroundColor(SettingsActivity.this.getResources().getColor(R.color.status_2));
                                        Map hashMap = new HashMap();
                                        hashMap.put("admobadsconsent", "Personalised");
                                    }

                                    public void onFailedToUpdateConsentInfo(String str) {
                                        Toast.makeText(SettingsActivity.this.getApplicationContext(), "Please check your Internet Connection", Toast.LENGTH_LONG).show();
                                        dialog.cancel();
                                    }
                                });
                            }
                        });
                        if ((SettingsActivity.this.getResources().getConfiguration().screenLayout & 15) == 4) {
                            button2.setTypeface(SettingsActivity.this.typeface);
                            button2.setTextSize(32.0f);
                            button.setTypeface(SettingsActivity.this.typeface);
                            button.setTextSize(32.0f);
                        } else if ((SettingsActivity.this.getResources().getConfiguration().screenLayout & 15) == 3) {
                            button2.setTypeface(SettingsActivity.this.typeface);
                            button2.setTextSize(24.0f);
                            button.setTypeface(SettingsActivity.this.typeface);
                            button.setTextSize(24.0f);
                        } else {
                            button2.setTypeface(SettingsActivity.this.typeface);
                            button2.setTextSize(18.0f);
                            button.setTypeface(SettingsActivity.this.typeface);
                            button.setTextSize(18.0f);
                        }
                        double access$600 = (double) SettingsActivity.this.sw;
                        Double.isNaN(access$600);
                        int i2 = (int) (access$600 * 0.07d);
                        double access$6002 = (double) SettingsActivity.this.sw;
                        Double.isNaN(access$6002);
                        int i3 = (int) (access$6002 * 0.07d);
                        access$6002 = (double) SettingsActivity.this.sw;
                        Double.isNaN(access$6002);
                        int i4 = (int) (access$6002 * 0.07d);
                        double access$6003 = (double) SettingsActivity.this.sw;
                        Double.isNaN(access$6003);
                        button.setPadding(i2, i3, i4, (int) (access$6003 * 0.07d));
                        access$600 = (double) SettingsActivity.this.sw;
                        Double.isNaN(access$600);
                        i2 = (int) (access$600 * 0.07d);
                        access$6002 = (double) SettingsActivity.this.sw;
                        Double.isNaN(access$6002);
                        i3 = (int) (access$6002 * 0.07d);
                        access$6002 = (double) SettingsActivity.this.sw;
                        Double.isNaN(access$6002);
                        i4 = (int) (access$6002 * 0.07d);
                        access$6003 = (double) SettingsActivity.this.sw;
                        Double.isNaN(access$6003);
                        button2.setPadding(i2, i3, i4, (int) (access$6003 * 0.07d));
                        if (SettingsActivity.this.sharedPreferences.getBoolean("googleads_consent_np", false)) {
                            button2.setBackgroundResource(R.drawable.bgsettingsconsentads);
                        } else {
                            button.setBackgroundResource(R.drawable.bgsettingsconsentads);
                        }
                        if (!SettingsActivity.this.activity.isFinishing()) {
                            dialog.show();
                        }
                    }
                }
            });
        }

        public int getItemCount() {
            String access$300 = SettingsActivity.this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(this.arrlist.size());
            Log.e(access$300, stringBuilder.toString());
            return this.arrlist.size();
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_settings);
        this.activity = this;
        StrictMode.setThreadPolicy(new Builder().permitAll().build());
        ArrayList arrayList = new ArrayList();
        arrayList.add("Privacy Policy");
        arrayList.add("Update Consent Status");
        String str = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(arrayList);
        Log.e(str, stringBuilder.toString());
        SharedPreferences sharedPreferences = getSharedPreferences("MYPREFERENCE", 0);
        this.sharedPreferences = sharedPreferences;
        this.editor = sharedPreferences.edit();
        this.typeface = Typeface.createFromAsset(getAssets(), "fonts/MAGNOLIA SCRIPT.OTF");
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.sw = displayMetrics.widthPixels;
        ConsentInformation instance = ConsentInformation.getInstance(getApplicationContext());
        this.consentInformation = instance;
        this.publisherIds = new String[]{"pub-4933880264960213"};
        boolean isRequestLocationInEeaOrUnknown = instance.isRequestLocationInEeaOrUnknown();
        String str2 = this.TAG;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("***********");
        stringBuilder2.append(isRequestLocationInEeaOrUnknown);
        Log.e(str2, stringBuilder2.toString());
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        RecyclerViewAdapter recyclerViewAdapter = new RecyclerViewAdapter(arrayList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.addItemDecoration(new DividerItemDecoration(this, 1));
        recyclerView.setAdapter(recyclerViewAdapter);
    }
}
