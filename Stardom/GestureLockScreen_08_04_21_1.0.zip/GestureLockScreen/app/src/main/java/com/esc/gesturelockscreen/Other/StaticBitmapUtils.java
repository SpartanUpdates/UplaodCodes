package com.esc.gesturelockscreen.Other;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

public class StaticBitmapUtils {

    public static Bitmap decodeFileFromUriToBitmap(Uri uri) {
        String uri2 = uri.toString();
        return BitmapFactory.decodeFile(uri2);
    }
}
