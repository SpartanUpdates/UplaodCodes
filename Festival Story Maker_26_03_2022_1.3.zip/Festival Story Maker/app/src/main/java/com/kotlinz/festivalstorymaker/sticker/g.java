package com.kotlinz.festivalstorymaker.sticker;


import com.kotlinz.festivalstorymaker.StickerView.StickerView;

public class g implements Runnable {
    public final  e e;
    public final  int f;
    public final StickerView g;

    public g(final StickerView g, final e e, final int f) {
        this.g = g;
        this.e = e;
        this.f = f;
    }

    @Override
    public void run() {
//        this.g.a(this.e, this.f);

    }
}
