package com.kotlinz.festivalstorymaker.Model.CollageMaker.Element;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class ElementMainResponse {

	@SerializedName("collage_cat_id")
	private int collageCatId;

	@SerializedName("updated_at")
	private String updatedAt;

	@SerializedName("element_categoty_thumbnail")
	private Object elementCategotyThumbnail;

	@SerializedName("element_category_name")
	private String elementCategoryName;

	@SerializedName("created_at")
	private String createdAt;

	@SerializedName("element_images")
	private ArrayList<ElementImagesItem> elementImages;

	@SerializedName("module_name")
	private String moduleName;

	@SerializedName("application_id")
	private String applicationId;

	public int getCollageCatId(){
		return collageCatId;
	}

	public String getUpdatedAt(){
		return updatedAt;
	}

	public Object getElementCategotyThumbnail(){
		return elementCategotyThumbnail;
	}

	public String getElementCategoryName(){
		return elementCategoryName;
	}

	public String getCreatedAt(){
		return createdAt;
	}

	public ArrayList<ElementImagesItem> getElementImages(){
		return elementImages;
	}

	public String getModuleName(){
		return moduleName;
	}

	public String getApplicationId(){
		return applicationId;
	}
}