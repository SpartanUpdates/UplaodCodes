package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter;

public class CanvadEditorColorListListener implements ColorListAdapter.a
{
    @Override
    public final void D(final int n) {
       D(n);
    }
}
