package com.example.lyricsvideo;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.lyricsvideo.PickImages.ImageSelectionUsage;
import com.example.lyricsvideo.activity.FullVideoPlayActivity;
import com.example.lyricsvideo.activity.MainActivity;
import com.example.lyricsvideo.application.App;

public class CallFromUnity {
    public static ImageSelectionUsage imageSelectionUsage;
    public static String TransparantVideoPath;
    public static String UnityXmlPath;
    public static String ImagePath;
    private static App application;

    public CallFromUnity() {
        application = App.getInstance();
    }

    public static void HomeActivity(Context context, String CateroryUrl, String CategoryDataUrl, String DownloadUrl, String VideoViewUrl, String VideoShareUrl) {
        App.IsFromHomeUnity = true;
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra("CategoryUrl", CateroryUrl);
        intent.putExtra("CategoryDataUrl", CategoryDataUrl);
        intent.putExtra("DownloadUrl", DownloadUrl);
        intent.putExtra("VideoViewUrl", VideoViewUrl);
        intent.putExtra("VideoShareUrl", VideoShareUrl);
        context.startActivity(intent);
    }

    public static void ImageSelection(Context cntx, int width, int hight, int noOfImage, boolean IsFromMytemplateVideo) {
        App.IS_EDITIMAGE = 0;
        imageSelectionUsage = ImageSelectionUsage.getInstance(cntx);
        ImageSelectionUsage.pickImages(width, hight, noOfImage, IsFromMytemplateVideo);
    }

    public static void OpenVideoDialog(Context context, boolean IsFrom) {
        AppUsages.PlayVideo(context, IsFrom);
    }

    public static void BannerAdsShow(Context context) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public void run() {
                UnityPlayerActivity.layoutNativeBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    public static void VideoMixing(Context context, String MuteVideoName, String SaveVideoName) {
        AppUsages.alertDialog.dismiss();
        AppUsages.VideoMearge(context, MuteVideoName, SaveVideoName);
//        Intent i = new Intent(context, ProgressActivity.class);
//        i.putExtra("MuteVideoName", MuteVideoName);
//        i.putExtra("SaveVideoName", SaveVideoName);
//        context.startActivity(i);
    }

    public static void OnBackPressFromUnity(Context context) {
        AppUsages.IsPreview = false;
        Toast.makeText(context, "OnBackPressUnity", Toast.LENGTH_SHORT).show();
    }

    public static void VideoPlayAct(Context context) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public void run() {
                UnityPlayerActivity.layoutNativeBanner.setVisibility(View.GONE);
            }
        });
        application = App.getInstance();
        application.Allclear();
        final Intent intent = new Intent(context, FullVideoPlayActivity.class);
        intent.putExtra("Url", AppUsages.OutputVideoPath);
        intent.putExtra("Name", AppUsages.OutputVideoName);
        intent.putExtra("IsPlayVidoeFromHome", false);
        intent.putExtra("IsVideoFromList", false);
        context.startActivity(intent);
        RefereshVideoList(context, AppUsages.OutputVideoPath);
        AppUsages.last = 0.0f;
    }

    private static void RefereshVideoList(Context cntx, String path) {
        try {
            android.media.MediaScannerConnection.scanFile(cntx,
                    new String[]{path},
                    new String[]{"video/mp4"},
                    new android.media.MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
