package com.esc.storymaker.utils;

import android.app.Activity;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.text.TextUtils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FontProvider {
    private static final String DEFAULT_FONT_CATEGORY = "Basic";
    private static final String DEFAULT_FONT_NAME = "Basic 1";
    private final Activity activity;
    private List<String> fontNames;
    private final Map<String, String> map3D = new HashMap();
    private final Map<String, String> mapBasic = new HashMap();
    private final Map<String, String> mapBrush = new HashMap();
    private final Map<String, String> mapCalligraphy = new HashMap();
    private final Map<String, String> mapComic = new HashMap();
    private final Map<String, String> mapDecorative = new HashMap();
    private final Map<String, String> mapGothic = new HashMap();
    private final Map<String, String> mapHolidays = new HashMap();
    private final Map<String, String> mapRetro = new HashMap();
    private final Map<String, String> mapStencilArmy = new HashMap();
    private final Resources resources;
    private final Map<String, Typeface> typefaces = new HashMap();

    public String getDefaultFontCategory() {
        return DEFAULT_FONT_CATEGORY;
    }

    public String getDefaultFontName() {
        return DEFAULT_FONT_NAME;
    }

    public FontProvider(Activity activity, Resources resources) {
        this.activity = activity;
        this.resources = resources;
        try {
            String str;
            Iterator it = getFontList("3D").iterator();
            while (it.hasNext()) {
                str = (String) it.next();
                this.map3D.put(getFontName(str), str);
            }
            it = getFontList(DEFAULT_FONT_CATEGORY).iterator();
            while (it.hasNext()) {
                str = (String) it.next();
                this.mapBasic.put(getFontName(str), str);
            }
            it = getFontList("Brush").iterator();
            while (it.hasNext()) {
                str = (String) it.next();
                this.mapBrush.put(getFontName(str), str);
            }
            it = getFontList("Calligraphy").iterator();
            while (it.hasNext()) {
                str = (String) it.next();
                this.mapCalligraphy.put(getFontName(str), str);
            }
            it = getFontList("Comic").iterator();
            while (it.hasNext()) {
                str = (String) it.next();
                this.mapComic.put(getFontName(str), str);
            }
            it = getFontList("Decorative").iterator();
            while (it.hasNext()) {
                str = (String) it.next();
                this.mapDecorative.put(getFontName(str), str);
            }
            it = getFontList("Gothic").iterator();
            while (it.hasNext()) {
                str = (String) it.next();
                this.mapGothic.put(getFontName(str), str);
            }
            it = getFontList("Retro").iterator();
            while (it.hasNext()) {
                str = (String) it.next();
                this.mapRetro.put(getFontName(str), str);
            }
            it = getFontList("Stencil Army").iterator();
            while (it.hasNext()) {
                str = (String) it.next();
                this.mapStencilArmy.put(getFontName(str), str);
            }
            it = getFontList("Holidays").iterator();
            while (it.hasNext()) {
                str = (String) it.next();
                this.mapHolidays.put(getFontName(str), str);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Typeface getTypeface(String str, String str2) {
        if (TextUtils.isEmpty(str2)) {
            return Typeface.DEFAULT;
        }
        if (this.typefaces.get(str2) == null) {
            if (getTypeFace(str, str2) != null) {
                Map map = this.typefaces;
                AssetManager assets = this.resources.getAssets();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Fonts/");
                stringBuilder.append(str);
                stringBuilder.append("/");
                stringBuilder.append(getTypeFace(str, str2));
                map.put(str2, Typeface.createFromAsset(assets, stringBuilder.toString()));
            } else {
                Map map2 = this.typefaces;
                AssetManager assets2 = this.resources.getAssets();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Fonts/Basic/");
                String str3 = DEFAULT_FONT_NAME;
                stringBuilder2.append(getTypeFace(DEFAULT_FONT_CATEGORY, str3));
                map2.put(str3, Typeface.createFromAsset(assets2, stringBuilder2.toString()));
            }
        }
        return (Typeface) this.typefaces.get(str2);
    }


    private String getFontName(String str) {
        return str.replace(str.substring(str.indexOf(".")), "");
    }
    private String getTypeFace(String str, String str2) {
        char c;
        switch (str.hashCode()) {
            case -1521798719:
                if (str.equals("Stencil Army")) {
                    c = 8;
                    break;
                }
            case -446019781:
                if (str.equals("Holidays")) {
                    c = 9;
                    break;
                }
            case 1649:
                if (str.equals("3D")) {
                    c = 0;
                    break;
                }
            case 63955982:
                if (str.equals(DEFAULT_FONT_CATEGORY)) {
                    c = 1;
                    break;
                }
            case 64464666:
                if (str.equals("Brush")) {
                    c = 2;
                    break;
                }
            case 65290811:
                if (str.equals("Comic")) {
                    c = 4;
                    break;
                }
            case 78852734:
                if (str.equals("Retro")) {
                    c = 7;
                    break;
                }
            case 1182766496:
                if (str.equals("Decorative")) {
                    c = 5;
                    break;
                }
            case 1345461846:
                if (str.equals("Calligraphy")) {
                    c = 3;
                    break;
                }
            case 2138739606:
                if (str.equals("Gothic")) {
                    c = 6;
                    break;
                }
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                return (String) this.map3D.get(str2);
            case 1:
                return (String) this.mapBasic.get(str2);
            case 2:
                return (String) this.mapBrush.get(str2);
            case 3:
                return (String) this.mapCalligraphy.get(str2);
            case 4:
                return (String) this.mapComic.get(str2);
            case 5:
                return (String) this.mapDecorative.get(str2);
            case 6:
                return (String) this.mapGothic.get(str2);
            case 7:
                return (String) this.mapRetro.get(str2);
            case 8:
                return (String) this.mapStencilArmy.get(str2);
            case 9:
                return (String) this.mapHolidays.get(str2);
            default:
                return "";
        }
    }


    public List<String> getFontNames(String str) {
        char c;
        switch (str.hashCode()) {
            case -1521798719:
                if (str.equals("Stencil Army")) {
                    c = 8;
                    break;
                }
            case -446019781:
                if (str.equals("Holidays")) {
                    c = 9;
                    break;
                }
            case 1649:
                if (str.equals("3D")) {
                    c = 0;
                    break;
                }
            case 63955982:
                if (str.equals(DEFAULT_FONT_CATEGORY)) {
                    c = 1;
                    break;
                }
            case 64464666:
                if (str.equals("Brush")) {
                    c = 2;
                    break;
                }
            case 65290811:
                if (str.equals("Comic")) {
                    c = 4;
                    break;
                }
            case 78852734:
                if (str.equals("Retro")) {
                    c = 7;
                    break;
                }
            case 1182766496:
                if (str.equals("Decorative")) {
                    c = 5;
                    break;
                }
            case 1345461846:
                if (str.equals("Calligraphy")) {
                    c = 3;
                    break;
                }
            case 2138739606:
                if (str.equals("Gothic")) {
                    c = 6;
                    break;
                }
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                this.fontNames = new ArrayList(this.map3D.keySet());
                break;
            case 1:
                this.fontNames = new ArrayList(this.mapBasic.keySet());
                break;
            case 2:
                this.fontNames = new ArrayList(this.mapBrush.keySet());
                break;
            case 3:
                this.fontNames = new ArrayList(this.mapCalligraphy.keySet());
                break;
            case 4:
                this.fontNames = new ArrayList(this.mapComic.keySet());
                break;
            case 5:
                this.fontNames = new ArrayList(this.mapDecorative.keySet());
                break;
            case 6:
                this.fontNames = new ArrayList(this.mapGothic.keySet());
                break;
            case 7:
                this.fontNames = new ArrayList(this.mapRetro.keySet());
                break;
            case 8:
                this.fontNames = new ArrayList(this.mapStencilArmy.keySet());
                break;
            case 9:
                this.fontNames = new ArrayList(this.mapHolidays.keySet());
                break;
        }
        return this.fontNames;
    }

    private ArrayList<String> getFontList(String str) throws IOException {
        AssetManager assets = this.activity.getAssets();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fonts/");
        stringBuilder.append(str);
        return new ArrayList(Arrays.asList(assets.list(stringBuilder.toString())));
    }

    public int getFontPosition(String str, String str2) {
        return getFontNames(str).indexOf(str2);
    }
}
