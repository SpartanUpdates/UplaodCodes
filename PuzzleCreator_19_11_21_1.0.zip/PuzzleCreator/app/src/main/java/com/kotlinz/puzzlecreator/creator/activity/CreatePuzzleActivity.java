package com.kotlinz.puzzlecreator.creator.activity;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.transition.Slide;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.material.textfield.TextInputLayout;
import com.kotlinz.puzzlecreator.App.MyApplication;
import com.kotlinz.puzzlecreator.activity.BaseActivity;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.kprogresshud.KProgressHUD;
import com.kotlinz.puzzlecreator.retrofit.APIClient;
import com.kotlinz.puzzlecreator.retrofit.APIInterface;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;
import com.yalantis.ucrop.UCrop;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import pl.droidsonroids.gif.GifImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreatePuzzleActivity extends BaseActivity {
    Activity activity = CreatePuzzleActivity.this;
    ImageView puzzleImg;
    LinearLayout addimg, lmanual;
    Button btnadd;
    EditText edtans, edtquestion, edthint;
    GridLayout lans;
    String type = "", userChoosenTask = "", difficulty = "", viewto = "", trueans = "", pid;
    TextInputLayout thint, tquestion, ltype, ldlevel, lviewto;
    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;
    ArrayList<String> anslist = new ArrayList<>();
    File image;
    AutoCompleteTextView spinutype, spinview, spindlevel;
    String updateType = "", UpdateView = "", Updatelevel = "";

    public InterstitialAd mInterstitialAd;
    private KProgressHUD hud;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_puzzle);
        setAnimation();
        setToolbar("Create Puzzle");

        edthint = findViewById(R.id.edthint);
        edtquestion = findViewById(R.id.edtquestion);
        edtans = findViewById(R.id.edtinvalidans);

        btnadd = findViewById(R.id.btnadd);

        thint = findViewById(R.id.thint);
        tquestion = findViewById(R.id.tquestion);
        lviewto = findViewById(R.id.lviewto);
        ldlevel = findViewById(R.id.ldlevel);
        ltype = findViewById(R.id.lptype);

        lans = findViewById(R.id.dynamictxt);

        spinview = findViewById(R.id.spinview);
        spindlevel = findViewById(R.id.spindificulty);
        spinutype = findViewById(R.id.textspin);

        addimg = findViewById(R.id.addimg);
        lmanual = findViewById(R.id.linearmanual);

        puzzleImg = findViewById(R.id.img);

        thint = findViewById(R.id.thint);
        tquestion = findViewById(R.id.tquestion);
        interstitialAd();
        settype();
        setdifficulty();
        setviewto();

        edtquestion.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tquestion.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtquestion.getText().toString().equalsIgnoreCase("")) {
                    tquestion.setErrorEnabled(true);
                    tquestion.setError("Enter Question");
                } else if (type.equalsIgnoreCase("")) {
                    ltype.setErrorEnabled(true);
                    ltype.setError("Select Question Type");
                } else if (lans.getVisibility() == View.VISIBLE && anslist.size() == 0) {
                    Toast.makeText(CreatePuzzleActivity.this, "Add Answer", Toast.LENGTH_LONG).show();
                } else if (lans.getVisibility() == View.GONE && edtans.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(CreatePuzzleActivity.this, "Add Valid Answer", Toast.LENGTH_LONG).show();
                } else if (viewto.equalsIgnoreCase("")) {
                    lviewto.setErrorEnabled(true);
                    lviewto.setError("Select View To");
                } else if (difficulty.equalsIgnoreCase("")) {
                    ldlevel.setErrorEnabled(true);
                    ldlevel.setError("Select Difficulty Level");
                } else {
                    if (anslist.size() != 0) {
                        Collections.shuffle(anslist);
                        Log.e("Arraylist", "....." + anslist.toString());
                    }
                    if (btnadd.getText().toString().equalsIgnoreCase("Create Puzzle")) {
                        Bundle params = new Bundle();
                        mFirebaseAnalytics.logEvent("Create_Puzzle_Button_Click", params);
                        if (type.equalsIgnoreCase(getResources().getString(R.string.bolean))) {
                            PostBooleanuzzle(edtquestion.getText().toString(), "boolean", anslist.get(0), anslist.get(1), trueans, edthint.getText().toString(), difficulty, viewto);
                        } else if (type.equalsIgnoreCase(getResources().getString(R.string.mcq))) {
                            PostMCQPuzzle(edtquestion.getText().toString(), "mcq", anslist.get(0), anslist.get(1), anslist.get(2), anslist.get(3), trueans, edthint.getText().toString(), difficulty, viewto);
                        } else {
                            anslist.add(edtans.getText().toString());
                            trueans = edtans.getText().toString();
                            PostManualPuzzle(edtquestion.getText().toString(), "manual", anslist.get(0), trueans, edthint.getText().toString(), difficulty, viewto);
                        }
                    } else {
                        Bundle params = new Bundle();
                        mFirebaseAnalytics.logEvent("Update_Puzzle_Button_Click", params);
                        if (mInterstitialAd != null) {
                            try {
                                hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                                hud.show();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        hud.dismiss();
                                    } catch (IllegalArgumentException e) {
                                        e.printStackTrace();

                                    } catch (NullPointerException e2) {
                                        e2.printStackTrace();
                                    } catch (Exception e3) {
                                        e3.printStackTrace();
                                    }
                                    if (mInterstitialAd != null) {
                                        MyApplication.AdsId = 1;
                                        mInterstitialAd.show(activity);
                                    }
                                }
                            }, 2000);
                        } else {
                            if (type.equalsIgnoreCase(getResources().getString(R.string.bolean))) {
                                UpdateBooleanuzzle(pid, edtquestion.getText().toString(), "boolean", anslist.get(0), anslist.get(1), trueans, edthint.getText().toString(), difficulty, viewto);
                            } else if (type.equalsIgnoreCase(getResources().getString(R.string.mcq))) {
                                UpdateMCQPuzzle(pid, edtquestion.getText().toString(), "mcq", anslist.get(0), anslist.get(1), anslist.get(2), anslist.get(3), trueans, edthint.getText().toString(), difficulty, viewto);
                            } else {
                                anslist.add(edtans.getText().toString());
                                trueans = edtans.getText().toString();
                                UpdateManualPuzzle(pid, edtquestion.getText().toString(), "manual", anslist.get(0), trueans, edthint.getText().toString(), difficulty, viewto);
                            }
                        }
                    }
                }

            }
        });
        puzzleImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean result = checkPermission(CreatePuzzleActivity.this);
                if (result) {
                    DeleteImage();
                    selectImage();
                }
            }
        });

        spindlevel.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ldlevel.setErrorEnabled(false);

                if (parent.getItemAtPosition(position).toString().equalsIgnoreCase(getResources().getString(R.string.high))) {
                    difficulty = "high";
                } else if (parent.getItemAtPosition(position).toString().equalsIgnoreCase(getResources().getString(R.string.medium))) {
                    difficulty = "medium";
                } else if (parent.getItemAtPosition(position).toString().equalsIgnoreCase(getResources().getString(R.string.low))) {
                    difficulty = "low";
                } else {
                    difficulty = "";
                }
            }
        });

        spinview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                lviewto.setErrorEnabled(false);

                if (parent.getItemAtPosition(position).toString().equalsIgnoreCase(getResources().getString(R.string.onlyme))) {
                    viewto = "only_me";
                } else if (parent.getItemAtPosition(position).toString().equalsIgnoreCase(getResources().getString(R.string.everyone))) {
                    viewto = "everyone";
                } else {
                    viewto = "";
                }
                Log.e("view", ".." + viewto);
            }
        });

        spinutype.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                type = parent.getItemAtPosition(position).toString();
                edtans.setHint("Enter Valid Answer");
                edtans.setText("");
                ltype.setErrorEnabled(false);
                if (type.equalsIgnoreCase(getResources().getString(R.string.bolean))) {

                    lans.setVisibility(View.VISIBLE);
                    lans.removeAllViews();
                    anslist.clear();
                    lans.setRowCount(2);
                    lmanual.setVisibility(View.GONE);
                    showAddAnsDialog(type, 2);
                } else if (type.equalsIgnoreCase(getResources().getString(R.string.mcq))) {
                    lans.setVisibility(View.VISIBLE);
                    anslist.clear();
                    lans.removeAllViews();
                    lans.setRowCount(4);
                    lmanual.setVisibility(View.GONE);
                    showAddAnsDialog(type, 4);
                } else if (type.equalsIgnoreCase(getResources().getString(R.string.manual))) {
                    anslist.clear();
                    lans.removeAllViews();
                    lmanual.setVisibility(View.VISIBLE);
                    lans.setVisibility(View.GONE);
                } else {
                    type = "";
                }
            }
        });

        if (getIntent().getExtras() != null) {
            if (getIntent().getExtras().getString("update").equalsIgnoreCase("update")) {
                btnadd.setText("Update");
                Glide.with(this).load(getIntent().getExtras().getString("img")).into(puzzleImg);
                edtquestion.setText(getIntent().getExtras().getString("question"));
                String hint = getIntent().getExtras().getString("hint");
                if (hint.equalsIgnoreCase("") || hint.equalsIgnoreCase(null) || hint.equalsIgnoreCase("null")) {
                    edthint.setText("");
                } else {
                    edthint.setText(hint);
                }
                updateType = getIntent().getExtras().getString("type");
                Updatelevel = getIntent().getExtras().getString("level");
                UpdateView = getIntent().getExtras().getString("view");
                pid = getIntent().getExtras().getString("pid");

                settype();
                setviewto();
                setdifficulty();

            }
        }
    }

    private void interstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(activity, getResources().getString(R.string.InterstitialAd_id), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        requestNewInterstitial();
                                        switch (MyApplication.AdsId) {
                                            case 1:
                                                if (type.equalsIgnoreCase(getResources().getString(R.string.bolean))) {
                                                    UpdateBooleanuzzle(pid, edtquestion.getText().toString(), "boolean", anslist.get(0), anslist.get(1), trueans, edthint.getText().toString(), difficulty, viewto);
                                                } else if (type.equalsIgnoreCase(getResources().getString(R.string.mcq))) {
                                                    UpdateMCQPuzzle(pid, edtquestion.getText().toString(), "mcq", anslist.get(0), anslist.get(1), anslist.get(2), anslist.get(3), trueans, edthint.getText().toString(), difficulty, viewto);
                                                } else {
                                                    anslist.add(edtans.getText().toString());
                                                    trueans = edtans.getText().toString();
                                                    UpdateManualPuzzle(pid, edtquestion.getText().toString(), "manual", anslist.get(0), trueans, edthint.getText().toString(), difficulty, viewto);
                                                }
                                                break;
                                        }
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                    }
                });

    }

    private void requestNewInterstitial() {
        interstitialAd();
    }

    public void setAnimation() {
        if (Build.VERSION.SDK_INT > 20) {
            Slide slide = new Slide();
            slide.setDuration(1000);
            slide.excludeTarget(android.R.id.statusBarBackground, true);
            slide.excludeTarget(android.R.id.navigationBarBackground, true);
            slide.setInterpolator(new DecelerateInterpolator());
            getWindow().setEnterTransition(slide);
            getWindow().setExitTransition(slide);
            getWindow().setBackgroundDrawable(getDrawable(R.drawable.gradiant));

        }
    }


    public void settype() {

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        R.layout.dropdown_menu_popup_item,
                        getResources().getStringArray(R.array.puzzle_type));
        spinutype.setText(adapter.getItem(0));
        spinutype.setAdapter(adapter);

        type = "";

       /* lans.setVisibility(View.VISIBLE);
        lans.removeAllViews();
        anslist.clear();
        lans.setRowCount(2);
        lmanual.setVisibility(View.GONE);*/

    }

    public void setviewto() {
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        R.layout.dropdown_menu_popup_item,
                        getResources().getStringArray(R.array.view_to));
        spinview.setText(adapter.getItem(0));
        spinview.setAdapter(adapter);
        viewto = "";
        Log.e("Utype", ".........." + viewto);

    }

    public void setdifficulty() {
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        R.layout.dropdown_menu_popup_item,
                        getResources().getStringArray(R.array.difficulty));
        spindlevel.setText(adapter.getItem(0));

        spindlevel.setAdapter(adapter);
        difficulty = "";
        Log.e("Utype", ".........." + difficulty);

    }

    public void addans(String text, boolean status) {
        lans.setVisibility(View.VISIBLE);
        TextView textView = new TextView(this);
        if (status) {
            textView.setText("Valid Ans : " + text);
            textView.setTextColor(Color.GREEN);
        } else {
            textView.setText("Invalid Ans : " + text);
            textView.setTextColor(Color.RED);

        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            textView.setTypeface(getResources().getFont(R.font.poppins_medium));
        }

        textView.setPadding(10, 15, 10, 15);
        textView.setTextSize(15);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(5, 5, 5, 5);
        textView.setLayoutParams(params);
        lans.addView(textView);
        if (lans.getChildCount() <= lans.getRowCount()) {
            anslist.add(text);
        }

    }

    public static boolean checkPermission(final Context context) {
        int currentAPIVersion = Build.VERSION.SDK_INT;
        if (currentAPIVersion >= android.os.Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
                    alertBuilder.setCancelable(true);
                    alertBuilder.setTitle("Permission necessary");
                    alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                        }
                    });
                    AlertDialog alert = alertBuilder.create();
                    alert.show();
                } else {
                    ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                }
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    private void selectImage() {
        final CharSequence[] options = {"Choose From Camera", "Choose From Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Choose Option!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Choose From Camera")) {
                    Intent takePicture = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(takePicture, 1);
                } else if (options[item].equals("Choose From Gallery")) {
                    Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pickPhoto, 2);
                } else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE:
                selectImage();
                break;
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == UCrop.REQUEST_CROP) {
                Uri resultUri = UCrop.getOutput(data);
                if (resultUri != null) {
                    Log.e("TAG", "Image Crop Found");
                    Picasso.with(activity).load(resultUri).memoryPolicy(MemoryPolicy.NO_CACHE).into(puzzleImg);
                    File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + File.separator + "Puzzle");
                    image = new File(file, "temp.jpg");
                } else {
                    Toast.makeText(activity, "Select Image First...", Toast.LENGTH_SHORT).show();
                }
            }
        }
        if (resultCode != RESULT_CANCELED) {
            switch (requestCode) {
                case 1:
                    if (resultCode == RESULT_OK && data != null) {
                        Bitmap selectedImage = (Bitmap) data.getExtras().get("data");

                        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                        selectedImage.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
                        String path = MediaStore.Images.Media.insertImage(getContentResolver(), selectedImage, "Title", null);

                        Uri CameraImage = Uri.parse(path);
                        if (CameraImage != null) {
                            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + File.separator + "Puzzle");
                            if (!file.isDirectory()) {
                                file.mkdirs();
                            }
                            UCrop.of(CameraImage, Uri.fromFile(new File(file, "temp.jpg")))
                                    .withAspectRatio(16, 19)
                                    .start(activity);
                        } else {
                            Toast.makeText(activity, "Select Image First...", Toast.LENGTH_SHORT).show();
                        }
                    }
                    break;
                case 2:
                    if (resultCode == RESULT_OK && data != null) {
                        Uri GalleryImage = data.getData();
                        if (GalleryImage != null) {
                            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + File.separator + "Puzzle");
                            if (!file.isDirectory()) {
                                file.mkdirs();
                            }
                            UCrop.of(GalleryImage, Uri.fromFile(new File(file, "temp.jpg")))
                                    .withAspectRatio(16, 19)
                                    .start(activity);
                        } else {
                            Toast.makeText(activity, "Select Image First...", Toast.LENGTH_SHORT).show();
                        }
                    }
                    break;
            }
        }
    }


    private void PostMCQPuzzle(String question, String qtype, String opt1, String opt2, String opt3, String opt4, String tans, String hint, String level, String view) {
        showProgressDialog();
        MultipartBody.Part filePart;
        if (image != null) {
            Log.e("Image", "..." + image.getName() + image);
            filePart = MultipartBody.Part.createFormData("image", image.getName(), RequestBody.create(MediaType.parse("image/*"), image));
        } else {
            filePart = null;
        }
        RequestBody rquestion = RequestBody.create(MediaType.parse("multipart/form-data"), question);
        RequestBody rqtype = RequestBody.create(MediaType.parse("multipart/form-data"), qtype);
        RequestBody ropt1 = RequestBody.create(MediaType.parse("multipart/form-data"), opt1);
        RequestBody ropt2 = RequestBody.create(MediaType.parse("multipart/form-data"), opt2);
        RequestBody ropt3 = RequestBody.create(MediaType.parse("multipart/form-data"), opt3);
        RequestBody ropt4 = RequestBody.create(MediaType.parse("multipart/form-data"), opt4);
        RequestBody rtans = RequestBody.create(MediaType.parse("multipart/form-data"), tans);
        RequestBody rhint = RequestBody.create(MediaType.parse("multipart/form-data"), hint);
        RequestBody rlevel = RequestBody.create(MediaType.parse("multipart/form-data"), level);
        RequestBody rview = RequestBody.create(MediaType.parse("multipart/form-data"), view);

        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).mcqPuzzle(sessionManager.getToken(), filePart, rquestion, rqtype, ropt1, ropt2, ropt3, ropt4, rtans, rhint, rlevel, rview);

        call.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        Log.e("Responce", "........" + res);
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            cancel_dialog();
                            showSuccessDialog("Success", jsonObject.getString("message"));
                        }

                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });


    }

    private void PostManualPuzzle(String question, String qtype, String opt1, String tans, String hint, String level, String view) {
        showProgressDialog();
        MultipartBody.Part filePart;
        if (image != null) {
            filePart = MultipartBody.Part.createFormData("image", image.getName(), RequestBody.create(MediaType.parse("image/*"), image));
        } else {
            filePart = null;
        }
        RequestBody rquestion = RequestBody.create(MediaType.parse("multipart/form-data"), question);
        RequestBody rqtype = RequestBody.create(MediaType.parse("multipart/form-data"), qtype);
        RequestBody ropt1 = RequestBody.create(MediaType.parse("multipart/form-data"), opt1);
        RequestBody rtans = RequestBody.create(MediaType.parse("multipart/form-data"), tans);
        RequestBody rhint = RequestBody.create(MediaType.parse("multipart/form-data"), hint);
        RequestBody rlevel = RequestBody.create(MediaType.parse("multipart/form-data"), level);
        RequestBody rview = RequestBody.create(MediaType.parse("multipart/form-data"), view);

        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).menualyPuzzle(sessionManager.getToken(), filePart, rquestion, rqtype, ropt1, rtans, rhint, rlevel, rview);

        call.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        Log.e("Response", "........" + res);
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            cancel_dialog();
                            showSuccessDialog("Success", jsonObject.getString("message"));
                        }

                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });


    }

    private void PostBooleanuzzle(String question, String qtype, String opt1, String opt2, String tans, String hint, String level, String view) {
        showProgressDialog();
        MultipartBody.Part filePart;
        if (image != null) {
            Log.e("Image", "..." + image.getName() + image);
            filePart = MultipartBody.Part.createFormData("image", image.getName(), RequestBody.create(MediaType.parse("image/*"), image));
        } else {
            filePart = null;
        }
        RequestBody rquestion = RequestBody.create(MediaType.parse("multipart/form-data"), question);
        RequestBody rqtype = RequestBody.create(MediaType.parse("multipart/form-data"), qtype);
        RequestBody ropt1 = RequestBody.create(MediaType.parse("multipart/form-data"), opt1);
        RequestBody ropt2 = RequestBody.create(MediaType.parse("multipart/form-data"), opt2);
        RequestBody rtans = RequestBody.create(MediaType.parse("multipart/form-data"), tans);
        RequestBody rhint = RequestBody.create(MediaType.parse("multipart/form-data"), hint);
        RequestBody rlevel = RequestBody.create(MediaType.parse("multipart/form-data"), level);
        RequestBody rview = RequestBody.create(MediaType.parse("multipart/form-data"), view);

        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).booleanPuzzle(sessionManager.getToken(), filePart, rquestion, rqtype, ropt1, ropt2, rtans, rhint, rlevel, rview);

        call.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        Log.e("Responce", "........" + res);
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            cancel_dialog();
                            showSuccessDialog("Success", jsonObject.getString("message"));
                        }

                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });


    }

    private void UpdateMCQPuzzle(String pid, String question, String qtype, String opt1, String opt2, String opt3, String opt4, String tans, String hint, String level, String view) {
        showProgressDialog();
        MultipartBody.Part filePart;
        if (image != null) {
            Log.e("Image", "..." + image.getName() + image);
            filePart = MultipartBody.Part.createFormData("image", image.getName(), RequestBody.create(MediaType.parse("image/*"), image));
        } else {
            filePart = null;
        }
        RequestBody rpid = RequestBody.create(MediaType.parse("multipart/form-data"), pid);

        RequestBody rquestion = RequestBody.create(MediaType.parse("multipart/form-data"), question);
        RequestBody rqtype = RequestBody.create(MediaType.parse("multipart/form-data"), qtype);
        RequestBody ropt1 = RequestBody.create(MediaType.parse("multipart/form-data"), opt1);
        RequestBody ropt2 = RequestBody.create(MediaType.parse("multipart/form-data"), opt2);
        RequestBody ropt3 = RequestBody.create(MediaType.parse("multipart/form-data"), opt3);
        RequestBody ropt4 = RequestBody.create(MediaType.parse("multipart/form-data"), opt4);
        RequestBody rtans = RequestBody.create(MediaType.parse("multipart/form-data"), tans);
        RequestBody rhint = RequestBody.create(MediaType.parse("multipart/form-data"), hint);
        RequestBody rlevel = RequestBody.create(MediaType.parse("multipart/form-data"), level);
        RequestBody rview = RequestBody.create(MediaType.parse("multipart/form-data"), view);

        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).updatemcqPuzzle(sessionManager.getToken(), rpid, filePart, rquestion, rqtype, ropt1, ropt2, ropt3, ropt4, rtans, rhint, rlevel, rview);

        call.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        Log.e("Responce", "........" + res);
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            cancel_dialog();
                            showSuccessDialog("Success", jsonObject.getString("message"));
                        }

                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });


    }

    private void UpdateManualPuzzle(String pid, String question, String qtype, String opt1, String tans, String hint, String level, String view) {
        showProgressDialog();
        MultipartBody.Part filePart;
        if (image != null) {
            Log.e("Image", "..." + image.getName() + image);
            filePart = MultipartBody.Part.createFormData("image", image.getName(), RequestBody.create(MediaType.parse("image/*"), image));
        } else {
            filePart = null;
        }
        RequestBody rpid = RequestBody.create(MediaType.parse("multipart/form-data"), pid);

        RequestBody rquestion = RequestBody.create(MediaType.parse("multipart/form-data"), question);
        RequestBody rqtype = RequestBody.create(MediaType.parse("multipart/form-data"), qtype);
        RequestBody ropt1 = RequestBody.create(MediaType.parse("multipart/form-data"), opt1);
        RequestBody rtans = RequestBody.create(MediaType.parse("multipart/form-data"), tans);
        RequestBody rhint = RequestBody.create(MediaType.parse("multipart/form-data"), hint);
        RequestBody rlevel = RequestBody.create(MediaType.parse("multipart/form-data"), level);
        RequestBody rview = RequestBody.create(MediaType.parse("multipart/form-data"), view);
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).updatemenualyPuzzle(sessionManager.getToken(), rpid, filePart, rquestion, rqtype, ropt1, rtans, rhint, rlevel, rview);

        call.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        Log.e("Responce", "........" + res);
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            cancel_dialog();
                            showSuccessDialog("Success", jsonObject.getString("message"));
                        }

                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });

    }

    private void UpdateBooleanuzzle(String pid, String question, String qtype, String opt1, String opt2, String tans, String hint, String level, String view) {
        showProgressDialog();
        MultipartBody.Part filePart;
        if (image != null) {
            Log.e("Image", "..." + image.getName() + image);
            filePart = MultipartBody.Part.createFormData("image", image.getName(), RequestBody.create(MediaType.parse("image/*"), image));
        } else {
            filePart = null;
        }
        RequestBody rpid = RequestBody.create(MediaType.parse("multipart/form-data"), pid);

        RequestBody rquestion = RequestBody.create(MediaType.parse("multipart/form-data"), question);
        RequestBody rqtype = RequestBody.create(MediaType.parse("multipart/form-data"), qtype);
        RequestBody ropt1 = RequestBody.create(MediaType.parse("multipart/form-data"), opt1);
        RequestBody ropt2 = RequestBody.create(MediaType.parse("multipart/form-data"), opt2);
        RequestBody rtans = RequestBody.create(MediaType.parse("multipart/form-data"), tans);
        RequestBody rhint = RequestBody.create(MediaType.parse("multipart/form-data"), hint);
        RequestBody rlevel = RequestBody.create(MediaType.parse("multipart/form-data"), level);
        RequestBody rview = RequestBody.create(MediaType.parse("multipart/form-data"), view);

        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).updatebooleanPuzzle(sessionManager.getToken(), rpid, filePart, rquestion, rqtype, ropt1, ropt2, rtans, rhint, rlevel, rview);

        call.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        Log.e("Responce", "........" + res);
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            cancel_dialog();
                            showSuccessDialog("Success", jsonObject.getString("message"));
                        }

                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });


    }

    public void showAddAnsDialog(String type, Integer range) {

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.setCancelable(false);
        dialog.setContentView(R.layout.popup_ans);
        ImageView btnok = dialog.findViewById(R.id.btn_dialog);
        ImageView btncancel = dialog.findViewById(R.id.btn_close);
        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                settype();
                dialog.dismiss();
            }
        });
        TextView txtmain = dialog.findViewById(R.id.txtmain);
        TextInputLayout valid, tiv1, tiv2, tiv3;
        EditText edtvalid, edtinvalid1, edtinvalid2, edtinvalid3;
        valid = dialog.findViewById(R.id.valid);
        tiv1 = dialog.findViewById(R.id.iv1);
        tiv2 = dialog.findViewById(R.id.iv2);
        tiv3 = dialog.findViewById(R.id.iv3);
        edtvalid = dialog.findViewById(R.id.edt_validAns);
        edtinvalid1 = dialog.findViewById(R.id.edt_invalidAns1);
        edtinvalid2 = dialog.findViewById(R.id.edt_invalidAns2);
        edtinvalid3 = dialog.findViewById(R.id.edt_invalidAns3);
        txtmain.setText(type);
        if (range == 2) {
            valid.setVisibility(View.VISIBLE);
            tiv1.setVisibility(View.VISIBLE);
            tiv2.setVisibility(View.GONE);
            tiv3.setVisibility(View.GONE);
        } else {
            valid.setVisibility(View.VISIBLE);
            tiv1.setVisibility(View.VISIBLE);
            tiv2.setVisibility(View.VISIBLE);
            tiv3.setVisibility(View.VISIBLE);
        }
        edtvalid.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                valid.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        edtinvalid1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tiv1.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        edtinvalid2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tiv2.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        edtinvalid3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tiv3.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                anslist.clear();

                if (range == 2) {
                    if (edtvalid.getText().toString().equals("")) {
                        valid.setErrorEnabled(true);
                        valid.setError("Enter Valid Answer");
                    } else if (edtinvalid1.getText().toString().equals("")) {
                        tiv1.setErrorEnabled(true);
                        tiv1.setError("Enter Invalid Answer");
                    } else {
                        addans(edtvalid.getText().toString(), true);
                        addans(edtinvalid1.getText().toString(), false);
                        trueans = edtvalid.getText().toString();
                        dialog.dismiss();
                    }
                } else {
                    if (edtvalid.getText().toString().equals("")) {
                        valid.setErrorEnabled(true);
                        valid.setError("Enter Valid Answer");
                    } else if (edtinvalid1.getText().toString().equals("")) {
                        tiv1.setErrorEnabled(true);
                        tiv1.setError("Enter Invalid Answer");
                    } else if (edtinvalid2.getText().toString().equals("")) {
                        tiv2.setErrorEnabled(true);
                        tiv2.setError("Enter Invalid Answer");
                    } else if (edtinvalid3.getText().toString().equals("")) {
                        tiv3.setErrorEnabled(true);
                        tiv3.setError("Enter Invalid Answer");
                    } else {
                        addans(edtvalid.getText().toString(), true);
                        addans(edtinvalid1.getText().toString(), false);
                        addans(edtinvalid2.getText().toString(), false);
                        addans(edtinvalid3.getText().toString(), false);
                        trueans = edtvalid.getText().toString();
                        dialog.dismiss();
                    }
                }
            }
        });
        dialog.show();
    }

    public void showSuccessDialog(String main, String Msg) {

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_layout);
        TextView txtmain = dialog.findViewById(R.id.txtmain);
        TextView txtmsg = dialog.findViewById(R.id.text_dialog);
        ImageView btnok = dialog.findViewById(R.id.btn_dialog);
        GifImageView gimg = dialog.findViewById(R.id.anim_tryagain);
        gimg.setImageResource(R.drawable.success_anim);
        txtmain.setVisibility(View.GONE);
        txtmain.setText(main);
        txtmsg.setText(Msg);
        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                DeleteImage();
                finish();
            }
        });
        dialog.show();
    }

    private void DeleteImage() {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + File.separator + "Puzzle" + File.separator + "temp.jpg");
        File fileDelete = new File(file.getAbsolutePath());
        if (fileDelete.exists()) {
            fileDelete.delete();
        }
    }
}