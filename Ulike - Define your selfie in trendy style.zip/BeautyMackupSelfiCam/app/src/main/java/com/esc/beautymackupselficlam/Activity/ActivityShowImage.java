package com.esc.beautymackupselficlam.Activity;

import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.esc.beautymackupselficlam.utils.Utils;
import com.esc.beautymackupselficlam.R;
import com.esc.beautymackupselficlam.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.io.IOException;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityShowImage extends AppCompatActivity {
    ImageView img;
    ImageView delete;
    int pos;
    ImageView set_as;
    ImageView share;
    ImageView ivBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_image);
        loadAd();
        pos = getIntent().getIntExtra("position", 0);
        BindView();
        initView();
    }

    private void initView() {

        img.setImageURI(Uri.parse((String) Utils.Glob.IMAGEALLARY.get(pos)));

        delete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                final Dialog dial = new Dialog(ActivityShowImage.this,
                        R.style.Theme_AppCompat);
                dial.requestWindowFeature(1);
                dial.setContentView(R.layout.delete_confirmation);
                dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dial.setCanceledOnTouchOutside(true);
                ((TextView) dial.findViewById(R.id.delete_yes))
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                File fD = new File((String) Utils.Glob.IMAGEALLARY
                                        .get(pos));
                                if (fD.exists()) {
                                    fD.delete();
                                }
                                Utils.Glob.IMAGEALLARY.remove(pos);
                                ActivityShowImage.this
                                        .sendBroadcast(new Intent(Intent.ACTION_SEND,
                                                Uri.fromFile(new File(String
                                                        .valueOf(fD)))));

                                if (Utils.Glob.IMAGEALLARY.size() == 0) {
                                    Toast.makeText(ActivityShowImage.this,
                                            "No Image Found..", Toast.LENGTH_SHORT).show();
                                }
                                dial.dismiss();
                                finish();

                            }
                        });
                ((TextView) dial.findViewById(R.id.delete_no))
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                dial.dismiss();
                            }
                        });
                dial.show();
            }
        });
        set_as.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                ActivityShowImage.this.setWallpaper(
                        "",
                        (String) Utils.Glob.IMAGEALLARY.get(pos));
            }
        });
        share.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("file://"
                        + ((String) Utils.Glob.IMAGEALLARY.get(pos)));
                Intent share = new Intent(Intent.ACTION_SEND);
                share.putExtra("android.intent.extra.STREAM", uri);
                share.setType("image/*");
                share.addFlags(1);
                share.putExtra("android.intent.extra.TEXT",
                        "created by : "
                                + ActivityShowImage.this.getPackageName());
                ActivityShowImage.this.startActivity(Intent.createChooser(
                        share, "Share image File"));
            }
        });
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.iv_back;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    startActivity(new Intent(ActivityShowImage.this, MyCreationActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    finish();
                }
            }
        });

    }

    private void BindView() {
        img = (ImageView) findViewById(R.id.final_img);
        set_as = (ImageView) findViewById(R.id.img_setas);
        share = (ImageView) findViewById(R.id.img_share);
        delete = (ImageView) findViewById(R.id.img_delete);
        ivBack = (ImageView) findViewById(R.id.iv_back);
    }

    public void onBackPressed() {
            startActivity(new Intent(ActivityShowImage.this, MyCreationActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            finish();
    }


    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {
        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(ActivityShowImage.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.iv_back:
                        startActivity(new Intent(ActivityShowImage.this, MyCreationActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ActivityShowImage.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    private void setWallpaper(String diversity, String s) {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int height = metrics.heightPixels;
        int width = metrics.widthPixels;
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            wallpaperManager.setBitmap(BitmapFactory.decodeFile(s, options));
            wallpaperManager.suggestDesiredDimensions(width / 2, height / 2);
            Toast.makeText(this, "Wallpaper Set Sucessfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
