package com.kotlinz.videoCollage.textmodule;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;

import java.util.ArrayList;

public class TextRelativeDraw extends View {
    private Context context;
    int progress = 0;
    RelativeLayout rel_artv;
    int x1;
    int x10;
    int x11;
    int x12;
    int x13;
    int x14;
    int x15;
    int x16;
    int x17;
    int x18;
    int x19;
    int x2;
    int x20;
    int x21;
    int x22;
    int x23;
    int x24;
    int x25;
    int x26;
    int x27;
    int x28;
    int x29;
    int x3;
    int x30;
    int x31;
    int x32;
    int x33;
    int x34;
    int x35;
    int x36;
    int x37;
    int x38;
    int x39;
    int x4;
    int x40;
    int x41;
    int x42;
    int x43;
    int x44;
    int x45;
    int x46;
    int x47;
    int x48;
    int x49;
    int x5;
    int x50;
    int x51;
    int x52;
    int x53;
    int x54;
    int x55;
    int x56;
    int x57;
    int x58;
    int x59;
    int x6;
    int x60;
    int x61;
    int x62;
    int x63;
    int x64;
    int x65;
    int x66;
    int x67;
    int x68;
    int x69;
    int x7;
    int x70;
    int x71;
    int x72;
    int x73;
    int x74;
    int x75;
    int x76;
    int x77;
    int x78;
    int x79;
    int x8;
    int x80;
    int x81;
    int x9;
    int y1;
    int y10;
    int y11;
    int y12;
    int y13;
    int y14;
    int y15;
    int y16;
    int y17;
    int y18;
    int y19;
    int y2;
    int y20;
    int y21;
    int y22;
    int y23;
    int y24;
    int y25;
    int y26;
    int y27;
    int y28;
    int y29;
    int y3;
    int y30;
    int y31;
    int y32;
    int y33;
    int y34;
    int y35;
    int y36;
    int y37;
    int y38;
    int y39;
    int y4;
    int y40;
    int y41;
    int y42;
    int y43;
    int y44;
    int y45;
    int y46;
    int y47;
    int y48;
    int y49;
    int y5;
    int y50;
    int y51;
    int y52;
    int y53;
    int y54;
    int y55;
    int y56;
    int y57;
    int y58;
    int y59;
    int y6;
    int y60;
    int y61;
    int y62;
    int y63;
    int y64;
    int y65;
    int y66;
    int y67;
    int y68;
    int y69;
    int y7;
    int y70;
    int y71;
    int y72;
    int y73;
    int y74;
    int y75;
    int y76;
    int y77;
    int y78;
    int y79;
    int y8;
    int y80;
    int y81;
    int y9;

    public TextRelativeDraw(Context context, RelativeLayout relativeLayout) {
        super(context);
        this.context = context;
        this.rel_artv = relativeLayout;
        init(context);
    }

    public void init(Context context) {
        this.context = context;
    }

    public void setTextCurveRotateProg(int i) {
        this.progress = i;
        invalidate();
    }

    public void onDraw(Canvas canvas) {
        if (this.rel_artv != null) {
            Paint paint = new Paint();
            paint.setColor(-16711936);
            Bitmap createBitmap = Bitmap.createBitmap(this.rel_artv.getWidth(), this.rel_artv.getHeight(), Config.ARGB_8888);
            this.rel_artv.draw(new Canvas(createBitmap));
            int width = createBitmap.getWidth();
            int height = createBitmap.getHeight();
            int i = width / 8;
            int i2 = height / 8;
            this.x1 = 0;
            this.y1 = 0;
            int i3 = 0;
            int i4 = (i * 1) + 0;
            this.x2 = i4;
            this.y2 = 0;
            int i5 = (i * 2) + 0;
            this.x3 = i5;
            this.y3 = 0;
            int i6 = (i * 3) + 0;
            this.x4 = i6;
            this.y4 = 0;
            int i7 = (i * 4) + 0;
            this.x5 = i7;
            this.y5 = 0;
            int i8 = (i * 5) + 0;
            this.x6 = i8;
            this.y6 = 0;
            int i9 = (i * 6) + 0;
            this.x7 = i9;
            this.y7 = 0;
            i = (i * 7) + 0;
            this.x8 = i;
            this.y8 = 0;
            width += 0;
            this.x9 = width;
            this.y9 = 0;
            this.x10 = 0;
            int i10 = i2 + 0;
            this.y10 = i10;
            this.x11 = i4;
            this.y11 = i10;
            this.x12 = i5;
            this.y12 = i10;
            this.x13 = i6;
            this.y13 = i10;
            this.x14 = i7;
            this.y14 = i10;
            this.x15 = i8;
            this.y15 = i10;
            this.x16 = i9;
            this.y16 = i10;
            this.x17 = i;
            this.y17 = i10;
            this.x18 = width;
            this.y18 = i10;
            this.x19 = 0;
            i10 = (i2 * 2) + 0;
            this.y19 = i10;
            this.x20 = i4;
            this.y20 = i10;
            this.x21 = i5;
            this.y21 = i10;
            this.x22 = i6;
            this.y22 = i10;
            this.x23 = i7;
            this.y23 = i10;
            this.x24 = i8;
            this.y24 = i10;
            this.x25 = i9;
            this.y25 = i10;
            this.x26 = i;
            this.y26 = i10;
            this.x27 = width;
            this.y27 = i10;
            this.x28 = 0;
            i10 = (i2 * 3) + 0;
            this.y28 = i10;
            this.x29 = i4;
            this.y29 = i10;
            this.x30 = i5;
            this.y30 = i10;
            this.x31 = i6;
            this.y31 = i10;
            this.x32 = i7;
            this.y32 = i10;
            this.x33 = i8;
            this.y33 = i10;
            this.x34 = i9;
            this.y34 = i10;
            this.x35 = i;
            this.y35 = i10;
            this.x36 = width;
            this.y36 = i10;
            this.x37 = 0;
            i10 = (i2 * 4) + 0;
            this.y37 = i10;
            this.x38 = i4;
            this.y38 = i10;
            this.x39 = i5;
            this.y39 = i10;
            this.x40 = i6;
            this.y40 = i10;
            this.x41 = i7;
            this.y41 = i10;
            this.x42 = i8;
            this.y42 = i10;
            this.x43 = i9;
            this.y43 = i10;
            this.x44 = i;
            this.y44 = i10;
            this.x45 = width;
            this.y45 = i10;
            this.x46 = 0;
            i10 = (i2 * 5) + 0;
            this.y46 = i10;
            this.x47 = i4;
            this.y47 = i10;
            this.x48 = i5;
            this.y48 = i10;
            this.x49 = i6;
            this.y49 = i10;
            this.x50 = i7;
            this.y50 = i10;
            this.x51 = i8;
            this.y51 = i10;
            this.x52 = i9;
            this.y52 = i10;
            this.x53 = i;
            this.y53 = i10;
            this.x54 = width;
            this.y54 = i10;
            this.x55 = 0;
            i10 = (i2 * 6) + 0;
            this.y55 = i10;
            this.x56 = i4;
            this.y56 = i10;
            this.x57 = i5;
            this.y57 = i10;
            this.x58 = i6;
            this.y58 = i10;
            this.x59 = i7;
            this.y59 = i10;
            this.x60 = i8;
            this.y60 = i10;
            this.x61 = i9;
            this.y61 = i10;
            this.x62 = i;
            this.y62 = i10;
            this.x63 = width;
            this.y63 = i10;
            this.x64 = 0;
            i2 = (i2 * 7) + 0;
            this.y64 = i2;
            this.x65 = i4;
            this.y65 = i2;
            this.x66 = i5;
            this.y66 = i2;
            this.x67 = i6;
            this.y67 = i2;
            this.x68 = i7;
            this.y68 = i2;
            this.x69 = i8;
            this.y69 = i2;
            this.x70 = i9;
            this.y70 = i2;
            this.x71 = i;
            this.y71 = i2;
            this.x72 = width;
            this.y72 = i2;
            this.x73 = 0;
            height += 0;
            this.y73 = height;
            this.x74 = i4;
            this.y74 = height;
            this.x75 = i5;
            this.y75 = height;
            this.x76 = i6;
            this.y76 = height;
            this.x77 = i7;
            this.y77 = height;
            this.x78 = i8;
            this.y78 = height;
            this.x79 = i9;
            this.y79 = height;
            this.x80 = i;
            this.y80 = height;
            this.x81 = width;
            this.y81 = height;
            i2 = width;
            Canvas canvas2 = canvas;
            Paint paint2 = paint;
            Path mPath = mPath(0, 0, i2, 0, this.progress, canvas2, paint2);
            Path mPath2 = mPath(this.x10, this.y10, this.x18, this.y18, this.progress, canvas2, paint2);
            Path mPath3 = mPath(this.x19, this.y19, this.x27, this.y27, this.progress, canvas2, paint2);
            Path mPath4 = mPath(this.x28, this.y28, this.x36, this.y36, this.progress, canvas2, paint2);
            Path mPath5 = mPath(this.x37, this.y37, this.x45, this.y45, this.progress, canvas2, paint2);
            Path mPath6 = mPath(this.x46, this.y46, this.x54, this.y54, this.progress, canvas2, paint2);
            Path mPath7 = mPath(this.x55, this.y55, this.x63, this.y63, this.progress, canvas2, paint2);
            Path mPath8 = mPath(this.x64, this.y64, this.x72, this.y72, this.progress, canvas2, paint2);
            Path mPath9 = mPath(this.x73, this.y73, this.x81, this.y81, this.progress, canvas2, paint2);
            Path[] pathArr = new Path[]{mPath, mPath2, mPath3, mPath4, mPath5, mPath6, mPath7, mPath8, mPath9};
            ArrayList arrayList = new ArrayList();
            for (i10 = 0; i10 < 9; i10++) {
                PathMeasure pathMeasure = new PathMeasure(pathArr[i10], false);
                float[] fArr = new float[]{0.0f, 0.0f};
                for (float f = 0.0f; f <= 1.0f; f += 0.125f) {
                    pathMeasure.getPosTan(pathMeasure.getLength() * f, fArr, null);
                    arrayList.add(Float.valueOf(fArr[0]));
                    arrayList.add(Float.valueOf(fArr[1]));
                }
            }
            height = arrayList.size();
            float[] fArr2 = new float[height];
            while (i3 < height) {
                fArr2[i3] = ((Float) arrayList.get(i3)).floatValue();
                i3++;
            }
            canvas.drawBitmapMesh(createBitmap, 8, 8, fArr2, 0, null, 0, null);
            return;
        }
        Log.e("not show", "visiblity");
    }

    public int getClosestResampleSize(int i, int i2, int i3) {
        i = Math.max(i, i2);
        int i4 = 1;
        while (i4 < 20) {
            if (i4 * i3 > i) {
                i4--;
                break;
            }
            i4++;
        }
        return i4 > 0 ? i4 : 1;
    }

    public Path mPath(int i, int i2, int i3, int i4, int i5, Canvas canvas, Paint paint) {
        Path path = new Path();
        int i6 = ((i3 - i) / 2) + i;
        int i7 = ((i4 - i2) / 2) + i2;
        double toRadians = Math.toRadians((Math.atan2((double) ((float) (i7 - i2)), (double) ((float) (i6 - i))) * 57.29577951308232d) - 90.0d);
        double d = (double) i5;
        float cos = (float) (((double) i6) + (Math.cos(toRadians) * d));
        float sin = (float) (((double) i7) + (d * Math.sin(toRadians)));
        float f = (float) i;
        float f2 = (float) i2;
        path.moveTo(f, f2);
        path.cubicTo(f, f2, cos, sin, (float) i3, (float) i4);
        return path;
    }

    public int dpToPx(Context context, int i) {
        float f = (float) i;
        context.getResources();
        return (int) (f * Resources.getSystem().getDisplayMetrics().density);
    }

    public static Bitmap resizeBitmap(Bitmap bitmap, int i, int i2) {
        float f = (float) i;
        float f2 = (float) i2;
        float width = (float) bitmap.getWidth();
        float height = (float) bitmap.getHeight();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(f);
        String str = "  ";
        stringBuilder.append(str);
        stringBuilder.append(f2);
        stringBuilder.append("  and  ");
        stringBuilder.append(width);
        stringBuilder.append(str);
        stringBuilder.append(height);
        String str2 = "testings";
        Log.i(str2, stringBuilder.toString());
        float f3 = width / height;
        float f4 = height / width;
        String str3 = "  if (he > hr) ";
        String str4 = " in else ";
        StringBuilder stringBuilder2;
        StringBuilder stringBuilder3;
        if (width > f) {
            f4 *= f;
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("if (wd > wr) ");
            stringBuilder2.append(f);
            stringBuilder2.append(str);
            stringBuilder2.append(f4);
            Log.i(str2, stringBuilder2.toString());
            if (f4 > f2) {
                f = f2 * f3;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str3);
                stringBuilder2.append(f);
                stringBuilder2.append(str);
                stringBuilder2.append(f2);
                Log.i(str2, stringBuilder2.toString());
                return Bitmap.createScaledBitmap(bitmap, (int) f, (int) f2, false);
            }
            stringBuilder3 = new StringBuilder();
            stringBuilder3.append(str4);
            stringBuilder3.append(f);
            stringBuilder3.append(str);
            stringBuilder3.append(f4);
            Log.i(str2, stringBuilder3.toString());
        } else {
            if (height > f2) {
                f3 *= f2;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str3);
                stringBuilder2.append(f3);
                stringBuilder2.append(str);
                stringBuilder2.append(f2);
                Log.i(str2, stringBuilder2.toString());
                if (f3 > f) {
                    f2 = f * f4;
                } else {
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append(str4);
                    stringBuilder4.append(f3);
                    stringBuilder4.append(str);
                    stringBuilder4.append(f2);
                    Log.i(str2, stringBuilder4.toString());
                    f = f3;
                }
            } else if (f3 > 0.75f) {
                f2 = f * f4;
                Log.i(str2, " if (rat1 > .75f) ");
            } else if (f4 > 1.5f) {
                f = f2 * f3;
                Log.i(str2, " if (rat2 > 1.5f) ");
            } else {
                f4 *= f;
                Log.i(str2, str4);
                if (f4 > f2) {
                    f = f2 * f3;
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str3);
                    stringBuilder2.append(f);
                    stringBuilder2.append(str);
                    stringBuilder2.append(f2);
                    Log.i(str2, stringBuilder2.toString());
                } else {
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(str4);
                    stringBuilder3.append(f);
                    stringBuilder3.append(str);
                    stringBuilder3.append(f4);
                    Log.i(str2, stringBuilder3.toString());
                }
            }
            return Bitmap.createScaledBitmap(bitmap, (int) f, (int) f2, false);
        }
        f2 = f4;
        return Bitmap.createScaledBitmap(bitmap, (int) f, (int) f2, false);
    }
}
