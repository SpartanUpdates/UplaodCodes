package game.kidspop.gk.quiz.info;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class QuizPlayWinLossActivity extends AppCompatActivity {
  String mPlayerName;
  int mQL;
  String mWinningAmt;
  TextView mbtnBack;
  TextView mbtnQuizTryAgain;
  boolean misQuizWon = false;

  public QuizPlayWinLossActivity() {
    String str = "";
    this.mPlayerName = str;
    this.mWinningAmt = str;
    this.mQL = 1;
  }

  public void onCreate(Bundle bundle) {
    super.onCreate(bundle);
    requestWindowFeature(1);
    getSupportActionBar().hide();
    getWindow().setFlags(1024, 1024);
    setContentView((int) R.layout.activity_quiz_play_win_loss);
    this.mbtnBack = (TextView) findViewById(R.id.ibtnBack);
    this.mbtnQuizTryAgain = (TextView) findViewById(R.id.ibtnQuizTryAgain);
    ImageView imageView = (ImageView) findViewById(R.id.iivTrophyImg);
    TextView textView = (TextView) findViewById(R.id.itvWinningDesc);
    TextView textView2 = (TextView) findViewById(R.id.itvWinnerName);
    TextView textView3 = (TextView) findViewById(R.id.itvWinningAmt);
    Bundle extras = getIntent().getExtras();
    this.mQL = extras.getInt("QL");
    this.mPlayerName = extras.getString("PlayerName");
    this.mWinningAmt = extras.getString("WinningAmt");
    this.misQuizWon = extras.getBoolean("isQuizWon");
    textView2.setText(this.mPlayerName);
    textView3.setText(this.mWinningAmt);
    if (this.misQuizWon) {
      textView.setText("Congratulations!, You have Won the Quiz.");
    } else {
      int i = this.mQL;
      if (i == 1) {
        imageView.setImageResource(R.drawable.coins_bag);
      } else if (i > 1 && i < 20) {
        imageView.setImageResource(R.drawable.coins_bag);
        int i2 = this.mQL;
        StringBuilder stringBuilder;
        if (i2 > 10 && i2 <= 15) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Wow!, Very well played.\n");
          stringBuilder.append(textView.getText().toString());
          textView.setText(stringBuilder.toString());
        } else if (this.mQL > 15) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Superb!, Very well played.\n");
          stringBuilder.append(textView.getText().toString());
          textView.setText(stringBuilder.toString());
        }
      }
    }
    prc_onClick_PlayQuiz();
    prc_onClick_Back();
  }

  private void prc_onClick_Back() {
    this.mbtnBack.setOnClickListener(new OnClickListener() {
      public void onClick(View view) {
        QuizPlayWinLossActivity.this.finish();
      }
    });
  }

  private void prc_onClick_PlayQuiz() {
    this.mbtnQuizTryAgain.setOnClickListener(new OnClickListener() {
      public void onClick(View view) {
        QuizPlayWinLossActivity.this.startActivity(new Intent(QuizPlayWinLossActivity.this.getApplicationContext(), QuizPlayActivity.class));
        QuizPlayWinLossActivity.this.finish();
      }
    });
  }
}