package com.esc.flashlight.util;

import android.content.Context;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.hardware.Camera.Parameters;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build.VERSION;

import com.esc.flashlight.App.APP;
import com.esc.flashlight.appwidget.FAAppWidget;
import com.esc.flashlight.flashlight.FlashService;

import java.util.List;

public class FALib {
    public static final int AVAILABLE = 1;
    public static final int INIT_FAILED = 0;
    public static final int NOT_AVAILABLE = 3;
    public static final int NOT_TORCH = 2;

    public static void sendBroadcastChangedTotallyUseState(Context context) {
        Intent intent = new Intent();
        intent.setAction(FAAppWidget.ACTION_CHANGED_TOTALLY_USE_STATE);
        context.sendBroadcast(intent);
    }

    public static void sendBroadcastFlashActionIntent(Context context, String str) {
        Intent intent = new Intent();
        intent.setAction(str);
        FlashService.runIntentInService(context, intent);
    }

    public static int checkFlashMode() {
        try {
            Camera open = Camera.open();
            if (open == null) {
                return 0;
            }
            Parameters parameters = open.getParameters();
            if (parameters == null) {
                open.release();
                return 3;
            }
            List supportedFlashModes = parameters.getSupportedFlashModes();
            open.release();
            if (supportedFlashModes == null) {
                return 3;
            }
            return supportedFlashModes.contains("torch") ? 1 : 2;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static int getFrontFlashableState(PrefManager prefManager) {
        if (VERSION.SDK_INT < 9) {
            return 0;
        }
        if (VERSION.SDK_INT >= 23) {
            CameraManager cameraManager = (CameraManager) APP.APP.getSystemService("camera");
            try {
                String[] cameraIdList = cameraManager.getCameraIdList();
                int length = cameraIdList.length;
                int i = 0;
                while (i < length) {
                    String str = cameraIdList[i];
                    if (((Integer) cameraManager.getCameraCharacteristics(str).get(CameraCharacteristics.LENS_FACING)).intValue() != 0) {
                        i++;
                    } else if (!((Boolean) cameraManager.getCameraCharacteristics(str).get(CameraCharacteristics.FLASH_INFO_AVAILABLE)).booleanValue()) {
                        return 0;
                    } else {
                        prefManager.setFrontCameraId(Integer.valueOf(str).intValue());
                        return 1;
                    }
                }
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
            return 0;
        }
        int numberOfCameras = Camera.getNumberOfCameras();
        int i2 = 0;
        while (i2 < numberOfCameras) {
            CameraInfo cameraInfo = new CameraInfo();
            try {
                Camera.getCameraInfo(i2, cameraInfo);
                if (cameraInfo.facing == 1) {
                    try {
                        Camera open = Camera.open(i2);
                        if (open == null) {
                            return 0;
                        }
                        Parameters parameters = open.getParameters();
                        if (parameters == null) {
                            open.release();
                            return 0;
                        }
                        List supportedFlashModes = parameters.getSupportedFlashModes();
                        open.release();
                        if (supportedFlashModes != null) {
                            if (!supportedFlashModes.contains("torch")) {
                                return 0;
                            }
                            prefManager.setFrontCameraId(i2);
                            return 1;
                        }
                    } catch (Exception e2) {
                        e2.printStackTrace();
                        return 0;
                    }
                }
                i2++;
            } catch (RuntimeException e3) {
                e3.printStackTrace();
            }
        }
        return 0;
    }
}
