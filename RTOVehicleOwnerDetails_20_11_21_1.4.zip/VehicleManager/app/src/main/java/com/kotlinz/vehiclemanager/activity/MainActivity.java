package com.kotlinz.vehiclemanager.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.fuel.model.FuelModel;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.pref.EPreferences;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.activity.RtoPreperationActivity;
import com.kotlinz.vehiclemanager.utils.ViewDialog;
import com.kotlinz.vehiclemanager.vehicledetails.loancalculator.LoanCalculatoractivity;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.famousperson.activity.FamousPersonListActivity;
import com.kotlinz.vehiclemanager.fuel.activity.FuelCityStateActivity;
import com.kotlinz.vehiclemanager.history.Activity.HistoryTabLayoutActivity;
import com.kotlinz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.kotlinz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.activity.RtoOfficeInfoActivity;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.activity.RtoQuestionActivity;
import com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.utils.Utils;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.activity.VehicleExpenseActivity;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.activity.VehicleMileageActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import static com.kotlinz.vehiclemanager.R.*;
import static com.kotlinz.vehiclemanager.R.drawable.*;

import org.jetbrains.annotations.NotNull;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private final Activity activity = MainActivity.this;

    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle drawerToggle;
    private Toolbar toolbar;
    private ImageView ownerInfo_iv, license_iv, rtoOfficeInfo_iv, vehicleExpense_iv, vehicleMileage_iv, mrPerfact_iv, dancer_iv, singer_iv, actor_iv, politician_iv, sportsMan_iv, actress_iv, loan_calculator_iv, near_petrol_pump_iv, examPreperation_iv, rtoExam_iv, near_autogas_iv, near_charging_station_iv;
    private TextView tv_city, tv_state, tv_petrolprice, tv_petrodiff, tv_dieselprice, tv_dieseldiff, petrol, diesel, tv_title;
    private Button btn_changeCity;
    private LinearLayout ll_ownerInfo, ll_vehicleLicense, ll_fuel, ll_rtoofficeInfo, ll_vehicleExpense, ll_vehicleMileage, ll_near_petrol_pump, ll_near_autogas, ll_near_charging_station;
    private LinearLayout ll_MrPerfect, ll_dancer, ll_actor, ll_politician, ll_sportsmen, ll_actress, ll_singer;
    private String cityName, stateName, currentDate, data;
    private RtoDetailsInterface rtoDetailsInterface;
    private LinearLayout ll_progress, ll_fuel_theme, ll_rtoOwnerDetails, ll_rtoDetails, ll_vehicleDetails, ll_famousPerson, ll_loan_calculator, ll_others, ll_exam_preperation, ll_rto_exam;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private SharedPreferences sharedPreferences2;
    private SharedPreferences.Editor editor2;

    private FirebaseRemoteConfig firebaseRemoteConfig;

    private EPreferences ePreferences;


    private int id2;
    public GGInterstitialAd interstitialAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);
        GGAppOpenAds.show();
        PutAnalyticsEvent();
        fetchVersion();
        InterAds();
        ePreferences = EPreferences.getInstance(this);
        Intent intent = getIntent();
        cityName = intent.getStringExtra("cityname");
        stateName = intent.getStringExtra("statename");
        data = intent.getStringExtra("data");
        rtoDetailsInterface = RtoDetailsApiClient.getOwnerDetailsFromPaidApi().create(RtoDetailsInterface.class);
        sharedPreferences = getSharedPreferences("CurrentFuelData", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        sharedPreferences2 = getApplicationContext().getSharedPreferences("stateName", Context.MODE_PRIVATE);
        editor2 = sharedPreferences2.edit();
        toolbar = findViewById(id.toolbar);
        setSupportActionBar(toolbar);
        BindView();
        class Navigation implements NavigationView.OnNavigationItemSelectedListener {
            Navigation() {
            }

            @SuppressLint("WrongConstant")
            public boolean onNavigationItemSelected(MenuItem item) {
                drawerLayout.closeDrawers();
                switch (item.getItemId()) {

                    case id.menu_share:
                        Intent share = new Intent(Intent.ACTION_SEND);
                        share.setType("text/plain");
                        share.putExtra(Intent.EXTRA_TEXT, getResources().getString(string.share_msg) + getPackageName());
                        startActivity(Intent.createChooser(share, "Share Via"));
                        return true;

                    case id.menu_rateus:
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse(getResources().getString(string.rate_us_url)
                                            + getPackageName())));
                            return true;
                        } catch (ActivityNotFoundException e) {
                            Toast.makeText(MainActivity.this, "You don't have Google Play installed",
                                    Toast.LENGTH_SHORT).show();
                            return true;
                        }

                    case id.menu_feedback:
                        Intent feedback = new Intent(Intent.ACTION_SEND);
                        feedback.setType("message/rfc822");
                        feedback.putExtra(Intent.EXTRA_EMAIL, new String[]{getResources().getString(string.feedback_email)});
                        feedback.putExtra(Intent.EXTRA_SUBJECT, "Subject");
                        feedback.setPackage("com.google.android.gm");
                        if (feedback.resolveActivity(getPackageManager()) != null)
                            startActivity(feedback);
                        else
                            Toast.makeText(MainActivity.this, "Gmail App is not installed", Toast.LENGTH_SHORT).show();
                        return true;

                    case id.menu_privacy:
                        try {
                            Intent intent1 = new Intent(Intent.ACTION_VIEW);
                            intent1.setData(Uri.parse(getResources().getString(string.privacy_policy_url)));
                            startActivity(intent1);
                            return true;
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "No internet connection", Toast.LENGTH_SHORT).show();
                            return true;
                        }

                    case id.nightMode:
                        changeColorDraewerIcon();
                        drawerLayout.closeDrawer(Gravity.START, false);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                MenuItem menuItem = navigationView.getMenu().findItem(id.nightMode);
                                try {
                                    if (menuItem.getTitle().equals("Night Mode")) {
                                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                                        AppCompatDelegate.getDefaultNightMode();
                                        menuItem.setTitle("Day Mode");
                                        editor.putString("mode", "nightMode");
                                        editor.commit();
                                        setupNightMode();
                                    } else {
                                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                                        AppCompatDelegate.getDefaultNightMode();
                                        menuItem.setTitle("Night Mode");
                                        editor.putString("mode", "dayMode");
                                        editor.commit();
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    default:
                        return false;
                }
            }
        }

        navigationView.setNavigationItemSelectedListener(new Navigation());
        drawerToggle = new ActionBarDrawerToggle(this, this.drawerLayout, toolbar,
                string.drawer_open, string.drawer_close);
        drawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);

                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });
        this.drawerLayout.setDrawerListener(drawerToggle);
        drawerToggle.syncState();
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        drawerToggle.setDrawerIndicatorEnabled(false);
        drawerToggle.setHomeAsUpIndicator(ic_drawer_menu);

        if (cityName == null) {
            cityName = "Ahmedabad";
        }
        if (stateName == null) {
            stateName = "Gujarat";
        }

        if (Utils.isOnline(MainActivity.this)) {
            SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
            currentDate = df.format(Calendar.getInstance().getTime());

            String sCurrentDate = sharedPreferences.getString("Date", "");

            if (data != null) {
                getFuelPrice();
            } else {
                if (currentDate.equals(sCurrentDate)) {
                    ll_progress.setVisibility(View.GONE);
                    ll_fuel.setVisibility(View.VISIBLE);
                    tv_petrolprice.setText(sharedPreferences.getString("petrolPrice", ""));
                    tv_dieselprice.setText(sharedPreferences.getString("dieselPrice", ""));
                    tv_petrodiff.setText(sharedPreferences.getString("petrolDiff", ""));
                    tv_dieseldiff.setText(sharedPreferences.getString("dieselDiff", ""));
                    tv_state.setText(sharedPreferences.getString("state", ""));
                    tv_city.setText(sharedPreferences.getString("city", ""));
                } else {
                    stateName = sharedPreferences2.getString("stateName", "Gujarat");
                    cityName = sharedPreferences2.getString("cityName", "Ahmedabad");
                    getFuelPrice();
                }
            }
        } else {
            Toast.makeText(this, getResources().getString(string.conne_msg), Toast.LENGTH_SHORT).show();
        }

        FirebaseMessaging.getInstance().subscribeToTopic(sharedPreferences2.getString("cityName", "Ahmedabad"));
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MainActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void fetchVersion() {
        firebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(5)
                .build();
        firebaseRemoteConfig.setConfigSettingsAsync(configSettings);
        firebaseRemoteConfig.fetchAndActivate().addOnCompleteListener(new OnCompleteListener<Boolean>() {
            @Override
            public void onComplete(@NonNull Task<Boolean> task) {
                if (task.isSuccessful()) {
                    final String newVersion = firebaseRemoteConfig.getString("new_version_code");
                    if (Float.valueOf(newVersion) > getCurrentVersionCode()) {
                        ViewDialog viewDialog = new ViewDialog();
                        viewDialog.showDialogForUpdate(MainActivity.this);
                    }
                }
            }
        });
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdClosed() {
                Intent intent;
                switch (id2) {
                    case 1:
                        startActivity(new Intent(MainActivity.this, HistoryTabLayoutActivity.class));
                        break;
                    case 2:
                        Intent intent1 = new Intent(MainActivity.this, FuelCityStateActivity.class);
                        startActivity(intent1);
                        break;
                    case 3:
                        startActivity(new Intent(MainActivity.this, RtoOwnerDetailActivity.class));
                        break;
                  /*  case 4:
                        startActivity(new Intent(MainActivity.this, VehicleLicenseActivity.class));
                        break;*/
                    case 5:
                        startActivity(new Intent(MainActivity.this, RtoOfficeInfoActivity.class));
                        break;
                    case 6:
                        startActivity(new Intent(new Intent(MainActivity.this, VehicleExpenseActivity.class)));
                        break;
                    case 7:
                        startActivity(new Intent(MainActivity.this, RtoPreperationActivity.class));
                        break;
                    case 8:
                        startActivity(new Intent(MainActivity.this, RtoQuestionActivity.class));
                        break;
                    case 9:
                        startActivity(new Intent(MainActivity.this, VehicleMileageActivity.class));
                        break;
                    case 10:
                        intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                        intent.putExtra("categoryname", "Mr.Perfect");
                        startActivity(intent);
                        break;
                    case 11:
                        intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                        intent.putExtra("categoryname", "Dancers");
                        startActivity(intent);
                        break;
                    case 12:
                        intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                        intent.putExtra("categoryname", "Singers");
                        startActivity(intent);
                        break;
                    case 13:
                        intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                        intent.putExtra("categoryname", "Actors");
                        startActivity(intent);
                        break;
                    case 14:
                        intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                        intent.putExtra("categoryname", "Politicians");
                        startActivity(intent);
                        break;
                    case 15:
                        intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                        intent.putExtra("categoryname", "Sports Person");
                        startActivity(intent);
                        break;
                    case 16:
                        intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                        intent.putExtra("categoryname", "Actresses");
                        startActivity(intent);
                        break;
                    case 17:
                        startActivity(new Intent(MainActivity.this, LoanCalculatoractivity.class));
                        break;
                    case 18:
                        goToNearPetrolPump();
                        break;
                    case 19:
                        gotoNearAutoGas();
                        break;
                    case 20:
                        gotoNearChargingStation();
                        break;
                }
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }


    @Override
    protected void onNightModeChanged(int mode) {
        super.onNightModeChanged(mode);
    }

    private void changeColorDraewerIcon() {

        MenuItem menuItem = navigationView.getMenu().findItem(id.menu_share);
        Drawable drawable = menuItem.getIcon();
        drawable.setColorFilter(getResources().getColor(color.orange), PorterDuff.Mode.SRC_IN);

        MenuItem menuItem2 = navigationView.getMenu().findItem(id.menu_rateus);
        Drawable drawable2 = menuItem2.getIcon();
        drawable2.setColorFilter(getResources().getColor(color.orange), PorterDuff.Mode.SRC_IN);

        MenuItem menuItem3 = navigationView.getMenu().findItem(id.menu_feedback);
        Drawable drawable3 = menuItem3.getIcon();
        drawable3.setColorFilter(getResources().getColor(color.orange), PorterDuff.Mode.SRC_IN);

        MenuItem menuItem4 = navigationView.getMenu().findItem(id.menu_privacy);
        Drawable drawable4 = menuItem4.getIcon();
        drawable4.setColorFilter(getResources().getColor(color.orange), PorterDuff.Mode.SRC_IN);

        MenuItem menuItem5 = navigationView.getMenu().findItem(id.nightMode);
        Drawable drawable5 = menuItem5.getIcon();
        drawable5.setColorFilter(getResources().getColor(color.orange), PorterDuff.Mode.SRC_IN);
    }


    @Override
    protected void onStart() {
        super.onStart();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            changeColorDraewerIcon();
            MenuItem menuItem = navigationView.getMenu().findItem(id.nightMode);
            menuItem.setTitle("Day Mode");
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            setupNightMode();
        }

        DarkTheame darkTheame = new DarkTheame(activity);
        if (darkTheame.modeData().equals("nightMode")) {
            changeColorDraewerIcon();
            MenuItem menuItem = navigationView.getMenu().findItem(id.nightMode);
            menuItem.setTitle("Day Mode");
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            setupNightMode();
        }
    }

    private void setupNightMode() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ll_progress.setBackgroundResource(R.drawable.ic_box_shadow_borderbg_dark);
                ll_fuel_theme.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
                ll_rtoOwnerDetails.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
                ownerInfo_iv.setImageResource(R.drawable.ic_ownerdetail_selector_dark);
                license_iv.setImageResource(ic_vehiclelicense_selector_dark);
                ll_rtoDetails.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
                rtoOfficeInfo_iv.setImageResource(ic_rtoofficeinfo_selector_dark);
                ll_vehicleDetails.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
                vehicleExpense_iv.setImageResource(ic_vehicleexpense_selector_dark);
                vehicleMileage_iv.setImageResource(ic_vehiclemileage_selector_dark);
                ll_famousPerson.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
                mrPerfact_iv.setImageResource(ic_mrperfact_selector_dark);
                dancer_iv.setImageResource(ic_dancer_selector_dark);
                singer_iv.setImageResource(ic_singer_selector_dark);
                actor_iv.setImageResource(ic_actor_selector_dark);
                politician_iv.setImageResource(ic_politiciant_selector_dark);
                sportsMan_iv.setImageResource(ic_sportsman_selector_dark);
                actress_iv.setImageResource(ic_actress_selector_dark);
                navigationView.setBackgroundResource(ic_drawer_bg_dark);
                ll_loan_calculator.setBackgroundResource(round_white_shadowbg_dark);
                loan_calculator_iv.setImageResource(ic_loan_calculator_selector_dark);
                ll_others.setBackgroundResource(round_white_shadowbg_dark);
                near_petrol_pump_iv.setImageResource(ic_near_petrol_pump_selector_dark);
                examPreperation_iv.setImageResource(ic_exam_preperation_dark_selector);
                rtoExam_iv.setImageResource(ic_rto_examp_dark_selector);
                tv_title.setTextColor(Color.parseColor("#FFFFFF"));
                near_autogas_iv.setImageResource(ic_near_autogas_selctor_dark);
                near_charging_station_iv.setImageResource(ic_near_charging_station_selector_dark);
            }
        });
    }

    @Override
    protected void onPostResume() {

        super.onPostResume();
    }

    private float getCurrentVersionCode() {
        PackageInfo packageInfo = null;
        try {
            packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return Float.parseFloat(packageInfo.versionName);
    }

    private void BindView() {
        drawerLayout = findViewById(id.drawerlayout);
        navigationView = findViewById(id.navigation_view);

        ll_progress = findViewById(id.ll_progress);
        ll_fuel_theme = findViewById(id.ll_fuel_theme);
        ll_rtoOwnerDetails = findViewById(R.id.ll_rtoOwnerDetails);
        ll_rtoDetails = findViewById(R.id.ll_rtoDetails);
        ll_vehicleDetails = findViewById(R.id.ll_vehicleDetails);
        ll_famousPerson = findViewById(R.id.ll_famousPerson);
        ll_fuel = findViewById(id.ll_fuel);
        btn_changeCity = findViewById(id.btn_changecity);
        tv_city = findViewById(id.tv_city);
        tv_state = findViewById(id.tv_state);
        tv_petrolprice = findViewById(id.tv_petrolprice);
        tv_dieselprice = findViewById(id.tv_dieselprice);
        tv_petrodiff = findViewById(id.tv_petrodiff);
        tv_dieseldiff = findViewById(id.tv_dieseldiff);
        petrol = findViewById(R.id.petrol);
        diesel = findViewById(id.diesel);
        tv_title = findViewById(R.id.tv_title);

        ownerInfo_iv = findViewById(id.ownerInfo_iv);
        license_iv = findViewById(id.license_iv);

        rtoOfficeInfo_iv = findViewById(id.rtoOfficeInfo_iv);
        vehicleExpense_iv = findViewById(id.vehicleExpense_iv);
        vehicleMileage_iv = findViewById(id.vehicleMileage_iv);
        mrPerfact_iv = findViewById(id.mrPerfact_iv);
        dancer_iv = findViewById(id.dancer_iv);
        singer_iv = findViewById(id.singler_iv);
        actor_iv = findViewById(id.actor_iv);
        politician_iv = findViewById(id.politician_iv);
        sportsMan_iv = findViewById(id.sportMan_iv);
        actress_iv = findViewById(id.actress_iv);
        loan_calculator_iv = findViewById(R.id.loan_calculator_iv);
        near_petrol_pump_iv = findViewById(id.near_petrol_pump_iv);
        examPreperation_iv = findViewById(id.examPreperation_iv);
        rtoExam_iv = findViewById(id.rtoExam_iv);
        near_autogas_iv = findViewById(id.nearAutoGas_iv);
        near_charging_station_iv = findViewById(id.nearChargingStation_iv);

        ll_ownerInfo = findViewById(id.ll_ownerInfo);
        ll_vehicleLicense = findViewById(id.ll_vehicleLicense);
        ll_rtoofficeInfo = findViewById(id.ll_rtoofficeInfo);
        ll_vehicleExpense = findViewById(id.ll_vehicleExpense);
        ll_vehicleMileage = findViewById(id.ll_vehicleMileage);
        ll_MrPerfect = findViewById(id.ll_MrPerfect);
        ll_dancer = findViewById(id.ll_dancer);
        ll_singer = findViewById(id.ll_singer);
        ll_actor = findViewById(id.ll_actor);
        ll_actress = findViewById(id.ll_actress);
        ll_sportsmen = findViewById(id.ll_sportsmen);
        ll_politician = findViewById(id.ll_politician);
        ll_loan_calculator = findViewById(id.ll_loan_calculator);
        ll_near_petrol_pump = findViewById(id.ll_near_petrol_pump);
        ll_exam_preperation = findViewById(id.ll_exam_preperation);
        ll_rto_exam = findViewById(id.ll_rtoExam);
        ll_others = findViewById(R.id.ll_others);
        ll_near_autogas = findViewById(id.ll_near_autogas);
        ll_near_charging_station = findViewById(id.ll_near_charging_station);

        btn_changeCity.setOnClickListener(this);
        ll_ownerInfo.setOnClickListener(this);
        ll_vehicleLicense.setOnClickListener(this);
        ll_vehicleExpense.setOnClickListener(this);
        ll_vehicleMileage.setOnClickListener(this);
        ll_rtoofficeInfo.setOnClickListener(this);
        ll_MrPerfect.setOnClickListener(this);
        ll_singer.setOnClickListener(this);
        ll_dancer.setOnClickListener(this);
        ll_politician.setOnClickListener(this);
        ll_actress.setOnClickListener(this);
        ll_actor.setOnClickListener(this);
        ll_sportsmen.setOnClickListener(this);
        ll_loan_calculator.setOnClickListener(this);
        ll_near_petrol_pump.setOnClickListener(this);
        ll_rto_exam.setOnClickListener(this);
        ll_exam_preperation.setOnClickListener(this);
        ll_near_autogas.setOnClickListener(this);
        ll_near_charging_station.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case id.btn_changecity:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 2;
                    interstitialAd.show();
                } else {
                    Intent intent1 = new Intent(MainActivity.this, FuelCityStateActivity.class);
                    startActivity(intent1);
                }
                break;

            case id.ll_ownerInfo:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 3;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(MainActivity.this, RtoOwnerDetailActivity.class));
                }
                break;

            case id.ll_vehicleLicense:
               /* if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 4;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(MainActivity.this, VehicleLicenseActivity.class));
                }*/
                break;

            case id.ll_rtoofficeInfo:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 5;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(MainActivity.this, RtoOfficeInfoActivity.class));
                }
                break;

            case id.ll_vehicleExpense:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 6;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(new Intent(MainActivity.this, VehicleExpenseActivity.class)));
                }
                break;

            case id.ll_vehicleMileage:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 9;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(MainActivity.this, VehicleMileageActivity.class));
                }
                break;

            case id.ll_MrPerfect:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 10;
                    interstitialAd.show();
                } else {
                    intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                    intent.putExtra("categoryname", "Mr.Perfect");
                    startActivity(intent);
                }
                break;

            case id.ll_dancer:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 11;
                    interstitialAd.show();
                } else {
                    intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                    intent.putExtra("categoryname", "Dancers");
                    startActivity(intent);
                }
                break;

            case id.ll_singer:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 12;
                    interstitialAd.show();
                } else {
                    intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                    intent.putExtra("categoryname", "Singers");
                    startActivity(intent);
                }
                break;

            case id.ll_actor:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 13;
                    interstitialAd.show();
                } else {
                    intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                    intent.putExtra("categoryname", "Actors");
                    startActivity(intent);
                }
                break;

            case id.ll_politician:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 14;
                    interstitialAd.show();
                } else {
                    intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                    intent.putExtra("categoryname", "Politicians");
                    startActivity(intent);
                }
                break;

            case id.ll_sportsmen:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 15;
                    interstitialAd.show();
                } else {
                    intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                    intent.putExtra("categoryname", "Sports Person");
                    startActivity(intent);
                }
                break;

            case id.ll_actress:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 16;
                    interstitialAd.show();
                } else {
                    intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
                    intent.putExtra("categoryname", "Actresses");
                    startActivity(intent);
                }
                break;

            case id.ll_loan_calculator:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 17;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(MainActivity.this, LoanCalculatoractivity.class));
                }
                break;

            case id.ll_near_petrol_pump:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 18;
                    interstitialAd.show();
                } else {
                    goToNearPetrolPump();
                }
                break;

            case id.ll_rtoExam:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 8;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(MainActivity.this, RtoQuestionActivity.class));
                }
                break;

            case id.ll_exam_preperation:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 7;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(MainActivity.this, RtoPreperationActivity.class));
                }
                break;

            case id.ll_near_autogas:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 19;
                    interstitialAd.show();
                } else {
                    gotoNearAutoGas();
                }
                break;

            case id.ll_near_charging_station:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 20;
                    interstitialAd.show();
                } else {
                    gotoNearChargingStation();
                }
                break;
        }
    }

    private void gotoNearChargingStation() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:0,0?q=" + "nearBy ev charging station"));
        try {
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void gotoNearAutoGas() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:0,0?q=" + "nearBy Cng Station"));
        try {
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void goToNearPetrolPump() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:0,0?q=" + "nearBy Petrol Pump"));
        try {
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getFuelPrice() {
        Call<FuelModel> call = rtoDetailsInterface.getFuelPrice(String.valueOf(string.app_link), MyApplication.id, cityName);
        call.enqueue(new Callback<FuelModel>() {
            @Override
            public void onResponse(Call<FuelModel> call, Response<FuelModel> response) {
                ll_progress.setVisibility(View.GONE);
                ll_fuel.setVisibility(View.VISIBLE);

                if (response.isSuccessful()) {
                    FuelModel.Response fuelModel = response.body().getResponse();
                    tv_petrolprice.setText(String.valueOf(fuelModel.getPetrolPrice()));
                    tv_dieselprice.setText(String.valueOf(fuelModel.getDieselPrice()));
                    tv_petrodiff.setText(String.valueOf(fuelModel.getPetrolChange()));
                    tv_dieseldiff.setText(String.valueOf(fuelModel.getDieselChange()));
                    tv_state.setText(String.valueOf(stateName));
                    tv_city.setText(cityName);

                    editor.putString("Date", currentDate);
                    editor.putString("state", stateName);
                    editor.putString("city", cityName);
                    editor.putString("petrolPrice", String.valueOf(fuelModel.getPetrolPrice()));
                    editor.putString("dieselPrice", String.valueOf(fuelModel.getDieselPrice()));
                    editor.putString("petrolDiff", String.valueOf(fuelModel.getPetrolChange()));
                    editor.putString("dieselDiff", String.valueOf(fuelModel.getDieselChange()));
                    editor.commit();
                    editor.apply();
                } else {
                    Toast.makeText(MainActivity.this, "Server under maintenance !", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<FuelModel> call, Throwable t) {
                ll_progress.setVisibility(View.GONE);
                ll_fuel.setVisibility(View.VISIBLE);
                Toast.makeText(MainActivity.this, "Fuel current price not available for this city , Sorry !", Toast.LENGTH_LONG).show();
                tv_city.setText("Not available for this city");
                tv_state.setText("");
                tv_petrolprice.setText("00");
                tv_dieselprice.setText("00");
                tv_dieseldiff.setText("00");
                tv_petrodiff.setText("00");
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.history, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case id.menu_history:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id2 = 1;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(MainActivity.this, HistoryTabLayoutActivity.class));
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(activity);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);

        TextView tvPro = dialog.findViewById(R.id.tvPro);
        Button btnLater = dialog.findViewById(R.id.btnLater);
        Button btnSubmit = dialog.findViewById(R.id.btnSubmit);

        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            tvPro.setTextColor(getResources().getColor(color.orange));
            btnLater.setTextColor(getResources().getColor(color.orange));
            btnSubmit.setTextColor(getResources().getColor(color.orange));
        }
        DarkTheame darkTheame = new DarkTheame(activity);
        if (darkTheame.modeData().equals("nightMode")) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            tvPro.setTextColor(getResources().getColor(color.orange));
            btnLater.setTextColor(getResources().getColor(color.orange));
            btnSubmit.setTextColor(getResources().getColor(color.orange));
        }

        GGAdview gg_native = dialog.findViewById(R.id.ggAdView_native);
        gg_native.setUnitId(getResources().getString(R.string.NativeAd));
        gg_native.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );

        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    finishAffinity();
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);

        TextView tvPro = dialog.findViewById(R.id.tvPro);
        Button btnLater = dialog.findViewById(R.id.btnLater);
        Button btnSubmit = dialog.findViewById(R.id.btnSubmit);

        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            tvPro.setTextColor(getResources().getColor(color.orange));
            btnLater.setTextColor(getResources().getColor(color.orange));
            btnSubmit.setTextColor(getResources().getColor(color.orange));
        }
        DarkTheame darkTheame = new DarkTheame(activity);
        if (darkTheame.modeData().equals("nightMode")) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            tvPro.setTextColor(getResources().getColor(color.orange));
            btnLater.setTextColor(getResources().getColor(color.orange));
            btnSubmit.setTextColor(getResources().getColor(color.orange));
        }

        GGAdview gg_native = dialog.findViewById(R.id.ggAdView_native);
        gg_native.setUnitId(getResources().getString(R.string.NativeAd));
        gg_native.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });
        dialog.show();
    }
}