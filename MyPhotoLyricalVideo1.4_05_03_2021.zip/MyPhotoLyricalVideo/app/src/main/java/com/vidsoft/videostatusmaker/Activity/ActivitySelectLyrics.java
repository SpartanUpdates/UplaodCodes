package com.vidsoft.videostatusmaker.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Handler;

import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import androidx.appcompat.app.AppCompatActivity;

import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import com.vidsoft.videostatusmaker.adapter.FregmentPagerAdapter;

public class ActivitySelectLyrics extends AppCompatActivity {
    static TextView tvEndTime;
    static Typeface typeface;
    static int h;
    ImageView ivTab1;
    ImageView ivTab10;
    ImageView ivTab11;
    ImageView ivTab12;
    ImageView ivTab13;
    ImageView ivTab14;
    ImageView ivTab15;
    ImageView ivTab16;
    ImageView ivTab17;
    ImageView ivTab18;
    ImageView ivTab19;
    ImageView ivTab2;
    ImageView ivTab20;
    ImageView ivTab21;
    ImageView ivTab3;
    ImageView ivTab4;
    ImageView ivTab5;
    ImageView ivTab6;
    ImageView ivTab7;
    ImageView ivTab8;
    ImageView ivTab9;
    TextView tvTitle;

    static SeekBar playerSeek;
    public static ProgressDialog progressDialog;
    static Runnable run = new Runnable() {
        public void run() {
            ActivitySelectLyrics.seekUpdation();
        }
    };
    static Handler seekHandler = new Handler();
    static TextView tvStart_time;
    public static String StrTxt_path;
    static int w;
    LinearLayout addTextLay;
    ImageView ivBack;
    LinearLayout linearLayout;
    ArrayList<ImageView> arrayList = new ArrayList();
    TextView lyricTxt;
    FregmentPagerAdapter fregmentPagerAdapter;
    int[] press = new int[]{R.drawable.tab1_pressed, R.drawable.tab2_pressed, R.drawable.tab3_pressed, R.drawable.tab4_pressed, R.drawable.tab5_pressed, R.drawable.tab6_pressed, R.drawable.tab7_pressed, R.drawable.tab8_pressed, R.drawable.tab9_pressed, R.drawable.tab10_pressed, R.drawable.tab11_pressed, R.drawable.tab12_pressed, R.drawable.tab13_pressed, R.drawable.tab14_pressed, R.drawable.tab15_pressed, R.drawable.tab16_pressed, R.drawable.tab17_pressed, R.drawable.tab18_pressed, R.drawable.tab19_pressed, R.drawable.tab20_pressed, R.drawable.tab21_pressed};
    HorizontalScrollView horizontalScrollView;
    int[] unpress = new int[]{R.drawable.tab1_unpressed, R.drawable.tab2_unpressed, R.drawable.tab3_unpressed, R.drawable.tab4_unpressed, R.drawable.tab5_unpressed, R.drawable.tab6_unpressed, R.drawable.tab7_unpressed, R.drawable.tab8_unpressed, R.drawable.tab9_unpressed, R.drawable.tab10_unpressed, R.drawable.tab11_unpressed, R.drawable.tab12_unpressed, R.drawable.tab13_unpressed, R.drawable.tab14_unpressed, R.drawable.tab15_unpressed, R.drawable.tab16_unpressed, R.drawable.tab17_unpressed, R.drawable.tab18_unpressed, R.drawable.tab19_unpressed, R.drawable.tab20_unpressed, R.drawable.tab21_unpressed};
    ViewPager viewPager;
    public static Activity activity;
    public static RelativeLayout relativeLayout;
    static MediaPlayer mediaPlayer;
    public static String strMusicPath;
    static ImageView ivPlayPause;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_select_lyrics);
        w = getResources().getDisplayMetrics().widthPixels;
        h = getResources().getDisplayMetrics().heightPixels;
        getWindow().addFlags(1024);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        int i = 0;
        progressDialog.setCancelable(false);
        activity = this;
        PutAnalyticsEvent();
        bindView();
        BannerAds();
        this.viewPager = findViewById(R.id.viewpager);
        this.fregmentPagerAdapter = new FregmentPagerAdapter(getSupportFragmentManager());
        this.viewPager.setAdapter(this.fregmentPagerAdapter);
        this.viewPager.setOnPageChangeListener(new OnPageChangeListener() {
            public void onPageScrollStateChanged(int i) {
            }

            public void onPageScrolled(int i, float f, int i2) {
            }

            public void onPageSelected(int i) {
                ActivitySelectLyrics.this.unpressAll();
                ActivitySelectLyrics.this.arrayList.get(i).setImageResource(ActivitySelectLyrics.this.press[i]);
                ActivitySelectLyrics.this.horizontalScrollView.requestChildFocus(ActivitySelectLyrics.this.linearLayout, ActivitySelectLyrics.this.arrayList.get(i));
            }
        });
        this.viewPager.setOffscreenPageLimit(this.arrayList.size());
        while (i < this.arrayList.size()) {
            onclick(this.arrayList.get(i), i);
            i++;
        }
        init();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivitySelectLyrics");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void bindView() {
        this.horizontalScrollView = findViewById(R.id.scrollView);
        this.linearLayout = findViewById(R.id.childLay);
        this.ivTab1 = findViewById(R.id.tab1);
        this.ivTab2 = findViewById(R.id.tab2);
        this.ivTab3 = findViewById(R.id.tab3);
        this.ivTab4 = findViewById(R.id.tab4);
        this.ivTab5 = findViewById(R.id.tab5);
        this.ivTab6 = findViewById(R.id.tab6);
        this.ivTab7 = findViewById(R.id.tab7);
        this.ivTab8 = findViewById(R.id.tab8);
        this.ivTab9 = findViewById(R.id.tab9);
        this.ivTab10 = findViewById(R.id.tab10);
        this.ivTab11 = findViewById(R.id.tab11);
        this.ivTab12 = findViewById(R.id.tab12);
        this.ivTab13 = findViewById(R.id.tab13);
        this.ivTab14 = findViewById(R.id.tab14);
        this.ivTab15 = findViewById(R.id.tab15);
        this.ivTab16 = findViewById(R.id.tab16);
        this.ivTab17 = findViewById(R.id.tab17);
        this.ivTab18 = findViewById(R.id.tab18);
        this.ivTab19 = findViewById(R.id.tab19);
        this.ivTab20 = findViewById(R.id.tab20);
        this.ivTab21 = findViewById(R.id.tab21);
        this.arrayList.clear();
        this.arrayList.add(this.ivTab1);
        this.arrayList.add(this.ivTab2);
        this.arrayList.add(this.ivTab3);
        this.arrayList.add(this.ivTab4);
        this.arrayList.add(this.ivTab5);
        this.arrayList.add(this.ivTab6);
        this.arrayList.add(this.ivTab7);
        this.arrayList.add(this.ivTab8);
        this.arrayList.add(this.ivTab9);
        this.arrayList.add(this.ivTab10);
        this.arrayList.add(this.ivTab11);
        this.arrayList.add(this.ivTab12);
        this.arrayList.add(this.ivTab13);
        this.arrayList.add(this.ivTab14);
        this.arrayList.add(this.ivTab15);
        this.arrayList.add(this.ivTab16);
        this.arrayList.add(this.ivTab17);
        this.arrayList.add(this.ivTab18);
        this.arrayList.add(this.ivTab19);
        this.arrayList.add(this.ivTab20);
        this.arrayList.add(this.ivTab21);
    }

    void init() {
        this.addTextLay = findViewById(R.id.add_text_lay);
        this.lyricTxt = findViewById(R.id.lyric_txt);
        this.ivBack = findViewById(R.id.back);
        this.tvTitle = findViewById(R.id.title);
        relativeLayout = findViewById(R.id.main);
        typeface = Typeface.createFromAsset(getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(typeface);
        this.lyricTxt.setTypeface(typeface);
        this.ivBack.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ActivitySelectLyrics.this.onBackPressed();
            }
        });
        mediaPlayer = new MediaPlayer();
        setLayout();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void setLayout() {
        int i = getResources().getDisplayMetrics().widthPixels;
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((i * 70) / 1080, (getResources().getDisplayMetrics().heightPixels * 70) / 1920);
        layoutParams.addRule(15);
        int i2 = 0;
        layoutParams.setMargins((i * 40) / 1080, 0, 0, 0);
        this.ivBack.setLayoutParams(layoutParams);
        while (i2 < this.arrayList.size()) {
            Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), this.press[i2]);
            this.arrayList.get(i2).setLayoutParams(new LinearLayout.LayoutParams((decodeResource.getWidth() * i) / 1080, (decodeResource.getHeight() * i) / 1080));
            i2++;
        }
    }

    public static void play_popup(String str) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.play_popup);
        LinearLayout linearLayout = dialog.findViewById(R.id.mainlay);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams((w * 930) / 1080, (h * 500) / 1920));
        linearLayout.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        TextView textView = dialog.findViewById(R.id.title);
        textView.setText(str);
        textView.setTypeface(typeface);
        tvStart_time = dialog.findViewById(R.id.start_time);
        tvEndTime = dialog.findViewById(R.id.end_time);
        ivPlayPause = dialog.findViewById(R.id.play_pause);
        playerSeek = dialog.findViewById(R.id.player_seek);
        setPlayer(ivPlayPause);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((w * 80) / 1080, (h * 80) / 1920);
        layoutParams.addRule(13);
        ivPlayPause.setLayoutParams(layoutParams);
        Bitmap decodeResource = BitmapFactory.decodeResource(activity.getResources(), R.drawable.thumb2);
        int width = (w * decodeResource.getWidth()) / 1080;
        playerSeek.setThumb(new BitmapDrawable(activity.getResources(), Bitmap.createScaledBitmap(decodeResource, width, width, true)));
        ImageView imageView = dialog.findViewById(R.id.cancel);
        ImageView imageView2 = dialog.findViewById(R.id.ok);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams((w * 282) / 1080, (h * 85) / 1920);
        layoutParams2.addRule(13);
        imageView.setLayoutParams(layoutParams2);
        imageView2.setLayoutParams(layoutParams2);
        dialog.show();
        ivPlayPause.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (ActivitySelectLyrics.mediaPlayer.isPlaying()) {
                    ActivitySelectLyrics.mediaPlayer.pause();
                    ActivitySelectLyrics.ivPlayPause.setImageResource(R.drawable.play5);
                    return;
                }
                ActivitySelectLyrics.mediaPlayer.start();
                ActivitySelectLyrics.ivPlayPause.setImageResource(R.drawable.pause5);
            }
        });
        playerSeek.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (z) {
                    ActivitySelectLyrics.mediaPlayer.seekTo(i);
                }
            }
        });
        imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.cancel();
            }
        });
        imageView2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (ActivitySelectLyrics.mediaPlayer.isPlaying()) {
                    ActivitySelectLyrics.mediaPlayer.pause();
                }
                dialog.cancel();
                ActivitySelectLyrics.activity.startActivity(new Intent(ActivitySelectLyrics.activity, ActivityPreview.class));
            }
        });
        ivPlayPause.performClick();
        dialog.setOnCancelListener(new OnCancelListener() {
            public void onCancel(DialogInterface dialogInterface) {
                ActivitySelectLyrics.resetPlayer();
            }
        });
    }

    static void setPlayer(final ImageView imageView) {
        resetPlayer();
        try {
            mediaPlayer.setDataSource(strMusicPath);
            mediaPlayer.prepare();
            mediaPlayer.setVolume(1.0f, 1.0f);
            mediaPlayer.setOnCompletionListener(new OnCompletionListener() {
                public void onCompletion(MediaPlayer mediaPlayer) {
                    imageView.setImageResource(R.drawable.play5);
                }
            });
            playerSeek.setMax(mediaPlayer.getDuration());
            seekUpdation();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void seekUpdation() {
        final int duration = ActivitySelectLyrics.mediaPlayer.getDuration();
        final int currentPosition = ActivitySelectLyrics.mediaPlayer.getCurrentPosition();
        final TimeUnit milliseconds = TimeUnit.MILLISECONDS;
        final long n = duration;
        final String format = String.format("%02d:%02d", milliseconds.toMinutes(n), TimeUnit.MILLISECONDS.toSeconds(n) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(n)));
        final TimeUnit milliseconds2 = TimeUnit.MILLISECONDS;
        final long n2 = currentPosition;
        ActivitySelectLyrics.tvStart_time.setText(String.format("%02d:%02d", milliseconds2.toMinutes(n2), TimeUnit.MILLISECONDS.toSeconds(n2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(n2))));
        ActivitySelectLyrics.tvEndTime.setText(format);
        ActivitySelectLyrics.playerSeek.setProgress(ActivitySelectLyrics.mediaPlayer.getCurrentPosition());
        ActivitySelectLyrics.seekHandler.postDelayed(ActivitySelectLyrics.run, 10L);
    }

    static void resetPlayer() {
        if (mediaPlayer != null) {
            mediaPlayer.reset();
            seekHandler.removeCallbacks(run);
        }
    }

    void unpressAll() {
        for (int i = 0; i < this.arrayList.size(); i++) {
            this.arrayList.get(i).setImageResource(this.unpress[i]);
        }
    }

    void onclick(View view, final int i) {
        view.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ActivitySelectLyrics.this.viewPager.setCurrentItem(i);
            }
        });
    }
}