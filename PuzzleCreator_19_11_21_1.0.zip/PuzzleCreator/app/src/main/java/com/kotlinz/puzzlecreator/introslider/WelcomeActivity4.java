package com.kotlinz.puzzlecreator.introslider;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kotlinz.puzzlecreator.R;

public class WelcomeActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome4);
    }
}