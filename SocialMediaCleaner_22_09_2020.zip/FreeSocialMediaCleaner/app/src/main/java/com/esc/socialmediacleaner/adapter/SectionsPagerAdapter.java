package com.esc.socialmediacleaner.adapter;

import android.content.Context;

import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.datastructure.FileDataWrapper;
import com.esc.socialmediacleaner.datastructure.SocialAppType;
import com.esc.socialmediacleaner.fragment.FileFragment;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import java.util.ArrayList;

public class SectionsPagerAdapter extends FragmentPagerAdapter {
    private final ArrayList<FileDataWrapper> listdata;
    private final Context mContext;
    private ArrayList<SocialAppType> tabList = new ArrayList();

    public SectionsPagerAdapter(Context context, FragmentManager fragmentManager, ArrayList<FileDataWrapper> arrayList) {
        super(fragmentManager);
        this.mContext = context;
        this.listdata = arrayList;
        for (int i = 0; i < arrayList.size(); i++) {
            if (!this.tabList.contains(((FileDataWrapper) arrayList.get(i)).socialAppType)) {
                this.tabList.add(((FileDataWrapper) arrayList.get(i)).socialAppType);
            }
        }
        MyApplication.getInstance().allData.tabList = this.tabList;
    }

    public Fragment getItem(int i) {
        ArrayList arrayList = new ArrayList();
        SocialAppType socialAppType = (SocialAppType) this.tabList.get(i);
        for (int i2 = 0; i2 < this.listdata.size(); i2++) {
            if (((FileDataWrapper) this.listdata.get(i2)).socialAppType == socialAppType) {
                arrayList.add(this.listdata.get(i2));
            }
        }
        return new FileFragment(this.mContext, arrayList);
    }

    public CharSequence getPageTitle(int i) {
        return ((SocialAppType) this.tabList.get(i)).toString();
    }

    public int getCount() {
        return this.tabList.size();
    }
}
