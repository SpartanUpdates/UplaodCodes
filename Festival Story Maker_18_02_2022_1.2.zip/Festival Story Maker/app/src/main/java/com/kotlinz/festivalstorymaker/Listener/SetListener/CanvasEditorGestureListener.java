package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

import com.kotlinz.festivalstorymaker.Utils.BorderedTextView;
import com.kotlinz.festivalstorymaker.Other.TextInputDilaog;
import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;

public class CanvasEditorGestureListener extends GestureDetector.SimpleOnGestureListener
{
    public final BorderedTextView borderedTextView;
    public final  com.kotlinz.festivalstorymaker.Models.g editModel;
    public final  FrameLayout frameLayout;
    public final CanvasEditorActivity activity;

    public CanvasEditorGestureListener(final CanvasEditorActivity h, final BorderedTextView e, final com.kotlinz.festivalstorymaker.Models.g f, final FrameLayout g) {
        this.activity = h;
        this.borderedTextView = e;
        this.editModel = f;
        this.frameLayout = g;
    }

    public void onLongPress(final MotionEvent motionEvent) {
        final CanvasEditorActivity h = this.activity;
        h.f1 = true;
        h.g1 = (View)this.borderedTextView;
        h.b0 = this.frameLayout;
        h.B0(true);
    }

    public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
        this.activity.w0();
        TextInputDilaog.q0((Context)this.activity, this.borderedTextView.getText().toString(), true, this.editModel.x).m0 = (TextInputDilaog.d)new TextInputDilaog.d() {
            @Override
            public void a(final String text, final int n) {
                CanvasEditorGestureListener.this.borderedTextView.setText((CharSequence)text);
            }

            @Override
            public void b(final String s) {
            }
        };
        return true;
    }
}
