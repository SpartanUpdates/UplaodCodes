package com.wavymusic.Partical.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.Partical.Model.ParticalCategoryModel;
import com.wavymusic.R;
import com.wavymusic.UnityPlayerActivity;

public class ParticalCatAdapter extends RecyclerView.Adapter<ParticalCatAdapter.ParticalViewHolder> {

    Context context;
    public int selectedPosition = -1;

    public ParticalCatAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public ParticalViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_partical_cat, parent, false);
        return new ParticalViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ParticalViewHolder holder, final int position) {
        final ParticalCategoryModel particalCategoryModel = ((UnityPlayerActivity) this.context).particalCategoryModels.get(position);
        holder.tvName.setText(particalCategoryModel.getCatName());
        holder.ivThumb.setImageResource(Utils.INSTANCE.ParticalCatThumb(particalCategoryModel.getCatName()));
        if (selectedPosition == position) {
            holder.ivThumb.setImageResource(Utils.INSTANCE.ParticalCatThumbPress(particalCategoryModel.getCatName()));
        } else {
            if (MyApplication.ThemeAssetCatSelectedPosition == particalCategoryModel.getCatName()) {
                holder.ivThumb.setImageResource(Utils.INSTANCE.ParticalCatThumbPress(particalCategoryModel.getCatName()));
            }
        }

        holder.llParticalMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UnityPlayerActivity.unityPlayeractivity.SetCategoryData(Integer.parseInt(particalCategoryModel.getCatId()));
                UnityPlayerActivity.unityPlayeractivity.CategoryHideWavy();
                selectedPosition = position;
                MyApplication.ThemeAssetCatSelectedPosition = "";
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return ((UnityPlayerActivity) this.context).particalCategoryModels.size();
    }

    public class ParticalViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivThumb;
        private TextView tvName;
        LinearLayout llParticalMain;

        public ParticalViewHolder(@NonNull View itemView) {
            super(itemView);
            ivThumb = itemView.findViewById(R.id.ivThumb);
            tvName = itemView.findViewById(R.id.tvName);
            llParticalMain = itemView.findViewById(R.id.ll_partical_main);
        }
    }
}
