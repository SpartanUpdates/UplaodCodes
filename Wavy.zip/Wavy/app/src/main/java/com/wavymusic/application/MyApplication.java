package com.wavymusic.application;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.gson.JsonObject;
import com.root.unity.AndroidUnityCall;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.Model.ImageModel;
import com.wavymusic.R;
import com.wavymusic.UnityPlayerActivity;
import com.wavymusic.activity.ExitAppActivity;
import com.wavymusic.activity.HomeActivity;
import com.wavymusic.activity.MyCreationPlayer;
import com.wavymusic.activity.TextEditActivity;
import com.wavymusic.activity.YourVideoActivity;
import com.wavymusic.cropImage.CropImage;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import retrofit2.Call;

public class MyApplication extends android.app.Application {

    public static Context mContext;
    public static String AppName = "Wavy Music";
    public static int TotalSelectedImage;
    private static MyApplication instance;
    public int min_pos;
    public static boolean IsSelectImageFrom;
    public static Context AppLaunchContex;
    //    public static InterstitialAd mInterstitialAd;
    public static boolean IsHomeAdsDisplay = false;
    public static String SPLIT_PATTERN;
    public final ArrayList<ImageModel> selectedImages;
    public final ArrayList<CropImage> cropimaglist;
    public HashMap<String, ArrayList<ImageModel>> allAlbum;
    private ArrayList<String> allFolder;
    private String selectedFolderId;
    public static boolean IsSongCuttingready = false;
    public static boolean IsVideoready = false;
    public static boolean IsAudioVideoMearge = false;
    public static String CutSongPath;
    public static int ThemePosition = -1;
    public static int CatSelectedPosition = -1;
    public boolean IsNativeAdsLoaded = false;
    public static String VideoPath;
    public AdLoader adLoader;
    public List<UnifiedNativeAd> mNativeAds = new ArrayList<>();

    public static String StyleStatus = "Close";
    public static String FilterStatus = "Close";
    public static String LightsStatus = "Close";

    public static int ThemeAssetCatSelectedPosition = -1;
    public static int ThemeAssetSelectedPosition = -1;
    public static int ParticalCatid = -1;
    public static int ParticalSelectedCatid = -1;
    public static boolean isEditCall = false;
    public static Call<JsonObject> Tempcall;

    public static InterstitialAd fbinterstitialAd;
    public static int AdsId;
    public static Activity AdsShowContext;
    public String result_conc = "";
    public static String AllFilePath;
    public static String FinalSongPath;

    static {
        MyApplication.TotalSelectedImage = 5;
        MyApplication.SPLIT_PATTERN = "?";
    }

    public MyApplication() {
        this.selectedImages = new ArrayList<ImageModel>();
        this.cropimaglist = new ArrayList<CropImage>();
        this.min_pos = Integer.MAX_VALUE;
    }

    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        MyApplication.mContext = this.getApplicationContext();
        MobileAds.initialize(MyApplication.mContext, MyApplication.mContext.getResources().getString(R.string.admob_app_id));
        AudienceNetworkAds.initialize(this);
        AdSettings.addTestDevice("6c30fd48-597e-4afd-85b8-02079cd227a0");
        LoadfbInterstitialAds();
//        LoadAdsPreviewUnity(MyApplication.mContext);
        loadNativeAds();
    }

    private void LoadfbInterstitialAds() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.e("TAG","onInterstitialDismissed..."+AdsId);
                switch (AdsId) {
                    case 1:
                        SelectedImages();
                        break;
                    case 2:
                        GoToPreview();
                        break;
                    case 3:
                        GoToExit();
                        break;
                    case 4:
                        GoBack();
                        break;
                    case 5:
                        SongSelect();
                        break;
                    case 6:
                        GetJsonResponse();
                        break;
                    case 7:
                        CloseVideoPlayer();
                        break;
                    case 8:
                        Log.e("TAG", "UnityPlayerActAdsShow");
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e("TAG","AdError..."+adError.getErrorMessage());
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.e("TAG","AdsLoaded...");
                // Interstitial ad is loaded and ready to be displayed
                // Show the ad
            }

            @Override
            public void onAdClicked(Ad ad) {
                // Ad clicked callback
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // Ad impression logged callback
            }
        });
        fbinterstitialAd.loadAd();
    }

    private void requestNewInterstitial() {
        if (fbinterstitialAd != null) {
            fbinterstitialAd.loadAd();
        } else {
            fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
            fbinterstitialAd.loadAd();
        }
    }

    private void SelectedImages() {
        for (int i = 0; i < this.getCropImages().size(); ++i) {
            if (i == 0) {
                result_conc = this.getCropImages().get(i).a();
            } else {
                result_conc = String.valueOf(result_conc) + MyApplication.SPLIT_PATTERN + this.getCropImages().get(i).a();
            }
        }
        String MethodName;
        String GameobjectName;
        if (MyApplication.IsSelectImageFrom) {
            MyApplication.IsSelectImageFrom = false;
            MethodName = "StaticThemeDataBase";
            GameobjectName = "LoadDefaultData";
        } else {
            MethodName = "GameManager";
            GameobjectName = "ReturnImagePath";
        }
        UnityPlayer.UnitySendMessage(MethodName, GameobjectName, result_conc);
        AdsShowContext.finish();
    }


    public void GoToPreview() {
        UnityPlayer.UnitySendMessage("StaticThemeDataBase", "OnLoadUserData", AllFilePath);
        HideShowUnityBannerAds();
        AdsShowContext.finish();
    }

    private void HideShowUnityBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void GoToExit() {
//        startActivity(new Intent(AdsShowContext, ExitAppActivity.class));
//        AdsShowContext.finish();
        Intent intent=new Intent(AdsShowContext,ExitAppActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        AdsShowContext.finish();
    }

    private void GoBack() {
//        startActivity(new Intent(AdsShowContext, HomeActivity.class));
        Intent intent=new Intent(AdsShowContext,HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        AdsShowContext.finish();
    }

    private void SongSelect() {
        UnityPlayer.UnitySendMessage("StackManager", "ReturnAudio", FinalSongPath);
        AdsShowContext.finish();
    }

    public void GetJsonResponse() {
        String ChangeTextResponse = TextEditActivity.GetJsonArray(TextEditActivity.textList);
        UnityPlayer.UnitySendMessage("GameManager", "ReturnTextResponce", ChangeTextResponse);
        AdsShowContext.finish();
    }

    private void CloseVideoPlayer() {
        if (MyCreationPlayer.IsFromAndroidlist) {
            AdsShowContext.finish();
        } else {
            AndroidUnityCall.ScanVideoList(AdsShowContext, MyApplication.VideoPath);
            UnityPlayer.UnitySendMessage("StackManager", "ResetEveryThing", "");
            Intent intent = new Intent(this, YourVideoActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            AdsShowContext.finish();
        }
    }

    public static void StatusUpdate(String stylestatus, String filterstatus, String lightsStatus) {
        StyleStatus = stylestatus;
        FilterStatus = filterstatus;
        LightsStatus = lightsStatus;
    }


//    public void LoadAdsPreviewUnity(final Context context) {
//        mInterstitialAd = new InterstitialAd(context);
//        mInterstitialAd.setAdUnitId(context.getResources().getString(R.string.interstitial));
//        mInterstitialAd.loadAd(new AdRequest.Builder().build());
//        mInterstitialAd.setAdListener(new AdListener() {
//            @Override
//            public void onAdClosed() {
//                GoToAndroid();
//                if (mInterstitialAd != null) {
//                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
//                }
//            }
//
//            @Override
//            public void onAdLoaded() {
//                super.onAdLoaded();
//            }
//
//            @Override
//            public void onAdFailedToLoad(int i) {
//                super.onAdFailedToLoad(i);
//                if (mInterstitialAd != null) {
//                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
//                }
//            }
//        });
//    }

    public void GoToAndroid() {
        Intent intent = new Intent(MyApplication.AppLaunchContex, HomeActivity.class);
        MyApplication.AppLaunchContex.startActivity(intent);
    }

    private void loadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getString(R.string.native_ad_home));
        adLoader = builder.forUnifiedNativeAd(
                new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                    @Override
                    public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                        mNativeAds.add(unifiedNativeAd);
                        Log.e("TAG","mNativeAds onUnifiedNativeAdLoaded"+unifiedNativeAd.getHeadline());
                        MyApplication.getInstance().IsNativeAdsLoaded = true;
                    }
                }).withAdListener(
                new AdListener() {
                    @Override
                    public void onAdFailedToLoad(int errorCode) {
                        Log.e("TAG","mNativeAds onAdFailedToLoad"+errorCode);
                        MyApplication.getInstance().IsNativeAdsLoaded = false;
                    }
                }).build();
        // Load the Native ads.
        adLoader.loadAds(new AdRequest.Builder().build(), 5);
    }

    public void init() {
        this.getFolderList();
    }

    public static String getFileName(String str) {
        return str.substring(str.lastIndexOf("/") + 1);
    }


    public String getSelectedFolderId() {
        return this.selectedFolderId;
    }

    public void setSelectedFolderId(final String selectedFolderId) {
        this.selectedFolderId = selectedFolderId;
    }

    public HashMap<String, ArrayList<ImageModel>> getAllAlbum() {
        return this.allAlbum;
    }

    public ArrayList<ImageModel> getImageByAlbum(final String folderId) {
        ArrayList<ImageModel> imageDatas = this.getAllAlbum().get(folderId);
        if (imageDatas == null) {
            imageDatas = new ArrayList<ImageModel>();
        }
        return imageDatas;
    }

    public ArrayList<ImageModel> getSelectedImages() {
        return this.selectedImages;
    }

    public void addSelectedImage(final ImageModel imageData) {
        this.selectedImages.add(imageData);
        ++imageData.imageCount;
    }

    public void removeSelectedImage(final int imageData) {
        if (imageData <= this.selectedImages.size()) {
            final ImageModel imageData2 = this.selectedImages.remove(imageData);
            --imageData2.imageCount;
        }
    }

    public void ReplaceSelectedImage(ImageModel imageData, int pos) {
        this.selectedImages.set(pos, imageData);
    }

    public ArrayList<CropImage> getCropImages() {
        return this.cropimaglist;
    }

    public void AddCropImages(CropImage imageData) {
        this.cropimaglist.add(imageData);

    }

    public void ReplaceCropImages(ImageModel imageData, int pos) {
        this.selectedImages.set(pos, imageData);
    }

    public void removecropImage(int imageData) {
        cropimaglist.remove(imageData);

    }


    public void getFolderList() {
        this.allFolder = new ArrayList<String>();
        this.allAlbum = new HashMap<String, ArrayList<ImageModel>>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "bucket_id", "datetaken", "_data"};
        final Uri images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "_data";
        final Cursor cur = this.getContentResolver().query(images, projection, (String) null, (String[]) null, "_data DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("bucket_display_name");
            final int bucketIdColumn = cur.getColumnIndex("bucket_id");

            ImageModel data = null;
            this.setSelectedFolderId(cur.getString(bucketIdColumn));
            do {
                data = new ImageModel();
                data.imagePath = cur.getString(cur.getColumnIndex("_data"));
                data.imageThumbnail = cur.getString(cur.getColumnIndex("_data"));
                if (!data.imagePath.endsWith(".gif")) {
                    final String folderName = cur.getString(bucketColumn);
                    final String folderId = cur.getString(bucketIdColumn);
                    if (!this.allFolder.contains(folderId)) {
                        this.allFolder.add(folderId);
                    }
                    ArrayList<ImageModel> imagePath = this.allAlbum.get(folderId);
                    if (imagePath == null) {
                        imagePath = new ArrayList<ImageModel>();
                    }
                    data.folderName = folderName;
                    imagePath.add(data);
                    this.allAlbum.put(folderId, imagePath);


                }
            } while (cur.moveToNext());
        }
    }
}
