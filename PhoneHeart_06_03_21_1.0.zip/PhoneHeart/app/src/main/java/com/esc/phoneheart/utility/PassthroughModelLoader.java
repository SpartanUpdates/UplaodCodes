package com.esc.phoneheart.utility;

import com.bumptech.glide.Priority;
import com.bumptech.glide.load.data.DataFetcher;
import com.bumptech.glide.load.model.ModelLoader;

public class PassthroughModelLoader<Result, Source extends Result> implements ModelLoader<Source, Result> {

    public static class CastingDataFetcher<Source, Result> implements DataFetcher<Result> {
        public final Source model;

        public CastingDataFetcher(Source source) {
            this.model = source;
        }

        public void cancel() {
        }

        public void cleanup() {
        }

        public String getId() {
            return this.model.toString();
        }

        public Result loadData(Priority priority) throws Exception {
            return (Result) this.model;
        }
    }

    public DataFetcher<Result> getResourceFetcher(Source source, int i, int i2) {
        return new CastingDataFetcher(source);
    }
}
