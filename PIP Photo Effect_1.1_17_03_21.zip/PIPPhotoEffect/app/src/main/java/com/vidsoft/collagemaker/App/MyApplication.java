package com.vidsoft.collagemaker.App;


import android.app.Application;
import android.content.Context;
import com.facebook.ads.AdSettings;

public class MyApplication extends Application {


    private static MyApplication instance;
    public static Context mContext;

    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        MyApplication.mContext = this.getApplicationContext();
        AdSettings.addTestDevice("7610faee-7fbb-4d8d-be43-f7d428020dca");
    }
}
