package com.esc.photovault.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.database.MergeCursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.hardware.fingerprint.FingerprintManager;
import android.hardware.fingerprint.FingerprintManager.CryptoObject;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.OnScanCompletedListener;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.provider.MediaStore.Images.Media;
import android.security.keystore.KeyGenParameterSpec;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.andrognito.pinlockview.IndicatorDots;
import com.andrognito.pinlockview.PinLockListener;
import com.andrognito.pinlockview.PinLockView;
import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.baoyz.swipemenulistview.SwipeMenuListView.OnMenuItemClickListener;
import com.baoyz.swipemenulistview.SwipeMenuListView.OnMenuStateChangeListener;
import com.baoyz.swipemenulistview.SwipeMenuListView.OnSwipeListener;
import com.bumptech.glide.Glide;
import com.esc.photovault.R;
import com.esc.photovault.model.BreakModel;
import com.esc.photovault.model.Model;
import com.esc.photovault.model.ModelFolder;
import com.esc.photovault.permission.Permission;
import com.esc.photovault.pref.EPreferences;
import com.esc.photovault.util.FingerprintHandler;
import com.esc.photovault.util.Utility;
import com.esc.photovault.util.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.cast.TextTrackStyle;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.hiddencamera.CameraConfig;
import com.hiddencamera.CameraError;
import com.hiddencamera.HiddenCameraActivity;
import com.hiddencamera.HiddenCameraFragment;
import com.hiddencamera.config.CameraImageFormat;
import com.hiddencamera.config.CameraRotation;
import com.squareup.picasso.Picasso;
import org.apache.commons.lang3.StringUtils;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class Vault_folder extends HiddenCameraActivity {
    private Activity activity = Vault_folder.this;
    private static final String KEY_NAME = "PhotoVault";
    public static boolean first_time;
    @SuppressLint("StaticFieldLeak")
    public static RelativeLayout lock_rel;
    private RelativeLayout Back_arrow;
    private SwipeMenuListView swipeMenuListView;
    private int REQUEST_CAMERA = 0;
    private int SELECT_FILE = 1;
    private ListAdapter listAdapter;
    private RelativeLayout album_header;
    private RelativeLayout album_rel;
    boolean app_status = false;
    private ArrayList<ModelFolder> arrayList_floder = new ArrayList();
    private ArrayList<Model> arrayList_pos = new ArrayList();
    private TextView ascending;
    private RelativeLayout back_rel;
    private RelativeLayout back_rel_gallery;
    private RelativeLayout back_selectimg_gallery;
    private ImageView background_color;
    private TextView background_txt_set;
    private ImageView bg_theme;
    private TextView break_in_alert__list_set;
    private RelativeLayout break_in_alert_header_rel;
    private RelativeLayout break_in_alert_rel;
    private TextView break_in_alert_set;
    private ArrayList<String> break_list = new ArrayList();
    private AdapterCallback callback;
    private RelativeLayout camera_rel;
    private TextView cancle_forget_rel;
    private TextView cancle_rel;
    private TextView cancle_rel_forget_pwd;
    private TextView cancle_set_rel;
    private TextView cancle_txt;
    private TextView change_pwd__txt_set;
    private ArrayList<Model> checkmark_status = new ArrayList();
    private Cipher cipher;
    int[] color_theme = new int[]{R.mipmap.color0, R.mipmap.color1, R.mipmap.color3, R.mipmap.color6, R.mipmap.color5,
            R.mipmap.color7, R.mipmap.color2, R.mipmap.color4};
    private TextView color_txt_set;
    private EditText conform_et;
    private EditText conform_reset_et;
    private EditText conform_save_et;
    private RelativeLayout copy_layout_folder;
    private RelativeLayout create_album_header_rel;
    private ImageView create_directory_rel;
    private TextView create_headettxt;
    private TextView create_headettxt_gallery;
    private RelativeLayout create_rel;
    private TextView create_txt;
    private ImageView delete;
    private RelativeLayout delete_img_rel;
    private TextView descending;
    private RelativeLayout dialog_box_bg;
    private RelativeLayout dialog_box_email_rel;
    private RelativeLayout dialog_box_forget_rel;
    private RelativeLayout dialog_box_passcode_rel;
    private TextView done_rel;
    private TextView done_rel_forget_pwd;
    private TextView done_txt;
    private TextView enter_datatype;
    private TextView enter_email_forget_txt;
    private ArrayList<String> f32f = new ArrayList();
    private String folder_name;
    private String folder_name2;
    private RelativeLayout forget_pwd_folder_list;
    private RelativeLayout forget_pwd_folder;
    private RelativeLayout forget_pwd_folder_arrow;
    private RelativeLayout forget_pwd_folder_header;
    private TextView forget_pwd_folder_txt;
    private TextView forget_pwd_txt;
    private RelativeLayout funcation_rel;
    private RelativeLayout gallery_header;
    private RelativeLayout gallery_phone_rel;
    private RelativeLayout gallery_rel;
    private TextView header;
    private ImageView image_bg;
    private TextView image_txt_set;
    private RelativeLayout import_photo_gallery;
    private TextView import_photo_txt;
    private ArrayList<BreakModel> jjs = new ArrayList();
    private KeyStore keyStore;
    private Double latitude = Double.valueOf(0.0d);
    private File[] listFile;
    private ListView listview;
    private ListView listview_forget_pwd;
    private RelativeLayout lock_rel_break;
    private RelativeLayout lock_rel_break_arrow;
    private RelativeLayout lock_rel_break_header;
    private TextView lock_rel_break_txt;
    private boolean lock_screen_share_status = false;
    private Double longitude = Double.valueOf(0.0d);
    private CameraConfig mCameraConfig;
    private CustomPagerAdapter mCustomPagerAdapter;
    private HiddenCameraFragment mHiddenCameraFragment;
    private IndicatorDots mIndicatorDots;
    private PinLockListener mPinLockListener = new PinLock();
    private PinLockView mPinLockView;
    private EditText mail_et_forget;
    private EditText mail_et_set;
    private SupportMapFragment mapFragment;
    private Permission permission;
    private ImageView move;
    private RelativeLayout move_img_rel;
    private RelativeLayout my_gallery_rel;
    private RelativeLayout my_picture_header;
    private EditText name_et;
    private EditText name_save_et;
    private RelativeLayout new_back_rel;
    private RelativeLayout new_hader;
    private TextView new_headettxt;
    private TextView ok_forget_rel;
    private TextView ok_txt;
    private TextView ok_txt_passcode_rel;
    private RelativeLayout open_gallery_btn_rel;
    private RelativeLayout open_gallery_floating_btn;
    private String order;
    private ViewPager pageView;
    private String passcode;
    private TextView passcode_txt;
    private String path;
    private ImageView person_imgview;
    private TextView popup_txt;
    private TextView popup_txt_forget_pwd;
    private EditText pwd_et;
    private String pwd_folder_send_email;
    private RelativeLayout pwd_rel_folder;
    private EditText pwd_reset_et;
    private EditText pwd_save_et;
    private TextView pwd_settig_txt_set;
    private EditText pwd_txt_folder;
    private RecyclerView recyclerView_gallery;
    private RecyclerView recyclerView_vault;
    private RecyclerView recyleview_break;
    private RecyclerView recyleview_theme;
    private RelativeLayout reset_header;
    private RelativeLayout reset_pwd_rel;
    private TextView reset_txt;
    private RelativeLayout resetpwd_back_arrow;
    private RelativeLayout rl_progressbar1;
    private RecyclerView rv_gallery;
    private RelativeLayout save_back_rel;
    private Button save_btn;
    private RelativeLayout save_header_rel;
    private TextView save_headettxt;
    private RelativeLayout save_rel;
    private TextView save_set_rel;
    private TextView save_txt;
    private RelativeLayout select_img_header;
    private TextView select_txt_mygallery;
    private TextView select_txt_myvault;
    private RelativeLayout setting_icon_rel;
    private RelativeLayout setting_lock_rel;
    private ImageView share;
    private RelativeLayout share_img_rel;
    private TextView sorting_txt_set;
    private ArrayList<Model> status = new ArrayList();
    private ArrayList<Model> status_select_namefolder = new ArrayList();
    private String store_path;
    private TextView takephoto_txt;
    private RelativeLayout theme_back_arrow;
    private String theme_color;
    private RelativeLayout theme_done_arrow;
    private TextView theme_header;
    private RelativeLayout theme_header_rel;
    private RelativeLayout theme_rel;
    private String theme_type;
    private TextView title_of_pwd_rel;
    private ToggleButton toggleButton;
    private RelativeLayout touch_rel;
    private TextView touchid_txt_set;
    private RelativeLayout view_pager_hader;
    private RelativeLayout view_pager_rel;
    private RelativeLayout viewpager_back_rel;
    private TextView viewpager_headettxt;
    private String worng_passcode;
    private RelativeLayout change_question_layout;
    private EPreferences ePreferences;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private UnifiedNativeAd nativeAd;
    private TextView txt_share, txt_rateus, txt_privacy;

    @SuppressLint("WrongConstant")
    @RequiresApi(api = 17)
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vault_folder);

        this.permission = new Permission(this);
        if (!this.permission.checkPermissionForWriteexternal()) {
            this.permission.requestPermissionForWriteexternal();
        }
        if (!this.permission.checkPermissionForCamera()) {
            this.permission.requestPermissionCamera();
        }

        if (!permission.checkPermissionForReadexternal()) {
            permission.requestPermissionForReadeexternal();
        }

        this.ePreferences = EPreferences.getInstance(this);
        BannerAds();

        change_question_layout = (RelativeLayout) findViewById(R.id.change_question_layout);
        this.mPinLockView = (PinLockView) findViewById(R.id.pin_lock_view);
        this.mIndicatorDots = (IndicatorDots) findViewById(R.id.indicator_dots);
        this.mPinLockView.attachIndicatorDots(this.mIndicatorDots);
        this.mPinLockView.setPinLockListener(this.mPinLockListener);
        this.mPinLockView.setPinLength(4);
        this.mPinLockView.setTextColor(ContextCompat.getColor(this, R.color.white));
        this.mIndicatorDots.setIndicatorType(0);
        this.enter_datatype = (TextView) findViewById(R.id.enter_datatype);
        this.enter_datatype.setText("Enter Passcode");
        this.enter_datatype.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/Mada-Medium.ttf"));
        this.header = (TextView) findViewById(R.id.header);
        this.album_header = (RelativeLayout) findViewById(R.id.album_header);
        this.album_rel = (RelativeLayout) findViewById(R.id.album_rel);
        lock_rel = (RelativeLayout) findViewById(R.id.lock_rel);
        this.setting_icon_rel = (RelativeLayout) findViewById(R.id.setting_icon_rel);
        this.rv_gallery = (RecyclerView) findViewById(R.id.recyclerView);
        this.create_directory_rel = (ImageView) findViewById(R.id.create_directory_rel);
        this.create_txt = (TextView) findViewById(R.id.create_txt);
        this.create_headettxt = (TextView) findViewById(R.id.create_headettxt);
        this.create_rel = (RelativeLayout) findViewById(R.id.create_rel);
        this.name_et = (EditText) findViewById(R.id.name_et);
        this.pwd_et = (EditText) findViewById(R.id.pwd_et);
        this.conform_et = (EditText) findViewById(R.id.conform_et);
        this.back_rel = (RelativeLayout) findViewById(R.id.back_rel);
        this.create_album_header_rel = (RelativeLayout) findViewById(R.id.create_album_header_rel);
        this.my_gallery_rel = (RelativeLayout) findViewById(R.id.my_gallery_rel);
        this.back_rel_gallery = (RelativeLayout) findViewById(R.id.back_rel_gallery);
        this.create_headettxt_gallery = (TextView) findViewById(R.id.create_headettxt_gallery);
        this.import_photo_gallery = (RelativeLayout) findViewById(R.id.import_photo_gallery);
        this.recyclerView_gallery = (RecyclerView) findViewById(R.id.recyclerView_gallery);
        this.select_txt_mygallery = (TextView) findViewById(R.id.select_txt_mygallery);
        this.gallery_header = (RelativeLayout) findViewById(R.id.gallery_header);
        this.import_photo_txt = (TextView) findViewById(R.id.import_photo_txt);
        this.gallery_rel = (RelativeLayout) findViewById(R.id.gallery_rel);
        this.takephoto_txt = (TextView) findViewById(R.id.takephoto_txt);
        this.camera_rel = (RelativeLayout) findViewById(R.id.camera_rel);
        this.open_gallery_floating_btn = (RelativeLayout) findViewById(R.id.open_gallery_floating_btn);
        this.gallery_phone_rel = (RelativeLayout) findViewById(R.id.gallery_phone_rel);
        this.done_txt = (TextView) findViewById(R.id.done_txt);
        this.recyclerView_vault = (RecyclerView) findViewById(R.id.recyclerView_vault);
        this.open_gallery_btn_rel = (RelativeLayout) findViewById(R.id.open_gallery_btn_rel);
        this.my_picture_header = (RelativeLayout) findViewById(R.id.my_picture_header);
        this.bg_theme = (ImageView) findViewById(R.id.bg_theme);
        this.pwd_rel_folder = (RelativeLayout) findViewById(R.id.pwd_rel_folder);
        this.pwd_txt_folder = (EditText) findViewById(R.id.pwd_txt_folder);
        this.ok_txt = (TextView) findViewById(R.id.ok_txt);
        this.cancle_txt = (TextView) findViewById(R.id.cancle_txt);
        this.title_of_pwd_rel = (TextView) findViewById(R.id.title_of_pwd_rel);
        this.select_img_header = (RelativeLayout) findViewById(R.id.select_img_header);
        this.back_selectimg_gallery = (RelativeLayout) findViewById(R.id.back_selectimg_gallery);
        this.select_txt_myvault = (TextView) findViewById(R.id.select_txt_myvault);
        this.share_img_rel = (RelativeLayout) findViewById(R.id.share_img_rel);
        this.move_img_rel = (RelativeLayout) findViewById(R.id.move_img_rel);
        this.delete_img_rel = (RelativeLayout) findViewById(R.id.delete_img_rel);
        this.copy_layout_folder = (RelativeLayout) findViewById(R.id.copy_layout_folder);
        this.funcation_rel = (RelativeLayout) findViewById(R.id.funcation_rel);
        this.share = (ImageView) findViewById(R.id.share);
        this.move = (ImageView) findViewById(R.id.move);
        this.delete = (ImageView) findViewById(R.id.delete);
        this.listview = (ListView) findViewById(R.id.listview);
        this.cancle_rel = (TextView) findViewById(R.id.cancle_rel);
        this.done_rel = (TextView) findViewById(R.id.done_rel);
        this.popup_txt = (TextView) findViewById(R.id.popup_txt);
        this.theme_rel = (RelativeLayout) findViewById(R.id.theme_rel);
        this.theme_header = (TextView) findViewById(R.id.theme_header);
        this.theme_back_arrow = (RelativeLayout) findViewById(R.id.theme_back_arrow);
        this.recyleview_theme = (RecyclerView) findViewById(R.id.recyleview_theme);
        this.theme_header_rel = (RelativeLayout) findViewById(R.id.theme_header_rel);
        this.theme_done_arrow = (RelativeLayout) findViewById(R.id.theme_done_arrow);
        this.reset_pwd_rel = (RelativeLayout) findViewById(R.id.reset_pwd_rel);
        this.reset_header = (RelativeLayout) findViewById(R.id.reset_header);
        this.reset_txt = (TextView) findViewById(R.id.reset_txt);
        this.resetpwd_back_arrow = (RelativeLayout) findViewById(R.id.resetpwd_back_arrow);
        this.pwd_reset_et = (EditText) findViewById(R.id.pwd_reset_et);
        this.conform_reset_et = (EditText) findViewById(R.id.conform_reset_et);
        this.save_btn = (Button) findViewById(R.id.save_btn);
        this.save_rel = (RelativeLayout) findViewById(R.id.save_rel);
        this.save_header_rel = (RelativeLayout) findViewById(R.id.save_header_rel);
        this.save_back_rel = (RelativeLayout) findViewById(R.id.save_back_rel);
        this.save_headettxt = (TextView) findViewById(R.id.save_headettxt);
        this.save_txt = (TextView) findViewById(R.id.save_txt);
        this.name_save_et = (EditText) findViewById(R.id.name_save_et);
        this.pwd_save_et = (EditText) findViewById(R.id.pwd_save_et);
        this.conform_save_et = (EditText) findViewById(R.id.conform_save_et);
        this.view_pager_rel = (RelativeLayout) findViewById(R.id.view_pager_rel);
        this.pageView = (ViewPager) findViewById(R.id.pageView);
        this.viewpager_back_rel = (RelativeLayout) findViewById(R.id.viewpager_back_rel);
        this.viewpager_headettxt = (TextView) findViewById(R.id.viewpager_headettxt);
        this.view_pager_hader = (RelativeLayout) findViewById(R.id.view_pager_hader);
        this.setting_lock_rel = (RelativeLayout) findViewById(R.id.setting_lock_rel);
        this.new_hader = (RelativeLayout) findViewById(R.id.new_hader);
        this.new_back_rel = (RelativeLayout) findViewById(R.id.new_back_rel);
        this.new_headettxt = (TextView) findViewById(R.id.new_headettxt);
        this.pwd_settig_txt_set = (TextView) findViewById(R.id.pwd_settig_txt_set);
        this.change_pwd__txt_set = (TextView) findViewById(R.id.change_pwd__txt_set);
        this.touchid_txt_set = (TextView) findViewById(R.id.touchid_txt_set);
        this.background_txt_set = (TextView) findViewById(R.id.background_txt_set);
        this.image_txt_set = (TextView) findViewById(R.id.image_txt_set);
        this.color_txt_set = (TextView) findViewById(R.id.color_txt_set);
        this.break_in_alert_set = (TextView) findViewById(R.id.break_in_alert_set);
        this.break_in_alert__list_set = (TextView) findViewById(R.id.break_in_alert__list_set);
        this.sorting_txt_set = (TextView) findViewById(R.id.sorting_txt_set);
        this.ascending = (TextView) findViewById(R.id.ascending);
        this.descending = (TextView) findViewById(R.id.descending);
        this.touch_rel = (RelativeLayout) findViewById(R.id.touch_rel);
        this.toggleButton = (ToggleButton) findViewById(R.id.tb);
        this.forget_pwd_folder_list = (RelativeLayout) findViewById(R.id.forgert_pwd_folder_list);
        this.listview_forget_pwd = (ListView) findViewById(R.id.listview_forget_pwd);
        this.cancle_rel_forget_pwd = (TextView) findViewById(R.id.cancle_rel_forget_pwd);
        this.done_rel_forget_pwd = (TextView) findViewById(R.id.done_rel_forget_pwd);
        this.popup_txt_forget_pwd = (TextView) findViewById(R.id.popup_txt_forget_pwd);
        this.dialog_box_email_rel = (RelativeLayout) findViewById(R.id.dialog_box_email_rel);
        this.mail_et_set = (EditText) findViewById(R.id.mail_et_set);
        this.save_set_rel = (TextView) findViewById(R.id.save_set_rel);
        this.cancle_set_rel = (TextView) findViewById(R.id.cancle_set_rel);
        this.dialog_box_bg = (RelativeLayout) findViewById(R.id.dialog_box_bg);
        this.forget_pwd_txt = (TextView) findViewById(R.id.forget_pwd_txt);
        this.dialog_box_forget_rel = (RelativeLayout) findViewById(R.id.dialog_box_forget_rel);
        this.enter_email_forget_txt = (TextView) findViewById(R.id.enter_email_forget_txt);
        this.ok_forget_rel = (TextView) findViewById(R.id.ok_forget_rel);
        this.cancle_forget_rel = (TextView) findViewById(R.id.cancle_forget_rel);
        this.mail_et_forget = (EditText) findViewById(R.id.mail_et_forget);
        this.dialog_box_passcode_rel = (RelativeLayout) findViewById(R.id.dialog_box_passcode_rel);
        this.passcode_txt = (TextView) findViewById(R.id.passcode_txt);
        this.ok_txt_passcode_rel = (TextView) findViewById(R.id.ok_txt_passcode_rel);
        this.recyleview_break = (RecyclerView) findViewById(R.id.recyleview_break);
        this.swipeMenuListView = (SwipeMenuListView) findViewById(R.id.cmn_list_view);
        this.break_in_alert_rel = (RelativeLayout) findViewById(R.id.break_in_alert_rel);
        this.break_in_alert_header_rel = (RelativeLayout) findViewById(R.id.break_in_alert_header_rel);
        this.Back_arrow = (RelativeLayout) findViewById(R.id.Break_back_arrow);
        this.forget_pwd_folder = (RelativeLayout) findViewById(R.id.forget_pwd_folder);
        this.forget_pwd_folder_arrow = (RelativeLayout) findViewById(R.id.forget_pwd_folder_arrow);
        this.forget_pwd_folder_header = (RelativeLayout) findViewById(R.id.forget_pwd_folder_header);
        this.forget_pwd_folder_txt = (TextView) findViewById(R.id.forget_pwd_folder_txt);
        this.rl_progressbar1 = (RelativeLayout) findViewById(R.id.rl_progressbar1);
        this.lock_rel_break = (RelativeLayout) findViewById(R.id.lock_rel_break);
        this.lock_rel_break_header = (RelativeLayout) findViewById(R.id.lock_rel_break_header);
        this.lock_rel_break_arrow = (RelativeLayout) findViewById(R.id.lock_rel_break_arrow);
        this.lock_rel_break_txt = (TextView) findViewById(R.id.lock_rel_break_txt);
        this.person_imgview = (ImageView) findViewById(R.id.person_imgview);
        txt_privacy = findViewById(R.id.txt_privacy);
        txt_share = findViewById(R.id.txt_share);
        txt_rateus = findViewById(R.id.txt_rate);
        if (VERSION.SDK_INT >= 23) {
            this.touch_rel.setVisibility(View.VISIBLE);
            if (getSharedPreferences("FIGUARE_PRINT", 0).getBoolean("figuare_print", false)) {
                this.toggleButton.setChecked(true);
            } else {
                this.toggleButton.setChecked(false);
            }
        } else {
            this.touch_rel.setVisibility(View.GONE);
        }
        if (this.mHiddenCameraFragment != null) {
            getSupportFragmentManager().beginTransaction().remove(this.mHiddenCameraFragment).commit();
            this.mHiddenCameraFragment = null;
        }
        this.mCameraConfig = new CameraConfig().getBuilder(this).setCameraFacing(1).setCameraResolution(2006)
                .setImageFormat(CameraImageFormat.FORMAT_JPEG).setImageRotation(CameraRotation.ROTATION_270).build();
        if (ActivityCompat.checkSelfPermission(this, Utils.permission.CAMERA) == 0) {
            startCamera(this.mCameraConfig);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Utils.permission.CAMERA}, 101);
        }
        if (first_time) {
            lock_rel.setVisibility(View.GONE);
        } else {
            background_lock();
            lock_rel.setVisibility(View.VISIBLE);
        }
        this.theme_type = getSharedPreferences("LOCK_THEME", 0).getString("lock_theme", "image");
        this.background_color = (ImageView) findViewById(R.id.background_color);
        this.image_bg = (ImageView) findViewById(R.id.image_bg);
        if (this.theme_type.equals("image")) {
            this.image_bg.setVisibility(View.VISIBLE);
            this.background_color.setVisibility(View.GONE);
            String previouslyEncodedImage = PreferenceManager.getDefaultSharedPreferences(this)
                    .getString("image_data", "");
            if (!previouslyEncodedImage.equalsIgnoreCase("")) {
                byte[] b = Base64.decode(previouslyEncodedImage, 0);
                this.image_bg.setBackground(new BitmapDrawable(getResources(), Utils.blur(getApplicationContext(),
                        BitmapFactory.decodeByteArray(b, 0, b.length))));
            }
        } else if (this.theme_type.equals("color")) {
            this.background_color.setBackgroundColor(Color.parseColor(getSharedPreferences("COLOR_THEME", 0)
                    .getString("color_theme", "#ff263237")));
            this.image_bg.setVisibility(View.GONE);
            this.background_color.setVisibility(View.VISIBLE);
        }
        this.theme_color = getSharedPreferences("COLOR_THEME", 0).getString("color_theme", "#ff263237");

        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/Mada-Medium.ttf");
        this.header.setTypeface(typeface);
        this.create_txt.setTypeface(typeface);
        this.create_headettxt.setTypeface(typeface);
        this.create_headettxt_gallery.setTypeface(typeface);
        this.import_photo_txt.setTypeface(typeface);
        this.takephoto_txt.setTypeface(typeface);
        this.select_txt_myvault.setTypeface(typeface);
        this.theme_header.setTypeface(typeface);
        this.ascending.setTypeface(typeface);
        this.descending.setTypeface(typeface);
        this.reset_txt.setTypeface(typeface);
        this.pwd_reset_et.setTypeface(typeface);
        this.conform_reset_et.setTypeface(typeface);
        this.save_btn.setTypeface(typeface);
        this.save_headettxt.setTypeface(typeface);
        this.save_txt.setTypeface(typeface);
        this.name_save_et.setTypeface(typeface);
        this.pwd_save_et.setTypeface(typeface);
        this.conform_save_et.setTypeface(typeface);
        this.viewpager_headettxt.setTypeface(typeface);
        this.change_pwd__txt_set.setTypeface(typeface);
        this.touchid_txt_set.setTypeface(typeface);
        this.image_txt_set.setTypeface(typeface);
        this.color_txt_set.setTypeface(typeface);
        this.break_in_alert__list_set.setTypeface(typeface);
        this.ascending.setTypeface(typeface);
        this.descending.setTypeface(typeface);
        this.forget_pwd_folder_txt.setTypeface(typeface);
        this.lock_rel_break_txt.setTypeface(typeface);
        Typeface typeface1 = Typeface.createFromAsset(getAssets(), "fonts/Mada-Regular.ttf");
        this.name_et.setTypeface(typeface1);
        this.pwd_et.setTypeface(typeface1);
        this.conform_et.setTypeface(typeface1);
        this.new_headettxt.setTypeface(typeface1);
        this.pwd_settig_txt_set.setTypeface(typeface1);
        this.background_txt_set.setTypeface(typeface1);
        this.break_in_alert_set.setTypeface(typeface1);
        this.sorting_txt_set.setTypeface(typeface1);
        this.forget_pwd_txt.setTypeface(typeface1);
        this.passcode_txt.setTypeface(typeface1);
        this.ok_txt_passcode_rel.setTypeface(typeface1);
        final File[] mydir = {new File(Environment.getExternalStorageDirectory() + "/Photo Vault/")};
        if (mydir[0].exists()) {
        } else {
            mydir[0].mkdirs();
        }
        this.path = Environment.getExternalStorageDirectory().toString() + "/Photo Vault/";
        File mydir2 = new File(this.path + "first album");
        if (!mydir2.exists()) {
            mydir2.mkdirs();
        }
        final File[][] list = {new File(Environment.getExternalStorageDirectory().toString()
                + "/Photo Vault").listFiles()};
        this.arrayList_floder.clear();
        for (File name : list[0]) {
            ModelFolder client = new ModelFolder();
            client.setName(name.getName());
            client.setPwd("");
            this.arrayList_floder.add(client);
        }
        this.forget_pwd_txt.setOnClickListener(new Click4());
        this.ok_forget_rel.setOnClickListener(new Click6());
        this.cancle_forget_rel.setOnClickListener(new Click8());
        this.ok_txt_passcode_rel.setOnClickListener(new Click9());
        this.order = getSharedPreferences("ODER", 0).getString("oder", "asc");
        if (this.order.equals("asc")) {
            ascending_order();
        } else {
            dcesending_order();
        }
        this.setting_icon_rel.setOnClickListener(new SettingClick());
        this.resetpwd_back_arrow.setOnClickListener(new Click());
        this.save_btn.setOnClickListener(new Click1());
        this.theme_back_arrow.setOnClickListener(new Click2());
        this.theme_done_arrow.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                for (int i = 0; i < Vault_folder.this.color_theme.length; i++) {
                    Model client = new Model();
                    client.setIsselected(false);
                    Vault_folder.this.checkmark_status.add(client);
                }
                Editor editor = Vault_folder.this.getSharedPreferences("COLOR_THEME", 0).edit();
                editor.putString("color_theme", Vault_folder.this.theme_color);
                editor.commit();
                Vault_folder.this.theme_rel.setVisibility(View.GONE);
                Vault_folder.this.setting_icon_rel.setVisibility(View.VISIBLE);
            }
        });
        this.ascending.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(Vault_folder.this, "Folder is Sorted", Toast.LENGTH_SHORT).show();
                Editor editor = Vault_folder.this.getSharedPreferences("ODER", 0).edit();
                editor.putString("oder", "asc");
                editor.commit();
                Vault_folder.this.ascending_order();
            }
        });

        this.descending.setOnClickListener(new OnClickListener() {
            @SuppressLint("ApplySharedPref")
            public void onClick(View view) {
                Toast.makeText(Vault_folder.this, "Folder is Sorted", Toast.LENGTH_SHORT).show();
                Editor editor = Vault_folder.this.getSharedPreferences("ODER", 0).edit();
                editor.putString("oder", "des");
                editor.commit();
                Vault_folder.this.dcesending_order();
            }
        });

        this.create_directory_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.create_rel.setVisibility(View.VISIBLE);
            }
        });

        this.create_txt.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (Vault_folder.this.name_et.getText().toString().equals("")) {
                    Vault_folder.this.name_et.setError("Enter Name");
                } else if (Vault_folder.this.pwd_et.getText().toString().equals(null) && conform_et.getText().toString()
                        .equals(null)) {
                    Editor editor = Vault_folder.this.getSharedPreferences(name_et.getText().toString(), 0).edit();
                    editor.putString("pwd", Vault_folder.this.pwd_et.getText().toString());
                    editor.commit();
                    Vault_folder.this.create_rel.setVisibility(View.GONE);
                    mydir[0] = new File(Vault_folder.this.path + Vault_folder.this.name_et.getText().toString());
                    if (mydir[0].exists()) {
                        Toast.makeText(Vault_folder.this, "Same Name Folder Exits", Toast.LENGTH_SHORT).show();
                    } else {
                        mydir[0].mkdirs();
                    }
                    list[0] = new File(Environment.getExternalStorageDirectory().toString()
                            + "/Photo Vault").listFiles();
                    Vault_folder.this.arrayList_floder.clear();
                    for (File name : list[0]) {
                        ModelFolder client = new ModelFolder();
                        client.setName(name.getName());
                        client.setPwd("");
                        Vault_folder.this.arrayList_floder.add(client);
                    }
                    if (Vault_folder.this.order.equals("asc")) {
                        Vault_folder.this.ascending_order();
                    } else {
                        Vault_folder.this.dcesending_order();
                    }
                    GridLayoutManager gridLayoutManager = new GridLayoutManager(Vault_folder.this, 2);
                    Allfilelist adapter2 = new Allfilelist(Vault_folder.this, Vault_folder.this.arrayList_floder);
                    Vault_folder.this.rv_gallery.setLayoutManager(gridLayoutManager);
                    Vault_folder.this.rv_gallery.setAdapter(adapter2);
                    Vault_folder.this.name_et.setText("");
                    Vault_folder.this.pwd_et.setText("");
                    Vault_folder.this.conform_et.setText("");
                    Vault_folder.this.hideSoftKeyboard();
                } else if (Vault_folder.this.pwd_et.getText().toString().equals(conform_et.getText().toString())) {
                    Editor editor = Vault_folder.this.getSharedPreferences(name_et.getText().toString(), 0).edit();
                    editor.putString("pwd", Vault_folder.this.pwd_et.getText().toString());
                    editor.commit();
                    Vault_folder.this.create_rel.setVisibility(View.GONE);
                    mydir[0] = new File(Vault_folder.this.path + Vault_folder.this.name_et.getText().toString());
                    if (mydir[0].exists()) {
                        Toast.makeText(Vault_folder.this, "Same Name Folder Exits", Toast.LENGTH_SHORT).show();
                    } else {
                        mydir[0].mkdirs();
                    }
                    list[0] = new File(Environment.getExternalStorageDirectory().toString()
                            + "/Photo Vault").listFiles();
                    Vault_folder.this.arrayList_floder.clear();
                    for (File name2 : list[0]) {
                        ModelFolder client = new ModelFolder();
                        client.setName(name2.getName());
                        client.setPwd("");
                        Vault_folder.this.arrayList_floder.add(client);
                    }
                    if (Vault_folder.this.order.equals("asc")) {
                        Vault_folder.this.ascending_order();
                    } else {
                        Vault_folder.this.dcesending_order();
                    }
                    GridLayoutManager gridLayoutManager = new GridLayoutManager(Vault_folder.this, 2);
                    Allfilelist adapter2 = new Allfilelist(Vault_folder.this, Vault_folder.this.arrayList_floder);
                    Vault_folder.this.rv_gallery.setLayoutManager(gridLayoutManager);
                    Vault_folder.this.rv_gallery.setAdapter(adapter2);
                    Vault_folder.this.name_et.setText("");
                    Vault_folder.this.pwd_et.setText("");
                    Vault_folder.this.conform_et.setText("");
                    Vault_folder.this.hideSoftKeyboard();
                } else {
                    Vault_folder.this.pwd_et.setError("Enter valid pwd");
                    Vault_folder.this.pwd_et.setText("");
                    Vault_folder.this.conform_et.setText("");
                }
            }
        });
        this.back_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.create_rel.setVisibility(View.GONE);
            }
        });
        this.back_rel_gallery.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.my_gallery_rel.setVisibility(View.GONE);
            }
        });
        this.import_photo_gallery.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.open_gallery_floating_btn.setVisibility(View.VISIBLE);
            }
        });

        txt_privacy.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent1 = new Intent(Intent.ACTION_VIEW);
                    intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                    startActivity(intent1);
                }catch (ActivityNotFoundException e)
                {
                    e.printStackTrace();
                }
            }
        });

        txt_rateus.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(getResources().getString(R.string.rate_us_url)
                                    + getPackageName())));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(Vault_folder.this, "You don't have Google Play installed",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        txt_share.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.share_msg) + getPackageName());
                startActivity(Intent.createChooser(share, "Share Via"));
            }
        });

        this.select_txt_mygallery.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.share.setAlpha(0.3f);
                Vault_folder.this.delete.setAlpha(0.3f);
                Vault_folder.this.move.setAlpha(0.3f);
                Vault_folder.this.select_img_header.setVisibility(View.VISIBLE);
                Vault_folder.this.funcation_rel.setVisibility(View.VISIBLE);
                Vault_folder.this.import_photo_gallery.setVisibility(View.GONE);
            }
        });
        this.back_selectimg_gallery.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                for (int i = 0; i < Vault_folder.this.status.size(); i++) {
                    ((Model) Vault_folder.this.status.get(i)).setIsselected(false);
                }
                Vault_folder.this.select_txt_myvault.setText("Selected");
                Vault_folder.this.f32f.clear();
                int mNoOfColumns = Utility.calculateNoOfColumns(Vault_folder.this.getApplicationContext());
                Vault_folder.this.getFromSdcard();
                GridLayoutManager gridLayoutManager;
                Allfilelist3 adapter2;
                if (Vault_folder.this.f32f.size() == 0) {
                    if (Vault_folder.this.order.equals("asc")) {
                        Vault_folder.this.ascending_order();
                    } else {
                        Vault_folder.this.dcesending_order();
                    }
                    Vault_folder.this.select_txt_mygallery.setEnabled(false);
                    Vault_folder.this.select_txt_mygallery.setTextColor(Color.parseColor("#65696d"));
                    gridLayoutManager = new GridLayoutManager(Vault_folder.this, mNoOfColumns);
                    adapter2 = new Allfilelist3(Vault_folder.this, Vault_folder.this.f32f);
                    Vault_folder.this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                    Vault_folder.this.recyclerView_vault.setAdapter(adapter2);
                } else {
                    if (Vault_folder.this.order.equals("asc")) {
                        Vault_folder.this.ascending_order();
                    } else {
                        Vault_folder.this.dcesending_order();
                    }
                    Vault_folder.this.select_txt_mygallery.setEnabled(true);
                    Vault_folder.this.select_txt_mygallery.setTextColor(Color.parseColor("#ffffff"));
                    gridLayoutManager = new GridLayoutManager(Vault_folder.this, mNoOfColumns);
                    adapter2 = new Allfilelist3(Vault_folder.this, Vault_folder.this.f32f);
                    Vault_folder.this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                    Vault_folder.this.recyclerView_vault.setAdapter(adapter2);
                }
                Vault_folder.this.funcation_rel.setVisibility(View.GONE);
                Vault_folder.this.select_img_header.setVisibility(View.GONE);
                Vault_folder.this.import_photo_gallery.setVisibility(View.VISIBLE);
                Vault_folder.this.hideSoftKeyboard();
            }
        });
        this.gallery_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.open_gallery_floating_btn.setVisibility(View.GONE);
                Vault_folder.this.gallery_phone_rel.setVisibility(View.VISIBLE);
                new LoadAllFolder().execute(new String[0]);
            }
        });
        this.camera_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.lock_screen_share_status = true;
                Vault_folder.this.cameraIntent();
            }
        });
        this.open_gallery_btn_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.open_gallery_floating_btn.setVisibility(View.GONE);
            }
        });
        this.save_back_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.save_rel.setVisibility(View.GONE);
            }
        });
        this.viewpager_back_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.view_pager_rel.setVisibility(View.GONE);
            }
        });
        this.new_back_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.setting_lock_rel.setVisibility(View.GONE);
            }
        });
        this.image_txt_set.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.lock_screen_share_status = true;
                Vault_folder.this.galleryIntent();
            }
        });
        this.color_txt_set.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                for (int i = 0; i < Vault_folder.this.color_theme.length; i++) {
                    Model client = new Model();
                    client.setIsselected(false);
                    Vault_folder.this.checkmark_status.add(client);
                }
                GridLayoutManager lLayout = new GridLayoutManager(Vault_folder.this, 4);
                Vault_folder.this.recyleview_theme.setHasFixedSize(true);
                Vault_folder.this.recyleview_theme.setLayoutManager(lLayout);
                Vault_folder.this.recyleview_theme.setAdapter(new MoviesAdapter(Vault_folder.this.color_theme));
                Vault_folder.this.theme_rel.setVisibility(View.VISIBLE);
            }
        });

        change_question_layout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Vault_folder.this, FirstTimeSecurityActivity.class);
                intent.putExtra("Change_security Question", "Change_security Question");
                startActivity(intent);
                finish();
            }
        });

        this.change_pwd__txt_set.setOnClickListener(new OnClickListener() {

            class AdapterCall implements AdapterCallback {
                AdapterCall() {
            }

            public void onItemClicked(boolean ismatch) {
                if (ismatch) {
                        Vault_folder.this.reset_pwd_rel.setVisibility(View.VISIBLE);
                }
            }
        }

            public void onClick(View view) {
                Vault_folder.this.background_lock();
                Vault_folder.lock_rel.setVisibility(View.VISIBLE);
                Vault_folder.this.callback = new AdapterCall();
            }
        });


        this.toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    FingerprintManager fingerprintManager = (FingerprintManager) getSystemService(FINGERPRINT_SERVICE);
                    if (!fingerprintManager.isHardwareDetected()) {
                        Vault_folder.this.toggleButton.setChecked(false);
                        Toast.makeText(Vault_folder.this, "This Devices does not supported fingerprint feature",
                                Toast.LENGTH_LONG).show();
                    } else if (ActivityCompat.checkSelfPermission(Vault_folder.this,
                            Manifest.permission.USE_FINGERPRINT) != 0) {
                        Vault_folder.this.toggleButton.setChecked(false);
                        Vault_folder.this.startActivityForResult(new Intent("android.settings.SETTINGS"), 0);

                    } else if (!fingerprintManager.hasEnrolledFingerprints()) {
                        Vault_folder.this.toggleButton.setChecked(false);
                        Vault_folder.this.startActivityForResult(new Intent("android.settings.SETTINGS"), 0);
                    } else if (b) {
                        Toast.makeText(Vault_folder.this, "TouchID set Successfully", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(Vault_folder.this, "TouchID not set", Toast.LENGTH_LONG).show();
                    }
                    Editor editor = Vault_folder.this.getSharedPreferences("FIGUARE_PRINT", 0).edit();
                    editor.putBoolean("figure_print", b);
                    editor.commit();
                }
            }
        });

        this.forget_pwd_folder_arrow.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.forget_pwd_folder.setVisibility(View.GONE);
            }
        });


        this.cancle_rel_forget_pwd.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                for (int i = 0; i < Vault_folder.this.arrayList_floder.size(); i++) {
                    Model client1 = new Model();
                    client1.setIsselected(false);
                    Vault_folder.this.status_select_namefolder.add(client1);
                }
                listview_forget_pwd.setAdapter(new ImageAdapterRules_forget(arrayList_floder));
                Vault_folder.this.forget_pwd_folder_list.setVisibility(View.GONE);
            }
        });
        this.done_rel_forget_pwd.setOnClickListener(new OnClickListener() {

            class C06431 extends Thread {
                C06431() {
                }
            }

            @SuppressLint({"LongLogTag"})
            public void onClick(View view) {
                Vault_folder.this.forget_pwd_folder_list.setVisibility(View.GONE);
                new C06431().start();
            }
        });
        this.save_set_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String email = getSharedPreferences("MAIL_TXT", 0).getString("mail_txt", "");
                final String str_email = Vault_folder.this.mail_et_set.getText().toString();
                if (str_email.equals("")) {
                    Vault_folder.this.mail_et_set.setError("Enter E-Mail");
                } else if (str_email.equals(email)) {
                    Vault_folder.this.dialog_box_email_rel.setVisibility(View.GONE);
                } else {
                    Vault_folder.this.hideSoftKeyboard();
                    Vault_folder.this.background_lock();
                    Vault_folder.lock_rel.setVisibility(View.VISIBLE);
                    Vault_folder.this.callback = new AdapterCallback() {
                        public void onItemClicked(boolean ismatch) {
                            if (ismatch) {
                                Editor editor = Vault_folder.this.getSharedPreferences("MAIL_TXT", 0).edit();
                                editor.putString("mail_txt", Vault_folder.this.mail_et_set.getText().toString());
                                editor.commit();
                                Vault_folder.this.mail_et_set.setText(str_email);
                                Vault_folder.this.dialog_box_email_rel.setVisibility(View.GONE);
                                Vault_folder.this.hideSoftKeyboard();
                            }
                        }
                    };
                }
            }
        });
        this.cancle_set_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.dialog_box_email_rel.setVisibility(View.GONE);
                Vault_folder.this.hideSoftKeyboard();
            }
        });
        this.break_in_alert__list_set.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.jjs.clear();
                if (LockScreenActivity.break_data_array == null) {
                    LockScreenActivity.break_data_array = new ArrayList();
                }
                for (int i = 0; i < LockScreenActivity.break_data_array.size(); i++) {
                    File imgFile = new File(((BreakModel) LockScreenActivity.break_data_array.get(i)).getPath_break());
                    BreakModel b = new BreakModel();
                    b.setDate(((BreakModel) LockScreenActivity.break_data_array.get(i)).getDate());
                    b.setPassword(((BreakModel) LockScreenActivity.break_data_array.get(i)).getPassword());
                    b.setLat(((BreakModel) LockScreenActivity.break_data_array.get(i)).getLat());
                    b.setLang(((BreakModel) LockScreenActivity.break_data_array.get(i)).getLang());
                    b.setFile(imgFile);
                    Vault_folder.this.jjs.add(b);
                }
                Collections.reverse(Vault_folder.this.jjs);
                Vault_folder.this.listAdapter = new ListAdapter(Vault_folder.this, Vault_folder.this.jjs);
                Vault_folder.this.swipeMenuListView.setAdapter(Vault_folder.this.listAdapter);
                Vault_folder.this.break_in_alert_rel.setVisibility(View.VISIBLE);
            }
        });
        this.swipeMenuListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Vault_folder.this.lock_rel_break.setVisibility(View.VISIBLE);
                Picasso.with(Vault_folder.this.getApplicationContext())
                        .load(((BreakModel) Vault_folder.this.jjs.get(position)).getFile())
                        .resize(Callback.DEFAULT_DRAG_ANIMATION_DURATION, Callback.DEFAULT_DRAG_ANIMATION_DURATION)
                        .centerCrop().into(Vault_folder.this.person_imgview);
                Vault_folder.this.showmap(((BreakModel) Vault_folder.this.jjs.get(position)).getLat(),
                        ((BreakModel) Vault_folder.this.jjs.get(position)).getLang());
            }
        });
        this.Back_arrow.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.break_in_alert_rel.setVisibility(View.GONE);
            }
        });
        this.swipeMenuListView.setMenuCreator(new SwipeMenuCreator() {
            public void create(SwipeMenu menu) {
                SwipeMenuItem deleteItem = new SwipeMenuItem(Vault_folder.this.getApplicationContext());
                deleteItem.setBackground(new ColorDrawable(Color.rgb(140, 108, 235)));
                deleteItem.setWidth(Vault_folder.this.dp2px(100));
                deleteItem.setIcon(R.drawable.icon_delete);
                menu.addMenuItem(deleteItem);
            }
        });
        this.swipeMenuListView.setOnMenuItemClickListener(new OnMenuItemClickListener() {

            class ScanClick implements OnScanCompletedListener {
                ScanClick() {
                }

                public void onScanCompleted(String path, Uri uri) {
                }
            }

            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:
                        File file = ((BreakModel) Vault_folder.this.jjs.get(position)).getFile();
                        if (file.exists()) {
                            file.delete();
                            if (file.exists()) {
                                try {
                                    file.getCanonicalFile().delete();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                if (file.exists()) {
                                    Vault_folder.this.getApplicationContext().deleteFile(file.getName());
                                }
                            }
                            MediaScannerConnection.scanFile(Vault_folder.this, new String[]{file.toString()},
                                    null, new ScanClick());
                            LockScreenActivity.break_data_array.remove(position);
                            Vault_folder.this.jjs.remove(position);
                            if (Vault_folder.this.listAdapter != null) {
                                Vault_folder.this.listAdapter.notifyDataSetChanged();
                            }
                            Editor editor = Vault_folder.this.getSharedPreferences("naimee", 0).edit();
                            editor.putString("patel", new Gson().toJson(LockScreenActivity.break_data_array));
                            editor.commit();
                            break;
                        }
                        break;
                }
                return true;
            }
        });
        this.swipeMenuListView.setOnMenuStateChangeListener(new OnMenuStateChangeListener() {
            public void onMenuOpen(int position) {
            }

            public void onMenuClose(int position) {
            }
        });
        this.swipeMenuListView.setOnSwipeListener(new OnSwipeListener() {
            public void onSwipeStart(int position) {
            }

            public void onSwipeEnd(int position) {
            }
        });
        this.lock_rel_break_arrow.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Vault_folder.this.lock_rel_break.setVisibility(View.GONE);
            }
        });
        this.album_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        lock_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.theme_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.reset_pwd_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.create_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.my_gallery_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.open_gallery_floating_btn.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.gallery_phone_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.pwd_rel_folder.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.view_pager_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.setting_lock_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.dialog_box_email_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.lock_rel_break.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.forget_pwd_folder.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.funcation_rel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.funcation_rel.setEnabled(false);
        this.delete_img_rel.setEnabled(false);
        this.move_img_rel.setEnabled(false);
        this.share_img_rel.setEnabled(false);
    }

    class PinLock implements PinLockListener {

        class RunnableHandler implements Runnable {
            RunnableHandler() {
            }

            public void run() {
                Vault_folder.this.takePicture();
            }
        }

        PinLock() {
        }

        public void onComplete(String pin) {
            SharedPreferences prefs4 = Vault_folder.this.getSharedPreferences("SCREEN_PWD", 0);
            Vault_folder.this.passcode = prefs4.getString("pwd", "");
            if (Vault_folder.this.passcode.equals(pin)) {
                if (Vault_folder.this.callback != null) {
                    Vault_folder.this.callback.onItemClicked(true);
                }
                Vault_folder.lock_rel.setVisibility(View.GONE);
            } else {
                Vault_folder.this.worng_passcode = pin;
                new Handler().postDelayed(new RunnableHandler(), 200);
                ((Vibrator) Vault_folder.this.getSystemService(VIBRATOR_SERVICE)).vibrate(700);
            }
            Vault_folder.this.mPinLockView.resetPinLockView();
        }

        public void onEmpty() {
        }

        public void onPinChange(int pinLength, String intermediatePin) {
        }
    }

    public interface AdapterCallback {
        void onItemClicked(boolean z);
    }

    class Click4 implements OnClickListener {

        class C06371 implements DialogInterface.OnClickListener {
            C06371() {
            }

            public void onClick(DialogInterface dialog, int which) {
            }
        }

        Click4() {
        }

        public void onClick(View view) {
            if (Vault_folder.this.getSharedPreferences("MAIL_TXT", 0).getString("mail_txt",
                    "").equals("")) {
                Builder alertDialog = new Builder(Vault_folder.this);
                alertDialog.setTitle("PhotoVault!");
                alertDialog.setMessage("Sorry! you have not set email id. so you can not recover your password.");
                alertDialog.setPositiveButton("OK", new C06371());
                alertDialog.show();
                return;
            }
            Vault_folder.this.dialog_box_forget_rel.setVisibility(View.VISIBLE);
        }
    }

    class Click6 implements OnClickListener {
        Click6() {
        }

        @SuppressLint("SetTextI18n")
        public void onClick(View view) {
            String email = Vault_folder.this.getSharedPreferences("MAIL_TXT", 0).getString("mail_txt",
                    "Enter Email");
            String passcode = Vault_folder.this.getSharedPreferences("SCREEN_PWD", 0).getString("pwd",
                    "");
            if (email.equals(Vault_folder.this.mail_et_set.getText().toString())) {
                Vault_folder.this.passcode_txt.setText("Your Passcode is " + passcode);
                Vault_folder.this.dialog_box_passcode_rel.setVisibility(View.VISIBLE);
                Vault_folder.this.hideSoftKeyboard();
                return;
            }
            Vault_folder.this.mail_et_set.setError("Enter Vaild Email");
        }
    }

    class Click8 implements OnClickListener {
        Click8() {
        }

        public void onClick(View view) {
            Vault_folder.this.dialog_box_email_rel.setVisibility(View.GONE);
            Vault_folder.this.hideSoftKeyboard();
        }
    }

    class Click9 implements OnClickListener {
        Click9() {
        }

        public void onClick(View view) {
            Vault_folder.this.dialog_box_passcode_rel.setVisibility(View.GONE);
            Vault_folder.this.dialog_box_forget_rel.setVisibility(View.GONE);
        }
    }

    class SettingClick implements OnClickListener {

        class SettingAdapter implements AdapterCallback {
            SettingAdapter() {
            }

            public void onItemClicked(boolean ismatch) {
                if (ismatch) {
                    Vault_folder.this.setting_lock_rel.setVisibility(View.VISIBLE);
                }
            }
        }

        SettingClick() {
        }

        @SuppressLint("NewApi")
        public void onClick(View view) {
            Vault_folder.this.background_lock();
            Vault_folder.lock_rel.setVisibility(View.VISIBLE);
            Vault_folder.this.callback = new SettingAdapter();
        }
    }

    class Click implements OnClickListener {
        Click() {
        }

        public void onClick(View view) {
            Vault_folder.this.reset_pwd_rel.setVisibility(View.GONE);
            Vault_folder.this.hideSoftKeyboard();
        }
    }

    class Click1 implements OnClickListener {
        Click1() {
        }

        public void onClick(View view) {
            if (!pwd_reset_et.getText().toString().equals(Vault_folder.this.conform_reset_et.getText().toString())) {
                Vault_folder.this.pwd_reset_et.setError("Password not match");
                Vault_folder.this.conform_reset_et.setError("conform not match");
                Vault_folder.this.pwd_reset_et.setText("");
                Vault_folder.this.conform_reset_et.setText("");
            } else if (Vault_folder.this.pwd_reset_et.length() == 4 && Vault_folder.this.conform_reset_et.length() == 4) {
                Editor editor = Vault_folder.this.getSharedPreferences("SCREEN_PWD", 0).edit();
                editor.putString("pwd", Vault_folder.this.pwd_reset_et.getText().toString());
                editor.commit();
                Vault_folder.this.pwd_reset_et.setText("");
                Vault_folder.this.conform_reset_et.setText("");
                Vault_folder.this.reset_pwd_rel.setVisibility(View.GONE);
                Vault_folder.this.hideSoftKeyboard();
            } else {
                Vault_folder.this.pwd_reset_et.setError("Enter 4 no");
                Vault_folder.this.conform_reset_et.setError("Enter 4 no");
                Vault_folder.this.pwd_reset_et.setText("");
                Vault_folder.this.conform_reset_et.setText("");
            }
        }
    }

    class Click2 implements OnClickListener {
        Click2() {
        }

        public void onClick(View view) {
            Vault_folder.this.theme_rel.setVisibility(View.GONE);
            Vault_folder.this.setting_icon_rel.setVisibility(View.VISIBLE);
            Vault_folder.this.hideSoftKeyboard();
        }
    }

    public class Allfilelist2 extends RecyclerView.Adapter<Allfilelist2.MyviewHolder> {
        private Context activity;
        ArrayList<Model> arrayList1;

        class Click3 implements OnClickListener {

            class Dialog1 implements DialogInterface.OnClickListener {

                class C06651 implements OnScanCompletedListener {
                    C06651() {
                    }

                    public void onScanCompleted(String path, Uri uri) {
                    }
                }

                Dialog1() {
                }

                public void onClick(DialogInterface arg0, int arg1) {
                    for (int i = 0; i < Allfilelist2.this.arrayList1.size(); i++) {
                        if (((Model) Allfilelist2.this.arrayList1.get(i)).isselected()) {
                            File imgFile = new File(((Model) Allfilelist2.this.arrayList1.get(i)).getPath());
                            if (imgFile.exists()) {
                                imgFile.delete();
                                MediaScannerConnection.scanFile(Vault_folder.this, new String[]{imgFile.toString()},
                                        null, new C06651());
                            }
                        }
                    }
                }
            }

            class Dialo2 implements DialogInterface.OnClickListener {
                Dialo2() {
                }

                public void onClick(DialogInterface dialog, int which) {
                }
            }

            Click3() {
            }

            public void onClick(View view) {
                for (int i = 0; i < Allfilelist2.this.arrayList1.size(); i++) {
                    if (((Model) Allfilelist2.this.arrayList1.get(i)).isselected()) {
                        Vault_folder.this.SaveImage(BitmapFactory.decodeFile(new File(((Model) Allfilelist2.this.
                                arrayList1.get(i)).getPath()).getAbsolutePath()), Vault_folder.this.store_path);
                    }
                }
                Builder alertDialogBuilder = new Builder(Vault_folder.this);
                alertDialogBuilder.setMessage("Are you sure, You wanted to Delete Image from gallery");
                alertDialogBuilder.setPositiveButton("yes", new Dialog1());
                alertDialogBuilder.setNegativeButton("No", new Dialo2());
                alertDialogBuilder.create().show();
                int mNoOfColumns = Utility.calculateNoOfColumns(Vault_folder.this.getApplicationContext());
                Vault_folder.this.f32f.clear();
                Vault_folder.this.getFromSdcard();
                GridLayoutManager gridLayoutManager;
                Allfilelist3 adapter2;
                if (Vault_folder.this.f32f.size() == 0) {
                    Vault_folder.this.select_txt_mygallery.setEnabled(false);
                    Vault_folder.this.select_txt_mygallery.setTextColor(Color.parseColor("#65696d"));
                    gridLayoutManager = new GridLayoutManager(Vault_folder.this, mNoOfColumns);
                    adapter2 = new Allfilelist3(Vault_folder.this, Vault_folder.this.f32f);
                    Vault_folder.this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                    Vault_folder.this.recyclerView_vault.setAdapter(adapter2);
                } else {
                    Vault_folder.this.select_txt_mygallery.setEnabled(true);
                    Vault_folder.this.select_txt_mygallery.setTextColor(Color.parseColor("#ffffff"));
                    gridLayoutManager = new GridLayoutManager(Vault_folder.this, mNoOfColumns);
                    adapter2 = new Allfilelist3(Vault_folder.this, Vault_folder.this.f32f);
                    Vault_folder.this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                    Vault_folder.this.recyclerView_vault.setAdapter(adapter2);
                }
                Vault_folder.this.my_gallery_rel.setVisibility(View.VISIBLE);
                Vault_folder.this.gallery_phone_rel.setVisibility(View.GONE);
            }
        }

        public class MyviewHolder extends RecyclerView.ViewHolder {
            ImageView galleryImage;
            ImageView gallerybackImage;
            ImageView selecte_img;

            public MyviewHolder(View view) {
                super(view);
                this.gallerybackImage = (ImageView) view.findViewById(R.id.gallerybackImage);
                this.galleryImage = (ImageView) view.findViewById(R.id.galleryImage);
                this.selecte_img = (ImageView) view.findViewById(R.id.selecte_img);
            }
        }

        public Allfilelist2(Context a, ArrayList<Model> arrayList) {
            this.activity = a;
            this.arrayList1 = arrayList;
        }

        public MyviewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new MyviewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.single_album_row, parent,
                    false));
        }

        public void onBindViewHolder(MyviewHolder holder, final int position) {
            if (((Model) this.arrayList1.get(position)).isselected()) {
                holder.gallerybackImage.setVisibility(View.VISIBLE);
            } else {
                holder.gallerybackImage.setVisibility(View.GONE);
            }
            holder.galleryImage.setId(position);
            try {
                Glide.with(this.activity).load(new File(((Model) this.arrayList1.get(position)).getPath()))
                        .into(holder.galleryImage);
            } catch (Exception e) {
                e.printStackTrace();
            }
            holder.galleryImage.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    if (((Model) Allfilelist2.this.arrayList1.get(position)).isselected()) {
                        ((Model) Allfilelist2.this.arrayList1.get(position)).setIsselected(false);
                        Allfilelist2.this.notifyDataSetChanged();
                        return;
                    }
                    ((Model) Allfilelist2.this.arrayList1.get(position)).setIsselected(true);
                    Allfilelist2.this.notifyDataSetChanged();
                }
            });
            Vault_folder.this.done_txt.setOnClickListener(new Click3());
        }

        public int getItemCount() {
            return this.arrayList1.size();
        }
    }

    public class Allfilelist3 extends RecyclerView.Adapter<Allfilelist3.MyviewHolder> {
        private Context activity;
        ArrayList<String> filesToSend = new ArrayList();
        String path = "";
        ArrayList<String> path_array;

        class Click4 implements OnClickListener {
            Click4() {
            }

            public void onClick(View view) {
                Vault_folder.this.lock_screen_share_status = true;
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND_MULTIPLE");
                intent.putExtra("android.intent.extra.SUBJECT", "Here are some files.");
                intent.setType("image/jpeg");
                ArrayList<Uri> files = new ArrayList();
                Iterator it = Allfilelist3.this.filesToSend.iterator();
                while (it.hasNext()) {
                    files.add(FileProvider.getUriForFile(Vault_folder.this,
                            Vault_folder.this.getPackageName() + ".provider", new File((String) it.next())));
                }
                intent.putParcelableArrayListExtra("android.intent.extra.STREAM", files);
                Vault_folder.this.startActivity(intent);
                for (int i = 0; i < Vault_folder.this.status.size(); i++) {
                    ((Model) Vault_folder.this.status.get(i)).setIsselected(false);
                }
                Allfilelist3.this.notifyDataSetChanged();
                Vault_folder.this.funcation_rel.setVisibility(View.GONE);
                Vault_folder.this.select_img_header.setVisibility(View.GONE);
                Vault_folder.this.import_photo_gallery.setVisibility(View.VISIBLE);
            }
        }

        class Click5 implements OnClickListener {

            class C06711 implements DialogInterface.OnClickListener {
                C06711() {
                }

                public void onClick(DialogInterface arg0, int arg1) {
                    int i;
                    Log.e("status.size()", ":====" + status.size());
                    for (i = 0; i < Vault_folder.this.status.size(); i++) {
                        if (((Model) Vault_folder.this.status.get(i)).isselected()) {
                            ((Model) Vault_folder.this.status.get(i)).setIsselected(false);
                            Log.e("File path", ":====" + Allfilelist3.this.path_array.get(i));
                            new File((String) Allfilelist3.this.path_array.get(i)).delete();
                            Vault_folder.this.status.remove(Allfilelist3.this.path_array.get(i));
                        }
                    }

                    int mNoOfColumns = Utility.calculateNoOfColumns(Vault_folder.this.getApplicationContext());
                    Vault_folder.this.f32f.clear();
                    Vault_folder.this.getFromSdcard();
                    GridLayoutManager gridLayoutManager;
                    Allfilelist3 adapter2;
                    if (Vault_folder.this.f32f.size() == 0) {
                        Vault_folder.this.select_txt_mygallery.setEnabled(false);
                        Vault_folder.this.select_txt_mygallery.setTextColor(Color.parseColor("#65696d"));
                        gridLayoutManager = new GridLayoutManager(Vault_folder.this, mNoOfColumns);
                        adapter2 = new Allfilelist3(Vault_folder.this, Vault_folder.this.f32f);
                        Vault_folder.this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                        Vault_folder.this.recyclerView_vault.setAdapter(adapter2);
                    } else {
                        Vault_folder.this.select_txt_mygallery.setEnabled(true);
                        Vault_folder.this.select_txt_mygallery.setTextColor(Color.parseColor("#ffffff"));
                        gridLayoutManager = new GridLayoutManager(Vault_folder.this, mNoOfColumns);
                        adapter2 = new Allfilelist3(Vault_folder.this, Vault_folder.this.f32f);
                        Vault_folder.this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                        Vault_folder.this.recyclerView_vault.setAdapter(adapter2);
                    }
                    Vault_folder.this.funcation_rel.setVisibility(View.GONE);
                    Vault_folder.this.select_img_header.setVisibility(View.GONE);
                    Vault_folder.this.import_photo_gallery.setVisibility(View.VISIBLE);
                }
            }

            class Dialog3 implements DialogInterface.OnClickListener {
                Dialog3() {
                }

                public void onClick(DialogInterface dialog, int which) {
                }
            }

            Click5() {
            }

            public void onClick(View view) {
                Builder alertDialogBuilder = new Builder(Vault_folder.this);
                alertDialogBuilder.setMessage("Are you sure, You wanted to delete this Images?");
                alertDialogBuilder.setPositiveButton("yes", new C06711());
                alertDialogBuilder.setNegativeButton("No", new Dialog3());
                alertDialogBuilder.create().show();
            }
        }

        class Click6 implements OnClickListener {
            Click6() {
            }

            public void onClick(View view) {
                int i;
                int j = 0;
                for (i = 0; i < Allfilelist3.this.path_array.size(); i++) {
                    if (((Model) Vault_folder.this.status.get(i)).isselected()) {
                        j++;
                    }
                }
                if (j > 0) {
                    for (i = 0; i < Vault_folder.this.arrayList_floder.size(); i++) {
                        Model client1 = new Model();
                        client1.setIsselected(false);
                        Vault_folder.this.status_select_namefolder.add(client1);
                    }
                    Vault_folder.this.copy_layout_folder.setVisibility(View.VISIBLE);
                    Vault_folder.this.listview.setAdapter(new ImageAdapterRules(Vault_folder.this.arrayList_floder));
                } else {
                    Toast.makeText(Allfilelist3.this.activity, "Select Image", Toast.LENGTH_SHORT).show();
                }
                Vault_folder.this.funcation_rel.setVisibility(View.GONE);
                Vault_folder.this.select_img_header.setVisibility(View.GONE);
                Vault_folder.this.import_photo_gallery.setVisibility(View.VISIBLE);
            }
        }

        class Click7 implements OnClickListener {
            Click7() {
            }

            public void onClick(View view) {
                int i;
                Allfilelist3.this.path = Environment.getExternalStorageDirectory().toString() + "/Photo Vault/";
                for (i = 0; i < Vault_folder.this.status.size(); i++) {
                    if (((Model) Vault_folder.this.status.get(i)).isselected()) {
                        ((Model) Vault_folder.this.status.get(i)).setIsselected(false);
                        File file = new File((String) Allfilelist3.this.path_array.get(i));
                        Vault_folder.this.SaveImage(BitmapFactory.decodeFile(file.getAbsolutePath()),
                                Allfilelist3.this.path + Vault_folder.this.folder_name2);
                        file.delete();
                    }
                }
                Vault_folder.this.copy_layout_folder.setVisibility(View.GONE);
                for (i = 0; i < Vault_folder.this.status.size(); i++) {
                    ((Model) Vault_folder.this.status.get(i)).setIsselected(false);
                }
                Vault_folder.this.f32f.clear();
                int mNoOfColumns = Utility.calculateNoOfColumns(Vault_folder.this.getApplicationContext());
                Vault_folder.this.getFromSdcard();
                GridLayoutManager gridLayoutManager;
                Allfilelist3 adapter2;
                if (Vault_folder.this.f32f.size() == 0) {
                    Vault_folder.this.select_txt_mygallery.setEnabled(false);
                    Vault_folder.this.select_txt_mygallery.setTextColor(Color.parseColor("#65696d"));
                    gridLayoutManager = new GridLayoutManager(Vault_folder.this, mNoOfColumns);
                    adapter2 = new Allfilelist3(Vault_folder.this, Vault_folder.this.f32f);
                    Vault_folder.this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                    Vault_folder.this.recyclerView_vault.setAdapter(adapter2);
                } else {
                    Vault_folder.this.select_txt_mygallery.setEnabled(true);
                    Vault_folder.this.select_txt_mygallery.setTextColor(Color.parseColor("#ffffff"));
                    gridLayoutManager = new GridLayoutManager(Vault_folder.this, mNoOfColumns);
                    adapter2 = new Allfilelist3(Vault_folder.this, Vault_folder.this.f32f);
                    Vault_folder.this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                    Vault_folder.this.recyclerView_vault.setAdapter(adapter2);
                }
                for (i = 0; i < Vault_folder.this.status_select_namefolder.size(); i++) {
                    ((Model) Vault_folder.this.status_select_namefolder.get(i)).setIsselected(false);
                }
                Vault_folder.this.listview.setAdapter(new ImageAdapterRules(Vault_folder.this.arrayList_floder));
            }
        }

        class Click8 implements OnClickListener {
            Click8() {
            }

            public void onClick(View view) {
                for (int i = 0; i < Vault_folder.this.status.size(); i++) {
                    ((Model) Vault_folder.this.status.get(i)).setIsselected(false);
                }
                Allfilelist3.this.notifyDataSetChanged();
                Vault_folder.this.copy_layout_folder.setVisibility(View.GONE);
                Vault_folder.this.hideSoftKeyboard();
            }
        }

        public class MyviewHolder extends RecyclerView.ViewHolder {
            RelativeLayout selected_rel;
            ImageView vault_img;

            public MyviewHolder(View view) {
                super(view);
                this.vault_img = (ImageView) view.findViewById(R.id.vault_img);
                this.selected_rel = (RelativeLayout) view.findViewById(R.id.selected_rel);
                if (Vault_folder.this.theme_color.equals("#ff1e282d")) {
                    this.selected_rel.setBackgroundColor(Color.parseColor("#904d8ce7"));
                } else if (Vault_folder.this.theme_color.equals("#4CE799")) {
                    this.selected_rel.setBackgroundColor(Color.parseColor("#904CE799"));
                } else if (Vault_folder.this.theme_color.equals("#F41D2C")) {
                    this.selected_rel.setBackgroundColor(Color.parseColor("#90F41D2C"));
                } else if (Vault_folder.this.theme_color.equals("#E7784D")) {
                    this.selected_rel.setBackgroundColor(Color.parseColor("#90E7784D"));
                } else if (Vault_folder.this.theme_color.equals("#664DE7")) {
                    this.selected_rel.setBackgroundColor(Color.parseColor("#90664DE7"));
                } else if (Vault_folder.this.theme_color.equals("#A84DE8")) {
                    this.selected_rel.setBackgroundColor(Color.parseColor("#90A84DE8"));
                } else if (Vault_folder.this.theme_color.equals("#E74CC1")) {
                    this.selected_rel.setBackgroundColor(Color.parseColor("#90E74CC1"));
                } else if (Vault_folder.this.theme_color.equals("#EB2A69")) {
                    this.selected_rel.setBackgroundColor(Color.parseColor("#90EB2A69"));
                }
            }
        }

        public Allfilelist3(Context a, ArrayList<String> array) {
            this.activity = a;
            this.path_array = array;
        }

        public MyviewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new MyviewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.subviewimage, parent,
                    false));
        }

        public void onBindViewHolder(final MyviewHolder holder, final int position) {
            if (((Model) Vault_folder.this.status.get(position)).isselected()) {
                holder.selected_rel.setVisibility(View.VISIBLE);
            } else {
                holder.selected_rel.setVisibility(View.GONE);
            }
            try {
                File imgFile = new File((String) this.path_array.get(position));
                if (imgFile.exists()) {
                    holder.vault_img.setImageBitmap(BitmapFactory.decodeFile(imgFile.getAbsolutePath()));
                }
                holder.vault_img.setOnClickListener(new OnClickListener() {
                    @SuppressLint("SetTextI18n")
                    public void onClick(View view) {
                        if (Vault_folder.this.select_img_header.getVisibility() != View.VISIBLE) {
                            Vault_folder.this.view_pager_rel.setVisibility(View.VISIBLE);
                            Vault_folder.this.f32f.clear();
                            Vault_folder.this.getFromSdcard();
                            if (Vault_folder.this.f32f.size() == 0) {
                                Vault_folder.this.mCustomPagerAdapter = new CustomPagerAdapter(Vault_folder.this);
                                Vault_folder.this.pageView.setAdapter(Vault_folder.this.mCustomPagerAdapter);
                            } else {
                                Vault_folder.this.mCustomPagerAdapter = new CustomPagerAdapter(Vault_folder.this);
                                Vault_folder.this.pageView.setAdapter(Vault_folder.this.mCustomPagerAdapter);
                            }
                        } else if (((Model) Vault_folder.this.status.get(position)).isselected()) {
                            ((Model) Vault_folder.this.status.get(position)).setIsselected(false);
                            holder.selected_rel.setVisibility(View.GONE);
                            Allfilelist3.this.notifyDataSetChanged();
                            Allfilelist3.this.filesToSend.remove(Allfilelist3.this.path_array.get(position));
                        } else {
                            Vault_folder.this.select_txt_myvault.setText(" Selected");
                            Vault_folder.this.funcation_rel.setEnabled(true);
                            Vault_folder.this.delete_img_rel.setEnabled(true);
                            Vault_folder.this.move_img_rel.setEnabled(true);
                            Vault_folder.this.share_img_rel.setEnabled(true);
                            Vault_folder.this.share.setAlpha(TextTrackStyle.DEFAULT_FONT_SCALE);
                            Vault_folder.this.delete.setAlpha(TextTrackStyle.DEFAULT_FONT_SCALE);
                            Vault_folder.this.move.setAlpha(TextTrackStyle.DEFAULT_FONT_SCALE);
                            ((Model) Vault_folder.this.status.get(position)).setIsselected(true);
                            holder.selected_rel.setVisibility(View.VISIBLE);
                            Allfilelist3.this.notifyDataSetChanged();
                            Allfilelist3.this.filesToSend.add(Allfilelist3.this.path_array.get(position));
                        }
                        int k = 0;
                        for (int i = 0; i < Vault_folder.this.status.size(); i++) {
                            if (((Model) Vault_folder.this.status.get(i)).isselected()) {
                                k++;
                            }
                        }
                        if (k > 0) {
                            Vault_folder.this.select_txt_myvault.setText(k + " Selected");
                            return;
                        }
                        Vault_folder.this.share.setAlpha(0.3f);
                        Vault_folder.this.delete.setAlpha(0.3f);
                        Vault_folder.this.move.setAlpha(0.3f);
                        Vault_folder.this.select_txt_myvault.setText(" Selected");
                    }
                });
                Vault_folder.this.share_img_rel.setOnClickListener(new Click4());
                Vault_folder.this.delete_img_rel.setOnClickListener(new Click5());
                Vault_folder.this.move_img_rel.setOnClickListener(new Click6());
                Vault_folder.this.done_rel.setOnClickListener(new Click7());
                Vault_folder.this.cancle_rel.setOnClickListener(new Click8());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public int getItemCount() {
            return this.path_array.size();
        }
    }

    public class Allfilelist extends RecyclerView.Adapter<Allfilelist.MyviewHolder> {
        private Context activity;
        ArrayList<ModelFolder> arrayList1;
        String path = "";

        public class MyviewHolder extends RecyclerView.ViewHolder {
            RelativeLayout delete_rel;
            RelativeLayout edit_rel;
            ImageView floder_img;
            TextView folder_name_txt;
            RelativeLayout item_rel;
            RelativeLayout line_rel;

            public MyviewHolder(View view) {
                super(view);
                this.floder_img = (ImageView) view.findViewById(R.id.floder_img);
                this.folder_name_txt = (TextView) view.findViewById(R.id.folder_name_txt);
                this.delete_rel = (RelativeLayout) view.findViewById(R.id.delete_rel);
                this.edit_rel = (RelativeLayout) view.findViewById(R.id.edit_rel);
                this.item_rel = (RelativeLayout) view.findViewById(R.id.item_rel);
                this.line_rel = (RelativeLayout) view.findViewById(R.id.line_rel);
                if (Vault_folder.this.theme_color.equals("#ff263237")) {
                    this.line_rel.setBackgroundColor(Color.parseColor(Vault_folder.this.theme_color));
                } else if (Vault_folder.this.theme_color.equals("#4CE799")) {
                    this.line_rel.setBackgroundColor(Color.parseColor(Vault_folder.this.theme_color));
                } else if (Vault_folder.this.theme_color.equals("#F41D2C")) {
                    this.line_rel.setBackgroundColor(Color.parseColor(Vault_folder.this.theme_color));
                } else if (Vault_folder.this.theme_color.equals("#E7784D")) {
                    this.line_rel.setBackgroundColor(Color.parseColor(Vault_folder.this.theme_color));
                } else if (Vault_folder.this.theme_color.equals("#664DE7")) {
                    this.line_rel.setBackgroundColor(Color.parseColor(Vault_folder.this.theme_color));
                } else if (Vault_folder.this.theme_color.equals("#A84DE8")) {
                    this.line_rel.setBackgroundColor(Color.parseColor(Vault_folder.this.theme_color));
                } else if (Vault_folder.this.theme_color.equals("#E74CC1")) {
                    this.line_rel.setBackgroundColor(Color.parseColor(Vault_folder.this.theme_color));
                } else if (Vault_folder.this.theme_color.equals("#EB2A69")) {
                    this.line_rel.setBackgroundColor(Color.parseColor(Vault_folder.this.theme_color));
                }
            }
        }

        public Allfilelist(Context a, ArrayList<ModelFolder> arrayList) {
            this.activity = a;
            this.arrayList1 = arrayList;
        }

        public MyviewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new MyviewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.subfile_foldercreating, parent, false));
        }

        public void onBindViewHolder(final MyviewHolder holder, @SuppressLint("RecyclerView") final int position) {
            try {
                holder.folder_name_txt.setText(StringUtils.capitalize(((ModelFolder) this.arrayList1.get(position))
                        .getName().toLowerCase().trim()));
                final String folder_name_store = Vault_folder.this.getSharedPreferences(((ModelFolder) this.arrayList1
                        .get(position)).getName(), 0).getString("pwd", "");

                if (holder.folder_name_txt.getText().toString().equals("My first album")) {
                    holder.delete_rel.setVisibility(View.GONE);
                    holder.edit_rel.setVisibility(View.GONE);
                } else {
                    holder.delete_rel.setVisibility(View.VISIBLE);
                    holder.edit_rel.setVisibility(View.VISIBLE);
                }

                holder.delete_rel.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Vault_folder.this);
                        alertDialog.setTitle("Confirm Delete...");
                        alertDialog.setMessage("Are you sure you want delete this?");
                        alertDialog.setIcon(R.drawable.delete);
                        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                Allfilelist.this.path = Environment.getExternalStorageDirectory().toString() + "/Photo Vault/";
                                deleteDirectory(new File(Allfilelist.this.path + arrayList_floder.get(position).getName()));
                                File[] list = new File(Environment.getExternalStorageDirectory().toString() + "/Photo Vault").listFiles();
                                Vault_folder.this.arrayList_floder.remove(position);
                                Allfilelist.this.notifyDataSetChanged();
                            }
                        });
                        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(getApplicationContext(), "You clicked on NO", Toast.LENGTH_SHORT).show();
                                dialog.cancel();
                            }
                        });

                        alertDialog.show();
                    }
                });

                holder.folder_name_txt.setTypeface(Typeface.createFromAsset(Vault_folder.this.getAssets(),
                        "fonts/Mada-Regular.ttf"));
                holder.item_rel.setOnClickListener(new OnClickListener() {

                    class Click9 implements OnClickListener {
                        Click9() {
                        }

                        public void onClick(View view) {
                            Vault_folder.this.pwd_rel_folder.setVisibility(View.GONE);
                            Vault_folder.this.pwd_txt_folder.setText("");
                            Vault_folder.this.hideSoftKeyboard();
                        }
                    }

                    class Click10 implements OnClickListener {
                        Click10() {
                        }

                        public void onClick(View view) {
                            if (Vault_folder.this.pwd_txt_folder.getText().toString().equals(folder_name_store)) {
                                Vault_folder.this.pwd_rel_folder.setVisibility(View.GONE);
                                Allfilelist.this.path = Environment.getExternalStorageDirectory().toString() + "/Photo Vault/";
                                Vault_folder.this.store_path = Allfilelist.this.path + holder.folder_name_txt.getText()
                                        .toString();
                                Vault_folder.this.my_gallery_rel.setVisibility(View.VISIBLE);
                                Vault_folder.this.pwd_txt_folder.setText("");
                                Vault_folder.this.hideSoftKeyboard();
                                return;
                            }
                            Vault_folder.this.pwd_txt_folder.setError("Password is worng");
                            Vault_folder.this.pwd_txt_folder.setText("");
                        }
                    }

                    public void onClick(View view) {
                        Vault_folder.this.folder_name = ((ModelFolder) Allfilelist.this.arrayList1.get(position)).getName();
                        create_headettxt_gallery.setText(StringUtils.capitalize(folder_name.toLowerCase().trim()));
                        if (folder_name_store.equals("")) {
                            Allfilelist.this.path = Environment.getExternalStorageDirectory().toString() + "/Photo Vault/";
                            Vault_folder.this.store_path = Allfilelist.this.path + holder.folder_name_txt.getText().toString();
                            Vault_folder.this.my_gallery_rel.setVisibility(View.VISIBLE);
                        } else {
                            Allfilelist.this.path = Environment.getExternalStorageDirectory().toString() + "/Photo Vault/";
                            Vault_folder.this.store_path = Allfilelist.this.path + holder.folder_name_txt.getText().toString();
                            Vault_folder.this.title_of_pwd_rel.setText("Enter Password");
                            Vault_folder.this.pwd_rel_folder.setVisibility(View.VISIBLE);
                            Vault_folder.this.cancle_txt.setOnClickListener(new Click9());
                            Vault_folder.this.ok_txt.setOnClickListener(new Click10());
                        }
                        int mNoOfColumns = Utility.calculateNoOfColumns(Vault_folder.this.getApplicationContext());
                        Vault_folder.this.f32f.clear();
                        Vault_folder.this.getFromSdcard();
                        if (Vault_folder.this.f32f.size() == 0) {
                            if (Vault_folder.this.order.equals("asc")) {
                                Vault_folder.this.ascending_order();
                            } else {
                                Vault_folder.this.dcesending_order();
                            }
                            Vault_folder.this.select_txt_mygallery.setEnabled(false);
                            Vault_folder.this.select_txt_mygallery.setTextColor(Color.parseColor("#65696d"));
                            GridLayoutManager gridLayoutManager = new GridLayoutManager(Vault_folder.this,
                                    mNoOfColumns);
                            Allfilelist3 adapter2 = new Allfilelist3(Vault_folder.this, Vault_folder.this.f32f);
                            Vault_folder.this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                            Vault_folder.this.recyclerView_vault.setAdapter(adapter2);
                            return;
                        }
                        if (Vault_folder.this.order.equals("asc")) {
                            Vault_folder.this.ascending_order();
                        } else {
                            Vault_folder.this.dcesending_order();
                        }
                        Vault_folder.this.select_txt_mygallery.setEnabled(true);
                        Vault_folder.this.select_txt_mygallery.setTextColor(Color.parseColor("#ffffff"));
                        GridLayoutManager gridLayoutManager = new GridLayoutManager(Vault_folder.this, mNoOfColumns);
                        Allfilelist3 adapter2 = new Allfilelist3(Vault_folder.this, Vault_folder.this.f32f);
                        Vault_folder.this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                        Vault_folder.this.recyclerView_vault.setAdapter(adapter2);
                    }
                });

                holder.edit_rel.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        Vault_folder.this.save_rel.setVisibility(View.VISIBLE);
                        final String folder_name_store = Vault_folder.this.getSharedPreferences(((ModelFolder)
                                Allfilelist.this.arrayList1.get(position)).getName(), 0).getString("pwd",
                                "");
                        Vault_folder.this.name_save_et.setText(((ModelFolder) Allfilelist.this.arrayList1.get(position))
                                .getName());
                        Vault_folder.this.pwd_save_et.setText(folder_name_store);
                        Vault_folder.this.conform_save_et.setText(folder_name_store);
                        Vault_folder.this.save_txt.setOnClickListener(new OnClickListener() {

                            class C06611 implements AdapterCallback {
                                C06611() {
                                }

                                public void onItemClicked(boolean ismatch) {
                                    if (ismatch) {
                                        Vault_folder.this.album_rel.setVisibility(View.GONE);
                                        if (Vault_folder.this.pwd_save_et.getText().toString().equals(
                                                conform_save_et.getText().toString())) {
                                            Editor editor = Vault_folder.this.getSharedPreferences(name_save_et.getText()
                                                    .toString(), 0).edit();
                                            editor.putString("pwd", Vault_folder.this.pwd_save_et.getText().toString());
                                            editor.commit();
                                        }
                                    }
                                }
                            }

                            @RequiresApi(api = 17)
                            public void onClick(View view) {
                                if (Vault_folder.this.pwd_save_et == null) {
                                    Vault_folder.this.pwd_save_et.setError("Enter Pwd");
                                } else if (!(Vault_folder.this.name_save_et.equals(((ModelFolder) Allfilelist.this.arrayList1.get(position)).getName()) && folder_name_store.equals(Vault_folder.this.pwd_save_et.getText().toString()))) {
                                    if (!Vault_folder.this.name_save_et.equals(((ModelFolder) Allfilelist.this.arrayList1.get(position)).getName())) {
                                        ((ModelFolder) Allfilelist.this.arrayList1.get(position)).setName(Vault_folder.this.name_save_et.getText().toString());
                                        Editor editor = Vault_folder.this.getSharedPreferences(Vault_folder.this.name_save_et.getText().toString(), 0).edit();
                                        editor.putString("pwd", Vault_folder.this.pwd_save_et.getText().toString());
                                        editor.commit();
                                        Allfilelist.this.path = Environment.getExternalStorageDirectory().toString() + "/Photo Vault/";
                                        Vault_folder.this.store_path = Allfilelist.this.path + holder.folder_name_txt.getText().toString();
                                        File F = new File(Vault_folder.this.store_path);
                                        F.renameTo(new File(F.getParent(), Vault_folder.this.name_save_et.getText().toString()));
                                        Allfilelist.this.notifyDataSetChanged();
                                    }
                                    if (!folder_name_store.equals(Vault_folder.this.pwd_save_et.getText().toString())) {
                                        Vault_folder.this.album_rel.setVisibility(View.GONE);
                                        Vault_folder.this.hideSoftKeyboard();
                                        Vault_folder.this.background_lock();
                                        Vault_folder.lock_rel.setVisibility(View.VISIBLE);
                                        Vault_folder.this.callback = new C06611();
                                    }
                                }
                                String folder_name_store = Vault_folder.this.getSharedPreferences(((ModelFolder) Allfilelist.this.arrayList1.get(position)).getName(), 0).getString("pwd", "");
                                Vault_folder.this.name_save_et.setText("");
                                Vault_folder.this.pwd_save_et.setText("");
                                Vault_folder.this.conform_save_et.setText("");
                                Vault_folder.this.save_rel.setVisibility(View.GONE);
                                Vault_folder.this.hideSoftKeyboard();
                            }
                        });
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public boolean deleteDirectory(File path) {
            if (path.exists()) {
                File[] files = path.listFiles();
                for (int i = 0; i < files.length; i++) {
                    if (files[i].isDirectory()) {
                        deleteDirectory(files[i]);
                    } else {
                        files[i].delete();
                    }
                }
            }
            return (path.delete());
        }

        public int getItemCount() {
            return this.arrayList1.size();
        }
    }

    class CustomPagerAdapter extends PagerAdapter {
        Context mContext;
        LayoutInflater mLayoutInflater;

        public CustomPagerAdapter(Context context) {
            this.mContext = context;
            mLayoutInflater = ((LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE));
        }

        public int getCount() {
            return Vault_folder.this.f32f.size();
        }

        public boolean isViewFromObject(View view, Object object) {
            return view == ((RelativeLayout) object);
        }

        public Object instantiateItem(ViewGroup container, int position) {
            View itemView = this.mLayoutInflater.inflate(R.layout.subsignleimage, container, false);
            ImageView imageView = (ImageView) itemView.findViewById(R.id.photo_view);
            File imgFile = new File((String) Vault_folder.this.f32f.get(position));
            if (imgFile.exists()) {
                imageView.setImageBitmap(BitmapFactory.decodeFile(imgFile.getAbsolutePath()));
            }
            container.addView(itemView);
            return itemView;
        }

        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((RelativeLayout) object);
        }
    }

    public class ImageAdapterRules extends BaseAdapter {
        private LayoutInflater inflater = null;
        ArrayList<ModelFolder> listarray;

        public class ViewHolder {
            TextView IMG;
            RelativeLayout click_rel;
            ImageView tick_mark;
        }

        public ImageAdapterRules(ArrayList<ModelFolder> arrayList) {
            this.listarray = arrayList;
            this.inflater = (LayoutInflater) Vault_folder.this.getSystemService(LAYOUT_INFLATER_SERVICE);
        }

        public int getCount() {
            return this.listarray.size();
        }

        public Object getItem(int position) {
            return Integer.valueOf(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(final int position, View convertView, ViewGroup parent) {
            final ViewHolder holder;
            View vi = convertView;
            if (vi == null) {
                vi = this.inflater.inflate(R.layout.list_item_layout, null);
                holder = new ViewHolder();
                holder.IMG = (TextView) vi.findViewById(R.id.textView_countryName);
                holder.click_rel = (RelativeLayout) vi.findViewById(R.id.click_rel);
                holder.tick_mark = (ImageView) vi.findViewById(R.id.tick_mark);
                if (((Model) Vault_folder.this.status_select_namefolder.get(position)).isselected()) {
                    holder.tick_mark.setVisibility(View.VISIBLE);
                    if (Vault_folder.this.theme_color.equals("#ff263237")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_0);
                    } else if (Vault_folder.this.theme_color.equals("#4CE799")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_1);
                    } else if (Vault_folder.this.theme_color.equals("#F41D2C")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_2);
                    } else if (Vault_folder.this.theme_color.equals("#E7784D")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_3);
                    } else if (Vault_folder.this.theme_color.equals("#664DE7")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_4);
                    } else if (Vault_folder.this.theme_color.equals("#A84DE8")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_5);
                    } else if (Vault_folder.this.theme_color.equals("#E74CC1")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_6);
                    } else if (Vault_folder.this.theme_color.equals("#EB2A69")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_7);
                    }
                } else {
                    holder.tick_mark.setVisibility(View.GONE);
                }
                vi.setTag(holder);
            } else {
                holder = (ViewHolder) vi.getTag();
            }
            if (Vault_folder.this.folder_name.equals(((ModelFolder) this.listarray.get(position)).getName())) {
                holder.click_rel.setVisibility(View.GONE);
            } else {
                holder.click_rel.setVisibility(View.VISIBLE);
                holder.IMG.setText(((ModelFolder) this.listarray.get(position)).getName());
            }
            holder.click_rel.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Vault_folder.this.folder_name2 = holder.IMG.getText().toString();
                    for (int i = 0; i < Vault_folder.this.status_select_namefolder.size(); i++) {
                        if (i == position) {
                            ((Model) Vault_folder.this.status_select_namefolder.get(position)).setIsselected(true);
                        } else {
                            ((Model) Vault_folder.this.status_select_namefolder.get(i)).setIsselected(false);
                        }
                    }
                    Vault_folder.this.listview.setAdapter(new ImageAdapterRules(Vault_folder.this.arrayList_floder));
                }
            });
            return vi;
        }
    }

    public class ImageAdapterRules_forget extends BaseAdapter {
        private LayoutInflater inflater = null;
        ArrayList<ModelFolder> listarray;

        public class ViewHolder {
            TextView IMG;
            RelativeLayout click_rel;
            ImageView tick_mark;
        }

        public ImageAdapterRules_forget(ArrayList<ModelFolder> arrayList) {
            this.listarray = arrayList;
            this.inflater = (LayoutInflater) Vault_folder.this.getSystemService(LAYOUT_INFLATER_SERVICE);
        }

        public int getCount() {
            return this.listarray.size();
        }

        public Object getItem(int position) {
            return Integer.valueOf(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        @SuppressLint("InflateParams")
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            View vi = convertView;
            if (vi == null) {
                vi = this.inflater.inflate(R.layout.list_item_layout, null);
                holder = new ViewHolder();
                holder.IMG = (TextView) vi.findViewById(R.id.textView_countryName);
                holder.click_rel = (RelativeLayout) vi.findViewById(R.id.click_rel);
                holder.tick_mark = (ImageView) vi.findViewById(R.id.tick_mark);
                if (((Model) Vault_folder.this.status_select_namefolder.get(position)).isselected()) {
                    holder.tick_mark.setVisibility(View.VISIBLE);
                    if (Vault_folder.this.theme_color.equals("#ff263237")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_0);
                    } else if (Vault_folder.this.theme_color.equals("#4CE799")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_1);
                    } else if (Vault_folder.this.theme_color.equals("#F41D2C")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_2);
                    } else if (Vault_folder.this.theme_color.equals("#E7784D")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_3);
                    } else if (Vault_folder.this.theme_color.equals("#664DE7")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_4);
                    } else if (Vault_folder.this.theme_color.equals("#A84DE8")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_5);
                    } else if (Vault_folder.this.theme_color.equals("#E74CC1")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_6);
                    } else if (Vault_folder.this.theme_color.equals("#EB2A69")) {
                        holder.tick_mark.setBackgroundResource(R.drawable.tick_7);
                    }
                } else {
                    holder.tick_mark.setVisibility(View.GONE);
                }
                vi.setTag(holder);
            } else {
                holder = (ViewHolder) vi.getTag();
            }
            holder.click_rel.setVisibility(View.VISIBLE);
            String folder_name_store = Vault_folder.this.getSharedPreferences(((ModelFolder) this.listarray.get(position)).getName(), 0).getString("pwd", "");
            holder.IMG.setText(StringUtils.capitalize(((ModelFolder) this.listarray.get(position)).getName().toLowerCase().trim()));
            if (folder_name_store.equals("")) {
                holder.click_rel.setVisibility(View.GONE);
            } else {
                holder.click_rel.setVisibility(View.VISIBLE);
            }
            holder.click_rel.setOnClickListener(new OnClickListener() {

                class C06791 implements AdapterCallback {
                    C06791() {
                    }

                    public void onItemClicked(boolean ismatch) {
                        if (ismatch) {
                            Vault_folder.this.folder_name2 = ((ModelFolder) ImageAdapterRules_forget.this.listarray.get(position)).getName();
                            SharedPreferences prefs2 = Vault_folder.this.getSharedPreferences(Vault_folder.this.folder_name2, 0);
                            Vault_folder.this.pwd_folder_send_email = prefs2.getString("pwd", "");
                        }
                    }
                }

                public void onClick(View view) {
                    Vault_folder.lock_rel.setVisibility(View.VISIBLE);
                    Vault_folder.this.callback = new C06791();
                }
            });
            return vi;
        }
    }

    public class ListAdapter extends BaseAdapter {
        private Activity activity;
        private ArrayList<BreakModel> data;

        public class ViewHolder {
            TextView Password_txt;
            TextView date_txt;
            ImageView image_capture;
            RelativeLayout item;
        }

        public ListAdapter(Activity a, ArrayList<BreakModel> basicList) {
            this.activity = a;
            this.data = basicList;
        }

        public int getCount() {
            return this.data.size();
        }

        public Object getItem(int position) {
            return this.data.get(position);
        }

        public long getItemId(int position) {
            return 0;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                holder = new ViewHolder();
                convertView = LayoutInflater.from(this.activity).inflate(R.layout.subfile_break, null);
                holder.image_capture = (ImageView) convertView.findViewById(R.id.image_capture);
                holder.Password_txt = (TextView) convertView.findViewById(R.id.Password_txt);
                holder.date_txt = (TextView) convertView.findViewById(R.id.date_txt);
                holder.item = (RelativeLayout) convertView.findViewById(R.id.item);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            Picasso.with(Vault_folder.this.getApplicationContext()).load(((BreakModel) this.data.get(position)).getFile()).resize(Callback.DEFAULT_DRAG_ANIMATION_DURATION, Callback.DEFAULT_DRAG_ANIMATION_DURATION).centerCrop().into(holder.image_capture);
            holder.Password_txt.setText("Passcode :" + ((BreakModel) this.data.get(position)).getPassword());
            holder.date_txt.setText("Created At :" + ((BreakModel) this.data.get(position)).getDate());
            return convertView;
        }
    }

    class LoadAllFolder extends AsyncTask<String, Void, String> {
        LoadAllFolder() {
        }

        protected void onPreExecute() {
            super.onPreExecute();
            Vault_folder.this.arrayList_pos.clear();
        }

        protected String doInBackground(String... args) {
            String xml = "";
            Uri uriExternal = Media.EXTERNAL_CONTENT_URI;
            Uri uriInternal = Media.INTERNAL_CONTENT_URI;
            String[] projection = new String[]{"_data", "_display_name", "date_modified"};
            Cursor cursorExternal = Vault_folder.this.getContentResolver().query(uriExternal, projection, null, null, null);
            Cursor cursorInternal = Vault_folder.this.getContentResolver().query(uriInternal, projection, null, null, null);
            Cursor cursor = new MergeCursor(new Cursor[]{cursorExternal, cursorInternal});
            while (cursor.moveToNext()) {
                String path = cursor.getString(cursor.getColumnIndexOrThrow("_data"));
                String album = cursor.getString(cursor.getColumnIndexOrThrow("_display_name"));
                if (album.toLowerCase().endsWith(".gif")) {
                } else {
                    Model client1 = new Model();
                    client1.setPath(path);
                    client1.setImage_name(album);
                    client1.setIsselected(false);
                    Vault_folder.this.arrayList_pos.add(client1);
                }
            }
            cursor.close();
            return xml;
        }

        protected void onPostExecute(String xml) {
            GridLayoutManager gridLayoutManager = new GridLayoutManager(Vault_folder.this, 2);
            Vault_folder.this.recyclerView_gallery.setAdapter(new Allfilelist2(Vault_folder.this, Vault_folder.this.arrayList_pos));
            Vault_folder.this.recyclerView_gallery.setLayoutManager(gridLayoutManager);
        }
    }

    public class MoviesAdapter extends RecyclerView.Adapter<MoviesAdapter.MyViewHolder> {
        private int[] moviesList;

        public class MyViewHolder extends RecyclerView.ViewHolder {
            ImageView check_mark_img;
            ImageView color_theme_img;
            public TextView genre;
            public TextView title;
            public TextView year;

            public MyViewHolder(View view) {
                super(view);
                this.color_theme_img = (ImageView) view.findViewById(R.id.color_theme_img);
                this.check_mark_img = (ImageView) view.findViewById(R.id.check_mark_img);
            }
        }

        public MoviesAdapter(int[] moviesList) {
            this.moviesList = moviesList;
        }

        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.theme_layout, parent, false));
        }

        public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
            if (((Model) Vault_folder.this.checkmark_status.get(position)).isselected()) {
                holder.check_mark_img.setVisibility(View.VISIBLE);
                if (position == 0) {
                    Vault_folder.this.theme_color = "#ff263237";
                } else if (position == 1) {
                    Vault_folder.this.theme_color = "#4CE799";
                } else if (position == 2) {
                    Vault_folder.this.theme_color = "#F41D2C";
                } else if (position == 3) {
                    Vault_folder.this.theme_color = "#E7784D";
                } else if (position == 4) {
                    Vault_folder.this.theme_color = "#664DE7";
                } else if (position == 5) {
                    Vault_folder.this.theme_color = "#A84DE8";
                } else if (position == 6) {
                    Vault_folder.this.theme_color = "#E74CC1";
                } else if (position == 7) {
                    Vault_folder.this.theme_color = "#EB2A69";
                }
                Editor editor = Vault_folder.this.getSharedPreferences("COLOR_THEME", 0).edit();
                editor.putString("color_theme", Vault_folder.this.theme_color);
                editor.commit();
                Editor editor2 = Vault_folder.this.getSharedPreferences("LOCK_THEME", 0).edit();
                editor2.putString("lock_theme", "color");
                editor2.commit();
            } else {
                holder.check_mark_img.setVisibility(View.GONE);
            }
            holder.color_theme_img.setImageResource(this.moviesList[position]);
            holder.color_theme_img.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    for (int i = 0; i < Vault_folder.this.checkmark_status.size(); i++) {
                        if (i == position) {
                            ((Model) Vault_folder.this.checkmark_status.get(position)).setIsselected(true);
                        } else {
                            ((Model) Vault_folder.this.checkmark_status.get(i)).setIsselected(false);
                        }
                    }
                    MoviesAdapter.this.notifyDataSetChanged();
                }
            });
        }

        public int getItemCount() {
            return this.moviesList.length;
        }
    }

    private void cameraIntent() {
        startActivityForResult(new Intent("android.media.action.IMAGE_CAPTURE"), this.REQUEST_CAMERA);
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        SaveImage(thumbnail, this.store_path);
        this.f32f.clear();
        getFromSdcard();
        int mNoOfColumns = Utility.calculateNoOfColumns(getApplicationContext());
        GridLayoutManager gridLayoutManager;
        Allfilelist3 adapter2;
        if (this.f32f.size() == 0) {
            this.select_txt_mygallery.setEnabled(false);
            this.select_txt_mygallery.setTextColor(Color.parseColor("#65696d"));
            gridLayoutManager = new GridLayoutManager(this, mNoOfColumns);
            adapter2 = new Allfilelist3(this, this.f32f);
            this.recyclerView_vault.setLayoutManager(gridLayoutManager);
            this.recyclerView_vault.setAdapter(adapter2);
        } else {
            this.select_txt_mygallery.setEnabled(true);
            this.select_txt_mygallery.setTextColor(Color.parseColor("#ffffff"));
            gridLayoutManager = new GridLayoutManager(this, mNoOfColumns);
            adapter2 = new Allfilelist3(this, this.f32f);
            this.recyclerView_vault.setLayoutManager(gridLayoutManager);
            this.recyclerView_vault.setAdapter(adapter2);
        }
        this.my_gallery_rel.setVisibility(View.VISIBLE);
        this.open_gallery_floating_btn.setVisibility(View.GONE);
        Editor editor = getSharedPreferences("LOCK_THEME", 0).edit();
        editor.putString("lock_theme", "image");
        editor.commit();
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (!this.permission.checkPermissionForWriteexternal()) {
            this.permission.requestPermissionForWriteexternal();
        }
    }

    private void SaveImage(Bitmap finalBitmap, String pathname) {
        File file = new File(pathname, "Image-" + new Random().nextInt(10000) + ".jpg");
        if (file.exists()) {
            file.delete();
        }
        try {
            FileOutputStream out = new FileOutputStream(file);
            finalBitmap.compress(CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getFromSdcard() {
        File file = new File(this.store_path);
        if (file.isDirectory()) {
            this.listFile = file.listFiles();
            for (File absolutePath : this.listFile) {
                this.f32f.add(absolutePath.getAbsolutePath());
                Model client1 = new Model();
                client1.setIsselected(false);
                this.status.add(client1);
            }
        }
    }

    public void ascending_order() {
        Collections.sort(this.arrayList_floder, new Comparator<ModelFolder>() {
            public int compare(ModelFolder o1, ModelFolder o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        Allfilelist adapter2 = new Allfilelist(this, this.arrayList_floder);
        this.rv_gallery.setLayoutManager(gridLayoutManager);
        this.rv_gallery.setAdapter(adapter2);
    }

    public void dcesending_order() {
        ascending_order();
        Collections.reverse(this.arrayList_floder);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        Allfilelist adapter2 = new Allfilelist(this, this.arrayList_floder);
        this.rv_gallery.setLayoutManager(gridLayoutManager);
        this.rv_gallery.setAdapter(adapter2);
    }

    public void onBackPressed() {
        if (lock_rel.getVisibility() == View.VISIBLE) {
            lock_rel.setVisibility(View.GONE);
            this.album_rel.setVisibility(View.VISIBLE);
        } else if (this.reset_pwd_rel.getVisibility() == View.VISIBLE) {
            this.reset_pwd_rel.setVisibility(View.GONE);
        } else if (this.lock_rel_break.getVisibility() == View.VISIBLE) {
            this.lock_rel_break.setVisibility(View.GONE);
        } else if (this.break_in_alert_rel.getVisibility() == View.VISIBLE) {
            this.break_in_alert_rel.setVisibility(View.GONE);
        } else if (this.forget_pwd_folder.getVisibility() == View.VISIBLE) {
            this.forget_pwd_folder.setVisibility(View.GONE);
        } else if (this.setting_lock_rel.getVisibility() == View.VISIBLE) {
            if (this.forget_pwd_folder_list.getVisibility() == View.VISIBLE) {
                this.forget_pwd_folder_list.setVisibility(View.GONE);
            } else if (this.dialog_box_email_rel.getVisibility() == View.VISIBLE) {
                this.dialog_box_email_rel.setVisibility(View.GONE);
            } else {
                this.setting_lock_rel.setVisibility(View.GONE);
            }
        } else if (this.theme_rel.getVisibility() == View.VISIBLE) {
            this.theme_rel.setVisibility(View.GONE);
            this.setting_lock_rel.setVisibility(View.VISIBLE);
        } else if (this.create_rel.getVisibility() == View.VISIBLE) {
            this.create_rel.setVisibility(View.GONE);
        } else if (this.save_rel.getVisibility() == View.VISIBLE) {
            this.save_rel.setVisibility(View.GONE);
        } else if (this.my_gallery_rel.getVisibility() == View.VISIBLE) {
            if (this.select_img_header.getVisibility() == View.VISIBLE) {
                this.funcation_rel.setVisibility(View.GONE);
                this.select_img_header.setVisibility(View.GONE);
                for (int i = 0; i < this.status.size(); i++) {
                    ((Model) this.status.get(i)).setIsselected(false);
                }
                this.select_txt_myvault.setText("Selected");
                this.f32f.clear();
                getFromSdcard();
                int mNoOfColumns = Utility.calculateNoOfColumns(getApplicationContext());
                GridLayoutManager gridLayoutManager;
                Allfilelist3 adapter2;
                if (this.f32f.size() == 0) {
                    if (this.order.equals("asc")) {
                        ascending_order();
                    } else {
                        dcesending_order();
                    }
                    this.select_txt_mygallery.setEnabled(false);
                    this.select_txt_mygallery.setTextColor(Color.parseColor("#65696d"));
                    gridLayoutManager = new GridLayoutManager(this, mNoOfColumns);
                    adapter2 = new Allfilelist3(this, this.f32f);
                    this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                    this.recyclerView_vault.setAdapter(adapter2);
                } else {
                    if (this.order.equals("asc")) {
                        ascending_order();
                    } else {
                        dcesending_order();
                    }
                    this.select_txt_mygallery.setEnabled(true);
                    this.select_txt_mygallery.setTextColor(Color.parseColor("#ffffff"));
                    gridLayoutManager = new GridLayoutManager(this, mNoOfColumns);
                    adapter2 = new Allfilelist3(this, this.f32f);
                    this.recyclerView_vault.setLayoutManager(gridLayoutManager);
                    this.recyclerView_vault.setAdapter(adapter2);
                }
            } else if (this.view_pager_rel.getVisibility() == View.VISIBLE) {
                this.view_pager_rel.setVisibility(View.GONE);
            } else if (this.open_gallery_floating_btn.getVisibility() == View.VISIBLE) {
                this.open_gallery_floating_btn.setVisibility(View.GONE);
            } else if (this.gallery_phone_rel.getVisibility() == View.VISIBLE) {
                this.gallery_phone_rel.setVisibility(View.GONE);
            } else {
                this.my_gallery_rel.setVisibility(View.GONE);
            }
        } else if (this.copy_layout_folder.getVisibility() == View.VISIBLE) {
            this.copy_layout_folder.setVisibility(View.GONE);
            this.select_img_header.setVisibility(View.VISIBLE);
            this.funcation_rel.setVisibility(View.VISIBLE);
        } else if (this.album_rel.getVisibility() == View.VISIBLE) {
            if (this.pwd_rel_folder.getVisibility() == View.VISIBLE) {
                this.pwd_rel_folder.setVisibility(View.GONE);
            } else {
                if (this.ePreferences.getBoolean("pref_key_rate", false)) {
                    ExitDialog();
                } else {
                    RateDialog();
                }
            }
        }
        hideSoftKeyboard();
    }

    public void hideSoftKeyboard() {
        if (getCurrentFocus() != null) {
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction("android.intent.action.GET_CONTENT");
        startActivityForResult(Intent.createChooser(intent, "Select File"), this.SELECT_FILE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != -1) {
            return;
        }
        if (requestCode == this.SELECT_FILE) {
            onSelectFromGalleryResult(data);
        } else if (requestCode == this.REQUEST_CAMERA) {
            onCaptureImageResult(data);
        }
    }

    private void onSelectFromGalleryResult(Intent data) {
        this.image_bg.setImageURI(data.getData());
        this.image_bg.buildDrawingCache();
        Bitmap realImage = ((BitmapDrawable) this.image_bg.getDrawable()).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        realImage.compress(CompressFormat.JPEG, 100, baos);
        byte[] b = baos.toByteArray();
        Editor editor = getSharedPreferences("LOCK_THEME", 0).edit();
        editor.putString("lock_theme", "image");
        editor.commit();
        String encodedImage = Base64.encodeToString(b, 0);
        Editor edit = PreferenceManager.getDefaultSharedPreferences(this).edit();
        edit.putString("image_data", encodedImage);
        edit.commit();
    }

    @RequiresApi(api = 17)
    public void onResume() {
        this.app_status = true;
        if (this.app_status) {
            if (first_time) {
                lock_rel.setVisibility(View.GONE);
            } else {
                this.forget_pwd_txt.setVisibility(View.VISIBLE);
                this.theme_type = getSharedPreferences("LOCK_THEME", 0).getString("lock_theme", "image");
                if (this.theme_type.equals("image")) {
                    this.image_bg.setVisibility(View.VISIBLE);
                    this.background_color.setVisibility(View.GONE);
                } else if (this.theme_type.equals("color")) {
                    this.background_color.setBackgroundColor(Color.parseColor(getSharedPreferences("COLOR_THEME", 0).getString("color_theme", "#ff263237")));
                    this.image_bg.setVisibility(View.GONE);
                    this.background_color.setVisibility(View.VISIBLE);
                }
                if (this.lock_screen_share_status) {
                    this.lock_screen_share_status = false;
                    lock_rel.setVisibility(View.GONE);
                } else {
                    background_lock();
                    lock_rel.setVisibility(View.VISIBLE);
                    boolean toggle_btn_sttaus = getSharedPreferences("FIGUARE_PRINT", 0).getBoolean("figure_print", false);
                    if (toggle_btn_sttaus) {
                        FingerprintManager fingerprintManager = null;
                        if (VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            fingerprintManager = (FingerprintManager) getSystemService(FINGERPRINT_SERVICE);
                        }
                        KeyguardManager keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
                        if (VERSION.SDK_INT >= 23 && fingerprintManager.isHardwareDetected() && ActivityCompat.checkSelfPermission(this, "android.permission.USE_FINGERPRINT") == 0 && fingerprintManager.hasEnrolledFingerprints() && keyguardManager.isKeyguardSecure()) {
                            generateKey();
                            if (cipherInit()) {
                                new FingerprintHandler(this).startAuth(fingerprintManager, new CryptoObject(this.cipher));
                            }
                        }
                    }
                }
                hideSoftKeyboard();
            }
            first_time = false;
        } else {
            lock_rel.setVisibility(View.GONE);
        }
        super.onResume();
    }

    public void onImageCapture(@NonNull File imageFile) {
        Options options = new Options();
        options.inPreferredConfig = Config.RGB_565;
        BreakModel client1 = new BreakModel();
        client1.setPath_break(imageFile.getAbsolutePath());
        client1.setImage_name(imageFile.getName());
        client1.setPassword(this.worng_passcode);
        client1.setDate(new SimpleDateFormat("dd-MMM-yyyy  hh:mm a").format(Long.valueOf(Date.parse(String.valueOf(new Date(imageFile.lastModified()))))));
        client1.setLat(this.latitude.doubleValue());
        client1.setLang(this.longitude.doubleValue());
        if (LockScreenActivity.break_data_array == null) {
            LockScreenActivity.break_data_array = new ArrayList();
        }
        LockScreenActivity.break_data_array.add(client1);
        Editor editor = getSharedPreferences("naimee", 0).edit();
        editor.putString("patel", new Gson().toJson(LockScreenActivity.break_data_array));
        editor.commit();
        SaveImage(BitmapFactory.decodeFile(imageFile.getAbsolutePath(), options));
    }

    public void onCameraError(int errorCode) {
        switch (errorCode) {
            case CameraError.ERROR_CAMERA_OPEN_FAILED /*1122*/:
                Toast.makeText(this, "Cannot open camera.", Toast.LENGTH_SHORT).show();
                return;
            case CameraError.ERROR_CAMERA_PERMISSION_NOT_AVAILABLE /*5472*/:
                Toast.makeText(this, "Camera permission not available.", Toast.LENGTH_SHORT).show();
                return;
            case CameraError.ERROR_DOES_NOT_HAVE_FRONT_CAMERA /*8722*/:
                Toast.makeText(this, "Your device does not have front camera.", Toast.LENGTH_SHORT).show();
                return;
            case CameraError.ERROR_IMAGE_WRITE_FAILED /*9854*/:
                Toast.makeText(this, "Cannot write image captured by camera.", Toast.LENGTH_SHORT).show();
                return;
            default:
                return;
        }
    }

    private void SaveImage(Bitmap finalBitmap) {
        File myDir = new File(Environment.getExternalStorageDirectory().toString() + "/Person_image");
        myDir.mkdirs();
        File file = new File(myDir, "Image-" + new Random().nextInt(10000) + ".jpg");
        if (file.exists()) {
            file.delete();
        }
        try {
            FileOutputStream out = new FileOutputStream(file);
            finalBitmap.compress(CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @SuppressLint("WrongConstant")
    @TargetApi(23)
    protected void generateKey() {
        GeneralSecurityException e;
        try {
            this.keyStore = KeyStore.getInstance("AndroidKeyStore");
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES", "AndroidKeyStore");
            try {
                this.keyStore.load(null);
                keyGenerator.init(new KeyGenParameterSpec.Builder(KEY_NAME, 3).setBlockModes(new String[]{"CBC"}).setUserAuthenticationRequired(true).setEncryptionPaddings(new String[]{"PKCS7Padding"}).build());
                keyGenerator.generateKey();
            } catch (NoSuchAlgorithmException e3) {
                throw new RuntimeException(e3);
            } catch (InvalidAlgorithmParameterException e4) {
                throw new RuntimeException(e4);
            } catch (CertificateException e5) {
                throw new RuntimeException(e5);
            } catch (IOException e6) {
                throw new RuntimeException(e6);
            }
        } catch (NoSuchAlgorithmException e7) {
            e = e7;
            throw new RuntimeException("Failed to get KeyGenerator instance", e);
        } catch (NoSuchProviderException e8) {
            e = e8;
            throw new RuntimeException("Failed to get KeyGenerator instance", e);
        }
    }

    @TargetApi(23)
    public boolean cipherInit() {
        GeneralSecurityException e;
        try {
            this.cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
            try {
                this.keyStore.load(null);
                this.cipher.init(1, (SecretKey) this.keyStore.getKey(KEY_NAME, null));
                return true;
            } catch (InvalidKeyException e2) {
                return false;
            } catch (Exception e3) {
                throw new RuntimeException("Failed to init Cipher", e3);
            }
        } catch (NoSuchAlgorithmException e4) {
            e = e4;
            throw new RuntimeException("Failed to get Cipher", e);
        } catch (NoSuchPaddingException e5) {
            e = e5;
            throw new RuntimeException("Failed to get Cipher", e);
        }
    }

    public void showmap(double lat, double lang) {
        this.mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        final double d = lat;
        final double d2 = lang;
        this.mapFragment.getMapAsync(new OnMapReadyCallback() {
            public void onMapReady(GoogleMap googleMap) {
                LatLng position = new LatLng(d, d2);
                MarkerOptions options = new MarkerOptions();
                options.position(position);
                googleMap.addMarker(options);
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(position, 12.0f));
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    public void background_lock() {
        this.theme_type = getSharedPreferences("LOCK_THEME", 0).getString("lock_theme", "image");
        if (this.theme_type.equals("image")) {
            String previouslyEncodedImage = PreferenceManager.getDefaultSharedPreferences(this).getString("image_data", "");
            if (previouslyEncodedImage.equals("")) {
                Editor editor = getSharedPreferences("LOCK_THEME", 0).edit();
                editor.putString("lock_theme", "color");
                editor.commit();
                this.background_color.setBackgroundColor(Color.parseColor(getSharedPreferences("COLOR_THEME", 0).getString("color_theme", "#ff263237")));
                this.image_bg.setVisibility(View.GONE);
                this.background_color.setVisibility(View.VISIBLE);
                return;
            }
            byte[] b = Base64.decode(previouslyEncodedImage, 0);
            this.image_bg.setImageBitmap(Utils.blur(getApplicationContext(), BitmapFactory.decodeByteArray(b, 0, b.length)));
            this.image_bg.setVisibility(View.VISIBLE);
            this.background_color.setVisibility(View.GONE);
        }
    }

    private int dp2px(int dp) {
        return (int) TypedValue.applyDimension(1, (float) dp, getResources().getDisplayMetrics());
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(Vault_folder.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.Ad_mob_native_advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                   finishAffinity();
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(Vault_folder.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.Ad_mob_native_advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });
        dialog.show();
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    protected void onDestroy() {
        if (nativeAd != null) {
            nativeAd.destroy();
        }
        super.onDestroy();
    }
}
