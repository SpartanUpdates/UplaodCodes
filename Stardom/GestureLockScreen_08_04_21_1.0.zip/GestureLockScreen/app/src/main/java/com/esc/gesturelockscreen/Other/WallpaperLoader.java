package com.esc.gesturelockscreen.Other;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.widget.ImageView;
import com.esc.gesturelockscreen.R;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import androidx.annotation.NonNull;

public class WallpaperLoader {
  private static WallpaperLoader _instance;
  private Map<ImageView, Integer> imageViews = Collections.synchronizedMap(new WeakHashMap());
  private Activity mActivity;
  private ExecutorService mExecutorService;
  private MemoryCache memoryCache = new MemoryCache();
  final int stub_id;

  class BitmapDisplayer implements Runnable {
    Bitmap bitmap;
    PhotoToLoad photoToLoad;

    public BitmapDisplayer(Bitmap b, PhotoToLoad p) {
      this.bitmap = b;
      this.photoToLoad = p;
    }

    public void run() {
      if (!WallpaperLoader.this.imageViewReused(this.photoToLoad)) {
        if (this.bitmap != null) {
          this.photoToLoad.imageView.setImageBitmap(this.bitmap);
        } else {
          this.photoToLoad.imageView.setImageResource(WallpaperLoader.this.stub_id);
        }
      }
    }
  }

  static class MemoryCache {
    private Map<Integer, Bitmap> cache = Collections.synchronizedMap(new LinkedHashMap(10, 1.5f, true));
    private final long limit = (Runtime.getRuntime().maxMemory() / 8);
    private long size = 0;

    MemoryCache() {
    }

    Bitmap get(Integer id) {
      try {
        if (this.cache.containsKey(id)) {
          return (Bitmap) this.cache.get(id);
        }
        return null;
      } catch (NullPointerException e) {
        return null;
      }
    }

    void put(Integer id, Bitmap bitmap) {
      try {
        if (this.cache.containsKey(id)) {
          this.size -= getSizeInBytes((Bitmap) this.cache.get(id));
        }
        this.cache.put(id, bitmap);
        this.size += getSizeInBytes(bitmap);
        checkSize();
      } catch (Throwable th) {
        th.printStackTrace();
      }
    }

    private void checkSize() {
      if (this.size > this.limit) {
        Iterator<Entry<Integer, Bitmap>> iter = this.cache.entrySet().iterator();
        while (iter.hasNext()) {
          this.size -= getSizeInBytes((Bitmap) ((Entry) iter.next()).getValue());
          iter.remove();
          if (this.size <= this.limit) {
            return;
          }
        }
      }
    }

    void clear() {
      this.cache.clear();
    }

    long getSizeInBytes(Bitmap bitmap) {
      if (bitmap == null) {
        return 0;
      }
      return (long) (bitmap.getRowBytes() * bitmap.getHeight());
    }
  }

  private class PhotoToLoad {
    public ImageView imageView;
    public Integer uri;

    public PhotoToLoad(Integer u, ImageView i) {
      this.uri = u;
      this.imageView = i;
    }
  }

  class PhotosLoader implements Runnable {
    PhotoToLoad photoToLoad;

    PhotosLoader(PhotoToLoad photoToLoad) {
      this.photoToLoad = photoToLoad;
    }

    public void run() {
      if (!WallpaperLoader.this.imageViewReused(this.photoToLoad)) {
        Bitmap bmp = WallpaperLoader.this.getBitmap(this.photoToLoad.uri);
        WallpaperLoader.this.memoryCache.put(this.photoToLoad.uri, bmp);
        if (!WallpaperLoader.this.imageViewReused(this.photoToLoad)) {
          WallpaperLoader.this.mActivity.runOnUiThread(new BitmapDisplayer(bmp, this.photoToLoad));
        }
      }
    }
  }

  public static WallpaperLoader getInstace() {
    return _instance;
  }

  public static void init(@NonNull Activity context) {
    if (_instance == null) {
      _instance = new WallpaperLoader(context, R.mipmap.ic_launcher);
    }
  }

  public WallpaperLoader(@NonNull Activity context, int resId) {
    this.mActivity = context;
    this.stub_id = resId;
    this.mExecutorService = Executors.newFixedThreadPool(5);
  }

  public void displayImage(int uri, ImageView imageView) {
    this.imageViews.put(imageView, Integer.valueOf(uri));
    Bitmap bitmap = this.memoryCache.get(Integer.valueOf(uri));
    if (bitmap != null) {
      imageView.setImageBitmap(bitmap);
      return;
    }
    queuePhoto(Integer.valueOf(uri), imageView);
    imageView.setImageResource(this.stub_id);
  }

  private void queuePhoto(Integer uri, ImageView imageView) {
    this.mExecutorService.submit(new PhotosLoader(new PhotoToLoad(uri, imageView)));
  }

  private Bitmap getBitmap(Integer uri) {
    Bitmap b = decodeFile(uri);
    return b != null ? b : null;
  }

  private Bitmap decodeFile(Integer path) {
    Bitmap bitmap = null;
    try {
      Options o = new Options();
      o.inJustDecodeBounds = true;
      BitmapFactory.decodeStream(this.mActivity.getResources().openRawResource(path.intValue()), null, o);
      int width_tmp = o.outWidth;
      int height_tmp = o.outHeight;
      int scale = 1;
      while (width_tmp / 2 >= 256 && height_tmp / 2 >= 256) {
        width_tmp /= 2;
        height_tmp /= 2;
        scale *= 2;
      }
      Options o2 = new Options();
      o2.inSampleSize = scale;
      bitmap = BitmapFactory.decodeStream(this.mActivity.getResources().openRawResource(path.intValue()), null, o2);
    } catch (Exception e) {
    }
    return bitmap;
  }

  boolean imageViewReused(PhotoToLoad photoToLoad) {
    Integer tag = (Integer) this.imageViews.get(photoToLoad.imageView);
    if (tag == null || !tag.equals(photoToLoad.uri)) {
      return true;
    }
    return false;
  }

  public void clearCache() {
    this.memoryCache.clear();
  }
}
