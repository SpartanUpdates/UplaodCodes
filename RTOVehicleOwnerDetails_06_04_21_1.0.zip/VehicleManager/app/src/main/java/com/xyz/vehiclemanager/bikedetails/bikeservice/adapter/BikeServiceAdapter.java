package com.xyz.vehiclemanager.bikedetails.bikeservice.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bikedetails.bikeservice.activity.BikeServiceSelectStateActivity;
import com.xyz.vehiclemanager.model.BikeBrands;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BikeServiceAdapter extends RecyclerView.Adapter<BikeServiceAdapter.MyViewHolder>
{
    Context mcontext;
    ArrayList<BikeBrands> bikeBrandlist;

    public class MyViewHolder extends RecyclerView.ViewHolder{
       ImageView iv_bikebrandImage;
       TextView tv_bikebrandName;
       LinearLayout rl_bikebrand;
       public MyViewHolder(@NonNull View itemView) {
           super(itemView);

           iv_bikebrandImage = itemView.findViewById(R.id.iv_bikebrandImage);
           tv_bikebrandName = itemView.findViewById(R.id.tv_bikebrandName);
           rl_bikebrand = itemView.findViewById(R.id.ll_bikebrand);
       }
    }

    public BikeServiceAdapter(Context context, ArrayList<BikeBrands> bikeBrandslist) {
        this.mcontext = context;
        this.bikeBrandlist = bikeBrandslist;
    }

    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_bikebrands,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        final BikeBrands bikeServiceBrand = bikeBrandlist.get(position);
        holder.tv_bikebrandName.setText(bikeServiceBrand.getBrandName());

        Glide.with(mcontext)
                .load(bikeServiceBrand.getImageUrl())
                .placeholder(R.drawable.ic_bike)
                .into(holder.iv_bikebrandImage);

        final String brandid = bikeServiceBrand.getId();


        holder.rl_bikebrand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println(brandid);
                Intent intent = new Intent(mcontext, BikeServiceSelectStateActivity.class);
                intent.putExtra("brandid",brandid);
                mcontext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return bikeBrandlist.size();
    }
}
