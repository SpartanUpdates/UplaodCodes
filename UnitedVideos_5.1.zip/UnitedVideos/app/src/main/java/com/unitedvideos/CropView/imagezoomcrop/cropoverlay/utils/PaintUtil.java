package com.unitedvideos.CropView.imagezoomcrop.cropoverlay.utils;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.TypedValue;

public class PaintUtil
{
  private static final int DEFAULT_CORNER_COLOR = -1;
  private static final String SEMI_TRANSPARENT = "#AA141414";
  private static final String DEFAULT_BACKGROUND_COLOR_ID = "#B029303F";
  private static final float DEFAULT_LINE_THICKNESS_DP = 1.0F;
  private static final float DEFAULT_CORNER_THICKNESS_DP = 5.0F;
  private static final float DEFAULT_GUIDELINE_THICKNESS_PX = 2.0F;
  
  public PaintUtil() {}
  
  public static Paint newBorderPaint(Context context)
  {
    float lineThicknessPx = TypedValue.applyDimension(1, 1.0F, context.getResources().getDisplayMetrics());
    
    Paint borderPaint = new Paint();
    borderPaint.setAntiAlias(true);
    borderPaint.setColor(Color.parseColor("#AA141414"));
    borderPaint.setStrokeWidth(lineThicknessPx);
    borderPaint.setStyle(Style.STROKE);
    
    return borderPaint;
  }
  public static Paint newGuidelinePaint()
  {
    Paint paint = new Paint();
    paint.setColor(Color.parseColor("#AA141414"));
    paint.setStrokeWidth(2.0F);
    
    return paint;
  }

  public static Paint newBackgroundPaint(Context context)
  {
    Paint paint = new Paint();
    paint.setColor(Color.parseColor("#B029303F"));
    
    return paint;
  }

  public static Paint newCornerPaint(Context context)
  {
    float lineThicknessPx = TypedValue.applyDimension(1, 5.0F, context.getResources().getDisplayMetrics());
    
    Paint cornerPaint = new Paint();
    cornerPaint.setColor(-1);
    cornerPaint.setStrokeWidth(lineThicknessPx);
    cornerPaint.setStyle(Style.STROKE);
    
    return cornerPaint;
  }

  public static float getCornerThickness()
  {
    return 5.0F;
  }
  public static float getLineThickness()
  {
    return 1.0F;
  }
}
