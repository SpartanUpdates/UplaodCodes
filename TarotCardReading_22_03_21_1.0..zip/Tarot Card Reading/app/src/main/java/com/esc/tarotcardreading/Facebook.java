package com.esc.tarotcardreading;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.CookieSyncManager;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;

public class Facebook {
    public static final String CANCEL_URI = "fbconnect://cancel";
    private static final int DEFAULT_AUTH_ACTIVITY_CODE = 32665;
    protected static String DIALOG_BASE_URL = "https://m.facebook.com/dialog/";
    public static final String EXPIRES = "expires_in";
    public static final String FB_APP_SIGNATURE = "30820268308201d102044a9c4610300d06092a864886f70d0101040500307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e3020170d3039303833313231353231365a180f32303530303932353231353231365a307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e30819f300d06092a864886f70d010101050003818d0030818902818100c207d51df8eb8c97d93ba0c8c1002c928fab00dc1b42fca5e66e99cc3023ed2d214d822bc59e8e35ddcf5f44c7ae8ade50d7e0c434f500e6c131f4a2834f987fc46406115de2018ebbb0d5a3c261bd97581ccfef76afc7135a6d59e8855ecd7eacc8f8737e794c60a761c536b72b11fac8e603f5da1a2d54aa103b8a13c0dbc10203010001300d06092a864886f70d0101040500038181005ee9be8bcbb250648d3b741290a82a1c9dc2e76a0af2f2228f1d9f9c4007529c446a70175c5a900d5141812866db46be6559e2141616483998211f4a673149fb2232a10d247663b26a9031e15f84bc1c74d141ff98a02d76f85b2c8ab2571b6469b232d8e768a7f7ca04f7abe4a775615916c07940656b58717457b42bd928a2";
    public static final int FORCE_DIALOG_AUTH = -1;
    protected static String GRAPH_BASE_URL = "https://graph.facebook.com/";
    private static final String LOGIN = "oauth";
    public static final String REDIRECT_URI = "fbconnect://success";
    protected static String RESTSERVER_URL = "https://api.facebook.com/restserver.php";
    public static final String SINGLE_SIGN_ON_DISABLED = "service_disabled";
    public static final String TOKEN = "access_token";
    private final long REFRESH_TOKEN_BARRIER = 86400000;
    private long mAccessExpires = 0;
    private String mAccessToken = null;
    private String mAppId;
    private Activity mAuthActivity;
    private int mAuthActivityCode;
    private DialogListener mAuthDialogListener;
    private String[] mAuthPermissions;
    private long mLastAccessUpdate = 0;

    public interface DialogListener {
        void onCancel();

        void onComplete(Bundle bundle);

        void onError(DialogError dialogError);

        void onFacebookError(FacebookError facebookError);
    }

    public interface ServiceListener {
        void onComplete(Bundle bundle);

        void onError(Error error);

        void onFacebookError(FacebookError facebookError);
    }

    private class TokenRefreshServiceConnection implements ServiceConnection {
        final Context applicationsContext;
        final Messenger messageReceiver = new Messenger(new Handler() {
            public void handleMessage(Message message) {
                String string = message.getData().getString(Facebook.TOKEN);
                Bundle data = message.getData();
                String str = Facebook.EXPIRES;
                long j = data.getLong(str) * 1000;
                data = (Bundle) message.getData().clone();
                data.putLong(str, j);
                if (string != null) {
                    Facebook.this.setAccessToken(string);
                    Facebook.this.setAccessExpires(j);
                    if (TokenRefreshServiceConnection.this.serviceListener != null) {
                        TokenRefreshServiceConnection.this.serviceListener.onComplete(data);
                    }
                } else if (TokenRefreshServiceConnection.this.serviceListener != null) {
                    string = message.getData().getString("error");
                    str = "error_code";
                    if (message.getData().containsKey(str)) {
                        TokenRefreshServiceConnection.this.serviceListener.onFacebookError(new FacebookError(string, null, message.getData().getInt(str)));
                    } else {
                        ServiceListener serviceListener = TokenRefreshServiceConnection.this.serviceListener;
                        if (string == null) {
                            string = "Unknown service error";
                        }
                        serviceListener.onError(new Error(string));
                    }
                }
                TokenRefreshServiceConnection.this.applicationsContext.unbindService(TokenRefreshServiceConnection.this);
            }
        });
        Messenger messageSender = null;
        final ServiceListener serviceListener;

        public TokenRefreshServiceConnection(Context context, ServiceListener serviceListener) {
            this.applicationsContext = context;
            this.serviceListener = serviceListener;
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            this.messageSender = new Messenger(iBinder);
            refreshToken();
        }

        public void onServiceDisconnected(ComponentName componentName) {
            this.serviceListener.onError(new Error("Service disconnected"));
            Facebook.this.mAuthActivity.unbindService(this);
        }

        private void refreshToken() {
            Bundle bundle = new Bundle();
            bundle.putString(Facebook.TOKEN, Facebook.this.mAccessToken);
            Message obtain = Message.obtain();
            obtain.setData(bundle);
            obtain.replyTo = this.messageReceiver;
            try {
                this.messageSender.send(obtain);
            } catch (RemoteException unused) {
                this.serviceListener.onError(new Error("Service connection error"));
            }
        }
    }

    public Facebook(String str) {
        if (str != null) {
            this.mAppId = str;
            return;
        }
        throw new IllegalArgumentException("You must specify your application ID when instantiating a Facebook object. See README for details.");
    }

    public void authorize(Activity activity, DialogListener dialogListener) {
        authorize(activity, new String[0], DEFAULT_AUTH_ACTIVITY_CODE, dialogListener);
    }

    public void authorize(Activity activity, String[] strArr, DialogListener dialogListener) {
        authorize(activity, strArr, DEFAULT_AUTH_ACTIVITY_CODE, dialogListener);
    }

    public void authorize(Activity activity, String[] strArr, int i, DialogListener dialogListener) {
        this.mAuthDialogListener = dialogListener;
        if (!(i >= 0 ? startSingleSignOn(activity, this.mAppId, strArr, i) : false)) {
            startDialogAuth(activity, strArr);
        }
    }

    private boolean startSingleSignOn(Activity activity, String str, String[] strArr, int i) {
        Intent intent = new Intent();
        intent.setClassName("com.facebook.katana", "com.facebook.katana.ProxyAuth");
        intent.putExtra("client_id", str);
        if (strArr.length > 0) {
            intent.putExtra("scope", TextUtils.join(",", strArr));
        }
        boolean z = false;
        if (!validateAppSignatureForIntent(activity, intent)) {
            return false;
        }
        this.mAuthActivity = activity;
        this.mAuthPermissions = strArr;
        this.mAuthActivityCode = i;
        try {
            activity.startActivityForResult(intent, i);
            z = true;
        } catch (ActivityNotFoundException unused) {
        }
        return z;
    }

    private boolean validateAppSignatureForIntent(Context context, Intent intent) {
        ResolveInfo resolveActivity = context.getPackageManager().resolveActivity(intent, 0);
        if (resolveActivity == null) {
            return false;
        }
        try {
            for (Signature toCharsString : context.getPackageManager().getPackageInfo(resolveActivity.activityInfo.packageName, 64).signatures) {
                if (toCharsString.toCharsString().equals(FB_APP_SIGNATURE)) {
                    return true;
                }
            }
        } catch (NameNotFoundException unused) {
            unused.printStackTrace();
        }
        return false;
    }

    private void startDialogAuth(Activity activity, String[] strArr) {
        Bundle bundle = new Bundle();
        if (strArr.length > 0) {
            bundle.putString("scope", TextUtils.join(",", strArr));
        }
        CookieSyncManager.createInstance(activity);
        dialog(activity, LOGIN, bundle, new DialogListener() {
            public void onComplete(Bundle bundle) {
                CookieSyncManager.getInstance().sync();
                Facebook.this.setAccessToken(bundle.getString(Facebook.TOKEN));
                Facebook.this.setAccessExpiresIn(bundle.getString(Facebook.EXPIRES));
                if (Facebook.this.isSessionValid()) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Login Success! access_token=");
                    stringBuilder.append(Facebook.this.getAccessToken());
                    stringBuilder.append(" expires=");
                    stringBuilder.append(Facebook.this.getAccessExpires());
                    Log.d("Facebook-authorize", stringBuilder.toString());
                    Facebook.this.mAuthDialogListener.onComplete(bundle);
                    return;
                }
                Facebook.this.mAuthDialogListener.onFacebookError(new FacebookError("Failed to receive access token."));
            }

            public void onError(DialogError dialogError) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Login failed: ");
                stringBuilder.append(dialogError);
                Log.d("Facebook-authorize", stringBuilder.toString());
                Facebook.this.mAuthDialogListener.onError(dialogError);
            }

            public void onFacebookError(FacebookError facebookError) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Login failed: ");
                stringBuilder.append(facebookError);
                Log.d("Facebook-authorize", stringBuilder.toString());
                Facebook.this.mAuthDialogListener.onFacebookError(facebookError);
            }

            public void onCancel() {
                Log.d("Facebook-authorize", "Login canceled");
                Facebook.this.mAuthDialogListener.onCancel();
            }
        });
    }

    public void authorizeCallback(int i, int i2, Intent intent) {
        if (i == this.mAuthActivityCode) {
            String str = "Login failed: ";
            String str2 = "Login canceled by user.";
            String str3 = "error";
            String str4 = "Facebook-authorize";
            if (i2 == -1) {
                String stringExtra = intent.getStringExtra(str3);
                if (stringExtra == null) {
                    stringExtra = intent.getStringExtra("error_type");
                }
                if (stringExtra == null) {
                    setAccessToken(intent.getStringExtra(TOKEN));
                    setAccessExpiresIn(intent.getStringExtra(EXPIRES));
                    if (isSessionValid()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Login Success! access_token=");
                        stringBuilder.append(getAccessToken());
                        stringBuilder.append(" expires=");
                        stringBuilder.append(getAccessExpires());
                        Log.d(str4, stringBuilder.toString());
                        this.mAuthDialogListener.onComplete(intent.getExtras());
                        return;
                    }
                    this.mAuthDialogListener.onFacebookError(new FacebookError("Failed to receive access token."));
                } else if (stringExtra.equals(SINGLE_SIGN_ON_DISABLED) || stringExtra.equals("AndroidAuthKillSwitchException")) {
                    Log.d(str4, "Hosted auth currently disabled. Retrying dialog auth...");
                    startDialogAuth(this.mAuthActivity, this.mAuthPermissions);
                } else if (stringExtra.equals("access_denied") || stringExtra.equals("OAuthAccessDeniedException")) {
                    Log.d(str4, str2);
                    this.mAuthDialogListener.onCancel();
                } else {
                    String stringExtra2 = intent.getStringExtra("error_description");
                    if (stringExtra2 != null) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(stringExtra);
                        stringBuilder2.append(":");
                        stringBuilder2.append(stringExtra2);
                        stringExtra = stringBuilder2.toString();
                    }
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(str);
                    stringBuilder3.append(stringExtra);
                    Log.d(str4, stringBuilder3.toString());
                    this.mAuthDialogListener.onFacebookError(new FacebookError(stringExtra));
                }
            } else if (i2 != 0) {
            } else {
                if (intent != null) {
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append(str);
                    stringBuilder4.append(intent.getStringExtra(str3));
                    Log.d(str4, stringBuilder4.toString());
                    this.mAuthDialogListener.onError(new DialogError(intent.getStringExtra(str3), intent.getIntExtra("error_code", -1), intent.getStringExtra("failing_url")));
                    return;
                }
                Log.d(str4, str2);
                this.mAuthDialogListener.onCancel();
            }
        }
    }

    public boolean extendAccessToken(Context context, ServiceListener serviceListener) {
        Intent intent = new Intent();
        intent.setClassName("com.facebook.katana", "com.facebook.katana.platform.TokenRefreshService");
        if (validateAppSignatureForIntent(context, intent)) {
            return context.bindService(intent, new TokenRefreshServiceConnection(context, serviceListener), 1);
        }
        return false;
    }

    public boolean extendAccessTokenIfNeeded(Context context, ServiceListener serviceListener) {
        return shouldExtendAccessToken() ? extendAccessToken(context, serviceListener) : true;
    }

    public boolean shouldExtendAccessToken() {
        return isSessionValid() && System.currentTimeMillis() - this.mLastAccessUpdate >= 86400000;
    }

    public String logout(Context context) throws MalformedURLException, IOException {
        Util.clearCookies(context);
        Bundle bundle = new Bundle();
        bundle.putString("method", "auth.expireSession");
        String request = request(bundle);
        setAccessToken(null);
        setAccessExpires(0);
        return request;
    }

    public String request(Bundle bundle) throws MalformedURLException, IOException {
        if (bundle.containsKey("method")) {
            return request(null, bundle, "GET");
        }
        throw new IllegalArgumentException("API method must be specified. (parameters must contain key \"method\" and value). See http://developers.facebook.com/docs/reference/rest/");
    }

    public String request(String str) throws MalformedURLException, IOException {
        return request(str, new Bundle(), "GET");
    }

    public String request(String str, Bundle bundle) throws MalformedURLException, IOException {
        return request(str, bundle, "GET");
    }

    public String request(String str, Bundle bundle, String str2) throws FileNotFoundException, MalformedURLException, IOException {
        bundle.putString("format", "json");
        if (isSessionValid()) {
            bundle.putString(TOKEN, getAccessToken());
        }
        if (str != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(GRAPH_BASE_URL);
            stringBuilder.append(str);
            str = stringBuilder.toString();
        } else {
            str = RESTSERVER_URL;
        }
        return Util.openUrl(str, str2, bundle);
    }

    public void dialog(Context context, String str, DialogListener dialogListener) {
        dialog(context, str, new Bundle(), dialogListener);
    }

    public void dialog(Context context, String str, Bundle bundle, DialogListener dialogListener) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DIALOG_BASE_URL);
        stringBuilder.append(str);
        String stringBuilder2 = stringBuilder.toString();
        bundle.putString("display", "touch");
        bundle.putString("redirect_uri", REDIRECT_URI);
        if (str.equals(LOGIN)) {
            bundle.putString("type", "user_agent");
            bundle.putString("client_id", this.mAppId);
        } else {
            bundle.putString("app_id", this.mAppId);
        }
        if (isSessionValid()) {
            bundle.putString(TOKEN, getAccessToken());
        }
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(stringBuilder2);
        stringBuilder3.append("?");
        stringBuilder3.append(Util.encodeUrl(bundle));
        str = stringBuilder3.toString();
        if (context.checkCallingOrSelfPermission("android.permission.INTERNET") != PackageManager.PERMISSION_GRANTED) {
            Util.showAlert(context, "Error", "Application requires permission to access the Internet");
        } else {
            new FbDialog(context, str, dialogListener).show();
        }
    }

    public boolean isSessionValid() {
        return getAccessToken() != null && (getAccessExpires() == 0 || System.currentTimeMillis() < getAccessExpires());
    }

    public String getAccessToken() {
        return this.mAccessToken;
    }

    public long getAccessExpires() {
        return this.mAccessExpires;
    }

    public void setAccessToken(String str) {
        this.mAccessToken = str;
        this.mLastAccessUpdate = System.currentTimeMillis();
    }

    public void setAccessExpires(long j) {
        this.mAccessExpires = j;
    }

    public void setAccessExpiresIn(String str) {
        if (str != null) {
            long j;
            if (str.equals("0")) {
                j = 0;
            } else {
                j = System.currentTimeMillis() + (Long.parseLong(str) * 1000);
            }
            setAccessExpires(j);
        }
    }

    public String getAppId() {
        return this.mAppId;
    }

    public void setAppId(String str) {
        this.mAppId = str;
    }
}
