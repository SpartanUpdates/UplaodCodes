package com.wavymusic.videolib.libffmpeg.exceptions;

public class FFmpegNotSupportedException extends Exception
{
  private static final long serialVersionUID = -441966701595002495L;
  
  public FFmpegNotSupportedException(String message) {
    super(message);
  }
}
