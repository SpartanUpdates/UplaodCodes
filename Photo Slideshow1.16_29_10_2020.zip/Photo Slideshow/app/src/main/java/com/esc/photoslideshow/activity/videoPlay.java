package com.esc.photoslideshow.activity;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;
import com.esc.photoslideshow.libffmpeg.FileUtils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.esc.photoslideshow.R;
import com.esc.photoslideshow.util.Utils;
import com.esc.photoslideshow.util.animUtil;
import com.esc.photoslideshow.util.apprater.AppRater;
import com.esc.photoslideshow.view.MyVideoView;
import java.io.File;
import java.util.Random;

import static com.esc.photoslideshow.view.CustomNativeAd.populateUnifiedNativeAdView;

public class videoPlay extends AppCompatActivity implements MyVideoView.PlayPauseListner, OnClickListener, OnSeekBarChangeListener {
    Activity activity = videoPlay.this;
    private int currentVideoDuration;
    private ImageView ivPlayPause;
    private android.os.Handler Handler;
    private boolean Complate;
    private File videoFile;
    private String StrVideoPath;
    private String strVideoName;
    private String videoDurationation;
    private String date;
    private Runnable runnable;
    private SeekBar SbVideo;
    private Long CaptureTime;
    private Toolbar toolbar;
    private MyVideoView myVideoView;
    private TextView tvDuration;
    private TextView tvEndDuration;
    private ImageView imgFacebook;
    private ImageView imgInstagram;
    private ImageView imgShare;
    private ImageView imgTwitter;
    private ImageView imgWhatsApp;

    public videoPlay() {
        this.Handler = new Handler();
        this.CaptureTime = Long.valueOf(0);
        this.runnable = new Runnable() {
            @Override
            public void run() {
                if (!videoPlay.this.Complate) {
                    videoPlay.this.currentVideoDuration = videoPlay.this.myVideoView
                            .getCurrentPosition();
                    videoPlay videoPlayActivity = videoPlay.this;
                    videoPlayActivity.CaptureTime = Long.valueOf(videoPlayActivity.CaptureTime.longValue() + 100);
                    videoPlay.this.tvDuration.setText(FileUtils
                            .getDuration(videoPlay.this.myVideoView
                                    .getCurrentPosition()));
                    videoPlay.this.tvEndDuration.setText(FileUtils
                            .getDuration(videoPlay.this.myVideoView
                                    .getDuration()));
                    videoPlay.this.SbVideo
                            .setProgress(videoPlay.this.currentVideoDuration);
                    videoPlay.this.Handler.postDelayed(this, 100);
                }
            }
        };
    }


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creationvideo_play);
        this.toolbar = findViewById(R.id.toolbar);
        this.myVideoView = findViewById(R.id.MyvideoView);
        this.tvDuration = findViewById(R.id.tvStartDuration);
        this.tvEndDuration = findViewById(R.id.tvEndDuration);
        this.ivPlayPause = findViewById(R.id.ivPlayPause);
        this.SbVideo = findViewById(R.id.VideoSeekbar);
        setSupportActionBar(this.toolbar);
        this.StrVideoPath = getIntent().getStringExtra("android.intent.extra.TEXT");
        this.strVideoName = getIntent().getStringExtra("Name");
        this.videoDurationation = getIntent().getStringExtra("Duration");
        this.date = getIntent().getStringExtra("Date");
        this.videoFile = new File(this.StrVideoPath);
        this.myVideoView.setVideoPath(this.StrVideoPath);
        getSupportActionBar().setHomeButtonEnabled(true);
        TextView mTitle = this.toolbar.findViewById(R.id.tvtittleToolbar);
        mTitle.setText(getString(R.string.sharemycreation));
        Utils.setFont(this, mTitle);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.myVideoView.setOnPlayPauseListner(this);
        this.myVideoView.setOnPreparedListener(new OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.seekTo(100);
                videoPlay.this.SbVideo.setMax(mp.getDuration());
                videoPlay.this.progressToTimer(mp.getDuration(),
                        mp.getDuration());
                videoPlay.this.tvDuration.setText(FileUtils
                        .getDuration(mp.getCurrentPosition()));
                videoPlay.this.tvEndDuration.setText(FileUtils
                        .getDuration(mp.getDuration()));
            }
        });
        findViewById(R.id.ClickVideo).setOnClickListener(this);
        this.myVideoView.setOnClickListener(this);
        this.ivPlayPause.setOnClickListener(this);
        this.SbVideo.setOnSeekBarChangeListener(this);
        this.myVideoView.setOnCompletionListener(new OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                videoPlay.this.Complate = true;
                videoPlay.this.Handler
                        .removeCallbacks(videoPlay.this.runnable);
                videoPlay.this.tvDuration.setText(FileUtils
                        .getDuration(mp.getDuration()));
                videoPlay.this.tvEndDuration.setText(FileUtils
                        .getDuration(mp.getDuration()));
            }
        });
        loadAd();
        this.imgWhatsApp = findViewById(R.id.imgFacebook);
        this.imgFacebook = findViewById(R.id.imgWhatsApp);
        this.imgInstagram = findViewById(R.id.imgInstagram);
        this.imgShare = findViewById(R.id.imgShare);
        this.imgTwitter = findViewById(R.id.imgTwitter);
        this.imgFacebook.setOnClickListener(this);
        this.imgInstagram.setOnClickListener(this);
        this.imgWhatsApp.setOnClickListener(this);
        this.imgTwitter.setOnClickListener(this);
        this.imgShare.setOnClickListener(this);
        PutAnalyticsEvent();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "videoPlay");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private UnifiedNativeAd nativeAd;
    private int id;
    private InterstitialAd mInterstitialAd;

    private void loadAd() {
        if (Utils.Utility.isNetworkAvailable(videoPlay.this)) {
            AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
            builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                @Override
                public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                    if (nativeAd != null) {
                        nativeAd.destroy();
                    }
                    findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                    nativeAd = unifiedNativeAd;
                    FrameLayout frameLayout =
                            findViewById(R.id.fl_adplaceholder);
                    UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                            .inflate(R.layout.ad_unified_small, null);
                    populateUnifiedNativeAdView(unifiedNativeAd, adView);
                    frameLayout.removeAllViews();
                    frameLayout.addView(adView);
                }

            });
            VideoOptions videoOptions = new VideoOptions.Builder().build();
            NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
            builder.withNativeAdOptions(adOptions);
            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            }).build();
            adLoader.loadAd(new AdRequest.Builder().build());
            mInterstitialAd = new InterstitialAd(this);
            mInterstitialAd.setAdUnitId(this.getString(R.string.admob_inter));
            mInterstitialAd.loadAd(new AdRequest.Builder().addTestDevice("A82A510A487DC76124317D6A70B3E4DD").build());
            mInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    switch (id) {
                        case 100:
                            Intent intent = new Intent(videoPlay.this, ActivityVideoAlbum.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                            intent.putExtra("KEY", ActivityVideoAlbum.EXTRA_FROM_VIDEO);
                            startActivity(intent);
                            finish();
                            break;
                        case 200:
                            intent = new Intent(videoPlay.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                            startActivity(intent);
                            finish();
                            break;
                        case 300:
                            intent = new Intent(videoPlay.this, ActivityVideoAlbum.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                            animUtil.startActivitySafely(toolbar, intent);
                            finish();
                            break;
                        case 400:
                            intent = new Intent(videoPlay.this, ActivityVideoAlbum.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                            startActivity(intent);
                            finish();
                            break;

                    }
                    requestNewInterstitial();
                }
            });

//            interstitialAd = new InterstitialAd(videoPlay.this, getResources().getString(R.string.FB_inter4));
//            interstitialAd.setAdListener(new InterstitialAdListener() {
//                @Override
//                public void onInterstitialDisplayed(Ad ad) {
//                }
//
//                @Override
//                public void onInterstitialDismissed(Ad ad) {
//                    dialogAd.dismiss();
//                    switch (id) {
//                        case 100:
//                            Intent intent = new Intent(videoPlay.this, ActivityVideoAlbum.class);
//                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                            intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
//                            intent.putExtra("KEY", ActivityVideoAlbum.EXTRA_FROM_VIDEO);
//                            startActivity(intent);
//                            finish();
//                            break;
//                        case 200:
//                            Intent intent = new Intent(videoPlay.this, MainActivity.class);
//                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                            intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
//                            startActivity(intent);
//                            finish();
//                            break;
//                        case 300:
//                            intent = new Intent(videoPlay.this, ActivityVideoAlbum.class);
//                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                            intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
//                            animUtil.startActivitySafely(toolbar, intent);
//                            finish();
//                            break;
//                        case 400:
//                            intent = new Intent(videoPlay.this, ActivityVideoAlbum.class);
//                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                            intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
//                            startActivity(intent);
//                            finish();
//                            break;
//                    }
//                    requestNewInterstitial();
//                }

//                @Override
//                public void onError(Ad ad, AdError adError) {
//                }
//
//                @Override
//                public void onAdLoaded(Ad ad) {
//                }
//
//                @Override
//                public void onAdClicked(Ad ad) {
//
//                }
//
//                @Override
//                public void onLoggingImpression(Ad ad) {
//                }
//            });
//            interstitialAd.loadAd();
        }

    }

    private void requestNewInterstitial() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    protected void onPause() {
        super.onPause();
        this.myVideoView.pause();
    }

    public View onCreateView(View view, String str, Context context,
                             AttributeSet attributeSet) {
        return super.onCreateView(view, str, context, attributeSet);
    }

    public View onCreateView(String str, Context context,
                             AttributeSet attributeSet) {
        return super.onCreateView(str, context, attributeSet);
    }

    public void onVideoPause() {
        if (!(this.Handler == null || this.runnable == null)) {
            this.Handler.removeCallbacks(this.runnable);
        }
        Animation animation = new AlphaAnimation(0.0f,
                1.0f);
        animation.setDuration(500);
        animation.setFillAfter(true);
        this.ivPlayPause.startAnimation(animation);
        animation.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                videoPlay.this.ivPlayPause.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
            }
        });
    }

    public void onVideoPlay() {
        updateProgressBar();
        Animation animation = new AlphaAnimation(
                1.0f, 0.0f);
        animation.setDuration(500);
        animation.setFillAfter(true);
        this.ivPlayPause.startAnimation(animation);
        animation.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                videoPlay.this.ivPlayPause.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                videoPlay.this.ivPlayPause.setVisibility(View.INVISIBLE);
            }
        });
    }

    public void updateProgressBar() {
        try {
            this.Handler.removeCallbacks(this.runnable);
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.Handler.postDelayed(this.runnable, 100);
    }

    public boolean onCreateOptionsMenu(final Menu menu) {
        this.getMenuInflater().inflate(R.menu.delete_video, menu);
        return true;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.MyvideoView:
            case R.id.ClickVideo:
            case R.id.ivPlayPause:
                if (this.myVideoView.isPlaying()) {
                    this.myVideoView.pause();
                    return;
                }
                this.myVideoView.start();
                this.Complate = false;
                break;
            case R.id.imgFacebook:
                shareImageWhatsApp("com.facebook.katana", "Facebook");
                return;
            case R.id.imgInstagram:
                shareImageWhatsApp("com.instagram.android", "Instagram");
                return;
            case R.id.imgShare:
               /* Parcelable fromFile;
                if (Build.VERSION.SDK_INT <= 19) {
                    fromFile = Uri.fromFile(new File(this.StrVideoPath));
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(getPackageName());
                    stringBuilder.append(".provider");
                    fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(this.StrVideoPath));
                }
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("video/mp4");
                intent.putExtra("android.intent.extra.STREAM", fromFile);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));*/
                Uri ShareUri;
                if (Build.VERSION.SDK_INT <= 19) {
                    ShareUri = FileProvider.getUriForFile(activity, String.valueOf(getPackageName()) + ".provider", new File(this.StrVideoPath));
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(getPackageName());
                    stringBuilder.append(".provider");
                    ShareUri = FileProvider.getUriForFile(activity, String.valueOf(getPackageName()) + ".provider", new File(this.StrVideoPath));
                }
                Log.e("TAG", "VideoPath" + StrVideoPath);
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("video/mp4");
                intent.putExtra("android.intent.extra.STREAM", ShareUri);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));
                return;
            case R.id.imgTwitter:
                shareImageWhatsApp("com.twitter.android", "Twitter");
                return;
            case R.id.imgWhatsApp:
                shareImageWhatsApp("com.whatsapp", "Whatsapp");
                return;
            default:
        }
    }

    private boolean isPackageInstalled(final String s, final Context context) {
        final PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(s, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ex) {
            return false;
        }
    }

    /*public void shareImageWhatsApp(String str, String str2) {
        Parcelable fromFile;
        if (Build.VERSION.SDK_INT <= 19) {
            fromFile = Uri.fromFile(new File(this.StrVideoPath));
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getPackageName());
            stringBuilder.append(".provider");
            fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(this.StrVideoPath));
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/mp4");
        intent.putExtra("android.intent.extra.STREAM", fromFile);
        if (isPackageInstalled(str, getApplicationContext())) {
            intent.setPackage(str);
            startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Please Install ");
        stringBuilder2.append(str2);
        Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_SHORT).show();
    }*/

    public void shareImageWhatsApp(String str, String str2) {
        Uri ShareUri;
        if (Build.VERSION.SDK_INT <= 19) {
            ShareUri = FileProvider.getUriForFile(activity, String.valueOf(getPackageName()) + ".provider", new File(this.StrVideoPath));
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getPackageName());
            stringBuilder.append(".provider");
            ShareUri = FileProvider.getUriForFile(activity, String.valueOf(getPackageName()) + ".provider", new File(this.StrVideoPath));

        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/mp4");
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        if (isPackageInstalled(str, getApplicationContext())) {
            intent.setPackage(str);
            startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Please Install ");
        stringBuilder2.append(str2);
        Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_LONG).show();
    }


    public void onProgressChanged(SeekBar seekBar, int progress,
                                  boolean fromUser) {
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        this.Handler.removeCallbacks(this.runnable);
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
        this.Handler.removeCallbacks(this.runnable);
        this.currentVideoDuration = progressToTimer(seekBar.getProgress(),
                this.myVideoView.getDuration());
        this.myVideoView.seekTo(seekBar.getProgress());
        if (this.myVideoView.isPlaying()) {
            updateProgressBar();
        }
    }

    public int progressToTimer(int progress, int totalDuration) {
        return ((int) ((((double) progress) / 100.0d) * ((double) (totalDuration / 1000))))
                * 1000;
    }

    protected void onDestroy() {
        this.myVideoView.stopPlayback();
        this.Handler.removeCallbacks(this.runnable);
        super.onDestroy();
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
//                id = 300;
//                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
//                    dialogAd.show();
//                    AdsDialogShow();
//                } else {
//                    Intent intent = new Intent(this, ActivityVideoAlbum.class);
//                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                    intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
//                    animUtil.startActivitySafely(this.toolbar, intent);
//                    finish();
//                }
                onBackPressed();
                break;
            case R.id.action_delete:
                if (this.myVideoView.isPlaying()) {
                    this.myVideoView.pause();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(videoPlay.this,
                        R.style.Theme_MovieMaker_AlertDialog);
                builder.setTitle("Delete Video !");
                builder.setMessage("Are you sure to delete?");
                builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        FileUtils.deleteFile(new File(
                                StrVideoPath));
                        startActivity(new Intent(videoPlay.this, ActivityVideoAlbum.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        finish();
                    }
                });
                builder.setNegativeButton("Cancel", null);
                builder.show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        Intent intent;
        if (getIntent().getExtras().get("KEY").equals("FromVideoAlbum")) {
            if (new Random().nextInt(100) > 50) {
                AppRater.showRateDialog(this);
                AppRater.setCallback(new AppRater.Callback() {
                    @Override
                    public void onCancelClicked() {
                        final Intent intent = new Intent(videoPlay.this, ActivityVideoAlbum.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra("EXTRA_FROM_VIDEO", true);
                        videoPlay.this.startActivity(intent);
                        videoPlay.this.finish();
                    }

                    @Override
                    public void onNoClicked() {
                    }

                    @Override
                    public void onYesClicked() {
                    }
                });
                return;
            }
            id = 400;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                intent = new Intent(this, ActivityVideoAlbum.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                startActivity(intent);
                finish();
            }
        } else if (getIntent().getExtras().get("KEY").equals("FromProgress")) {
            id = 100;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                intent = new Intent(this, ActivityVideoAlbum.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                intent.putExtra("KEY", ActivityVideoAlbum.EXTRA_FROM_VIDEO);
                startActivity(intent);
                finish();
            }
        } else if (getIntent().getExtras().get("KEY").equals("FromNotify")) {
            id = 200;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                intent = new Intent(this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                startActivity(intent);
                finish();
            }
        } else {
            super.onBackPressed();
        }
    }
}
