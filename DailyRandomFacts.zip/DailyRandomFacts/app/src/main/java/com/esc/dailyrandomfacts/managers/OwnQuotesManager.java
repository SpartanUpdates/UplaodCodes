package com.esc.dailyrandomfacts.managers;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.List;

public class OwnQuotesManager {
    private static final String PREF_OWN_QUOTES = "pref_own_quotescom.esc.dailyrandomfacts.facts_";

    public static ArrayList<String> getOwnQuotes() {
        String string = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext()).getString(PREF_OWN_QUOTES, null);
        if (string != null) {
            return (ArrayList) new Gson().fromJson(string, new TypeToken<List<String>>() {
            }.getType());
        }
        return new ArrayList();
    }

    public static void addOwnQuote(String str) {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext());
        ArrayList ownQuotes = getOwnQuotes();
        if (ownQuotes == null) {
            ownQuotes = new ArrayList();
        }
        ownQuotes.add(str);
        Editor edit = defaultSharedPreferences.edit();
        edit.putString(PREF_OWN_QUOTES, new Gson().toJson(ownQuotes));
        edit.commit();
    }

    public static void removeOwnQuote(String str) {
        ArrayList ownQuotes = getOwnQuotes();
        ownQuotes.remove(str);
        Editor edit = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext()).edit();
        if (str != null) {
            edit.putString(PREF_OWN_QUOTES, new Gson().toJson(ownQuotes));
        }
        edit.commit();
    }
}
