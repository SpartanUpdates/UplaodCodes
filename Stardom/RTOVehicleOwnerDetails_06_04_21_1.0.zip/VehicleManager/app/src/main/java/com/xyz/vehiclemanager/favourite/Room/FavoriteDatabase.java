package com.xyz.vehiclemanager.favourite.Room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.xyz.vehiclemanager.favourite.model.FavoriteBikeModel;
import com.xyz.vehiclemanager.favourite.model.FavoriteCarModel;
@Database(entities = {FavoriteCarModel.class, FavoriteBikeModel.class},version = 1 ,exportSchema = false)
public abstract class FavoriteDatabase extends RoomDatabase {
    public abstract FavoriteCarDao favoriteCarDao();
    public abstract FavoriteBikeDao favoriteBikeDao();
    public static FavoriteDatabase favoriteDatabase;
    public static FavoriteDatabase getFavoriteDatabase(final Context context) {
        if (favoriteDatabase == null) {
            synchronized (FavoriteDatabase.class) {
                if (favoriteDatabase == null) {
                    favoriteDatabase = Room.databaseBuilder(context,
                            FavoriteDatabase.class, "Favorite")
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return favoriteDatabase;
    }
}
