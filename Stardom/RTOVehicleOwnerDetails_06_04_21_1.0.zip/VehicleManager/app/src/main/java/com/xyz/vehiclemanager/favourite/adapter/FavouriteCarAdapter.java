package com.xyz.vehiclemanager.favourite.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.activity.BikeVariantActivity;
import com.xyz.vehiclemanager.favourite.Room.FavoriteDatabase;
import com.xyz.vehiclemanager.favourite.model.FavoriteCarModel;

import java.util.List;

public class FavouriteCarAdapter extends RecyclerView.Adapter<FavouriteCarAdapter.ViewHolder> {

    private Context context;
    List<FavoriteCarModel> favoriteCarModelList;

    public FavouriteCarAdapter(Context context, List<FavoriteCarModel> favoriteCarModelList) {
        this.context = context;
        this.favoriteCarModelList = favoriteCarModelList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_bikemodelname, tv_bikemodelprice;
        ImageView iv_bikecategory;
        LikeButton likeButton;
        LinearLayout ll_main;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_bikemodelname =itemView.findViewById(R.id.tv_carname);
            tv_bikemodelprice =itemView.findViewById(R.id.tv_modelprice);
            iv_bikecategory =itemView.findViewById(R.id.iv_category);
            likeButton=itemView.findViewById(R.id.likeButton);
            ll_main = itemView.findViewById(R.id.ll_main);
        }
    }

    private void deleteItem(int position2) {
        favoriteCarModelList.remove(position2);
        notifyItemRemoved(position2);
        notifyItemRangeChanged(position2, favoriteCarModelList.size());
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_favorite, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final FavoriteCarModel favoriteCarModel=favoriteCarModelList.get(position);
        final String modelId=favoriteCarModel.getModelId();
        holder.tv_bikemodelname.setText(favoriteCarModel.getModelName());
        holder.tv_bikemodelprice.setText(favoriteCarModel.getExShowroomPrice());
        Glide.with(context)
                .load(favoriteCarModel.getImageUrl())
                .placeholder(R.drawable.ic_car)
                .into(holder.iv_bikecategory);
        holder.likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                Thread thread=new Thread(new Runnable() {
                    @Override
                    public void run() {
                        FavoriteDatabase.getFavoriteDatabase(context).favoriteCarDao().insertCarFavorite(favoriteCarModel);
                    }
                });
                thread.start();
            }
            @Override
            public void unLiked(LikeButton likeButton) {
                Thread thread=new Thread(new Runnable() {
                    @Override
                    public void run() {
                        FavoriteDatabase.getFavoriteDatabase(context).favoriteCarDao().deleteCarFavorite(modelId);
                        deleteItem(position);
                    }
                });
                thread.start();

            }
        });
        holder.ll_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, BikeVariantActivity.class);
                intent.putExtra("modelId",modelId);
                intent.putExtra("modelName", favoriteCarModel.getModelName());
                intent.putExtra("imageUrl",favoriteCarModel.getImageUrl());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }
    @Override
    public int getItemCount() {
        return favoriteCarModelList.size();
    }
}
