package com.esc.howtomakeschoolsupplies.data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import java.util.ArrayList;
import java.util.List;

public class LikesContract {

    public static final class DBEntry implements BaseColumns {
        public static final String COLUMN_ARTICLE_ID = "article_id";
        public static final String TABLE_NAME_FAVORITES = "favorites";
        public static final String TABLE_NAME_LIKES = "likes";
        public static final String _ID = "_id";
    }

    private LikesContract() {
    }

    public static List<Integer> databaseInfoValues(Context context, String str) {
        SQLiteDatabase readableDatabase = new LikesDbHelper(context).getReadableDatabase();
        String[] strArr = new String[1];
        String str2 = DBEntry.COLUMN_ARTICLE_ID;
        strArr[0] = str2;
        Cursor query = readableDatabase.query(str, strArr, null, null, null, null, null);
        int columnIndex = query.getColumnIndex(str2);
        ArrayList arrayList = new ArrayList();
        while (query.moveToNext()) {
            arrayList.add(Integer.valueOf(query.getInt(columnIndex)));
        }
        query.close();
        readableDatabase.close();
        return arrayList;
    }

    public static List<Integer> getFavoriteList(Context context) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = new LikesDbHelper(context).getReadableDatabase();
        String[] strArr = new String[1];
        String str = DBEntry.COLUMN_ARTICLE_ID;
        strArr[0] = str;
        Cursor query = readableDatabase.query(DBEntry.TABLE_NAME_FAVORITES, strArr, null, null, null, null, null);
        int columnIndex = query.getColumnIndex(str);
        while (query.moveToNext()) {
            arrayList.add(Integer.valueOf(query.getInt(columnIndex)));
        }
        query.close();
        return arrayList;
    }
}
