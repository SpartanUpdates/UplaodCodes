package com.kotlinz.festivalstorymaker.Listener.SetListener;


import android.app.Activity;

import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew.c;

public class HDimageStickerView implements c {
    HighlightDetailsDetailActivity activity;
    public final ImageStickerViewNew imageStickerView;
    public final HighlightDetailsDetailActivity.g b;

    public HDimageStickerView(Activity activity, HighlightDetailsDetailActivity.g gVar, ImageStickerViewNew imageStickerViewNew) {
        this.activity = (HighlightDetailsDetailActivity) activity;
        this.b = gVar;
        this.imageStickerView = imageStickerViewNew;
    }

    public void a(ImageStickerViewNew imageStickerViewNew) {
        activity.svScroll.requestDisallowInterceptTouchEvent(true);
        ImageStickerViewNew imageStickerViewNew2 = activity.T;
        if (imageStickerViewNew2 != null) {
            imageStickerViewNew2.setInEdit(false);
        }
        activity.T = imageStickerViewNew;
        imageStickerViewNew.setInEdit(true);
    }

    public void b(ImageStickerViewNew imageStickerViewNew) {
        activity.flElements.removeView(imageStickerViewNew);
    }

    public void c(Boolean bool) {
        activity.svScroll.requestDisallowInterceptTouchEvent(bool.booleanValue());
        if (bool.booleanValue()) {
            activity.T = this.imageStickerView;
        }
    }

    public void d(ImageStickerViewNew imageStickerViewNew) {
    }
}
