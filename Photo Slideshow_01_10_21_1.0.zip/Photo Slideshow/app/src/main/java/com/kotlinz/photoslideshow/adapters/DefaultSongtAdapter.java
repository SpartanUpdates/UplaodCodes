package com.kotlinz.photoslideshow.adapters;

import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.kotlinz.photoslideshow.R;
import com.kotlinz.photoslideshow.activity.DefaultSongActivity;

import java.util.ArrayList;

public class DefaultSongtAdapter extends BaseAdapter {
    Context context;
    int SelectdeSongPosition = 0;
    ArrayList<String> songName;
    SparseBooleanArray booleanArray = new SparseBooleanArray();

    public DefaultSongtAdapter(Context cnx, ArrayList<String> name) {
        this.context = cnx;
        this.songName = name;
        booleanArray.put(0, true);
    }

    public int getCount() {
        return this.songName.size();
    }

    public Object getItem(int arg0) {
        return this.songName.get(arg0);
    }

    public long getItemId(int arg0) {
        return (long) arg0;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(this.context).inflate(R.layout.row_default_song, parent, false);
        }
        RelativeLayout rlMain = convertView.findViewById(R.id.rl_main);
        CheckBox cbSelectSong = convertView.findViewById(R.id.ivImageSong);
        TextView tvname = convertView.findViewById(R.id.tvname);
        tvname.setText(songName.get(position));
        cbSelectSong.setChecked(this.booleanArray.get(position, false));
        cbSelectSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                booleanArray.clear();
                DefaultSongtAdapter.this.SelectdeSongPosition = position;
                booleanArray.put(SelectdeSongPosition, true);
                ((DefaultSongActivity) DefaultSongtAdapter.this.context).setMusic(SelectdeSongPosition);
                notifyDataSetChanged();
            }
        });
        rlMain.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View arg0) {
                booleanArray.clear();
                DefaultSongtAdapter.this.SelectdeSongPosition = position;
                booleanArray.put(SelectdeSongPosition, true);
                ((DefaultSongActivity) DefaultSongtAdapter.this.context).setMusic(SelectdeSongPosition);
                notifyDataSetChanged();
            }
        });
        return convertView;
    }
}