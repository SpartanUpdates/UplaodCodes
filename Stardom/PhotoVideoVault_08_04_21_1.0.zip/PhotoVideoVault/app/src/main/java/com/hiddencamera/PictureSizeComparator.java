package com.hiddencamera;

import android.hardware.Camera.Size;

import java.util.Comparator;

class PictureSizeComparator implements Comparator<Size> {
    @Override
    public int compare(final Size cameraSize, final Size cameraSize2) {
        return cameraSize2.height * cameraSize2.width - cameraSize.height * cameraSize.width;
    }
}
