package com.MV.Lyrics.SelectImage.Fragment;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.MV.Lyrics.R;
import com.MV.Lyrics.SelectImage.Adapter.VideoAdapter;
import com.MV.Lyrics.SelectImage.Interface.OnItemClickListner;
import com.MV.Lyrics.SelectImage.Model.ImageModel;
import com.MV.Lyrics.SelectImage.Model.VideoModel;
import com.MV.Lyrics.VideoTrim.activity.TrimVideoActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;

public class VideoMediaFragment extends Fragment {

    private RecyclerView rvVideo;
    private VideoAdapter videoAdapter;
    public ArrayList<VideoModel> VideoList = new ArrayList<>();
    public String FolderName;

    RelativeLayout rlLoadingTheme;
    public static Fragment getInstance(String foldername) {
        Bundle bundle = new Bundle();
        bundle.putString("FolderName", foldername);
        VideoMediaFragment videoMediaFragment = new VideoMediaFragment();
        videoMediaFragment.setArguments(bundle);
        return videoMediaFragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FolderName = getArguments().getString("FolderName");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_selected_media, container, false);
        BindView(view);
//        getAllVideoByFolderWise(FolderName);
        new GetAllVideoByFolder().execute();
        return view;
    }

    private void BindView(View view) {
        rvVideo = view.findViewById(R.id.rv_media);
        rlLoadingTheme=view.findViewById(R.id.rl_loading_pager);
    }

    private void SetVideoAdapter() {
        videoAdapter = new VideoAdapter(getActivity(), VideoList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        rvVideo.setLayoutManager(mLayoutManager);
        rvVideo.setAdapter(videoAdapter);
        videoAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(View view, int position) {
                Intent intent=new Intent(getActivity(),TrimVideoActivity.class);
                intent.putExtra("VideoPath", VideoList.get(position).getVideoFullPath());
                startActivity(intent);
                getActivity().finish();
            }
        });
    }

    /*public void getAllVideoByFolderWise(String foldename) {
        VideoList.clear();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        Cursor cursor = getContext().getContentResolver()
                .query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, MediaStore.Video.Media.BUCKET_DISPLAY_NAME + " =?", new String[]{FolderName}, MediaStore.Video.Media.DATE_ADDED);
        ArrayList<VideoModel> videolist = new ArrayList<>(cursor.getCount());
        HashSet<String> albumSet = new HashSet<>();
        File file;
        if (cursor.moveToFirst()) {
            final int duration = cursor.getColumnIndex("duration");
            final int data = cursor.getColumnIndex("_data");
            final int name = cursor.getColumnIndex("title");
            final int dateTaken = cursor.getColumnIndex("datetaken");
            do {
                if (Thread.interrupted()) {
                    return;
                }
                final VideoModel videoData = new VideoModel();
                videoData.videoDuration = cursor.getLong(duration);
                videoData.videoFullPath = cursor.getString(data);
                videoData.videoName = cursor.getString(name);
                videoData.dateTaken = cursor.getLong(dateTaken);
                file = new File(videoData.videoFullPath);
                if (file.exists() && !albumSet.contains(videoData.videoFullPath)) {
                    videolist.add(videoData);
                    albumSet.add(videoData.videoFullPath);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        if (videolist == null) {
            videolist = new ArrayList<>();
        }
        VideoList.clear();
        VideoList.addAll(videolist);
    }*/

    @SuppressLint("StaticFieldLeak")
    public class GetAllVideoByFolder extends AsyncTask<Void, Void, Void> {

        protected void onPreExecute() {
            VideoList.clear();
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected Void doInBackground(Void... arg0) {
            final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
            Cursor cursor = getContext().getContentResolver()
                    .query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, MediaStore.Video.Media.BUCKET_DISPLAY_NAME + " =?", new String[]{FolderName}, MediaStore.Video.Media.DATE_ADDED);
            ArrayList<VideoModel> videolist = new ArrayList<>(cursor.getCount());
            HashSet<String> albumSet = new HashSet<>();
            File file;
            if (cursor.moveToFirst()) {
                final int duration = cursor.getColumnIndex("duration");
                final int data = cursor.getColumnIndex("_data");
                final int name = cursor.getColumnIndex("title");
                final int dateTaken = cursor.getColumnIndex("datetaken");
                do {
                    final VideoModel videoData = new VideoModel();
                    videoData.videoDuration = cursor.getLong(duration);
                    videoData.videoFullPath = cursor.getString(data);
                    videoData.videoName = cursor.getString(name);
                    videoData.dateTaken = cursor.getLong(dateTaken);
                    file = new File(videoData.videoFullPath);
                    if (file.exists() && !albumSet.contains(videoData.videoFullPath)) {
                        videolist.add(videoData);
                        albumSet.add(videoData.videoFullPath);
                    }
                } while (cursor.moveToNext());
            }
            cursor.close();
            if (videolist == null) {
                videolist = new ArrayList<>();
            }
            VideoList.clear();
            VideoList.addAll(videolist);
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(Void result) {
            rlLoadingTheme.setVisibility(View.GONE);
            SetVideoAdapter();
        }
    }

}