package com.kotlinz.festivalstorymaker.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.QuoteMakerCatAdapter;
import com.kotlinz.festivalstorymaker.Adapter.QuoteSubCategoryAdapter;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.CategoryWiseData.QuoteCategoryWiseData;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.CategoryWiseData.QuoteCategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.QuoteMainCategory;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.QuoteMakerResponse;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QuoteMakerActivity extends BaseActivity {

    Activity activity = QuoteMakerActivity.this;

    @BindView(com.kotlinz.festivalstorymaker.R.id.rv_quote_category)
    public RecyclerView rvQuoteMakerCategory;

    @BindView(R.id.rv_quote_subcategory)
    public RecyclerView rvQuoteSubCategory;


    private int ModuleId;

    APIInterface apiInterface;
    private ProgressDialog progressDialog;

    ArrayList<QuoteMainCategory> quoteMainCategories;
    QuoteMakerCatAdapter quoteMakerCatListAdapter;
    public RecyclerView.LayoutManager mLayoutManager;

    public ArrayList<QuoteCategoryWiseData> quoteSubCategoryList;
    public QuoteSubCategoryAdapter quoteSubCategoryAdapter;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onClick(View view) {
        int id = view.getId();
        if (id == com.kotlinz.festivalstorymaker.R.id.iv_back) {
            finish();
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.kotlinz.festivalstorymaker.R.layout.activity_quote_maker);
        ButterKnife.bind(this);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        ModuleId = getIntent().getIntExtra("moduleid", 0);
        PutAnalyticsEvent();
        InitProgressDialog();
        BannerAds();
        GetQuoteList(ModuleId);
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "QuoteMakerActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(com.kotlinz.festivalstorymaker.R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(com.kotlinz.festivalstorymaker.R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void GetQuoteList(int ModuleId) {
        progressDialog.show();
        Call<QuoteMakerResponse> call = apiInterface.getQuoteModuleWiseCategory(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<QuoteMakerResponse>() {
            @Override
            public void onResponse(Call<QuoteMakerResponse> call, Response<QuoteMakerResponse> response) {
                if (response.isSuccessful()) {
                    quoteMainCategories = response.body().getData();
                    quoteMakerCatListAdapter = new QuoteMakerCatAdapter(activity, quoteMainCategories);
                    mLayoutManager = new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false);
                    rvQuoteMakerCategory.setLayoutManager(mLayoutManager);
                    rvQuoteMakerCategory.setAdapter(quoteMakerCatListAdapter);

                    GetStoryCategoryDataByID(String.valueOf(quoteMainCategories.get(0).getCatId()), String.valueOf(quoteMainCategories.get(0).getChildCategory().get(0).getChildCatId()));
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<QuoteMakerResponse> call, Throwable t) {

            }
        });
    }

    public void GetStoryCategoryDataByID(String ParentCatId, String ChildCatId) {
        progressDialog.show();
        Call<QuoteCategoryWiseResponse> call = apiInterface.getQuoteCategoryWiseData(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId), "0", ParentCatId, ChildCatId);
        call.enqueue(new Callback<QuoteCategoryWiseResponse>() {
            @Override
            public void onResponse(Call<QuoteCategoryWiseResponse> call, Response<QuoteCategoryWiseResponse> response) {
                if (response.isSuccessful()) {
                    quoteSubCategoryList = response.body().getData();
                    quoteSubCategoryAdapter = new QuoteSubCategoryAdapter(activity, quoteSubCategoryList);
                    mLayoutManager = new LinearLayoutManager(activity, RecyclerView.VERTICAL, false);
                    rvQuoteSubCategory.setLayoutManager(mLayoutManager);
                    rvQuoteSubCategory.setAdapter(quoteSubCategoryAdapter);
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<QuoteCategoryWiseResponse> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }


    @OnClick(R.id.iv_my_creation)
    public void MyCreation() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, MyPostActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 22;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(activity, MyPostActivity.class));
                finish();
            }
        }
    }

    @OnClick(R.id.iv_back)
    public void Back(View view) {
        onBackPressed();
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, DashBordActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 21;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(activity, DashBordActivity.class));
                finish();
            }
        }
    }
}