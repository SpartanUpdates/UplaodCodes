package com.claptoflashlightonoff.util;

import android.hardware.Camera;
import java.util.ArrayList;

public class Utility {
    public static final String PREF_NAME = "flashlightonclap";
    public static Camera camera = null;
    public static boolean flagWidget = false;
    public static boolean soundCheck = true;
    public static boolean tempCameraOpenChecker;

    public static ArrayList<String> listIcon;
    public static ArrayList<String> listName;
    public static ArrayList<String> listUrl;
    public static ArrayList<String> listStatus;

    static {
        listIcon = new ArrayList();
        listName = new ArrayList();
        listUrl = new ArrayList();
        listStatus = new ArrayList();
    }
}
