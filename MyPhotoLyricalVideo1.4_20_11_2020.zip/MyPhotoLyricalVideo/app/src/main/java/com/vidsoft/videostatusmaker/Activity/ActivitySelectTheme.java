package com.vidsoft.videostatusmaker.Activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import com.vidsoft.videostatusmaker.adapter.ThemeAdapter;

public class ActivitySelectTheme extends AppCompatActivity {

    ThemeAdapter themeAdapter;
    ImageView ivBack;
    Typeface typeface;
    ImageLoader imageLoader;
    GridView stylelist;
    String[] theme;
    TextView title;

    private void initImageLoader() {
        (this.imageLoader = ImageLoader.getInstance()).init(new ImageLoaderConfiguration.Builder((Context) this).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).build()).build());
    }

    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.select_typface);
        this.getWindow().addFlags(1024);
        loadAd();
        this.initImageLoader();
        init();
    }


    private NativeBannerAd mNativeBannerAd;

    private void loadAd() {
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(ActivitySelectTheme.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                nativeBannerAdContainer.setVisibility(View.VISIBLE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });

        mNativeBannerAd.loadAd();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
    }

    private void init() {
        this.ivBack = this.findViewById(R.id.back);
        this.title = this.findViewById(R.id.title);
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivitySelectTheme.this.onBackPressed();
            }
        });
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.title.setTypeface(this.typeface);
        this.title.setText((CharSequence) "Themes");
        this.stylelist = this.findViewById(R.id.stylelist);
        try {
            this.theme = this.getResources().getAssets().list("theme");
            this.themeAdapter = new ThemeAdapter(this.getApplicationContext(), this.theme);
            this.stylelist.setAdapter((ListAdapter) this.themeAdapter);
            this.stylelist.setNumColumns(2);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.stylelist.setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int theme, final long n) {
                if (theme == 0) {
                    Log.e("LOG", "====11111====");
                    ActivityPreview.THEME = theme;
                    ActivityPreview.complete = false;
                    if (theme == 4) {
                        Log.e("LOG", "====22222====");
                        ActivityPreview.lyricTxt1.setTextColor(-16777216);
                        ActivityPreview.lyricTxt2.setTextColor(-16777216);
                    } else {
                        Log.e("LOG", "====33333====");
                        ActivityPreview.lyricTxt1.setTextColor(-1);
                        ActivityPreview.lyricTxt2.setTextColor(-1);
                    }
                    Log.e("LOG", "====44444====");
                    ActivitySelectTheme.this.setResult(-1, new Intent(ActivitySelectTheme.this.getApplicationContext(), (Class) ActivityPreview.class));
                    ActivitySelectTheme.this.finish();
                    return;
                }
                Log.e("LOG","====5555555====");
                ActivityPreview.complete = false;
                ActivityPreview.THEME = theme;
                if (n == 4) {
                    Log.e("LOG","====66666====");
                    ActivityPreview.lyricTxt1.setTextColor(-16777216);
                    ActivityPreview.lyricTxt2.setTextColor(-16777216);
                } else if (n == 5) {
                    Log.e("LOG","====777777====");
                    ActivityPreview.lyricTxt1.setTextColor(Color.parseColor("#000004"));
                    ActivityPreview.lyricTxt2.setTextColor(Color.parseColor("#000004"));
                } else {
                    Log.e("LOG","====88888====");
                    ActivityPreview.lyricTxt1.setTextColor(-1);
                    ActivityPreview.lyricTxt2.setTextColor(-1);
                }
                ActivitySelectTheme.this.setResult(-1, new Intent(ActivitySelectTheme.this.getApplicationContext(), (Class) ActivityPreview.class));
                ActivitySelectTheme.this.finish();
            }
        });
    }
}
