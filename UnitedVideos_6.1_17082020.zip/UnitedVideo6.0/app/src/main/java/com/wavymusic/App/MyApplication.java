package com.wavymusic.App;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;

import com.UnitedVideos.AppConstant.UvConstant;
import com.UnitedVideos.ArrangeImages.activity.ArrangePhotosActivityUv;
import com.UnitedVideos.TextChange.activity.TextEditActivityUv;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.gson.JsonObject;
import com.root.UnitySendValue.AndroidUnityCall;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.CropImage.Model.CropImage;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.ExitApplication.activity.ExitAppActivity;
import com.wavymusic.ImageSelection.Model.ImageModel;
import com.wavymusic.MyCreationVideo.activity.YourVideoActivity;
import com.wavymusic.R;
import com.wavymusic.TextChange.activity.TextEditActivity;
import com.wavymusic.UnityPlayerActivity;
import com.wavymusic.VideoPlayer.activity.VideoPlayerActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;

public class MyApplication extends Application {

    private static MyApplication instance;
    public static Context mContext;
    public static String SPLIT_PATTERN;
    public static String AppName = "United Videos";
    //Image Selection
    public final ArrayList<ImageModel> selectedImages;
    public static int TotalSelectedImage;
    public static boolean IsSelectImageFrom;
    public int min_pos;
    public HashMap<String, ArrayList<ImageModel>> allAlbum;
    private ArrayList<String> allFolder;
    private String selectedFolderId;

    /*Image Crop*/
    public final ArrayList<CropImage> cropimaglist;

    /*Created Video path*/
    public static String VidoePath;

    /*Song Crop Variable*/
    public static boolean IsSongCuttingready = false;
    public static boolean IsVideoready = false;
    public static boolean IsAudioVideoMearge = false;
    public static String CutSongPath;

    /*Theme Selected Position*/
    public static int ThemePositionWavy = -1;
    public static int CatSelectedPositionWavy = -1;

    public static int ThemePositionUv = -1;
    public static int CatSelectedPositionUv = -1;

    /*Use For home Native Ads Loaded ot Not*/
    public boolean IsNativeAdsLoaded = false;
    public AdLoader adLoader;
    public List<UnifiedNativeAd> mNativeAds = new ArrayList<>();

    /*Use For Preview Bottom Button*/
    public static String StyleStatus = "Close";
    public static String FilterStatus = "Close";
    public static String LightsStatus = "Close";

    /*Use For Partical And Category Selection*/
  /*  public static int ThemeAssetCatSelectedPosition = -1;
    public static int ThemeAssetSelectedPosition = -1;
    public static int ParticalCatid = -1;
    public static int ParticalSelectedCatid = -1;*/

    public static String ThemeAssetCatSelectedPosition = "";
    public static String ThemeAssetSelectedPosition = "";
    public static String ParticalCatid = "";
    public static String ParticalSelectedCatid = "";
    /*Use For Api Call Runnnig or Not*/
    public static boolean isEditCallWavy = false;
    public static Call<JsonObject> TempcallWavy;

    //    public static boolean isEditCallUv = false;
    public static Call<JsonObject> TempcallUv;


    /*Use For HomeActivity First Time Ads Display*/
    public static boolean IsHomeAdsDisplay = false;
    public static Context AppLaunchContex;
    /*Path*/

    /*Facebook Ads Wavy*/
    public static InterstitialAd fbinterstitialAd;
    /*AddMob Wavy*/
    public static com.google.android.gms.ads.InterstitialAd mInterstitialAdWavy;
    public static int AdsId;

    /*Facebook Ads Uv*/
    public static InterstitialAd fbinterstitialAdUv;
    /*AddMob Uv*/
    public static com.google.android.gms.ads.InterstitialAd mInterstitialAdUv;
    public static int AdsIdUv;

    public static Activity AdsShowContext;
    public String result_conc = "";
    public static String AllFilePath;
    public static String FinalSongPath;

    /*United Videos*/
    public final ArrayList<String> cropimaglistUV;
    public static boolean SkipAll;
    public static boolean isBreak;
    public boolean isEditModeEnable;
    public boolean IsBack = false;
    public int posForAddMusicDialog;


    public MyApplication() {
        selectedImages = new ArrayList<ImageModel>();
        cropimaglist = new ArrayList<CropImage>();
        cropimaglistUV = new ArrayList<String>();
        min_pos = Integer.MAX_VALUE;
        posForAddMusicDialog = 0;
    }

    static {
        MyApplication.TotalSelectedImage = 5;
        MyApplication.SPLIT_PATTERN = "?";
        MyApplication.SkipAll = false;
        MyApplication.isBreak = false;
    }

    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        MyApplication.mContext = this.getApplicationContext();
        MobileAds.initialize(MyApplication.mContext, MyApplication.mContext.getResources().getString(R.string.admob_app_id));
        AudienceNetworkAds.initialize(this);
        AdSettings.addTestDevice("483d1447-297b-479e-9c89-4237a410cd8b");
        LoadfbInterstitialAds();
        LoadInterstitialAdAdmobWavy();
        LoadfbInterstitialAdsUv();
        LoadInterstitialAdAdmobUv();
        loadNativeAds();
    }

    private void LoadfbInterstitialAds() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial_Wavy));
        fbinterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                switch (AdsId) {
                    /*Wavy Music Start*/
                    case 1:
                        SelectedImages();
                        break;
                    case 2:
                        GoToPreview();
                        break;
                    case 3:
                        GoToExit();
                        break;
                    case 5:
                        SongSelect();
                        break;
                    case 6:
                        GetJsonResponse();
                        break;
                    case 7:
                        CloseVideoPlayer();
                        break;
                    case 8:
                        Log.e("TAG", "UnityPlayerActAdsShow");
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        fbinterstitialAd.loadAd();
    }

    private void requestNewInterstitial() {
        if (fbinterstitialAd != null) {
            fbinterstitialAd.loadAd();
        } else {
            fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial_Wavy));
            fbinterstitialAd.loadAd();
        }
    }

    private void LoadInterstitialAdAdmobWavy() {
        mInterstitialAdWavy = new com.google.android.gms.ads.InterstitialAd(this);
        mInterstitialAdWavy.setAdUnitId(getResources().getString(R.string.interstitial_Wavy));
        mInterstitialAdWavy.loadAd(new AdRequest.Builder().build());
        mInterstitialAdWavy.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (AdsId) {
                    /*Wavy Music Start*/
                    case 1:
                        SelectedImages();
                        break;
                    case 2:
                        GoToPreview();
                        break;
                    case 3:
                        GoToExit();
                        break;
                    case 5:
                        SongSelect();
                        break;
                    case 6:
                        GetJsonResponse();
                        break;
                    case 7:
                        CloseVideoPlayer();
                        break;
                    case 8:
                        Log.e("TAG", "UnityPlayerActAdsShow");
                        break;
                }
                requestNewInterstitialAdmobWavy();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    private void requestNewInterstitialAdmobWavy() {
//        mInterstitialAdWavy = new com.google.android.gms.ads.InterstitialAd(this);
//        mInterstitialAdWavy.setAdUnitId(getResources().getString(R.string.interstitial_Wavy));
        mInterstitialAdWavy.loadAd(new AdRequest.Builder().build());
    }

    private void LoadfbInterstitialAdsUv() {
        fbinterstitialAdUv = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial_Uv));
        fbinterstitialAdUv.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                switch (AdsIdUv) {
                    /*Uv Video Start*/
                    case 1:
                        SelectImagesUv();
                        break;
                    case 2:
                        GoToPreViewUv();
                        break;
                    case 3:
                        GetJsonResopnseUv();
                        break;

                }
                requestNewInterstitialUv();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        fbinterstitialAdUv.loadAd();
    }

    private void requestNewInterstitialUv() {
        if (fbinterstitialAdUv != null) {
            fbinterstitialAdUv.loadAd();
        } else {
            fbinterstitialAdUv = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial_Uv));
            fbinterstitialAdUv.loadAd();
        }
    }

    private void LoadInterstitialAdAdmobUv() {
        mInterstitialAdUv = new com.google.android.gms.ads.InterstitialAd(this);
        mInterstitialAdUv.setAdUnitId(getResources().getString(R.string.interstitialUv));
        mInterstitialAdUv.loadAd(new AdRequest.Builder().build());
        mInterstitialAdUv.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (AdsIdUv) {
                    /*Uv Video Start*/
                    case 1:
                        SelectImagesUv();
                        break;
                    case 2:
                        GoToPreViewUv();
                        break;
                    case 3:
                        GetJsonResopnseUv();
                        break;
                }
                requestNewInterstitialAdmobUv();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    private void requestNewInterstitialAdmobUv() {
//        mInterstitialAdUv = new com.google.android.gms.ads.InterstitialAd(this);
//        mInterstitialAdUv.setAdUnitId(getResources().getString(R.string.interstitialUv));
        mInterstitialAdUv.loadAd(new AdRequest.Builder().build());
    }

    private void SelectedImages() {
        for (int i = 0; i < this.getCropImages().size(); ++i) {
            if (i == 0) {
                result_conc = this.getCropImages().get(i).a();
            } else {
                result_conc = String.valueOf(result_conc) + MyApplication.SPLIT_PATTERN + this.getCropImages().get(i).a();
            }
        }
        UnityPlayer.UnitySendMessage("WavyThemeData", "SetUserImage", result_conc);
        AdsShowContext.finish();
    }


    public void GoToPreview() {
        UnityPlayer.UnitySendMessage("AndroidManager", "GoWavyPreview", MyApplication.AllFilePath);
        HideShowUnityBannerAds();
        AdsShowContext.finish();
    }

    private void HideShowUnityBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void GoToExit() {
        Intent intent = new Intent(AdsShowContext, ExitAppActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        AdsShowContext.finish();
    }

    private void GoBack() {
        Intent intent = new Intent(AdsShowContext, DashbordActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        AdsShowContext.finish();
    }

    private void SongSelect() {
        UnityPlayer.UnitySendMessage("WavyThemeData", "LoadMusic", FinalSongPath);
        AdsShowContext.finish();
    }

    public void GetJsonResponse() {
        String ChangeTextResponse = TextEditActivity.GetJsonArray(TextEditActivity.textList);
        UnityPlayer.UnitySendMessage("WavyThemeData", "ReturnTextResponce", ChangeTextResponse);
        AdsShowContext.finish();
    }

    private void CloseVideoPlayer() {
        if (VideoPlayerActivity.IsFromAndroidlist) {
            Intent intent = new Intent(this, YourVideoActivity.class);
            startActivity(intent);
            AdsShowContext.finish();
        } else {
            AndroidUnityCall.ScanVideoList(AdsShowContext, MyApplication.VidoePath);
//            UnityPlayer.UnitySendMessage("StackManager", "ResetEveryThing", "");
            Intent intent = new Intent(this, YourVideoActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            AdsShowContext.finish();
        }
    }


    /*Uv Video Start*/
    private void SelectImagesUv() {
        isEditModeEnable = false;
        if (ArrangePhotosActivityUv.Preview) {
            AdsShowContext.setResult(-1);
            AdsShowContext.finish();
        } else {
            loadPreview();
        }
    }

    private void loadPreview() {
        for (int i = 0; i < getCropImagesUV().size(); ++i) {
            if (i == 0) {
                result_conc = getCropImagesUV().get(i);
            } else {
                result_conc = result_conc + MyApplication.SPLIT_PATTERN + getCropImagesUV().get(i);
            }
        }
        SendDataToUnity();
    }

    public void SendDataToUnity() {
        UnityPlayer.UnitySendMessage("UVThemeData", "GetImagePath", result_conc);
        AdsShowContext.finish();
    }

    private void GoToPreViewUv() {
        HideShowUnityBannerAds();
        String AllFilePath = UvConstant.BundelPath + MyApplication.SPLIT_PATTERN + UvConstant.PrefebName + MyApplication.SPLIT_PATTERN + UvConstant.AudioPath + MyApplication.SPLIT_PATTERN + UvConstant.VideoType;
        UnityPlayer.UnitySendMessage("AndroidManager", "GoUVPreview", AllFilePath);
        AdsShowContext.finish();
    }

    private void GetJsonResopnseUv() {
        String a = TextEditActivityUv.a(TextEditActivityUv.a);
        UnityPlayer.UnitySendMessage("UVThemeData", "ReturnTextResponce", a);
        AdsShowContext.finish();
    }

    //Use For Preview Activity Button Status Update
    public static void StatusUpdate(String stylestatus, String filterstatus, String lightsStatus) {
        StyleStatus = stylestatus;
        FilterStatus = filterstatus;
        LightsStatus = lightsStatus;
    }

    //Use For Home Activity Theme Between Ads Show
    private void loadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getString(R.string.native_ad_home));
        adLoader = builder.forUnifiedNativeAd(
                new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                    @Override
                    public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                        mNativeAds.add(unifiedNativeAd);
                        MyApplication.getInstance().IsNativeAdsLoaded = true;
                    }
                }).withAdListener(
                new AdListener() {
                    @Override
                    public void onAdFailedToLoad(int errorCode) {
                        MyApplication.getInstance().IsNativeAdsLoaded = false;
                    }
                }).build();
        // Load the Native ads.
        adLoader.loadAds(new AdRequest.Builder().build(), 5);
    }

    public void init() {
        this.getFolderList();
    }

    public static String getFileName(String str) {
        return str.substring(str.lastIndexOf("/") + 1);
    }

    public String getSelectedFolderId() {
        return this.selectedFolderId;
    }

    public void setSelectedFolderId(final String selectedFolderId) {
        this.selectedFolderId = selectedFolderId;
    }

    public HashMap<String, ArrayList<ImageModel>> getAllAlbum() {
        return this.allAlbum;
    }

    public ArrayList<ImageModel> getImageByAlbum(final String folderId) {
        ArrayList<ImageModel> imageDatas = this.getAllAlbum().get(folderId);
        if (imageDatas == null) {
            imageDatas = new ArrayList<ImageModel>();
        }
        return imageDatas;
    }

    public ArrayList<ImageModel> getSelectedImages() {
        return this.selectedImages;
    }

    public void addSelectedImage(final ImageModel imageData) {
        this.selectedImages.add(imageData);
        ++imageData.imageCount;
    }

    public void removeSelectedImage(final int imageData) {
        if (imageData <= this.selectedImages.size()) {
            final ImageModel imageData2 = this.selectedImages.remove(imageData);
            --imageData2.imageCount;
        }
    }

    public void ReplaceSelectedImage(ImageModel imageData, int pos) {
        this.selectedImages.set(pos, imageData);
    }

    //Get All Images From Storage
    public void getFolderList() {
        this.allFolder = new ArrayList<String>();
        this.allAlbum = new HashMap<String, ArrayList<ImageModel>>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "bucket_id", "datetaken", "_data"};
        final Uri images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "_data";
        final Cursor cur = this.getContentResolver().query(images, projection, (String) null, (String[]) null, "_data DESC");
        if (cur.moveToFirst()) {
            final int bucketColumnName = cur.getColumnIndex("bucket_display_name");
            final int bucketIdColumnId = cur.getColumnIndex("bucket_id");

            ImageModel data = null;
            this.setSelectedFolderId(cur.getString(bucketIdColumnId));
            do {
                data = new ImageModel();
                data.imagePath = cur.getString(cur.getColumnIndex("_data"));
                data.imageThumbnail = cur.getString(cur.getColumnIndex("_data"));
                if (!data.imagePath.endsWith(".gif")) {
                    final String folderName = cur.getString(bucketColumnName);
                    final String folderId = cur.getString(bucketIdColumnId);
                    if (!allFolder.contains(folderId)) {
                        allFolder.add(folderId);
                    }
                    ArrayList<ImageModel> imagePath = this.allAlbum.get(folderName);
                    if (imagePath == null) {
                        imagePath = new ArrayList<ImageModel>();
                    }
                    data.folderName = folderName;
                    imagePath.add(data);
                    this.allAlbum.put(folderName, imagePath);


                }
            } while (cur.moveToNext());
        }
    }

    //Image Crop Wavy
    public ArrayList<CropImage> getCropImages() {
        return this.cropimaglist;
    }

    public void AddCropImages(CropImage imageData) {
        this.cropimaglist.add(imageData);

    }

    public void ReplaceCropImages(ImageModel imageData, int pos) {
        this.selectedImages.set(pos, imageData);
    }

    public void removecropImage(int imageData) {
        cropimaglist.remove(imageData);

    }


    //United Videos
    public ArrayList<String> getCropImagesUV() {
        return cropimaglistUV;
    }

    public void AddCropImagesUV(String imageData) {
        this.cropimaglistUV.add(imageData);

    }

    public void removecropImageUv(int imageData) {
        cropimaglistUV.remove(imageData);

    }
}
