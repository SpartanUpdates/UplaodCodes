package com.kotlinz.videoeditor.audiovideomixer.Utils;

public class TimeUtils {



    public static String toFormattedTime(int i) {
        int i2 = i / 3600000;
        int i3 = i - (3600000 * i2);
        int i4 = (i3 - ((i3 / 60000) * 60000)) / 1000;
        if (i2 > 0) {
            return String.format("%02d:%02d:%02d", new Object[]{Integer.valueOf(i2), Integer.valueOf(0), Integer.valueOf(i4)});
        }
        return String.format("%02d:%02d", new Object[]{Integer.valueOf(0), Integer.valueOf(i4)});
    }
}
