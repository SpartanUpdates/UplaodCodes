package com.xyz.vehiclemanager.history.Fragment;

import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.history.Adapter.LicenseHistoryAdapter;
import com.xyz.vehiclemanager.history.Adapter.OwnerInfoHistoryAdapter;
import com.xyz.vehiclemanager.history.Model.LicenseHistory;
import com.xyz.vehiclemanager.history.Model.OwnerHistory;
import com.xyz.vehiclemanager.history.Room.HistoryDatabase;
import com.xyz.vehiclemanager.rtoownerdetails.rtovehiclelicense.model.VehicleLicenseRoot;

import java.util.ArrayList;
import java.util.List;

public class LicenseInfoFragment extends Fragment
{
    private View view;
    private RecyclerView rv_owner;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_ownerhistory, container, false);
        rv_owner =view.findViewById(R.id.rv_owner);
        gettingDataFromDb();
        return view;
    }
    private void gettingDataFromDb()
    {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run()
            {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run()
                    {
                        List<LicenseHistory> licenceHistoryList= HistoryDatabase.getDatabase(getActivity()).licenseHistoryDao().getLicenseHistory();
                        LicenseHistoryAdapter licenseHistoryAdapter=new LicenseHistoryAdapter(getActivity(), licenceHistoryList);
                        rv_owner.setAdapter(licenseHistoryAdapter);
                        rv_owner.setLayoutManager(new LinearLayoutManager(getActivity()));
                        rv_owner.setHasFixedSize(true);
                    }
                });
            }
        });
        thread.start();
    }
}