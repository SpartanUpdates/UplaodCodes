package com.kotlinz.festivalstorymaker.Interface;

public interface g {
    void N(final int p0);

    void Q(final int p0, final int p1);
}
