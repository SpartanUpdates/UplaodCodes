package com.esc.phoneheart.utility;

import android.annotation.SuppressLint;
import android.os.Environment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

public class StorageHelper {
    public static final String[] AVOIDED_DEVICES = new String[]{"rootfs", "tmpfs", "dvpts", "proc", "sysfs", "none"};
    public static final String[] AVOIDED_DIRECTORIES = new String[]{"obb", "asec"};
    public static final String[] DISALLOWED_FILESYSTEMS = new String[]{"tmpfs", "rootfs", "romfs", "devpts", "sysfs", "proc", "cgroup", "debugfs"};
    public static final String STORAGES_ROOT;
    public static String prefixEmuPath = "/storage/emulated";

    public static final class StorageVolume {
        public final String device;
        public final File file;
        public final String fileSystem;
        public boolean mEmulated;
        public boolean mReadOnly;
        public boolean mRemovable;
        public Type mType;

        public enum Type {
            INTERNAL,
            EXTERNAL,
            USB
        }

        public StorageVolume(String str, File file2, String str2) {
            this.device = str;
            this.file = file2;
            this.fileSystem = str2;
        }

        public synchronized boolean equals(Object obj) {
            boolean z = true;
            if (obj == this) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            StorageVolume storageVolume = (StorageVolume) obj;
            if (this.file != null) {
                return this.file.equals(storageVolume.file);
            } else if (storageVolume.file != null) {
                z = false;
            }
            return false;
        }

        public Type getType() {
            return this.mType;
        }

        public int hashCode() {
            File file2 = this.file;
            return 31 + (file2 == null ? 0 : file2.hashCode());
        }

        public boolean isEmulated() {
            return this.mEmulated;
        }

        public boolean isReadOnly() {
            return this.mReadOnly;
        }

        public boolean isRemovable() {
            return this.mRemovable;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(this.file.getAbsolutePath());
            sb.append(this.mReadOnly ? " ro " : " rw ");
            sb.append(this.mType);
            String str = "";
            sb.append(this.mRemovable ? " R " : str);
            if (this.mEmulated) {
                str = " E ";
            }
            sb.append(str);
            sb.append(this.fileSystem);
            return sb.toString();
        }
    }

    static {
        String absolutePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        int indexOf = absolutePath.indexOf(File.separatorChar, 1);
        if (indexOf != -1) {
            STORAGES_ROOT = absolutePath.substring(0, indexOf + 1);
        } else {
            STORAGES_ROOT = File.separator;
        }
    }

    public static synchronized <T> boolean arrayContains(T[] tArr, T t) {
        synchronized (StorageHelper.class) {
            for (Object equals : tArr) {
                if (equals.equals(t)) {
                    return true;
                }
            }
            return false;
        }
    }

    public static synchronized boolean containsIgnoreCase(String str, String str2) {
        synchronized (StorageHelper.class) {
            if (str != null && str2 != null) {
                int length = str2.length();
                int length2 = str.length() - length;
                for (int i = 0; i <= length2; i++) {
                    if (str.regionMatches(true, i, str2, 0, length)) {
                        return true;
                    }
                }
                return false;
            }
        }
        return false;
    }

    @SuppressLint({"NewApi"})
    public static synchronized ArrayList<File> getStorages(boolean z) {
        ArrayList<File> arrayList;
        BufferedReader bufferedReader = null;
        IOException e;
        HashMap hashMap = new HashMap();
        synchronized (StorageHelper.class) {
            arrayList = new ArrayList<>();
            if (!STORAGES_ROOT.equals(File.separator)) {
                try {
                    bufferedReader = new BufferedReader(new FileReader("/proc/mounts"));
                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                }
                while (true) {
                    try {
                        String readLine = bufferedReader.readLine();
                        if (readLine != null) {
                            StringTokenizer stringTokenizer = new StringTokenizer(readLine, " ");
                            String nextToken = stringTokenizer.nextToken();
                            if (!arrayContains(AVOIDED_DEVICES, nextToken)) {
                                String nextToken2 = stringTokenizer.nextToken();
                                if (nextToken2.startsWith(STORAGES_ROOT)) {
                                    if (!pathContainsDir(nextToken2, AVOIDED_DIRECTORIES)) {
                                        String nextToken3 = stringTokenizer.nextToken();
                                        if (!arrayContains(DISALLOWED_FILESYSTEMS, nextToken3)) {
                                            if (nextToken2.toLowerCase().equals(prefixEmuPath)) {
                                                StringBuilder sb = new StringBuilder();
                                                sb.append(nextToken2);
                                                sb.append("/0");
                                                nextToken2 = sb.toString();
                                            }
                                            if (!arrayList.contains(new File(nextToken2))) {
                                                arrayList.add(new File(nextToken2));
                                            }
                                            PrintStream printStream = System.out;
                                            StringBuilder sb2 = new StringBuilder();
                                            sb2.append("File path is=========");
                                            sb2.append(nextToken2);
                                            printStream.println(sb2.toString());
                                            File file = new File(nextToken2);
                                            if (file.canRead()) {
                                                if (file.canExecute()) {
                                                    List list = (List) hashMap.get(nextToken);
                                                    if (list == null) {
                                                        list = new ArrayList(3);
                                                        hashMap.put(nextToken, list);
                                                    }
                                                    StorageVolume storageVolume = new StorageVolume(nextToken, file, nextToken3);
                                                    StringTokenizer stringTokenizer2 = new StringTokenizer(stringTokenizer.nextToken(), ",");
                                                    while (true) {
                                                        if (!stringTokenizer2.hasMoreTokens()) {
                                                            break;
                                                        }
                                                        String nextToken4 = stringTokenizer2.nextToken();
                                                        if (!nextToken4.equals("rw")) {
                                                            if (nextToken4.equals("ro")) {
                                                                storageVolume.mReadOnly = true;
                                                            }
                                                        } else {
                                                            storageVolume.mReadOnly = false;
                                                        }
                                                    }
                                                    list.add(storageVolume);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }
        File externalStorageDirectory = Environment.getExternalStorageDirectory();
        ArrayList arrayList2 = new ArrayList();
        boolean z2 = false;
//        for (Entry value : hashMap.entrySet()) {
//            List list2 = (List) value.getValue();
//            if (list2.size() != 1) {
//                int size = list2.size();
//                int i = 0;
//                while (true) {
//                    if (i >= size) {
//                        break;
//                    }
//                    StorageVolume storageVolume2 = (StorageVolume) list2.get(i);
//                    if (storageVolume2.file.equals(externalStorageDirectory)) {
//                        setTypeAndAdd(arrayList2, storageVolume2, z, true);
//                        z2 = true;
//                        break;
//                    }
//                    if (i == size - 1) {
//                        setTypeAndAdd(arrayList2, storageVolume2, z, false);
//                    }
//                    i++;
//                }
//            } else {
//                StorageVolume storageVolume3 = (StorageVolume) list2.get(0);
//                boolean equals = storageVolume3.file.equals(externalStorageDirectory);
//                z2 |= equals;
//                setTypeAndAdd(arrayList2, storageVolume3, z, equals);
//            }
//        }
        if (!z2) {
            StorageVolume storageVolume4 = new StorageVolume("", externalStorageDirectory, "UNKNOWN");
            storageVolume4.mEmulated = Environment.isExternalStorageEmulated();
            storageVolume4.mType = storageVolume4.mEmulated ? StorageVolume.Type.INTERNAL : StorageVolume.Type.EXTERNAL;
            storageVolume4.mRemovable = Environment.isExternalStorageRemovable();
            storageVolume4.mReadOnly = Environment.getExternalStorageState().equals("mounted_ro");
            arrayList2.add(0, storageVolume4);
        }

        return arrayList;
    }

    public static synchronized boolean pathContainsDir(String str, String[] strArr) {
        synchronized (StorageHelper.class) {
            StringTokenizer stringTokenizer = new StringTokenizer(str, File.separator);
            while (true) {
                int i = 0;
                if (stringTokenizer.hasMoreElements()) {
                    str = stringTokenizer.nextToken();
                    int length = strArr.length;
                    while (i < length) {
                        if (str.equals(strArr[i])) {
                            return true;
                        }
                        i++;
                    }
                } else {
                    return false;
                }
            }
        }
    }

    public static synchronized StorageVolume.Type resolveType(StorageVolume storageVolume) {
        synchronized (StorageHelper.class) {
            StorageVolume.Type type;
            if (storageVolume.file.equals(Environment.getExternalStorageDirectory()) && Environment.isExternalStorageEmulated()) {
                type = StorageVolume.Type.INTERNAL;
                return type;
            } else if (containsIgnoreCase(storageVolume.file.getAbsolutePath(), "usb")) {
                type = StorageVolume.Type.USB;
                return type;
            } else {
                type = StorageVolume.Type.EXTERNAL;
                return type;
            }
        }
    }

    public static synchronized void setTypeAndAdd(List<StorageVolume> list, StorageVolume storageVolume, boolean z, boolean z2) {
        synchronized (StorageHelper.class) {
            StorageVolume.Type resolveType = resolveType(storageVolume);
            if (z || resolveType != StorageVolume.Type.USB) {
                storageVolume.mType = resolveType;
                boolean z3 = true;
                if (storageVolume.file.equals(Environment.getExternalStorageDirectory())) {
                    storageVolume.mRemovable = Environment.isExternalStorageRemovable();
                } else {
                    storageVolume.mRemovable = resolveType != StorageVolume.Type.INTERNAL;
                }
                if (resolveType != StorageVolume.Type.INTERNAL) {
                    z3 = false;
                }
                storageVolume.mEmulated = z3;
                if (z2) {
                    list.add(0, storageVolume);
                } else {
                    list.add(storageVolume);
                }
            }
        }
    }
}
