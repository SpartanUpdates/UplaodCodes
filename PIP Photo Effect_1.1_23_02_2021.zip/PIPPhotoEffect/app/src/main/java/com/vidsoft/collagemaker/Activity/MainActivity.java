package com.vidsoft.collagemaker.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeAdView;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.vidsoft.collagemaker.GridAct.ImageSelectionActivity;
import com.vidsoft.collagemaker.GridThreeD.GridSelectionActivity;
import com.vidsoft.collagemaker.Model.StickerData;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Const;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static ArrayList<StickerData> stickerArrayList;
    public static int stickerValue;
    String[] PERMISSIONS;
    public int PERMISSION_ALL;
    Activity activity;
    Editor edit;
    SharedPreferences sharedPreferences;

    public MainActivity() {
        this.activity = this;
        this.PERMISSION_ALL = 23;
        this.PERMISSIONS = new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"};
    }

    static {
        stickerArrayList = new ArrayList();
        stickerValue = 0;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loadAd();
        init();
    }

    private void init() {
        this.sharedPreferences = getSharedPreferences(Const.PRFS_NAME, 0);
        this.edit = this.sharedPreferences.edit();
        this.edit.putString(Const.PRFS_ADS1, Const.PRFS_ADS1);
        this.edit.apply();
        findViewById(R.id.ll3dCollage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ll3dCollage;
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    dialogAd.show();
                    AdsDialogShow();
                } else {
                    threeD_collage();

                }
            }
        });

        findViewById(R.id.llCollage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.llCollage;
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    dialogAd.show();
                    AdsDialogShow();
                } else {
                    collagebtnClick();
                }
            }
        });

        findViewById(R.id.llText).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.llText;
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    dialogAd.show();
                    AdsDialogShow();
                } else {
                    textcollageClick();

                }
            }
        });
        findViewById(R.id.llMyCreation).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.llMyCreation;
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    dialogAd.show();
                    AdsDialogShow();
                } else {
                    myAlbumClick();
                }
            }


        });
    }

    private void textcollageClick() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (!hasPermissions(MainActivity.this, PERMISSIONS)) {
                ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS,
                        4);
            } else {
                gotoActivity(FrameListActivity.class);
            }
        } else {
            gotoActivity(FrameListActivity.class);
        }
    }

    private void myAlbumClick() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (!hasPermissions(MainActivity.this, PERMISSIONS)) {
                ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS,
                        3);
            } else {
                gotoActivity(MyCreationActivity.class);
            }
        } else {
            gotoActivity(MyCreationActivity.class);
        }
    }

    private void threeD_collage() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (!hasPermissions(MainActivity.this, PERMISSIONS)) {
                ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS,
                        2);
            } else {
                gotoActivity(GridSelectionActivity.class);
            }
        } else {
            gotoActivity(GridSelectionActivity.class);
        }
    }

    public void collagebtnClick() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (!hasPermissions(MainActivity.this, PERMISSIONS)) {
                ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS,
                        1);
            } else {
                gotoActivity(ImageSelectionActivity.class);
            }
        } else {
            gotoActivity(ImageSelectionActivity.class);
        }
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1:
                for (int i = 0; i < grantResults.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(
                                MainActivity.this,
                                "Sorry We cant process ahed due to denied pemission",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                collagebtnClick();
                return;
            case 2:
                for (int i = 0; i < grantResults.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(
                                MainActivity.this,
                                "Sorry We cant process ahed due to denied pemission",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                threeD_collage();
                return;
            case 3:
                for (int i = 0; i < grantResults.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(
                                MainActivity.this,
                                "Sorry We cant process ahed due to denied pemission",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                myAlbumClick();
                return;
            case 4:
                for (int i = 0; i < grantResults.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(
                                MainActivity.this,
                                "Sorry We cant process ahed due to denied pemission",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                textcollageClick();
                return;

        }
    }

    public void gotoActivity(Class aClass) {
        Intent intent = new Intent(getApplicationContext(), aClass);
        intent.putExtra(Const.imgId, "9");
        startActivity(intent);
        overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                interstitialAd.show();
                dialogAd.dismiss();
            }
        }, 2000);
    }

    private int id;
    private InterstitialAd interstitialAd;
    private NativeAd mNativeBannerAd;
    Dialog dialogAd;

    private void loadAd() {
        dialogAd = new Dialog(MainActivity.this);
        dialogAd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogAd.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialogAd.getWindow().setGravity(Gravity.CENTER);
        dialogAd.setContentView(R.layout.dialog_layout_progress);
        dialogAd.setCanceledOnTouchOutside(false);
        mNativeBannerAd = new NativeAd(this, getString(R.string.FB_Native));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                View adView = NativeAdView.render(MainActivity.this, mNativeBannerAd, NativeAdView.Type.HEIGHT_300);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });

        mNativeBannerAd.loadAd();
        interstitialAd = new InterstitialAd(this, getResources().getString(R.string.FB_inter));
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                dialogAd.dismiss();
                switch (id) {
                    case R.id.ll3dCollage:
                        threeD_collage();
                        break;
                    case R.id.llCollage:
                        collagebtnClick();
                        break;
                    case R.id.llText:
                        textcollageClick();
                        break;
                    case R.id.llMyCreation:
                        myAlbumClick();
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        interstitialAd.loadAd();

    }

    private void requestNewInterstitial() {
        interstitialAd.loadAd();
    }

    public void onBackPressed() {
        ExitDialog();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        final NativeBannerAd mNativeBannerAd;

        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                dialog.findViewById(R.id.tvLoadingads).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(MainActivity.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) dialog.findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        dialog.show();
    }
}