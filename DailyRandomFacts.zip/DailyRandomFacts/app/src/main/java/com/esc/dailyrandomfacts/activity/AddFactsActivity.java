package com.esc.dailyrandomfacts.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatDialog;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;

import com.esc.dailyrandomfacts.R;
import com.esc.dailyrandomfacts.kprogresshud.KProgressHUD;
import com.esc.dailyrandomfacts.managers.OwnQuotesManager;
import com.esc.dailyrandomfacts.model.Quote;
import com.esc.dailyrandomfacts.util.QuoteUtils;
import com.esc.dailyrandomfacts.util.TrackerEventUtils;
import com.esc.dailyrandomfacts.adapter.QuotesListAdapter;
import com.esc.dailyrandomfacts.adapter.QuotesListAdapter.Callback;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;

public class AddFactsActivity extends BaseActivity implements Callback {
    private AppCompatDialog addQuoteDialog;
    private Button btnAddQuote;
    private int dialogStyle = R.style.DialogStyleLight;
    private ImageView iv_back;
    private View linearDivider;
    private LinearLayout linearEmpty;
    private ArrayList<String> mOwn = new ArrayList();
    private QuotesListAdapter mQuotesListAdapter;
    private RecyclerView recyclerView;
    private TextView txtAdd;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_addfacts);
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_ADD_YOUR_OWN_VIEW, null, null);
        bindUI();
        setListeners();
        updateData();
        loadAd();
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
    }

    private void bindUI() {
        this.iv_back = findViewById(R.id.iv_back);
        this.recyclerView = findViewById(R.id.recyclerView);
        this.linearEmpty = findViewById(R.id.linearEmpty);
        this.btnAddQuote = findViewById(R.id.btnAddQuote);
        this.txtAdd = findViewById(R.id.txtAdd);
        this.linearDivider = findViewById(R.id.linearDivider);
    }

    private void setListeners() {
        this.iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                id = 100;
                if (interstitialAd != null && interstitialAd.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    startActivity(new Intent(AddFactsActivity.this, QuotesHomeActivity.class));
                    finish();
                }
            }
        });

        this.btnAddQuote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddOwnDialog();
            }
        });

        this.txtAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddOwnDialog();
            }
        });

        this.recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @SuppressLint("WrongConstant")
            public void onScrolled(RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                if (recyclerView.canScrollVertically(-1)) {
                    AddFactsActivity.this.linearDivider.setVisibility(0);
                } else {
                    AddFactsActivity.this.linearDivider.setVisibility(8);
                }
            }
        });
    }

    @SuppressLint("WrongConstant")
    public void updateData() {
        this.mQuotesListAdapter = new QuotesListAdapter(this.mOwn, this, this);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        this.recyclerView.setAdapter(this.mQuotesListAdapter);
        ArrayList ownQuotes = OwnQuotesManager.getOwnQuotes();
        this.mOwn = ownQuotes;
        if (ownQuotes.isEmpty()) {
            this.linearEmpty.setVisibility(0);
            this.recyclerView.setVisibility(8);
        } else {
            this.linearEmpty.setVisibility(8);
            this.recyclerView.setVisibility(0);
        }
        QuotesListAdapter quotesListAdapter = this.mQuotesListAdapter;
        if (quotesListAdapter != null) {
            quotesListAdapter.setTruckloads(this.mOwn);
        }
    }

    public void showOptionsDialog(final int i) {

        final AppCompatDialog appCompatDialog = new AppCompatDialog(this, this.dialogStyle);
        addQuoteDialog = appCompatDialog;
        appCompatDialog.setContentView(R.layout.dialog_share_delete);
        addQuoteDialog.setCanceledOnTouchOutside(true);
        Button btn_delete = addQuoteDialog.findViewById(R.id.btn_delete);
        Button btn_share = addQuoteDialog.findViewById(R.id.btn_share);

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                OwnQuotesManager.removeOwnQuote(mOwn.get(i));
                updateData();
                addQuoteDialog.dismiss();
            }
        });

        btn_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Quote quote = QuoteUtils.getQuote(1, mOwn.get(i), true);
                if (quote.getAuthor() == null || quote.getAuthor().isEmpty()) {
                    shareIntent(quote.getText());
                    return;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(quote.getText());
                stringBuilder.append("\n");
                stringBuilder.append(quote.getAuthor());
                shareIntent(stringBuilder.toString());
                addQuoteDialog.dismiss();
            }
        });

        if (!addQuoteDialog.isShowing() && !isFinishing()) {
            this.addQuoteDialog.show();
        }
    }

    private void shareIntent(String str) {
        String str2 = TrackerEventUtils.KEY_QUOTE;
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_SHARE_TOUCHED, str2, str);
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_SHARED_MIXPANEL, str2, str);
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_FAVORITED_OR_SHARED_MIXPANEL, str2, str);
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.SUBJECT", "Subject Here");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("\n");
        stringBuilder.append(getString(R.string.share_url));
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        startActivity(Intent.createChooser(intent, getString(R.string.share)));
    }

    @SuppressLint("WrongConstant")
    public void onQuoteClick(int i) {
        String str = this.mOwn.get(i);
        Intent intent = new Intent(this, QuotesHomeActivity.class);
        intent.addFlags(603979776);
        intent.putExtra(QuotesHomeActivity.QUOTE_SELECTED, str);
        startActivity(intent);
    }

    public void onQuoteLongClick(int i) {
        showOptionsDialog(i);
    }

    @SuppressLint("ResourceType")
    private void showAddOwnDialog() {
        AppCompatDialog appCompatDialog = new AppCompatDialog(this, this.dialogStyle);
        this.addQuoteDialog = appCompatDialog;
        appCompatDialog.setContentView(R.layout.dialog_add_quote);
        this.addQuoteDialog.setCanceledOnTouchOutside(true);
        Button btn_save = this.addQuoteDialog.findViewById(R.id.btn_save);
        final EditText editText = this.addQuoteDialog.findViewById(R.id.editQuote);
        final EditText textView = this.addQuoteDialog.findViewById(R.id.editAuthor);
        Button btn_cancel = this.addQuoteDialog.findViewById(R.id.btn_cancel);
        editText.setImeOptions(5);
        editText.setRawInputType(16385);

        editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                editText.post(new Runnable() {
                    @SuppressLint("WrongConstant")
                    public void run() {
                        ((InputMethodManager) AddFactsActivity.this.getSystemService("input_method")).showSoftInput(editText, 1);
                    }
                });
            }
        });

        editText.requestFocus();
        textView.setVisibility(View.VISIBLE);
        this.addQuoteDialog.getWindow().setLayout(-1, -2);

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String obj = editText.getText().toString();
                String charSequence = textView.getText().toString();
                if (obj.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Add a quote", Toast.LENGTH_LONG).show();
                    return;
                }
                if (!charSequence.isEmpty()) {
                    StringBuilder stringBuilder;
                    if (obj.endsWith(".")) {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(obj);
                        stringBuilder.append(" @ -");
                        stringBuilder.append(charSequence);
                        obj = stringBuilder.toString();
                    } else {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(obj);
                        stringBuilder.append("\n");
                        stringBuilder.append("@ -");
                        stringBuilder.append(charSequence);
                        obj = stringBuilder.toString();
                    }
                }
                OwnQuotesManager.addOwnQuote(obj);
                updateData();
                addQuoteDialog.dismiss();
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addQuoteDialog.dismiss();
            }
        });
        if (!this.addQuoteDialog.isShowing() && !isFinishing()) {
            this.addQuoteDialog.show();
        }
    }

    private FrameLayout adContainerView;
    private AdView adView;
    private InterstitialAd interstitialAd;
    private int id;
    private KProgressHUD hud;

    private void loadAd() {
        //AdaptiveBannerAd
        adContainerView = findViewById(R.id.ad_view_container);
        adView = new AdView(this);
        adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
        adContainerView.addView(adView);

        AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();

        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        startActivity(new Intent(AddFactsActivity.this, QuotesHomeActivity.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.e("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    private void requestNewInterstitial() {
        this.interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(AddFactsActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(AddFactsActivity.this, QuotesHomeActivity.class));
        finish();
    }
}
