package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class a5 implements View.OnClickListener {
    public final int e;
    public final ImageView f;
    public final com.kotlinz.festivalstorymaker.Models.g g;
    public final FrameEditorNewDesign h;

    public a5(final FrameEditorNewDesign h, final int e, final ImageView f, final com.kotlinz.festivalstorymaker.Models.g g) {
        this.h = h;
        this.e = e;
        this.f = f;
        this.g = g;
    }

    public void onClick(final View view) {
        this.h.u0();
        final FrameEditorNewDesign h = this.h;
        if (!h.l1) {
            h.d0 = this.e;
            final ImageView v1 = FrameEditorNewDesign.v1;
            if (v1 != null) {
                v1.setOnTouchListener((View.OnTouchListener) null);
                FrameEditorNewDesign.v1.setBackground((Drawable) null);
            }
            final TextView w1 = FrameEditorNewDesign.w1;
            if (w1 != null) {
                w1.setBackground((Drawable) null);
            }
            FrameEditorNewDesign.F1 = (FrameEditorNewDesign.v1 = this.f);
            FrameEditorNewDesign.R1 = false;
            FrameEditorNewDesign.S1 = false;
            FrameEditorNewDesign.T1 = false;
            this.h.H0(true);
            FrameEditorNewDesign.M1 = false;
            if (this.g.C.equalsIgnoreCase("1")) {
                FrameEditorNewDesign.N1 = true;
                FrameEditorNewDesign.P1 = false;
               /* final FrameEditorNewDesign.v v2 = new FrameEditorNewDesign.v();
                 v2.p0(this.h.U(), v2.B); */
            }
        } else {
            h.l1 = false;
        }
    }
}
