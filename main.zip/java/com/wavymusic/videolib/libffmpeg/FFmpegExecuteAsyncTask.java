package com.wavymusic.videolib.libffmpeg;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeoutException;

class FFmpegExecuteAsyncTask extends AsyncTask<Void, String, CommandResult>
{
  private final String[] cmd;
  private final FFmpegExecuteResponseHandler ffmpegExecuteResponseHandler;
  private String output;
  private Process process;
  private final ShellCommand shellCommand;
  private long startTime;
  private final long timeout;

  FFmpegExecuteAsyncTask(final String[] cmd, final long timeout, final FFmpegExecuteResponseHandler ffmpegExecuteResponseHandler) {
    this.output = "";
    this.cmd = cmd;
    this.timeout = timeout;
    this.ffmpegExecuteResponseHandler = ffmpegExecuteResponseHandler;
    this.shellCommand = new ShellCommand();
  }

  protected void onPreExecute() {
    this.startTime = System.currentTimeMillis();
    if (this.ffmpegExecuteResponseHandler != null) {
      this.ffmpegExecuteResponseHandler.onStart();
    }
  }

  protected CommandResult doInBackground(final Void... params) {
    try {
      this.process = this.shellCommand.run(this.cmd);
      if (this.process == null) {
        return CommandResult.getDummyFailureResponse();
      }
      this.checkAndUpdateProcess();
      return CommandResult.getOutputFromProcess(this.process);
    }
    catch (TimeoutException e) {
      return new CommandResult(false, e.getMessage());
    }
    catch (Exception e2) {
      e2.printStackTrace();
    }
    finally {
      Util.destroyProcess(this.process);
    }
    return CommandResult.getDummyFailureResponse();
  }

  protected void onProgressUpdate(final String... values) {
    if (values != null && values[0] != null && this.ffmpegExecuteResponseHandler != null) {
      this.ffmpegExecuteResponseHandler.onProgress(values[0]);
    }
  }

  protected void onPostExecute(final CommandResult commandResult) {
    if (this.ffmpegExecuteResponseHandler != null) {
      this.output = String.valueOf(this.output) + commandResult.output;
      if (commandResult.success) {
        this.ffmpegExecuteResponseHandler.onSuccess(this.output);
      }
      else {
        this.ffmpegExecuteResponseHandler.onFailure(this.output);
      }
      this.ffmpegExecuteResponseHandler.onFinish();
    }
  }

  private void checkAndUpdateProcess() throws TimeoutException, InterruptedException {
    while (!Util.isProcessCompleted(this.process)) {
      if (Util.isProcessCompleted(this.process)) {
        return;
      }
      if (this.timeout != Long.MAX_VALUE && System.currentTimeMillis() > this.startTime + this.timeout) {
        throw new TimeoutException("FFmpeg timed out");
      }
      try {
        final BufferedReader reader = new BufferedReader(new InputStreamReader(this.process.getErrorStream()));
        String line;
        while ((line = reader.readLine()) != null) {
          if (this.isCancelled()) {
            return;
          }
          this.output = String.valueOf(String.valueOf(this.output)) + line + "\n";
          this.publishProgress(new String[] { line });
        }
      }
      catch (IOException e) {
        e.printStackTrace();
      }
    }
  }

  boolean isProcessCompleted() {
    return Util.isProcessCompleted(this.process);
  }
}
