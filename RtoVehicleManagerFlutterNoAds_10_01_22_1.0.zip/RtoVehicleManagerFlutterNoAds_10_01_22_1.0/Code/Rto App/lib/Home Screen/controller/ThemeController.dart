import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../themes.dart';

class ThemeController extends GetxController {
  int count = 0;
  static bool isDarkModeEnabled = false;
  late ThemeMode themeMode = ThemeMode.system;
  int dayOrNight = 0;
  bool endSplash = false;
  String mode = "dark";
  var statusBarColor;
  var brightNess;

  Future<void> updateScreen() async {
    endSplash = true;
    update();
  }

  Future<void> tempThemeMode(BuildContext context) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    mode = prefs.getString('mode')!;
  }

  Future<void> getThemeMode(BuildContext context) async {
    String mode;
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    mode = prefs.getString('mode')!;
    if (mode == "light") {
      themeMode = ThemeMode.light;
      changeTheme(context, ThemeMode.light);
    } else {
      themeMode = ThemeMode.dark;
      changeTheme(context, ThemeMode.dark);
    }
    update();
  }

  Future<void> changeTheme(BuildContext context, ThemeMode mode) async {
    if (mode == ThemeMode.light) {
      themeMode = ThemeMode.dark;
      dayOrNight = 1;
      statusBarColor = MyThemes.fulldark;
      brightNess = Brightness.dark;
    } else {
      themeMode = ThemeMode.light;
      isDarkModeEnabled = false;
      dayOrNight = 0;
      statusBarColor = Colors.white;
      brightNess = Brightness.light;
    }
    update();
  }
}
