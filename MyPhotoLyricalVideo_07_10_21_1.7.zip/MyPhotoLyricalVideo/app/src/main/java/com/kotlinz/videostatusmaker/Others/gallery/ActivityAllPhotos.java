package com.kotlinz.videostatusmaker.Others.gallery;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.kotlinz.videostatusmaker.Activity.ActivityViewAlImages;
import com.kotlinz.videostatusmaker.Utils.RoundedImageView;
import com.kotlinz.videostatusmaker.Utils.Utils;
import com.kotlinz.videostatusmaker.adapter.GridViewAdapter;

public class ActivityAllPhotos extends Activity {

    LinearLayout AddLinearLayout;
    Typeface typeface1;
    TextView tvTitle;
    ImageView ivBack;
    TextView tvDone;
    Typeface typeface;
    public Activity MyActivity = ActivityAllPhotos.this;
    public static Activity activity;
    private GridView gridView;
    ImageLoader imageLoader;
    int intPosition;
    TextView tvListtotal;
    GridViewAdapter gridViewAdapter;


    private void initImageLoader() {
        (this.imageLoader = ImageLoader.getInstance()).init(new ImageLoaderConfiguration.Builder(this).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).build()).build());
    }

    void layoutAdd(final String s) {
        final View inflate = LayoutInflater.from(this.getApplicationContext()).inflate(R.layout.trail, null, false);
        final RoundedImageView roundedImageView = inflate.findViewById(R.id.imgtrail);
        final ImageView imageView = inflate.findViewById(R.id.closetrail);
        final DisplayImageOptions build = new DisplayImageOptions.Builder().build();
        final ImageLoader instance = ImageLoader.getInstance();
        final StringBuilder sb = new StringBuilder();
        sb.append("file:///");
        sb.append(s);
        instance.displayImage(sb.toString(), roundedImageView, build);
        roundedImageView.setCornerRadius(this.getResources().getDisplayMetrics().widthPixels * 25 / 1080);
        roundedImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(this.getResources().getDisplayMetrics().widthPixels * 60 / 1080, this.getResources().getDisplayMetrics().heightPixels * 60 / 1920);
        layoutParams.addRule(11);
        imageView.setLayoutParams(layoutParams);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                Utils.photos.remove(ActivityAllPhotos.this.AddLinearLayout.indexOfChild(inflate));
                ActivityAllPhotos.this.gridViewAdapter.notifyDataSetChanged();
                final TextView listtotal = ActivityAllPhotos.this.tvListtotal;
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(Utils.photos.size());
                sb.append("");
                listtotal.setText(sb.toString());
                ActivityAllPhotos.this.AddLinearLayout.removeView(inflate);
            }
        });
        this.AddLinearLayout.addView(inflate, 0);
        final TextView listtotal = this.tvListtotal;
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(Utils.photos.size());
        sb2.append("");
        listtotal.setText(sb2.toString());
    }


    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_folder);
        this.getWindow().addFlags(1024);
        this.initImageLoader();
        ActivityAllPhotos.activity = this;
        this.ivBack = this.findViewById(R.id.back);
        this.gridView = this.findViewById(R.id.gv_folder);
        this.intPosition = this.getIntent().getIntExtra("value", 0);
        this.gridViewAdapter = new GridViewAdapter(this, ActivityImageFolder.AllFolderImages, this.intPosition);
        this.gridView.setNumColumns(3);
        this.gridView.setAdapter(this.gridViewAdapter);
        this.AddLinearLayout = this.findViewById(R.id.addlay);
        this.tvDone = this.findViewById(R.id.done);
        this.tvListtotal = this.findViewById(R.id.listtotal);
        (this.tvTitle = this.findViewById(R.id.title)).setText(ActivityImageFolder.AllFolderImages.get(this.intPosition).getStr_folder());
//        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
//        this.typeface1 = Typeface.createFromAsset(this.getAssets(), "Montserrat-Light_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        this.tvTitle.setTextSize(18.0f);
        this.tvListtotal.setTypeface(this.typeface1);
        clickEvents();
    }

    private void clickEvents() {
        this.gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                final String s = ActivityImageFolder.AllFolderImages.get(ActivityAllPhotos.this.intPosition).getAl_imagepath().get(n);
                int i = 0;
                boolean b = false;
                while (i < Utils.photos.size()) {
                    if (Utils.photos.get(i).equals(ActivityImageFolder.AllFolderImages.get(ActivityAllPhotos.this.intPosition).getAl_imagepath().get(n))) {
                        Utils.photos.remove(i);
                        ActivityAllPhotos.this.AddLinearLayout.removeViewAt(i);
                        final TextView listtotal = ActivityAllPhotos.this.tvListtotal;
                        final StringBuilder sb = new StringBuilder();
                        sb.append("");
                        sb.append(Utils.photos.size());
                        sb.append("");
                        listtotal.setText(sb.toString());
                        b = true;
                    }
                    ++i;
                }
                if (!b) {
                    if (Utils.photos.size() < 8) {
                        Utils.photos.add(0, s);
                        ActivityAllPhotos.this.layoutAdd(s);
                    } else {
                        Toast.makeText(ActivityAllPhotos.this, "Max 8 Images", Toast.LENGTH_SHORT).show();
                    }
                }
                ActivityAllPhotos.this.gridViewAdapter.notifyDataSetChanged();
            }
        });
        this.tvDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (Utils.photos.size() == 8) {
                    if (MyApplication.isShowAd == 1) {
                        startActivity(new Intent(activity, ActivityViewAlImages.class));
                        MyApplication.isShowAd = 0;
                    } else {
                        if (MyApplication.interstitialAd != null && MyApplication.interstitialAd.isAdLoaded()) {
                            MyApplication.activity = MyActivity;
                            MyApplication.AdsId = 5;
                            MyApplication.interstitialAd.show();
                            MyApplication.isShowAd = 1;
                        } else {
                            startActivity(new Intent(activity, ActivityViewAlImages.class));
                        }
                    }
                    return;
                }
                Toast.makeText(ActivityAllPhotos.this.getApplicationContext(), "Add 8 pics", Toast.LENGTH_SHORT).show();
            }
        });
        this.ivBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityAllPhotos.this.onBackPressed();
            }
        });
    }


    protected void onResume() {
        this.AddLinearLayout.removeAllViews();
        final TextView listtotal = this.tvListtotal;
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(Utils.photos.size());
        sb.append("");
        listtotal.setText(sb.toString());
        for (int i = Utils.photos.size() - 1; i >= 0; --i) {
            this.layoutAdd(Utils.photos.get(i));
        }
        super.onResume();
    }
}
