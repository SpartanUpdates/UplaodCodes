package com.esc.phoneheart.animations;

public enum AnimationText {
    START_SPINNING,
    STOP_SPINNING,
    SET_VALUE,
    SET_VALUE_ANIMATED,
    TICK
}
