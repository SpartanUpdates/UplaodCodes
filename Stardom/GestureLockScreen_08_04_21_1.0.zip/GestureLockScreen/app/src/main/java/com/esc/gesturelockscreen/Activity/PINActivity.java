package com.esc.gesturelockscreen.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.TextView;
import com.esc.gesturelockscreen.Other.PINLockLayout;
import com.esc.gesturelockscreen.Other.PINLockLayout.IPasscodeListener;
import com.esc.gesturelockscreen.Other.PINLockLayout.MODE;
import com.esc.gesturelockscreen.Other.SettingsKeys;
import com.esc.gesturelockscreen.Other.SettingsUtils;
import com.esc.gesturelockscreen.R;

public class PINActivity extends Activity {
    private boolean createNew = false;
    private int length = -1;
    private IPasscodeListener mListener = new IPasscodeListener() {
        @Override
        public void onPasscodeWrong(MODE mode) {
            if (mode == MODE.MODE_VERIFY) {
                PINActivity.this.doVibration(100);
            }
        }

        public void onPasscodeSuccess(MODE mode) {
            if (PINActivity.this.createNew && mode == MODE.MODE_VERIFY) {
                ((TextView) PINActivity.this.findViewById(R.id.top_titlebar)).setText("Create New Passcode");
                PINActivity.this.mPasscodeLayout.switchToCreateMode(SettingsUtils.getPasscodeLengthValue());
            } else if (PINActivity.this.length > 0) {
                Intent in = new Intent();
                in.putExtra("length", PINActivity.this.length);
                PINActivity.this.setResult(-1, in);
                PINActivity.this.finish();
            } else {
                PINActivity.this.setResult(-1);
                PINActivity.this.finish();
            }
        }

        @Override
        public void onPasscodeCancel() {
            PINActivity.this.setResult(0);
            PINActivity.this.finish();
        }

        @Override
        public void onPasscodeDot(MODE mode) {
            if (mode == MODE.MODE_VERIFY) {
                PINActivity.this.doVibration(50);
            }
        }
    };
    private PINLockLayout mPasscodeLayout;

    protected void onStart() {
        super.onStart();
        overridePendingTransition(0, 0);
    }

    public void doVibration(long value) {
        if (SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_VIBRATION, true)) {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v.hasVibrator()) {
                v.vibrate(value);
            }
        }
    }

    public void onBackPressed(View v) {
        finish();
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passcode);
        this.mPasscodeLayout = (PINLockLayout) findViewById(R.id.passlock_layout);
        this.mPasscodeLayout.setListener(this.mListener);
        if (getIntent().hasExtra("length")) {
            this.length = getIntent().getIntExtra("length", 4);
            this.mPasscodeLayout.init(MODE.MODE_CREATE, this.length);
            ((TextView) findViewById(R.id.top_titlebar)).setText("Create New Passcode");
        } else if (SettingsUtils.getRecoveryPasscode() == null) {
            this.mPasscodeLayout.init(MODE.MODE_CREATE);
            ((TextView) findViewById(R.id.top_titlebar)).setText("Create Recovery Passcode");
        } else {
            if (getIntent().hasExtra("verify_n_create")) {
                this.createNew = getIntent().getBooleanExtra("verify_n_create", false);
            }
            if (getIntent().hasExtra("change")) {
                this.mPasscodeLayout.init(MODE.MODE_CREATE);
                ((TextView) findViewById(R.id.top_titlebar)).setText("Create New Passcode");
                return;
            }
            ((TextView) findViewById(R.id.top_titlebar)).setText("Verify Passcode");
            this.mPasscodeLayout.init(MODE.MODE_VERIFY);
        }
    }
}
