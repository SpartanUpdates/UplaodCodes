package com.kotlinz.festivalstorymaker.Interface;

public interface o <T>
{
    void a(final T p0);
}
