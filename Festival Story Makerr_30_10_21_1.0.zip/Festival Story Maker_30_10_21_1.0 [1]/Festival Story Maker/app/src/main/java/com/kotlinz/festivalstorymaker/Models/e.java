package com.kotlinz.festivalstorymaker.Models;

import java.io.Serializable;
import java.util.ArrayList;

public class e implements Serializable {
    public String e;
    public String f;
    public String g;
    public String h;
    public String i;
    public String j;
    public ArrayList<c> k = new ArrayList();
}
