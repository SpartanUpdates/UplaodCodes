package com.kotlinz.festivalstorymaker.Utils.a;

public class e {
    public boolean a;
    public boolean b;
    public boolean c;
    public boolean d;
    public i e;
    public int f;
    public int g;
    public int h;
    public int i;
    public int j;
    public String k;
    public String l;
    public String m;
    public String n;
    public String o;

    public e() {
        this.a = true;
        this.b = true;
        this.c = true;
        this.d = false;
        this.e = com.kotlinz.festivalstorymaker.Utils.a.i.e;
        this.f = com.kotlinz.festivalstorymaker.Utils.a.g.rate_dialog_title;
        this.g = com.kotlinz.festivalstorymaker.Utils.a.g.rate_dialog_message;
        this.h = com.kotlinz.festivalstorymaker.Utils.a.g.rate_dialog_ok;
        this.i = com.kotlinz.festivalstorymaker.Utils.a.g.rate_dialog_cancel;
        this.j = com.kotlinz.festivalstorymaker.Utils.a.g.rate_dialog_no;
        this.k = null;
        this.l = null;
        this.m = null;
        this.n = null;
        this.o = null;
    }
}
