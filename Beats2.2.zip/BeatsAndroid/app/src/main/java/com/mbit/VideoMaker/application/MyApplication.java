package com.mbit.VideoMaker.application;

import android.app.Application;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.facebook.ads.AdError;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.NativeAdsManager;
import com.google.android.gms.ads.MobileAds;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Extra.kprogresshud.KProgressHUD;
import com.mbit.VideoMaker.Model.ImageInfo;
import com.mbit.VideoMaker.Model.SongInfo;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.cropImage.CropImage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;


public class MyApplication extends Application {

    public static String b = "Beats";
    public static Context mContext;
    public static int IS_EDITIMAGE;
    public static int TotalSelectedImage;
    public static String APP_SPLIT_PATTERN;
    public static ArrayList<ImageInfo> selectedImageslist = new ArrayList<>();
    public static boolean SkipAll;
    public static boolean IsSongCuttingready = false;
    public static boolean IsVideoready = false;
    public static boolean IsAudioVideoMearge = false;
    public static String CutSongPath;
    public static boolean isBreak;
    public static boolean IsFromHomeUnity = false;
    public static boolean IsSelectImageFrom;
    public static KProgressHUD hud;
    public static int ThemePosition = -1;
    public static int CatSelectedPosition = -1;
    public static ArrayList<String> stringArrayList = new ArrayList<String>();
    private static MyApplication instance;

    static {
        MyApplication.IS_EDITIMAGE = 0;
        MyApplication.isBreak = false;
        MyApplication.TotalSelectedImage = 5;
        MyApplication.APP_SPLIT_PATTERN = "?";

    }

    public int posForAddMusicDialog;
    public boolean isEditModeEnable;
    public boolean isFromSdCardAudio;
    public HashMap<String, ArrayList<ImageInfo>> AllAlbumList;
    public ArrayList<String> videoImages;
    public ArrayList<String> welcomeImages;
    public int MinimumPosition;
    public ArrayList<CropImage> cropimaglist = new ArrayList<>();
    public int min_pos;
    public boolean IsNativeAdsLoaded = false;
    public HashMap<String, ArrayList<SongInfo>> AllSongAlbumList;
    public NativeAdsManager mAdsManager;
    String SongDirPath;
    private String selectedFolderId;
    private ArrayList<String> AllFolderList;
    private SongInfo musicCropInfo;
    private ArrayList<String> AllSongFolderList;
    public static boolean aa=false;
    public MyApplication() {
        this.posForAddMusicDialog = 0;
        this.isEditModeEnable = false;
        this.isFromSdCardAudio = false;
        this.videoImages = new ArrayList<String>();
        this.welcomeImages = new ArrayList<String>();
        selectedImageslist = new ArrayList<ImageInfo>();
        cropimaglist = new ArrayList<CropImage>();
        this.selectedFolderId = "";
        this.MinimumPosition = Integer.MAX_VALUE;
        this.SongDirPath = "";
        this.min_pos = Integer.MAX_VALUE;
        this.posForAddMusicDialog = 0;
        this.videoImages = new ArrayList<String>();
        this.welcomeImages = new ArrayList<String>();


    }

    public static MyApplication e() {
        return instance;
    }

    public static MyApplication getInstance() {
        return MyApplication.instance;

    }

    public static void ShowDialog(Context context) {
        hud = KProgressHUD.create(context)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Showing Ads")
                .setDetailsLabel("Please Wait...");
        hud.show();
        scheduleDismiss();
    }

    public static void scheduleDismiss() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
            }
        }, 10000);
    }

    public void initNativeAds() {
        mAdsManager = new NativeAdsManager(mContext, getResources().getString(R.string.FB_Native), 8);
        mAdsManager.loadAds();
        mAdsManager.setListener(new NativeAdsManager.Listener() {
            @Override
            public void onAdsLoaded() {
                IsNativeAdsLoaded = true;
//                Log.e("MyApplication", "IsNativeAdsLoaded True");
            }


            @Override
            public void onAdError(AdError adError) {
//                Log.e("MyApplication", "onAdError" + adError.getErrorMessage());
                IsNativeAdsLoaded = false;
            }

        });
    }

    public void init() {
        this.getFolderList();
    }

    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        MyApplication.mContext = this.getApplicationContext();
        MobileAds.initialize(mContext,getResources().getString(R.string.admob_app_id));
        AudienceNetworkAds.initialize(mContext);
        AdSettings.addTestDevice("e34e5002-8b13-4d6c-a490-54745d2b8b24");
        initNativeAds();
    }

    public String getSelectedFolderId() {
        return this.selectedFolderId;
    }

    public void setSelectedFolderId(final String selectedFolderId) {
        this.selectedFolderId = selectedFolderId;
    }

    public HashMap<String, ArrayList<ImageInfo>> getAllAlbumList() {
        return this.AllAlbumList;
    }

    public ArrayList<ImageInfo> getImageByAlbum(final String folderId) {
        ArrayList<ImageInfo> imageDatas = this.getAllAlbumList().get(folderId);
        if (imageDatas == null) {
            imageDatas = new ArrayList<ImageInfo>();
        }
        return imageDatas;
    }

    public ArrayList<ImageInfo> getSelectedImageslist() {
        return selectedImageslist;
    }

    public void addSelectedImage(final ImageInfo imageData) {
        selectedImageslist.add(imageData);
        ++imageData.NoOfImage;
    }

    public void removeSelectedImage(final int imageData) {
        if (imageData <= selectedImageslist.size()) {
            final ImageInfo imageData2 = selectedImageslist.remove(imageData);
            --imageData2.NoOfImage;
        }
    }

    public void ReplaceSelectedImage(ImageInfo imageData, int pos) {
        selectedImageslist.set(pos, imageData);
    }

    public ArrayList<CropImage> getCropImages() {
        return this.cropimaglist;
    }

    public void AddCropImages(CropImage imageData) {
        this.cropimaglist.add(imageData);

    }

    public void ReplaceCropImages(ImageInfo imageData, int pos) {
        selectedImageslist.set(pos, imageData);
    }

    public void removecropImage(int imageData) {
        cropimaglist.remove(imageData);

    }

    public SongInfo getMusicCropInfo() {
        return this.musicCropInfo;
    }

    public void setMusicCropInfo(SongInfo musicData) {
        this.musicCropInfo = musicData;
    }

    public void getFolderList() {
        this.AllFolderList = new ArrayList<String>();
        this.AllAlbumList = new HashMap<String, ArrayList<ImageInfo>>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "bucket_id", "datetaken", "_data"};
        final Uri images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "_data";
        final Cursor cur = this.getContentResolver().query(images, projection, null, null, "_data DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("bucket_display_name");
            final int bucketIdColumn = cur.getColumnIndex("bucket_id");

            ImageInfo data = null;
            this.setSelectedFolderId(cur.getString(bucketIdColumn));
            do {
                data = new ImageInfo();
                data.ImagePath = cur.getString(cur.getColumnIndex("_data"));
                data.ThumbbailImage = cur.getString(cur.getColumnIndex("_data"));
                if (!data.ImagePath.endsWith(".gif")) {
                    final String folderName = cur.getString(bucketColumn);
                    final String folderId = cur.getString(bucketIdColumn);
                    if (!this.AllFolderList.contains(folderId)) {
                        this.AllFolderList.add(folderId);
                    }
                    ArrayList<ImageInfo> imagePath = this.AllAlbumList.get(folderId);
                    if (imagePath == null) {
                        imagePath = new ArrayList<ImageInfo>();
                    }
                    data.folderName = folderName;
                    imagePath.add(data);
                    this.AllAlbumList.put(folderId, imagePath);


                }
            } while (cur.moveToNext());
        }
    }

    private boolean IsSongFile(String path) {
        if (TextUtils.isEmpty(path)) {
            return false;
        }
        return path.endsWith(".mp3");
    }

    public boolean IsSongFilterPath(final String s) {
        if (this.SongDirPath.equals("")) {
            this.SongDirPath = Utils.INSTANCE.getMusicFolderPath();
        }
        return s.contains(this.SongDirPath);
    }

    public ArrayList<SongInfo> GetSongList() {
        final ArrayList<SongInfo> list = new ArrayList<SongInfo>();
        final Cursor query = this.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "title", "_data", "_display_name", "duration"}, "is_music != 0", null, "title ASC");
        final int columnIndex = query.getColumnIndex("_id");
        final int columnIndex2 = query.getColumnIndex("title");
        final int columnIndex3 = query.getColumnIndex("_display_name");
        final int columnIndex4 = query.getColumnIndex("_data");
        final int columnIndex5 = query.getColumnIndex("duration");
        while (query.moveToNext()) {
            final String string = query.getString(columnIndex4);
            if (this.IsSongFile(string)) {
                final SongInfo songinfolist = new SongInfo();
                songinfolist.SongtrackId = query.getLong(columnIndex);
                songinfolist.SongTitle = query.getString(columnIndex2);
                songinfolist.SongTrackData = string;
                songinfolist.SongDuration = query.getLong(columnIndex5);
                songinfolist.SongDisplayName = query.getString(columnIndex3);
                list.add(songinfolist);
            }
        }
        return list;
    }

    public void clearAllSelection() {
        this.videoImages.clear();
        this.AllAlbumList = null;
        this.getSelectedImageslist().clear();
        System.gc();
        this.getFolderList();
    }

    public ArrayList<String> getAllFolder() {
        Collections.sort(this.AllFolderList);
        return this.AllFolderList;
    }

}
