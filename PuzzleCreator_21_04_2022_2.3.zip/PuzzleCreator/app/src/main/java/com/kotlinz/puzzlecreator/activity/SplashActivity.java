package com.kotlinz.puzzlecreator.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.introslider.IntroActivity;
import com.kotlinz.puzzlecreator.login.LoginActivity;

public class SplashActivity extends BaseActivity {
    Activity activity = SplashActivity.this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_avtivity);
        GoToMain();
    }

    private void GoToMain(){
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (sessionManager.isFirstTimeLaunch()) {
                    Intent intent = new Intent(activity, IntroActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    if (sessionManager.isLoggedIn()) {
                        GoToNext();
                    } else {
                        Intent intent = new Intent(activity, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }
        }, 2000);
    }

    private void GoToNext() {
        Intent intent = new Intent(activity, MainActivity.class);
        startActivity(intent);
        finish();
    }


}