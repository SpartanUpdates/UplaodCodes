package com.kotlinz.videoeditor.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.FileModel;
import com.kotlinz.videoeditor.Interface.ItemClickListener;
import com.kotlinz.videoeditor.audiovideomixer.Utils.AddAudio;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.ViewHolder> implements Filterable {
    Context context;
    private List<FileModel> MyfileListFiltered;
    private final List<FileModel> myfileList;
    private ItemClickListener clickListener;
    int position = -1;

    public MusicAdapter(Context context, List<FileModel> list) {
        this.context = context;
        this.myfileList = list;
        this.MyfileListFiltered = list;
    }

    public Filter getFilter() {
        return new Filter() {

            public FilterResults performFiltering(CharSequence charSequence) {
                String charSequence2 = charSequence.toString();
                if (charSequence2.isEmpty()) {
                    MusicAdapter adapterZipUnzipRecycler = MusicAdapter.this;
                    adapterZipUnzipRecycler.MyfileListFiltered = adapterZipUnzipRecycler.myfileList;
                } else {
                    ArrayList arrayList = new ArrayList();
                    for (FileModel fileModel : MusicAdapter.this.myfileList) {
                        if (fileModel.getFileName().toLowerCase().contains(charSequence2.toLowerCase())) {
                            arrayList.add(fileModel);
                        }
                    }
                    MusicAdapter.this.MyfileListFiltered = arrayList;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = MusicAdapter.this.MyfileListFiltered;
                return filterResults;
            }

            public void publishResults(CharSequence charSequence, FilterResults filterResults) {
                MusicAdapter.this.MyfileListFiltered = (ArrayList) filterResults.values;
                MusicAdapter.this.notifyDataSetChanged();
            }
        };
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.selectmusic_row, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        FileModel fileModel = this.MyfileListFiltered.get(i);
        viewHolder.file_name.setText(fileModel.getFileName());
        if (position == i) {
            viewHolder.itemView.setBackgroundResource(R.drawable.ic_recycler_selector_bg);
            viewHolder.iv_music.setImageResource(R.drawable.ic_song_press);
            viewHolder.ic_music_unselect_round.setImageResource(R.drawable.ic_music_select_round);
            viewHolder.file_name.setTextColor(context.getResources().getColor(R.color.white));
        } else {
            viewHolder.itemView.setBackgroundResource(0);
            viewHolder.iv_music.setImageResource(R.drawable.ic_song_unpress);
            viewHolder.file_name.setTextColor(context.getResources().getColor(R.color.gary));
            viewHolder.ic_music_unselect_round.setImageResource(R.drawable.ic_music_unselect_round);
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                position = i;
                notifyDataSetChanged();
                AddAudio.status = 1;
                AddAudio.audioName = fileModel.getFilePath();
                AddAudio.audioPath = fileModel.getFilePath();
            }
        });

    }


    @Override
    public int getItemCount() {
        return this.MyfileListFiltered.size();
    }

    public void setClickListener(ItemClickListener clickListener) {
        this.clickListener = clickListener;

    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView file_name;
        ImageView iv_music, ic_music_unselect_round;


        ViewHolder(View view) {
            super(view);
            this.file_name = (TextView) view.findViewById(R.id.row_title);
            this.iv_music = (ImageView) view.findViewById(R.id.iv_music);
            this.ic_music_unselect_round = (ImageView) view.findViewById(R.id.ic_music_unselect_round);
            this.file_name.setSelected(true);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (clickListener != null) clickListener.onClick(view, getAdapterPosition());
        }
    }

    public static String readableFileSize(long j) {
        if (j <= 0) {
            return "0";
        }
        double d = (double) j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        return new DecimalFormat("#,##0.#").format(d / Math.pow(1024.0d, (double) log10)) + " " + new String[]{"B", "kB", "MB", "GB", "TB"}[log10];
    }
}