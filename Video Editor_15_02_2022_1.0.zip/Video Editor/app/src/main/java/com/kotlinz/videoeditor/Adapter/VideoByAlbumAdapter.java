package com.kotlinz.videoeditor.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.RequestManager;
import com.kotlinz.videoeditor.Interface.OnItemClickListner;
import com.kotlinz.videoeditor.Model.VideoModel;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.VideoSelectActivity;

import java.util.List;

import static com.kotlinz.videoeditor.activity.VideoSelectActivity.Name;

public class VideoByAlbumAdapter extends RecyclerView.Adapter<VideoByAlbumAdapter.Holder> {
    private MyApplication myApplication;
    private LayoutInflater inflater;
    private OnItemClickListner<Object> clickListner;
    private RequestManager glide;
    private VideoSelectActivity activity;
    int position = -1;
    private List<VideoModel> mModelList;
    public static int count;

    public VideoByAlbumAdapter(Context context, List<VideoModel> listData) {
        myApplication = MyApplication.getInstance();
        inflater = LayoutInflater.from(context);
        glide = com.bumptech.glide.Glide.with(context);
        activity = ((VideoSelectActivity) context);
        this.mModelList = listData;
        count = 0;
    }

    public void setOnItemClickListner(OnItemClickListner<Object> clickListner) {
        this.clickListner = clickListner;
    }

    public int getItemCount() {
        return myApplication.getImageByAlbum(myApplication.getSelectedFolderId()).size();
    }

    public VideoModel getItem(int pos) {
        return myApplication.getImageByAlbum(myApplication.getSelectedFolderId()).get(pos);
    }

    public void onBindViewHolder(final Holder holder, @SuppressLint("RecyclerView") final int pos) {
        VideoModel data = getItem(pos);
        glide.load(data.imagePath).into(holder.ivthumb);
        Log.e("TAG","Video Duration"+data.getVideoDuration());
        holder.tvDuration.setText(data.getVideoDuration());
        try {
            if (Name.equals("MergeVideo")) {
                if (data.isSelected()) {
                    holder.ivthumb.setBackground(activity.getResources().getDrawable(R.drawable.bg_album_video_item_selected));
                    holder.img_select.setImageResource(R.drawable.ic_select_right);
                } else {
                    holder.ivthumb.setBackground(null);
                    holder.img_select.setImageResource(0);
                }
            } else if (Name.equals("Single")) {
                if (position == pos) {
                    holder.ivthumb.setBackground(activity.getResources().getDrawable(R.drawable.bg_album_video_item_selected));
                    holder.img_select.setImageResource(R.drawable.ic_select_right);
                } else {
                    holder.ivthumb.setBackground(null);
                    holder.img_select.setImageResource(0);
                }
            }
        } catch (Exception e) {
            e.getMessage();
        }

        holder.rlmain.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                position = pos;
                data.setSelected(!data.isSelected());
                try {
                    if (Name.equals("MergeVideo")) {
                        if (data.isSelected()) {
                            count++;
                            if (count <= 2) {
                                myApplication.addSelectedImage(data);
                                notifyDataSetChanged();
                                return;
                            }
                            Toast.makeText(myApplication, "Select Maximum Two Videos", Toast.LENGTH_SHORT).show();
                        } else if (!data.isSelected()) {
                            myApplication.removeSelectedImage(data);
                            holder.ivthumb.setBackground(null);
                            holder.img_select.setImageResource(0);
                            count--;
                            notifyDataSetChanged();
                        }
                    } else if (Name.equals("Single")) {
                        if (holder.ivthumb.getDrawable() == null) {
                            Toast.makeText(myApplication, "Video corrupted or not support.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        myApplication.addSelectedImage(data);
                        notifyDataSetChanged();
                    }
                } catch (Exception e) {
                    e.getMessage();
                }
            }
        });
    }

    public class Holder extends RecyclerView.ViewHolder {
        CardView cvMain;
        RelativeLayout rlmain;
        TextView tvDuration;
        ImageView ivthumb, img_select;

        public Holder(View v) {
            super(v);
            cvMain = v.findViewById(R.id.cvMain);
            tvDuration = v.findViewById(R.id.tv_duration);
            rlmain = v.findViewById(R.id.rl_main);
            ivthumb = v.findViewById(R.id.iv_thumb);
            img_select = v.findViewById(R.id.img_select);
        }

        public void onItemClick(View view, Object item) {
            if (clickListner != null) {
                clickListner.onItemClick(view, item);
            }
        }
    }

    @NonNull
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int pos) {
        return new Holder(inflater.inflate(R.layout.row_image_by_folder, parent, false));
    }
}
