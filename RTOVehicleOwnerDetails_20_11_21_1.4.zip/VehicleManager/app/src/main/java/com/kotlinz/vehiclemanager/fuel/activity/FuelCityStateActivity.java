package com.kotlinz.vehiclemanager.fuel.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.utils.Utils;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class FuelCityStateActivity extends AppCompatActivity implements View.OnClickListener {

    private Activity activity = FuelCityStateActivity.this;
    private ImageView iv_back;
    private Button btn_getdetails;
    private Spinner stateListSpinner;
    private Spinner cityListSpinner;
    private AppCompatDialog dialog;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private TextView title_tv;
    private RelativeLayout city_layout;
    private Boolean checkDark = false;
    private int statePosition = 11, cityPosition = 0;

    GGAdview gg_native;

    private int id;
    public GGInterstitialAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fuel_city_state);
        sharedPreferences = getApplicationContext().getSharedPreferences("stateName", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        statePosition = sharedPreferences.getInt("statePosition", 0);
        cityPosition = sharedPreferences.getInt("cityPosition", 0);
        PutAnalyticsEvent();
        BindView();
        DialogAnimation();
        CallNativeAds();
        InterAds();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            checkDark = true;
            setupNightMode();
        }

        DarkTheame darkTheame = new DarkTheame(FuelCityStateActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            checkDark = true;
            setupNightMode();
        }
        if (Utils.isOnline(activity)) {
            getStateCityData();

        } else {
            Toast.makeText(activity, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "FuelCityStateActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void CallNativeAds() {
        gg_native = findViewById(R.id.ggAdView_native);
        gg_native.setUnitId(getResources().getString(R.string.NativeAd));
        gg_native.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 1:
                        startActivity(new Intent(FuelCityStateActivity.this, MainActivity.class));
                        finish();
                        break;
                    case 2:
                        Intent intent = new Intent(FuelCityStateActivity.this, MainActivity.class);
                        intent.putExtra("cityname", String.valueOf(cityListSpinner.getSelectedItem()));
                        intent.putExtra("statename", String.valueOf(stateListSpinner.getSelectedItem()));
                        intent.putExtra("data", "data");
                        startActivity(intent);
                        break;
                }
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }


    private void setupNightMode() {
        city_layout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
    }

    private void getStateCityData() {
        String cityStateJsonData = Utils.getStateCityFromJson(FuelCityStateActivity.this, "rtoofficeinfo.json");
        ArrayList<String> stateList = new ArrayList<>();
        ArrayList<String> cityList = new ArrayList<>();
        try {
            JSONObject obj = new JSONObject(cityStateJsonData);
            JSONArray mainArray = obj.getJSONArray("details");
            for (int i = 0; i < mainArray.length(); i++) {
                JSONObject stateObj = mainArray.getJSONObject(i);
                String stateName = stateObj.getString("name");
                stateList.add(String.valueOf(stateName));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ArrayAdapter stateAdapter;
        if (checkDark) {
            stateAdapter = new ArrayAdapter(activity, R.layout.city_list_background_spinner, stateList);
            stateAdapter.setDropDownViewResource(R.layout.city_list_background_spinner);
        } else {
            stateAdapter = new ArrayAdapter(activity, R.layout.city_list_background_spinner_dark, stateList);
            stateAdapter.setDropDownViewResource(R.layout.city_list_background_spinner_dark);
        }
        stateListSpinner.setAdapter(stateAdapter);
        stateListSpinner.setSelection(statePosition);

        stateListSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cityList.clear();
                String selectedState = (String) stateListSpinner.getSelectedItem();
                editor.putString("stateName", selectedState);
                editor.putInt("statePosition", stateListSpinner.getSelectedItemPosition());
                editor.commit();
                try {
                    JSONObject obj = new JSONObject(cityStateJsonData);
                    JSONArray mainArray = obj.getJSONArray("details");
                    for (int i = 0; i < mainArray.length(); i++) {
                        JSONObject stateObj = mainArray.getJSONObject(i);
                        String stateName = stateObj.getString("name");
                        JSONArray cityArray = stateObj.getJSONArray("rtoList");
                        if (stateName.equals(selectedState)) {
                            for (int j = 0; j < cityArray.length(); j++) {
                                JSONObject cityObj = cityArray.getJSONObject(j);
                                String cityName = cityObj.getString("district");
                                cityList.add(cityName);
                            }
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                ArrayAdapter cityAdapter;
                if (checkDark) {
                    cityAdapter = new ArrayAdapter(activity, R.layout.city_list_background_spinner, cityList);
                    cityAdapter.setDropDownViewResource(R.layout.city_list_background_spinner);
                } else {
                    cityAdapter = new ArrayAdapter(activity, R.layout.city_list_background_spinner_dark, cityList);
                    cityAdapter.setDropDownViewResource(R.layout.city_list_background_spinner_dark);
                }
                cityListSpinner.setAdapter(cityAdapter);
                cityListSpinner.setSelection(cityPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        dialog.dismiss();

        cityListSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String cityName = (String) cityListSpinner.getSelectedItem();
                editor.putString("cityName", cityName);
                editor.putInt("cityPosition", cityListSpinner.getSelectedItemPosition());
                editor.commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void BindView() {
        iv_back = findViewById(R.id.iv_back);
        stateListSpinner = findViewById(R.id.spinnerstatelist);
        cityListSpinner = findViewById(R.id.spinnercitylist);
        btn_getdetails = findViewById(R.id.btn_get_details);
        title_tv = findViewById(R.id.title_tv);
        city_layout = findViewById(R.id.city_layout);
        iv_back.setOnClickListener(this);
        btn_getdetails.setOnClickListener(this);
    }

    private void DialogAnimation() {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_fuelcitydialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.btn_get_details:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 2;
                    interstitialAd.show();
                } else {
                    Intent intent = new Intent(FuelCityStateActivity.this, MainActivity.class);
                    intent.putExtra("cityname", String.valueOf(cityListSpinner.getSelectedItem()));
                    intent.putExtra("statename", String.valueOf(stateListSpinner.getSelectedItem()));
                    intent.putExtra("data", "data");
                    startActivity(intent);
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 1;
            interstitialAd.show();
        } else {
            startActivity(new Intent(FuelCityStateActivity.this, MainActivity.class));
            finish();
            super.onBackPressed();
        }
    }
}