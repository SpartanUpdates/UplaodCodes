package com.rtovehicleinformation.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.rtovehicleinformation.R;

public class ViewDialog {

    public void showDialogForUpdate(Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.update_dialog);
        dialog.show();

        Button update = dialog.findViewById(R.id.update);
        TextView updateTxt = dialog.findViewById(R.id.updateTxt);
        TextView updateTxt2 = dialog.findViewById(R.id.updateTxt2);
        LinearLayout mainLayout = dialog.findViewById(R.id.mainLayout);


        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try { activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(activity.getString(R.string.rate_us_url) + activity.getPackageName())));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(activity, "You don't have Google Play installed", Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }
        });
    }

}