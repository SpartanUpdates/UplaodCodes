package com.kotlinz.festivalstorymaker.activity;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.Layout;
import android.text.TextUtils;
import android.util.Log;
import android.view.DragEvent;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.transition.Slide;
import androidx.transition.TransitionManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.BackgroundCatImageListAdapter;
import com.kotlinz.festivalstorymaker.Adapter.BackgroundCategoryListAdapter;
import com.kotlinz.festivalstorymaker.Adapter.CollageMakeBottomFrameListAdapter;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.Background.BackgroundMainResponse;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.Background.BackgroundResponse;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.CategoryWiseData.CollageCategoryWiseData;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.CollageMainCategory;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.kotlinz.festivalstorymaker.Other.TextInputDilaog;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.TypeFace.Font;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerActivity;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerSavePath;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ReturnMode;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.cameraonly.CameraOnlyConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CollageText;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CollageImage;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CollageMakerFl;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CollageImageSticker;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CollageTextOperationListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CollageTextSticker;
import com.kotlinz.festivalstorymaker.Listener.SetListener.FontHeight;
import com.kotlinz.festivalstorymaker.Listener.SetListener.FontSpacingCollageMaker;
import com.kotlinz.festivalstorymaker.Listener.SetListener.SetColorList;
import com.kotlinz.festivalstorymaker.Listener.SetListener.SetFont;
import com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter;
import com.kotlinz.festivalstorymaker.texteditor.FontListAdapter;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.squareup.picasso.Picasso;
import com.yalantis.ucrop.UCropActivity;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static com.kotlinz.festivalstorymaker.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

public class CollageMakerDetailActivity extends BaseActivity implements com.kotlinz.festivalstorymaker.Other.g.c, com.kotlinz.festivalstorymaker.texteditor.FontListAdapter.a, com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter.a {

    Activity activity = CollageMakerDetailActivity.this;

    @BindView(com.kotlinz.festivalstorymaker.R.id.listBackgroundCat)
    public RecyclerView rvBackground;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listBackgroundCatImage)
    public RecyclerView rvBackgroundCatImage;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listColor)
    public RecyclerView rvColors;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listFont)
    public RecyclerView rvFonts;

    @BindView(com.kotlinz.festivalstorymaker.R.id.listMain)
    public RecyclerView rvCollageFrame;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llAlign)
    public LinearLayout llAlign;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llCaps)
    public LinearLayout llI;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llColors)
    public LinearLayout llcolors;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llDeleteImage)
    public LinearLayout llDelete;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llFonts)
    public LinearLayout llFonts;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llLine)
    public LinearLayout llLine;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llSpacing)
    public LinearLayout llSpacing;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llTextEditor)
    public LinearLayout llTextEditor;

    @BindView(com.kotlinz.festivalstorymaker.R.id.frameElements)
    public FrameLayout flElements;

    @BindView(com.kotlinz.festivalstorymaker.R.id.frameLayout)
    public FrameLayout flFrameLayout;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llBackgroundSelection)
    public LinearLayout llBackGroundSelection;

    @BindView(com.kotlinz.festivalstorymaker.R.id.rlTop)
    public RelativeLayout rlTop;

    @BindView(com.kotlinz.festivalstorymaker.R.id.rlFull)
    public RelativeLayout rlFull;


    @BindView(com.kotlinz.festivalstorymaker.R.id.scroll)
    public ScrollView SvScroll;

    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontSpacing)
    public SeekBar sbFontSpacing;

    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontHeight)
    public SeekBar sbFontHeight;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlign)
    public ImageView ivAlign;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignCenter)
    public ImageView ivAlignCenter;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignLeft)
    public ImageView ivAlignLeft;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignRight)
    public ImageView ivAlignRight;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAllCap)
    public ImageView ivAlignAllCap;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgCaps)
    public ImageView ivCaps;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgColor)
    public ImageView ivColor;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFirstCap)
    public ImageView ivFirstCap;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFont)
    public ImageView ivFont;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgLine)
    public ImageView ivLine;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSmall)
    public ImageView ivSmall;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSpace)
    public ImageView ivSpace;

    @BindView(com.kotlinz.festivalstorymaker.R.id.iv_background)
    ImageView ivBackground;

    @BindView(com.kotlinz.festivalstorymaker.R.id.iv_text)
    ImageView ivText;

    @BindView(com.kotlinz.festivalstorymaker.R.id.iv_logo)
    ImageView ivLogo;

    @BindView(com.kotlinz.festivalstorymaker.R.id.iv_element)
    ImageView ivElements;

    @BindView(com.kotlinz.festivalstorymaker.R.id.tv_background)
    TextView tvBackground;
    @BindView(com.kotlinz.festivalstorymaker.R.id.tv_text)
    TextView tvText;
    @BindView(com.kotlinz.festivalstorymaker.R.id.tv_logo)
    TextView tvLogo;
    @BindView(com.kotlinz.festivalstorymaker.R.id.tv_element)
    TextView tvElements;

    @BindView(com.kotlinz.festivalstorymaker.R.id.fl_adplaceholder)
    FrameLayout frameLayout;

    public com.kotlinz.festivalstorymaker.Other.g.a K;
    public ArrayList<ImageView> O = new ArrayList();
    public ArrayList<String> SelectedImageList;
    public int Q = 0;
    public int R = 45;
    public int S = 0;
    public int T = 0;
    public int U;
    public int V;
    public int W;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.g> Images;
    public com.kotlinz.festivalstorymaker.Models.e d0;
    public String e0 = "";
    public ImageView f0;
    public ImageView g0;
    public String h0;
    public FontListAdapter fontListAdapter;
    public ColorListAdapter j0;
    public int k0 = -1;
    public int l0 = -1;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.z.c> m0 = new ArrayList();
    public TextStickerViewNew1 n0;
    public boolean o0 = false;
    public ImageStickerViewNew p0;
    public int q0;

    private int ModuleId;
    String FilePath;

    BackgroundCategoryListAdapter backgroundCategoryListAdapter;
    public ArrayList<BackgroundMainResponse> backgroundMainResponses = new ArrayList();


    private ProgressDialog progressDialog;
    APIInterface apiInterface;

    private NativeAd nativeAd;

    public class f implements View.OnDragListener {
        public int a;

        public f(int i) {
            this.a = i;
        }

        public boolean onDrag(View view, DragEvent dragEvent) {
            if (dragEvent.getAction() == 3) {
                int i = 0;
                CollageMakerDetailActivity.this.q0 = Integer.parseInt(dragEvent.getClipData().getItemAt(0).getText().toString());
                if (CollageMakerDetailActivity.this.q0 == this.a) {
                    return false;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(CollageMakerDetailActivity.this.q0);
                String str = "";
                stringBuilder.append(str);
                stringBuilder = new StringBuilder();
                stringBuilder.append(this.a);
                stringBuilder.append(str);
                CollageMakerDetailActivity collageMakerDetailActivity = CollageMakerDetailActivity.this;
                Collections.swap(collageMakerDetailActivity.SelectedImageList, collageMakerDetailActivity.q0, this.a);
                while (i < CollageMakerDetailActivity.this.SelectedImageList.size()) {
                    CollageMakerDetailActivity.this.O.get(i).setImageBitmap(Utils.A(CollageMakerDetailActivity.this.SelectedImageList.get(i)));
                    CollageMakerDetailActivity.this.O.get(i).setTag(CollageMakerDetailActivity.this.SelectedImageList.get(i));
                    CollageMakerDetailActivity.this.O.get(i).requestLayout();
                    i++;
                }
            }
            return true;
        }
    }

    public class g extends AsyncTask<String, Boolean, File> {


        @Override
        protected void onPostExecute(File file) {
            super.onPostExecute(file);
            File files = file;
            CollageMakerDetailActivity.this.u.u();
            Toast.makeText(CollageMakerDetailActivity.this.getApplicationContext(), CollageMakerDetailActivity.this.getResources().getString(com.kotlinz.festivalstorymaker.R.string.download_sucess), Toast.LENGTH_LONG).show();
        }

        @Override
        protected File doInBackground(String... strings) {
            String[] strArr = strings;
            Utils.J(com.kotlinz.festivalstorymaker.Other.AppConstant.d2, CollageMakerDetailActivity.this.h0);
            try {
                Bitmap e0 = CollageMakerDetailActivity.this.e0(rlFull);
                File o0 = CollageMakerDetailActivity.this.o0();
                if (o0 != null) {
                    FileOutputStream fileOutputStream = new FileOutputStream(o0.getAbsolutePath());
                    e0.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.close();
                    Utils.K(CollageMakerDetailActivity.this, o0);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return new File("");
        }

        public void onPreExecute() {
            super.onPreExecute();
            CollageMakerDetailActivity.this.u = new Utils(CollageMakerDetailActivity.this);
            CollageMakerDetailActivity collageMakerDetailActivity = CollageMakerDetailActivity.this;
            collageMakerDetailActivity.u.c(collageMakerDetailActivity.getResources().getString(com.kotlinz.festivalstorymaker.R.string.downloading));
            CollageMakerDetailActivity.this.u.M();
        }
    }

    public class h implements View.OnTouchListener {
        public int e = -1;
        public GestureDetector f;
        public int g;
        public int h;
        public int i;
        public ImageView j;

        public class a extends GestureDetector.SimpleOnGestureListener {
            public int e;

            public a(ImageView imageView, int i) {
                this.e = i;
            }

            public boolean onDoubleTap(MotionEvent motionEvent) {
                int size = CollageMakerDetailActivity.this.SelectedImageList.size();
                int i = this.e;
                if (size > i && CollageMakerDetailActivity.this.SelectedImageList.get(i).length() > 0) {
                    CollageMakerDetailActivity collageMakerDetailActivity = CollageMakerDetailActivity.this;
                    String str = collageMakerDetailActivity.SelectedImageList.get(this.e);
                    h hVar = h.this;
                    int i2 = hVar.h;
                    int i3 = hVar.i;
                    if (collageMakerDetailActivity != null) {
                        Utils.d();
                        Bundle bundle = new Bundle();
                        bundle.putString("com.yalantis.ucrop.CompressionFormatName", Bitmap.CompressFormat.JPEG.name());
                        bundle.putInt("com.yalantis.ucrop.CompressionQuality", 100);
                        bundle.putString("com.yalantis.ucrop.UcropToolbarTitleText", "Crop");
                        bundle.putBoolean("com.yalantis.ucrop.HideBottomControls", true);
                        bundle.putBoolean("com.yalantis.ucrop.FreeStyleCrop", false);
                        Uri fromFile = Uri.fromFile(new File(str));
                        File cacheDir = collageMakerDetailActivity.getCacheDir();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(System.currentTimeMillis());
                        stringBuilder.append(".png");
                        Uri fromFile2 = Uri.fromFile(new File(cacheDir, stringBuilder.toString()));
                        Intent intent = new Intent();
                        Bundle bundle2 = new Bundle();
                        bundle2.putParcelable("com.yalantis.ucrop.InputUri", fromFile);
                        bundle2.putParcelable("com.yalantis.ucrop.OutputUri", fromFile2);
                        float f = (float) i3;
                        bundle2.putFloat("com.yalantis.ucrop.AspectRatioX", (float) i2);
                        bundle2.putFloat("com.yalantis.ucrop.AspectRatioY", f);
                        bundle2.putInt("com.yalantis.ucrop.MaxSizeX", 2200);
                        bundle2.putInt("com.yalantis.ucrop.MaxSizeY", 2200);
                        bundle2.putAll(bundle);
                        intent.setClass(collageMakerDetailActivity, UCropActivity.class);
                        intent.putExtras(bundle2);
                        collageMakerDetailActivity.startActivityForResult(intent, 69);
                    } else {
                        throw null;
                    }
                }
                return false;
            }

            public boolean onDoubleTapEvent(MotionEvent motionEvent) {
                return false;
            }

            public void onLongPress(MotionEvent motionEvent) {
                if (motionEvent.findPointerIndex(h.this.e) != -1) {
                    View.DragShadowBuilder dragShadowBuilder = new View.DragShadowBuilder(h.this.j);
                    if (Build.VERSION.SDK_INT >= 24) {
                        h.this.j.startDragAndDrop(ClipData.newPlainText("source", String.valueOf(this.e)), dragShadowBuilder, h.this.j, 0);
                    }
                }
            }

            public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
                CollageMakerDetailActivity collageMakerDetailActivity = CollageMakerDetailActivity.this;
                if (collageMakerDetailActivity.o0) {
                    collageMakerDetailActivity.o0 = false;
                } else {
                    collageMakerDetailActivity.m0();
                    e eVar = new e();
                    eVar.show(getSupportFragmentManager(), eVar.getTag());
                }
                return false;
            }
        }

        public h(Activity activity, ImageView imageView, int i, int i2, int i3) {
            this.j = imageView;
            this.g = i;
            this.i = i3;
            this.h = i2;
            this.f = new GestureDetector(activity, new a(imageView, i));
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            CollageMakerDetailActivity collageMakerDetailActivity = CollageMakerDetailActivity.this;
            collageMakerDetailActivity.f0 = this.j;
            collageMakerDetailActivity.S = this.g;
            if (this.f.onTouchEvent(motionEvent)) {
                return true;
            }
            int action = motionEvent.getAction();
            int actionMasked = motionEvent.getActionMasked() & action;
            int i = 0;
            if (actionMasked == 0) {
                TextStickerViewNew1 textStickerViewNew1 = CollageMakerDetailActivity.this.n0;
                if (textStickerViewNew1 != null) {
                    textStickerViewNew1.setBackground(null);
                }
            } else if (actionMasked == 1 || actionMasked == 3) {
                this.e = -1;
                return true;
            } else {
                if (actionMasked == 6) {
                    action = (action & 65280) >> 8;
                    if (motionEvent.getPointerId(action) == this.e) {
                        if (action == 0) {
                            i = 1;
                        }
                    }
                }
                return true;
            }
            this.e = motionEvent.getPointerId(i);
            return true;
        }
    }

    public class i extends AsyncTask<Void, Void, Void> {
        public String a;
        public Bitmap b;

        public i(String str) {
            this.a = str;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (this.b != null) {
                ImageStickerViewNew imageStickerViewNew = new ImageStickerViewNew(CollageMakerDetailActivity.this, this.a, 150.0f, 150.0f, 1.0f, 0.0f, 2, true);
                imageStickerViewNew.setGif(false);
                imageStickerViewNew.setTag("Element");
                imageStickerViewNew.setBitmap(this.b, Boolean.TRUE);
                imageStickerViewNew.setSize(250.0f);
                imageStickerViewNew.setOperationListener(new CollageTextOperationListener(CollageMakerDetailActivity.this, this, imageStickerViewNew));
                flElements.addView(imageStickerViewNew);
                flElements.requestLayout();
            }
            if (!CollageMakerDetailActivity.this.isFinishing()) {
                CollageMakerDetailActivity.this.u.u();
            }
        }

        @Override
        protected Void doInBackground(Void... voids) {
            Void[] voidArr = voids;
            Utils.O();
            try {
                this.b = BitmapFactory.decodeStream(new URL(this.a).openConnection().getInputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        public void onPreExecute() {
            super.onPreExecute();
            CollageMakerDetailActivity.this.u = new Utils(CollageMakerDetailActivity.this);
            CollageMakerDetailActivity collageMakerDetailActivity = CollageMakerDetailActivity.this;
            collageMakerDetailActivity.u.c(collageMakerDetailActivity.getResources().getString(com.kotlinz.festivalstorymaker.R.string.loading));
            if (!CollageMakerDetailActivity.this.isFinishing()) {
                CollageMakerDetailActivity.this.u.M();
            }
        }
    }

    public class a implements CollageMakeBottomFrameListAdapter.a {
        public void a(int i) {
            CollageMakerDetailActivity collageMakerDetailActivity = CollageMakerDetailActivity.this;
            /*collageMakerDetailActivity.n0(collageMakerDetailActivity.M.get(i).e);*/
        }
    }

    public class b implements BackgroundCategoryListAdapter.a {
        public void a(int i) {
            CollageMakerDetailActivity.this.s0(i);
        }
    }

    public class c implements BackgroundCatImageListAdapter.a {
        public final int a;

        public c(int i) {
            this.a = i;
        }

        public void a(int i) {
            if (g0 != null) {
                e0 = backgroundMainResponses.get(this.a).getBackgroundImages().get(i).getThemeThumbnail();
                Picasso.get().load(CollageMakerDetailActivity.this.e0).into(CollageMakerDetailActivity.this.g0, null);
            }
        }
    }

    public class d implements TextInputDilaog.d {
        public final FrameLayout a;
        public final TextStickerViewNew1 b;

        public d(CollageMakerDetailActivity collageMakerDetailActivity, FrameLayout frameLayout, TextStickerViewNew1 textStickerViewNew1) {
            this.a = frameLayout;
            this.b = textStickerViewNew1;
        }

        public void a(String str, int i) {
            if (str.length() == 0) {
                this.a.removeView(this.b);
                this.a.requestLayout();
                return;
            }
            this.b.setText(str);
        }

        public void b(String str) {
        }
    }

    public static class e extends BottomSheetDialogFragment {
        public CoordinatorLayout.Behavior k0;

        public class a implements View.OnClickListener {
            public void onClick(View view) {
                CoordinatorLayout.Behavior behavior = e.this.k0;
                if (behavior != null && (behavior instanceof BottomSheetBehavior)) {
                    ((BottomSheetBehavior) behavior).setState(BottomSheetBehavior.STATE_HIDDEN);
                }
                CameraOnlyConfig cameraOnlyConfig = new CameraOnlyConfig();
                cameraOnlyConfig.savePath = ImagePickerSavePath.DEFAULT;
                cameraOnlyConfig.returnMode = ReturnMode.CAMERA_ONLY;
                FragmentActivity c = e.this.getActivity();
                Intent intent = new Intent(c, ImagePickerActivity.class);
                intent.putExtra(CameraOnlyConfig.class.getSimpleName(), cameraOnlyConfig);
                c.startActivityForResult(intent, 553);
            }
        }

        public class b implements View.OnClickListener {
            public void onClick(View view) {
                CoordinatorLayout.Behavior behavior = e.this.k0;
                if (behavior != null && (behavior instanceof BottomSheetBehavior)) {
                    ((BottomSheetBehavior) behavior).setState(BottomSheetBehavior.STATE_HIDDEN);
                }
                ImagePicker.ImagePickerWithActivity aVar = new ImagePicker.ImagePickerWithActivity(e.this.getActivity());
                ImagePickerConfig imagePickerConfig = aVar.config;
                imagePickerConfig.folderMode = true;
                imagePickerConfig.returnMode = ReturnMode.GALLERY_ONLY;
                aVar.single();
                aVar.config.showCamera = false;
                aVar.start();
            }
        }


        @SuppressLint("RestrictedApi")
        @Override
        public void setupDialog(@NonNull Dialog dialog, int style) {
            super.setupDialog(dialog, style);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setDimAmount(0.0f);
            View inflate = View.inflate(getActivity(), com.kotlinz.festivalstorymaker.R.layout.dialog_select_image, null);
            dialog.setContentView(inflate);
            CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams) ((View) inflate.getParent()).getLayoutParams();
            CoordinatorLayout.Behavior behavior = params.getBehavior();
            this.k0 = behavior;
            if (behavior != null && (behavior instanceof BottomSheetBehavior)) {
                ((BottomSheetBehavior) behavior).setState(BottomSheetBehavior.STATE_EXPANDED);
            }
            dialog.findViewById(com.kotlinz.festivalstorymaker.R.id.llCamera).setOnClickListener(new a());
            dialog.findViewById(com.kotlinz.festivalstorymaker.R.id.llGallery).setOnClickListener(new b());
        }

    }

    public void B(Typeface typeface, int i) {
        Font font = this.n0.getFont();
        font.c = typeface;
        this.n0.setFont(font);
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.m0.get((Integer) this.n0.getTag());
        cVar.f = i;
        this.m0.set(((Integer) this.n0.getTag()).intValue(), cVar);
    }

    public void D(int i) {
        Font font = this.n0.getFont();
        font.a = Color.parseColor(colorList[i]);
        this.n0.setFont(font);
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.m0.get(((Integer) this.n0.getTag()).intValue());
        cVar.d = i;
        this.m0.set(((Integer) this.n0.getTag()).intValue(), cVar);
    }

    public void L(int i, String str) {
    }

    public final void g0(FrameLayout frameLayout, TextStickerViewNew1 textStickerViewNew1) {
        TextInputDilaog.q0(this, textStickerViewNew1.getText(), false, "").m0 = new d(this, frameLayout, textStickerViewNew1);
    }

    @SuppressLint({"NewApi"})
    public final void j0(int i) {
        int i2 = -16777216;
        ivAlignCenter.setColorFilter(i == 0 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ivAlignLeft.setColorFilter(i == -1 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ImageView imageView = ivAlignRight;
        if (i != 1) {
            i2 = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView.setColorFilter(i2);
        String str = this.n0.getText();
        TextStickerViewNew1 textStickerViewNew1 = this.n0;
        Layout.Alignment alignment = i == 0 ? Layout.Alignment.ALIGN_CENTER : i == 1 ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL;
        textStickerViewNew1.setAlign(alignment);
        this.n0.setText(str);
        this.n0.requestLayout();
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.m0.get(((Integer) this.n0.getTag()).intValue());
        cVar.c = i;
        this.m0.set(((Integer) this.n0.getTag()).intValue(), cVar);
    }

    public final void k0(int i) {
        int i2 = -16777216;
        ivFirstCap.setColorFilter(i == 1 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ivAlignAllCap.setColorFilter(i == 2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ImageView imageView = ivSmall;
        if (i != 0) {
            i2 = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView.setColorFilter(i2);
        String str = this.n0.getText();
        if (i != -1) {
            TextStickerViewNew1 textStickerViewNew1 = this.n0;
            str = i == 2 ? str.toUpperCase() : i == 0 ? str.toLowerCase() : f0(str);
            textStickerViewNew1.setText(str);
        }
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.m0.get(((Integer) this.n0.getTag()).intValue());
        cVar.e = i;
        this.m0.set(((Integer) this.n0.getTag()).intValue(), cVar);
    }

    public final void l0(ImageView imageView) {
        LinearLayout linearLayout;
        ImageView imageView2 = ivFont;
        int i = -16777216;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivColor;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivAlign;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivSpace;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivLine;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivCaps;
        if (imageView != imageView2) {
            i = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView2.setColorFilter(i);
        if (imageView == ivFont) {
            linearLayout = llFonts;
        } else if (imageView == ivColor) {
            linearLayout = llcolors;
        } else if (imageView == ivAlign) {
            linearLayout = llAlign;
        } else if (imageView == ivSpace) {
            linearLayout = llSpacing;
        } else if (imageView == ivLine) {
            linearLayout = llLine;
        } else if (imageView == ivCaps) {
            linearLayout = llI;
        } else {
            return;
        }
        linearLayout.bringToFront();
    }

    public void m0() {
        if (llDelete.isShown()) {
            q0(false);
        }
        ImageStickerViewNew imageStickerViewNew = this.p0;
        if (imageStickerViewNew != null) {
            imageStickerViewNew.setInEdit(false);
        }
        TextStickerViewNew1 textStickerViewNew1 = this.n0;
        if (textStickerViewNew1 != null) {
            textStickerViewNew1.setInEdit(false);
        }
        if (llTextEditor.isShown()) {
            r0(false);
        }
    }

    public final void n0(String str) {
        this.h0 = str;
        this.Q = 0;
        GetEditData();
    }

    private void GetEditData() {
        File fileEvents = new File(FilePath);
        StringBuilder text = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileEvents));
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String Response = text.toString();
        z(320, Response);
    }

    public File o0() {
        String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "My Post";
        String s = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.s(new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US));
        File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(file);
        stringBuilder.append(File.separator);
        stringBuilder.append(s);
        stringBuilder.append(".jpg");
        absolutePath = stringBuilder.toString();
        return TextUtils.isEmpty(absolutePath) ? null : new File(absolutePath);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == this.R) {
            if (intent != null) {
                String str = "element";
                if (intent.getStringExtra(str) != null) {
                    new i(intent.getStringExtra(str)).execute();
                }
            }
        } else if (i2 == -1 && i == 69) {
            this.f0.setImageURI(intent.getParcelableExtra("com.yalantis.ucrop.OutputUri"));
        } else {
            i2 = com.kotlinz.festivalstorymaker.Other.AppConstant.H;
            if (i == 7924 && intent != null) {
                String stringExtra = intent.getStringExtra("path");
                if (!stringExtra.isEmpty()) {
                    for (i = 0; i < flElements.getChildCount(); i++) {
                        if (flElements.getChildAt(i) instanceof ImageStickerViewNew) {
                            flElements.removeViewAt(i);
                            break;
                        }
                    }
                    Bitmap decodeFile = BitmapFactory.decodeFile(new File(stringExtra).getAbsolutePath());
                    float x = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) decodeFile.getWidth(), (((float) decodeFile.getWidth()) * 150.0f) / ((float) decodeFile.getHeight()), 2.0f, (float) ((decodeFile.getWidth() / 2) + 10), 20.0f);
                    float x2 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) decodeFile.getHeight(), 150.0f, 2.0f, (float) ((decodeFile.getHeight() / 2) + 10), 20.0f);
                    File file = new File(stringExtra);
                    if (file.exists()) {
                        try {
                            decodeFile = BitmapFactory.decodeFile(file.getAbsolutePath());
                            ImageStickerViewNew imageStickerViewNew = new ImageStickerViewNew(this, stringExtra, x, x2, 1.0f, 0.0f, 2, true);
                            imageStickerViewNew.setGif(false);
                            imageStickerViewNew.setBitmap(decodeFile, Boolean.TRUE);
                            imageStickerViewNew.setOperationListener(new CollageImageSticker(this, imageStickerViewNew));
                            imageStickerViewNew.setInEdit(false);
                            imageStickerViewNew.setSize(150.0f);
                            flElements.addView(imageStickerViewNew);
                            flElements.requestLayout();
                        } catch (OutOfMemoryError e) {
                            e.printStackTrace();
                        }
                    }
                }
            } else if (intent != null) {
                List c = ImagePicker.getImages(intent);
                if (c != null && c.size() > 0) {
                    this.SelectedImageList.set(this.S, ((Image) c.get(0)).path);
                    this.f0.setImageURI(Uri.parse(((Image) c.get(0)).path));
                    this.f0.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    this.f0.requestLayout();
                }
            }
        }
    }

    @OnClick({com.kotlinz.festivalstorymaker.R.id.iv_back, com.kotlinz.festivalstorymaker.R.id.iv_Download, com.kotlinz.festivalstorymaker.R.id.llAddBackground, com.kotlinz.festivalstorymaker.R.id.rlFull, com.kotlinz.festivalstorymaker.R.id.llAddElement, com.kotlinz.festivalstorymaker.R.id.llAddLogo, com.kotlinz.festivalstorymaker.R.id.llAddText})
    public void onClick(View view) {
        Intent intent;
        int i;
        switch (view.getId()) {
            case com.kotlinz.festivalstorymaker.R.id.iv_back:
                finish();
                return;
            case com.kotlinz.festivalstorymaker.R.id.iv_Download:
                m0();
                new g().execute();
                return;
            case com.kotlinz.festivalstorymaker.R.id.llAddBackground:
                ivBackground.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_bg_press);
                ivText.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collagetext_unpress);
                ivLogo.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collage_logo_unpress);
                ivElements.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_element_unpress);

                tvBackground.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_press));
                tvText.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvLogo.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvElements.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                p0();
            case com.kotlinz.festivalstorymaker.R.id.rlFull:
                return;
            case com.kotlinz.festivalstorymaker.R.id.llAddElement:
                ivElements.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_element_press);
                ivBackground.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_bg_unpress);
                ivText.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collagetext_unpress);
                ivLogo.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collage_logo_unpress);

                tvElements.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_press));
                tvBackground.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvText.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvLogo.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                i = this.R;
                intent = new Intent(activity, ElementsActivity.class);
                intent.putExtra("moduleid", ModuleId);
                break;
            case com.kotlinz.festivalstorymaker.R.id.llAddLogo:
                ivLogo.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_colllagelogo_press);
                ivBackground.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_bg_unpress);
                ivText.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collagetext_unpress);
                ivElements.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_element_unpress);

                tvLogo.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_press));
                tvBackground.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvText.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvElements.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));

                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                Utils.z(this).compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                intent = new Intent(getApplicationContext(), SelectLogoActivity.class).putExtra("image", byteArrayOutputStream.toByteArray());
                i = com.kotlinz.festivalstorymaker.Other.AppConstant.H;
                i = 7924;
                break;
            case com.kotlinz.festivalstorymaker.R.id.llAddText:
                ivText.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collagetext_press);
                ivBackground.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_bg_unpress);
                ivLogo.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collage_logo_unpress);
                ivElements.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_element_unpress);

                tvText.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_press));
                tvBackground.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvLogo.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvElements.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));

                FrameLayout frameLayout = flElements;
                TextStickerViewNew1 d0 = d0(this, SvScroll, frameLayout.getWidth(), frameLayout.getHeight(), "");
                g0(frameLayout, d0);
                d0.setOperationListener(new CollageTextSticker(this, frameLayout, d0));
                d0.setOnOutSideTouchListner(new CollageText(this));
                com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.G(this.m0, d0);
                this.m0.add(new com.kotlinz.festivalstorymaker.Models.z.c());
                frameLayout.addView(d0);
                frameLayout.requestLayout();
                return;
            default:
                return;
        }
        startActivityForResult(intent, i);
    }

    @OnClick({com.kotlinz.festivalstorymaker.R.id.imgAlign, com.kotlinz.festivalstorymaker.R.id.imgAlignCenter, com.kotlinz.festivalstorymaker.R.id.imgAlignLeft, com.kotlinz.festivalstorymaker.R.id.imgAlignRight, com.kotlinz.festivalstorymaker.R.id.imgAllCap, com.kotlinz.festivalstorymaker.R.id.imgCaps, com.kotlinz.festivalstorymaker.R.id.imgColor, com.kotlinz.festivalstorymaker.R.id.imgFirstCap, com.kotlinz.festivalstorymaker.R.id.imgFont, com.kotlinz.festivalstorymaker.R.id.imgLine, com.kotlinz.festivalstorymaker.R.id.imgSmall, com.kotlinz.festivalstorymaker.R.id.imgSpace})
    public void onClicks(View view) {
        ImageView imageView;
        switch (view.getId()) {
            case com.kotlinz.festivalstorymaker.R.id.imgAlign:
                imageView = this.ivAlign;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignCenter:
                j0(0);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignLeft:
                j0(-1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignRight:
                j0(1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAllCap:
                k0(2);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgCaps:
                imageView = ivCaps;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgColor:
                imageView = ivColor;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgFirstCap:
                k0(1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgFont:
                imageView = ivFont;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgLine:
                imageView = ivLine;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgSmall:
                k0(0);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgSpace:
                imageView = ivSpace;
                break;
            default:
                return;
        }
        l0(imageView);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.kotlinz.festivalstorymaker.R.layout.activity_collage_maker_detail);
        ButterKnife.bind(this);
        PutAnalyticsEvent();
        com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b = getSharedPreferences("MyPREFERENCES", Context.MODE_PRIVATE);
        ModuleId = getIntent().getIntExtra("moduleid", 0);
        FilePath = getIntent().getStringExtra("FilePath");
        SelectedImageList = getIntent().getStringArrayListExtra("list");
        apiInterface = APIClient.getClient().create(APIInterface.class);
        InitProgressDialog();
        LoadNativeAds();
        this.K = new com.kotlinz.festivalstorymaker.Other.g.a(this, this);
        if (Utils.x(this)) {
            GetEditData();
        }
        ivFont.setColorFilter(-16777216);
        llFonts.bringToFront();
        fontListAdapter = new FontListAdapter(this, fontList, new SetFont(this), this.l0);
        rvFonts.setAdapter(fontListAdapter);
        ColorListAdapter colorListAdapter = new ColorListAdapter(this, colorList, new SetColorList(this), this.k0);
        j0 = colorListAdapter;
        rvColors.setAdapter(colorListAdapter);
        sbFontHeight.setOnSeekBarChangeListener(new FontHeight(this));
        sbFontSpacing.setOnSeekBarChangeListener(new FontSpacingCollageMaker(this));

    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CollageMakerDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(com.kotlinz.festivalstorymaker.R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (CollageMakerDetailActivity.this.nativeAd != null) {
                            CollageMakerDetailActivity.this.nativeAd.destroy();
                        }
                        CollageMakerDetailActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(com.kotlinz.festivalstorymaker.R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(com.kotlinz.festivalstorymaker.R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

   /* private void GetCollageCategory(int ModuleId) {
        progressDialog.show();
        Call<CollageResponse> call = apiInterface.getCollageModuleWiseCategory(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<CollageResponse>() {
            @Override
            public void onResponse(Call<CollageResponse> call, Response<CollageResponse> response) {
                if (response.isSuccessful()) {
                    collageCategoryList = response.body().getData();
                    GetCollageCategoryDataByID(String.valueOf(collageCategoryList.get(0).getCatId()), String.valueOf(collageCategoryList.get(0).getChildCategory().get(0).getChildCatId()));
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<CollageResponse> call, Throwable t) {

            }
        });
    }

    public void GetCollageCategoryDataByID(String ParentCatId, String ChildCatId) {
        progressDialog.show();
        Call<CollageCategoryWiseResponse> call = apiInterface.getCollageCategoryWiseData(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId), "0", ParentCatId, ChildCatId);
        call.enqueue(new Callback<CollageCategoryWiseResponse>() {
            @Override
            public void onResponse(Call<CollageCategoryWiseResponse> call, Response<CollageCategoryWiseResponse> response) {
                if (response.isSuccessful()) {
                    categoryWiseCollageList = response.body().getData();
                    collageMakeBottomFrameListAdapter = new CollageMakeBottomFrameListAdapter(activity, categoryWiseCollageList, new a());
                    rvCollageFrame.setLayoutManager(new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false));
                    rvCollageFrame.setAdapter(collageMakeBottomFrameListAdapter);
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<CollageCategoryWiseResponse> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }*/


    @OnClick
    public void onViewClick(View view) {
        int id = view.getId();
        if (id == com.kotlinz.festivalstorymaker.R.id.cardCancelImage || id == com.kotlinz.festivalstorymaker.R.id.cardDeleteImage) {
            q0(false);
        }
    }

    public final void p0() {
        LinearLayout linearLayout = llBackGroundSelection;
        int Visibility = View.GONE;
        int AdsVisibility = View.VISIBLE;
        Slide slide = new Slide(Gravity.BOTTOM);
        slide.setDuration(500);
        slide.addTarget(com.kotlinz.festivalstorymaker.R.id.llBackgroundSelection);
        if (!linearLayout.isShown()) {
            Visibility = View.VISIBLE;
            GetCollageBackground(ModuleId);
        }
        linearLayout.setVisibility(Visibility);
        if (frameLayout.isShown()){
            AdsVisibility =  View.GONE;
        }
        frameLayout.setVisibility(AdsVisibility);

    }


    private void GetCollageBackground(int ModuleId) {
        progressDialog.show();
        Call<BackgroundResponse> call = apiInterface.getBackgroundDetails(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<BackgroundResponse>() {
            @Override
            public void onResponse(Call<BackgroundResponse> call, Response<BackgroundResponse> response) {
                if (response.isSuccessful()) {
                    backgroundMainResponses = response.body().getData();
                    backgroundCategoryListAdapter = new BackgroundCategoryListAdapter(activity, backgroundMainResponses, new b(), 0);
                    rvBackground.setLayoutManager(new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false));
                    rvBackground.setAdapter(backgroundCategoryListAdapter);
                    s0(0);
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<BackgroundResponse> call, Throwable t) {

            }
        });
    }

    public final void q0(boolean z) {
        int i = 0;
        rlTop.setVisibility(z ? View.VISIBLE : View.GONE);
        LinearLayout linearLayout = llDelete;
        FrameLayout frameLayout = flFrameLayout;
        Slide slide = new Slide(Gravity.BOTTOM);
        slide.setDuration(500);
        slide.addTarget(llDelete);
        TransitionManager.beginDelayedTransition(frameLayout, slide);
        if (!z) {
            i = 8;
        }
        linearLayout.setVisibility(i);
    }

    public final void r0(boolean z) {
        if (z) {
            l0(ivFont);
            com.kotlinz.festivalstorymaker.Models.z.c cVar = this.m0.get(((Integer) this.n0.getTag()).intValue());
            k0 = cVar.d;
            l0 = cVar.f;
            sbFontHeight.setProgress(cVar.a);
            sbFontSpacing.setProgress(cVar.b);
            j0.k(this.k0);
            fontListAdapter.k(this.l0);
            j0(cVar.c);
            k0(cVar.e);
        }
        LinearLayout linearLayout = llTextEditor;
        FrameLayout frameLayout = flFrameLayout;
        Slide slide = new Slide(Gravity.BOTTOM);
        slide.setDuration(500);
        slide.addTarget(linearLayout);
        TransitionManager.beginDelayedTransition(frameLayout, slide);
        linearLayout.setVisibility(z ? View.VISIBLE : View.GONE);
    }

    public final void s0(int i) {
        rvBackgroundCatImage.setAdapter(new BackgroundCatImageListAdapter(activity, backgroundMainResponses.get(i).getBackgroundImages(), new c(i)));
    }

    public final void t0(int i) {
        if (i == 0) {
            U = (int) Float.parseFloat(Images.get(i).j);
            int parseFloat = (int) Float.parseFloat(Images.get(i).k);
            V = parseFloat;
            W = (parseFloat * T) / U;
            flFrameLayout.getLayoutParams().width = T;
            flFrameLayout.getLayoutParams().height = W;
            flFrameLayout.requestLayout();
            flElements.getLayoutParams().width = T;
            flElements.getLayoutParams().height = W;
            flElements.requestLayout();
        }
        if (Images.get(i).e.equalsIgnoreCase("image")) {
            com.kotlinz.festivalstorymaker.Models.g gVar = Images.get(i);
            Float valueOf = Float.valueOf((Float.parseFloat(gVar.h) * ((float) this.T)) / ((float) this.U));
            Float valueOf2 = Float.valueOf((Float.parseFloat(gVar.i) * ((float) this.T)) / ((float) this.U));
            int parseFloat2 = (int) ((Float.parseFloat(gVar.j) * ((float) this.T)) / ((float) this.U));
            int parseFloat3 = (int) ((Float.parseFloat(gVar.k) * ((float) this.T)) / ((float) this.U));
            ImageView imageView = new ImageView(this);
            String str = "1";
            if (gVar.B.equals(str) || gVar.q.equals(str)) {
                imageView.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
                imageView.getLayoutParams().width = parseFloat2;
                imageView.getLayoutParams().height = parseFloat3;
                imageView.setX(valueOf.floatValue());
                imageView.setY(valueOf2.floatValue());
                imageView.setAdjustViewBounds(true);
                imageView.setBackgroundColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
                if (gVar.f.isEmpty() || this.SelectedImageList.size() <= this.Q) {
                    imageView.setTag(Integer.valueOf(0));
                    imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    Glide.with(activity).load(com.kotlinz.festivalstorymaker.R.drawable.ic_add_image).into(imageView);
                } else {
                    imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    Glide.with(activity).load(new File(this.SelectedImageList.get(this.Q))).into(imageView);
                    imageView.setTag(Integer.valueOf(this.Q));
                    this.Q++;
                }
                imageView.setOnDragListener(new f(this.O.size()));
                imageView.setOnTouchListener(new h(this, imageView, this.O.size(), parseFloat2, parseFloat3));
                imageView.requestLayout();
                this.O.add(imageView);
            } else {
                imageView.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
                imageView.setX(valueOf.floatValue());
                imageView.setY(valueOf2.floatValue());
                imageView.getLayoutParams().width = parseFloat2;
                imageView.getLayoutParams().height = parseFloat3;
                imageView.requestLayout();
                imageView.setAdjustViewBounds(true);
                imageView.setBackgroundColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.transparent_black));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.requestLayout();
                if (gVar.C.equalsIgnoreCase(str)) {
                    imageView.setOnClickListener(new CollageImage(this));
                }
                if (!gVar.f.isEmpty()) {
                    Glide.with(activity).load(gVar.f).into(imageView);
                }
                if (i == 0) {
                    this.g0 = imageView;
                    if (this.e0.length() > 0) {
                        Glide.with(activity).load(this.e0).into(this.g0);
                    }
                }
            }
            this.flFrameLayout.addView(imageView);
            this.flFrameLayout.requestLayout();
        }
    }

    @Override
    public void z(int i, String str) {
        int i2 = 0;
        if (i == 320) {
            this.flFrameLayout.removeAllViews();
            this.flFrameLayout.requestLayout();
            ArrayList d = new com.kotlinz.festivalstorymaker.Other.AppConstant().getCollageEditThemeData(this, str);
            Images = d;
            if (d != null && d.size() > 0) {
                this.O.clear();
                if (this.T == 0) {
                    this.flFrameLayout.getViewTreeObserver().addOnGlobalLayoutListener(new CollageMakerFl(this));
                    return;
                }
                while (i2 < Images.size()) {
                    t0(i2);
                    i2++;
                }
            }
        }
    }
}