package com.unitedvideos.Model;


import java.util.ArrayList;

public class VerticalModel {
    private String id;
    private String Name;
    private ArrayList<ThemeHorizontalModel> arrayList;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public ArrayList<ThemeHorizontalModel> getArrayList() {
        return arrayList;
    }

    public void setArrayList(ArrayList<ThemeHorizontalModel> arrayList) {
        this.arrayList = arrayList;
    }
}
