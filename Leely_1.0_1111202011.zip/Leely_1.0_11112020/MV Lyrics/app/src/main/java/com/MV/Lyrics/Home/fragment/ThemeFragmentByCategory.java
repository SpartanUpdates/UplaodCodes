package com.MV.Lyrics.Home.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.Home.Adapter.HomeLyricsAdapter;
import com.MV.Lyrics.Home.Model.ThemeHorizontalModel;
import com.MV.Lyrics.Home.activity.HomeActivity;
import com.MV.Lyrics.LyricsSelect.LanguagePref;
import com.MV.Lyrics.R;
import com.MV.Lyrics.Retrofit.APIClient;
import com.MV.Lyrics.Retrofit.APIInterface;
import com.MV.Lyrics.Retrofit.AppConstant;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThemeFragmentByCategory extends Fragment {

    public LanguagePref sharedpreferences;
    LinearLayout llInternetCheck;
    Button btnRetry;
    RelativeLayout rlLoadingTheme;
    RecyclerView rvVideos;
    String offlineThemeData;
    int CategoryId = -1;
    String CatId;
    SharedPreferences pref;
    String[] split_selctedLan;
    private ArrayList<ThemeHorizontalModel> ThemeListCategoryWise = new ArrayList<>();
    LinearLayoutManager linearLayoutManager;
    public HomeLyricsAdapter themeAdapter;
    APIInterface apiInterface;

    private boolean isLoading = false;
    private int PageId = 1;

    Integer TabIndex = -1;

    public static ThemeFragmentByCategory newInstance(int catid, int TabIndex) {
        ThemeFragmentByCategory fragment = new ThemeFragmentByCategory();
        Bundle bundle = new Bundle();
        bundle.putInt("CategoryId", catid);
        bundle.putInt("TabIndex", TabIndex);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            CategoryId = getArguments().getInt("CategoryId");
            TabIndex = getArguments().getInt("TabIndex");
            CatId = String.valueOf(CategoryId);
        }
    }

    public int getTabIndex() {
        return this.TabIndex;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_theme, container, false);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        sharedpreferences = LanguagePref.a(getActivity());
        split_selctedLan = LanguagePref.a(getActivity()).a("pref_key_language_list", "28").split(",");
        apiInterface = APIClient.getClient().create(APIInterface.class);
        BindView(view);
        SetListener();
        if (ThemeListCategoryWise != null && ThemeListCategoryWise.size() == 0) {
            SetThemeData();
        } else {
            SetUpAdapter();
        }
        return view;
    }


    private void SetThemeData() {
        String id = pref.getString(CatId, null);
        if (id != null && !id.equals("")) {
            getOfflineCategory(getActivity(), CatId);
            if (offlineThemeData != null) {
                new GetofflineThemeData().execute();
            } else {
                llInternetCheck.setVisibility(View.VISIBLE);
                rlLoadingTheme.setVisibility(View.GONE);
                Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void BindView(View view) {
        rvVideos = view.findViewById(R.id.rvVideos);
        llInternetCheck = view.findViewById(R.id.llRetry);
        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
        rlLoadingTheme = view.findViewById(R.id.rl_loading_pager);
        rvVideos.setNestedScrollingEnabled(false);
        rvVideos.setHasFixedSize(true);
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    startActivity(new Intent(getActivity(), HomeActivity.class));
                    getActivity().finish();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlineThemeData = pref.getString(key, null);
    }


    private void SetUpAdapter() {
        RecyclerView recyclerView;
        int i2 = 0;
        themeAdapter = new HomeLyricsAdapter(getActivity(), ThemeListCategoryWise, this);
        linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvVideos.setLayoutManager(linearLayoutManager);
        rvVideos.setItemAnimator(new DefaultItemAnimator());
        rvVideos.setAdapter(themeAdapter);
        if (MyApplication.ThemePosition == -1) {
            recyclerView = this.rvVideos;
        } else {
            recyclerView = this.rvVideos;
            i2 = MyApplication.ThemePosition;
        }
        recyclerView.scrollToPosition(i2);
        rvVideos.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                MyApplication.ThemePosition = linearLayoutManager.findFirstVisibleItemPosition();
                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
                if (!isLoading) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == ThemeListCategoryWise.size() - 1) {
                        GetLoadMoreCategoryOfTheme();
                        isLoading = true;
                    }
                }
            }
        });
       /* if (!MyApplication.IsHomeInterstitialAdsDisplay && MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
            MyApplication.IsHomeInterstitialAdsDisplay = true;
            MyApplication.AdsId = 6;
            MyApplication.mInterstitialAd.show();
        }*/
        themeAdapter.notifyDataSetChanged();
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }


    private void GetLoadMoreCategoryOfTheme() {
        PageId++;
        rlLoadingTheme.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.loadMoreList(AppConstant.Token, AppConstant.ApplicationId, CatId, String.valueOf(PageId));
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
//                        String bundelPath = jsonObj.getString("thumb_big_path");
//                        String ThemeThumb = jsonObj.getString("thumb_small_path");
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                            int Catid = Integer.parseInt(themeJSONObject.getString("id"));
                            String CategoryName = themeJSONObject.getString("name");
                            if (CategoryId == Catid) {
                                JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                                for (int j = 0; j < jSONArray4.length(); j++) {
                                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                                    themeModel.setThemeid(jsonobjecttheme.getString("video_id"));
                                    themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                    themeModel.setThemeName(jsonobjecttheme.getString("video_name"));
                                    themeModel.setImage(AppConstant.VideoThumbPath + jsonobjecttheme.getString("video_thumbnail"));
                                    themeModel.setBundelurl(AppConstant.DataFilePath + jsonobjecttheme.getString("data_file"));
                                    themeModel.setBundelname(jsonobjecttheme.getString("data_file"));
                                    themeModel.setBundelPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getBundelname());
                                    themeModel.setZipDownloadCatName(CategoryName);
                                    String foldername = themeModel.getBundelname();
                                    int pos = foldername.lastIndexOf(".");
                                    if (pos > 0) {
                                        foldername = foldername.substring(0, pos);
                                    }
                                    themeModel.setZipFolderName(foldername);
                                    themeModel.setUnity3DName(foldername + ".unity3d");
                                    themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + themeModel.getZipDownloadCatName() + File.separator + themeModel.getZipFolderName() + File.separator + themeModel.getBundelname());
                                    themeModel.setBundelfilesize(Integer.parseInt(jsonobjecttheme.getString("data_file_size")));
                                    themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                    themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                    if (!Arrays.asList(AppConstant.split_AllLan).contains(String.valueOf(Catid))) {
                                        ThemeListCategoryWise.add(themeModel);
                                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                                        ThemeListCategoryWise.add(themeModel);
                                    }

                                }
                            }
                        }
                        SetUpAdapter();
                        rlLoadingTheme.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                rlLoadingTheme.setVisibility(View.GONE);
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    public class GetofflineThemeData extends AsyncTask<Void, Void, Void> {

        protected void onPreExecute() {
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlineThemeData);
                int Catid = Integer.parseInt(jsonObj.getString("id"));
                String CategoryName = jsonObj.getString("name");
                JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
                for (int j = 0; j < jSONArray4.length(); j++) {
                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                    themeModel.setThemeid(jsonobjecttheme.getString("video_id"));
                    themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                    themeModel.setThemeName(jsonobjecttheme.getString("video_name"));
                    themeModel.setImage(AppConstant.VideoThumbPath + jsonobjecttheme.getString("video_thumbnail"));
                    themeModel.setBundelurl(AppConstant.DataFilePath + jsonobjecttheme.getString("data_file"));
                    themeModel.setBundelname(jsonobjecttheme.getString("data_file"));
                    themeModel.setBundelPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getBundelname());
                    themeModel.setZipDownloadCatName(CategoryName);
                    String foldername = themeModel.getBundelname();
                    int pos = foldername.lastIndexOf(".");
                    if (pos > 0) {
                        foldername = foldername.substring(0, pos);
                    }
                    themeModel.setZipFolderName(foldername);
                    themeModel.setUnity3DName(foldername + ".unity3d");
                    themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + themeModel.getZipDownloadCatName() + File.separator + themeModel.getZipFolderName() + File.separator + themeModel.getBundelname());
                    themeModel.setBundelfilesize(Integer.parseInt(jsonobjecttheme.getString("data_file_size")));
                    themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                    themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                    if (!Arrays.asList(AppConstant.split_AllLan).contains(String.valueOf(Catid))) {
                        ThemeListCategoryWise.add(themeModel);
                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                        ThemeListCategoryWise.add(themeModel);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(Void result) {
            rlLoadingTheme.setVisibility(View.GONE);
            SetUpAdapter();
        }
    }

}
