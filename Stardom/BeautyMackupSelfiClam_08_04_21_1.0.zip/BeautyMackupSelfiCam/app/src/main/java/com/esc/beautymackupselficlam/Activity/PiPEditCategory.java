package com.esc.beautymackupselficlam.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.esc.beautymackupselficlam.R;
import com.esc.beautymackupselficlam.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class PiPEditCategory extends Activity implements OnClickListener {
    private RelativeLayout rl_pipIndianEdior;
    private RelativeLayout rl_pipeditor;
    private RelativeLayout rl_pipPakisanEditor;
    private RelativeLayout rl_pipMagazineeditor;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pip_category);
        loadAd();
        BannerAds();
        BannerAds();
        BindView();
    }

    private void BindView() {
        this.rl_pipeditor = (RelativeLayout) findViewById(R.id.ll_editor);
        this.rl_pipeditor.setOnClickListener(this);
        this.rl_pipMagazineeditor = (RelativeLayout) findViewById(R.id.ll_Editor);
        this.rl_pipMagazineeditor.setOnClickListener(this);
        this.rl_pipPakisanEditor = (RelativeLayout) findViewById(R.id.ll_CollageEditor);
        this.rl_pipPakisanEditor.setOnClickListener(this);
        this.rl_pipIndianEdior = (RelativeLayout) findViewById(R.id.ll_IndianPIPEditor);
        this.rl_pipIndianEdior.setOnClickListener(this);
    }

    public void onClick(View v) {
        if (v == this.rl_pipeditor) {
            if (interstitial != null && interstitial.isLoaded()) {
                try {
                    hud = KProgressHUD.create(PiPEditCategory.this)
                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                            .setLabel("Showing Ads")
                            .setDetailsLabel("Please Wait...");
                    hud.show();
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (NullPointerException e2) {
                    e2.printStackTrace();
                } catch (Exception e3) {
                    e3.printStackTrace();
                }

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            hud.dismiss();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();

                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }
                        if (interstitial != null && interstitial.isLoaded()) {
                            id = R.id.ll_editor;
                            interstitial.show();
                        }
                    }
                }, 2000);
            } else {
                startActivity(new Intent(this, PIPPhotoEditor.class));
            }
        } else if (v == this.rl_pipMagazineeditor) {
            startActivity(new Intent(this, PipPhotoMagazineEditor.class));
        } else if (v == this.rl_pipPakisanEditor) {
            startActivity(new Intent(this, PipPhotoPakistanEditor.class));
        } else if (v == this.rl_pipIndianEdior) {
            if (interstitial != null && interstitial.isLoaded()) {
                try {
                    hud = KProgressHUD.create(PiPEditCategory.this)
                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                            .setLabel("Showing Ads")
                            .setDetailsLabel("Please Wait...");
                    hud.show();
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (NullPointerException e2) {
                    e2.printStackTrace();
                } catch (Exception e3) {
                    e3.printStackTrace();
                }

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            hud.dismiss();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();

                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }
                        if (interstitial != null && interstitial.isLoaded()) {
                            id = R.id.ll_IndianPIPEditor;
                            interstitial.show();
                        }
                    }
                }, 2000);
            } else {
                startActivity(new Intent(this, PipphotoIndiaEditor.class));
            }
        }
    }

    private void loadAd() {
        //interstitial FullScreenAd
        interstitial = new InterstitialAd(PiPEditCategory.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.ll_editor:
                        startActivity(new Intent(PiPEditCategory.this, PIPPhotoEditor.class));
                        break;
                    case R.id.ll_IndianPIPEditor:
                        startActivity(new Intent(PiPEditCategory.this, PipphotoIndiaEditor.class));
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(PiPEditCategory.this);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(PiPEditCategory.this);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
