package com.esc.dailyrandomfacts.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Category implements Serializable {
    public static final String TAG = "category";
    @SerializedName("is_free")
    private boolean free;
    @SerializedName("id")
    private String id;
    private boolean reminderSelected = false;
    @SerializedName("name")
    private String title;

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public boolean isFree() {
        return this.free;
    }

    public void setFree(boolean z) {
        this.free = z;
    }

    public boolean isReminderSelected() {
        return this.reminderSelected;
    }

    public void setReminderSelected(boolean z) {
        this.reminderSelected = z;
    }
}
