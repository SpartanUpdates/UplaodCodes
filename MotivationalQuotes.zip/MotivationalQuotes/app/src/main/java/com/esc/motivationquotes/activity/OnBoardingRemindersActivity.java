package com.esc.motivationquotes.activity;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.esc.motivationquotes.R;
import com.esc.motivationquotes.kprogresshud.KProgressHUD;
import com.esc.motivationquotes.managers.SettingsManager;
import com.esc.motivationquotes.model.Pref;
import com.esc.motivationquotes.util.Constants;
import com.esc.motivationquotes.util.Utils;
import com.esc.motivationquotes.reminders.RemindersUtils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.util.HashMap;
import java.util.Map;

public class OnBoardingRemindersActivity extends BaseActivity implements OnClickListener {
    private Button btn_save;
    private Button btn_cancel;
    private ImageView iv_plus;
    private ImageView iv_minus;
    private boolean isFromStartTime = false;
    private LinearLayout linearConfig;
    private int mEndHour;
    private int mEndMinute;
    private int mStartHour;
    private int mStartMinute;
    private OnTimeSetListener myTimeListener = new OnTimeSetListener() {
        @SuppressLint("WrongConstant")
        public void onTimeSet(TimePicker timePicker, int i, int i2) {
            String str = "HH:mm";
            String str2 = ":";
            Context context;
            String str3;
            String str4;
            int parseInt;
            int parseInt2;
            TextView access$100;
            StringBuilder stringBuilder;
            String str5;
            StringBuilder stringBuilder2;
            if (OnBoardingRemindersActivity.this.isFromStartTime) {
                context = OnBoardingRemindersActivity.this;
                str3 = Constants.NOTIFICATION_END_TIME;
                str4 = RemindersUtils.DEFAULT_END_HOUR;
                parseInt = Integer.parseInt(Pref.getValue(context, str3, str4).split(str2)[0]);
                parseInt2 = Integer.parseInt(Pref.getValue(OnBoardingRemindersActivity.this, Constants.NOTIFICATION_END_TIME, str4).split(str2)[1]);
                if (i < parseInt || (i == parseInt && i2 < parseInt2)) {
                    access$100 = OnBoardingRemindersActivity.this.txt_StartTime;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(i);
                    stringBuilder.append(str2);
                    stringBuilder.append(i2);
                    access$100.setText(Utils.convertDateStringToString(stringBuilder.toString(), str, str));
                    context = OnBoardingRemindersActivity.this;
                    str5 = Constants.NOTIFICATION_START_TIME;
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(i);
                    stringBuilder2.append(str2);
                    stringBuilder2.append(i2);
                    Pref.setValue(context, str5, Utils.convertDateStringToString(stringBuilder2.toString(), str, str));
                    return;
                }
                Toast.makeText(OnBoardingRemindersActivity.this.getApplicationContext(), OnBoardingRemindersActivity.this.getString(R.string.startValidMsg), 0).show();
                return;
            }
            context = OnBoardingRemindersActivity.this;
            str3 = Constants.NOTIFICATION_START_TIME;
            str4 = RemindersUtils.DEFAULT_START_HOUR;
            parseInt = Integer.parseInt(Pref.getValue(context, str3, str4).split(str2)[0]);
            parseInt2 = Integer.parseInt(Pref.getValue(OnBoardingRemindersActivity.this, Constants.NOTIFICATION_START_TIME, str4).split(str2)[1]);
            if (i > parseInt || (i == parseInt && i2 > parseInt2)) {
                access$100 = OnBoardingRemindersActivity.this.txt_EndTime;
                stringBuilder = new StringBuilder();
                stringBuilder.append(i);
                stringBuilder.append(str2);
                stringBuilder.append(i2);
                access$100.setText(Utils.convertDateStringToString(stringBuilder.toString(), str, str));
                context = OnBoardingRemindersActivity.this;
                str5 = Constants.NOTIFICATION_END_TIME;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(i);
                stringBuilder2.append(str2);
                stringBuilder2.append(i2);
                Pref.setValue(context, str5, Utils.convertDateStringToString(stringBuilder2.toString(), str, str));
                return;
            }
            Toast.makeText(OnBoardingRemindersActivity.this.getApplicationContext(), OnBoardingRemindersActivity.this.getString(R.string.endValidMsg), 0).show();
        }
    };
    private RelativeLayout relativeEnd;
    private RelativeLayout relativeHowMany;
    private RelativeLayout relativePushEndTime;
    private RelativeLayout relativePushStartTime;
    private RelativeLayout relativeStart;
    private int remindersNumber = 0;
    private TextView txt_EndTime;
    private TextView txt_StartTime;
    private TextView txt_Author;
    private TextView txtRepeat;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_onboarding_reminders);
        bindUi();
        setListeners();
        loadValues();
        changeAuthorVisibility();
        Pref.setValue(this, Constants.IS_SLIDER_ON, "1");
        this.linearConfig.animate().setDuration(750).setStartDelay(500).alpha(1.0f);
        loadAd();
    }

    private void bindUi() {
        this.txtRepeat = findViewById(R.id.txt_Repeat);
        this.txt_StartTime = findViewById(R.id.txt_StartTime);
        this.txt_EndTime = findViewById(R.id.txt_EndTime);
        this.iv_minus = findViewById(R.id.iv_minus);
        this.iv_plus = findViewById(R.id.iv_plus);
        this.linearConfig = findViewById(R.id.linearConfig);
        this.btn_save = findViewById(R.id.btn_save);
        btn_cancel = findViewById(R.id.btn_cancel);
        this.txt_Author = findViewById(R.id.txt_Author);
        this.relativePushStartTime = findViewById(R.id.relativePushStartTime);
        this.relativePushEndTime = findViewById(R.id.relativePushEndTime);
        this.relativeHowMany = findViewById(R.id.relativeHowMany);
        this.relativeStart = findViewById(R.id.relativeStart);
        this.relativeEnd = findViewById(R.id.relativeEnd);
    }

    private void setListeners() {
        this.iv_minus.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = remindersNumber;
                if (i < 30) {
                    remindersNumber = i + 1;
                    Pref.setValue(getApplicationContext(), Constants.PREF_REPEAT_RATIO, Integer.toString(remindersNumber));
                    TextView textView = txtRepeat;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(remindersNumber);
                    stringBuilder.append("X");
                    textView.setText(stringBuilder.toString());
                    Pref.setValue(getApplicationContext(), Constants.IS_SLIDER_ON, "1");
                }
            }
        });

        this.iv_plus.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = remindersNumber;
                String str = "0";
                if (i > 0) {
                    remindersNumber = i - 1;
                    Pref.setValue(getApplicationContext(), Constants.PREF_REPEAT_RATIO, Integer.toString(remindersNumber));
                    TextView textView = txtRepeat;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(remindersNumber);
                    stringBuilder.append("X");
                    textView.setText(stringBuilder.toString());
                    if (remindersNumber == 0) {
                        Pref.setValue(getApplicationContext(), Constants.IS_SLIDER_ON, str);
                        RemindersUtils.cancelAlarms(getApplicationContext());
                        return;
                    }
                    return;
                }
                Pref.setValue(getApplicationContext(), Constants.IS_SLIDER_ON, str);
                RemindersUtils.cancelAlarms(getApplicationContext());
            }
        });
        this.btn_save.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                id = 100;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    String str = "1";
                    if (Pref.getValue(getApplicationContext(), Constants.IS_SLIDER_ON, str).equals(str)) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                            RemindersUtils.setAlarmOnTime(getApplicationContext());
                        }
                    }
                    startActivity(new Intent(getApplicationContext(), QuotesHomeActivity.class));
                    finish();
                }
            }
        });

        btn_cancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v)
            {
                id = 101;
                if (interstitialAd != null && interstitialAd.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    startActivity(new Intent(getApplicationContext(), QuotesHomeActivity.class));
                    finish();
                }
            }
        });

        this.txt_StartTime.setOnClickListener(this);
        this.txt_EndTime.setOnClickListener(this);
        this.relativePushStartTime.setOnClickListener(this);
        this.relativePushEndTime.setOnClickListener(this);
    }

    private void loadValues() {
        Pref.setValue(this, Constants.PREF_IS_FIRST, "1");
        this.remindersNumber = Integer.parseInt(Pref.getValue(this, Constants.PREF_REPEAT_RATIO, RemindersUtils.REMINDERS_DEFAULT));
        TextView textView = this.txtRepeat;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.remindersNumber);
        stringBuilder.append("X");
        textView.setText(stringBuilder.toString());
        String str = "";
        String str2 = ":";
        if (Pref.getValue(this, Constants.NOTIFICATION_START_TIME, str).equals(str)) {
            Pref.setValue(this, Constants.NOTIFICATION_START_TIME, RemindersUtils.DEFAULT_START_HOUR);
            this.txt_StartTime.setText(Pref.getValue(this, Constants.NOTIFICATION_START_TIME, str));
            this.mStartHour = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_START_TIME, str).split(str2)[0]);
            this.mStartMinute = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_START_TIME, str).split(str2)[1]);
        } else {
            this.txt_StartTime.setText(Pref.getValue(this, Constants.NOTIFICATION_START_TIME, str));
            this.mStartHour = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_START_TIME, str).split(str2)[0]);
            this.mStartMinute = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_START_TIME, str).split(str2)[1]);
        }
        if (Pref.getValue(this, Constants.NOTIFICATION_END_TIME, str).equals(str)) {
            Pref.setValue(this, Constants.NOTIFICATION_END_TIME, RemindersUtils.DEFAULT_END_HOUR);
            this.txt_EndTime.setText(Pref.getValue(this, Constants.NOTIFICATION_END_TIME, str));
            this.mEndHour = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_END_TIME, str).split(str2)[0]);
            this.mEndMinute = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_END_TIME, str).split(str2)[1]);
            return;
        }
        this.txt_EndTime.setText(Pref.getValue(this, Constants.NOTIFICATION_END_TIME, str));
        this.mEndHour = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_END_TIME, str).split(str2)[0]);
        this.mEndMinute = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_END_TIME, str).split(str2)[1]);
    }

    public void onBackPressed()
    {
        startActivity(new Intent(OnBoardingRemindersActivity.this, HomeActivity.class));
        finish();
    }

    public void onDestroy() {
        Map hashMap = new HashMap();
        hashMap.put("Enabled", this.remindersNumber > 0 ? "Yes" : "No");
        hashMap.put("Repeat", Pref.getValue(this, Constants.PREF_REPEAT_RATIO, RemindersUtils.REMINDERS_DEFAULT));
        super.onDestroy();
    }

    public void onClick(View view) {
        String str = ":";
        String str2 = "";
        TimePickerDialog timePickerDialog;
        switch (view.getId()) {
            case R.id.txt_EndTime:
                this.mEndHour = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_END_TIME, str2).split(str)[0]);
                this.mEndMinute = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_END_TIME, str2).split(str)[1]);
                timePickerDialog = new TimePickerDialog(this, this.myTimeListener, this.mEndHour, this.mEndMinute, true);
                changeTimeDialogButtonsColor(timePickerDialog);
                timePickerDialog.show();
                return;
            case R.id.txt_StartTime:
                this.isFromStartTime = true;
                this.mStartHour = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_START_TIME, str2).split(str)[0]);
                this.mStartMinute = Integer.parseInt(Pref.getValue(this, Constants.NOTIFICATION_START_TIME, str2).split(str)[1]);
                timePickerDialog = new TimePickerDialog(this, this.myTimeListener, this.mStartHour, this.mStartMinute, true);
                changeTimeDialogButtonsColor(timePickerDialog);
                timePickerDialog.show();
                return;
            default:
                return;
        }
    }

    private void changeTimeDialogButtonsColor(final TimePickerDialog timePickerDialog)
    {
        timePickerDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                if (SettingsManager.isDarkMode().booleanValue()) {
                    timePickerDialog.getButton(-1).setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.color_white));
                    timePickerDialog.getButton(-2).setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.color_white));
                    return;
                }
                timePickerDialog.getButton(-1).setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.color_blue));
                timePickerDialog.getButton(-2).setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.color_cyan));
            }
        });
    }

    @SuppressLint("WrongConstant")
    private void changeAuthorVisibility() {
        this.txt_Author.setVisibility(0);
    }

    private FrameLayout adContainerView;
    private InterstitialAd interstitialAd;
    private int id;
    private AdView adView;
    private KProgressHUD hud;

    private void loadAd() {

        //AdaptiveBannerAd
        adContainerView = findViewById(R.id.ad_view_container);
        adView = new AdView(this);
        adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
        adContainerView.addView(adView);

        AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();

        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        String str = "1";
                        if (Pref.getValue(getApplicationContext(), Constants.IS_SLIDER_ON, str).equals(str)) {
                            RemindersUtils.setAlarmOnTime(getApplicationContext());
                        }
                        startActivity(new Intent(getApplicationContext(), QuotesHomeActivity.class));
                        finish();
                        break;

                    case 101:
                        startActivity(new Intent(getApplicationContext(), QuotesHomeActivity.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.e("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    private void requestNewInterstitial() {
        this.interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(OnBoardingRemindersActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }
}
