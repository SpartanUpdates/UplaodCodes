package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class SpecialSymbols2 implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟", "💯", "⚪", "⚫", "✪", "🔴", "🔵", "✅", "☑", "❌", "❎", "©", "®", "📶", "📳", "📴", "⭕"};
    }

    public String getName() {
        return "1️⃣2️⃣3️⃣";
    }

    public float getSizeFactorKeys() {
        return 0.95f;
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟", "💯", "⚪", "⚫", "✪", "🔴", "🔵", "✅", "☑", "❌", "❎", "©", "®", "📶", "📳", "📴", "⭕"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
