package com.kotlinz.videostatusmaker.Others.gallery;

import java.util.*;

public class ImageData
{
  ArrayList<String> al_imagepath;
  String str_folder;

  public ArrayList<String> getAl_imagepath() {
    return this.al_imagepath;
  }

  public String getStr_folder() {
    return this.str_folder;
  }

  public void setAl_imagepath(final ArrayList<String> al_imagepath) {
    this.al_imagepath = al_imagepath;
  }

  public void setStr_folder(final String str_folder) {
    this.str_folder = str_folder;
  }
}
