package com.xyz.vehiclemanager.famousperson.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.famousperson.adapter.famousListAdapter;
import com.xyz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity;
import com.xyz.vehiclemanager.utils.Utils;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class FamousPersonListActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = FamousPersonListActivity.this;
    private RecyclerView rv_trending;
    private ImageView iv_back;
    private TextView tv_tile;
    private String catName;
    private famousListAdapter trendingListAdapter;
    private String Input1;
    private String Input2;
    private String Input3;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_celebrity_list);

        catName = getIntent().getStringExtra("categoryname");

        BindView();
        PutAnalyticsEvent();
        BannerAds();
        tv_tile.setText(this.catName);
        SetData();
    }

    private void BindView() {
        iv_back = findViewById(R.id.iv_back);
        tv_tile = findViewById(R.id.tv_title);
        rv_trending = findViewById(R.id.rv_trending);

        iv_back.setOnClickListener(this);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "FamousPersonListActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void SetData() {
        if (catName.equals("Mr.Perfect")) {
            tv_tile.setText("Mr.Perfect");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new famousListAdapter(this, Utils.mrperfectsnum, Utils.mrperfectsname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.mrperfectsnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Dancers")) {
            tv_tile.setText("Dancers");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            trendingListAdapter = new famousListAdapter(this, Utils.dancersnum, Utils.dancersname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.dancersnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Singers")) {
            tv_tile.setText("Singers");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            trendingListAdapter = new famousListAdapter(this, Utils.singersnum, Utils.singersname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.singersnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Actors")) {
            tv_tile.setText("Actors");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            trendingListAdapter = new famousListAdapter(this, Utils.actorsnum, Utils.actorsname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.actorsnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Politicians")) {
            tv_tile.setText("Politicians");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new famousListAdapter(this, Utils.politiciansnum, Utils.politiciansname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.politiciansnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Sports Person")) {
            tv_tile.setText("Sports Person");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new famousListAdapter(this, Utils.sportspersonsnum, Utils.sportspersonsname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.sportspersonsnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Actresses")) {
            tv_tile.setText("Actresses");
            rv_trending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new famousListAdapter(this, Utils.actressesnum, Utils.actressesname, new famousListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    substring(Utils.actressesnum[i]);
                }
            });
            rv_trending.setAdapter(this.trendingListAdapter);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }

    public void substring(String str) {
        String substring;
        if (Character.isDigit(str.charAt(4))) {
            substring = str.substring(0, 4);
            str = str.substring(4);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = "";
        } else if (Character.isDigit(str.charAt(5))) {
            substring = str.substring(0, 5);
            str = str.substring(5);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = substring.substring(4, 5);
        } else if (Character.isDigit(str.charAt(6))) {
            substring = str.substring(0, 6);
            str = str.substring(6);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = substring.substring(4, 6);
        } else {
            substring = str.substring(0, 7);
            str = str.substring(7);
        }

        Intent intent = new Intent(this, RtoOwnerDetailActivity.class);
        intent.putExtra("first", Input1);
        intent.putExtra("second", Input2);
        intent.putExtra("third", Input3);
        intent.putExtra("fourth", str);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}