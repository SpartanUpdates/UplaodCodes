package com.kotlinz.festivalstorymaker.Model;

import java.util.ArrayList;
import com.google.gson.annotations.SerializedName;


public class PosterCategoryResponse {

    @SerializedName("current_page_number")
    private String mCurrentPageNumber;
    @SerializedName("data")
    private ArrayList<PosterCategoryData> mData;
    @SerializedName("total_pages")
    private String mTotalPages;
    @SerializedName("total_records")
    private String mTotalRecords;

    public String getCurrentPageNumber() {
        return mCurrentPageNumber;
    }

    public void setCurrentPageNumber(String currentPageNumber) {
        mCurrentPageNumber = currentPageNumber;
    }

    public ArrayList<PosterCategoryData> getData() {
        return mData;
    }

    public void setData(ArrayList<PosterCategoryData> data) {
        mData = data;
    }

    public String getTotalPages() {
        return mTotalPages;
    }

    public void setTotalPages(String totalPages) {
        mTotalPages = totalPages;
    }

    public String getTotalRecords() {
        return mTotalRecords;
    }

    public void setTotalRecords(String totalRecords) {
        mTotalRecords = totalRecords;
    }

}
