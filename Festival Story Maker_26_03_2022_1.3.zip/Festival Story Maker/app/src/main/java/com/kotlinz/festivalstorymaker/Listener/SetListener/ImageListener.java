package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;

public class ImageListener implements View.OnClickListener {
    public final int e;
    public final ImageView imageView;
    public final com.kotlinz.festivalstorymaker.Models.g g;
    public final CanvasEditorActivity activity;

    public ImageListener(final CanvasEditorActivity activity, final int e, final ImageView imageView, final com.kotlinz.festivalstorymaker.Models.g g) {
        this.activity = activity;
        this.e = e;
        this.imageView = imageView;
        this.g = g;
    }

    public void onClick(final View view) {
        activity.w0();
        final CanvasEditorActivity h = activity;
        if (!h.m1) {
            h.H0 = e;
            final ImageView y1 = CanvasEditorActivity.y1;
            if (y1 != null) {
                y1.setOnTouchListener((View.OnTouchListener) null);
                CanvasEditorActivity.y1.setBackground((Drawable) null);
            }
            final TextView z1 = CanvasEditorActivity.z1;
            if (z1 != null) {
                z1.setBackground((Drawable) null);
            }
            CanvasEditorActivity.I1 = (CanvasEditorActivity.y1 = imageView);
            CanvasEditorActivity.U1 = false;
            CanvasEditorActivity.V1 = false;
            CanvasEditorActivity.W1 = false;
            activity.J0(true);
            CanvasEditorActivity.P1 = false;
            if (this.g.C.equalsIgnoreCase("1")) {
                CanvasEditorActivity.Q1 = true;
                CanvasEditorActivity.S1 = false;
             /*   final CanvasEditorActivity.x x = new CanvasEditorActivity.x();
                x.p0(this.h.U(), x.B);*/
            }
        } else {
            h.m1 = false;
        }
    }
}
