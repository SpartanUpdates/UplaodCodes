package com.wavymusic.ShareVideo.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wavymusic.App.MyApplication;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.MyCreationVideo.activity.YourVideoActivity;
import com.wavymusic.R;
import com.wavymusic.VideoPlayer.activity.VideoPlayerActivity;
import java.io.File;
import java.text.DecimalFormat;

public class ShareActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = ShareActivity.this;
    TextView tvvideoName;
    TextView tvvideoSize;
    TextView tvVideoShareWhatsApp;
    TextView tvVideoShareFb;
    TextView tvVideoShareInsta;
    TextView tvVideoShareYoutube;
    TextView tvVideoShareMore;
    ImageView ivThumb;

    ImageView ivback, ivHome;
    String VideoSize;
    String VideoFormate = "";
    private String VideoUrl;
    public boolean IsFromAndroidlist;
    public int videoCurrentposition;

    private NativeBannerAd mNativeBannerAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
        videoCurrentposition = getIntent().getIntExtra("VideoPosition", 0);
        IsFromAndroidlist = getIntent().getBooleanExtra("IsVideoFromAndroidList", false);
        PutAnalyticsEvent();
        BindView();
        LoadNativeAds();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ShareActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BindView() {
        tvvideoName = findViewById(R.id.videoName);
        tvvideoSize = findViewById(R.id.videoSize);
        tvVideoShareWhatsApp = findViewById(R.id.ivVideoShareWhatsApp);
        tvVideoShareFb = findViewById(R.id.ivVideoShareFb);
        tvVideoShareInsta = findViewById(R.id.ivVideoShareInsta);
        tvVideoShareYoutube = findViewById(R.id.ivVideoShareYoutube);
        tvVideoShareMore = findViewById(R.id.ivVideoShareMore);
        ivThumb = findViewById(R.id.ivThumb);
        ivback = findViewById(R.id.ivBack);
        ivHome = findViewById(R.id.iv_home);
        Drawable drawable = ivHome.getDrawable();
        if (drawable instanceof Animatable) {
            ((Animatable) drawable).start();
        }
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivHome.setOnClickListener(this);

        try {
            String format;
            if (getIntent().getExtras() != null) {
                VideoUrl = getIntent().getStringExtra("VideoUrl");
            }
            String str2 = VideoUrl;
            MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
            mediaMetadataRetriever.setDataSource(this, Uri.fromFile(new File(str2)));
            long parseLong = Long.parseLong(mediaMetadataRetriever.extractMetadata(9));
            mediaMetadataRetriever.release();
            parseLong /= 1000;
            long j = parseLong % 60;
            long j2 = (parseLong / 60) % 60;
            if ((parseLong / 3600) % 24 > 0) {
                format = String.format("%02d:%02d:%02d", Long.valueOf((parseLong / 3600) % 24), Long.valueOf(j2), Long.valueOf(j));
            } else {
                format = String.format("%02d:%02d", Long.valueOf(j2), Long.valueOf(j));
            }
            VideoFormate = format;
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        tvvideoName.setText(MyApplication.getFileName(VideoUrl));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(VideoFormate);
        stringBuilder.append("(");
        long length = new File(VideoUrl).length();
        if (length <= 0) {
            VideoSize = "0";
        } else {
            String[] strArr = new String[]{"B", "KB", "MB", "GB", "TB"};
            double d = (double) length;
            int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(new DecimalFormat("#,##0.#").format(d / Math.pow(1024.0d, (double) log10)));
            stringBuilder2.append(" ");
            stringBuilder2.append(strArr[log10]);
            VideoSize = stringBuilder2.toString();
        }
        stringBuilder.append(VideoSize);
        stringBuilder.append(")");
        tvvideoSize.setText(stringBuilder.toString());
        Glide.with(activity).load(VideoUrl).into(ivThumb);
        this.tvVideoShareWhatsApp.setOnClickListener(this);
        tvVideoShareFb.setOnClickListener(this);
        tvVideoShareInsta.setOnClickListener(this);
        tvVideoShareYoutube.setOnClickListener(this);
        tvVideoShareMore.setOnClickListener(this);
        findViewById(R.id.llTopPanel).setOnClickListener(this);
    }


    private void LoadNativeAds(){
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(activity, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                FrameLayout nativeBannerAdContainer =findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();
    }


    @Override
    public void onClick(View view) {
        int id = view.getId();
        Intent intent;
        if (id == R.id.iv_home) {
            startActivity(new Intent(activity, DashbordActivity.class));
            finish();
        } else if (id != R.id.llTopPanel) {
            switch (id) {
                case R.id.ivVideoShareFb:
                    ShareVideoFile(getResources().getString(R.string.facebook_package), getResources().getString(R.string.facebook));
                    return;
                case R.id.ivVideoShareInsta:
                    ShareVideoFile(getResources().getString(R.string.instagram_package), getResources().getString(R.string.instagram));
                    return;
                case R.id.ivVideoShareMore:
                    final File file = new File(VideoUrl);
                    intent = new Intent("android.intent.action.SEND");
                    intent.setType("image/*");
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(getResources().getString(R.string.app_name));
                    stringBuilder.append(": ");
                    stringBuilder.append(getString(R.string.get_free));
                    stringBuilder.append(getString(R.string.app_name));
                    stringBuilder.append(" Music at here : https://play.google.com/store/apps/details?id=");
                    stringBuilder.append(getPackageName());
                    final Uri ShareUri = FileProvider.getUriForFile(activity, String.valueOf(activity.getPackageName()) + ".provider", file);
                    intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                    intent.putExtra("android.intent.extra.STREAM", ShareUri);
                    startActivity(Intent.createChooser(intent, getString(R.string.share_video)));
                    break;
                case R.id.ivVideoShareWhatsApp:
                    ShareVideoFile(getResources().getString(R.string.whatsapp_package), getResources().getString(R.string.whatsapp));
                    return;
                case R.id.ivVideoShareYoutube:
                    ShareVideoFile(getResources().getString(R.string.youtube_package), getResources().getString(R.string.youtube));
                    return;
            }
        } else {
            intent = new Intent(this, VideoPlayerActivity.class);
            intent.putExtra("VideoUrl", VideoUrl);
            intent.putExtra("VideoPosition", 0);
            intent.putExtra("IsVideoFromAndroidList", false);
            startActivity(intent);
            finish();
        }
    }

    private void ShareVideoFile(String str, String str2) {
        File file = new File(VideoUrl);
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/*");
        intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.app_name));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getString(R.string.get_free));
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" Music at here : https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        final Uri ShareUri = FileProvider.getUriForFile(activity, String.valueOf(activity.getPackageName()) + ".provider", file);
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        intent.putExtra("android.intent.extra.TITLE", "United Videos : Particle.ly Video Status Maker");
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (str != null) {
            if (getPackageInfo(str, activity)) {
                intent.setPackage(str);
            } else {
                Context applicationContext = getApplicationContext();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(getString(R.string.please_install));
                stringBuilder2.append(str2);
                Toast.makeText(applicationContext, stringBuilder2.toString(), Toast.LENGTH_LONG).show();
                return;
            }
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_video)));
    }


    private static boolean getPackageInfo(String str, Context context) {
        try {
            context.getPackageManager().getPackageInfo(str, PackageManager.GET_META_DATA);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    public void onBackPressed() {
        if (!IsFromAndroidlist) {
            Intent intent = new Intent(this, YourVideoActivity.class);
            startActivity(intent);
            finish();
        }
        finish();
    }
}