//package com.Pulse.VideoStatus.View;
//
//import android.app.Activity;
//import android.content.Context;
//import android.support.v7.widget.DefaultItemAnimator;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.util.AttributeSet;
//import android.util.DisplayMetrics;
//import android.view.Display;
//import android.view.View;
//import android.view.animation.Animation;
//import android.view.animation.AnimationUtils;
//import android.view.animation.LinearInterpolator;
//import android.widget.FrameLayout;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.RelativeLayout;
//import android.widget.TextView;
//import com.Pulse.VideoStatus.Activity.ImageSelectActivity;
//import com.Pulse.VideoStatus.Adapter.SelectedImageAdapter;
//import com.Pulse.VideoStatus.Interface.OnItemClickListner;
//import com.Pulse.VideoStatus.R;
//import com.Pulse.VideoStatus.application.MyApplication;
//
//
//public class ExpandableView extends RelativeLayout implements OnItemClickListner {
//    public LinearLayout llPoplayout;
//    public LinearLayout llitemlayout;
//    public TextView tvNoImage;
//    public  static TextView tvNoOfImageCount;
//    public RecyclerView rvSelectedImage;
//    public RelativeLayout rldrawerlayout;
//    public ImageView ivStateInfo;
//    public int ImageHeight;
//    public int ImageWidth;
//    public Context context;
//    public int l;
//    public SelectedImageAdapter selectedImageAdapter;
//    public boolean n = false;
//    public MyApplication application;
//
//    public ExpandableView(Context context) {
//        super(context);
//        this.context = context;
//        BindView();
//    }
//
//    public ExpandableView(Context context, AttributeSet attributeSet) {
//        super(context, attributeSet);
//        this.context = context;
//        BindView();
//    }
//
//    public ExpandableView(Context context, AttributeSet attributeSet, int i) {
//        super(context, attributeSet, i);
//        this.context = context;
//        BindView();
//    }
//
//    public static DisplayMetrics a(Activity activity) {
//        Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
//        DisplayMetrics displayMetrics = new DisplayMetrics();
//        try {
//            Class.forName("android.view.Display").getMethod("getRealMetrics", new Class[]{DisplayMetrics.class}).invoke(defaultDisplay, displayMetrics);
//            return displayMetrics;
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
//
//    public void a() {
//        SetNoOfImageCount();
//        setImageState();
//        SetLayoutParams();
//        RecyclerView recyclerView = this.rvSelectedImage;
//        recyclerView.scrollToPosition(MyApplication.selectedImageslist.size() - 1);
//    }
//
//    public void ZoomImage(boolean z) {
//        Animation loadAnimation;
//        Animation.AnimationListener eVar;
//        if (z) {
//            loadAnimation = AnimationUtils.loadAnimation(this.context, R.anim.pop_left_out);
//            loadAnimation.setInterpolator(new LinearInterpolator());
//            eVar = new PopleftoutAnimation(this);
//        } else {
//            MyApplication myApplication = this.application;
//            if (MyApplication.selectedImageslist.size() <= 0) {
//                this.rvSelectedImage.setVisibility(View.GONE);
//                this.tvNoImage.setVisibility(View.VISIBLE);
//            } else {
//                this.rvSelectedImage.setVisibility(View.VISIBLE);
//                this.tvNoImage.setVisibility(View.GONE);
//            }
//            loadAnimation = AnimationUtils.loadAnimation(this.context, R.anim.pop_left_in);
//            loadAnimation.setInterpolator(new LinearInterpolator());
//            eVar = new PopleftInAnimation(this);
//        }
//        loadAnimation.setAnimationListener(eVar);
//        this.llitemlayout.startAnimation(loadAnimation);
//    }
//
//    public void b() {
//        SetNoOfImageCount();
//        SetLayoutParams();
//    }
//
//    public final void setImageState() {
//        if (this.n) {
//            this.ivStateInfo.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.zoom_in));
//        } else {
//            this.tvNoOfImageCount.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.zoom_in));
//        }
//    }
//
//    public final void BindView() {
//        this.application = MyApplication.e();
//        this.ImageHeight = (int) this.context.getResources().getDimension(R.dimen.photo_select_height);
//        this.ImageWidth = (int) this.context.getResources().getDimension(R.dimen.photo_draw_width);
//        DisplayMetrics a = a((Activity) this.context);
//        if (a != null) {
//            this.l = ((a.widthPixels * 2) / 3) - this.ImageWidth;
//        }
//        View inflate = RelativeLayout.inflate(getContext(), R.layout.popup_window_select, this);
//        this.llPoplayout = inflate.findViewById(R.id.popup_layout);
//        this.llitemlayout = inflate.findViewById(R.id.items_layout);
//        this.tvNoImage = inflate.findViewById(R.id.no_resource);
//        this.tvNoOfImageCount = inflate.findViewById(R.id.text_count);
//        this.rvSelectedImage = inflate.findViewById(R.id.recycler_select);
//        this.rldrawerlayout = inflate.findViewById(R.id.drawer_layout);
//        this.ivStateInfo = inflate.findViewById(R.id.image_state);
//        FrameLayout.LayoutParams layoutParams = ( FrameLayout.LayoutParams) this.rvSelectedImage.getLayoutParams();
//        layoutParams.width = this.ImageHeight * 3;
//        this.tvNoImage.setLayoutParams(layoutParams);
//        this.selectedImageAdapter = new SelectedImageAdapter(this.context);
//        RecyclerView.LayoutManager linearLayoutManager = new LinearLayoutManager(this.context);
//        ((LinearLayoutManager) linearLayoutManager).setOrientation(0);
//        ((LinearLayoutManager)linearLayoutManager).setStackFromEnd(true);
//        this.rvSelectedImage.setLayoutManager(linearLayoutManager);
//        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
//        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
//        selectedImageAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
//            @Override
//            public void onItemClick(final View view, final Object item) {
//                if (MyApplication.TotalSelectedImage >= 50) {
//                    tvNoOfImageCount.setText(String.valueOf(application.getSelectedImageslist().size()));
//                } else {
//                    tvNoOfImageCount.setText(String.valueOf(String.valueOf(application.getSelectedImageslist().size())) + "/" + MyApplication.TotalSelectedImage);
//                }
//                ImageSelectActivity.albumWiseImageAdapter.notifyDataSetChanged();
//            }
//        });
//        SetSelectedImage();
//        SetLayoutParams();
//        this.rldrawerlayout.setOnClickListener(new ExpandableClick(this));
//
//    }
//
//    public final void SetNoOfImageCount() {
//        if (!this.n) {
//            MyApplication myApplication = this.application;
//            if (MyApplication.selectedImageslist.size() != 0) {
//                StringBuilder stringBuilder;
//                if (MyApplication.TotalSelectedImage == 50) {
//                    stringBuilder = new StringBuilder();
//                    stringBuilder.append(MyApplication.selectedImageslist.size());
//                } else {
//                    stringBuilder = new StringBuilder();
//                    stringBuilder.append(MyApplication.selectedImageslist.size());
//                    stringBuilder.append("/");
//                    stringBuilder.append(MyApplication.TotalSelectedImage);
//                }
//
//                tvNoOfImageCount.setText(stringBuilder.toString());
//                this.ivStateInfo.setVisibility(GONE);
//                this.tvNoOfImageCount.setVisibility(VISIBLE);
//                return;
//            }
//        }
//        this.ivStateInfo.setVisibility(VISIBLE);
//        this.tvNoOfImageCount.setVisibility(GONE);
//
//    }
//
//
//    public void SetSelectedImage() {
//        ImageView imageView;
//        MyApplication myApplication = this.application;
//        int size = MyApplication.selectedImageslist.size();
//        int i = R.drawable.album_box_state_close_normal;
//        if (size <= 0) {
//            this.tvNoOfImageCount.setVisibility(GONE);
//            this.ivStateInfo.setVisibility(VISIBLE);
//            if (!this.n) {
//                imageView = this.ivStateInfo;
//                i = R.drawable.album_box_state_normal;
//                imageView.setImageResource(i);
//            }
//        }
//        boolean z = this.n;
//        String str = "";
//        String str2 = "/";
//        if (z) {
//            CharSequence stringBuilder;
//            if (MyApplication.TotalSelectedImage == 50) {
//                StringBuilder stringBuilder2 = new StringBuilder();
//                stringBuilder2.append(MyApplication.selectedImageslist.size());
//                stringBuilder2.append(str);
//                stringBuilder = stringBuilder2.toString();
//            } else {
//
//                StringBuilder stringBuilder3 = new StringBuilder();
//                stringBuilder3.append(MyApplication.selectedImageslist.size());
//                stringBuilder3.append(str2);
//                stringBuilder3.append(MyApplication.TotalSelectedImage);
//                stringBuilder = stringBuilder3.toString();
//            }
//            tvNoOfImageCount.setText(stringBuilder);
//            this.tvNoOfImageCount.setVisibility(GONE);
//            this.ivStateInfo.setVisibility(VISIBLE);
//        } else {
//            StringBuilder stringBuilder4;
//            if (MyApplication.TotalSelectedImage == 50) {
//                stringBuilder4 = new StringBuilder();
//                stringBuilder4.append(MyApplication.selectedImageslist.size());
//                stringBuilder4.append(str);
//            } else {
//                stringBuilder4 = new StringBuilder();
//                stringBuilder4.append(MyApplication.selectedImageslist.size());
//                stringBuilder4.append(str2);
//                stringBuilder4.append(MyApplication.TotalSelectedImage);
//            }
//            tvNoOfImageCount.setText(stringBuilder4.toString());
//            this.tvNoOfImageCount.setVisibility(VISIBLE);
//            this.ivStateInfo.setVisibility(INVISIBLE);
//            return;
//        }
//        imageView = this.ivStateInfo;
//        imageView.setImageResource(i);
//    }
//
//
//    public void SetLayoutParams() {
//        MyApplication myApplication = this.application;
//        FrameLayout.LayoutParams layoutParams;
//        if (MyApplication.selectedImageslist.size() == 0) {
//            layoutParams = (FrameLayout.LayoutParams) this.rvSelectedImage.getLayoutParams();
//            if (layoutParams != null) {
//                layoutParams.width = this.ImageHeight * 3;
//                this.rvSelectedImage.setLayoutParams(layoutParams);
//            }
//            if (this.n) {
//                this.tvNoImage.setVisibility(View.VISIBLE);
//                this.rvSelectedImage.setVisibility(View.GONE);
//                return;
//            }
//            return;
//        }
//        if (this.n) {
//            this.tvNoImage.setVisibility(View.GONE);
//            this.rvSelectedImage.setVisibility(View.VISIBLE);
//        }
//        layoutParams = (FrameLayout.LayoutParams) this.rvSelectedImage.getLayoutParams();
//        int i = this.l;
//        MyApplication myApplication2 = this.application;
//        if (i <= MyApplication.selectedImageslist.size() * this.ImageHeight) {
//            if (layoutParams != null) {
//                i = this.l;
//            } else {
//                return;
//            }
//        } else if (layoutParams != null) {
//            i = -2;
//        } else {
//            return;
//        }
//        layoutParams.width = i;
//        this.rvSelectedImage.setLayoutParams(layoutParams);
//    }
//
//    public View getImageView() {
//        return this.ivStateInfo;
//    }
//
//    public OnItemClickListner getListener() {
//        return this;
//    }
//
//    @Override
//    public void onItemClick(View paramView, Object paramT) {
//
//    }
//}
