package com.vidsoft.videostatusmaker.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.viewpager.widget.PagerAdapter;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;

import com.vidsoft.videostatusmaker.Activity.ActivityViewAlImages;
import com.vidsoft.videostatusmaker.Activity.MainActivity;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.vidsoft.videostatusmaker.Utils.RoundedImageView;

public class PreviewImagePagerAdapter extends PagerAdapter {
    ArrayList<String> stringArrayList;
    LayoutInflater layoutInflater;
    Context context;

    public PreviewImagePagerAdapter(final Context context, final ArrayList<String> stringArrayList) {
        this.context = context;
        this.stringArrayList = stringArrayList;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public static Bitmap blur(final Context context, Bitmap bitmap) {
        final Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * 0.3f), Math.round(bitmap.getHeight() * 0.3f), false);
        bitmap = Bitmap.createBitmap(scaledBitmap);
        final RenderScript create = RenderScript.create(context);
        final ScriptIntrinsicBlur create2 = ScriptIntrinsicBlur.create(create, Element.U8_4(create));
        final Allocation fromBitmap = Allocation.createFromBitmap(create, scaledBitmap);
        final Allocation fromBitmap2 = Allocation.createFromBitmap(create, bitmap);
        create2.setRadius(7.5f);
        create2.setInput(fromBitmap);
        create2.forEach(fromBitmap2);
        fromBitmap2.copyTo(bitmap);
        return bitmap;
    }

    @Override
    public void destroyItem(final ViewGroup viewGroup, final int n, final Object o) {
        viewGroup.removeView((View) o);
    }

    @Override
    public int getCount() {
        return this.stringArrayList.size();
    }

    @Override
    public Object instantiateItem(final ViewGroup viewGroup, int n) {
        final View inflate = this.layoutInflater.inflate(R.layout.page_adapter, viewGroup, false);
        final RoundedImageView roundedImageView = (RoundedImageView) inflate.findViewById(R.id.imageView);
        final RoundedImageView roundedImageView2 = (RoundedImageView) inflate.findViewById(R.id.bg_imageView);
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.edit);
        final ImageView imageView2 = (ImageView) inflate.findViewById(R.id.bg_img);
        final String s = this.stringArrayList.get(n);
        final int widthPixels = this.context.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.context.getResources().getDisplayMetrics().heightPixels;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 126 / 1080, heightPixels * 126 / 1920);
        layoutParams.addRule(11);
        n = widthPixels * 40 / 1080;
        final int n2 = widthPixels * 75 / 1080;
        layoutParams.setMargins(n, n2, n, n2);
        imageView.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
        final DisplayImageOptions build = new DisplayImageOptions.Builder().build();
        final ImageLoader instance = ImageLoader.getInstance();
        final StringBuilder sb = new StringBuilder();
        sb.append("file:///");
        sb.append(s);
        instance.displayImage(sb.toString(), roundedImageView, build);
        if (MainActivity.anInt == 1) {
            final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams(widthPixels * 660 / 1080, heightPixels * 1025 / 1920);
            relativeLayout$LayoutParams.addRule(13);
            roundedImageView.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams);
            roundedImageView2.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams);
            final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(widthPixels * 751 / 1080, heightPixels * 1081 / 1920);
            layoutParams2.addRule(13);
            imageView2.setLayoutParams((ViewGroup.LayoutParams) layoutParams2);
            imageView.setVisibility(View.GONE);
            roundedImageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView2.setScaleType(ImageView.ScaleType.FIT_XY);
            imageView2.setImageResource(R.drawable.fullscreen_bg);
            try {
                roundedImageView2.setImageBitmap(blur(this.context, BitmapFactory.decodeFile(s)));
            } catch (Exception ex) {
                ex.toString();
            }
            roundedImageView2.setCornerRadius(n);
        } else {
            final int n3 = widthPixels * 655 / 1080;
            final RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(n3, n3);
            layoutParams3.addRule(13);
            roundedImageView.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
            final int n4 = widthPixels * 751 / 1080;
            final RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(n4, n4);
            layoutParams4.addRule(13);
            imageView2.setLayoutParams((ViewGroup.LayoutParams) layoutParams4);
            imageView.setVisibility(View.VISIBLE);
            roundedImageView.setCornerRadius(n);
        }
        imageView.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ((ActivityViewAlImages) PreviewImagePagerAdapter.this.context).click_edit();
            }
        });
        viewGroup.addView(inflate);
        return inflate;
    }

    @Override
    public boolean isViewFromObject(final View view, final Object o) {
        return view == o;
    }
}
