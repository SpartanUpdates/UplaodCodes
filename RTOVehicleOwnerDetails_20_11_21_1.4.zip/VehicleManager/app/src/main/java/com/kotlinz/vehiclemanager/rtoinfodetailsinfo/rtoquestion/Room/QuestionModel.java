package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.Room;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class QuestionModel {

    @PrimaryKey(autoGenerate = true)
    public int questionNo;
    public String question;
    public String optionA;
    public String optionB;
    public String optionC;
    public String answer;

    public QuestionModel(String question, String optionA, String optionB, String optionC, String answer) {
        this.question = question;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.answer = answer;
    }

    public int getQuestionNo() {
        return questionNo;
    }

    public String getQuestion() {
        return question;
    }

    public String getOptionA() {
        return optionA;
    }

    public String getOptionB() {
        return optionB;
    }

    public String getOptionC() {
        return optionC;
    }

    public String getAnswer() {
        return answer;
    }
}
