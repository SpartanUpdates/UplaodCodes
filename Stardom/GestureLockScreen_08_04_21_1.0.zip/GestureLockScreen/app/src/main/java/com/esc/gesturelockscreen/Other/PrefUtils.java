package com.esc.gesturelockscreen.Other;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

public class PrefUtils {
    public static final String PRF_BACKGROUND_IMG_POSITION = "prf_background_img_position";
    public static final String PRF_IS_SET_BACKGROUND = "prf_is_set_background";
    public static final String PRF_IS_SET_BGCOLOR = "prf_is_set_bgcolor";
    public static final String PRF_IS_SET_GALLERY = "prf_is_set_gallery";
    public static final String PRF_IS_SET_LOCK = "prf_is_set_lock";
    public static final String PRF_SELECTED_GALLERY_IMG_URI = "prf_selected_gallery_img_uri";
    public static final String PRF_SET_FRAME_BLUR_RADIUS = "prf_set_frame_blur_radius";

    public static void setStringPref(Context context, String str, String str2) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
        edit.putString(str, str2);
        edit.apply();
    }

    public static String getStringPref(Context context, String str, String str2) {
        return PreferenceManager.getDefaultSharedPreferences(context).getString(str, str2);
    }

    public static void setIntPref(Context context, String str, int i) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
        edit.putInt(str, i);
        edit.apply();
    }

    public static int getIntPref(Context context, String str, int i) {
        return PreferenceManager.getDefaultSharedPreferences(context).getInt(str, i);
    }

    public static void setBooleanPref(Context context, String str, boolean z) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
        edit.putBoolean(str, z);
        edit.apply();
    }

    public static boolean getBooleanPref(Context context, String str, boolean z) {
        return PreferenceManager.getDefaultSharedPreferences(context).getBoolean(str, z);
    }
}
