package com.xyz.vehiclemanager.cardetails.carservice.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class CarServiceRoot {
    @SerializedName("statusMessage")
    public String statusMessage;
    @SerializedName("data")
   public ArrayList<ServiceCenterDetail> data = null;

    public ArrayList<ServiceCenterDetail> getData() {
        return data;
    }

    public void setData(ArrayList<ServiceCenterDetail> data) {
        this.data = data;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }
}
