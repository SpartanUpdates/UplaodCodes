package com.wavymusic.Model;

public class ParticalCategoryModel {

    private String CatId;
    private String CatName;
//    public boolean IsAssetCatSelected=false;

//    public ParticalCategoryModel(String catId, String catName) {
//        CatId = catId;
//        CatName = catName;
//    }

    public String getCatId() {
        return CatId;
    }

    public void setCatId(String catId) {
        CatId = catId;
    }

    public String getCatName() {
        return CatName;
    }

    public void setCatName(String catName) {
        CatName = catName;
    }
}
