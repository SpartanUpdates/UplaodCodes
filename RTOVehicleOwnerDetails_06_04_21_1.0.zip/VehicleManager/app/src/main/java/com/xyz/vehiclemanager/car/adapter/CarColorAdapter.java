package com.xyz.vehiclemanager.car.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.car.model.CarDetailsRoot;

import java.util.ArrayList;

public class CarColorAdapter extends RecyclerView.Adapter<CarColorAdapter.ViewHolder> {
    Context context;
    ArrayList<CarDetailsRoot.Details.Color> carColorlist;

    public CarColorAdapter(Context context, ArrayList<CarDetailsRoot.Details.Color> carColorlist) {
        this.context = context;
        this.carColorlist = carColorlist;
    }
    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView colorName;
        ImageView bgColor;
        ImageView iv_smallbgcolor;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            colorName=itemView.findViewById(R.id.colorName);
            bgColor=itemView.findViewById(R.id.bgColor);
            iv_smallbgcolor = itemView.findViewById(R.id.iv_smallbgcolor);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.layout_color, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CarDetailsRoot.Details.Color carColor = carColorlist.get(position);
        holder.colorName.setText(carColor.getColorName());
        String str = "#";
        String str2 = "/";
        StringBuilder stringBuilder;

        if (carColor.getBackgroundName().contains(str2)){

            holder.bgColor.setVisibility(View.VISIBLE);
            holder.iv_smallbgcolor.setVisibility(View.VISIBLE);
            String[] split = carColor.getBackgroundName().split(str2);
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(split[0].trim());
            holder.bgColor.setBackgroundColor(Color.parseColor(stringBuilder.toString()));

            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(split[1].trim());
            holder.iv_smallbgcolor.setBackgroundColor(Color.parseColor(stringBuilder.toString()));
        }else {
            holder.bgColor.setVisibility(View.VISIBLE);
            holder.iv_smallbgcolor.setVisibility(View.GONE);
            holder.bgColor.getLayoutParams().height=60;
            holder.bgColor.getLayoutParams().width=60;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(carColor.getBackgroundName());
            holder.bgColor.setBackgroundColor(Color.parseColor(stringBuilder.toString()));
        }
    }
    @Override
    public int getItemCount() {
        return carColorlist.size();
    }
}
