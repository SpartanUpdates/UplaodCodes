package com.esc.palmreadingfuture.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.esc.palmreadingfuture.database.DataBaseHelper;
import com.esc.palmreadingfuture.R;
import com.esc.palmreadingfuture.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

public class LineQuestions extends AppCompatActivity {
    private Activity activity = LineQuestions.this;
    static Editor editor = null;
    static SharedPreferences sharedPreferences = null;
    public static String trans;
    private ArrayList<String> alopt;
    private ArrayList<String> aloptno;
    private ArrayList<String> alques;
    private ArrayList<String> alquesNo;
    private DataBaseHelper baseHelper;
    private int cid;
    private String endresult;
    private int i = 0;
    private String imgans;
    private String line;
    private String line_eng;
    private TextView txt_yes;
    private TextView txt_no;
    private TextView optc;
    private String optiona;
    private String optionb;
    private String optionc;
    private int pos;
    private TextView ques;
    private int queslength = 0;
    private String question;
    private int resid;
    private int resoid;
    private int scid;
    private TextView txt_title;
    private ImageView iv_back;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int Adid;

    OnClickListener listenanswer = new OnClickListener() {
        public void onClick(View view) {
            int id = view.getId();
            int parseInt = LineQuestions.this.i < LineQuestions.this.queslength ? Integer.parseInt((String) LineQuestions.this.alquesNo.get(LineQuestions.this.i)) : -1;
            String str = "en";
            String str2 = "hi";
            String str3 = "zh";
            String str4 = "it";
            String str5 = "fr";
            String str6 = "de";
            String str7 = "iw";
            String str8 = "ms";
            String str9 = "pl";
            String str10 = "ru";
            String str11 = "sk";
            String str12 = "th";
            String str13 = "es";
            String str14 = "da";
            String str15 = "pt";
            String str16 = "ko";
            String str17 = "in";
            String str18 = "el";
            String str19 = "";
            String str20 = "tr";
            String str21 = "aloptno ";
            String str22;
            LineQuestions lineQuestions;
            StringBuilder stringBuilder;
            StringBuilder stringBuilder2;
            if (id != R.id.txt_yes || parseInt == -1) {
                String str23 = str7;
                String str24 = str9;
                String str25 = str11;
                String str26 = str13;
                String str27 = str15;
                String str28 = str17;
                String str29 = str21;
                String str30 = str;
                if (id != R.id.txt_no || parseInt == -1) {
                    str21 = str29;
                    str = str30;
                    str7 = str23;
                    str9 = str24;
                    str11 = str25;
                    str13 = str26;
                    str15 = str27;
                    str17 = str28;
                    if (id == R.id.optct && parseInt != -1) {
                        id = Integer.parseInt((String) LineQuestions.this.aloptno.get(2));
                        if (LineQuestions.trans.contains(str18) || LineQuestions.trans.contains(str16) || LineQuestions.trans.contains(str14) || LineQuestions.trans.contains(str12) || LineQuestions.trans.contains(str10) || LineQuestions.trans.contains(str8) || LineQuestions.trans.contains(str6) || LineQuestions.trans.contains(str5) || LineQuestions.trans.contains(str4) || LineQuestions.trans.contains(str3) || LineQuestions.trans.contains(str2) || LineQuestions.trans.contains(str) || LineQuestions.trans.contains(str20) || LineQuestions.trans.contains(str17) || LineQuestions.trans.contains(str15) || LineQuestions.trans.contains(str13) || LineQuestions.trans.contains(str11) || LineQuestions.trans.contains(str9) || LineQuestions.trans.contains(str7) || LineQuestions.trans.contains("zu") || LineQuestions.trans.contains("ro") || LineQuestions.trans.contains("af")) {
                            str19 = LineQuestions.this.baseHelper.getAns(parseInt, id, LineQuestions.this.scid, LineQuestions.this.pos, LineQuestions.this.cid);
                        }
                        str22 = str19;
                        lineQuestions = LineQuestions.this;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(LineQuestions.this.endresult);
                        stringBuilder.append(str22);
                        lineQuestions.endresult = stringBuilder.toString();
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(str21);
                        stringBuilder2.append(LineQuestions.this.endresult);
                        Log.e("XXXX  ", stringBuilder2.toString());
                    }
                } else {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str29);
                    stringBuilder2.append(LineQuestions.this.aloptno);
                    Log.e("AAAA  ", stringBuilder2.toString());
                    id = Integer.parseInt((String) LineQuestions.this.aloptno.get(1));
                    if (LineQuestions.trans.contains(str18) || LineQuestions.trans.contains(str16) || LineQuestions.trans.contains(str14) || LineQuestions.trans.contains(str12) || LineQuestions.trans.contains(str10) || LineQuestions.trans.contains(str8) || LineQuestions.trans.contains(str6) || LineQuestions.trans.contains(str5) || LineQuestions.trans.contains(str4) || LineQuestions.trans.contains(str3) || LineQuestions.trans.contains(str2) || LineQuestions.trans.contains(str30) || LineQuestions.trans.contains(str20) || LineQuestions.trans.contains(str28) || LineQuestions.trans.contains(str27) || LineQuestions.trans.contains(str26) || LineQuestions.trans.contains(str25) || LineQuestions.trans.contains(str24) || LineQuestions.trans.contains(str23) || LineQuestions.trans.contains("zu") || LineQuestions.trans.contains("ro") || LineQuestions.trans.contains("af")) {
                        str19 = LineQuestions.this.baseHelper.getAns(parseInt, id, LineQuestions.this.scid, LineQuestions.this.pos, LineQuestions.this.cid);
                    }
                    str22 = str19;
                    lineQuestions = LineQuestions.this;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(LineQuestions.this.endresult);
                    stringBuilder.append(str22);
                    lineQuestions.endresult = stringBuilder.toString();
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str29);
                    stringBuilder2.append(LineQuestions.this.endresult);
                    Log.e("UUUU  ", stringBuilder2.toString());
                }
            } else {
                id = Integer.parseInt((String) LineQuestions.this.aloptno.get(0));
                if (LineQuestions.trans.contains(str18) || LineQuestions.trans.contains(str16) || LineQuestions.trans.contains(str14) || LineQuestions.trans.contains(str12) || LineQuestions.trans.contains(str10) || LineQuestions.trans.contains(str8) || LineQuestions.trans.contains(str6) || LineQuestions.trans.contains(str5) || LineQuestions.trans.contains(str4) || LineQuestions.trans.contains(str3) || LineQuestions.trans.contains(str2) || LineQuestions.trans.contains(str) || LineQuestions.trans.contains(str20) || LineQuestions.trans.contains(str17) || LineQuestions.trans.contains(str15) || LineQuestions.trans.contains(str13) || LineQuestions.trans.contains(str11) || LineQuestions.trans.contains(str9) || LineQuestions.trans.contains(str7) || LineQuestions.trans.contains("zu") || LineQuestions.trans.contains("ro") || LineQuestions.trans.contains("af")) {
                    str19 = LineQuestions.this.baseHelper.getAns(parseInt, id, LineQuestions.this.scid, LineQuestions.this.pos, LineQuestions.this.cid);
                }
                str22 = str19;
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("KKKK888  ");
                stringBuilder3.append(str22);
                str6 = stringBuilder3.toString();
                stringBuilder = new StringBuilder();
                str5 = str21;
                stringBuilder.append(str5);
                stringBuilder.append(LineQuestions.this.endresult);
                Log.e(str6, stringBuilder.toString());
                lineQuestions = LineQuestions.this;
                stringBuilder = new StringBuilder();
                stringBuilder.append(LineQuestions.this.endresult);
                stringBuilder.append(str22);
                lineQuestions.endresult = stringBuilder.toString();
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str5);
                stringBuilder2.append(LineQuestions.this.endresult);
                Log.e("KKKK  ", stringBuilder2.toString());
            }
            LineQuestions lineQuestions2 = LineQuestions.this;
            lineQuestions2.i++;
            if (LineQuestions.this.i < LineQuestions.this.queslength) {
                LineQuestions.this.getques();
                return;
            }
            Intent intent = new Intent(LineQuestions.this, ShowResult.class);
            Bundle bundle = new Bundle();
            bundle.putString("finalresult", LineQuestions.this.endresult);
            bundle.putString("line", LineQuestions.this.line);
            bundle.putString("line_eng", LineQuestions.this.line_eng);
            bundle.putInt("resid", LineQuestions.this.resoid);
            intent.putExtras(bundle);
            LineQuestions.this.startActivityForResult(intent, 0);
            LineQuestions.this.finish();
        }
    };

    public LineQuestions() {
        String str = "";
        this.line = str;
        this.line_eng = str;
        this.endresult = str;
        this.question = str;
        this.optiona = str;
        this.optionb = str;
        this.optionc = str;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.line_questions);
        final StringBuilder sb = new StringBuilder();
        sb.append("oncreate control ");
        sb.append(LineQuestions.trans);
        sb.append(" current trans ");
        sb.append(Locale.getDefault().getLanguage());
        sb.append(" different ");
        sb.append(Locale.getDefault().getLanguage().equals(LineQuestions.trans));
        Log.e("jjjj", sb.toString());
        Log.e("activity", "line questions");
        LineQuestions.editor = (LineQuestions.sharedPreferences = this.getApplicationContext().getSharedPreferences("palmreading", 0)).edit();
        if (LineQuestions.sharedPreferences.getString("trans3", (String)null) != null && !LineQuestions.sharedPreferences.getString("trans3", (String)null).equals(Locale.getDefault().getLanguage())) {
            LineQuestions.editor.putString("trans3", (String)null);
            LineQuestions.editor.commit();
            this.finish();
            return;
        }
        LineQuestions.editor.putString("trans3", LineQuestions.trans = Locale.getDefault().getLanguage().toString());
        LineQuestions.editor.commit();
        bundle = this.getIntent().getExtras();
        this.line = bundle.getString("line");
        this.line_eng = bundle.getString("line_eng");
        this.pos = bundle.getInt("pos");
        this.cid = bundle.getInt("cid");
        this.scid = bundle.getInt("scid");
        this.resoid = bundle.getInt("resid");
        txt_title = findViewById(R.id.txt_title);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(this.line);
        txt_title.setText((CharSequence)sb2.toString());
        final DataBaseHelper baseHelper = new DataBaseHelper(this.getApplicationContext(), this.getResources().getString(R.string.db_name));
        this.baseHelper = baseHelper;
        try {
            baseHelper.createDataBase();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        this.alopt = new ArrayList<String>();
        this.aloptno = new ArrayList<String>();
        this.alques = new ArrayList<String>();
        this.alquesNo = new ArrayList<String>();
        if (LineQuestions.trans.contains("el") || LineQuestions.trans.contains("ko") || LineQuestions.trans.contains("da") || LineQuestions.trans.contains("th") || LineQuestions.trans.contains("ru") || LineQuestions.trans.contains("ms") || LineQuestions.trans.contains("de") || LineQuestions.trans.contains("fr") || LineQuestions.trans.contains("it") || LineQuestions.trans.contains("zh") || LineQuestions.trans.contains("hi") || LineQuestions.trans.contains("en") || LineQuestions.trans.contains("tr") || LineQuestions.trans.contains("in") || LineQuestions.trans.contains("pt") || LineQuestions.trans.contains("es") || (LineQuestions.trans.contains("sk") || LineQuestions.trans.contains("pl") || LineQuestions.trans.contains("iw") || LineQuestions.trans.contains("zu") || LineQuestions.trans.contains("ro") || LineQuestions.trans.contains("af"))) {
            this.imgans = this.baseHelper.getImgAns(this.pos, this.scid);
            this.alques = this.baseHelper.getQues(this.scid, this.pos, this.cid);
            this.alquesNo = this.baseHelper.getQuesNo(this.scid, this.pos, this.cid);
        }
        if (this.line.equals(this.getResources().getString(R.string.heartlinereading)) || this.line.equals(this.getResources().getString(R.string.lifelinereading)) || this.line.equals(this.getResources().getString(R.string.headlinereading)) || this.line.equals(this.getResources().getString(R.string.marriagelinereading)) || this.line.equals(this.getResources().getString(R.string.successlinereading))) {
            this.pos = 1;
        }
        this.txt_yes = this.findViewById(R.id.txt_yes);
        this.txt_no = this.findViewById(R.id.txt_no);
        this.optc = this.findViewById(R.id.optct);
        this.ques = this.findViewById(R.id.txt_description);

        this.resid = this.getResources().getIdentifier(this.line.toLowerCase().replaceAll(" ", ""), "drawable", this.getPackageName());
        if (LineQuestions.trans.contains("el") || LineQuestions.trans.contains("ko") || LineQuestions.trans.contains("da") || LineQuestions.trans.contains("th") || LineQuestions.trans.contains("ru") || LineQuestions.trans.contains("ms") || LineQuestions.trans.contains("de") || LineQuestions.trans.contains("fr") || LineQuestions.trans.contains("it") || LineQuestions.trans.contains("zh") || LineQuestions.trans.contains("hi") || LineQuestions.trans.contains("en") || LineQuestions.trans.contains("tr") || LineQuestions.trans.contains("in") || LineQuestions.trans.contains("pt") || LineQuestions.trans.contains("es") || LineQuestions.trans.contains("sk") || LineQuestions.trans.contains("pl") || LineQuestions.trans.contains("iw") || LineQuestions.trans.contains("zu") || LineQuestions.trans.contains("ro") || LineQuestions.trans.contains("af")) {
            if (this.cid == 0) {
                this.endresult = this.imgans;
            }
            else {
                this.endresult = "";
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("RRRRs ");
            sb3.append(this.imgans);
            final String string = sb3.toString();
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("EnsResults ");
            sb4.append(this.endresult);
            Log.e(string, sb4.toString());
        }
        this.queslength = this.alques.size();
        this.getques();
        this.txt_yes.setOnClickListener(this.listenanswer);
        this.txt_no.setOnClickListener(this.listenanswer);
        this.optc.setOnClickListener(this.listenanswer);
        if (this.baseHelper.getOptCnt(this.scid, this.pos, Integer.parseInt(this.alquesNo.get(this.i)), this.cid) > 2) {
            this.optc.setVisibility(View.VISIBLE);
        }
        else {
            this.optc.setVisibility(View.GONE);
        }

        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitial !=null && interstitial.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                Adid = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                }else {
                    editor.putString("trans3", null);
                    editor.commit();
                    startActivity(new Intent(LineQuestions.this, ShowTypesOfLines.class));
                    finish();
                }
            }
        });
        loadAd();
        BannerAds();
    }

    public void getques() {
        int parseInt = Integer.parseInt((String) this.alquesNo.get(this.i));
        if (trans.contains("el") || trans.contains("ko") || trans.contains("da") || trans.contains("th") || trans.contains("ru") || trans.contains("ms") || trans.contains("de") || trans.contains("fr") || trans.contains("it") || trans.contains("zh") || trans.contains("hi") || trans.contains("en") || trans.contains("tr") || trans.contains("in") || trans.contains("pt") || trans.contains("es") || trans.contains("sk") || trans.contains("pl") || trans.contains("iw") || trans.contains("zu") || trans.contains("ro") || trans.contains("af")) {
            if (this.cid != 1) {
                this.question = (String) this.alques.get(this.i);
            } else if (this.scid == 1) {
                this.question = getResources().getString(R.string.mountquestion);
            } else {
                this.question = getResources().getString(R.string.mountquestion);
            }
            this.alopt = this.baseHelper.getOptTxt(this.scid, this.pos, parseInt, this.cid);
            this.aloptno = this.baseHelper.getOptNo(this.scid, this.pos, parseInt, this.cid);
            parseInt = this.baseHelper.getOptCnt(this.scid, this.pos, parseInt, this.cid);
        } else {
            parseInt = 0;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("alopt ");
        stringBuilder.append(this.alopt);
        String str = "PPPP  ";
        Log.e(str, stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("aloptno ");
        stringBuilder.append(this.aloptno);
        Log.e(str, stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("optcnt ");
        stringBuilder.append(parseInt);
        Log.e(str, stringBuilder.toString());
        this.optiona = (String) this.alopt.get(0);
        this.optionb = (String) this.alopt.get(1);
        if (parseInt > 2) {
            String str2 = (String) this.alopt.get(2);
            this.optionc = str2;
            this.optc.setText(str2);
            this.optc.setVisibility(View.VISIBLE);
        } else {
            this.optc.setVisibility(View.GONE);
        }
        this.ques.setText(this.question);
        this.txt_yes.setText(this.optiona);
        this.txt_no.setText(this.optionb);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }

    private void loadAd() {

        //InterstitialAd
        interstitial = new InterstitialAd(LineQuestions.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        editor.putString("trans3", null);
                        editor.commit();
                        startActivity(new Intent(LineQuestions.this, ShowTypesOfLines.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(activity);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void onBackPressed() {
        editor.putString("trans3", null);
        editor.commit();
        startActivity(new Intent(LineQuestions.this, ShowTypesOfLines.class));
        finish();
    }
}
