package com.xyz.vehiclemanager.car.CarVarianDetails.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.viewpager.widget.ViewPager;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.adapter.VarientFragmentPageAdapter;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.fragment.BikeFeaturesFragment;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.fragment.BikeOverViewFragment;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.fragment.BikeSpecificationsFragment;
import com.xyz.vehiclemanager.car.CarVarianDetails.fragment.CarFeatureFragment;
import com.xyz.vehiclemanager.car.CarVarianDetails.fragment.CarOverViewFragment;
import com.xyz.vehiclemanager.car.CarVarianDetails.fragment.CarSpecificationFragment;
import com.xyz.vehiclemanager.car.CarVarianDetails.model.CarOverview;
import com.xyz.vehiclemanager.car.CarVarianDetails.model.CarVariantRoot;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CarVariantTabActivity extends AppCompatActivity
{

    public static String varientName,varientId;
    private ImageView iv_back;
    private TabLayout tabLayout;
    private VarientFragmentPageAdapter varientFragmentPageAdapter;
    private ViewPager viewPager;
    private TextView tv_title;
    public static AppCompatDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_variant_tab);

        varientName = getIntent().getStringExtra("VarientName");
        varientId = getIntent().getStringExtra("VarientId");
        iv_back = findViewById(R.id.iv_back);
        tv_title = findViewById(R.id.tv_title);
        tv_title.setText(varientName);

        viewPager = findViewById(R.id.viewPager);
        setViewPager();
        PutAnalyticsEvent();
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);
        CreateTab();
        DialogAnimation();

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void  DialogAnimation()
    {
        dialog = new AppCompatDialog(CarVariantTabActivity.this, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_cardialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CarVariantTabActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void setViewPager()
    {
        varientFragmentPageAdapter = new VarientFragmentPageAdapter(getSupportFragmentManager());
        varientFragmentPageAdapter.addFragment(new CarOverViewFragment(), "Overview");
        varientFragmentPageAdapter.addFragment(new CarSpecificationFragment(), "Specifications");
        varientFragmentPageAdapter.addFragment(new CarFeatureFragment(), "Features");
        viewPager.setAdapter(varientFragmentPageAdapter);
    }

    private void CreateTab()
    {
        TextView overView = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        overView.setText("OverView");
        tabLayout.getTabAt(0).setCustomView(overView);

        TextView specification = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        specification.setText("Specification");
        tabLayout.getTabAt(1).setCustomView(specification);

        TextView features = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        features.setText("Features");
        tabLayout.getTabAt(2).setCustomView(features);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}