package com.name.nameart.motionview;

import android.view.MotionEvent;
import android.view.View;

public class DetectorMotion {
    private static final float PRESSURE_THRESHOLD = 0.67f;
    private static final String TAG = "DetectorMotion";
    private boolean mActive0MostRecent;
    private int mActiveId0;
    private int mActiveId1;
    private MotionEvent mCurrEvent;
    private float mCurrFingerDiffX;
    private float mCurrFingerDiffY;
    private float mCurrLen;
    private float mCurrPressure;
    private Vector4DMotion mCurrSpanVector = new Vector4DMotion();
    private float mFocusX;
    private float mFocusY;
    private boolean mGestureInProgress;
    private boolean mInvalidGesture;
    private final OnScaleGestureListener mListener;
    private MotionEvent mPrevEvent;
    private float mPrevFingerDiffX;
    private float mPrevFingerDiffY;
    private float mPrevLen;
    private float mPrevPressure;
    private float mScaleFactor;
    private long mTimeDelta;

    public DetectorMotion(OnScaleGestureListener mListener) {
        this.mListener = mListener;
    }

    public interface OnScaleGestureListener {
        boolean onScale(View view, DetectorMotion detectorMotion);

        boolean onScaleBegin(View view, DetectorMotion detectorMotion);

        void onScaleEnd(View view, DetectorMotion detectorMotion);
    }

    public static class SimpleOnScaleGestureListener implements OnScaleGestureListener {
        public boolean onScale(View view, DetectorMotion detectorMotion) {
            return false;
        }

        public boolean onScaleBegin(View view, DetectorMotion detectorMotion) {
            return true;
        }

        public void onScaleEnd(View view, DetectorMotion detectorMotion) {
        }
    }

   /* public DetectorMotion(MyTouchMation.ScaleGestureListener onScaleGestureListener) {
        this.mListener = onScaleGestureListener;
    }
*/
    public boolean onTouchEvent(View view, MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            reset();
        }
        if (this.mInvalidGesture) {
            return false;
        }
        int i;
        int pointerId;
        if (this.mGestureInProgress) {
            if (actionMasked == 1) {
                reset();
            } else if (actionMasked == 2) {
                setContext(view, motionEvent);
                if (this.mCurrPressure / this.mPrevPressure > PRESSURE_THRESHOLD && this.mListener.onScale(view, this)) {
                    this.mPrevEvent.recycle();
                    this.mPrevEvent = MotionEvent.obtain(motionEvent);
                }
            } else if (actionMasked == 3) {
                this.mListener.onScaleEnd(view, this);
                reset();
            } else if (actionMasked == 5) {
                this.mListener.onScaleEnd(view, this);
                actionMasked = this.mActiveId0;
                i = this.mActiveId1;
                reset();
                this.mPrevEvent = MotionEvent.obtain(motionEvent);
                if (!this.mActive0MostRecent) {
                    actionMasked = i;
                }
                this.mActiveId0 = actionMasked;
                this.mActiveId1 = motionEvent.getPointerId(motionEvent.getActionIndex());
                this.mActive0MostRecent = false;
                if (motionEvent.findPointerIndex(this.mActiveId0) < 0 || this.mActiveId0 == this.mActiveId1) {
                    this.mActiveId0 = motionEvent.getPointerId(findNewActiveIndex(motionEvent, this.mActiveId1, -1));
                }
                setContext(view, motionEvent);
                this.mGestureInProgress = this.mListener.onScaleBegin(view, this);
            } else if (actionMasked == 6) {
                actionMasked = motionEvent.getPointerCount();
                int actionIndex = motionEvent.getActionIndex();
                pointerId = motionEvent.getPointerId(actionIndex);
                if (actionMasked > 2) {
                    actionMasked = this.mActiveId0;
                    if (pointerId == actionMasked) {
                        actionMasked = findNewActiveIndex(motionEvent, this.mActiveId1, actionIndex);
                        if (actionMasked >= 0) {
                            this.mListener.onScaleEnd(view, this);
                            this.mActiveId0 = motionEvent.getPointerId(actionMasked);
                            this.mActive0MostRecent = true;
                            this.mPrevEvent = MotionEvent.obtain(motionEvent);
                            setContext(view, motionEvent);
                            this.mGestureInProgress = this.mListener.onScaleBegin(view, this);
                            this.mPrevEvent.recycle();
                            this.mPrevEvent = MotionEvent.obtain(motionEvent);
                            setContext(view, motionEvent);
                        }
                    } else {
                        if (pointerId == this.mActiveId1) {
                            actionMasked = findNewActiveIndex(motionEvent, actionMasked, actionIndex);
                            if (actionMasked >= 0) {
                                this.mListener.onScaleEnd(view, this);
                                this.mActiveId1 = motionEvent.getPointerId(actionMasked);
                                this.mActive0MostRecent = false;
                                this.mPrevEvent = MotionEvent.obtain(motionEvent);
                                setContext(view, motionEvent);
                                this.mGestureInProgress = this.mListener.onScaleBegin(view, this);
                            }
                        }
                        this.mPrevEvent.recycle();
                        this.mPrevEvent = MotionEvent.obtain(motionEvent);
                        setContext(view, motionEvent);
                    }
                    this.mPrevEvent.recycle();
                    this.mPrevEvent = MotionEvent.obtain(motionEvent);
                    setContext(view, motionEvent);
                }
                setContext(view, motionEvent);
                actionMasked = this.mActiveId0;
                if (pointerId == actionMasked) {
                    actionMasked = this.mActiveId1;
                }
                i = motionEvent.findPointerIndex(actionMasked);
                this.mFocusX = motionEvent.getX(i);
                this.mFocusY = motionEvent.getY(i);
                this.mListener.onScaleEnd(view, this);
                reset();
                this.mActiveId0 = actionMasked;
                this.mActive0MostRecent = true;
            }
        } else if (actionMasked == 0) {
            this.mActiveId0 = motionEvent.getPointerId(0);
            this.mActive0MostRecent = true;
        } else if (actionMasked == 1) {
            reset();
        } else if (actionMasked == 5) {
            MotionEvent motionEvent2 = this.mPrevEvent;
            if (motionEvent2 != null) {
                motionEvent2.recycle();
            }
            this.mPrevEvent = MotionEvent.obtain(motionEvent);
            this.mTimeDelta = 0;
            actionMasked = motionEvent.getActionIndex();
            i = motionEvent.findPointerIndex(this.mActiveId0);
            pointerId = motionEvent.getPointerId(actionMasked);
            this.mActiveId1 = pointerId;
            if (i < 0 || i == actionMasked) {
                this.mActiveId0 = motionEvent.getPointerId(findNewActiveIndex(motionEvent, pointerId, -1));
            }
            this.mActive0MostRecent = false;
            setContext(view, motionEvent);
            this.mGestureInProgress = this.mListener.onScaleBegin(view, this);
        }
        return true;
    }

    private int findNewActiveIndex(MotionEvent motionEvent, int i, int i2) {
        int pointerCount = motionEvent.getPointerCount();
        int findPointerIndex = motionEvent.findPointerIndex(i);
        i = 0;
        while (i < pointerCount) {
            if (i != i2 && i != findPointerIndex) {
                return i;
            }
            i++;
        }
        return -1;
    }

    private void setContext(View view, MotionEvent motionEvent) {
        MotionEvent motionEvent2 = this.mCurrEvent;
        if (motionEvent2 != null) {
            motionEvent2.recycle();
        }
        this.mCurrEvent = MotionEvent.obtain(motionEvent);
        this.mCurrLen = -1.0f;
        this.mPrevLen = -1.0f;
        this.mScaleFactor = -1.0f;
        this.mCurrSpanVector.set(0.0f, 0.0f);
        motionEvent2 = this.mPrevEvent;
        int findPointerIndex = motionEvent2.findPointerIndex(this.mActiveId0);
        int findPointerIndex2 = motionEvent2.findPointerIndex(this.mActiveId1);
        int findPointerIndex3 = motionEvent.findPointerIndex(this.mActiveId0);
        int findPointerIndex4 = motionEvent.findPointerIndex(this.mActiveId1);
        if (findPointerIndex < 0 || findPointerIndex2 < 0 || findPointerIndex3 < 0 || findPointerIndex4 < 0) {
            this.mInvalidGesture = true;
            if (this.mGestureInProgress) {
                this.mListener.onScaleEnd(view, this);
            }
            return;
        }
        float x = motionEvent2.getX(findPointerIndex);
        float y = motionEvent2.getY(findPointerIndex);
        float x2 = motionEvent2.getX(findPointerIndex2);
        float y2 = motionEvent2.getY(findPointerIndex2);
        float x3 = motionEvent.getX(findPointerIndex3);
        float y3 = motionEvent.getY(findPointerIndex3);
        float x4 = motionEvent.getX(findPointerIndex4) - x3;
        float y4 = motionEvent.getY(findPointerIndex4) - y3;
        this.mCurrSpanVector.set(x4, y4);
        this.mPrevFingerDiffX = x2 - x;
        this.mPrevFingerDiffY = y2 - y;
        this.mCurrFingerDiffX = x4;
        this.mCurrFingerDiffY = y4;
        this.mFocusX = x3 + (x4 * 0.5f);
        this.mFocusY = y3 + (y4 * 0.5f);
        this.mTimeDelta = motionEvent.getEventTime() - motionEvent2.getEventTime();
        this.mCurrPressure = motionEvent.getPressure(findPointerIndex3) + motionEvent.getPressure(findPointerIndex4);
        this.mPrevPressure = motionEvent2.getPressure(findPointerIndex) + motionEvent2.getPressure(findPointerIndex2);
    }

    private void reset() {
        MotionEvent motionEvent = this.mPrevEvent;
        if (motionEvent != null) {
            motionEvent.recycle();
            this.mPrevEvent = null;
        }
        motionEvent = this.mCurrEvent;
        if (motionEvent != null) {
            motionEvent.recycle();
            this.mCurrEvent = null;
        }
        this.mGestureInProgress = false;
        this.mActiveId0 = -1;
        this.mActiveId1 = -1;
        this.mInvalidGesture = false;
    }

    public boolean isInProgress() {
        return this.mGestureInProgress;
    }

    public float getFocusX() {
        return this.mFocusX;
    }

    public float getFocusY() {
        return this.mFocusY;
    }

    public float getCurrentSpan() {
        if (this.mCurrLen == -1.0f) {
            float f = this.mCurrFingerDiffX;
            float f2 = this.mCurrFingerDiffY;
            this.mCurrLen = (float) Math.sqrt((double) ((f * f) + (f2 * f2)));
        }
        return this.mCurrLen;
    }

    public Vector4DMotion getCurrentSpanVector() {
        return this.mCurrSpanVector;
    }

    public float getCurrentSpanX() {
        return this.mCurrFingerDiffX;
    }

    public float getCurrentSpanY() {
        return this.mCurrFingerDiffY;
    }

    public float getPreviousSpan() {
        if (this.mPrevLen == -1.0f) {
            float f = this.mPrevFingerDiffX;
            float f2 = this.mPrevFingerDiffY;
            this.mPrevLen = (float) Math.sqrt((double) ((f * f) + (f2 * f2)));
        }
        return this.mPrevLen;
    }

    public float getPreviousSpanX() {
        return this.mPrevFingerDiffX;
    }

    public float getPreviousSpanY() {
        return this.mPrevFingerDiffY;
    }

    public float getScaleFactor() {
        if (this.mScaleFactor == -1.0f) {
            this.mScaleFactor = getCurrentSpan() / getPreviousSpan();
        }
        return this.mScaleFactor;
    }

    public long getTimeDelta() {
        return this.mTimeDelta;
    }

    public long getEventTime() {
        return this.mCurrEvent.getEventTime();
    }
}
