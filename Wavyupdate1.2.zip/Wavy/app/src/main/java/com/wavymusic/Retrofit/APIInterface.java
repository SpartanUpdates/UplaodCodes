package com.wavymusic.Retrofit;

import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface APIInterface {

    @POST("get_themes_v2")
    @FormUrlEncoded
    Call<JsonObject> GetAllTheme(@Field("token") String token, @Field("application_id") String applicationId,@Field("cat_id") String CategoryId);

    @POST("setdowncount")
    @FormUrlEncoded
    Call<JsonObject> DownloadIncrement(@Field("token") String token, @Field("application_id") String applicationId, @Field("cat_id") String CatId, @Field("theme_id") String ThemeId);

}
