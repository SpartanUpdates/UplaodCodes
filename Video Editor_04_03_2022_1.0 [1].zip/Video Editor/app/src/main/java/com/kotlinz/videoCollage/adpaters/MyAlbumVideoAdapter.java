package com.kotlinz.videoCollage.adpaters;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.kotlinz.videoCollage.interfaces.MyAlbumVideoAdapterCallBackInterface;
import com.kotlinz.videoCollage.models.Videos;
import com.kotlinz.videoeditor.R;

import java.util.ArrayList;

public class MyAlbumVideoAdapter extends Adapter<MyAlbumVideoAdapter.PhotoViewHolder> {
    private Context context;
    private int height;
    private ArrayList<Videos> imagePaths;
    private MyAlbumVideoAdapterCallBackInterface listener;
    private int width;

    public static class PhotoViewHolder extends ViewHolder {
        FrameLayout frameTrans;
        ImageView imgDelete;
        ImageView imgShare;
        ImageView mIvPhoto;
        RelativeLayout mMain;
        ProgressBar progressBar;

        public PhotoViewHolder(View view) {
            super(view);
            this.mIvPhoto = (ImageView) view.findViewById(R.id.iv_photo);
            this.mMain = (RelativeLayout) view.findViewById(R.id.photo_item_main_layout);
            this.imgShare = (ImageView) view.findViewById(R.id.img_album_share);
            this.imgDelete = (ImageView) view.findViewById(R.id.img_album_delete);
            this.progressBar = (ProgressBar) view.findViewById(R.id.loading_progress);
            this.frameTrans = (FrameLayout) view.findViewById(R.id.fram_trans);
        }
    }

    public MyAlbumVideoAdapter(Context context, ArrayList<Videos> arrayList, MyAlbumVideoAdapterCallBackInterface myAlbumVideoAdapterCallBackInterface) {
        this.context = context;
        this.imagePaths = arrayList;
        this.listener = myAlbumVideoAdapterCallBackInterface;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.height = displayMetrics.heightPixels;
        this.width = displayMetrics.widthPixels;
    }

    public PhotoViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new PhotoViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.my_album_video_items, viewGroup, false));
    }

    public void onBindViewHolder(PhotoViewHolder photoViewHolder, final int i) {
        LayoutParams layoutParams = photoViewHolder.mMain.getLayoutParams();
        layoutParams.height = this.width / 2;
        photoViewHolder.mMain.setLayoutParams(layoutParams);
        final String path = ((Videos) this.imagePaths.get(i)).getPath();
        Glide.with(this.context).asBitmap().load(path).apply((RequestOptions) new RequestOptions().frame(1000000)).into(photoViewHolder.mIvPhoto);
        photoViewHolder.mIvPhoto.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyAlbumVideoAdapter.this.listener.itemClick(i, path);
            }
        });
        photoViewHolder.imgShare.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyAlbumVideoAdapter.this.listener.itemShare(i, path);
            }
        });
        photoViewHolder.imgDelete.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyAlbumVideoAdapter.this.listener.itemDelete(i, path);
            }
        });
    }

    public int getItemCount() {
        ArrayList arrayList = this.imagePaths;
        return arrayList == null ? 0 : arrayList.size();
    }
}
