﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[ExecuteInEditMode]
public class WayPoints : MonoBehaviour
{
    [SerializeField]
    public wayPoints1[] wayPointList;

    [System.Serializable]
    public class wayPoints1
    {
        public waypoints2[] mainPoints;

        [System.Serializable]
        public class waypoints2
        {
            public GameObject[] subPoints;
        }
    }

    public List<GameObject> finalWayPoints;

    public List<int> finalWayValue;

    //public Color lineColor;

    // Vector3 size = new Vector3(.7f, .7f, .7f);

    //[SerializeField]
    //public vectorpoints1[] vectorpoints11;

    //[System.Serializable]
    //public class vectorpoints1
    //{
    //    public vectorpoints2[] mainPoints;

    //    [System.Serializable]
    //    public class vectorpoints2
    //    {
    //        public Vector3[] subPoints;
    //    }
    //}
    int temp;
    void Awake()
    {
        finalWayPoints = new List<GameObject>();
        finalWayValue = new List<int>();

        for (int i = 0; i < wayPointList.Length; i++)
        {
            temp = UnityEngine.Random.Range(0, wayPointList[i].mainPoints.Length);
            finalWayValue.Add(temp);
            for (int j = 0; j < wayPointList[i].mainPoints[temp].subPoints.Length; j++)
            {
                finalWayPoints.Add(wayPointList[i].mainPoints[temp].subPoints[j]);
            }
        }
    }
    public virtual List<GameObject> GetPathPoints()
    {
        return finalWayPoints;
    }
  

    //void OnDrawGizmos()
    //{
    //    if (finalWayPoints.Count > 2)
    //    {
    //        Vector3 start = finalWayPoints[0].transform.position;
    //        Vector3 end = finalWayPoints[finalWayPoints.Count - 1].transform.position;
    //        Gizmos.color = Color.blue;
    //        Gizmos.DrawWireCube(start, size * GetHandleSize(start) * 1.5f);
    //        Gizmos.DrawWireCube(end, size * GetHandleSize(end) * 1.5f);

    //        for (int i = 1; i < finalWayPoints.Count - 1; i++)
    //        {
    //            Gizmos.color = Color.yellow;
    //            Gizmos.DrawWireSphere(finalWayPoints[i].transform.position, 0.4f * GetHandleSize(finalWayPoints[i].transform.position));
    //        }
    //        DrawStraight(finalWayPoints);
    //    }
    //}
    //public virtual float GetHandleSize(Vector3 pos)
    //{
    //    float handleSize = 1f;
    //    #if UNITY_EDITOR
    //        handleSize = UnityEditor.HandleUtility.GetHandleSize(pos) * 0.4f;
    //        handleSize = Mathf.Clamp(handleSize, 0, 1.2f);
    //    #endif
    //    return handleSize;
    //}
    //void DrawStraight(List<GameObject> waypoints)
    //{
    //    for (int i = 0; i < waypoints.Count - 1; i++)
    //    {
    //        waypoints[i].name = "WayPoints " + i;
    //        Gizmos.color = lineColor;
    //        Gizmos.DrawLine(waypoints[i].transform.position, waypoints[i + 1].transform.position);
    //    }

    //    for (int i = 0; i < waypoints.Count; i++)
    //    {
    //        waypoints[i].name = "WayPoints " + i;
    //    }
    //}

    //[SerializeField]
    //vectorpoints33[] vectorpoints333;

    //[System.Serializable]
    //class vectorpoints33
    //{
    //     public vectorpoints3[] mainPoints;

    //    [System.Serializable]
    //    public class vectorpoints3
    //    {
    //        public GameObject[] subPoints;
    //    }
    //}
    //public void MainArray()
    //{
    //    //vectorpoints11 = new vectorpoints1[wayPointList.Length];
    //    vectorpoints333 = new vectorpoints33[vectorpoints11.Length];
    //}

    //public void SubArray()
    //{
    //    //for (int i = 0; i < wayPointList.Length; i++)
    //    //{

    //    //    vectorpoints11[i].mainPoints = new vectorpoints1.vectorpoints2[wayPointList[i].mainPoints.Length];
    //    //}
    //    for (int i = 0; i < vectorpoints11.Length; i++)
    //    {

    //        vectorpoints333[i].mainPoints = new vectorpoints33.vectorpoints3[vectorpoints11[i].mainPoints.Length];
    //    }
    //}
    //public GameObject test111;
    //public void FinalArray()
    //{
    //    //for (int i = 0; i < wayPointList.Length; i++)
    //    //{

    //    //    vectorpoints11[i].mainPoints = new vectorpoints1.vectorpoints2[wayPointList[i].mainPoints.Length];
    //    //    for (int j = 0; j < wayPointList[i].mainPoints.Length; j++)
    //    //    {
    //    //        vectorpoints11[i].mainPoints[j].subPoints = new Vector3[wayPointList[i].mainPoints[j].subPoints.Length];

    //    //        for (int m = 0; m < wayPointList[i].mainPoints[j].subPoints.Length; m++)
    //    //        {
    //    //            vectorpoints11[i].mainPoints[j].subPoints[m] = wayPointList[i].mainPoints[j].subPoints[m].transform.position;
    //    //        }

    //    //    }
    //    //}

    //    for (int i = 0; i < vectorpoints11.Length; i++)
    //    {

    //        for (int j = 0; j < vectorpoints11[i].mainPoints.Length; j++)
    //        {
    //            vectorpoints333[i].mainPoints[j].subPoints = new GameObject[vectorpoints11[i].mainPoints[j].subPoints.Length] ;

    //            for (int m = 0; m < wayPointList[i].mainPoints[j].subPoints.Length; m++)
    //            {
    //                vectorpoints333[i].mainPoints[j].subPoints[m] =Instantiate(test111, vectorpoints11[i].mainPoints[j].subPoints[m],Quaternion.identity);
    //            }

    //        }
    //    }
    //}
}
