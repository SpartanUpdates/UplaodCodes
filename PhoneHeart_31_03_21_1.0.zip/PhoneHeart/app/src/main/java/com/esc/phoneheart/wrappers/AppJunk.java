package com.esc.phoneheart.wrappers;

import java.util.ArrayList;

public class AppJunk {
    public long appJunkSize;
    public String appName;
    public ArrayList<MediaJunkData> mediaJunkData = new ArrayList();

    public AppJunk(String str) {
        this.appName = str;
    }

    public void refresh() {
        this.appJunkSize = 0;
        for (int i = 0; i < this.mediaJunkData.size(); i++) {
            ((MediaJunkData) this.mediaJunkData.get(i)).totSelectedSize = 0;
            ((MediaJunkData) this.mediaJunkData.get(i)).totSelectedCount = 0;
            ArrayList arrayList = ((MediaJunkData) this.mediaJunkData.get(i)).dataList;
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                this.appJunkSize += ((BigSizeFilesWrapper) arrayList.get(i2)).size;
                ((BigSizeFilesWrapper) arrayList.get(i2)).ischecked = false;
            }
        }
    }
}
