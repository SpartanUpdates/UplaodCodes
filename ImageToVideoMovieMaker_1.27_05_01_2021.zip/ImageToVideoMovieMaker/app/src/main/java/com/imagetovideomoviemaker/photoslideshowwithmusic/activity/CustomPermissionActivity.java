package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.view.View;
import android.view.Window;
import android.view.animation.AccelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;
import com.xyz.imagetovideomoviewmaker.R;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.EPreferences;

public class CustomPermissionActivity extends AppCompatActivity {
    Activity activity = CustomPermissionActivity.this;
    String AppName;
    ComponentName SecurityComponentName;
    Button btnGotIt;
    EPreferences ePref;
    private AnimatorSet g;
    ImageView imageHand;
    SwitchCompat switchTut;
    private TextView tvName;
    private TextView tvMessage;
    private TextView tvDescrtption;

    public CustomPermissionActivity() {
        this.SecurityComponentName = null;
        this.AppName = "";
    }

    public static int b(final Context context, final float n) {
        return (int) (context.getResources().getDisplayMetrics().density * n + 0.5f);
    }

    private void staranimation() {
        this.imageHand.setAlpha(0.0f);
        this.switchTut.setAlpha(0.0f);
        this.tvName.setAlpha(0.0f);
        final int b = b(this, 125.0f);
        this.imageHand.setTranslationY((float) b);
        this.imageHand.setTranslationX((float) (-b / 2));
        final ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this.imageHand, "alpha", 1.0f);
        final ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this.tvName, "alpha", 1.0f);
        final ObjectAnimator ofFloat3 = ObjectAnimator.ofFloat(this.switchTut, "alpha", 1.0f);
        ofFloat.setDuration(250L);
        ofFloat2.setDuration(250L);
        ofFloat3.setDuration(250L);
        final ObjectAnimator ofFloat4 = ObjectAnimator.ofFloat(this.imageHand, "translationY", 0.0f);
        final ObjectAnimator ofFloat5 = ObjectAnimator.ofFloat(this.imageHand, "translationX", 0.0f);
        final ObjectAnimator ofFloat6 = ObjectAnimator.ofFloat(this, "rotationX", -60.0f, 0.0f);
        ofFloat4.setDuration(600L);
        ofFloat5.setDuration(600L);
        ofFloat6.setDuration(600L);
        ofFloat6.setInterpolator(new AccelerateInterpolator());
        (this.g = new AnimatorSet()).playTogether(ofFloat3, ofFloat2, ofFloat, ofFloat4, ofFloat5);
        this.g.setStartDelay(700L);
        this.g.addListener(new Animator.AnimatorListener() {
            public void onAnimationCancel(final Animator animator) {
            }

            public void onAnimationEnd(final Animator animator) {
                CustomPermissionActivity.this.switchTut.setChecked(true);
            }

            public void onAnimationRepeat(final Animator animator) {
                CustomPermissionActivity.this.switchTut.setChecked(false);
            }

            public void onAnimationStart(final Animator animator) {
                CustomPermissionActivity.this.switchTut.setChecked(false);
            }
        });
        this.g.start();
    }

    public void onBackPressed() {
    }

    @TargetApi(19)
    protected void onCreate(@Nullable final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 19) {
            final Window window = this.getWindow();
            window.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP, Intent.FLAG_ACTIVITY_CLEAR_TOP);
            window.setFlags(134217728, 134217728);
        }
        this.setContentView(R.layout.tutorial_activity);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CustomPermissionActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);

        this.ePref = EPreferences.getInstance(this);
        this.switchTut = this.findViewById(R.id.scSwitchTut);
        this.imageHand = this.findViewById(R.id.ivImageHand);
        this.btnGotIt = this.findViewById(R.id.btnGotIt);
        tvMessage = findViewById(R.id.tvMsg);
        tvDescrtption = findViewById(R.id.tv_description);
        this.tvName = this.findViewById(R.id.tvName);
        Utils.setFont(activity, tvMessage);
        Utils.setFont(activity, tvDescrtption);
        Utils.setButtonFont(activity, btnGotIt);
        this.btnGotIt.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                final Intent intent = CustomPermissionActivity.this.getIntent();
                CustomPermissionActivity.this.SecurityComponentName = intent.getParcelableExtra("PACKAGE");
                CustomPermissionActivity.this.AppName = intent.getStringExtra("APPNAME");
                if (CustomPermissionActivity.this.SecurityComponentName != null) {
                    final Intent intent2 = new Intent();
                    intent2.setComponent(CustomPermissionActivity.this.SecurityComponentName);
                    CustomPermissionActivity.this.startActivity(intent2);
                }
                CustomPermissionActivity.this.ePref.putBoolean("HasAutoStartPermission", true);
                CustomPermissionActivity.this.finish();
            }
        });
        this.staranimation();
    }

    protected void onDestroy() {
        super.onDestroy();
    }

    protected void onPause() {
        super.onPause();
        this.overridePendingTransition(0, 0);
    }
}
