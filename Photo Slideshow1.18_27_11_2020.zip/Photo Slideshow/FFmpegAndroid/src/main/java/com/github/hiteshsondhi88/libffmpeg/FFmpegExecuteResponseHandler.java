package com.github.hiteshsondhi88.libffmpeg;

public interface FFmpegExecuteResponseHandler extends ResponseHandler {


    public void onSuccess(String message);

    public void onProgress(String message);


    public void onFailure(String message);

}
