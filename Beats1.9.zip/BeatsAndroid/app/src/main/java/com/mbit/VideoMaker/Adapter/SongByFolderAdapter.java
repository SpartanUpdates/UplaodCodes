package com.mbit.VideoMaker.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.mbit.VideoMaker.Activity.LocalSongActivity;
import com.mbit.VideoMaker.Model.LocalTrack;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.View.CircleImageView;
import com.mbit.VideoMaker.application.MyApplication;

import java.util.List;


public class SongByFolderAdapter extends RecyclerView.Adapter<SongByFolderAdapter.MyViewHolder> {

    public static int FirstSelected = 0;
    public static boolean IsSongPlay = false;
    Context ctx;
    private List<LocalTrack> localTracks;
    private LocalmusicInterface localmusicInterface;
    private LocalSongActivity ActivityOfsong;

    public SongByFolderAdapter(Context ctx, List<LocalTrack> localTracks) {
        this.ctx = ctx;
        this.ActivityOfsong = (LocalSongActivity) ctx;
        this.localTracks = localTracks;
    }

    public void Music(LocalmusicInterface localmusicInterface) {
        this.localmusicInterface = localmusicInterface;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_local_song, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (this.localTracks != null) {
            final LocalTrack track = localTracks.get(position);
            holder.Songname.setText(track.m5778d());
            if (FirstSelected == 0) {
                FirstSelected = this.localTracks.get(position).a();
                if (localmusicInterface != null) {
                    localmusicInterface.a(track, position);
                }
            }
            if (FirstSelected != this.localTracks.get(position).a()) {
                holder.ivThumb.setBackgroundResource(R.drawable.img_ring);
                holder.tvuseSong.setBackgroundResource(R.drawable.btn_gradiant_use_normal);
                holder.IvplayPause.setImageResource(R.drawable.icon_player_play);
            } else {
                holder.ivThumb.setBackgroundResource(R.drawable.img_ring_press);
                holder.tvuseSong.setBackgroundResource(R.drawable.btn_gradiant_use_selected);
                holder.IvplayPause.setImageResource(R.drawable.icon_player_pause);
            }
            holder.itemView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    if (localmusicInterface != null) {
                        localmusicInterface.a(track, position);
                    }
                }
            });
            holder.tvuseSong.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (ActivityOfsong.mInterstitialAd != null && ActivityOfsong.mInterstitialAd.isAdLoaded()) {
                        ActivityOfsong.mediacontroler.g();
                        ActivityOfsong.id = 102;
//                        MyApplication.ShowDialog(ctx);
                        MyApplication.ShowDialog(ctx, ActivityOfsong.mInterstitialAd);
//                        ActivityOfsong.mInterstitialAd.show();
                    } else {
                        ActivityOfsong.Done();
//                        ActivityOfsong.finish();
                    }

                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return localTracks.size();
    }

    public interface LocalmusicInterface {
        void a();

        void a(LocalTrack musicRes, int i);
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        LinearLayout llMain;
        CircleImageView ivThumb;
        TextView Songname, tvSongtime, tvuseSong;
        ImageView IvplayPause;

        public MyViewHolder(View itemView) {
            super(itemView);
            llMain = itemView.findViewById(R.id.image_layout);
            ivThumb = itemView.findViewById(R.id.image_content);
            IvplayPause = itemView.findViewById(R.id.ivPopularPlayPause);
            Songname = itemView.findViewById(R.id.tvMusicName);
            tvuseSong = itemView.findViewById(R.id.tvUseMusic);
            tvSongtime = itemView.findViewById(R.id.tvMusicEndTime);
        }
    }

}
