package com.xyz.vehiclemanager.rtoownerdetails.rtoowner.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.room.Room;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.history.Model.OwnerHistory;
import com.xyz.vehiclemanager.history.Room.HistoryDatabase;
import com.xyz.vehiclemanager.kprogresshud.KProgressHUD;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.rtoownerdetails.rtoowner.model.OwnerRoot;
import com.xyz.vehiclemanager.utils.HeaderFooterPageEvent;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RtoOwnerDetailActivity extends AppCompatActivity {
    private Activity activity = RtoOwnerDetailActivity.this;
    private String strImageUri, strOwnerName, strRegistrationNumber, strRegistrationDate, strFuelType, strChassisNumber, strFuelNorms,
            strEngineNumber, strInsuranceUpto, strFitnessUpto, strVehicleClass, strCity, strMarkerModel, strBrandName, strModelName,
            strShowRoomPrice, strVehicleType, strVehicleColor, strSeatCapacity, strOwnerShip;
    private LinearLayout ll_brandname, ll_modelname, ll_price, ll_ownership;
    private TextView tv_address, tv_registrationNo, tv_registrationDate, tv_chassisNo, tv_engineNo, tv_ownerName, tv_vehicleClass,
            tv_fuelType, tv_markerModel, tv_fitnessUpto, tv_insuranceUpto, tv_fuelNorms, tv_brandName, tv_modelName, tv_price, tv_vehicletype,
            tv_vehiclecolor, tv_seatCapacity, tv_ownership;
    private ImageView vehicleImage;
    private Button btn_getData;
    private Button btn_download;
    private ScrollView scrollView;
    private EditText input1, input2, input3, input4;
    private String result;
    private String resultTwo;
    private ProgressDialog pddownload;
    private ArrayList<OwnerRoot> ownerDetaillist;
    private List<List<OwnerHistory>> ownerHistory;
    private ImageView iv_back;
    private ImageView iv_reset;
    private String first;
    private String second;
    private String Third;
    private String Fourth;
    private boolean IsvehicleInfo = false;
    private Boolean checkExistOrNot = true;
    private RtoDetailsInterface rtoDetailsInterface;
    private LinearLayout ll_ownerData;
    private AppCompatDialog dialog;
    HistoryDatabase historyDatabase;


    private KProgressHUD hud;
    public InterstitialAd mInterstitialAd;
    private int id;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rto_owner_detail);

        first = getIntent().getStringExtra("first");
        second = getIntent().getStringExtra("second");
        Third = getIntent().getStringExtra("third");
        Fourth = getIntent().getStringExtra("fourth");

        //from History
        strImageUri = getIntent().getStringExtra("imageUri");
        strOwnerName = getIntent().getStringExtra("ownerName");
        strRegistrationNumber = getIntent().getStringExtra("registrationNumber");
        strRegistrationDate = getIntent().getStringExtra("registrationDate");
        strFuelType = getIntent().getStringExtra("fuelType");
        strChassisNumber = getIntent().getStringExtra("chassisNumber");
        strFuelNorms = getIntent().getStringExtra("fuelNorms");
        strEngineNumber = getIntent().getStringExtra("engineNumber");
        strInsuranceUpto = getIntent().getStringExtra("insuranceUpto");
        strFitnessUpto = getIntent().getStringExtra("fitnessUpto");
        strVehicleClass = getIntent().getStringExtra("vehicleClass");
        strCity = getIntent().getStringExtra("city");
        strMarkerModel = getIntent().getStringExtra("markerModel");
        strBrandName = getIntent().getStringExtra("brandName");
        strModelName = getIntent().getStringExtra("modelName");
        strShowRoomPrice = getIntent().getStringExtra("showRoomPrice");
        strVehicleType = getIntent().getStringExtra("vehicleType");
        strVehicleColor = getIntent().getStringExtra("vehicleColor");
        strSeatCapacity = getIntent().getStringExtra("seatCapacity");
        strOwnerShip = getIntent().getStringExtra("ownerShip");

        ownerDetaillist = new ArrayList<>();
        ownerHistory = new ArrayList<List<OwnerHistory>>();
        rtoDetailsInterface = RtoDetailsApiClient.getOwnerDetails().create(RtoDetailsInterface.class);
        historyDatabase = Room.databaseBuilder(RtoOwnerDetailActivity.this, HistoryDatabase.class, "VehicleDetailsHistory").allowMainThreadQueries().build();

        BindView();
        PutAnalyticsEvent();
        BannerAds();
        interstitialAd();
        SetClickListener();
        getStringFromHistory();

        if (first != null && second != null && Third != null && Fourth != null) {
            input1.setText(first);
            input2.setText(second);
            input3.setText(Third);
            input4.setText(Fourth);

            input1.setEnabled(false);
            input2.setEnabled(false);
            input3.setEnabled(false);
            input4.setEnabled(false);
        }
    }

    private void BindView() {
        input1 = findViewById(R.id.input1);
        input2 = findViewById(R.id.input2);
        input3 = findViewById(R.id.input3);
        input4 = findViewById(R.id.input4);

        iv_back = findViewById(R.id.iv_back);
        iv_reset = findViewById(R.id.iv_reset);

        btn_getData = findViewById(R.id.btn_getData);
        vehicleImage = findViewById(R.id.vehicleImage);
        tv_address = findViewById(R.id.city);
        tv_registrationNo = findViewById(R.id.regNumber);
        tv_registrationDate = findViewById(R.id.regDate);
        tv_chassisNo = findViewById(R.id.chasisNo);
        tv_engineNo = findViewById(R.id.engineNo);
        tv_ownerName = findViewById(R.id.ownerName);
        tv_vehicleClass = findViewById(R.id.tv_vehicleClass);
        tv_fuelType = findViewById(R.id.fuelType);
        tv_markerModel = findViewById(R.id.makerModel);
        tv_fitnessUpto = findViewById(R.id.fitness);
        tv_insuranceUpto = findViewById(R.id.insUpto);
        tv_fuelNorms = findViewById(R.id.fNorms);
        tv_modelName = findViewById(R.id.modelName);
        tv_brandName = findViewById(R.id.tv_brandName);
        tv_price = findViewById(R.id.prize);
        tv_vehicletype = findViewById(R.id.vehicle_type);
        tv_vehiclecolor = findViewById(R.id.vehicle_color);
        tv_seatCapacity = findViewById(R.id.seatCapacity);
        tv_ownership = findViewById(R.id.ownership);
        btn_download = findViewById(R.id.btn_download);
        ll_ownership = findViewById(R.id.ll_ownership);
        ll_brandname = findViewById(R.id.ll_brandname);
        ll_modelname = findViewById(R.id.ll_modelname);
        ll_price = findViewById(R.id.ll_price);
        ll_ownerData = findViewById(R.id.ll_ownerData);
        scrollView = findViewById(R.id.scrollView);
        scrollView.setScrollbarFadingEnabled(false);
        scrollView.setSmoothScrollingEnabled(true);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "RtoOwnerDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getStringFromHistory() {

        if (strRegistrationNumber != null) {

            input1.setText(strRegistrationNumber.substring(0, 2));
            input2.setText(strRegistrationNumber.substring(2, 4));
            input3.setText(strRegistrationNumber.substring(4, 6));
            input4.setText(strRegistrationNumber.substring(6, 10));

            System.out.println(strImageUri);
            ll_ownerData.setVisibility(View.VISIBLE);
            Glide.with(getApplicationContext()).load(strImageUri).centerCrop().placeholder(R.drawable.ic_car).into(vehicleImage);
            tv_ownerName.setText(strOwnerName);
            tv_registrationNo.setText(strRegistrationNumber);
            tv_registrationDate.setText(strRegistrationDate);
            tv_fuelType.setText(strFuelType);
            tv_chassisNo.setText(strChassisNumber);
            tv_fuelNorms.setText(strFuelNorms);
            tv_engineNo.setText(strEngineNumber);
            tv_insuranceUpto.setText(strInsuranceUpto);
            tv_fitnessUpto.setText(strFitnessUpto);
            tv_vehicleClass.setText(strVehicleClass);
            tv_address.setText(strCity);
            tv_markerModel.setText(strMarkerModel);
            tv_brandName.setText(strBrandName);
            tv_modelName.setText(strModelName);
            tv_price.setText(strShowRoomPrice);
            tv_vehicletype.setText(strVehicleType);
            tv_vehiclecolor.setText(strVehicleColor);
            tv_seatCapacity.setText(strSeatCapacity);
            tv_ownership.setText(strOwnerShip);
            input1.setEnabled(false);
            input2.setEnabled(false);
            input3.setEnabled(false);
            input4.setEnabled(false);
            btn_getData.setEnabled(false);
        }
    }

    public void SetClickListener() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        iv_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                input1.setEnabled(true);
                input2.setEnabled(true);
                input3.setEnabled(true);
                input4.setEnabled(true);
                ResetData();
            }
        });

        input1.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input1.getText().toString().length() == 2) {
                    input2.setText("");
                    input2.requestFocus();
                }
            }
        });
        input2.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input2.getText().toString().length() == 2) {
                    input3.setText("");
                    input3.requestFocus();
                }
            }
        });
        input3.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input3.getText().toString().length() == 2) {
                    input4.setText("");
                    input4.requestFocus();
                }
            }
        });

        input4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if (input4.length() == 3) {
                    View view = getCurrentFocus();
                    if (view != null) {
                        InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        btn_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                printData();
            }
        });

        btn_getData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 101;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                }
                else {
                    GetData();
                }
            }
        });
    }

    public void GetData() {
        tv_ownerName.setText("");
        tv_registrationNo.setText("");
        tv_registrationDate.setText("");
        tv_fuelType.setText("");
        tv_chassisNo.setText("");
        tv_engineNo.setText("");
        tv_insuranceUpto.setText("");
        tv_fitnessUpto.setText("");
        tv_fuelNorms.setText("");
        tv_vehicleClass.setText("");
        tv_address.setText("");
        tv_markerModel.setText("");
        tv_brandName.setText("");
        tv_modelName.setText("");
        tv_price.setText("");
        tv_vehicletype.setText("");
        tv_vehiclecolor.setText("");
        tv_seatCapacity.setText("");
        tv_ownership.setText("");
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input4.getWindowToken(), 0);
        input4.clearFocus();
        if (!isConnected(activity)) {
            Toast.makeText(activity, "No Internet Connection", Toast.LENGTH_SHORT).show();
            return;
        }
        final String string = input1.getText().toString();
        final String string2 = input2.getText().toString();
        final String string3 = input3.getText().toString();
        final String string4 = input4.getText().toString();
        final StringBuilder sb = new StringBuilder();
        sb.append(string);
        sb.append(string2);
        sb.append(string3);
        sb.append(string4);
        result = sb.toString();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("&reg2=");
        sb2.append(string4);
        resultTwo = sb2.toString();

        if (TextUtils.isEmpty(string)) {
            input1.setError("This should not be empty");
            input1.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string2)) {
            input2.setError("This should not be empty");
            input2.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string3)) {
            input3.setError("This should not be empty");
            input3.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string4)) {
            input4.setError("This should not be empty");
            input4.requestFocus();
            return;
        }
        DialogAnimation();
        vehicleImage.setImageDrawable(getResources().getDrawable(R.drawable.ic_car));
        scrollView.fullScroll(ScrollView.FOCUS_UP);
        GetVehicleDetails(result);
    }

    private void DialogAnimation() {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_dialog_search);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    public void ResetData() {
        if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()) {
            try {
                hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        id = 100;
                        mInterstitialAd.show();
                    }
                }
            }, 2000);
        }
        else {
            ResetAllData();
        }
    }

    private void ResetAllData(){
        tv_ownerName.setText("");
        tv_registrationNo.setText("");
        tv_registrationDate.setText("");
        tv_fuelType.setText("");
        tv_chassisNo.setText("");
        tv_engineNo.setText("");
        tv_insuranceUpto.setText("");
        tv_fitnessUpto.setText("");
        tv_fuelNorms.setText("");
        tv_vehicleClass.setText("");
        tv_address.setText("");
        tv_markerModel.setText("");
        tv_brandName.setText("");
        tv_modelName.setText("");
        tv_price.setText("");
        tv_vehicletype.setText("");
        tv_vehiclecolor.setText("");
        tv_seatCapacity.setText("");
        tv_ownership.setText("");

        input1.setText("");
        input2.setText("");
        input3.setText("");
        input4.setText("");
        ll_ownerData.setVisibility(View.GONE);
        btn_getData.setEnabled(true);
        vehicleImage.setImageDrawable(getResources().getDrawable(R.drawable.ic_car));
        scrollView.fullScroll(ScrollView.FOCUS_UP);
        input1.requestFocus();
    }
    private void printDataFromApi() {
        final String string = input1.getText().toString();
        final String string2 = input2.getText().toString();
        final String string3 = input3.getText().toString();
        final String string4 = input4.getText().toString();
        final StringBuilder sb = new StringBuilder();
        sb.append(string);
        sb.append(string2);
        sb.append(string3);
        sb.append(string4);
        result = sb.toString();

        final StringBuilder sb2 = new StringBuilder();
        sb2.append("&reg2=");
        sb2.append(string4);
        resultTwo = sb2.toString();
        if (TextUtils.isEmpty(string)) {
            input1.setError("This should not be empty");
            input1.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string2)) {
            input2.setError("This should not be empty");
            input2.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string3)) {
            input3.setError("This should not be empty");
            input3.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string4)) {
            input4.setError("This should not be empty");
            input4.requestFocus();
            return;
        }
        final StringBuilder sb3 = new StringBuilder();
        sb3.append("Owner Name : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getOwnerName());
        sb3.append("\nRegistration No : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getRegistrationNo());
        sb3.append("\nRegistration Date : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getRegistrationDate());
        sb3.append("\nFuel Type : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getFuelType());
        sb3.append("\nChasis Number : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getChassisNo());
        sb3.append("\nEngine Number : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getEngineNo());
        sb3.append("\nInsurance Upto : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getInsuranceUpto());
        sb3.append("\nFitness Upto : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getFitnessUpto());
        sb3.append("\nFuel Norms : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getFuelNorms());
        sb3.append("\nVehicle Class : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getVehicleClass());
        sb3.append("\nCity : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getRegistrationAuthority());
        sb3.append("\nMaker Model : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getMakerModel());
        if (IsvehicleInfo) {
        } else {
            sb3.append("\nBrand Name: ");
            sb3.append(ownerDetaillist.get(0).getDetails().getVehicleInfo().getBrandName());
            sb3.append("\nModel Name: ");
            sb3.append(ownerDetaillist.get(0).getDetails().getVehicleInfo().getModelName());
            sb3.append("\nShow Room Prize: ");
            sb3.append(ownerDetaillist.get(0).getDetails().getVehicleInfo().getExShowroomPrice());
            sb3.append("\nOwnership : ");
            sb3.append(ownerDetaillist.get(0).getDetails().getOwnership());
        }
        sb3.append("\nVehicle Type : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getVehicleType());
        sb3.append("\nVehicle Color : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getVehicleColor());

        sb3.append("\nSeat Capacity : ");
        sb3.append(ownerDetaillist.get(0).getDetails().getSeatCapacity());
        sb3.append("\n\nGet All Inidia Vehicle details using ");
        sb3.append(getResources().getString(R.string.app_name));
        sb3.append(" Android App get app @ \n https://play.google.com/store/apps/details?id=");
        sb3.append(getPackageName());
        createandDisplayPdf(sb3.toString());
    }

    private void printDataFromHistory() {
        final String string = input1.getText().toString();
        final String string2 = input2.getText().toString();
        final String string3 = input3.getText().toString();
        final String string4 = input4.getText().toString();
        final StringBuilder sb = new StringBuilder();
        sb.append(string);
        sb.append(string2);
        sb.append(string3);
        sb.append(string4);
        result = sb.toString();
        List<OwnerHistory> ownerHistoryList = HistoryDatabase.getDatabase(RtoOwnerDetailActivity.this).ownerHistoryDao().getOwnerHistory();
        for (int i = 0; i < ownerHistoryList.size(); i++) {
            if (result.equals(ownerHistoryList.get(i).getRegistrationNo())) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append("Owner Name : ");
                sb3.append(ownerHistoryList.get(i).getOwnerName());
                sb3.append("\nRegistration No : ");
                sb3.append(ownerHistoryList.get(i).getRegistrationNo());
                sb3.append("\nRegistration Date : ");
                sb3.append(ownerHistoryList.get(i).getRegistrationDate());
                sb3.append("\nFuel Type : ");
                sb3.append(ownerHistoryList.get(i).getFuelType());
                sb3.append("\nChasis Number : ");
                sb3.append(ownerHistoryList.get(i).getChasisNumber());
                sb3.append("\nEngine Number : ");
                sb3.append(ownerHistoryList.get(i).getEngineNumber());
                sb3.append("\nInsurance Upto : ");
                sb3.append(ownerHistoryList.get(i).getInsuranceUpto());
                sb3.append("\nFitness Upto : ");
                sb3.append(ownerHistoryList.get(i).getFitnessUpto());
                sb3.append("\nFuel Norms : ");
                sb3.append(ownerHistoryList.get(i).getFuelNorms());
                sb3.append("\nVehicle Class : ");
                sb3.append(ownerHistoryList.get(i).getVehicleClass());
                sb3.append("\nCity : ");
                sb3.append(ownerHistoryList.get(i).getCity());
                sb3.append("\nMaker Model : ");
                sb3.append(ownerHistoryList.get(i).getMarkerModel());
                if (IsvehicleInfo) {
                } else {
                    sb3.append("\nBrand Name: ");
                    sb3.append(ownerHistoryList.get(i).getBrandName());
                    sb3.append("\nModel Name: ");
                    sb3.append(ownerHistoryList.get(i).getModelName());
                    sb3.append("\nShow Room Prize: ");
                    sb3.append(ownerHistoryList.get(i).getShowRoomPrice());
                }
                sb3.append("\nOwnership : ");
                sb3.append(ownerHistoryList.get(i).getOwnership());
                sb3.append("\nVehicle Type : ");
                sb3.append(ownerHistoryList.get(i).getVehicleType());
                sb3.append("\nVehicle Color : ");
                sb3.append(ownerHistoryList.get(i).getVehicleColor());

                sb3.append("\nSeat Capacity : ");
                sb3.append(ownerHistoryList.get(i).getSeatCapacity());
                sb3.append("\n\nGet All Inidia Vehicle details using ");
                sb3.append(getResources().getString(R.string.app_name));
                sb3.append(" Android App get app @ \n https://play.google.com/store/apps/details?id=");
                sb3.append(getPackageName());
                createandDisplayPdf(sb3.toString());
            }
        }
    }

    public void createandDisplayPdf(final String s) {
        pddownload = new ProgressDialog(activity);
        pddownload.setMessage("Please Wait Downloaded...");
        pddownload.setCancelable(false);
        pddownload.show();
        StringBuilder sb2;
        final Document document = new Document(PageSize.A4, 20.0f, 20.0f, 50.0f, 25.0f);
        try {
            try {
                final StringBuilder sb = new StringBuilder();
                sb.append(Environment.getExternalStorageDirectory());
                sb.append("ViewVehicleDetails");
                File file = new File(Environment.getExternalStorageDirectory(), "ViewVehicleDetails");
                if (!file.exists()) {
                    file.mkdir();
                }
                sb2 = new StringBuilder();
                sb2.append(result);
                sb2.append(".pdf");
                final File file2 = new File(file, sb2.toString());
                PdfWriter.getInstance(document, new FileOutputStream(file2)).setPageEvent(new HeaderFooterPageEvent());
                document.open();
                final Paragraph paragraph = new Paragraph(s);
                final Font font = new Font(Font.FontFamily.COURIER);
                paragraph.setAlignment(0);
                paragraph.setFont(font);
                document.addTitle("VEHICLE DETAILS");
                document.add(paragraph);
                document.close();
                new CountDownTimer(500L, 500L) {
                    public void onFinish() {
                        openScreenshot(file2);
                        pddownload.dismiss();
                    }

                    public void onTick(final long n) {
                    }
                }.start();
            } finally {
            }
        } catch (IOException ex) {
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("ioException:");
            sb3.append(ex);
        } catch (DocumentException ex2) {
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("DocumentException:");
            sb4.append(ex2);
        }
        document.close();
    }


    private void openScreenshot(final File file) {
        final Uri uriForFile = FileProvider.getUriForFile(activity, getPackageName() + ".provider", file);
        final AlertDialog.Builder builder = new AlertDialog.Builder(activity);

        builder.setTitle("Share vehicle details");
        builder.setMessage("Your  Vehicle Details have been saved to PDF in \"ViewVehicleDetails\" folder.").setCancelable(true).setPositiveButton("OPEN", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                Intent target = new Intent(Intent.ACTION_VIEW);
                target.setDataAndType(uriForFile, "application/pdf");
                target.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                target.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                target.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent intent = Intent.createChooser(target, "Open File");
                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(activity, "No Application available to view pdf", Toast.LENGTH_LONG).show();
                }
            }
        }).setNegativeButton("Share", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {

                final StringBuilder sb = new StringBuilder();
                sb.append("View All India Vehicle details - Get \n App @ https://play.google.com/store/apps/details?id=");
                sb.append(getPackageName());
                final Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
                intent.putExtra(Intent.EXTRA_TEXT, sb.toString());
                intent.putExtra(Intent.EXTRA_STREAM, uriForFile);
                startActivity(Intent.createChooser(intent, "Share"));
            }
        });
        builder.create().show();
    }

    private void printData() {
        if (strRegistrationNumber != null) {
            printDataFromHistory();
        } else {
            if (ownerDetaillist != null && ownerDetaillist.size() != 0) {
                if (Build.VERSION.SDK_INT > 22) {
                    if (!checkIfAlreadyhavePermission()) {
                        requestForSpecificPermission();
                        return;
                    }
                    printDataFromApi();
                }
            } else {
                Toast.makeText(activity, "Please Click On Get Result", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean checkIfAlreadyhavePermission() {
        return ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101 && (grantResults.length > 0) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            printData();
        } else {
            Toast.makeText(activity, "Permission Denied", Toast.LENGTH_LONG).show();
        }
    }

    public boolean isConnected(final Context context) {
        final ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        final NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting()) {
            final NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
            final NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(0);
            return (networkInfo2 != null && networkInfo2.isConnectedOrConnecting()) || (networkInfo != null && networkInfo.isConnectedOrConnecting());
        }
        return false;
    }

    private void GetVehicleDetails(final String number) {
        List<OwnerHistory> ownerHistoryList = HistoryDatabase.getDatabase(RtoOwnerDetailActivity.this).ownerHistoryDao().getOwnerHistory();
        for (int i = 0; i < ownerHistoryList.size(); i++) {
            if (ownerHistoryList.get(i).getRegistrationNo().equals(number)) {
                checkExistOrNot = false;
                ll_ownerData.setVisibility(View.VISIBLE);
                if (dialog != null && dialog.isShowing()) {
                    dialog.dismiss();
                }
                tv_ownerName.setText(ownerHistoryList.get(i).getOwnerName());
                tv_registrationNo.setText(ownerHistoryList.get(i).getRegistrationNo());
                tv_registrationDate.setText(ownerHistoryList.get(i).getRegistrationDate());
                tv_fuelType.setText(ownerHistoryList.get(i).getFuelType());
                tv_chassisNo.setText(ownerHistoryList.get(i).getChasisNumber());
                tv_engineNo.setText(ownerHistoryList.get(i).getEngineNumber());
                tv_insuranceUpto.setText(ownerHistoryList.get(i).getInsuranceUpto());
                tv_fitnessUpto.setText(ownerHistoryList.get(i).getFitnessUpto());
                tv_fuelNorms.setText(ownerHistoryList.get(i).getFuelNorms());
                tv_vehicleClass.setText(ownerHistoryList.get(i).getVehicleClass());
                tv_address.setText(ownerHistoryList.get(i).getCity());
                tv_markerModel.setText(ownerHistoryList.get(i).getMarkerModel());
                tv_vehicletype.setText(ownerHistoryList.get(i).getVehicleType());
                tv_vehiclecolor.setText(ownerHistoryList.get(i).getVehicleColor());
                tv_seatCapacity.setText(ownerHistoryList.get(i).getSeatCapacity());
                if (ownerHistoryList.get(i).getBrandName() == null && ownerHistoryList.get(i).getModelName() == null && ownerHistoryList.get(i).getShowRoomPrice() == null) {
                    IsvehicleInfo = true;
                    ll_brandname.setVisibility(View.GONE);
                    ll_modelname.setVisibility(View.GONE);
                    ll_price.setVisibility(View.GONE);
                } else {
                    tv_brandName.setText(ownerHistoryList.get(i).getBrandName());
                    tv_modelName.setText(ownerHistoryList.get(i).getModelName());
                    tv_price.setText(ownerHistoryList.get(i).getShowRoomPrice());
                    Glide.with(getApplicationContext()).load(ownerHistoryList.get(i).getImageUrl()).centerCrop().placeholder(R.drawable.ic_car).into(vehicleImage);
                }
                if (ownerHistoryList.get(i).getOwnership() == null) {
                    ll_ownership.setVisibility(View.GONE);
                } else {
                    tv_ownership.setText(ownerHistoryList.get(i).getOwnership());
                }
                ownerHistory.add(ownerHistoryList);
            }
        }
        if (checkExistOrNot) {
            Call<OwnerRoot> call = rtoDetailsInterface.getOwnerDetail(number);
            call.enqueue(new Callback<OwnerRoot>() {
                @Override
                public void onResponse(Call<OwnerRoot> call, Response<OwnerRoot> response) {

                    if (response.isSuccessful()) {
                        ll_ownerData.setVisibility(View.VISIBLE);
                        OwnerRoot ownerRoot = response.body();
                        String statusMessage = response.body().getStatusMessage();
                        if (statusMessage.equals("RC data not found.") && statusMessage.equals("Registration No. does not exist, please search another no.!!!!")) {
                            btn_getData.setEnabled(true);
                            dialog.dismiss();
                            Toast.makeText(RtoOwnerDetailActivity.this, "No Data found", Toast.LENGTH_SHORT).show();
                        } else {
                            tv_address.setText(ownerRoot.getDetails().getRegistrationAuthority());
                            tv_registrationNo.setText(ownerRoot.getDetails().getRegistrationNo());
                            tv_registrationDate.setText(ownerRoot.getDetails().getRegistrationDate());
                            tv_chassisNo.setText(ownerRoot.getDetails().getChassisNo());
                            tv_engineNo.setText(ownerRoot.getDetails().getEngineNo());
                            tv_ownerName.setText(ownerRoot.getDetails().getOwnerName());
                            tv_vehicleClass.setText(ownerRoot.getDetails().getVehicleClass());
                            tv_fuelType.setText(ownerRoot.getDetails().getFuelType());
                            tv_markerModel.setText(ownerRoot.getDetails().getMakerModel());
                            tv_fitnessUpto.setText(ownerRoot.getDetails().getFitnessUpto());
                            tv_insuranceUpto.setText(ownerRoot.getDetails().getInsuranceUpto());
                            tv_fuelNorms.setText(ownerRoot.getDetails().getFuelNorms());
                            tv_vehicletype.setText(ownerRoot.getDetails().getVehicleType());
                            tv_vehiclecolor.setText(ownerRoot.getDetails().getVehicleColor());
                            tv_seatCapacity.setText(ownerRoot.getDetails().getSeatCapacity());

                            //OwnerVehicleInfo
                            OwnerRoot.OwnerDetails.VehicleInfo VehicleInfo = ownerRoot.getDetails().getVehicleInfo();
                            String brandName = null, modelName = null, price = null, ownership = null, imageurl = null;

                            if (VehicleInfo == null) {
                                IsvehicleInfo = true;
                                ll_brandname.setVisibility(View.GONE);
                                ll_modelname.setVisibility(View.GONE);
                                ll_price.setVisibility(View.GONE);

                            } else {
                                tv_brandName.setText(ownerRoot.getDetails().getVehicleInfo().getBrandName());
                                brandName = ownerRoot.getDetails().getVehicleInfo().getBrandName();
                                tv_modelName.setText(ownerRoot.getDetails().getVehicleInfo().getModelName());
                                modelName = ownerRoot.getDetails().getVehicleInfo().getModelName();
                                tv_price.setText(ownerRoot.getDetails().getVehicleInfo().getExShowroomPrice());
                                price = ownerRoot.getDetails().getVehicleInfo().getExShowroomPrice();
                                imageurl = ownerRoot.getDetails().getVehicleInfo().getImageUrl();
                                Glide.with(getApplicationContext()).load(imageurl).centerCrop().placeholder(R.drawable.ic_car).into(vehicleImage);
                            }
                            if (ownerRoot.getDetails().getOwnership() == null) {
                                ll_ownership.setVisibility(View.GONE);
                            } else {
                                ownership = ownerRoot.getDetails().getOwnership();
                                tv_ownership.setText(ownership);
                            }

                            String address = ownerRoot.getDetails().getRegistrationAuthority();
                            String registrationNo = ownerRoot.getDetails().getRegistrationNo();
                            String registrationDate = ownerRoot.getDetails().getRegistrationDate();
                            String chassisNo = ownerRoot.getDetails().getChassisNo();
                            String engineNo = ownerRoot.getDetails().getEngineNo();
                            String ownerName = ownerRoot.getDetails().getOwnerName();
                            String vehicleClass = ownerRoot.getDetails().getVehicleClass();
                            String fuelType = ownerRoot.getDetails().getFuelType();
                            String markerModel = ownerRoot.getDetails().getMakerModel();
                            String fitnessUpto = ownerRoot.getDetails().getFitnessUpto();
                            String insuranceUpto = ownerRoot.getDetails().getInsuranceUpto();
                            String fuelNorms = ownerRoot.getDetails().getFuelNorms();
                            String vehicleType = ownerRoot.getDetails().getVehicleType();
                            String vehicleColor = ownerRoot.getDetails().getVehicleColor();
                            String seatCapacity = ownerRoot.getDetails().getSeatCapacity();

                            //Inserting Data in Database
                            insertOwnerDataIntoRoom(imageurl, ownerName, registrationNo, registrationDate, fuelType, chassisNo, fuelNorms, engineNo, insuranceUpto, fitnessUpto, vehicleClass, address, markerModel, brandName, modelName, price, vehicleType, vehicleColor, seatCapacity, ownership);

                            if (dialog != null && dialog.isShowing()) {
                                dialog.dismiss();
                            }
                            ownerDetaillist.add(ownerRoot);
                        }
                    } else {
                        Toast.makeText(RtoOwnerDetailActivity.this, "Please enter valid vehicle number", Toast.LENGTH_SHORT).show();
                        btn_getData.setEnabled(true);
                        if (dialog != null && dialog.isShowing()) {
                            dialog.dismiss();
                        }
                        ll_ownerData.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onFailure(Call<OwnerRoot> call, Throwable t) {
                    if (dialog != null && dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    Toast.makeText(RtoOwnerDetailActivity.this, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void insertOwnerDataIntoRoom(final String imageUrl, final String ownerName, final String registrationNo, final String registrationDate, final String fuelType, final String chasisNo, final String fuelNorms, final String engineNo, final String insuranceUpto, final String fitnessUpto, final String vehicleClass, final String address, final String markerModel, final String brandName, final String modelName, final String showRoomPrice, final String vehicleType, final String vehicleColor, final String seatCapacity, final String ownership) {
        Thread thread = new Thread(new Runnable() {
            public void run() {
                OwnerHistory ownerHistory = new OwnerHistory(imageUrl, ownerName, registrationNo, registrationDate, fuelType, chasisNo, fuelNorms, engineNo, insuranceUpto, fitnessUpto, vehicleClass, address, markerModel, brandName, modelName, showRoomPrice, vehicleType, vehicleColor, seatCapacity, ownership);
                historyDatabase.ownerHistoryDao().insertOwnerData(ownerHistory);
            }
        });
        thread.start();
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        ResetAllData();
                        break;

                    case 101:
                        GetData();
                        break;
                }
                RequestInterstitial();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}