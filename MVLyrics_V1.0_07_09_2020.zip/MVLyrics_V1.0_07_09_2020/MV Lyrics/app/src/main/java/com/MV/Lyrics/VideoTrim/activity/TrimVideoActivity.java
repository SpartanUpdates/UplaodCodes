package com.MV.Lyrics.VideoTrim.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.R;
import com.MV.Lyrics.SelectImage.activity.SelectImageActivity;
import com.MV.Lyrics.VideoTrim.interfaces.OnTrimVideoListener;
import com.MV.Lyrics.VideoTrim.view.RangeSeekBarView;
import com.MV.Lyrics.VideoTrim.view.VideoTrimmer;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.root.UnitySendValue.AndroidUnityCall;
import com.unity3d.player.UnityPlayer;

public class TrimVideoActivity extends AppCompatActivity implements OnTrimVideoListener {

    Activity activity = TrimVideoActivity.this;
    ImageView ivback;
    private VideoTrimmer mVideoTrimmer;
    TextView tvVideoSize;
    RangeSeekBarView timeLineBar;
    private String videoPath;
    public String trimVideoPath;
    public String VideoMode;
    public String UnitySendValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trim_video);
        videoPath = getIntent().getStringExtra("VideoPath");
        PutAnalyticsEvent();
        BindView();
        SetListener();
    }
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "TrimVideoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }
    private void BindView() {
        ivback = findViewById(R.id.ivBack);
        mVideoTrimmer = findViewById(R.id.video_trimmer);
        timeLineBar = findViewById(R.id.timeLineBar);
        tvVideoSize = findViewById(R.id.tv_videoSize);
        if (mVideoTrimmer != null && videoPath != null) {
            mVideoTrimmer.setMaxDuration(100);
            mVideoTrimmer.setOnTrimVideoListener(this);
            mVideoTrimmer.setVideoURI(Uri.parse(videoPath));

        } else {
            Toast.makeText(activity, R.string.selectedvideo_not_retrive, Toast.LENGTH_SHORT).show();
        }
    }

    private void SetListener() {
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    @Override
    public void getResult(final Uri uri) {
        trimVideoPath = uri.toString();
        MyApplication.getInstance().isSettingEnable = true;
        AndroidUnityCall.ShowSetting(activity);
        if (mVideoTrimmer.VideoWidth != 0 && mVideoTrimmer.VideoHeight != 0) {
            if (mVideoTrimmer.VideoHeight == mVideoTrimmer.VideoWidth) {
                VideoMode = "0";
            } else if (mVideoTrimmer.VideoHeight > mVideoTrimmer.VideoWidth) {
                VideoMode = "1";
            } else {
                VideoMode = "2";
            }
        }
        UnitySendValue = trimVideoPath + MyApplication.SPLIT_PATTERN + VideoMode;
        Log.e("TAG", "UnitySendValue" + UnitySendValue);
        Log.e("TAG", "VideoWidth" + mVideoTrimmer.VideoWidth);
        Log.e("TAG", "VideoHeight" + mVideoTrimmer.VideoHeight);
        UnityPlayer.UnitySendMessage("AppManager", "GetVideoPath", UnitySendValue);
        finish();
    }

    @Override
    public void cancelAction() {
        mVideoTrimmer.destroy();
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent=new Intent(activity,SelectImageActivity.class);
        intent.putExtra("NoofImage", 1);
        intent.putExtra("IsFrom", "Video");
        startActivity(intent);
        finish();
    }
}