import 'dart:io' as Io;
import 'dart:ui';
import 'package:pdf/pdf.dart';
import 'package:rto_app/History%20Screen/controller/history_controller.dart';
import 'package:rto_app/History%20Screen/model/history_model.dart';
import 'package:rto_app/Home%20Screen/themes.dart';
import 'package:rto_app/Owner%20Info%20Screen/controllers/controllers.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:rto_app/Utils/utils.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:http/http.dart' as http;
import 'package:lottie/lottie.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:velocity_x/src/flutter/center.dart';
import 'package:velocity_x/src/flutter/padding.dart';
import 'package:pdf/widgets.dart' as pw;

class OwnerInfo extends StatelessWidget {
  bool isFocus;
  String number;

  OwnerInfo(this.isFocus, this.number);

  HistoryController historyController = Get.put(HistoryController());

  @override
  Widget build(BuildContext context) {
    historyController.getAllData();
    return WillPopScope(
      onWillPop: () {
        DisplayData.isResponseAvailable = false;
        Future.delayed(const Duration(milliseconds: 350), () {
          Navigator.pop(context);
        });
        return Future.value(false);
      },
      child: Material(
        child: SafeArea(
          child: Scaffold(
            backgroundColor: Theme.of(context).disabledColor,
            body: NestedScrollView(
              physics: BouncingScrollPhysics(),
              floatHeaderSlivers: true,
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return <Widget>[
                  SliverAppBar(
                    backgroundColor: Theme.of(context).focusColor,
                    title: Text(
                      "Owner Info",
                      style: TextStyle(
                          fontSize: 16.5,
                          color: context.accentColor,
                          fontFamily: "Circular Bold"),
                    ).centered(),
                    leading: Container(
                      padding: EdgeInsets.all(10),
                      child: Material(
                        color: Colors.transparent,
                        shape: CircleBorder(),
                        clipBehavior: Clip.hardEdge,
                        child: IconButton(
                            padding: EdgeInsets.zero,
                            onPressed: () {
                              DisplayData.isResponseAvailable = false;
                              if (Links.rateDialog) {
                                Links.rateDialog = false;
                                Future.delayed(
                                    const Duration(milliseconds: 350), () {
                                  CommanDialog.showRatingDialog(context);
                                });
                              } else {
                                Future.delayed(
                                    const Duration(milliseconds: 350), () {
                                  Navigator.pop(context, true);
                                });
                              }
                            },
                            icon: Icon(
                              Icons.arrow_back_ios_rounded,
                              color: context.accentColor,
                              size: 20,
                            )),
                      ),
                    ),
                    actions: [
                      IconButton(
                        onPressed: () {},
                        icon: Hero(
                          tag: "ownerinfo",
                          transitionOnUserGestures: true,
                          child: Opacity(
                            opacity: 0.7,
                            child: (Image.asset(
                              'assets/images/owner_info.png',
                            )),
                          ),
                        ),
                        iconSize: 35,
                      ).pOnly(right: 10),
                    ],
                  )
                ];
              },
              body: Column(
                children: [
                  MySearchBar(historyController, isFocus, number),
                  DisplayData(historyController)
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MySearchBar extends StatelessWidget {
  bool isFocus;
  bool searched = false;
  String number;
  MainControllers controller = Get.put(MainControllers());
  TextEditingController searchController = TextEditingController();
  HistoryController historyController;

  MySearchBar(this.historyController, this.isFocus, this.number);

  var focusNode = FocusNode();

  @override
  Widget build(BuildContext context) {
    if (number.isNotEmpty) {
      searched = true;
    }
    searchController.text = number;
    searchController.selection = TextSelection.fromPosition(
        TextPosition(offset: searchController.text.length));
    return GetBuilder<MainControllers>(builder: (controller) {
      return Container(
        width: double.infinity,
        decoration: BoxDecoration(
            color: Theme.of(context).focusColor,
            shape: BoxShape.rectangle,
            borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(30.0),
                bottomLeft: Radius.circular(30.0))),
        child: Column(
          children: [
            TextField(
              onTap: () {
                print("clicked");
              },
              focusNode: focusNode,
              textInputAction: TextInputAction.search,
              onSubmitted: (value) {
                FocusScope.of(context).requestFocus(focusNode);
                searching(context);
                print("submited");
              },
              cursorColor: Theme.of(context).shadowColor,
              style: TextStyle(
                  fontFamily: "Circular Medium",
                  fontSize: 20,
                  color: Theme.of(context).accentColor),
              autofocus: isFocus ? FocusScope.of(context).isFirstFocus : false,
              controller: searchController,
              onChanged: (value) {
                controller.clearAll();
                searched = false;
                controller.itemValidation(false);
                if (searchController.text.length < 10) {
                  controller.clearAll();
                }
                if (value.isEmpty) {
                  print("clear called");
                  controller.clearAll();
                }
                final first = RegExp(r'^[a-zA-Z]+$');
                final second = RegExp(r'^[0-9]+$');
                if (value.substring(0, 1).contains(first) &&
                    value.substring(1, 2).contains(first) &&
                    value.substring(2, 3).contains(second) &&
                    value.substring(3, 4).contains(second) &&
                    value.substring(4, 5).contains(first) &&
                    value.substring(5, 6).contains(first) &&
                    value.substring(6, 7).contains(second) &&
                    value.substring(7, 8).contains(second) &&
                    value.substring(8, 9).contains(second) &&
                    value.substring(9, 10).contains(second) &&
                    value.length <= 10) {
                  historyController.getAllData();
                } else {
                  controller.itemValidation(true);
                }
              },
              decoration: InputDecoration(
                suffixIcon: IconButton(
                  icon: Icon(CupertinoIcons.search_circle_fill),
                  color: Colors.blueGrey,
                  iconSize: 35,
                  onPressed: () {
                    searching(context);
                  },
                ).pOnly(right: 5),
                contentPadding:
                    EdgeInsets.symmetric(vertical: 5, horizontal: 20),
                focusedErrorBorder: OutlineInputBorder(
                    gapPadding: 0,
                    borderRadius: BorderRadius.circular(35.0),
                    borderSide:
                        BorderSide(color: Colors.redAccent, width: 0.5)),
                errorBorder: OutlineInputBorder(
                    gapPadding: 0,
                    borderRadius: BorderRadius.circular(35.0),
                    borderSide:
                        BorderSide(color: Colors.redAccent, width: 0.5)),
                focusedBorder: OutlineInputBorder(
                  gapPadding: 0,
                  borderRadius: BorderRadius.circular(35.0),
                  borderSide: BorderSide(color: Colors.grey, width: 0.5),
                ),
                enabledBorder: OutlineInputBorder(
                  gapPadding: 0,
                  borderRadius: BorderRadius.circular(35.0),
                  borderSide: BorderSide(color: Colors.grey, width: 0.5),
                ),
                border: const OutlineInputBorder(),
                labelText: "Vehicle number",
                labelStyle: TextStyle(
                    fontFamily: "Circular Medium",
                    fontSize: 17,
                    color: Color(0xffAEA3A3)),
                hintStyle: TextStyle(
                    fontFamily: "Circular Medium",
                    fontSize: 20,
                    color: Theme.of(context).shadowColor),
                hintText: "ex : MH10AB5521",
                errorStyle: TextStyle(
                    fontFamily: "Circular Medium",
                    fontSize: 10,
                    color: Colors.redAccent),
                errorText: controller.itemError,
              ),
              //controller: controller,
            ).px(5).pOnly(bottom: 15, top: 5).px(15)
          ],
        ),
      );
    });
  }

  void searching(BuildContext context) {
    if (searched == false) {
      controller.itemValidation(false);
      historyController.getAllData();
      if (searchController.text.isEmpty) {
        controller.clearAll();
      }
      bool exist = false;
      final first = RegExp(r'^[a-zA-Z]+$');
      final second = RegExp(r'^[0-9]+$');
      if (searchController.text.substring(0, 1).contains(first) &&
          searchController.text.substring(1, 2).contains(first) &&
          searchController.text.substring(2, 3).contains(second) &&
          searchController.text.substring(3, 4).contains(second) &&
          searchController.text.substring(4, 5).contains(first) &&
          searchController.text.substring(5, 6).contains(first) &&
          searchController.text.substring(6, 7).contains(second) &&
          searchController.text.substring(7, 8).contains(second) &&
          searchController.text.substring(8, 9).contains(second) &&
          searchController.text.substring(9, 10).contains(second) &&
          searchController.text.length >= 10) {
        if (searchController.text.length == 10) {
          searched = true;
          number = searchController.text;
          controller.fetchOwnerData(
              context, searchController.text.toUpperCase().toString());
          FocusScope.of(context).unfocus();
        }
      } else {
        controller.itemValidation(true);
      }
    }
  }
}

class DisplayData extends StatelessWidget {
  static bool isResponseAvailable = false;
  MainControllers controller = MainControllers();
  HistoryController historyController;

  DisplayData(this.historyController);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: Container(
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Container(
            color: Theme.of(context).disabledColor,
            width: double.infinity,
            child: GetBuilder<MainControllers>(
              builder: (controller) {
                return isResponseAvailable
                    ? Align(
                        alignment: Alignment.topCenter,
                        child: getDisplayAllTheData(context, historyController,
                            controller.ownerInfoData))
                    : Center(
                        child: getSearchingLottieFile(),
                      );
              },
            ),
          ),
        ),
      ),
    );
  }
}

getDisplayAllTheData(
    BuildContext context, HistoryController controllers, var response) {
  print("Owner name : ${response.ownerName}");
  print("license plate : ${response.licensePlate}");
  print("reg date : ${response.registrationDate.toString()}");
  print("Class : ${response.responseClass}");
  print("brand Name : ${response.brandName}");
  print("engine number : ${response.engineNumber}");
  print("Fuel type : ${response.fuelType}");
  print("Insurance company : ${response.insuranceCompany}");
  print("Insurance exp date : ${response.insuranceExpiry}");

  bool exist = false;
  String regDate;
  String expDate;
  for (int i = 0; i < controllers.ownerInfoList.length; i++) {
    if (controllers.ownerInfoList[i].licensePlate == response.licensePlate) {
      exist = true;
    }
  }
  if (exist == false) {
    regDate =
        "${response.registrationDate.toString().substring(8, 10)} - ${response.registrationDate.toString().substring(5, 7)} - ${response.registrationDate.toString().substring(0, 4)}";
    if (response.insuranceExpiry.toString() == "Invalid date") {
      expDate = "Date not available";
    } else {
      expDate =
          "${response.insuranceExpiry.toString().substring(8, 10)} - ${response.insuranceExpiry.toString().substring(5, 7)} - ${response.insuranceExpiry.toString().substring(0, 4)}";
    }
    controllers.insert(HistoryModel(
      ownerName: response.ownerName,
      licensePlate: response.licensePlate,
      registrationDate: regDate,
      responseClass: response.responseClass,
      brandName: response.brandName,
      brandModel: response.brandModel,
      engineNumber: response.engineNumber,
      fuelType: response.fuelType,
      insuranceCompany: response.insuranceCompany,
      insuranceExpiry: expDate,
      rto: response.rto,
      state: response.state,
      rtoCode: response.rtoCode,
    ));
  } else {
    regDate = response.registrationDate.toString();
    if (response.response.insuranceExpiry.toString() == "Invalid date") {
      expDate = "Date not available";
    } else {
      expDate = response.insuranceExpiry.toString();
    }
  }
  return SingleChildScrollView(
    physics: BouncingScrollPhysics(),
    scrollDirection: Axis.vertical,
    child: Column(
      children: [
        Card(
          elevation: 0,
          color: Theme.of(context).errorColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ListTile(
              leading: Card(
                color: Theme.of(context).errorColor,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(width: 0.3, color: Colors.grey)),
                child: Container(
                  padding: EdgeInsets.all(8),
                  height: 55,
                  width: 55,
                  child: Image.asset('assets/images/profile.png'),
                ),
              ).px(5),
              title: Text("Owner Name",
                      style: TextStyle(
                          fontFamily: "Circular Medium",
                          color: Theme.of(context).hintColor))
                  .text
                  .size(15)
                  .make()
                  .pOnly(bottom: 2.2),
              subtitle: Text("${response.ownerName}",
                      style: TextStyle(
                          fontFamily: "Circular Medium", color: Colors.grey))
                  .text
                  .size(13)
                  .make()
                  .pOnly(top: 2.2)),
        ).px(10).pOnly(top: 5),
        Card(
          elevation: 0,
          color: Theme.of(context).errorColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ListTile(
              leading: Card(
                color: Theme.of(context).errorColor,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(width: 0.3, color: Colors.grey)),
                child: Container(
                  padding: EdgeInsets.all(8),
                  height: 55,
                  width: 55,
                  child: Image.asset('assets/images/driver_license.png'),
                ),
              ).px(5).pOnly(bottom: 2.2),
              title: Text("Registration Number",
                      style: TextStyle(
                          fontFamily: "Circular Medium",
                          color: Theme.of(context).hintColor))
                  .text
                  .size(15)
                  .make(),
              subtitle: Text("${response.licensePlate}",
                      style: TextStyle(
                          fontFamily: "Circular Medium", color: Colors.grey))
                  .text
                  .size(13)
                  .make()
                  .pOnly(top: 2.2)),
        ).px(10),
        Card(
          elevation: 0,
          color: Theme.of(context).errorColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ListTile(
              leading: Card(
                color: Theme.of(context).errorColor,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(width: 0.3, color: Colors.grey)),
                child: Container(
                  padding: EdgeInsets.all(8),
                  height: 55,
                  width: 55,
                  child: Image.asset('assets/images/registration_date.png'),
                ),
              ).px(5).pOnly(bottom: 2.2),
              title: Text("Registration Date",
                      style: TextStyle(
                          fontFamily: "Circular Medium",
                          color: Theme.of(context).hintColor))
                  .text
                  .size(15)
                  .make(),
              subtitle: Text(regDate,
                      style: TextStyle(
                          fontFamily: "Circular Medium", color: Colors.grey))
                  .text
                  .size(13)
                  .make()
                  .pOnly(top: 2.2)),
        ).px(10),
        Card(
          elevation: 0,
          color: Theme.of(context).errorColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ListTile(
              leading: Card(
                color: Theme.of(context).errorColor,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(width: 0.3, color: Colors.grey)),
                child: Container(
                  padding: EdgeInsets.all(8),
                  height: 55,
                  width: 55,
                  child: Image.asset('assets/images/class.png'),
                ),
              ).px(5).pOnly(bottom: 2.2),
              title: Text("Vehicle Class",
                      style: TextStyle(
                          fontFamily: "Circular Medium",
                          color: Theme.of(context).hintColor))
                  .text
                  .size(15)
                  .make(),
              subtitle: Text("${response.responseClass}",
                      style: TextStyle(
                          fontFamily: "Circular Medium", color: Colors.grey))
                  .text
                  .size(13)
                  .make()
                  .pOnly(top: 2.2)),
        ).px(10),
        if (response.brandName.length < 2)
          Container()
        else
          Card(
            elevation: 0,
            color: Theme.of(context).errorColor,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: ListTile(
                leading: Card(
                  color: Theme.of(context).errorColor,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                      side: BorderSide(width: 0.3, color: Colors.grey)),
                  child: Container(
                    padding: EdgeInsets.all(8),
                    height: 55,
                    width: 55,
                    child: Image.asset('assets/images/brand_name.png'),
                  ),
                ).px(5).pOnly(bottom: 2.2),
                title: Text("Vehicle Brand",
                        style: TextStyle(
                            fontFamily: "Circular Medium",
                            color: Theme.of(context).hintColor))
                    .text
                    .size(15)
                    .make()
                    .pOnly(top: 2.2),
                subtitle: Text("${response.brandName}",
                        style: TextStyle(
                            fontFamily: "Circular Medium", color: Colors.grey))
                    .text
                    .size(13)
                    .make()),
          ).px(10),
        if (response.brandModel.length < 2)
          Container()
        else
          Card(
            elevation: 0,
            color: Theme.of(context).errorColor,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: ListTile(
                leading: Card(
                  color: Theme.of(context).errorColor,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                      side: BorderSide(width: 0.3, color: Colors.grey)),
                  child: Container(
                    padding: EdgeInsets.all(8),
                    height: 55,
                    width: 55,
                    child: Image.asset('assets/images/model_name.png'),
                  ),
                ).px(5).pOnly(bottom: 2.2),
                title: Text("Vehicle Model",
                        style: TextStyle(
                            fontFamily: "Circular Medium",
                            color: Theme.of(context).hintColor))
                    .text
                    .size(15)
                    .make(),
                subtitle: Text("${response.brandModel}",
                        style: TextStyle(
                            fontFamily: "Circular Medium", color: Colors.grey))
                    .text
                    .size(13)
                    .make()
                    .pOnly(top: 2.2)),
          ).px(10),
        Card(
          elevation: 0,
          color: Theme.of(context).errorColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ListTile(
              leading: Card(
                color: Theme.of(context).errorColor,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(width: 0.3, color: Colors.grey)),
                child: Container(
                  padding: EdgeInsets.all(8),
                  height: 55,
                  width: 55,
                  child: Image.asset('assets/images/engine_number.png'),
                ),
              ).px(5).pOnly(bottom: 2.2),
              title: Text("Engine Number",
                      style: TextStyle(
                          fontFamily: "Circular Medium",
                          color: Theme.of(context).hintColor))
                  .text
                  .size(15)
                  .make(),
              subtitle: Text("${response.engineNumber}",
                      style: TextStyle(
                          fontFamily: "Circular Medium", color: Colors.grey))
                  .text
                  .size(13)
                  .make()
                  .pOnly(top: 2.2)),
        ).px(10),
        Card(
          elevation: 0,
          color: Theme.of(context).errorColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ListTile(
              leading: Card(
                color: Theme.of(context).errorColor,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(width: 0.3, color: Colors.grey)),
                child: Container(
                  padding: EdgeInsets.all(8),
                  height: 55,
                  width: 55,
                  child: Image.asset('assets/images/fuel_type.png'),
                ),
              ).px(5),
              title: Text("Fuel Type",
                      style: TextStyle(
                          fontFamily: "Circular Medium",
                          color: Theme.of(context).hintColor))
                  .text
                  .size(15)
                  .make()
                  .pOnly(bottom: 2.2),
              subtitle: Text("${response.fuelType}",
                      style: TextStyle(
                          fontFamily: "Circular Medium", color: Colors.grey))
                  .text
                  .size(13)
                  .make()
                  .pOnly(top: 2.2)),
        ).px(10),
        if (response.insuranceCompany == "")
          Container()
        else
          Card(
            elevation: 0,
            color: Theme.of(context).errorColor,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: ListTile(
                leading: Card(
                  color: Theme.of(context).errorColor,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                      side: BorderSide(width: 0.3, color: Colors.grey)),
                  child: Container(
                    padding: EdgeInsets.all(8),
                    height: 55,
                    width: 55,
                    child: Image.asset('assets/images/insurance_company.png'),
                  ),
                ).px(5),
                title: Text("Insurance Company",
                        style: TextStyle(
                            fontFamily: "Circular Medium",
                            color: Theme.of(context).hintColor))
                    .text
                    .size(15)
                    .make()
                    .pOnly(bottom: 2.2),
                subtitle: Text("${response.insuranceCompany}",
                        style: TextStyle(
                            fontFamily: "Circular Medium", color: Colors.grey))
                    .text
                    .size(13)
                    .make()
                    .pOnly(top: 2.2)),
          ).px(10),
        Card(
          elevation: 0,
          color: Theme.of(context).errorColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ListTile(
              leading: Card(
                color: Theme.of(context).errorColor,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(width: 0.3, color: Colors.grey)),
                child: Container(
                  padding: EdgeInsets.all(8),
                  height: 55,
                  width: 55,
                  child: Image.asset('assets/images/insurance_expiry.png'),
                ),
              ).px(5),
              title: Text("Insurance Expiry",
                      style: TextStyle(
                          fontFamily: "Circular Medium",
                          color: Theme.of(context).hintColor))
                  .text
                  .size(15)
                  .make()
                  .pOnly(bottom: 2.2),
              subtitle: Text(expDate,
                      style: TextStyle(
                          fontFamily: "Circular Medium", color: Colors.grey))
                  .text
                  .size(13)
                  .make()
                  .pOnly(top: 2.2)),
        ).px(10),
        Card(
          elevation: 0,
          color: Theme.of(context).errorColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ListTile(
              leading: Card(
                color: Theme.of(context).errorColor,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(width: 0.3, color: Colors.grey)),
                child: Container(
                  padding: EdgeInsets.all(8),
                  height: 55,
                  width: 55,
                  child: Image.asset('assets/images/city_name.png'),
                ),
              ).px(5),
              title: Text("Address",
                      style: TextStyle(
                          fontFamily: "Circular Medium",
                          color: Theme.of(context).hintColor))
                  .text
                  .size(15)
                  .make()
                  .pOnly(bottom: 2.2),
              subtitle: Text(
                      "${response.rto} , ${response.state} (${response.rtoCode})",
                      style: TextStyle(
                          fontFamily: "Circular Medium", color: Colors.grey))
                  .text
                  .size(13)
                  .make()
                  .pOnly(top: 2.2)),
        ).px(10),
        Container(
                height: 50,
                child: Material(
                  color: Theme.of(context).focusColor,
                  child: Ink(
                    decoration: BoxDecoration(),
                    child: InkWell(
                      customBorder: RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(15),
                              bottomRight: Radius.circular(15))),
                      splashColor: MyThemes.darkCreamColor,
                      onTap: () {
                        //_createPDF(context);
                        createPdf(context, response, regDate, expDate);
                      },
                      child: Center(
                        child: Text(
                          "Download PDF",
                          style: TextStyle(
                              color: Theme.of(context).hintColor,
                              fontFamily: "Circular Medium"),
                        ),
                      ),
                    ),
                  ),
                ).cornerRadius(15))
            .pOnly(bottom: 20)
            .px(50)
            .py(10),
      ],
    ),
  );
}

final doc = pw.Document();

void createPdf(
    BuildContext context, response, String regDate, String expDate) async {
  if (await Permission.storage.request().isGranted) {
    doc.addPage(pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Center(
              child: pw.Column(
            children: [
              pw.Text(
                "Rto Vehicle Manager \n\n"
                "Vehicle Owner Name : ${response.ownerName}\n"
                "Vehicle Registration Number : ${response.licensePlate}\n"
                "Vehicle Registration Date : ${regDate}\n"
                "Vehicle Class : ${response.responseClass}\n"
                "Vehicle Brand : ${response.brandName}\n"
                "Vehicle Model : ${response.brandModel}\n"
                "Vehicle Engine Number : ${response.engineNumber}\n"
                "Vehicle Fuel Type : ${response.fuelType}\n"
                "Vehicle Insurance Company : ${response.insuranceCompany}\n"
                "Vehicle Insurance Expiry : ${expDate}\n"
                "Vehicle Address : ${response.rto} , ${response.state} ( ${response.rtoCode} )\n\n"
                "Get Rto Vehicle Manager app by click here",
              ),
            ],
          ));
        })); // Page

    final path = await getExternalStorageDirectory();
    String pathToWrite = path!.path + '/${response.ownerName}.pdf';
    Io.File outputFile = Io.File(pathToWrite);
    outputFile.writeAsBytes(await doc.save());
    CommanDialog.pdfOpenDialog(context, "Download successfully",
        "${path.path}/${response.ownerName}.pdf");
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: Theme.of(context).focusColor,
        content: "path.path/${response.ownerName}.pdf"
            .text
            .color(Theme.of(context).accentColor)
            .make(),
        behavior: SnackBarBehavior.floating,
        duration: Duration(milliseconds: 3)));
  }
}

getProcessBar() {
  return Center(
    child: CircularProgressIndicator(),
  );
}

getSearchingLottieFile() {
  return Lottie.asset(
    "assets/lottie/alertno.json",
    height: 200,
    width: 200,
  ).pOnly(top: 80);
}
