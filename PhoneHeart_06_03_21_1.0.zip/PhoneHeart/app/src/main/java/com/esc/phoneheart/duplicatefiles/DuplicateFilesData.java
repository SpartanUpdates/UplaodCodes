package com.esc.phoneheart.duplicatefiles;

import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DuplicateFilesData {
    public int currentGroupChildIndex;
    public int currentGroupIndex;
    public ArrayList<BigSizeFilesWrapper> currentList;
    public ArrayList<DuplicateFileMediaData> duplicateFilesMediaDataList = new ArrayList();
    public Map<Integer, ArrayList<BigSizeFilesWrapper>> duplicateGridAudios;
    public Map<Integer, ArrayList<BigSizeFilesWrapper>> duplicateGridDocs;
    public Map<Integer, ArrayList<BigSizeFilesWrapper>> duplicateGridImages;
    public Map<Integer, ArrayList<BigSizeFilesWrapper>> duplicateGridVideo;
    public HashMap<Long, ArrayList<BigSizeFilesWrapper>> mediaMap = new HashMap();
    public long recoveredSpace;
    public ArrayList<DupFileMediaMapData> selectedList;
    public int totalDuplicates;
    public long totalDuplicatesSize;
    public long totalGroups;
    public long totalItems;
    public long totalSelectedItems;
    public long totalSelectedSize;
    public long totalSize;

    public void addMediaData(DuplicateFileMediaData duplicateFileMediaData) {
        this.duplicateFilesMediaDataList.add(duplicateFileMediaData);
    }

    public ArrayList<DupFileMediaMapData> getPerticulerDupFileDataList(String str) {
        for (int i = 0; i < this.duplicateFilesMediaDataList.size(); i++) {
            if (((DuplicateFileMediaData) this.duplicateFilesMediaDataList.get(i)).mediaName.equalsIgnoreCase(str)) {
                return ((DuplicateFileMediaData) this.duplicateFilesMediaDataList.get(i)).fileTypeDataList;
            }
        }
        return new ArrayList();
    }

    public void refresh() {
        this.totalDuplicates = 0;
        this.totalDuplicatesSize = 0;
        for (int i = 0; i < this.duplicateFilesMediaDataList.size(); i++) {
            ArrayList arrayList = ((DuplicateFileMediaData) this.duplicateFilesMediaDataList.get(i)).fileTypeDataList;
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                for (int i3 = 0; i3 < ((DupFileMediaMapData) arrayList.get(i2)).list.size(); i3++) {
                    if (i3 != 0) {
                        this.totalDuplicates++;
                        this.totalDuplicatesSize += ((BigSizeFilesWrapper) ((DupFileMediaMapData) arrayList.get(i2)).list.get(i3)).size;
                    }
                }
            }
        }
    }

    public void removeNode(BigSizeFilesWrapper bigSizeFilesWrapper) {
        this.recoveredSpace += bigSizeFilesWrapper.size;
    }

    public void selectNode(BigSizeFilesWrapper bigSizeFilesWrapper) {
        this.totalSelectedSize += bigSizeFilesWrapper.size;
        this.totalSelectedItems++;
    }

    public void unselectNode(BigSizeFilesWrapper bigSizeFilesWrapper) {
        this.totalSelectedSize -= bigSizeFilesWrapper.size;
        this.totalSelectedItems--;
    }
}
