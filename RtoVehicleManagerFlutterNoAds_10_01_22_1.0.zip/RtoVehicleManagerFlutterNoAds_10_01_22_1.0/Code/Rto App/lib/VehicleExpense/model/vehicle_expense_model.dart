class VehicleExpenseModel {
  final String randomId;
  final String date;
  final String itemName;
  final String note;
  final String amount;
  final String type;

  VehicleExpenseModel(
      {required this.randomId,
      required this.date,
      required this.itemName,
      required this.note,
      required this.amount,
      required this.type});

  VehicleExpenseModel.fromMap(Map<String, dynamic> res)
      : randomId = res['randomId'],
        date = res['date'],
        itemName = res['itemName'],
        note = res['note'],
        amount = res['amount'],
        type = res['type'];

  Map<String, Object?> toMap() {
    return {
      'randomId': randomId,
      'date': date,
      'itemName': itemName,
      'note': note,
      'amount': amount,
      'type': type
    };
  }
}
