package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.Target;
import com.kotlinz.videoCollage.Utilss;
import com.kotlinz.videoCollage.interfaces.RatioAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

public class RatioAdapter extends RecyclerView.Adapter<RatioAdapter.ViewHolder> {
    private Context context;
    public RatioAdapterCallBackInterface listener;
    public int pos = -1;
    private int[] ratioIconImages;
    private int[] ratioImages;
    private String[] ratioList;

    public RatioAdapter(String[] strArr, int[] iArr, Context context2, RatioAdapterCallBackInterface ratioAdapterCallBackInterface) {
        this.ratioList = strArr;
        this.ratioImages = iArr;
        //this.ratioIconImages = iArr2;
        this.listener = ratioAdapterCallBackInterface;
        this.context = context2;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_ratio, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.txtSize.setText(this.ratioList[i]);
        if (pos == i) {
            Glide.with(context).load(Utilss.INSTANCE.CatThumbPress(ratioList[i])).override(Target.SIZE_ORIGINAL).into(viewHolder.imageIcon);
        } else {
            Glide.with(context).load(Utilss.INSTANCE.CatThumb(ratioList[i])).override(Target.SIZE_ORIGINAL).into(viewHolder.imageIcon);
        }

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                pos = i;
                RatioAdapter.this.listener.itemClick(i);
                notifyDataSetChanged();
            }
        });
    }

    public int getItemCount() {
        return this.ratioList.length;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageIcon;
        RelativeLayout mainLin;
        TextView txtSize;

        ViewHolder(View view) {
            super(view);
            this.txtSize = (TextView) view.findViewById(R.id.ratio_text);
            this.imageIcon = (ImageView) view.findViewById(R.id.ratio_icon_image);
            this.mainLin = view.findViewById(R.id.main_lin);
        }
    }
}
