package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Font_8 implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"ꋫ", "ꃃ", "ꏸ", "ꁕ", "ꍟ", "ꄘ", "ꁍ", "ꑛ", "ꂑ", "ꀭ", "ꀗ", "꒒", "ꁒ", "ꁹ", "ꆂ", "ꉣ", "ꁸ", "꒓", "ꌚ", "꓅", "ꐇ", "ꏝ", "ꅐ", "ꇓ", "ꐟ", "ꁴ"};
    }

    public String getName() {
        return "ꋫꃃꏸ";
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"ꋫ", "ꃃ", "ꏸ", "ꁕ", "ꍟ", "ꄘ", "ꁍ", "ꑛ", "ꂑ", "ꀭ", "ꀗ", "꒒", "ꁒ", "ꁹ", "ꆂ", "ꉣ", "ꁸ", "꒓", "ꌚ", "꓅", "ꐇ", "ꏝ", "ꅐ", "ꇓ", "ꐟ", "ꁴ"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public float getSizeFactorKeys() {
        return DefaultImpls.getSizeFactorKeys(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
