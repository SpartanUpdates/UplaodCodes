package com.kotlinz.festivalstorymaker.Utils;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;

import com.kotlinz.festivalstorymaker.Other.a;
import com.kotlinz.festivalstorymaker.R;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class Utils {

    public static int[][] f;


    public static Bitmap g(Context context, Uri uri) {
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(context.getContentResolver(), uri);
            if (bitmap == null) {
                return null;
            }
            float min = Math.min(50.0f / ((float) bitmap.getWidth()), 50.0f / ((float) bitmap.getHeight()));
            return Bitmap.createScaledBitmap(bitmap, Math.round(((float) bitmap.getWidth()) * min), Math.round(min * ((float) bitmap.getHeight())), true);
        } catch (Exception unused) {
            throw new IllegalArgumentException("Error creating bitmap from URI");
        }
    }


    public static int[][] s(Bitmap bitmap) {
        int width = bitmap.getWidth();
        f = (int[][]) Array.newInstance(int.class, new int[]{bitmap.getHeight(), width});
        for (width = 0; width < bitmap.getWidth(); width++) {
            for (int i = 0; i < bitmap.getHeight(); i++) {
                f[width][i] = bitmap.getPixel(width, i);
            }
        }
        return f;
    }

    public static Bitmap getBitmapFromURL(String imageUrl) {
        try {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    public static String getPath(Context context, Uri uri) {
        String result = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = context.getContentResolver().query(uri, proj, null, null, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int column_index = cursor.getColumnIndexOrThrow(proj[0]);
                result = cursor.getString(column_index);
            }
            cursor.close();
        }
        if (result == null) {
            result = "Not found";
        }
        return result;
    }


    public static boolean c(Activity activity) {
        String[] strArr = com.kotlinz.festivalstorymaker.Other.Utils.e;
        int length = strArr.length;
        int i = 0;
        boolean z = false;
        while (i < length) {
            if (a.a(activity, strArr[i]) == 0) {
                i++;
                z = true;
            } else {
                ArrayList arrayList = new ArrayList();
                for (String str : com.kotlinz.festivalstorymaker.Other.Utils.e) {
                    if (a.a(activity, str) != 0) {
                        arrayList.add(str);
                    }
                }
                if (arrayList.isEmpty()) {
                    return false;
                }
                a.m(activity, (String[]) arrayList.toArray(new String[arrayList.size()]), 144);
                return false;
            }
        }
        return z;
    }

    public static int ModuleImage(String str) {
        str = str.toLowerCase();
        return str.contains("poster maker") ? R.drawable.ic_postermaker_unpress : str.contains("story maker") ? R.drawable.ic_storymaker_unpress : str.contains("festival") ? R.drawable.ic_festivalmaker_unpress : str.contains("collage maker") ? R.drawable.ic_collagemaker_unpress : str.contains("quote maker") ? R.drawable.ic_quotemaker_unpress : str.contains("zoom collage") ? R.drawable.ic_zoomcollage_unpress : str.contains("offer poster") ? R.drawable.ic_offerposter_unpress : str.contains("predesign artbord") ? R.drawable.ic_predesignartbrod_unpress : str.contains("thematic template") ? R.drawable.ic_thematictemplate_unpress : str.contains("wish maker") ? R.drawable.ic_wishmaker_unpress : R.drawable.ic_launcher_background;
    }

    public static int ModuleImagePress(String str) {
        str = str.toLowerCase();
        return str.contains("poster maker") ? R.drawable.ic_postermaker_press : str.contains("story maker") ? R.drawable.ic_storymaker_press : str.contains("festival") ? R.drawable.ic_festivalmaker_press : str.contains("collage maker") ? R.drawable.ic_collagemaker_press : str.contains("quote maker") ? R.drawable.ic_quotemaker_press : str.contains("zoom collage") ? R.drawable.ic_zoomcollage_press : str.contains("offer poster") ? R.drawable.ic_offerposter_press : str.contains("predesign artbord") ? R.drawable.ic_predesignartbord_press : str.contains("thematic template") ? R.drawable.ic_thematictemplate_press : str.contains("wish maker") ? R.drawable.ic_wishmaker_press : R.drawable.ic_launcher_background;
    }

    public static int PosterMakerCategory(String str) {
        str = str.toLowerCase();
        return str.contains("means' outfit") ? R.drawable.ic_mensoutfitunpress : str.contains("womens outfit") ? R.drawable.ic_womensoutfit_unpress : str.contains("furtunire") ? R.drawable.ic_furnitureunpress : str.contains("foot ware") ? R.drawable.ic_footware_unpress : str.contains("jewellery") ? R.drawable.ic_jewellery_unpress : str.contains("sunglasses") ? R.drawable.ic_sunglasses_unpress : str.contains("art & decore") ? R.drawable.ic_artdecore_unpress : str.contains("bath ware") ? R.drawable.ic_bathware_unpress : str.contains("ceramic") ? R.drawable.ic_ceramic_unpress : str.contains("handbags") ? R.drawable.ic_handbags_unpress : str.contains("handicraft") ? R.drawable.ic_handicraft_unpress : str.contains("hardware") ? R.drawable.ic_hardware_unpress : str.contains("kitchenware") ? R.drawable.ic_kitchenware_unpress : str.contains("laminate") ? R.drawable.ic_laminate_unpress : str.contains("lighting") ? R.drawable.ic_lighting_unpress : str.contains("mobile") ? R.drawable.ic_mobile_unpress : str.contains("perfumes") ? R.drawable.ic_prefumes_unpress : str.contains("salon") ? R.drawable.ic_saloon_unpress : str.contains("wallets") ? R.drawable.ic_wallets_unpress : str.contains("watch's") ? R.drawable.ic_watches_unpress : R.drawable.ic_default_unpress;
    }

    public static int PosterMakerCategoryPress(String str) {
        str = str.toLowerCase();
        return str.contains("means' outfit") ? R.drawable.ic_mensoutfit_press : str.contains("womens outfit") ? R.drawable.ic_womensfit_press : str.contains("furtunire") ? R.drawable.ic_furniture_press : str.contains("foot ware") ? R.drawable.ic_footware_press : str.contains("jewellery") ? R.drawable.ic_jewellery_press : str.contains("sunglasses") ? R.drawable.ic_sunglasses_press : str.contains("art & decore") ? R.drawable.ic_artdecore_press : str.contains("bath ware") ? R.drawable.ic_bathware_press : str.contains("ceramic") ? R.drawable.ic_cramic_press : str.contains("handbags") ? R.drawable.ic_handbags_press : str.contains("handicraft") ? R.drawable.ic_handicraft_press : str.contains("hardware") ? R.drawable.ic_hardware_press : str.contains("kitchenware") ? R.drawable.ic_kitchenware_press : str.contains("laminate") ? R.drawable.ic_laminate_press : str.contains("lighting") ? R.drawable.ic_lighting_press : str.contains("mobile") ? R.drawable.ic_mobile_press : str.contains("perfumes") ? R.drawable.ic_prefumes_press : str.contains("salon") ? R.drawable.ic_saloon_press : str.contains("wallets") ? R.drawable.ic_wallets_press : str.contains("watch's") ? R.drawable.ic_watches_press : R.drawable.ic_default_press;
    }

    public static int StoryMakerCategory(String str) {
        str = str.toLowerCase();
        return str.contains("abstract") ? R.drawable.ic_abstract_unpress : str.contains("floral") ? R.drawable.ic_foral_unpress : str.contains("minimal") ? R.drawable.ic_minimal_unpress : str.contains("polaroid") ? R.drawable.ic_polaroid_unpress : str.contains("stroke") ? R.drawable.ic_stroke_unpress : str.contains("camera roll") ? R.drawable.ic_cameraroll_unpress : str.contains("paper cut") ? R.drawable.ic_papercut_unpress : str.contains("brush") ? R.drawable.ic_brush_unpress : str.contains("classical") ? R.drawable.ic_classical_unpress : str.contains("trendy") ? R.drawable.ic_trendy_unpress : str.contains("ceramics") ? R.drawable.ic_paceramic_unpress : str.contains("birthday") ? R.drawable.ic_birthday_unpress : str.contains("anniversary") ? R.drawable.ic_anniversary_unpress : str.contains("general") ? R.drawable.ic_general_unpress : R.drawable.ic_default_unpress;
    }

    public static int StoryMakerCategoryPress(String str) {
        str = str.toLowerCase();
        return str.contains("abstract") ? R.drawable.ic_abstract_press : str.contains("floral") ? R.drawable.ic_foral_press : str.contains("minimal") ? R.drawable.ic_minimal_press : str.contains("polaroid") ? R.drawable.ic_polaroid_press : str.contains("stroke") ? R.drawable.ic_stroke_press : str.contains("camera roll") ? R.drawable.ic_cameraroll_press : str.contains("paper cut") ? R.drawable.ic_papercut_press : str.contains("brush") ? R.drawable.ic_brush_press : str.contains("classical") ? R.drawable.ic_classical_press : str.contains("trendy") ? R.drawable.ic_trendy_press : str.contains("ceramics") ? R.drawable.ic_paceramic_press : str.contains("birthday") ? R.drawable.ic_birthday_press : str.contains("anniversary") ? R.drawable.ic_anniversary_press : str.contains("general") ? R.drawable.ic_general_press : R.drawable.ic_default_press;
    }
}
