package com.kotlinz.festivalstorymaker.esafirm.imagepicker.listeners;

public interface OnImageClickListener {
    boolean onImageClick(boolean isSelected);
}
