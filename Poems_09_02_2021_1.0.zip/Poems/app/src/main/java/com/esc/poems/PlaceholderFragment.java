package com.esc.poems;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import androidx.appcompat.app.AlertDialog.Builder;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class PlaceholderFragment extends Fragment {
    private static final String ARG_SECTION_NUMBER = "section_number";
    private static int catid;
    private static Context con;
    private static String sss;
    private ListView SubcatList;
    private String TAG = "PlaceholderFragment";
    private SubListAdapter adapter;
    private ArrayList<String> count;
    private ArrayList<String> subcat;
    private ArrayList<String> subcatid;

    public static Fragment newInstance(int i, Context context, String str) {
        catid = i;
        con = context;
        sss = str;
        PlaceholderFragment placeholderFragment = new PlaceholderFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, i);
        placeholderFragment.setArguments(bundle);
        return placeholderFragment;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_main, viewGroup, false);
        this.SubcatList = inflate.findViewById(R.id.SubcatList);
        int i = catid;
        final Bundle bundle2;
        if (i == 0) {
            MainActivity.gv.setVisibility(View.VISIBLE);
            this.SubcatList.setVisibility(View.INVISIBLE);
            MainActivity.onback = true;
        } else if (i == 1) {
            System.gc();
            bundle2 = new Bundle();
            bundle2.putString("cat", "Top100");
            MainActivity.gv.setVisibility(View.VISIBLE);
            this.SubcatList.setVisibility(View.INVISIBLE);
            startActivity(new Intent(getActivity(), TopCategoryActivity.class));
            MainActivity.onback = true;
        } else {
            String str = "menuClicked";
            String str2 = "list";
            if (i == 2 && sss.contains(str2)) {
                MainActivity.gv.setVisibility(View.VISIBLE);
                this.SubcatList.setVisibility(View.INVISIBLE);
                MainActivity.onback = true;
                bundle2 = new Bundle();
                String str3 = "Users_Poem";
                bundle2.putString(str, str3);
                Map hashMap = new HashMap();
                hashMap.put(str, str3);
                startActivity(new Intent(con, UsersPoemsActivity.class));
            } else if (catid == 3 && sss.contains(str2)) {
                MainActivity.gv.setVisibility(View.VISIBLE);
                this.SubcatList.setVisibility(View.INVISIBLE);
                MainActivity.onback = true;
                bundle2 = new Bundle();
                String str4 = "Submit_Your_Poem";
                bundle2.putString(str, str4);
                final Map hashMap2 = new HashMap();
                hashMap2.put(str, str4);
                Builder builder = new Builder(getActivity());
                builder.setPositiveButton("Email", new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String str = "Email";
                        String str2 = "opt";
                        bundle2.putString(str2, str);
                        hashMap2.put(str2, str);
                        Intent intent = new Intent("android.intent.action.SEND");
                        intent.putExtra("android.intent.extra.EMAIL", new String[]{"support@touchzing.com "});
                        intent.putExtra("android.intent.extra.SUBJECT", "[Poems For All Occasions]");
                        intent.putExtra("android.intent.extra.TEXT", "Write your original poem below.\nMention your firstname, lastname and location(State, Country).\n");
                        intent.setType("text/html");
                        intent.setPackage("com.google.android.gm");
                        PlaceholderFragment.this.startActivity(Intent.createChooser(intent, "Send mail"));
                    }
                });
                builder.setNegativeButton("Cancel", new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String str = "Cancel";
                        String str2 = "opt";
                        bundle2.putString(str2, str);
                        hashMap2.put(str2, str);
                    }
                });
                builder.setMessage("If you wish to share your original poem with the world, email it to us.\nWe will add it on the app.").setTitle("Submit Your Poem");
                builder.setCancelable(false);
                builder.create().show();
            } else {
                if (sss.contains(str2)) {
                    catid -= 4;
                } else {
                    catid -= 2;
                }
                this.subcat = MainActivity.DBhelper.getSubCategory(Integer.parseInt(MainActivity.categoryid.get(catid)));
                this.count = MainActivity.DBhelper.getMessagesCount(Integer.parseInt(MainActivity.categoryid.get(catid)));
                this.subcatid = MainActivity.DBhelper.getSubCategoryId(Integer.parseInt(MainActivity.categoryid.get(catid)));
                SubListAdapter subListAdapter = new SubListAdapter(con, this.subcat, this.count);
                this.adapter = subListAdapter;
                this.SubcatList.setAdapter(subListAdapter);
                MainActivity.gv.setVisibility(View.INVISIBLE);
                this.SubcatList.setVisibility(View.VISIBLE);
                MainActivity.onback = false;
                if (sss.contains(str2)) {
                    catid += 4;
                } else {
                    catid += 2;
                }
            }
        }
        this.SubcatList.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                String access$000 = PlaceholderFragment.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("tracker - ");
                stringBuilder.append(MainActivity.catt[PlaceholderFragment.catid]);
                stringBuilder.append("  SUBCAT  ");
                stringBuilder.append(PlaceholderFragment.this.subcat.get(i));
                stringBuilder.append(" ##################    ");
                stringBuilder.append(PlaceholderFragment.this.subcatid.get(i));
                Log.e(access$000, stringBuilder.toString());
                Bundle bundle = new Bundle();
                bundle.putString("subcat", PlaceholderFragment.this.subcat.get(i));
                Intent intent = new Intent(PlaceholderFragment.this.getActivity(), Second1.class);
                Bundle bundle2 = new Bundle();
                bundle2.putString("subcatid", PlaceholderFragment.this.subcatid.get(i));
                bundle2.putString("categroy", MainActivity.catt[PlaceholderFragment.catid]);
                bundle2.putString("subcatname", PlaceholderFragment.this.subcat.get(i));
                intent.putExtras(bundle2);
                PlaceholderFragment.this.startActivity(intent);
            }
        });
        return inflate;
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        ((MainActivity) activity).onSectionAttached(getArguments().getInt(ARG_SECTION_NUMBER));
    }
}
