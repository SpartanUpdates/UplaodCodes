package com.kotlinz.vehiclemanager.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class StateList {
    @SerializedName("name")
    public String stateName;
    @SerializedName("cityList")
    public ArrayList<CityList> cityLists = null;

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public ArrayList<CityList> getCityLists() {
        return cityLists;
    }

    public void setCityLists(ArrayList<CityList> cityLists) {
        this.cityLists = cityLists;
    }
}
