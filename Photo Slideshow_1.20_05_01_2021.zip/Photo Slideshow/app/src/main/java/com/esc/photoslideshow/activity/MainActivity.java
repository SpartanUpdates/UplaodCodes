package com.esc.photoslideshow.activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Dialog;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.app.Service;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.esc.photoslideshow.sidemenu.model.SlideMenuItem;
import com.esc.photoslideshow.sidemenu.sample.fragment.ContentFragment;
import com.esc.photoslideshow.util.service.CreateVideoServicenew;
import com.esc.photoslideshow.util.service.ImageCreatorServicenew;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.esc.photoslideshow.MyApplication;
import com.esc.photoslideshow.R;
import com.esc.photoslideshow.util.ActivityAnimUtil;
import com.esc.photoslideshow.util.EPreferences;
import com.esc.photoslideshow.util.PermissionModelUtil;
import com.esc.photoslideshow.util.Utils;
import com.esc.photoslideshow.util.apprater.AppRater;
import com.esc.photoslideshow.util.service.CreateVideoService;
import com.esc.photoslideshow.util.service.ImageCreatorService;

import java.util.ArrayList;
import java.util.List;

import static com.esc.photoslideshow.view.CustomNativeAd.populateUnifiedNativeAdView;
import static com.esc.photoslideshow.view.CustomNativeAd.populateUnifiedNativeAdViewbig;


public class MainActivity extends AppCompatActivity implements OnClickListener {
    private LinearLayout linearLayout;
    private static final int RequestPermissionCode = 222;
    static int anInt;
    View view;
    private List<SlideMenuItem> list = new ArrayList();
    EPreferences ePreferences;
    EPreferences ePreferences1;
    ComponentName SecurityComponentName = null;
    PermissionModelUtil permissionModelUtil;

    private UnifiedNativeAd nativeAd;

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        if (this.isVideoInprocess()) {
            this.startActivity(new Intent(this, ProgressActivity.class));
            this.overridePendingTransition(0, 0);
            this.finish();
            return;
        } else if (this.isVideoInprocessnew()) {
            this.startActivity(new Intent(this, ProgressActivity.class));
            this.overridePendingTransition(0, 0);
            this.finish();
            return;
        }
        this.setContentView(R.layout.activity_main);
        this.ePreferences = EPreferences.getInstance(this);
        this.ePreferences1 = EPreferences.getInstance1(this);
        this.setActionBar();
        this.init();
        this.createMenuList();
        this.addListener();
        loadAd();
        MyApplication.getInstance().setAutostartAppName();
        if (MyApplication.getInstance().runApp(Utils.autostart_app_name, 0) && !this.check_permission()) {
            this.permissionDialog();
        }
        AppRater.setPackageName(this.getPackageName());
        AppRater.app_launched(this);
        if (!this.ePreferences1.getBoolean("privacy_policy", false)) {
            PolicyDialog();
        }
        PutAnalyticsEvent();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MainActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void PolicyDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_policy);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ePreferences1.putBoolean("privacy_policy", true);
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    private void createMenuList() {
        this.list.add(new SlideMenuItem(ContentFragment.CLOSE, R.drawable.icn_close));
        this.list.add(new SlideMenuItem(ContentFragment.RATEUS, R.drawable.icon_rate_us));
        this.list.add(new SlideMenuItem(ContentFragment.SHARE, R.drawable.icon_share));
        this.list.add(new SlideMenuItem(ContentFragment.MORE, R.drawable.more));
        this.list.add(new SlideMenuItem(ContentFragment.PRIVACY, R.drawable.cloud));

    }

    public boolean check_permission() {
        return this.ePreferences.getBoolean("HasAutoStartPermission", false);
    }


    private void permissionDialog() {
        String str = Build.MANUFACTURER;
        if (str.equals("Xiaomi")) {

            this.SecurityComponentName = new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity");
            Utils.autostart_app_name = "Security";

        } else if (str.equals("asus")) {

            this.SecurityComponentName = new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity");
            Utils.autostart_app_name = "Auto-start Manager";

        }
        Intent intent = new Intent(this, ActivityPermission.class);
        intent.putExtra("PACKAGE", this.SecurityComponentName);
        intent.putExtra("APPNAME", Utils.autostart_app_name);
        startActivity(intent);
    }


    private boolean isVideoInprocess() {
        return MyApplication.isMyServiceRunning(this, CreateVideoService.class) || MyApplication.isMyServiceRunning(this, ImageCreatorService.class);
    }

    private boolean isVideoInprocessnew() {
        return MyApplication.isMyServiceRunning(this, CreateVideoServicenew.class) || MyApplication.isMyServiceRunning(this, ImageCreatorServicenew.class);
    }

    private void init() {
        Utils.isVideoCreationRunning = true;
        if (Utils.checkPermission(this)) {
            MyApplication.getInstance().getFolderList();
        } else {
            Utils.requestPermission(this);
        }
        ((NotificationManager) getSystemService(Service.NOTIFICATION_SERVICE)).cancel(307);
    }

    protected void onResume() {
        super.onResume();
        if (anInt == 1) {
            anInt = 0;
            if (Utils.checkPermission(this)) {
                onStart();
            } else {
                Utils.requestPermission(this);
            }
        }
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int n, @NonNull final String[] array, @NonNull final int[] array2) {
        if (n != 222) {
            return;
        }
        if (array2.length > 0) {
            boolean b = false;
            if (array2[0] == 0) {
                n = 1;
            } else {
                n = 0;
            }
            if (array2[1] == 0) {
                b = true;
            }
            if (n != 0 && b) {
                MyApplication.getInstance().getFolderList();
                return;
            }
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.READ_EXTERNAL_STORAGE") && !ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
                Utils.permissionDailog(this);
                return;
            }
            Utils.requestPermission(this);
        }
    }

    private void addListener() {
        findViewById(R.id.btnCreateVideo).setOnClickListener(this);
        findViewById(R.id.btnViewVideo).setOnClickListener(this);
    }

    public void onClick(View view) {
        this.view = view;
        int id = view.getId();
        if (id == R.id.btnCreateVideo) {
            idd = 100;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                if (Utils.checkPermission(this)) {
                    AsyncTaskRunner1 runner1 = new AsyncTaskRunner1();
                    runner1.execute("");
                }
                Utils.requestPermission(this);

            }
        } else if (id == R.id.btnViewVideo) {
            idd = 101;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                loadVideoList();
            }
        } else {
            this.permissionModelUtil.showPermissionExplanationThenAuthorization();
        }
//        if (id != R.id.btnChangeLang) {
//            if (id != R.id.btnCreateVideo) {
//                if (id == R.id.btnViewVideo) {
//                    if (Utils.checkPermission(this)) {
//                        if (interstitial != null && interstitial.isAdLoaded()) {
//                            interstitial.showAd();
//                        } else {
//                            loadVideoList(view);
//                        }
//
//                    }
//                    Utils.requestPermission(this);
//                }
//            } else if (Utils.checkPermission(this)) {
//                AsyncTaskRunner1 runner1 = new AsyncTaskRunner1();
//                runner1.execute("");
//
//            } else {
//                Utils.requestPermission(this);
//            }
//        } else {
//            this.permissionModelUtil.showPermissionExplanationThenAuthorization();
//        }
    }

    private void loadVideoList() {
        if (Utils.checkPermission(this)) {
            Intent intent = new Intent(MainActivity.this, ActivityVideoAlbum.class);
            startActivity(intent);
        }
        Utils.requestPermission(this);

    }

    private void loadCreateVideo(View view) {
        if (MyApplication.getInstance().getAllFolder().size() > 0) {
            MyApplication.isStoryAdded = false;
            MyApplication.isBreak = false;
            MyApplication.getInstance().setMusicData(null);
            ActivityAnimUtil.startActivitySafely(view, new Intent(MainActivity.this, PhotoselectActivity.class));
        }
    }

    private class AsyncTaskRunner1 extends AsyncTask<String, String, String> {

        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            init();
            MyApplication.getInstance().getFolderList();
            if (MyApplication.getInstance().getAllFolder().size() > 0) {
                loadCreateVideo(view);
                return "";
            }
            return "Null";
        }

        @Override
        protected void onPostExecute(String result) {
            if (result.equalsIgnoreCase("Null")) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.no_images_found_in_device_please_add_images_in_sdcard), Toast.LENGTH_SHORT).show();
            }
            progressDialog.dismiss();
        }


        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(MainActivity.this,
                    "Loading Images",
                    "Please Wait...");
        }


        @Override
        protected void onProgressUpdate(String... text) {
        }
    }

    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(MainActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                dialog.findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    ePreferences.putBoolean("pref_key_rate", true);
                    dialog.dismiss();
                    if (isRate[0]) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                dialog.findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        dialog.show();
    }

    private void setActionBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        TextView textView = toolbar.findViewById(R.id.toolbar_title);
        textView.setText(getString(R.string.app_name));
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        Utils.setFont(this, textView);
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }


    public boolean onOptionsItemSelected(MenuItem menuItem) {
        return true;
    }

//    public void AdsDialogShow() {
//        Handler mHandler = new Handler();
//        mHandler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//
//                dialogAd.dismiss();
//            }
//        }, 2000);
//    }

    private InterstitialAd mInterstitialAd;
    int idd;

    private void loadAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getString(R.string.admobNativeAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_native, null);
                populateUnifiedNativeAdViewbig(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(true)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());

        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(this.getString(R.string.admob_inter));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (idd) {
                    case 100:
                        if (Utils.checkPermission(MainActivity.this)) {
                            AsyncTaskRunner1 runner1 = new AsyncTaskRunner1();
                            runner1.execute("");
                        }
                        Utils.requestPermission(MainActivity.this);
                        break;
                    case 101:
                        loadVideoList();
                        break;

                }
                requestNewInterstitial();
            }
        });
    }

    private void requestNewInterstitial() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }
}
