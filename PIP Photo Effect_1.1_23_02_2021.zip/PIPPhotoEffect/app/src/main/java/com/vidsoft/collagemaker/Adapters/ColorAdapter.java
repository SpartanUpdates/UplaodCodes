package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;

import androidx.multidex.BuildConfig;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import java.util.ArrayList;

public class ColorAdapter extends Adapter<ColorAdapter.ViewHolder> {
    String Selection;
    Activity activity;
    LayoutInflater inflater;
    ArrayList<Integer> list;

    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout border;
        LinearLayout colorLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            this.colorLayout = (LinearLayout) itemView.findViewById(R.id.ll_colorLayout);
            this.border = (RelativeLayout) itemView.findViewById(R.id.rl_border);
        }
    }

    public ColorAdapter(Activity activity, ArrayList<Integer> list) {
        this.Selection = BuildConfig.FLAVOR;
        this.inflater = LayoutInflater.from(activity);
        this.activity = activity;
        this.list = list;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.color_adapter, parent, false));
    }

    public void onBindViewHolder(ViewHolder holder, int position) {
        if (this.Selection.equals(BuildConfig.FLAVOR)) {
            holder.border.setVisibility(View.GONE);
        } else if (position == Integer.parseInt(this.Selection)) {
            holder.border.setVisibility(View.VISIBLE);
        } else {
            holder.border.setVisibility(View.GONE);
        }
        holder.colorLayout.setBackgroundColor(((Integer) this.list.get(position)).intValue());
    }

    public int getItemCount() {
        return this.list.size();
    }

    public void setSelection(int position) {
        this.Selection = String.valueOf(position);
        notifyDataSetChanged();
    }
}