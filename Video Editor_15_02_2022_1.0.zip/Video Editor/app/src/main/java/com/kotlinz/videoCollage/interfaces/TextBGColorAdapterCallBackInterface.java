package com.kotlinz.videoCollage.interfaces;

public interface TextBGColorAdapterCallBackInterface {
    void itemClick(int i);
}
