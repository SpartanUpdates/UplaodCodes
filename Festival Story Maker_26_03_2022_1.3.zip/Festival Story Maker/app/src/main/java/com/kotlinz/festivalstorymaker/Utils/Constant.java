package com.kotlinz.festivalstorymaker.Utils;


public class Constant {
    public static int Camera = 100;
    public static int NoofImage;
    public static String ImageFrame;
    public static String TextFilePath;
    public static  String FolderPath;
    public static String IsFromPoster = "Poster";
    public static String IsFromStory = "Story";
}
