package com.rtovehicleinformation.application;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.rtovehicleinformation.Database.OpenSQLite;
import com.rtovehicleinformation.Model.MileageModel;
import com.rtovehicleinformation.Model.PetrolDieselData;
import com.rtovehicleinformation.OpenAppAds.AppOpenAdManager;
import com.rtovehicleinformation.R;
import com.rtovehicleinformation.activity.MainActivity;
import com.rtovehicleinformation.activity.MileageActivity;
import com.rtovehicleinformation.activity.TrafficSymbolsActivity;
import com.rtovehicleinformation.activity.TrendingActivity;
import com.rtovehicleinformation.activity.VehicleDetailActivity;
import com.rtovehicleinformation.activity.VehicleExpenseActivity;
import com.rtovehicleinformation.utils.Utils;

import java.util.ArrayList;
import java.util.List;


public class AppController extends Application implements Application.ActivityLifecycleCallbacks, LifecycleObserver {

    public static String id;
    private static AppController mInstance;
    private static Context context;

    private AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;

    public static InterstitialAd mInterstitialAd;
    public static Activity activity;
    public static int AdsId;

    public List<PetrolDieselData> petrolDieselData = new ArrayList<>();
    public List<PetrolDieselData> search_result_arraylist = new ArrayList();
    public int CityPosition;

    public OpenSQLite openSQLite;
    public MileageModel mileageModel;

    public int TrandingPositiion;

    public String Input1;
    public String Input2;
    public String Input3;

    public String catName;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        context = getApplicationContext();
        id = (new String(Base64.decode(Utils.id + Utils.id2, Base64.DEFAULT)));
        this.registerActivityLifecycleCallbacks(this);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        appOpenAdManager = new AppOpenAdManager();
        interstitialAd();
    }

    public static Context getContext() {
        return context;
    }


    public static synchronized AppController getInstance() {
        return mInstance;
    }

    private void interstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, getResources().getString(R.string.InterstitialAd_id), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        requestNewInterstitial();
                                        switch (AdsId) {
                                            case 1:
                                                Intent intent = new Intent();
                                                if (search_result_arraylist.size() > 0) {
                                                    intent.putExtra("data", search_result_arraylist.get(CityPosition));
                                                } else {
                                                    intent.putExtra("data", petrolDieselData.get(CityPosition));
                                                }
                                                activity.setResult(-1, intent);
                                                activity.finish();
                                                break;
                                            case 2:
                                                activity.finish();
                                                break;
                                            case 3:
                                                activity.startActivity(new Intent(activity, VehicleExpenseActivity.class));
                                                activity.finish();
                                                break;
                                            case 4:
                                                activity.startActivity(new Intent(activity, MileageActivity.class));
                                                activity.finish();
                                                break;
                                            case 5:
                                                activity.startActivity(new Intent(activity, VehicleDetailActivity.class));
                                                break;
                                            case 6:
                                                activity.startActivity(new Intent(activity, TrafficSymbolsActivity.class));
                                                break;
                                            case 7:
                                                activity.startActivity(new Intent(activity, TrendingActivity.class));
                                                break;
                                            case 8:
                                                activity.startActivity(new Intent(activity, MainActivity.class));
                                                activity.finish();
                                                break;
                                            case 9:
                                                Save(mileageModel);
                                                break;
                                            case 10:
                                                activity.finish();
                                                break;
                                            case 11:
                                                TrandingItemClick(TrandingPositiion);
                                                break;
                                            case 12:
                                                activity.startActivity(new Intent(activity, TrendingActivity.class));
                                                activity.finish();
                                                break;
                                            case 13:
                                                Log.e("TAG", "Get Data Callled");
                                                break;
                                            case 14:
                                                Log.e("TAG", "Reset Data Called");
                                                break;
                                            case 15:
                                                activity.startActivity(new Intent(activity, MainActivity.class));
                                                activity.finish();
                                                break;
                                        }
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    }
                });

    }

    private void requestNewInterstitial() {
        interstitialAd();
    }

    private void Save(MileageModel mileageModel) {
        if (openSQLite.insrtMileage(mileageModel) > 0) {
            activity.onBackPressed();
        }
    }

    private void TrandingItemClick(int i) {
        if (catName.equals("Mr.Perfect")) {
            substring(Utils.mrperfectsnum[i]);

        } else if (catName.equals("Dancers")) {
            substring(Utils.dancersnum[i]);

        } else if (catName.equals("Singers")) {
            substring(Utils.singersnum[i]);

        } else if (catName.equals("Actors")) {
            substring(Utils.actorsnum[i]);

        } else if (catName.equals("Politicians")) {
            substring(Utils.politiciansnum[i]);

        } else if (catName.equals("Sports Person")) {
            substring(Utils.sportspersonsnum[i]);

        } else if (catName.equals("Actresses")) {
            substring(Utils.actressesnum[i]);
        }
    }

    public void substring(String str) {
        String substring;
        if (Character.isDigit(str.charAt(4))) {
            substring = str.substring(0, 4);
            str = str.substring(4);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = "";
        } else if (Character.isDigit(str.charAt(5))) {
            substring = str.substring(0, 5);
            str = str.substring(5);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = substring.substring(4, 5);
        } else if (Character.isDigit(str.charAt(6))) {
            substring = str.substring(0, 6);
            str = str.substring(6);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = substring.substring(4, 6);
        } else {
            substring = str.substring(0, 7);
            str = str.substring(7);
        }

        Intent intent = new Intent(activity, VehicleDetailActivity.class);
        intent.putExtra("first", Input1);
        intent.putExtra("second", Input2);
        intent.putExtra("third", Input3);
        intent.putExtra("fourth", str);
        activity.startActivity(intent);
    }


    /*AppOpenAds Start*/
    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    protected void onMoveToForeground() {
        appOpenAdManager.showAdIfAvailable(currentActivity);
    }


    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {

        if (!appOpenAdManager.isShowingAd) {
            currentActivity = activity;
        }
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {
    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
    }

    /**
     * Shows an app open ad.
     *
     * @param activity                 the activity that shows the app open ad
     * @param onShowAdCompleteListener the listener to be notified when an app open ad is complete
     */
    public void showAdIfAvailable(
            @NonNull Activity activity,
            @NonNull OnShowAdCompleteListener onShowAdCompleteListener) {
        // We wrap the showAdIfAvailable to enforce that other classes only interact with MyApplication
        // class.
        appOpenAdManager.showAdIfAvailable(activity, onShowAdCompleteListener);
    }

    /**
     * Interface definition for a callback to be invoked when an app open ad is complete
     * (i.e. dismissed or fails to show).
     */
    public interface OnShowAdCompleteListener {
        void onShowAdComplete();
    }

    /*AppOpenAds End*/
}
