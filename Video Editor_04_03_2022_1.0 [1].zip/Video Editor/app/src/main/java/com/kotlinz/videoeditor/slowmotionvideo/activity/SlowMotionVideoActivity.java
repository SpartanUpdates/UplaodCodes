package com.kotlinz.videoeditor.slowmotionvideo.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.provider.MediaStore.Images.Media;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.bumptech.glide.Glide;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.Utils.UtilCommand;
import com.kotlinz.videoeditor.activity.TrimVideoPrivewActivity;
import com.kotlinz.videoeditor.view.VideoPlayerState;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar.SeekBarChangeListener;
import com.kotlinz.videoeditor.editvideo.activity.EditActivity;
import com.kotlinz.videoeditor.slowmotionvideo.Utils.FileUtils;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xw.repo.BubbleSeekBar;
import com.xw.repo.BubbleSeekBar.OnProgressChangedListener;

import java.io.File;
import java.util.concurrent.TimeUnit;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;

@SuppressLint({"WrongConstant"})
public class SlowMotionVideoActivity extends AppCompatActivity {
    Activity activity = SlowMotionVideoActivity.this;
    static boolean j = false;
    static final boolean k = true;
    String a;
    String b = null;
    String c = "00";
    Boolean d = Boolean.valueOf(false);
    ImageView e;
    VideoSliceSeekBar f;
    BubbleSeekBar bubbleSeekBar;
    private float aFloat;
    int h;
    StringBuilder i = new StringBuilder();
    private CheckBox checkBox;
    private PowerManager m;

    public TextView n;

    public TextView o;


    public VideoPlayerState q = new VideoPlayerState();
    private final a r = new a();

    public VideoView videoView;
    private ImageView ivThumbnail;
    private WakeLock t;

    ImageView ivback, ivDone;
    TextView tvToolbarName;


    private class a extends Handler {
        private boolean b;
        private final Runnable c;

        private a() {
            this.b = false;
            this.c = new Runnable() {
                public void run() {
                    SlowMotionVideoActivity.a.this.a();
                }
            };
        }


        public void a() {
            if (!this.b) {
                this.b = SlowMotionVideoActivity.k;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            this.b = false;
            f.videoPlayingProgress(videoView.getCurrentPosition());
            if (!videoView.isPlaying() || SlowMotionVideoActivity.this.videoView.getCurrentPosition() >= SlowMotionVideoActivity.this.f.getRightProgress()) {
                if (videoView.isPlaying()) {
                    videoView.pause();
                    d = Boolean.valueOf(false);
                    e.setBackgroundResource(R.drawable.ic_play_upress);
                }
                f.setSliceBlocked(false);
                f.removeVideoStatusThumb();
                return;
            }
            postDelayed(c, 50);
        }
    }

    @SuppressLint({"ClickableViewAccessibility", "InvalidWakeLockTag"})
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.slowmotionvideoactivity);
        PutAnalyticsEvent();
        d();
        m = (PowerManager) getSystemService(Context.POWER_SERVICE);
        t = m.newWakeLock(6, "My Tag");
        Object lastNonConfigurationInstance = getLastNonConfigurationInstance();
        if (lastNonConfigurationInstance != null) {
            q = (VideoPlayerState) lastNonConfigurationInstance;
        } else {
            Bundle extras = getIntent().getExtras();
            q.setFilename(extras.getString("videofilename"));
            b = extras.getString("videofilename");
            MyApplication.getInstance().VideoFileName = b;
            extras.getString("videofilename").split("/");
        }
        tvToolbarName = findViewById(R.id.tv_app_name);
        ivback = findViewById(R.id.iv_back);
        ivDone = findViewById(R.id.iv_done);
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (videoView.isPlaying()) {
                    videoView.pause();
                    e.setBackgroundResource(R.drawable.ic_play_upress);
                }
                videoView.start();
                if (q.isValid()) {
                    slowmotioncommand();
                }
            }
        });
        this.videoView.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                d = Boolean.valueOf(false);
                e.setBackgroundResource(R.drawable.ic_play_upress);
            }
        });
        this.videoView.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (d.booleanValue()) {
                    videoView.pause();
                    d = Boolean.valueOf(false);
                    e.setBackgroundResource(R.drawable.ic_play_upress);
                }
                return SlowMotionVideoActivity.k;
            }
        });
        g();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SlowMotionVideoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public void c() {
        Intent intent = new Intent(getApplicationContext(), TrimVideoPrivewActivity.class);
        intent.putExtra("videofilename", b);
        startActivity(intent);
        finish();
    }

    public void slowmotioncommand() {
        String[] strArr = new String[0];
        String valueOf = String.valueOf(q.getStart() / 1000);
        String.valueOf(q.getStop() / 1000);
        String valueOf2 = String.valueOf(q.getDuration() / 1000);
        String filename = q.getFilename();
        b = FileUtils.getTargetFileName(activity, filename);
        j = k;
        if (h == 1) {
            strArr = new String[]{"-y", "-i", filename, "-filter_complex", "[0:v]setpts=6.0*PTS[v];[0:a]atempo=0.5,atempo=0.5,atempo=0.5[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", b};
        } else if (h == 2) {
            strArr = new String[]{"-y", "-i", filename, "-filter_complex", "[0:v]setpts=2.0*PTS[v];[0:a]atempo=0.5[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", b};
        } else if (h == 3) {
            strArr = new String[]{"-y", "-i", filename, "-filter_complex", "[0:v]setpts=3.0*PTS[v];[0:a]atempo=0.5,atempo=0.5[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", b};
        } else if (h == 4) {
            strArr = new String[]{"-y", "-i", filename, "-filter_complex", "[0:v]setpts=4.0*PTS[v];[0:a]atempo=0.5,atempo=0.5[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", b};
        } else if (h == 5) {
            strArr = new String[]{"-y", "-i", filename, "-filter_complex", "[0:v]setpts=5.0*PTS[v];[0:a]atempo=0.5,atempo=0.5[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", b};
        } else if (h == 6) {
            strArr = new String[]{"-y", "-i", filename, "-filter_complex", "[0:v]setpts=6.0*PTS[v];[0:a]atempo=0.5,atempo=0.5[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", b};
        } else if (h == 7) {
            strArr = new String[]{"-y", "-i", filename, "-filter_complex", "[0:v]setpts=7.0*PTS[v];[0:a]atempo=0.5,atempo=0.5[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", b};
        } else if (h == 8) {
            strArr = new String[]{"-y", "-i", filename, "-filter_complex", "[0:v]setpts=8.0*PTS[v];[0:a]atempo=0.5,atempo=0.5,atempo=0.5[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", b};
        }
        a(strArr, b);
    }

    private void a(String[] strArr, final String str) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();

        String ffmpegCommand = UtilCommand.main(strArr);
        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {

            @Override
            public void apply(final long executionId, final int returnCode) {
                progressDialog.dismiss();
                if (returnCode == RETURN_CODE_SUCCESS) {
                    progressDialog.dismiss();
                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(b)));
                    sendBroadcast(intent);
                    c();
                    refreshGallery(str);
                } else if (returnCode == RETURN_CODE_CANCEL) {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Toast.makeText(activity, "Error Creating Video", Toast.LENGTH_LONG).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                } else {
                    Log.e("TAG", "Error Creating Video");
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Toast.makeText(activity, "Error Creating Video", Toast.LENGTH_LONG).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }
            }
        });
        getWindow().clearFlags(16);
    }

    private void d() {
        n = findViewById(R.id.left_pointer);
        o = findViewById(R.id.right_pointer);
        e = findViewById(R.id.buttonply1);
        videoView = findViewById(R.id.videoView1);
        ivThumbnail = findViewById(R.id.iv_thumbnail);
        checkBox = findViewById(R.id.checkBox1);
        f = findViewById(R.id.seek_bar);
        bubbleSeekBar = findViewById(R.id.seekBar);
        checkBox.setChecked(false);
        bubbleSeekBar.setOnProgressChangedListener(new OnProgressChangedListener() {
            public void getProgressOnActionUp(BubbleSeekBar bubbleSeekBar, int i, float f) {

            }

            @Override
            public void getProgressOnFinally(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {
                videoView.setVisibility(View.VISIBLE);
                ivThumbnail.setVisibility(View.INVISIBLE);
                if (d.booleanValue() || videoView.isPlaying()) {
                    videoView.pause();
                    d = Boolean.valueOf(false);
                    e.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (videoView.isPlaying()) {
                                videoView.pause();
                                e.setImageResource(R.drawable.ic_play_upress);
                            } else {
                                e.setImageResource(R.drawable.ic_pause_unpresss);
                                videoView.start();
                            }
                        }
                    });
                } else {
                    e.setBackgroundResource(R.drawable.ic_pause_unpresss);
                    d = Boolean.valueOf(k);
                    e.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (videoView.isPlaying()) {
                                videoView.pause();
                                e.setImageResource(R.drawable.ic_play_upress);
                            } else {
                                videoView.start();
                                e.setImageResource(R.drawable.ic_pause_unpresss);
                            }
                        }
                    });
                }
            }

            public void onProgressChanged(BubbleSeekBar bubbleSeekBar, int i, float f, boolean fromUser) {
                aFloat = i;
                SlowMotionVideoActivity.this.i.delete(0, SlowMotionVideoActivity.this.i.length());
                StringBuilder sb = SlowMotionVideoActivity.this.i;
                sb.append("(listener) int:");
                sb.append(i);
                h = i;
                e.setImageResource(R.drawable.ic_pause_unpresss);
                g();
            }
        });
    }


    @SuppressLint("ResourceType")
    public void f() {
        new AlertDialog.Builder(this).setIcon(17301543).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        }).create().show();
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }

    private void g() {
        Glide.with(activity).asBitmap().load((q.getFilename())).into(ivThumbnail);

        videoView.setVideoURI(Uri.parse(q.getFilename()));
        videoView.setOnPreparedListener(new OnPreparedListener() {

            public void onPrepared(MediaPlayer mediaPlayer) {
                if (aFloat == 2) {
                    float speed = 0.5f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed));
                } else if (aFloat == 3) {
                    float speed1 = 0.33333334f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed1));
                } else if (aFloat == 4) {
                    float speed3 = 0.25f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed3));
                } else if (aFloat == 5) {
                    float speed4 = 0.2f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed4));
                } else if (aFloat == 6) {
                    float speed5 = 0.16666667f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed5));
                } else if (aFloat == 7) {
                    float speed6 = 0.14285715f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed6));
                } else if (aFloat == 8) {
                    float speed7 = 0.125f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed7));
                }

                f.setSeekBarChangeListener(new SeekBarChangeListener() {
                    public void SeekBarValueChanged(int i, int i2) {
                        if (f.getSelectedThumb() == 1) {
                            videoView.seekTo(f.getLeftProgress());
                        }
                        n.setText(getTimeForTrackFormat(i));
                        o.setText(getTimeForTrackFormat(i2));
                        c = getTimeForTrackFormat(i);
                        q.setStart(i);
                        a = getTimeForTrackFormat(i2);
                        q.setStop(i2);
                    }
                });
                a = getTimeForTrackFormat(mediaPlayer.getDuration());
                f.setMaxValue(mediaPlayer.getDuration());
                f.setLeftProgress(0);
                f.setRightProgress(mediaPlayer.getDuration());
                f.setProgressMinDiff(0);
            }
        });
        a = getTimeForTrackFormat(videoView.getDuration());
    }


    public void h() {
        if (videoView.isPlaying()) {
            videoView.pause();
            f.setSliceBlocked(false);
            f.removeVideoStatusThumb();
            return;
        }
        videoView.seekTo(f.getLeftProgress());
        videoView.start();
        f.videoPlayingProgress(f.getLeftProgress());
        r.a();
    }

    public static String getTimeForTrackFormat(int i2) {
        long j2 = i2;
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }


    @Override
    public void onResume() {
        super.onResume();
        t.acquire();
        if (!this.videoView.isPlaying()) {
            this.d = Boolean.valueOf(false);
            this.e.setBackgroundResource(R.drawable.ic_play_upress);
        }
        this.videoView.seekTo(this.q.getCurrentTime());
    }


    public void onPause() {
        this.t.release();
        super.onPause();
        this.q.setCurrentTime(this.videoView.getCurrentPosition());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        File file = new File(b);
        MediaScannerConnection.scanFile(this, new String[]{file.getPath()},
                null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        // now visible in gallery
                    }
                });
        if (MyApplication.isShowAd == 1) {
            Intent intent = new Intent(activity, EditActivity.class);
            intent.putExtra("videofilename", b);
            startActivity(intent);
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 9;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, EditActivity.class);
                intent.putExtra("videofilename", b);
                startActivity(intent);
                finish();
            }
        }
    }

}
