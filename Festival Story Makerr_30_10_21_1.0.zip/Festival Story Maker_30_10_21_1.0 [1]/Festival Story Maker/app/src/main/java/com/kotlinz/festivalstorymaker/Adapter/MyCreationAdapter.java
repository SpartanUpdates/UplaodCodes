package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Adapter.DashBord.AllModuleAdapter;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;

import java.io.File;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MyCreationAdapter extends RecyclerView.Adapter<MyCreationAdapter.MyViewHolder> {

    Activity activity;
    ArrayList<String> myPostList;
    private boolean dialogShown = false;

    public MyCreationAdapter(Activity activity, ArrayList<String> myPostList) {
        this.activity = activity;
        this.myPostList = myPostList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_mycreation, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(activity).load(myPostList.get(position)).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivMyCreation);
        holder.ivShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final File file = new File(myPostList.get(position));
                final Intent shareIntent = new Intent("android.intent.action.SEND");
                shareIntent.setType("image/*");
                shareIntent.putExtra("android.intent.extra.SUBJECT", activity.getString(R.string.app_name));
                shareIntent.putExtra("android.intent.extra.TEXT", String.valueOf(activity.getString(R.string.get_free)) + activity.getString(R.string.app_name) + " at here : " + "https://play.google.com/store/apps/details?id=" + activity.getPackageName());
                final Uri ShareUri = FileProvider.getUriForFile(activity, String.valueOf(activity.getPackageName()) + ".provider", file);
                shareIntent.putExtra("android.intent.extra.STREAM", ShareUri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(Intent.createChooser(shareIntent, "Share Image"));
            }
        });
        holder.ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!dialogShown) {
                    dialogShown = true;
                    final AlertDialog.Builder builder = new AlertDialog.Builder(activity, R.style.AppDialog);
                    AlertDialog dialog = builder.create();
                    if (dialog != null && !dialog.isShowing()) {
                        try {
                            builder.setTitle(R.string.deletetitle);
                            builder.setMessage(String.valueOf(activity.getResources().getString(R.string.deleteMessage)) + " " + " ?");
                            builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                                public void onClick(final DialogInterface dialog, final int which) {
                                    dialogShown = false;
                                    try {
                                        Utils.deleteFile(new File(myPostList.get(position)));
                                        itemRemoved(position);
                                        notifyDataSetChanged();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                            final AlertDialog finalDialog = dialog;
                            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    finalDialog.dismiss();
                                    dialogShown = false;
                                }
                            });
                            dialog = builder.create();
                            dialog.show();
                            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(activity.getResources().getColor(R.color.bg_main_color));
                            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(activity.getResources().getColor(R.color.bg_main_color));
                            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(activity.getResources().getColor(R.color.bg_main_color));
                        } catch (Resources.NotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return myPostList.size();
    }

    public void itemRemoved(int pos) {
        if ((myPostList != null) && (myPostList.size() > 0)) {
            myPostList.remove(pos);
        }
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.iv_my_creation)
        ImageView ivMyCreation;

        @BindView(R.id.ivDelete)
        ImageView ivDelete;

        @BindView(R.id.ivShare)
        ImageView ivShare;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
