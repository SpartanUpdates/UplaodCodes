package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Point;
import android.graphics.Typeface;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.kotlinz.videoCollage.interfaces.TextFontAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

public class TextFontAdapter extends Adapter<TextFontAdapter.FontAdapterViewHolder> {
    private Context context;
    private int height;
    private String[] imageId;
    private TextFontAdapterCallBackInterface listener;
    private int pos = 0;
    private int width;

    public static class FontAdapterViewHolder extends ViewHolder {
        LinearLayout mMain;
        TextView txtView;

        public FontAdapterViewHolder(View view) {
            super(view);
            this.mMain = (LinearLayout) view.findViewById(R.id.main_font);
            this.txtView = (TextView) view.findViewById(R.id.txt_font_name);
        }
    }

    public TextFontAdapter(Context context, String[] strArr, TextFontAdapterCallBackInterface textFontAdapterCallBackInterface) {
        this.context = context;
        this.imageId = strArr;
        this.listener = textFontAdapterCallBackInterface;
        Display defaultDisplay = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        this.width = point.x;
        this.height = point.y;
    }

    public FontAdapterViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new FontAdapterViewHolder(LayoutInflater.from(this.context).inflate(R.layout.item_text_font, viewGroup, false));
    }

    public void onBindViewHolder(FontAdapterViewHolder fontAdapterViewHolder, final int i) {
        fontAdapterViewHolder.txtView.setText("Font Style");
        fontAdapterViewHolder.txtView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                TextFontAdapter.this.pos = i;
                TextFontAdapter.this.listener.itemClick(i, TextFontAdapter.this.imageId[i]);
                TextFontAdapter.this.notifyDataSetChanged();
            }
        });
        if (i == 0) {
            fontAdapterViewHolder.txtView.setTypeface(Typeface.DEFAULT);
        } else {
            TextView textView = fontAdapterViewHolder.txtView;
            AssetManager assets = this.context.getResources().getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("fonts/");
            stringBuilder.append(this.imageId[i]);
            textView.setTypeface(Typeface.createFromAsset(assets, stringBuilder.toString()));
        }
        if (this.pos == i) {
            fontAdapterViewHolder.txtView.setBackgroundResource(R.drawable.text_font_selected);
        } else {
            fontAdapterViewHolder.txtView.setBackgroundResource(R.drawable.text_font_un_selected);
        }
    }

    public int getItemCount() {
        return this.imageId.length;
    }
}
