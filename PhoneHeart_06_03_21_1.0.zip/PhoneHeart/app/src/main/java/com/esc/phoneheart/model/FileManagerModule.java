package com.esc.phoneheart.model;

import com.esc.phoneheart.activity.PhoneCleaner;
import com.esc.phoneheart.smedia.FileMedia;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.Util;
import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;
import com.esc.phoneheart.model.FileType.FileTypes;

import java.util.ArrayList;

public class FileManagerModule {
    public String TAG;
    public ArrayList<FileMedia> arrContents = new ArrayList();
    public MediaList currentList = null;
    public ArrayList<BigSizeFilesWrapper> dataToDelete = new ArrayList();
    public long recoveredSize;
    public int selectedCount;
    public long selectedForDeleteSize;
    public long selectedSize;
    public long totalSize;

    public FileManagerModule() {
        String str = "SocialmediaModule";
        this.TAG = str;
        Util.appendLogphonecleaner(str, " Constractor calling SocialmediaModule", GlobalData.FILE_NAME);
    }

    private long getAllAppMediaSize(FileMedia fileMedia) {
        long j = 0;
        for (int i = 0; i < fileMedia.arrContents.size(); i++) {
            j += ((MediaList) fileMedia.arrContents.get(i)).totalSize;
        }
        return j;
    }

    public void addDataForDeletion(BigSizeFilesWrapper bigSizeFilesWrapper) {
        if (!bigSizeFilesWrapper.ischecked) {
            this.dataToDelete.add(bigSizeFilesWrapper);
            this.selectedForDeleteSize += bigSizeFilesWrapper.size;
            this.selectedCount++;
            bigSizeFilesWrapper.ischecked = true;
        }
    }

    public ArrayList<FileMedia> getAllAppsHavingData() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.arrContents.size(); i++) {
            if (PhoneCleaner.getInstance().socialModule.getAllAppMediaSize((FileMedia) this.arrContents.get(i)) > 0) {
                arrayList.add(this.arrContents.get(i));
            }
        }
        return arrayList;
    }

    public void removeDataFromDeletionList(BigSizeFilesWrapper bigSizeFilesWrapper) {
        for (int i = 0; i < this.dataToDelete.size(); i++) {
            if (((BigSizeFilesWrapper) this.dataToDelete.get(i)).id == bigSizeFilesWrapper.id) {
                this.dataToDelete.remove(i);
                this.selectedCount--;
                this.selectedForDeleteSize -= bigSizeFilesWrapper.size;
            }
        }
    }

    public void updateSelf() {
        this.totalSize = 0;
        this.selectedSize = 0;
        this.selectedCount = 0;
        for (int i = 0; i < this.arrContents.size(); i++) {
            FileMedia fileMedia = (FileMedia) this.arrContents.get(i);
            for (int i2 = 0; i2 < fileMedia.arrContents.size(); i2++) {
                MediaList mediaList = (MediaList) fileMedia.arrContents.get(i2);
                if (mediaList.mediaType != FileTypes.ALL) {
                    this.selectedSize += mediaList.selectedSize;
                    this.selectedCount += mediaList.selectedCount;
                    this.totalSize += mediaList.totalSize;
                }
            }
        }
    }
}
