package com.kotlinz.vehiclemanager.retrofit;
import com.kotlinz.vehiclemanager.fuel.model.FuelModel;
import com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.model.OwnerInfoModel;
import com.kotlinz.vehiclemanager.rtoownerdetails.rtovehiclelicense.model.VehicleLicenseRoot;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface RtoDetailsInterface
{
    @FormUrlEncoded
    @POST("v1/vehicle_info")
    Call<OwnerInfoModel> getVehicleOwnerDetails(@Header("Referer") String referee, @Header("API-KEY")String apikey, @Field("vehicleId")String vehicleId);

    @POST("searchLicenseDetails")
    Call<VehicleLicenseRoot> getLicenseDetail(@Query("licenseNo") String licenseNo, @Query("dob") String dob);

    @FormUrlEncoded
    @POST("v1/fuel_info")
    Call<FuelModel> getFuelPrice(@Header("Referer") String referee, @Header("API-KEY")String apikey, @Field("citystate")String cityName);
}
