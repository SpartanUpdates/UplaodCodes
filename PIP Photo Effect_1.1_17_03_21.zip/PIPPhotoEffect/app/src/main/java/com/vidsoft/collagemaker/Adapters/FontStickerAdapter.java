package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;
import androidx.core.content.ContextCompat;
import androidx.multidex.BuildConfig;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Const;

import java.util.ArrayList;

public class FontStickerAdapter extends Adapter<FontStickerAdapter.ViewHolder> {
    String Selection;
    Activity activity;
    FontStickerCallBack fontStickerCallBack;
    LayoutInflater inflater;
    ArrayList<Integer> list;

    public interface FontStickerCallBack {
        void FontStickerMethod(int i);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout border;
        ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.border = (LinearLayout) itemView.findViewById(R.id.rl_border);
            this.imageView = (ImageView) itemView.findViewById(R.id.imageView);
        }
    }

    public FontStickerAdapter(Activity activity, ArrayList<Integer> list) {
        this.Selection = BuildConfig.FLAVOR;
        this.inflater = LayoutInflater.from(activity);
        this.list = list;
        this.activity = activity;
        this.fontStickerCallBack = (FontStickerCallBack) activity;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.font_sticker_adapter, parent, false));
    }

    public void onBindViewHolder(ViewHolder holder, final int position) {
        if (this.Selection.equals(BuildConfig.FLAVOR)) {
            holder.imageView.setColorFilter(ContextCompat.getColor(this.activity, Const.normalColor));
        } else if (position == Integer.parseInt(this.Selection)) {
            holder.imageView.setColorFilter(ContextCompat.getColor(this.activity, Const.selectedColor));
        } else {
            holder.imageView.setColorFilter(ContextCompat.getColor(this.activity, Const.normalColor));
        }
        holder.imageView.setImageResource(((Integer) this.list.get(position)).intValue());
        holder.border.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                FontStickerAdapter.this.Selection = String.valueOf(position);
                FontStickerAdapter.this.notifyDataSetChanged();
                FontStickerAdapter.this.fontStickerCallBack.FontStickerMethod(position);

            }
        });
    }

    public int getItemCount() {
        return this.list.size();
    }
}