package com.kotlinz.videoCollage.interfaces;

public interface FrameAdapterCallBackInterface {
    void itemClick(int i);
}
