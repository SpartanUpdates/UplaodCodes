package com.esc.phoneheart.advancedclean;

public class StringUtils {
    public static boolean contains(String str, String str2) {
        return str != null && str.contains(str2);
    }

    public static boolean containsIgnoreCase(String str, String str2) {
        return (str == null || str2 == null || !str.toLowerCase().contains(str2.toLowerCase())) ? false : true;
    }
}
