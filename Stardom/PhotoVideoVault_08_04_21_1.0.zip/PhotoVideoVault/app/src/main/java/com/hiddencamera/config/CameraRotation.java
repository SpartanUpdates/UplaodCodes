package com.hiddencamera.config;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class CameraRotation {
    public static final int ROTATION_270 = 270;

    private CameraRotation() {
        super();
        throw new RuntimeException("Cannot initialize this class.");
    }

    @Retention(RetentionPolicy.SOURCE)
    public @interface SupportedRotation {
    }
}
