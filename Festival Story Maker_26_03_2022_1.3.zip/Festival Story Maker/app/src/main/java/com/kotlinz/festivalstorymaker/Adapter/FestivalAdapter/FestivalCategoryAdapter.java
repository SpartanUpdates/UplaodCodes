package com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter;


import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Model.FestivalPoster.FestivalDataItem;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Utils;
import com.kotlinz.festivalstorymaker.activity.FestivalTemplateActivity;
import com.kotlinz.festivalstorymaker.activity.StoryMakerActivity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FestivalCategoryAdapter extends RecyclerView.Adapter<FestivalCategoryAdapter.MyViewHolder> {

    public FestivalTemplateActivity festivalActivity;
    public String h = "0";
    public int SelectedPosition = 0;
    public ArrayList<FestivalDataItem> festivalCategoryList;

    public FestivalCategoryAdapter(Context context, ArrayList<FestivalDataItem> festivalCategoryList) {
        this.festivalActivity = (FestivalTemplateActivity) context;
        this.festivalCategoryList = festivalCategoryList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_festival_category, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
            holder.tvCategoryName.setText(festivalCategoryList.get(position).getFestivalName());
            holder.tvFestivalDate.setText(festivalCategoryList.get(position).getFestivalDate());
            if (SelectedPosition == position) {
                holder.tvCategoryName.setTextColor(festivalActivity.getResources().getColor(R.color.child_cat_text_press));
                holder.tvFestivalDate.setTextColor(festivalActivity.getResources().getColor(R.color.child_cat_text_press));
                Glide.with(festivalActivity).load(festivalCategoryList.get(position).getThemeThumbnail()).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivCategoryThumb);
            } else {
                holder.tvCategoryName.setTextColor(festivalActivity.getResources().getColor(R.color.child_cat_text_unpress));
                holder.tvFestivalDate.setTextColor(festivalActivity.getResources().getColor(R.color.child_cat_text_unpress));
                Glide.with(festivalActivity).load(festivalCategoryList.get(position).getThemeThumbnail()).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivCategoryThumb);
            }

            holder.llMain.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SelectedPosition = position;
                    festivalActivity.FestivalCategoryId = String.valueOf(festivalCategoryList.get(position).getFestivalId());
                    if (com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(festivalActivity, false)) {
                        if (ThemeDataPreferences.INSTANCE.getPreferencesData(festivalActivity, ThemeDataPreferences.FestivalMaker + festivalCategoryList.get(position).getFestivalId()).equalsIgnoreCase("")) {
                            festivalActivity.GetFestivalCategoryDataByID(String.valueOf(festivalCategoryList.get(position).getFestivalId()));
                        } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(festivalActivity, ThemeDataPreferences.FestivalMakerResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                            festivalActivity.GetFestivalCategoryDataByID(String.valueOf(festivalCategoryList.get(position).getFestivalId()));
                        } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(festivalActivity, ThemeDataPreferences.FestivalMaker + festivalCategoryList.get(position).getFestivalId()).equalsIgnoreCase("")) {
                            festivalActivity.SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(festivalActivity, ThemeDataPreferences.FestivalMaker + festivalCategoryList.get(position).getFestivalName()));
                        }
                    } else {
                        if (ThemeDataPreferences.INSTANCE.getPreferencesData(festivalActivity, ThemeDataPreferences.FestivalMaker + festivalCategoryList.get(position).getFestivalId()).equalsIgnoreCase("")) {
                            festivalActivity.rlMainData.setVisibility(View.GONE);
                            festivalActivity.llRetry.setVisibility(View.VISIBLE);
                        } else {
                            festivalActivity.SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(festivalActivity, ThemeDataPreferences.FestivalMaker + festivalCategoryList.get(position).getFestivalId()));
                        }
                    }
                    notifyDataSetChanged();
                }
            });
    }

    @Override
    public int getItemCount() {
        return festivalCategoryList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.ivCategoryThumb)
        public ImageView ivCategoryThumb;
        @BindView(R.id.llMain)
        public LinearLayout llMain;
        @BindView(R.id.tvCategoryName)
        public TextView tvCategoryName;
        @BindView(R.id.tvFestivalDate)
        public TextView tvFestivalDate;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
