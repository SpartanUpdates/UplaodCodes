package flash.light.shine.com.flashlight.controller;

import android.graphics.SurfaceTexture;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.Size;
import java.io.IOException;

public class UseSurfaceTextureFlashController extends BaseFlashController {
    private static UseSurfaceTextureFlashController mBack;
    private static UseSurfaceTextureFlashController mFront;

    public static UseSurfaceTextureFlashController getInstanceBack() {
        UseSurfaceTextureFlashController useSurfaceTextureFlashController = mBack;
        if (useSurfaceTextureFlashController == null && useSurfaceTextureFlashController == null) {
            mBack = new UseSurfaceTextureFlashController(-1);
        }
        return mBack;
    }

    public static UseSurfaceTextureFlashController getInstanceFront(int i) {
        UseSurfaceTextureFlashController useSurfaceTextureFlashController = mFront;
        if (useSurfaceTextureFlashController == null && useSurfaceTextureFlashController == null) {
            mFront = new UseSurfaceTextureFlashController(i);
        }
        return mFront;
    }

    private UseSurfaceTextureFlashController(int i) {
        super(i);
    }

    public void afterCameraOpen() {
        this.mCamera.startPreview();
    }

    public void beforeCameraRelease() {
        try {
            this.mCamera.stopPreview();
            this.mCamera.setPreviewDisplay(null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* Access modifiers changed, original: protected */
    public void onStartUse() {
        try {
            this.mCamera.setPreviewTexture(new SurfaceTexture(0));
            Parameters parameters = this.mCamera.getParameters();
            Size size = (Size) parameters.getSupportedPreviewSizes().get(0);
            parameters.setPreviewSize(size.width, size.height);
            this.mCamera.setParameters(parameters);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
