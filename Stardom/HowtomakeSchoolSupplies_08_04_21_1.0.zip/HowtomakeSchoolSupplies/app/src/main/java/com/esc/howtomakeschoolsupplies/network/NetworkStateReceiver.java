package com.esc.howtomakeschoolsupplies.network;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import java.util.HashSet;
import java.util.Set;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;


public class NetworkStateReceiver extends BroadcastReceiver {
    private Boolean connected = ((Boolean) null);
    private Set<NetworkStateReceiverListener> listeners = new HashSet();

    public interface NetworkStateReceiverListener {
        void networkAvailable();

        void networkUnavailable();
    }

    public final Set<NetworkStateReceiverListener> getListeners() {
        return this.listeners;
    }

    public final void setListeners(Set<NetworkStateReceiverListener> set) {
        Intrinsics.checkParameterIsNotNull(set, "<set-?>");
        this.listeners = set;
    }

    public final Boolean getConnected() {
        return this.connected;
    }

    public final void setConnected(Boolean bool) {
        this.connected = bool;
    }

    public void onReceive(Context context, Intent intent) {
        Intrinsics.checkParameterIsNotNull(context, "context");
        if (intent != null && intent.getExtras() != null) {
            Object systemService = context.getSystemService("connectivity");
            if (systemService != null) {
                NetworkInfo activeNetworkInfo = ((ConnectivityManager) systemService).getActiveNetworkInfo();
                if (activeNetworkInfo == null || activeNetworkInfo.getState() != State.CONNECTED) {
                    Boolean bool = Boolean.FALSE;
                    Intrinsics.checkExpressionValueIsNotNull(bool, "java.lang.Boolean.FALSE");
                    if (intent.getBooleanExtra("noConnectivity", bool.booleanValue())) {
                        this.connected = Boolean.valueOf(false);
                    }
                } else {
                    this.connected = Boolean.valueOf(true);
                }
                notifyStateToAll();
                return;
            }
            throw new TypeCastException("null cannot be cast to non-null type android.net.ConnectivityManager");
        }
    }

    private final void notifyStateToAll() {
        for (NetworkStateReceiverListener notifyState : this.listeners) {
            notifyState(notifyState);
        }
    }

    private final void notifyState(NetworkStateReceiverListener networkStateReceiverListener) {
        Object obj = this.connected;
        if (obj != null && networkStateReceiverListener != null) {
            if (Intrinsics.areEqual(obj, Boolean.valueOf(true))) {
                networkStateReceiverListener.networkAvailable();
            } else {
                networkStateReceiverListener.networkUnavailable();
            }
        }
    }

    public final void addListener(NetworkStateReceiverListener networkStateReceiverListener) {
        Intrinsics.checkParameterIsNotNull(networkStateReceiverListener, "l");
        this.listeners.add(networkStateReceiverListener);
        notifyState(networkStateReceiverListener);
    }

    public final void removeListener(NetworkStateReceiverListener networkStateReceiverListener) {
        Intrinsics.checkParameterIsNotNull(networkStateReceiverListener, "l");
        this.listeners.remove(networkStateReceiverListener);
    }
}
