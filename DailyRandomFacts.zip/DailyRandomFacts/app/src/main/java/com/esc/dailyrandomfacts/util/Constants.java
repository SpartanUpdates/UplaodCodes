package com.esc.dailyrandomfacts.util;

import android.os.Environment;

public class Constants {
    public static String APP_HOME = null;
    public static String DIR_DATA = null;
    public static String IS_SLIDER_ON = "IS_SLIDER_ON_com.esc.dailyrandomfacts";
    public static String NOTIFICATION_END_TIME = "NOTIFICATION_END_TIME_com.esc.dailyrandomfacts";
    public static String NOTIFICATION_MESSAGE = "NOTIFICATION_MESSAGEcom.esc.dailyrandomfacts";
    public static String NOTIFICATION_START_TIME = "NOTIFICATION_START_TIME_com.esc.dailyrandomfacts";
    public static final String PREF_FILE = "QuoteDaily_PREF";
    public static String PREF_FIRST_TIME_APP = "PREF_FIRST_TIME_APP_com.esc.dailyrandomfacts";
    public static String PREF_IS_FIRST = "PREF_IS_FIRST_com.esc.dailyrandomfacts;.facts";
    public static String PREF_REPEAT_RATIO = "PREF_REPEAT_RATIO_com.esc.dailyrandomfacts";
    public static String PREF_SOFT_KEYS = "PREF_SOFT_KEYScom.esc.dailyrandomfacts";
    public static String WIDGET_MESSAGE = "WIDGET_MESSAGEcom.esc.dailyrandomfacts";

    static {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStorageDirectory().getPath());
        stringBuilder.append("/Motivation");
        APP_HOME = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(APP_HOME);
        stringBuilder.append("/data");
        DIR_DATA = stringBuilder.toString();
    }
}
