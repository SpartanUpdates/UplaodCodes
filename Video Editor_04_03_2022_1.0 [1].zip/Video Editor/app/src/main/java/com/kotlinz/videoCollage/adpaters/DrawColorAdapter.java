package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.kotlinz.videoCollage.interfaces.DrawColorAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

public class DrawColorAdapter extends Adapter<DrawColorAdapter.ViewHolder> {
    private Context context;
    private DrawColorAdapterCallBackInterface listener;
    private int pos = 1;
    private String[] textColorList;

    class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        ImageView imgDrawColor;
        ImageView imgDrawColorSelector;

        ViewHolder(View view) {
            super(view);
            this.imgDrawColor = (ImageView) view.findViewById(R.id.img_draw_color);
            this.imgDrawColorSelector = (ImageView) view.findViewById(R.id.img_draw_color_selector);
        }
    }

    public DrawColorAdapter(String[] strArr, Context context, DrawColorAdapterCallBackInterface drawColorAdapterCallBackInterface) {
        this.textColorList = strArr;
        this.listener = drawColorAdapterCallBackInterface;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_draw_color, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        String str = this.textColorList[i];
        viewHolder.imgDrawColor.setBackgroundResource(R.drawable.round_bg_color);
        GradientDrawable gradientDrawable = (GradientDrawable) viewHolder.imgDrawColor.getBackground();
        gradientDrawable.setColor(Color.parseColor(str));
        viewHolder.imgDrawColor.setBackground(gradientDrawable);
        viewHolder.imgDrawColor.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DrawColorAdapter.this.pos = i;
                DrawColorAdapter.this.listener.itemClick(i);
                DrawColorAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewHolder.imgDrawColorSelector.setBackgroundResource(R.drawable.bg_round_selector);
        } else {
            viewHolder.imgDrawColorSelector.setBackgroundResource(R.drawable.bg_round_un_selector);
        }
    }

    public void setPos(int i) {
        this.pos = i;
    }

    public int getItemCount() {
        return this.textColorList.length;
    }
}
