package com.example.womenabsworkout.meals;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.fragments.MealPlanFragment;


public class MealsMainActivity extends AppCompatActivity {

    public void onBackPressed() {
        int backStackEntryCount = getSupportFragmentManager().getBackStackEntryCount();
        if (backStackEntryCount == 0) {
            super.onBackPressed();
        } else if (backStackEntryCount != 1) {
            getFragmentManager().popBackStack();
        }
        super.onBackPressed();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.meals_activity_main);
        if (bundle == null) {
            FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
            beginTransaction.replace(R.id.meals_content_fragment, new MealPlanFragment());
            beginTransaction.commit();
        }
    }
}
