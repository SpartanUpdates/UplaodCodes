package com.kotlinz.videoCollage.interfaces;

public interface TextBorderColorAdapterCallBackInterface {
    void itemClick(int i);
}
