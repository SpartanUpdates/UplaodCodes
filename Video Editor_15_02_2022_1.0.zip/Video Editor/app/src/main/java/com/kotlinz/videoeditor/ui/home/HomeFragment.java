package com.kotlinz.videoeditor.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.kotlinz.videoCollage.SelectActivity;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.VideoSelectActivity;
import java.util.List;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    ImageView ivCreateVideo, ivMearge, ivCollage;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        ivCreateVideo = root.findViewById(R.id.createvideo);
        ivMearge = root.findViewById(R.id.videomerge);
        ivCollage = root.findViewById(R.id.iv_collage);
        ivCreateVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MyApplication.isShowAd == 0) {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = getActivity();
                        MyApplication.AdsId = 1;
                        MyApplication.mInterstitialAd.show(getActivity());
                        MyApplication.isShowAd = 1;
                    } else {
                        CreateVideo();
                    }
                } else {
                    CreateVideo();
                    MyApplication.isShowAd = 0;
                }
            }
        });
        ivMearge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MyApplication.isShowAd == 0) {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = getActivity();
                        MyApplication.AdsId =  2;
                        MyApplication.mInterstitialAd.show(getActivity());
                        MyApplication.isShowAd = 1;
                    } else {
                        MergeVideo();
                    }
                } else {
                    MergeVideo();
                    MyApplication.isShowAd = 0;
                }
            }
        });
        ivCollage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MyApplication.isShowAd == 0) {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = getActivity();
                        MyApplication.AdsId = 3 ;
                        MyApplication.mInterstitialAd.show(getActivity());
                        MyApplication.isShowAd = 1;
                    } else {
                        Collage();
                    }
                } else {
                    Collage();
                    MyApplication.isShowAd = 0;
                }
            }
        });
        return root;
    }

    private void CreateVideo() {
        Intent intent = new Intent(getContext(), VideoSelectActivity.class);
        intent.putExtra("IsVideoFrom", "Single");
        startActivity(intent);
        getActivity().finish();
    }

    private void MergeVideo() {
        Intent intent = new Intent(getContext(), VideoSelectActivity.class);
        intent.putExtra("IsVideoFrom", "MergeVideo");
        startActivity(intent);
        getActivity().finish();
    }

    private void Collage() {
        startActivity(new Intent(getActivity(), SelectActivity.class));
        getActivity().finish();
    }

    private boolean hasStoragePermission() {
        return EasyPermissions.hasPermissions(getActivity(), "android.permission.WRITE_EXTERNAL_STORAGE");
    }

    private boolean hasRecordPermission() {
        return EasyPermissions.hasPermissions(getActivity(), "android.permission.RECORD_AUDIO");
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        EasyPermissions.onRequestPermissionsResult(i, strArr, iArr, this);
    }

    public void onPermissionsGranted(int i, List<String> list) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onPermissionsGranted:");
        stringBuilder.append(i);
        stringBuilder.append(":");
        stringBuilder.append(list.size());
    }

    public void onPermissionsDenied(int i, List<String> list) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onPermissionsDenied:");
        stringBuilder.append(i);
        stringBuilder.append(":");
        stringBuilder.append(list.size());
        if (EasyPermissions.somePermissionPermanentlyDenied(this, list)) {
            new AppSettingsDialog.Builder(this).build().show();
        }
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == AppSettingsDialog.DEFAULT_SETTINGS_REQ_CODE) {
            String string = getString(R.string.yes);
            String string2 = getString(R.string.no);
            Object[] objArr = new Object[1];
            if (!hasStoragePermission()) {
                string = string2;
            }
            objArr[0] = string;
        }
    }
}