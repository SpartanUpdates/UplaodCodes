package com.esc.phoneheart.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Debug;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import com.esc.phoneheart.R;
import com.esc.phoneheart.kprogresshud.KProgressHUD;
import com.esc.phoneheart.processes.AndroidAppProcess;
import com.esc.phoneheart.promo.ParentScreen;
import com.esc.phoneheart.utility.AndroidProcesses;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.pref.SharedPrefUtil;
import com.esc.phoneheart.utility.Util;
import com.esc.phoneheart.wrappers.AppDetails;
import com.esc.phoneheart.wrappers.PackageData;
import com.esc.phoneheart.wrappers.ProcessWrapper;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PhoneBoostScreen extends ParentScreen implements OnClickListener {
    public static final String TAG = "AnimatedBoostScreen";
    private Activity activity = PhoneBoostScreen.this;
    public Context context;
    public String data;
    public int deviceHeight;
    public int deviceWidth;
    public Handler handlerProgress;
    public boolean isInbackground = false;
    public ImageView iv_rocket;
    public ArrayList<ProcessWrapper> l = new ArrayList();
    public boolean noti_result_back;
    public volatile boolean o = false;
    public Handler p;
    public volatile boolean processesReceived = false;
    public int progress;
    public ProgressBar progressBar;
    public Dialog q;
    public RelativeLayout r;
    public long ramFillSpace = 0;
    public long ramsaveSize = 0;
    public boolean redirectToHome;
    public boolean redirectToNoti;
    public RelativeLayout rocket_lay;
    public RelativeLayout s;
    public long saved = 0;
    public long sizebfore = 0;
    public String statusProgress = "";
    public int t = 0;
    public long totBoostSize;
    public int u = 0;
    private ImageView iv_back;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitialAd;
    private int id;
    private KProgressHUD hud;

    private void getProcessesList() {
        new AsyncTask<String, String, String>() {
            public void onPreExecute() {
                PhoneBoostScreen.this.totBoostSize = 0;
                PhoneBoostScreen phoneBoostScreen = PhoneBoostScreen.this;
                phoneBoostScreen.t = 0;
                phoneBoostScreen.u = 0;
                phoneBoostScreen.l.clear();
                super.onPreExecute();
            }

            public String doInBackground(String... r17) {
                int i;
                Iterator it;
                ActivityManager.RunningAppProcessInfo runningAppProcessInfo;
                int length;
                int i2;
                Debug.MemoryInfo memoryInfo;
                ProcessWrapper processWrapper;
                int i3;
                Iterator it2;
                String str = "";
                @SuppressLint("WrongConstant") ActivityManager activityManager = (ActivityManager) PhoneBoostScreen.this.context.getSystemService("activity");
                PackageManager packageManager = PhoneBoostScreen.this.getPackageManager();
                try {
                    List runningAppProcesses = activityManager.getRunningAppProcesses();
                    PhoneBoostScreen.this.t = runningAppProcesses.size();
                    i = 1;
                    if (PhoneBoostScreen.this.t > 1) {
                        ArrayList ignoredData = PhoneBoostScreen.this.getIgnoredData();
                        it = runningAppProcesses.iterator();
                        while (it.hasNext()) {
                            runningAppProcessInfo = (ActivityManager.RunningAppProcessInfo) it.next();
                            if (!ignoredData.contains(runningAppProcessInfo.processName)) {
                                int[] iArr = new int[i];
                                iArr[0] = runningAppProcessInfo.pid;
                                Debug.MemoryInfo[] processMemoryInfo = activityManager.getProcessMemoryInfo(iArr);
                                length = processMemoryInfo.length;
                                i2 = 0;
                                while (i2 < length) {
                                    memoryInfo = processMemoryInfo[i2];
                                    processWrapper = new ProcessWrapper();
                                    PhoneBoostScreen.this.u += i;
                                    try {
                                        @SuppressLint("WrongConstant") CharSequence applicationLabel = packageManager.getApplicationLabel(packageManager.getApplicationInfo(runningAppProcessInfo.processName, 128));
                                        StringBuilder sb = new StringBuilder();
                                        sb.append(str);
                                        sb.append(applicationLabel);
                                        String sb2 = sb.toString();
                                        processWrapper.appname = sb2;
                                        if (!sb2.equalsIgnoreCase("Google play services")) {
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        processWrapper.appname = runningAppProcessInfo.processName;
                                    }
                                    it2 = it;
                                    i3 = length;
                                    i2++;
                                    it = it2;
                                    length = i3;
                                    i = 1;
                                }
                            }
                        }
                        publishProgress(new String[]{"0", "Boosted"});
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
                return null;
            }

            public void onPostExecute(String str) {
                new AsyncTask<String, String, String>() {
                    public void onPostExecute(String str) {
                    }

                    public void onPreExecute() {
                        super.onPreExecute();
                    }

                    public String doInBackground(String... strArr) {
                        SharedPrefUtil savedPref = new SharedPrefUtil(PhoneBoostScreen.this);
                        String str = SharedPrefUtil.LASTBOOSTTIME;
                        StringBuilder stringBuilder = new StringBuilder();
                        String str2 = "";
                        stringBuilder.append(str2);
                        stringBuilder.append(System.currentTimeMillis());
                        savedPref.saveString(str, stringBuilder.toString());
                        PhoneBoostScreen.this.getRamSize();
                        PhoneBoostScreen phoneBoostScreen = PhoneBoostScreen.this;
                        phoneBoostScreen.sizebfore = phoneBoostScreen.ramFillSpace;
                        PhoneBoostScreen.this.kill_services();
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(str2);
                        stringBuilder2.append(System.currentTimeMillis());
                        savedPref.saveString(SharedPrefUtil.RAMPAUSE, stringBuilder2.toString());
                        PhoneBoostScreen.this.getRamSize();
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(str2);
                        stringBuilder2.append(Math.round((float) PhoneBoostScreen.this.ramsaveSize));
                        savedPref.saveString(SharedPrefUtil.RAMATPAUSE, stringBuilder2.toString());
                        long c = PhoneBoostScreen.this.ramFillSpace;
                        PhoneBoostScreen phoneBoostScreen2 = PhoneBoostScreen.this;
                        phoneBoostScreen2.saved = phoneBoostScreen2.sizebfore - c;
                        return null;
                    }
                }.execute(new String[0]);
            }

            public void onProgressUpdate(String... strArr) {
                super.onProgressUpdate(strArr);
            }
        }.execute(new String[0]);
    }

    private void getRamSize() {
        @SuppressLint("WrongConstant") ActivityManager activityManager = (ActivityManager) getSystemService("activity");
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        if (activityManager != null) {
            activityManager.getMemoryInfo(memoryInfo);
        }
        if (VERSION.SDK_INT >= 16) {
            long j = memoryInfo.totalMem;
            long j2 = j / 1048576;
            long j3 = memoryInfo.availMem;
            long j4 = j3 / 1048576;
            this.ramFillSpace = j - j3;
            this.ramsaveSize = ((j - j3) * 100) / j;
        }
    }

    private void init() {
        Util.appendLogphonecleaner(TAG, " init ", "");
        this.context = this;
        TextView textView = (TextView) findViewById(R.id.booststatus);
        String capitalizeFirstLetter = Util.capitalizeFirstLetter(Build.BRAND);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(capitalizeFirstLetter.substring(0, 1).toUpperCase());
        stringBuilder.append(capitalizeFirstLetter.substring(1));
        capitalizeFirstLetter = stringBuilder.toString();
        textView.setText(String.format(getResources().getString(R.string.ram_clean_message).replace("DO_NOT_TRANSLATE", "%s"), new Object[]{capitalizeFirstLetter}));
        this.r = (RelativeLayout) findViewById(R.id.layout_one);
        this.s = (RelativeLayout) findViewById(R.id.layout_two);
        this.handlerProgress = new Handler();
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);
        this.progressBar = progressBar;
        try {
            progressBar.getProgressDrawable().setColorFilter(getResources().getColor(R.color.color_gray), Mode.SRC_IN);
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.iv_rocket = (ImageView) findViewById(R.id.iv_rocket);
        this.rocket_lay = (RelativeLayout) findViewById(R.id.rocket_lay);

        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitialAd !=null && interstitialAd.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 100;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                }else {
                    startActivity(new Intent(PhoneBoostScreen.this, HomeActivity.class));
                    finish();
                }
            }
        });
    }

    private void kill_services() {
        List<ApplicationInfo> installedApplications = getPackageManager().getInstalledApplications(0);
        @SuppressLint("WrongConstant") ActivityManager activityManager = (ActivityManager) getSystemService("activity");
        ArrayList ignoredData = getIgnoredData();
        for (ApplicationInfo applicationInfo : installedApplications) {
            if ((applicationInfo.flags & 1) != 1) {
                if (!applicationInfo.packageName.equals("")) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(applicationInfo.packageName);
                    if (!ignoredData.contains(stringBuilder.toString())) {
                        if (activityManager != null) {
                            activityManager.killBackgroundProcesses(applicationInfo.packageName);
                        }
                    }
                }
            }
        }
    }

    private void performScanningAsPerCondition() {
        String str = "";
        Util.appendLogphonecleaner(TAG, " method:performScanningAsPerCondition ", str);
        String string = new SharedPrefUtil(this).getString(SharedPrefUtil.LASTBOOSTTIME);
        if (string != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(System.currentTimeMillis());
            if (Util.checkTimeDifference(stringBuilder.toString(), string) <= ((long) GlobalData.boostPause)) {
                this.processesReceived = true;
            } else if (VERSION.SDK_INT <= 23) {
                setprocesslist();
            } else {
                getProcessesList();
            }
        } else if (VERSION.SDK_INT <= 23) {
            setprocesslist();
        } else {
            getProcessesList();
        }
    }

    private void redirectToHome() {
        this.redirectToHome = getIntent().getBooleanExtra(GlobalData.REDIRECTHOME, false);
        this.redirectToNoti = getIntent().getBooleanExtra(GlobalData.REDIRECTNOTI, false);
        this.noti_result_back = getIntent().getBooleanExtra(GlobalData.NOTI_RESULT_BACK, false);
    }

    private void rocketAnimation() {
        this.iv_rocket.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.rocket_shake));
    }

    private void setDimensions() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        @SuppressLint("WrongConstant") WindowManager windowManager = (WindowManager) getSystemService("window");
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        }
        this.deviceHeight = displayMetrics.heightPixels;
        this.deviceWidth = displayMetrics.widthPixels;
        LayoutParams layoutParams = (LayoutParams) this.rocket_lay.getLayoutParams();
        layoutParams.setMargins(0, (this.deviceHeight * 20) / 100, 0, 0);
        this.rocket_lay.setLayoutParams(layoutParams);
        LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.iv_rocket.getLayoutParams();
        layoutParams2.height = (this.deviceHeight * 22) / 100;
        layoutParams2.width = (this.deviceWidth * 19) / 100;
        this.iv_rocket.setLayoutParams(layoutParams2);
    }

    private void setprocesslist() {
        Util.appendLogphonecleaner(TAG, "setprocesslist", "");
        new AsyncTask<String, String, String>() {
            public void onPreExecute() {
                Util.appendLogphonecleaner(PhoneBoostScreen.TAG, "onPreExecute", "");
                GlobalData.processDataList.clear();
                super.onPreExecute();
            }

            public String doInBackground(String... strArr) {
                Exception e;
                String str = "BCHECK";
                String str2 = PhoneBoostScreen.TAG;
                String str3 = "";
                Util.appendLogphonecleaner(str2, "doInBackground", str3);
                @SuppressLint("WrongConstant") ActivityManager activityManager = (ActivityManager) PhoneBoostScreen.this.context.getSystemService("activity");
                PackageManager packageManager = PhoneBoostScreen.this.getPackageManager();
                List runningAppProcesses = activityManager.getRunningAppProcesses();
                ArrayList installedSystemApps = new AppDetails(PhoneBoostScreen.this.context).getInstalledSystemApps();
                int size = runningAppProcesses.size();
                String str4 = "";
                String str5 = "Google play store";
                String str6 = "Google play services";
                int i = 0;
                int i2 = 1;
                ArrayList arrayList;
                StringBuilder stringBuilder;
                if (size > 1) {
                    ArrayList ignoredData = PhoneBoostScreen.this.getIgnoredData();
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(" doInBackground runningProcesses > 1 ");
                    stringBuilder2.append(runningAppProcesses.size());
                    Util.appendLogphonecleaner(str2, stringBuilder2.toString(), str3);
                    Iterator it = runningAppProcesses.iterator();
                    while (it.hasNext()) {
                        ActivityManager.RunningAppProcessInfo runningAppProcessInfo = (ActivityManager.RunningAppProcessInfo) it.next();
                        if (!ignoredData.contains(runningAppProcessInfo.processName)) {
                            int[] iArr = new int[i2];
                            iArr[i] = runningAppProcessInfo.pid;
                            Debug.MemoryInfo[] processMemoryInfo = activityManager.getProcessMemoryInfo(iArr);
                            i = processMemoryInfo.length;
                            int i3 = 0;
                            while (i3 < i) {
                                Debug.MemoryInfo memoryInfo = processMemoryInfo[i3];
                                Iterator it2 = it;
                                ProcessWrapper processWrapper = new ProcessWrapper();
                                ArrayList arrayList2 = ignoredData;
                                int i4;
                                Debug.MemoryInfo[] memoryInfoArr;
                                try {
                                    i4 = i;
                                    try {
                                        @SuppressLint("WrongConstant") CharSequence applicationLabel = packageManager.getApplicationLabel(packageManager.getApplicationInfo(runningAppProcessInfo.processName, 128));
                                        StringBuilder stringBuilder3 = new StringBuilder();
                                        stringBuilder3.append(str3);
                                        stringBuilder3.append(applicationLabel);
                                        String stringBuilder4 = stringBuilder3.toString();
                                        processWrapper.appname = stringBuilder4;
                                        if (stringBuilder4.equalsIgnoreCase(str6) || processWrapper.appname.equalsIgnoreCase(str5)) {
                                            arrayList = installedSystemApps;
                                            memoryInfoArr = processMemoryInfo;
                                            i3++;
                                            it = it2;
                                            ignoredData = arrayList2;
                                            i = i4;
                                            processMemoryInfo = memoryInfoArr;
                                            installedSystemApps = arrayList;
                                        } else {
                                            Object obj;
                                            size = 0;
                                            while (size < installedSystemApps.size()) {
                                                String str7 = ((PackageData) installedSystemApps.get(size)).appname;
                                                memoryInfoArr = processMemoryInfo;
                                                StringBuilder stringBuilder5 = new StringBuilder();
                                                stringBuilder5.append(str3);
                                                arrayList = installedSystemApps;
                                                stringBuilder5.append(processWrapper.appname);
                                                if (str7.equalsIgnoreCase(stringBuilder5.toString())) {
                                                    stringBuilder = new StringBuilder();
                                                    stringBuilder.append(str3);
                                                    stringBuilder.append(processWrapper.appname);
                                                    if (Util.notInIgnoreList(stringBuilder.toString())) {
                                                        obj = 1;
                                                        break;
                                                    }
                                                }
                                                size++;
                                                processMemoryInfo = memoryInfoArr;
                                                installedSystemApps = arrayList;
                                            }
                                            arrayList = installedSystemApps;
                                            memoryInfoArr = processMemoryInfo;
                                            obj = null;
                                            if (obj == null) {
                                                String str8 = runningAppProcessInfo.processName;
                                                processWrapper.name = str8;
                                                if (!str8.equalsIgnoreCase(str4)) {
                                                    if (runningAppProcessInfo.importance == 400 || runningAppProcessInfo.importance == 200 || runningAppProcessInfo.importance == 300) {
                                                        processWrapper.size = (long) (memoryInfo.getTotalPss() * 1024);
                                                        processWrapper.pid = runningAppProcessInfo.pid;
                                                        String[] strArr2 = new String[2];
                                                        stringBuilder = new StringBuilder();
                                                        stringBuilder.append(str3);
                                                        stringBuilder.append(processWrapper.size);
                                                        strArr2[0] = stringBuilder.toString();
                                                        stringBuilder = new StringBuilder();
                                                        stringBuilder.append("Process : ");
                                                        stringBuilder.append(processWrapper.name);
                                                        strArr2[1] = stringBuilder.toString();
                                                        publishProgress(strArr2);
                                                        processWrapper.ischecked = true;
                                                        GlobalData.processDataList.add(processWrapper);
                                                    }
                                                }
                                            }
                                            i3++;
                                            it = it2;
                                            ignoredData = arrayList2;
                                            i = i4;
                                            processMemoryInfo = memoryInfoArr;
                                            installedSystemApps = arrayList;
                                        }
                                    } catch (Exception e2) {
                                        e = e2;
                                        arrayList = installedSystemApps;
                                        memoryInfoArr = processMemoryInfo;
                                        e.printStackTrace();
                                        processWrapper.appname = runningAppProcessInfo.processName;
                                        i3++;
                                        it = it2;
                                        ignoredData = arrayList2;
                                        i = i4;
                                        processMemoryInfo = memoryInfoArr;
                                        installedSystemApps = arrayList;
                                    }
                                } catch (Exception e3) {
                                    e = e3;
                                    arrayList = installedSystemApps;
                                    i4 = i;
                                    memoryInfoArr = processMemoryInfo;
                                    e.printStackTrace();
                                    processWrapper.appname = runningAppProcessInfo.processName;
                                    i3++;
                                    it = it2;
                                    ignoredData = arrayList2;
                                    i = i4;
                                    processMemoryInfo = memoryInfoArr;
                                    installedSystemApps = arrayList;
                                }
                            }
                            i = 0;
                            i2 = 1;
                        }
                    }
                    Util.appendLogphonecleaner(str2, "doInBackground ends", str3);
                    return null;
                }
                arrayList = installedSystemApps;
                Util.appendLogphonecleaner(str2, " doInBackground runningProcesses == 1 ", str3);
                runningAppProcesses = AndroidProcesses.getRunningAppProcesses();
                stringBuilder = new StringBuilder();
                stringBuilder.append(runningAppProcesses.size());
                stringBuilder.append(str3);
                Log.d(str, stringBuilder.toString());
                installedSystemApps = PhoneBoostScreen.this.getIgnoredData();
                size = 0;
                while (size < runningAppProcesses.size()) {
                    AndroidAppProcess androidAppProcess = (AndroidAppProcess) runningAppProcesses.get(size);
                    if (!installedSystemApps.contains(androidAppProcess.getPackageName())) {
                        int[] iArr2 = new int[1];
                        int i5 = 0;
                        iArr2[0] = androidAppProcess.pid;
                        Debug.MemoryInfo[] processMemoryInfo2 = activityManager.getProcessMemoryInfo(iArr2);
                        i2 = processMemoryInfo2.length;
                        while (i5 < i2) {
                            Debug.MemoryInfo memoryInfo2 = processMemoryInfo2[i5];
                            ProcessWrapper processWrapper2 = new ProcessWrapper();
                            ActivityManager activityManager2 = activityManager;
                            List list;
                            ArrayList arrayList3;
                            ArrayList arrayList4;
                            PackageManager packageManager2;
                            try {
                                list = runningAppProcesses;
                                try {
                                    @SuppressLint("WrongConstant") CharSequence applicationLabel2 = packageManager.getApplicationLabel(packageManager.getApplicationInfo(androidAppProcess.name, 128));
                                    StringBuilder stringBuilder6 = new StringBuilder();
                                    stringBuilder6.append(str3);
                                    stringBuilder6.append(applicationLabel2);
                                    String stringBuilder7 = stringBuilder6.toString();
                                    processWrapper2.appname = stringBuilder7;
                                    if (stringBuilder7.equalsIgnoreCase(str6) || processWrapper2.appname.equalsIgnoreCase(str5)) {
                                        arrayList3 = installedSystemApps;
                                        arrayList4 = arrayList;
                                        packageManager2 = packageManager;
                                        i5++;
                                        activityManager = activityManager2;
                                        runningAppProcesses = list;
                                        packageManager = packageManager2;
                                        installedSystemApps = arrayList3;
                                        arrayList = arrayList4;
                                    } else {
                                        StringBuilder stringBuilder8;
                                        Object obj2;
                                        processWrapper2.name = androidAppProcess.name;
                                        int i6 = 0;
                                        while (i6 < arrayList.size()) {
                                            ArrayList arrayList5 = arrayList;
                                            packageManager2 = packageManager;
                                            String str9 = ((PackageData) arrayList5.get(i6)).appname;
                                            arrayList4 = arrayList5;
                                            stringBuilder6 = new StringBuilder();
                                            stringBuilder6.append(str3);
                                            arrayList3 = installedSystemApps;
                                            stringBuilder6.append(processWrapper2.appname);
                                            if (str9.equalsIgnoreCase(stringBuilder6.toString())) {
                                                stringBuilder8 = new StringBuilder();
                                                stringBuilder8.append(str3);
                                                stringBuilder8.append(processWrapper2.appname);
                                                if (Util.notInIgnoreList(stringBuilder8.toString())) {
                                                    obj2 = 1;
                                                    break;
                                                }
                                            }
                                            i6++;
                                            packageManager = packageManager2;
                                            installedSystemApps = arrayList3;
                                            arrayList = arrayList4;
                                        }
                                        arrayList3 = installedSystemApps;
                                        arrayList4 = arrayList;
                                        packageManager2 = packageManager;
                                        obj2 = null;
                                        if (obj2 == null) {
                                            if (!processWrapper2.name.equalsIgnoreCase(str4)) {
                                                long totalPss = (long) (memoryInfo2.getTotalPss() * 1024);
                                                processWrapper2.size = totalPss;
                                                if (totalPss != 0) {
                                                    stringBuilder8 = new StringBuilder();
                                                    stringBuilder8.append(str3);
                                                    stringBuilder8.append(Util.convertBytes(processWrapper2.size));
                                                    Log.d("SIZEEEE", stringBuilder8.toString());
                                                    processWrapper2.pid = androidAppProcess.pid;
                                                    processWrapper2.ischecked = true;
                                                    GlobalData.processDataList.add(processWrapper2);
                                                    i5++;
                                                    activityManager = activityManager2;
                                                    runningAppProcesses = list;
                                                    packageManager = packageManager2;
                                                    installedSystemApps = arrayList3;
                                                    arrayList = arrayList4;
                                                }
                                            }
                                        }
                                        i5++;
                                        activityManager = activityManager2;
                                        runningAppProcesses = list;
                                        packageManager = packageManager2;
                                        installedSystemApps = arrayList3;
                                        arrayList = arrayList4;
                                    }
                                } catch (Exception unused) {
                                    arrayList3 = installedSystemApps;
                                    arrayList4 = arrayList;
                                    packageManager2 = packageManager;
                                    processWrapper2.appname = androidAppProcess.name;
                                    i5++;
                                    activityManager = activityManager2;
                                    runningAppProcesses = list;
                                    packageManager = packageManager2;
                                    installedSystemApps = arrayList3;
                                    arrayList = arrayList4;
                                }
                            } catch (Exception unused2) {
                                list = runningAppProcesses;
                                arrayList3 = installedSystemApps;
                                arrayList4 = arrayList;
                                packageManager2 = packageManager;
                                processWrapper2.appname = androidAppProcess.name;
                                i5++;
                                activityManager = activityManager2;
                                runningAppProcesses = list;
                                packageManager = packageManager2;
                                installedSystemApps = arrayList3;
                                arrayList = arrayList4;
                            }
                        }
                    }
                    size++;
                    activityManager = activityManager;
                    runningAppProcesses = runningAppProcesses;
                    packageManager = packageManager;
                    installedSystemApps = installedSystemApps;
                    arrayList = arrayList;
                }
                StringBuilder stringBuilder9 = new StringBuilder();
                stringBuilder9.append(GlobalData.processDataList.size());
                stringBuilder9.append(str3);
                Log.d(str, stringBuilder9.toString());
                Util.appendLogphonecleaner(str2, "doInBackground ends", str3);
                return null;
            }

            public void onPostExecute(String str) {
                Util.appendLogphonecleaner(PhoneBoostScreen.TAG, "onPostExecute", "");
                PhoneBoostScreen.this.processesReceived = true;
            }

            public void onProgressUpdate(String... strArr) {
                super.onProgressUpdate(strArr);
            }
        }.execute(new String[0]);
    }

    private void trackIfFromNotification() {
        Util.appendLogphonecleaner(TAG, " method:trackIfFromNotification", "");
        getIntent().getBooleanExtra("FROMNOTI", false);
    }

    private void update_progress() {
        this.p.postDelayed(new Runnable() {
            public void run() {
                String str = "";
                StringBuilder stringBuilder;
                if (PhoneBoostScreen.this.progress >= 100) {
                    PhoneBoostScreen.this.statusProgress = "normal";
                    if (!PhoneBoostScreen.this.isInbackground) {
                        int i = VERSION.SDK_INT;
                        String str2 = GlobalData.REDIRECTNOTI;
                        String str3 = "BOOST";
                        String str4 = "TYPE";
                        String str5 = "DATA";
                        String str6 = PhoneBoostScreen.TAG;
                        Intent intent;
                        if (i <= 23) {
                            Util.appendLogphonecleaner(str6, " statusProgress = normal", str);
                            intent = new Intent(PhoneBoostScreen.this, FinalScreen.class);
                            intent.putExtra(str5, PhoneBoostScreen.this.getResources().getString(R.string.ram_finish_success));
                            intent.putExtra(str4, str3);
                            intent.putExtra(str2, true);
                            GlobalData.afterDelete = true;
                            GlobalData.loadAds = false;
                            Util.appendLogphonecleaner(str6, " CommonResultScreen called ", str);
                            PhoneBoostScreen.this.startActivity(intent);
                            PhoneBoostScreen.this.finish();
                            return;
                        }
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str);
                        stringBuilder.append(Util.convertBytes(PhoneBoostScreen.this.saved));
                        Util.appendLogphonecleaner(str6, stringBuilder.toString(), str);
                        intent = new Intent(PhoneBoostScreen.this.context, JunkDeleteAnimationScreen.class);
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(str);
                        stringBuilder2.append(PhoneBoostScreen.this.getResources().getString(R.string.ram_finish_success));
                        intent.putExtra(str5, stringBuilder2.toString());
                        intent.putExtra(str4, str3);
                        intent.putExtra(str2, true);
                        PhoneBoostScreen.this.startActivity(intent);
                        PhoneBoostScreen.this.finish();
                    }
                } else if (!PhoneBoostScreen.this.o) {
                    PhoneBoostScreen phoneBoostScreen = PhoneBoostScreen.this;
                    phoneBoostScreen.progress = phoneBoostScreen.progress + 1;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(str);
                    stringBuilder.append(PhoneBoostScreen.this.progress);
                    Log.e("======", stringBuilder.toString());
                    PhoneBoostScreen.this.progressBar.setProgress(PhoneBoostScreen.this.progress);
                    if (VERSION.SDK_INT > 23) {
                        PhoneBoostScreen.this.p.postDelayed(this, 90);
                    } else if (PhoneBoostScreen.this.progress < 80 || PhoneBoostScreen.this.processesReceived) {
                        PhoneBoostScreen.this.p.postDelayed(this, 90);
                    } else {
                        PhoneBoostScreen.this.p.postDelayed(this, 2000);
                    }
                }
            }
        }, 700);
    }

    public void onBackPressed() {
        this.o = true;
        Dialog dialog = new Dialog(this);
        this.q = dialog;
        dialog.requestWindowFeature(1);
        if (this.q.getWindow() != null) {
            this.q.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            this.q.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
        }
        this.q.setContentView(R.layout.new_dialog_junk_cancel);
        this.q.setCancelable(false);
        this.q.setCanceledOnTouchOutside(false);
        this.q.getWindow().setLayout(-1, -1);
        this.q.getWindow().setGravity(17);
        ((TextView) this.q.findViewById(R.id.dialog_title)).setText(getResources().getString(R.string.ram_clean_back_title));
        ((TextView) this.q.findViewById(R.id.dialog_msg)).setText(getResources().getString(R.string.dialouge_scan_back));
        this.q.findViewById(R.id.ll_no).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!PhoneBoostScreen.this.doubleClicked()) {
                    PhoneBoostScreen.this.o = false;
                    Log.e("=========", "onBackPressed free update_progress() cancle button click");
                    PhoneBoostScreen.this.update_progress();
                    PhoneBoostScreen.this.q.dismiss();
                }
            }
        });
        this.q.findViewById(R.id.ll_yes).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!PhoneBoostScreen.this.doubleClicked()) {
                    PhoneBoostScreen.this.handlerProgress.removeMessages(0);
                    PhoneBoostScreen.this.o = false;
                    PhoneBoostScreen.this.q.dismiss();
                    Util.appendLogphonecleaner(PhoneBoostScreen.TAG, "backpressed pDialog finish ", "");
                    GlobalData.processDataList.clear();
                    PhoneBoostScreen.this.finish();
                    if (PhoneBoostScreen.this.redirectToHome || PhoneBoostScreen.this.redirectToNoti || PhoneBoostScreen.this.noti_result_back) {
                        PhoneBoostScreen.this.startActivity(new Intent(PhoneBoostScreen.this.context, HomeActivity.class));
                    }
                }
            }
        });
        this.q.show();
    }

    public void onClick(View view) {
        if (doubleClicked()) {
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        GlobalData.SETAPPLAnguage(this);
        setContentView(R.layout.activity_boost_animation_screen);
        Util.isHome = false;
        GlobalData.processDataList.clear();
        init();
        setDimensions();
        performScanningAsPerCondition();
        this.p = new Handler();
        this.progress = 0;
        update_progress();
        clearNotification(new int[]{600});
        trackIfFromNotification();
        Util.appendLogphonecleaner(TAG, " oncreate ends", "");
        redirectToHome();
        rocketAnimation();
        loadAd();
        BannerAds();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        onBackPressed();
        return true;
    }

    public void onPause() {
        super.onPause();
        Log.e("=========", "onPause() ");
        this.o = true;
        this.isInbackground = true;
    }

    public void onResume() {
        super.onResume();
        Util.appendLogphonecleaner(TAG, " onResume", "");
        this.isInbackground = false;
        RelativeLayout relativeLayout = this.s;
        String str = "pDialog.isShowing()";
        String str2 = "=======";
        if (relativeLayout == null || relativeLayout.getVisibility() != View.VISIBLE) {
            Dialog dialog = this.q;
            if (dialog == null || !dialog.isShowing()) {
                Log.e(str2, "pDialog.isShowing() else part");
                this.o = false;
                update_progress();
                return;
            }
            this.o = true;
            Log.e(str2, str);
            return;
        }
        Log.e(str2, str);
        this.o = true;
    }

    private void loadAd()
    {
        //interstitial FullScreenAd
        interstitialAd = new InterstitialAd(PhoneBoostScreen.this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        startActivity(new Intent(PhoneBoostScreen.this, HomeActivity.class));
                        finish();
                    break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitialAd = new InterstitialAd(activity);
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
