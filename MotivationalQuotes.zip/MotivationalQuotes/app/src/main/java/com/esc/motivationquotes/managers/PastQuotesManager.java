package com.esc.motivationquotes.managers;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.List;

public class PastQuotesManager {
    private static final String PREF_PAST_QUOTES = "pref_past_quotescom.esc.motivationquotes.motivation_";

    public static ArrayList<String> getPastQuotes() {
        String string = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext()).getString(PREF_PAST_QUOTES, null);
        if (string != null) {
            return (ArrayList) new Gson().fromJson(string, new TypeToken<List<String>>() {
            }.getType());
        }
        return new ArrayList();
    }

    public static void addPastQuote(String str) {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext());
        ArrayList pastQuotes = getPastQuotes();
        if (pastQuotes == null) {
            pastQuotes = new ArrayList();
        }
        if (!pastQuotes.contains(str)) {
            pastQuotes.add(str);
        }
        if (pastQuotes.size() > 100) {
            pastQuotes.remove(0);
        }
        Editor edit = defaultSharedPreferences.edit();
        edit.putString(PREF_PAST_QUOTES, new Gson().toJson(pastQuotes));
        edit.commit();
    }
}
