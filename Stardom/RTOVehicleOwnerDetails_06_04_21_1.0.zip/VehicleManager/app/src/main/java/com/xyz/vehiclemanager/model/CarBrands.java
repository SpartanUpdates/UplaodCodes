package com.xyz.vehiclemanager.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class CarBrands
{
    @SerializedName("data")
    public ArrayList<CarBrands> data = null;
    @SerializedName("id")
    public String id;
    @SerializedName("brandName")
    public String brandName;
    @SerializedName("brandSlug")
    public String brandSlug;
    @SerializedName("imageUrl")
    public String imageUrl;

    public CarBrands() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getBrandSlug() {
        return brandSlug;
    }

    public void setBrandSlug(String brandSlug) {
        this.brandSlug = brandSlug;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public ArrayList<CarBrands> getData() {
        return data;
    }

    public void setData(ArrayList<CarBrands> data) {
        this.data = data;
    }
}
