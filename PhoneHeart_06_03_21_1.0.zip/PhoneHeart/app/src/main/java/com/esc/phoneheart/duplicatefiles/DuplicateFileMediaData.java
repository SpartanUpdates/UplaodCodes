package com.esc.phoneheart.duplicatefiles;

import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;

import java.util.ArrayList;
import java.util.HashMap;

public class DuplicateFileMediaData {
    public ArrayList<DupFileMediaMapData> fileTypeDataList = new ArrayList<>();
    public String mediaName;

    public DuplicateFileMediaData(String str, ArrayList<BigSizeFilesWrapper> arrayList) {
        HashMap hashMap = new HashMap();
        mediaName = str;
        for (int i = 0; i < arrayList.size(); i++) {
            BigSizeFilesWrapper bigSizeFilesWrapper = arrayList.get(i);
            if (hashMap.get(bigSizeFilesWrapper.hash) == null) {
                ArrayList arrayList2 = new ArrayList();
                arrayList2.add(bigSizeFilesWrapper);
                hashMap.put(bigSizeFilesWrapper.hash, arrayList2);
            } else {
                ((ArrayList) hashMap.get(bigSizeFilesWrapper.hash)).add(bigSizeFilesWrapper);
            }
        }
        for (Object str2 : hashMap.keySet()) {
            this.fileTypeDataList.add(new DupFileMediaMapData(this.mediaName, (String) str2, (ArrayList) hashMap.get(str2)));
        }
    }
}
