package com.vidsoft.videostatusmaker.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

import java.io.InputStream;

import com.vidsoft.videostatusmaker.adapter.StickerAdapter;

public class ActivityStickerSelect extends Activity {
    StickerAdapter stickerAdapter;
    ImageView ivBack;
    Drawable d;
    String strFolder;
    Typeface font1;
    GridView grid;
    InputStream is;
    String[] sticker;
    TextView title;

    protected void onCreate(@Nullable final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.select_sticker);
        this.getWindow().addFlags(1024);
        this.grid = (GridView) this.findViewById(R.id.grid);
        this.title = (TextView) this.findViewById(R.id.title);
        this.ivBack = (ImageView) this.findViewById(R.id.back);
        this.font1 = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.title.setTypeface(this.font1);
        this.title.setTextSize(18.0f);
        PutAnalyticsEvent();
        try {
            this.grid.setNumColumns(3);
            this.title.setText((CharSequence) "Sticker");
            this.strFolder = "sticker";
            this.sticker = this.getResources().getAssets().list("sticker");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.stickerAdapter = new StickerAdapter((Context) this, this.sticker, this.strFolder);
        this.grid.setAdapter((ListAdapter) this.stickerAdapter);
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityStickerSelect.this.onBackPressed();
            }
        });
        this.grid.setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                try {
                    final ActivityStickerSelect this$0 = ActivityStickerSelect.this;
                    final AssetManager assets = ActivityStickerSelect.this.getAssets();
                    final StringBuilder sb = new StringBuilder();
                    sb.append(ActivityStickerSelect.this.strFolder);
                    sb.append("/");
                    sb.append(ActivityStickerSelect.this.sticker[n]);
                    this$0.is = assets.open(sb.toString());
                    ActivityStickerSelect.this.d = Drawable.createFromStream(ActivityStickerSelect.this.is, (String) null);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                ActivityEditImage.birmapSticker = ((BitmapDrawable) ActivityStickerSelect.this.d).getBitmap();
                ActivityStickerSelect.this.setResult(-1);
                ActivityStickerSelect.this.finish();
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityStickerSelect");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

}
