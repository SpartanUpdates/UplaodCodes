package com.esc.poems.preference;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class EPreferences {
    String PrefKeyUrl;
    private SharedPreferences m_csPref;

    private EPreferences(final Context context, final String s, final int n) {
        this.PrefKeyUrl = "all_url";
        this.m_csPref = context.getSharedPreferences(s, n);
    }

    public static EPreferences getInstance(final Context context) {
        return new EPreferences(context, "slideshow_pref", 0);
    }


    public boolean getBoolean(final String s, final boolean b) {
        Log.e("getBool S = ", "" + s);
        return this.m_csPref.getBoolean(s, b);
    }


    public int putBoolean(final String s, final boolean b) {
        final SharedPreferences.Editor edit = this.m_csPref.edit();
        edit.putBoolean(s, b);
        edit.commit();
        Log.e("putBool S = ", "pref_key_rate" + s);
        return 0;
    }

}
