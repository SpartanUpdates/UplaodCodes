﻿namespace BallCollect
{
	public enum VibrateType
	{
		Selection,
		Success,
		Warning,
		Failure,
		LightImpact,
		MediumImpact,
		HeavyImpact,
		None
	}
}
