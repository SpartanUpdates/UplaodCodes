package com.MV.Lyrics.SelectImage.Fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.CropImage.activity.CropImageActivity;
import com.MV.Lyrics.Home.Model.ThemeHorizontalModel;
import com.MV.Lyrics.R;
import com.MV.Lyrics.Retrofit.AppConstant;
import com.MV.Lyrics.SelectImage.Adapter.ImageAdapter;
import com.MV.Lyrics.SelectImage.Interface.OnItemClickListner;
import com.MV.Lyrics.SelectImage.Model.ImageModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;


public class ImageMediaFragment extends Fragment {

    private RecyclerView rvImage;
    private ImageAdapter imageAdapter;
    public ArrayList<ImageModel> imagesList = new ArrayList<>();
    public String FolderName;
    private MyApplication application;
    String imageOrientation;
    public String PathOfImage;

    RelativeLayout rlLoadingTheme;
    public static Fragment getInstance(String foldername, String from) {
        Bundle bundle = new Bundle();
        bundle.putString("FolderName", foldername);
        ImageMediaFragment selectedMediaFragment = new ImageMediaFragment();
        selectedMediaFragment.setArguments(bundle);
        return selectedMediaFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FolderName = getArguments().getString("FolderName");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_selected_media, container, false);
        application = MyApplication.getInstance();
        BindView(view);
        new GetAllImagesByFolder().execute();
        return view;
    }

    private void BindView(View view) {
        rvImage = view.findViewById(R.id.rv_media);
        rlLoadingTheme=view.findViewById(R.id.rl_loading_pager);
    }

    private void SetImageAdapter() {
        imageAdapter = new ImageAdapter(getActivity(), imagesList);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 3);
        rvImage.setLayoutManager(mLayoutManager);
        rvImage.setAdapter(imageAdapter);
        imageAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(View view, int position) {
                if (application.getSelectedImages().size() != 0) {
                    if (application.getSelectedImages().size() <= MyApplication.TotalSelectedImage) {
                        int i = 0;
                        for (final ImageModel imageModel : application.getSelectedImages()) {
                            final String isLandOrPort = getDropboxIMGSize(imageModel.getImagePath());
                            if (i == 0) {
                                PathOfImage = imageModel.getImagePath();
                                imageOrientation = isLandOrPort;
                            } else {
                                PathOfImage = PathOfImage + MyApplication.SPLIT_PATTERN + imageModel.getImagePath();
                                imageOrientation = imageOrientation + "$" + isLandOrPort;
                            }
                            ++i;
                        }
                        MyApplication.IsCropedImageFrom = true;
                        MyApplication.IsCropedExists = true;
                        Intent intent = new Intent(getActivity(), CropImageActivity.class);
                        intent.putExtra("path", PathOfImage);
                        intent.putExtra("IsNew", "0");
                        intent.putExtra("NoofImage", MyApplication.TotalSelectedImage);
                        startActivity(intent);
                        getActivity().finish();
                    } else if (application.getSelectedImages().size() > MyApplication.TotalSelectedImage) {
                        new StringBuilder("Please Remove ").append(application.getSelectedImages().size() - MyApplication.TotalSelectedImage).append(" Images").toString();
                    } else {
                        Toast.makeText(getActivity(), "Selected : " + MyApplication.TotalSelectedImage + " Image", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "Please Select Image!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    /*public void getAllImageByFolderWise(String folderName) {
        imagesList.clear();
        final String[] projection = {"_data", "_id", "bucket_display_name", "bucket_id", "datetaken", "_data"};
        Cursor cursor = getContext().getContentResolver()
                .query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection,
                        MediaStore.Images.Media.BUCKET_DISPLAY_NAME + " =?", new String[]{folderName}, MediaStore.Images.Media.DATE_ADDED);
        ArrayList<ImageModel> images = new ArrayList<>(cursor.getCount());
        HashSet<String> albumSet = new HashSet<>();
        File file;
        ImageModel data = null;
        if (cursor.moveToLast()) {
            do {
                data = new ImageModel();
                data.imagePath = cursor.getString(cursor.getColumnIndex("_data"));
                data.imageThumbnail = cursor.getString(cursor.getColumnIndex("_data"));
                if (Thread.interrupted()) {
                    return;
                }
                file = new File(data.imagePath);
                if (file.exists() && !albumSet.contains(data.imagePath)) {
                    images.add(data);
                    albumSet.add(data.imagePath);
                }
            } while (cursor.moveToPrevious());
        }
        cursor.close();
        if (images == null) {
            images = new ArrayList<>();
        }
        imagesList.clear();
        imagesList.addAll(images);
        SetImageAdapter();
    }*/

    @SuppressLint("StaticFieldLeak")
    public class GetAllImagesByFolder extends AsyncTask<Void, Void, Void> {

        protected void onPreExecute() {
            imagesList.clear();
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected Void doInBackground(Void... arg0) {
            final String[] projection = {"_data", "_id", "bucket_display_name", "bucket_id", "datetaken", "_data"};
            Cursor cursor = getContext().getContentResolver()
                    .query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection,
                            MediaStore.Images.Media.BUCKET_DISPLAY_NAME + " =?", new String[]{FolderName}, MediaStore.Images.Media.DATE_ADDED);
            ArrayList<ImageModel> images = new ArrayList<>(cursor.getCount());
            HashSet<String> albumSet = new HashSet<>();
            File file;
            if (cursor.moveToFirst()) {
                do {
                    ImageModel data = new ImageModel();
                    data.imagePath = cursor.getString(cursor.getColumnIndex("_data"));
                    data.imageThumbnail = cursor.getString(cursor.getColumnIndex("_data"));
                    file = new File(data.imagePath);
                    if (file.exists() && !albumSet.contains(data.imagePath)) {
                        images.add(data);
                        albumSet.add(data.imagePath);
                    }
                } while (cursor.moveToNext());
            }
            cursor.close();
            if (images == null) {
                images = new ArrayList<>();
            }
            imagesList.clear();
            imagesList.addAll(images);
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(Void result) {
            rlLoadingTheme.setVisibility(View.GONE);
            SetImageAdapter();
        }
    }

    private String getDropboxIMGSize(final String uri) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(new File(uri).getAbsolutePath(), options);
        final int imageHeight = options.outHeight;
        final int imageWidth = options.outWidth;
        if (imageHeight > imageWidth) {
            return "P";
        }
        return "L";
    }
}