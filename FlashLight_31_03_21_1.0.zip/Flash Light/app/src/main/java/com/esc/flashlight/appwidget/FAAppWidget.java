package com.esc.flashlight.appwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViews;
import com.esc.flashlight.R;
import com.esc.flashlight.appwidget.receiver.AppWidgetBroadcastReceiver;
import com.esc.flashlight.config.Config;
import com.esc.flashlight.util.IPref;

public class FAAppWidget extends AppWidgetProvider {

    public static final String ACTION_CHANGED_TOTALLY_USE_STATE = " flash.light.shine.CHANGED_TOTALLY_USE_STATE";
    private static final String TAG = "FAAppWidget";

    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] iArr) {
        super.onUpdate(context, appWidgetManager, iArr);
        Log.d(TAG, "onUpdate");
        updateWidgets(context, appWidgetManager, iArr);
    }

    private void updateWidgets(Context context, AppWidgetManager appWidgetManager, int[] iArr) {
        for (int updateAppWidget : iArr) {
            appWidgetManager.updateAppWidget(updateAppWidget, createRemoteView(context));
        }
    }

    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        Log.d(TAG, "onReceive");
        if (intent != null) {
            if (ACTION_CHANGED_TOTALLY_USE_STATE.equals(intent.getAction())) {
                AppWidgetManager instance = AppWidgetManager.getInstance(context);
                int[] appWidgetIds = instance.getAppWidgetIds(new ComponentName(context, FAAppWidget.class));
                for (int i : appWidgetIds) {
                    Log.d(TAG, "running widget id: " + i);
                }
                updateWidgets(context, instance, appWidgetIds);
            }
        }
    }

    public void onEnabled(Context context) {
        super.onEnabled(context);
        Log.d(TAG, "onEnabled");
    }

    public void onDisabled(Context context) {
        super.onDisabled(context);
        Log.d(TAG, "onDisabled");
    }

    public void onDeleted(Context context, int[] iArr) {
        super.onDeleted(context, iArr);
        Log.d(TAG, "onDeleted");
    }

    private RemoteViews createRemoteView(Context context) {
        int i = context.getSharedPreferences(Config.PREF_NAME, 0).getBoolean(IPref.USE_TOTALLY, true) ? R.layout.widget_toggle_state_on : R.layout.widget_toggle_state_off;
        Intent intent = new Intent();
        intent.setAction(AppWidgetBroadcastReceiver.ACTION);
        PendingIntent broadcast = PendingIntent.getBroadcast(context, 0, intent, 0);
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), i);
        remoteViews.setOnClickPendingIntent(R.id.ib_use, broadcast);
        return remoteViews;
    }
}
