package flash.light.shine.com.flashlight.controller;

import android.view.SurfaceView;

public interface BaseFlashControllerInterface {
    void flashOff();

    void flashOn();

    void useStart(SurfaceView surfaceView);

    void useStop();
}
