package com.esc.storymaker.utils;

import android.graphics.Point;
import android.graphics.RectF;

public class RectUtil {
    public static void scaleRect(RectF rectF, float f) {
        float width = rectF.width();
        float height = rectF.height();
        float f2 = ((f * width) - width) / 2.0f;
        f = ((f * height) - height) / 2.0f;
        rectF.left -= f2;
        rectF.top -= f;
        rectF.right += f2;
        rectF.bottom += f;
    }

    public static void rotateRect(RectF rectF, float f, float f2, float f3) {
        float centerX = rectF.centerX();
        float centerY = rectF.centerY();
        double d = (double) f3;
        f3 = (float) Math.sin(Math.toRadians(d));
        float cos = (float) Math.cos(Math.toRadians(d));
        float f4 = centerX - f;
        float f5 = centerY - f2;
        rectF.offset(((f + (f4 * cos)) - (f5 * f3)) - centerX, ((f2 + (f5 * cos)) + (f4 * f3)) - centerY);
    }

    public static void rotatePoint(Point point, float f, float f2, float f3) {
        double d = (double) f3;
        f3 = (float) Math.sin(Math.toRadians(d));
        float cos = (float) Math.cos(Math.toRadians(d));
        point.set((int) ((((((float) point.x) - f) * cos) + f) - ((((float) point.y) - f2) * f3)), (int) ((f2 + ((((float) point.y) - f2) * cos)) + ((((float) point.x) - f) * f3)));
    }
}
