package com.esc.gesturelockscreen.Other;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import com.esc.gesturelockscreen.Activity.WallpaperActivity;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WallpaperUtils {
  public static WallpaperUtils _instance = new WallpaperUtils();
  private ExecutorService mExecutor;
  private Handler mHandler = new Handler(Looper.getMainLooper());

  private WallpaperUtils() {
  }

  public static WallpaperUtils getInstance() {
    return _instance;
  }

  public void destory() {
    if (this.mExecutor != null && !this.mExecutor.isShutdown() && !this.mExecutor.isTerminated()) {
      this.mExecutor.isShutdown();
      this.mExecutor = null;
    }
  }

  public void startLoadImage(final Context context, final ImageView image) {
    this.mExecutor = Executors.newSingleThreadExecutor();
    this.mExecutor.submit(new Runnable() {
      public void run() {
        File f = SettingsUtils.getUserWallpaper();
        InputStream is = null;
        if (f != null) {
          try {
            is = context.getContentResolver().openInputStream(Uri.fromFile(f));
          } catch (FileNotFoundException e) {
            e.printStackTrace();
            is = null;
          }
        }
        if (is == null) {
          try {
            is = context.getResources().openRawResource(WallpaperActivity.backgrounds[SettingsUtils.getInt(SettingsKeys.KEY_INDEX_WALLPAPER, 0)]);
          } catch (Exception e2) {
            is = context.getResources().openRawResource(WallpaperActivity.backgrounds[0]);
          }
        }
        final Bitmap mBitmap = BitmapFactory.decodeStream(is);
        BitmapUtils.closeQuietly(is);
        Handler access$0 = WallpaperUtils.this.mHandler;
        final ImageView imageView = image;
        access$0.post(new Runnable() {
          public void run() {
            imageView.setImageBitmap(mBitmap);
          }
        });
      }
    });
  }
}
