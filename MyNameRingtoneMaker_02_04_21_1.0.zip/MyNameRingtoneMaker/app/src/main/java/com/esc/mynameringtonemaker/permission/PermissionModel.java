package com.esc.mynameringtonemaker.permission;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.pm.PackageManager;
import android.os.Build.VERSION;

import com.esc.mynameringtonemaker.R;

@SuppressLint({"NewApi"})
public class PermissionModel {
    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;
    public static final String[] NECESSARY_PERMISSIONS = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
    private static Context context;

    public static void requestPermissions() {
        ((Activity) context).requestPermissions(NECESSARY_PERMISSIONS, 1);
    }

    public static boolean checkPermission(final Context context) {
        if (VERSION.SDK_INT < 23) {
            return true;
        }
        if (((Activity) context).checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }

        if (((Activity) context).shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)) {
            Builder alertBuilder = new Builder(context);
            alertBuilder.setCancelable(true);
            alertBuilder.setTitle(R.string.permission_necessary);

            alertBuilder.setMessage(R.string.external_storage_and_camera_permission_are_necessary);
            alertBuilder.setPositiveButton(android.R.string.yes, new OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                    ((Activity) context).requestPermissions(PermissionModel.NECESSARY_PERMISSIONS, PermissionModel.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                }
            });
            alertBuilder.create().show();
        } else {
            ((Activity) context).requestPermissions(NECESSARY_PERMISSIONS, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
        }
        return false;
    }
}
