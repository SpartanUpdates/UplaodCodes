package com.kotlinz.videoCollage.flying.poiphoto.datatype;

import android.os.Parcel;
import android.os.Parcelable;

public class Video implements Parcelable {
    public static final Creator<Video> CREATOR = new Creator<Video>() {
        public Video createFromParcel(Parcel parcel) {
            return new Video(parcel);
        }

        public Video[] newArray(int i) {
            return new Video[i];
        }
    };
    private long dataAdded;
    private long dataModified;
    private long duration;
    private String path;

    public int describeContents() {
        return 0;
    }

    public Video(String str, long j, long j2, long j3) {
        this.path = str;
        this.dataAdded = j;
        this.dataModified = j2;
        this.duration = j3;
    }

    protected Video(Parcel parcel) {
        this.path = parcel.readString();
        this.dataAdded = parcel.readLong();
        this.dataModified = parcel.readLong();
        this.duration = parcel.readLong();
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String str) {
        this.path = str;
    }

    public long getDataAdded() {
        return this.dataAdded;
    }

    public void setDataAdded(long j) {
        this.dataAdded = j;
    }

    public long getDataModified() {
        return this.dataModified;
    }

    public void setDataModified(long j) {
        this.dataModified = j;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.path);
        parcel.writeLong(this.dataAdded);
        parcel.writeLong(this.dataModified);
        parcel.writeLong(this.duration);
    }

    public long getDuration() {
        return this.duration;
    }

    public void setDuration(long j) {
        this.duration = j;
    }
}
