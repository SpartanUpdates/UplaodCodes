package com.MV.Lyrics.SelectImage.Adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.R;
import com.MV.Lyrics.SelectImage.Interface.OnItemClickListner;
import com.MV.Lyrics.SelectImage.Model.ImageModel;
import com.makeramen.roundedimageview.RoundedImageView;

import java.util.ArrayList;


public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.MyViewHolder> {
    private MyApplication application;
    private Context context;
    private ArrayList<ImageModel> imageList;
    private OnItemClickListner<Object> clickListner;
    public ImageAdapter(Context context, ArrayList<ImageModel> imageList) {
        application = MyApplication.getInstance();
        this.context = context;
        this.imageList = imageList;
    }

    public void setOnItemClickListner(OnItemClickListner<Object> clickListner) {
        this.clickListner = clickListner;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_image_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        final ImageModel imageModel = imageList.get(position);
        Glide.with(context).load(imageModel.getImagePath()).into(holder.ivThumb);
        holder.layoutImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.ivThumb.getDrawable() == null) {
                    Toast.makeText(context, "Image currpted or not support.", Toast.LENGTH_LONG).show();
                    return;
                }
                if (application.getSelectedImages().size() < MyApplication.TotalSelectedImage) {
                    application.addSelectedImage(imageModel);
                    notifyItemChanged(position);

                } else {
                    Toast.makeText(context, "Please Select only " + MyApplication.TotalSelectedImage + " Image", Toast.LENGTH_SHORT).show();
                }
                if (clickListner != null) {
                    clickListner.onItemClick(view, position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return imageList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public RoundedImageView ivThumb, check;
        public RelativeLayout layoutImage;

        public MyViewHolder(View view) {
            super(view);
            layoutImage = view.findViewById(R.id.rl_image);
            ivThumb = view.findViewById(R.id.iv_thumb);
            check = view.findViewById(R.id.imageView1);
        }
    }
}

