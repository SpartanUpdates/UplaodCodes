package com.esc.phoneheart.activity;

import java.io.File;
import java.io.FileFilter;

import androidx.core.app.NotificationCompat;

public class ImageFileFilter implements FileFilter {
    public String[] fileExtensions = new String[]{"jpg", "jpeg"};

    public ImageFileFilter(int i) {
        int i2 = i;
        if (i2 == 0) {
            this.fileExtensions = new String[]{"jpeg", "jpg", "png", "tiff", "tif", "bmp"};
        } else if (i2 == 1) {
            this.fileExtensions = new String[]{"mp4", "gif", "mpg", "3gp", "avi", "mpeg"};
        } else if (i2 == 2) {
            this.fileExtensions = new String[]{"mp3", "aac", "m4a", "wav"};
        } else if (i2 == 3) {
            this.fileExtensions = new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"};
        } else if (i2 == 4) {
            this.fileExtensions = new String[]{"mp4"};
        }
    }

    public boolean accept(File file) {
        for (String endsWith : this.fileExtensions) {
            if (file.getName().toLowerCase().endsWith(endsWith)) {
                return true;
            }
        }
        return false;
    }
}
