package com.esc.photovault.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.esc.photovault.R;
import com.squareup.picasso.Picasso;

public class StatePage extends AppCompatActivity {

    public static String myIntValue;
    int[] myImageList = new int[]{R.mipmap.image1, R.mipmap.image2, R.mipmap.image3};
    TextView skip_txt;
    Button swaip_1;
    Button swaip_2;
    Button swaip_3;
    ViewPager viewPager;

    class C06321 implements OnClickListener {
        C06321() {
        }

        public void onClick(View view) {
            StatePage.myIntValue = StatePage.this.getSharedPreferences("password_main", 0).getString("pwd_main", null);
            StatePage.this.startActivity(new Intent(StatePage.this, LockScreenActivity.class));
            if (StatePage.myIntValue != null) {
                Toast.makeText(StatePage.this, "Pwd alerady store", Toast.LENGTH_LONG).show();
            }
        }
    }

    class C06332 implements ViewPager.OnPageChangeListener {
        C06332() {
        }

        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        public void onPageSelected(int position) {
            if (position == 0) {
                StatePage.this.swaip_1.setBackgroundResource(R.drawable.fill_round);
                StatePage.this.swaip_2.setBackgroundResource(R.drawable.board);
                StatePage.this.swaip_3.setBackgroundResource(R.drawable.board);
            } else if (position == 1) {
                StatePage.this.swaip_1.setBackgroundResource(R.drawable.board);
                StatePage.this.swaip_2.setBackgroundResource(R.drawable.fill_round);
                StatePage.this.swaip_3.setBackgroundResource(R.drawable.board);
            } else if (position == 2) {
                StatePage.this.swaip_1.setBackgroundResource(R.drawable.board);
                StatePage.this.swaip_2.setBackgroundResource(R.drawable.board);
                StatePage.this.swaip_3.setBackgroundResource(R.drawable.fill_round);
            }
        }

        public void onPageScrollStateChanged(int state) {
        }
    }

    class CustomPagerAdapter extends PagerAdapter {
        Context mContext;
        LayoutInflater mLayoutInflater = ((LayoutInflater) this.mContext.getSystemService(LAYOUT_INFLATER_SERVICE));

        public CustomPagerAdapter(Context context) {
            this.mContext = context;
        }

        public int getCount() {
            return StatePage.this.myImageList.length;
        }

        public boolean isViewFromObject(View view, Object object) {
            return view == ((RelativeLayout) object);
        }

        public Object instantiateItem(ViewGroup container, int position) {
            View itemView = this.mLayoutInflater.inflate(R.layout.subsignleimage, container, false);
            Picasso.with(StatePage.this.getApplicationContext()).load(StatePage.this.myImageList[position]).into((ImageView) itemView.findViewById(R.id.photo_view));
            container.addView(itemView);
            return itemView;
        }

        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((RelativeLayout) object);
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_state_page);
        this.viewPager = (ViewPager) findViewById(R.id.pageView);
        this.skip_txt = (TextView) findViewById(R.id.skip_txt);
        this.swaip_1 = (Button) findViewById(R.id.swip_1);
        this.swaip_2 = (Button) findViewById(R.id.swip_2);
        this.swaip_3 = (Button) findViewById(R.id.swip_3);
        this.viewPager.setAdapter(new CustomPagerAdapter(this));
        this.swaip_1.setBackgroundResource(R.drawable.fill_round);
        this.swaip_2.setBackgroundResource(R.drawable.board);
        this.swaip_3.setBackgroundResource(R.drawable.board);
        this.skip_txt.setOnClickListener(new C06321());
        this.viewPager.addOnPageChangeListener(new C06332());
    }
}
