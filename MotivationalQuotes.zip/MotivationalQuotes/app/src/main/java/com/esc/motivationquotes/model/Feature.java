package com.esc.motivationquotes.model;

import java.io.Serializable;

public class Feature implements Serializable {
    private int icon;
    private String subtitle;
    private String title;

    public int getIcon() {
        return this.icon;
    }

    public void setIcon(int i) {
        this.icon = i;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getSubtitle() {
        return this.subtitle;
    }

    public void setSubtitle(String str) {
        this.subtitle = str;
    }
}
