package com.wavymusic.Fragment;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wavymusic.Adapter.PhoneSongAdapter;
import com.wavymusic.Model.PhoneSong;
import com.wavymusic.Model.PhoneSongModel;
import com.wavymusic.R;
import com.wavymusic.activity.PhoneSongActivity;

import java.util.List;

import static com.wavymusic.activity.PhoneSongActivity.PhoneSongFolders;

public class PhoneSongByCatFragment extends Fragment {

    public List<PhoneSongModel> PhonsSongList;
    public PhoneSong phoneSong;
    Integer Folderid = -1;
    Integer TabIndex = -1;
    RecyclerView rvPhoneSong;
    PhoneSongAdapter mPhonsSongAdp;



    public static Fragment getInstance(int Folderid, int TabIndex) {
        Bundle bundle = new Bundle();
        bundle.putInt("Folderid", Folderid);
        bundle.putInt("TabIndex", TabIndex);
        PhoneSongByCatFragment songByCatFragmentent = new PhoneSongByCatFragment();
        songByCatFragmentent.setArguments(bundle);
        return songByCatFragmentent;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Folderid = getArguments().getInt("Folderid");
        TabIndex = getArguments().getInt("TabIndex");
    }
    public int getFolderid() {
        return this.Folderid;
    }

    public int getTabIndex() {
        return this.TabIndex;
    }
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_phone_song, container, false);
        phoneSong = PhoneSongFolders.getMusicFolders().get(Folderid);
        PhonsSongList = phoneSong.getLocalTracks();
        rvPhoneSong = view.findViewById(R.id.rv_recycler_view);
        mPhonsSongAdp = new PhoneSongAdapter(this,getContext(), PhonsSongList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvPhoneSong.setLayoutManager(mLayoutManager);
        rvPhoneSong.setItemAnimator(new DefaultItemAnimator());
        rvPhoneSong.setAdapter(mPhonsSongAdp);
        return view;
    }


}
