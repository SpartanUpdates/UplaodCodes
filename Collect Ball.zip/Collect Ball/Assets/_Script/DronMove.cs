﻿using UnityEngine;
using System.Collections.Generic;
namespace BallCollect
{
    public class DronMove : MonoBehaviour
    {
        public float Speed = 1;

        [Range(0.01f, 0.2f)]
        public float spawnWait = 0.05f;

        public bool isSpawnBall = false;

        public GameObject DronRoot;

        public bool isStart = true;

        public bool Animation = true;

        public Animator wingAnimator;

        public DronMove fastDronMove;

        internal bool nextParbola = false;

        protected float animationTime = float.MaxValue;

        protected DronFly gizmo;

        protected DronFly dronFly;

        public GameObject ball;
        void OnDrawGizmos()
        {
            if (gizmo == null)
            {
                gizmo = new DronFly(DronRoot.transform);
            }

            gizmo.RefreshTransforms(1f);
            if ((gizmo.Points.Length - 1) % 2 != 0)
                return;

            int accur = 50;
            Vector3 prevPos = gizmo.Points[0].position;
            for (int c = 1; c <= accur; c++)
            {
                float currTime = c * gizmo.GetDuration() / accur;
                Vector3 currPos = gizmo.GetPositionAtTime(currTime);
                float mag = (currPos - prevPos).magnitude * 2;
                Gizmos.color = new Color(mag, 0, 0, 1);
                Gizmos.DrawLine(prevPos, currPos);
                Gizmos.DrawSphere(currPos, 0.01f);
                prevPos = currPos;
            }
        }


        void Start()
        {
            dronFly = new DronFly(DronRoot.transform);
        }
        float ballWait = 0;
        GameObject go;
        void FixedUpdate()
        {
            if (isStart)
            {
                isStart = false;
                RefreshTransforms(Speed);
                wingAnimator.enabled = true;
                FollowDron();
            }
            nextParbola = false;

            if (Animation && dronFly != null && animationTime < dronFly.GetDuration())
            {
                int DronIndexBefore;
                int DronIndexAfter;
                dronFly.GetDronIndexAtTime(animationTime, out DronIndexBefore);
                animationTime += Time.fixedDeltaTime;


                dronFly.GetDronIndexAtTime(animationTime, out DronIndexAfter);

                transform.position = dronFly.GetPositionAtTime(animationTime);

                if (DronIndexBefore != DronIndexAfter)
                    nextParbola = true;

                if (animationTime >= ballWait && isSpawnBall)
                {
                    ballWait = animationTime + spawnWait;
                    go = Instantiate(ball, transform.position, Quaternion.identity);
                    go.transform.SetParent(this.gameObject.transform.parent);

                }
            }
            else if (Animation && dronFly != null && animationTime > dronFly.GetDuration())
            {
                animationTime = float.MaxValue;
                Animation = false;
                if (dronFly.GetDuration() > 0.4f)
                {
                    if (fastDronMove != null)
                    {
                        if (fastDronMove.enabled == false)
                        {
                            fastDronMove.enabled = true;
                            this.enabled = false;
                            fastDronMove.isStart = true;
                        }
                    }
                }
            }
        }
        private void OnDestroy()
        {
            Destroy(GetComponent<DronMove>());
        }
        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                this.GetComponent<BoxCollider>().enabled = false;
                this.isStart = true;
            }
        }
        public void FollowDron()
        {
            RefreshTransforms(Speed);
            animationTime = 0f;
            transform.position = dronFly.Points[0].position;
            Animation = true;
        }

        public Vector3 getHighestPoint(int dronIndex)
        {
            return dronFly.getHighestPoint(dronIndex);
        }

        public Transform[] getPoints()
        {
            return dronFly.Points;
        }

        public Vector3 GetPositionAtTime(float time)
        {
            return dronFly.GetPositionAtTime(time);
        }

        public float GetDuration()
        {
            return dronFly.GetDuration();
        }

        public void StopFollow()
        {
            animationTime = float.MaxValue;
        }

        public void RefreshTransforms(float speed)
        {
            dronFly.RefreshTransforms(speed);
        }


        public static float DistanceToLine(Ray ray, Vector3 point)
        {
            return Vector3.Cross(ray.direction, point - ray.origin).magnitude;
        }

        public static Vector3 ClosestPointInLine(Ray ray, Vector3 point)
        {
            return ray.origin + ray.direction * Vector3.Dot(ray.direction, point - ray.origin);
        }

        public class DronFly
        {
            public Transform[] Points;
            protected Dron3D[] drons;
            protected float[] partDuration;
            protected float completeDuration;

            public DronFly(Transform DronRoot)
            {

                List<Component> components = new List<Component>(DronRoot.GetComponentsInChildren(typeof(Transform)));
                List<Transform> transforms = components.ConvertAll(c => (Transform)c);

                transforms.Remove(DronRoot.transform);
                transforms.Sort(delegate (Transform a, Transform b)
                {
                    return a.name.CompareTo(b.name);
                });

                Points = transforms.ToArray();

                if ((Points.Length - 1) % 2 != 0)
                    throw new UnityException("DronRoot needs odd number of points");

                if (drons == null || drons.Length < (Points.Length - 1) / 2)
                {
                    drons = new Dron3D[(Points.Length - 1) / 2];
                    partDuration = new float[drons.Length];
                }

            }

            public Vector3 GetPositionAtTime(float time)
            {
                int dronIndex;
                float timeInDron;
                GetDronIndexAtTime(time, out dronIndex, out timeInDron);

                var percent = timeInDron / partDuration[dronIndex];
                return drons[dronIndex].GetPositionAtLength(percent * drons[dronIndex].Length);
            }

            public void GetDronIndexAtTime(float time, out int dronIndex)
            {
                float timeInDron;
                GetDronIndexAtTime(time, out dronIndex, out timeInDron);
            }

            public void GetDronIndexAtTime(float time, out int dronIndex, out float timeInDron)
            {
                timeInDron = time;
                dronIndex = 0;

                while (dronIndex < drons.Length - 1 && partDuration[dronIndex] < timeInDron)
                {
                    timeInDron -= partDuration[dronIndex];
                    dronIndex++;
                }
            }

            public float GetDuration()
            {
                return completeDuration;
            }

            public Vector3 getHighestPoint(int dronIndex)
            {
                return drons[dronIndex].getHighestPoint();
            }

            public void RefreshTransforms(float speed)
            {
                if (speed <= 0f)
                    speed = 1f;

                if (Points != null)
                {

                    completeDuration = 0;

                    //create drons
                    for (int i = 0; i < drons.Length; i++)
                    {
                        if (drons[i] == null)
                            drons[i] = new Dron3D();

                        drons[i].Set(Points[i * 2].position, Points[i * 2 + 1].position, Points[i * 2 + 2].position);
                        partDuration[i] = drons[i].Length / speed;
                        completeDuration += partDuration[i];
                    }
                }
            }
        }

        public class Dron3D
        {
            public float Length { get; private set; }

            public Vector3 A;
            public Vector3 B;
            public Vector3 C;

            protected Dron2D dron2D;
            protected Vector3 h;
            protected bool tooClose;

            public Dron3D()
            {
            }

            public Dron3D(Vector3 A, Vector3 B, Vector3 C)
            {
                Set(A, B, C);
            }

            public void Set(Vector3 A, Vector3 B, Vector3 C)
            {
                this.A = A;
                this.B = B;
                this.C = C;
                refreshCurve();
            }

            public Vector3 getHighestPoint()
            {
                var d = (C.y - A.y) / dron2D.Length;
                var e = A.y - C.y;

                var dronCompl = new Dron2D(dron2D.a, dron2D.b + d, dron2D.c + e, dron2D.Length);

                Vector3 E = new Vector3();
                E.y = dronCompl.E.y;
                E.x = A.x + (C.x - A.x) * (dronCompl.E.x / dronCompl.Length);
                E.z = A.z + (C.z - A.z) * (dronCompl.E.x / dronCompl.Length);

                return E;
            }

            public Vector3 GetPositionAtLength(float length)
            {
                //f(x) = axÂ² + bx + c
                var percent = length / Length;

                var x = percent * (C - A).magnitude;
                if (tooClose)
                    x = percent * 2f;

                Vector3 pos;

                pos = A * (1f - percent) + C * percent + h.normalized * dron2D.f(x);
                if (tooClose)
                    pos.Set(A.x, pos.y, A.z);

                return pos;
            }

            private void refreshCurve()
            {

                if (Vector2.Distance(new Vector2(A.x, A.z), new Vector2(B.x, B.z)) < 0.1f &&
                    Vector2.Distance(new Vector2(B.x, B.z), new Vector2(C.x, C.z)) < 0.1f)
                    tooClose = true;
                else
                    tooClose = false;

                Length = Vector3.Distance(A, B) + Vector3.Distance(B, C);

                if (!tooClose)
                {
                    refreshCurveNormal();
                }
                else
                {
                    refreshCurveClose();
                }
            }


            private void refreshCurveNormal()
            {
                Ray rl = new Ray(A, C - A);
                var v1 = ClosestPointInLine(rl, B);

                Vector2 A2d, B2d, C2d;

                A2d.x = 0f;
                A2d.y = 0f;
                B2d.x = Vector3.Distance(A, v1);
                B2d.y = Vector3.Distance(B, v1);
                C2d.x = Vector3.Distance(A, C);
                C2d.y = 0f;

                dron2D = new Dron2D(A2d, B2d, C2d);

                h = (B - v1) / Vector3.Distance(v1, B) * dron2D.E.y;
            }

            private void refreshCurveClose()
            {
                var fac01 = (A.y <= B.y) ? 1f : -1f;
                var fac02 = (A.y <= C.y) ? 1f : -1f;

                Vector2 A2d, B2d, C2d;

                A2d.x = 0f;
                A2d.y = 0f;

                B2d.x = 1f;
                B2d.y = Vector3.Distance((A + C) / 2f, B) * fac01;

                C2d.x = 2f;
                C2d.y = Vector3.Distance(A, C) * fac02;

                dron2D = new Dron2D(A2d, B2d, C2d);
                h = Vector3.up;
            }
        }

        public class Dron2D
        {
            public float a { get; private set; }
            public float b { get; private set; }
            public float c { get; private set; }

            public Vector2 E { get; private set; }
            public float Length { get; private set; }

            public Dron2D(float a, float b, float c, float length)
            {
                this.a = a;
                this.b = b;
                this.c = c;

                setMetadata();
                this.Length = length;
            }

            public Dron2D(Vector2 A, Vector2 B, Vector2 C)
            {
                var divisor = ((A.x - B.x) * (A.x - C.x) * (C.x - B.x));
                if (divisor == 0f)
                {
                    A.x += 0.00001f;
                    B.x += 0.00002f;
                    C.x += 0.00003f;
                    divisor = ((A.x - B.x) * (A.x - C.x) * (C.x - B.x));
                }
                a = (A.x * (B.y - C.y) + B.x * (C.y - A.y) + C.x * (A.y - B.y)) / divisor;
                b = (A.x * A.x * (B.y - C.y) + B.x * B.x * (C.y - A.y) + C.x * C.x * (A.y - B.y)) / divisor;
                c = (A.x * A.x * (B.x * C.y - C.x * B.y) + A.x * (C.x * C.x * B.y - B.x * B.x * C.y) + B.x * C.x * A.y * (B.x - C.x)) / divisor;

                b = b * -1f;//hack

                setMetadata();
                Length = Vector2.Distance(A, C);
            }

            public float f(float x)
            {
                return a * x * x + b * x + c;
            }

            private void setMetadata()
            {
                //derive
                //a*xÂ²+b*x+c = 0
                //2ax+b=0
                //x = -b/2a
                var x = -b / (2 * a);
                E = new Vector2(x, f(x));
            }
        }
    }
}