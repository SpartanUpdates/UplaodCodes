package com.esc.motivationquotes.util;

import android.graphics.Color;

public class ColorUtils {
    public static boolean isDarkColor(int i) {
        double red = (double) Color.red(i);
        Double.isNaN(red);
        red *= 0.299d;
        double green = (double) Color.green(i);
        Double.isNaN(green);
        red += green * 0.587d;
        green = (double) Color.blue(i);
        Double.isNaN(green);
        return 1.0d - ((red + (green * 0.114d)) / 255.0d) >= 0.5d;
    }
}
