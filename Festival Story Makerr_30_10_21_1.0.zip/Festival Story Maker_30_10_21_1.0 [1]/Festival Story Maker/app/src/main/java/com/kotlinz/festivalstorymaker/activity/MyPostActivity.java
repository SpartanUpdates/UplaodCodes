package com.kotlinz.festivalstorymaker.activity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.DashBord.AllModuleAdapter;
import com.kotlinz.festivalstorymaker.Adapter.MyCreationAdapter;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;

import java.io.File;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.kotlinz.festivalstorymaker.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;


public class MyPostActivity extends BaseActivity {

    Activity activity = MyPostActivity.this;

    @BindView(R.id.rv_my_post)
    public RecyclerView rvMyPost;

    @BindView(R.id.txtDataNotAvailable)
    public TextView txtDataNotAvailable;


    ArrayList<String> myPostList = new ArrayList();
    File[] listFile;
    public GridLayoutManager mLayoutManager;
    MyCreationAdapter myCreationAdapter;

    private NativeAd nativeAd;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_my_post);
        ButterKnife.bind(this);
        PutAnalyticsEvent();
        loadAd();
        GetAllFile();
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MyPostActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void loadAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (MyPostActivity.this.nativeAd != null) {
                            MyPostActivity.this.nativeAd.destroy();
                        }
                        MyPostActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void GetAllFile() {
        try {
            myPostList.clear();
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "My Post");
            if (file.isDirectory()) {
                this.listFile = file.listFiles();
                int length = listFile.length;
                for (int i = 0; i < this.listFile.length; i++) {
                    int i2 = length - 1;
                    if (MyApplication.isImageFile(this.listFile[i2].getAbsolutePath())) {
                        myPostList.add(listFile[i2].getAbsolutePath());
                    }
                    length--;
                }
                SetAdapter();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void SetAdapter() {
        myCreationAdapter = new MyCreationAdapter(activity, myPostList);
        mLayoutManager = new GridLayoutManager(activity, 2, GridLayoutManager.VERTICAL, false);
        rvMyPost.setLayoutManager(mLayoutManager);
        rvMyPost.setAdapter(myCreationAdapter);
    }

    @OnClick(R.id.iv_back)
    public void GoToBack() {
        if (MyApplication.isShowAd == 1) {
            onBackPressed();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 14;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                onBackPressed();
            }
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(activity, DashBordActivity.class));
        finish();
    }
}