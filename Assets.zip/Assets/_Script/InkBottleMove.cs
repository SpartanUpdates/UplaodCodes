﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InkBottleMove : MonoBehaviour
{
    public GameObject breakBottle, particleEffect;

    void OnTriggerEnter(Collider target)
    {
        if (target.CompareTag("Player"))
        {
            particleEffect.SetActive(true);
            breakBottle.SetActive(true);
            Destroy(this.transform.parent.gameObject, 2);
        }
    }
}
