package com.kotlinz.festivalstorymaker.Adapter.Story;


import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Model.StoryMaker.StoryMainCategory;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Utils;
import com.kotlinz.festivalstorymaker.activity.StoryMakerActivity;

import java.util.ArrayList;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class StoryCategoryAdapter extends RecyclerView.Adapter<StoryCategoryAdapter.MyViewHolder> {

    public StoryMakerActivity storyActivity;
    public String h = "0";
    public int SelectedPosition = 0;
    public ArrayList<StoryMainCategory> storyCategoryList;

    public StoryCategoryAdapter(Context context, ArrayList<StoryMainCategory> storyCategoryList) {
        this.storyActivity = (StoryMakerActivity) context;
        this.storyCategoryList = storyCategoryList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_story_category, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.tvCategoryName.setText(storyCategoryList.get(position).getCatName());
        if (SelectedPosition == position) {
            holder.tvCategoryName.setTextColor(storyActivity.getResources().getColor(R.color.child_cat_text_press));
            Glide.with(storyActivity).load(Utils.StoryMakerCategoryPress(storyCategoryList.get(position).getCatName())).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivCategoryThumb);
        } else {
            holder.tvCategoryName.setTextColor(storyActivity.getResources().getColor(R.color.child_cat_text_unpress));
            Glide.with(storyActivity).load(Utils.StoryMakerCategory(storyCategoryList.get(position).getCatName())).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivCategoryThumb);
        }
        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectedPosition = position;
                if (com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(storyActivity, false)) {
                    if (ThemeDataPreferences.INSTANCE.getPreferencesData(storyActivity, ThemeDataPreferences.StoryMakerTheme + storyActivity.IsFrom + storyCategoryList.get(position).getCatId() + storyCategoryList.get(position).getChildCategory().get(0).getChildCatId()).equalsIgnoreCase("")) {
                        storyActivity.GetStoryCategoryDataByID(String.valueOf(storyCategoryList.get(position).getCatId()), String.valueOf(storyCategoryList.get(position).getChildCategory().get(0).getChildCatId()));

                    } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(storyActivity, ThemeDataPreferences.StoryMakerThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                        storyActivity.GetStoryCategoryDataByID(String.valueOf(storyCategoryList.get(position).getCatId()), String.valueOf(storyCategoryList.get(position).getChildCategory().get(0).getChildCatId()));

                    } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(storyActivity, ThemeDataPreferences.StoryMakerTheme + storyActivity.IsFrom + storyCategoryList.get(position).getCatId() + storyCategoryList.get(position).getChildCategory().get(0).getChildCatId()).equalsIgnoreCase("")) {

                        storyActivity.SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(storyActivity, ThemeDataPreferences.StoryMakerTheme + storyActivity.IsFrom + storyCategoryList.get(position).getCatId() + storyCategoryList.get(position).getChildCategory().get(0).getChildCatId()));
                    }
                } else {
                    if (ThemeDataPreferences.INSTANCE.getPreferencesData(storyActivity, ThemeDataPreferences.StoryMakerTheme + storyActivity.IsFrom + storyCategoryList.get(position).getCatId() + storyCategoryList.get(position).getChildCategory().get(0).getChildCatId()).equalsIgnoreCase("")) {
                        storyActivity.rlMainData.setVisibility(View.GONE);
                        storyActivity.llRetry.setVisibility(View.VISIBLE);

                    } else {
                        storyActivity.SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(storyActivity, ThemeDataPreferences.StoryMakerTheme + storyActivity.IsFrom + storyCategoryList.get(position).getCatId() + storyCategoryList.get(position).getChildCategory().get(0).getChildCatId()));
                    }
                }
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return storyCategoryList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.ivCategoryThumb)
        public ImageView ivCategoryThumb;
        @BindView(R.id.llMain)
        public LinearLayout llMain;
        @BindView(R.id.tvCategoryName)
        public TextView tvCategoryName;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
