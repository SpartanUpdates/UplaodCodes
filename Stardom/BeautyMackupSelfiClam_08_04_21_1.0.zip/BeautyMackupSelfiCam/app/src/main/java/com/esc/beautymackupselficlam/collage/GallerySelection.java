package com.esc.beautymackupselficlam.collage;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.os.Bundle;
import android.provider.MediaStore;
import com.esc.beautymackupselficlam.Activity.CollagePhotoEdiotrActivity;
import com.esc.beautymackupselficlam.adapter.CustomGalleryAdapter;
import com.esc.beautymackupselficlam.library.Utility;
import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration.Builder;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class GallerySelection extends Activity {
    private static int RESULT_LOAD_IMAGE = 1;
    public static Bitmap bitmap_five;
    public static Bitmap bitmap_four;
    public static Bitmap bitmap_one;
    public static Bitmap bitmap_six;
    public static Bitmap bitmap_three;
    public static Bitmap bitmap_two;
    public static int int_photo_size = 0;
    private CustomGalleryAdapter customGalleryadapter;
    private ImageLoader imageLoader;
    private ArrayList<String> imagePaths;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initImageLoader();
        init();

        Intent intent2 = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent2.setType("image/*");
        startActivityForResult(intent2, 200);
    }

    private void initImageLoader() {
        ImageLoaderConfiguration config = new Builder(this).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheOnDisc().imageScaleType(ImageScaleType.EXACTLY_STRETCHED).bitmapConfig(Config.RGB_565).build()).memoryCache(new WeakMemoryCache()).build();
        this.imageLoader = ImageLoader.getInstance();
        this.imageLoader.init(config);
    }

    private void init() {
        this.customGalleryadapter = new CustomGalleryAdapter(getApplicationContext(), this.imageLoader);
        this.customGalleryadapter.setMultiplePick(false);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        this.imagePaths = new ArrayList();
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == -1 && data != null) {
            String[] filePathColumn = new String[]{"_data"};
            Cursor cursor = getContentResolver().query(data.getData(), filePathColumn, null, null, null);
            cursor.moveToFirst();
            String picturePath = cursor.getString(cursor.getColumnIndex(filePathColumn[0]));
            cursor.close();
        } else if (requestCode == 200 && resultCode == -1) {
            String[] all_path = data.getStringArrayExtra("all_path");
            ArrayList<CustomGallery> dataT = new ArrayList();
            for (String string : all_path) {
                CustomGallery item = new CustomGallery();
                item.sdcardPath = string;
                this.imagePaths.add(string);
                dataT.add(item);
            }
            int_photo_size = this.imagePaths.size();
            if (this.imagePaths.size() == 1) {
                bitmap_one = CreateBitmap((String) this.imagePaths.get(0));
            } else if (this.imagePaths.size() == 2) {
                bitmap_one = CreateBitmap((String) this.imagePaths.get(0));
                bitmap_two = CreateBitmap((String) this.imagePaths.get(1));
            } else if (this.imagePaths.size() == 3) {
                bitmap_one = CreateBitmap((String) this.imagePaths.get(0));
                bitmap_two = CreateBitmap((String) this.imagePaths.get(1));
                bitmap_three = CreateBitmap((String) this.imagePaths.get(2));
            } else if (this.imagePaths.size() == 4) {
                bitmap_one = CreateBitmap((String) this.imagePaths.get(0));
                bitmap_two = CreateBitmap((String) this.imagePaths.get(1));
                bitmap_three = CreateBitmap((String) this.imagePaths.get(2));
                bitmap_four = CreateBitmap((String) this.imagePaths.get(3));
            } else if (this.imagePaths.size() == 5) {
                bitmap_one = CreateBitmap((String) this.imagePaths.get(0));
                bitmap_two = CreateBitmap((String) this.imagePaths.get(1));
                bitmap_three = CreateBitmap((String) this.imagePaths.get(2));
                bitmap_four = CreateBitmap((String) this.imagePaths.get(3));
                bitmap_five = CreateBitmap((String) this.imagePaths.get(4));
            } else if (this.imagePaths.size() >= 6) {
                bitmap_one = CreateBitmap((String) this.imagePaths.get(0));
                bitmap_two = CreateBitmap((String) this.imagePaths.get(1));
                bitmap_three = CreateBitmap((String) this.imagePaths.get(2));
                bitmap_four = CreateBitmap((String) this.imagePaths.get(3));
                bitmap_five = CreateBitmap((String) this.imagePaths.get(4));
                bitmap_six = CreateBitmap((String) this.imagePaths.get(5));
            }
            startActivity(new Intent(GallerySelection.this, CollagePhotoEdiotrActivity.class));
            finish();
        } else if (requestCode == 200 && resultCode == 0) {
            finish();
        }
    }

    private Bitmap CreateBitmap(String filePath) {
        Bitmap bitmap = null;
        File f = new File(filePath);
        Options options = new Options();
        options.inPreferredConfig = Config.ARGB_8888;
        try {
            bitmap = Utility.modifyOrientation(Utility.getResizedBitmap(BitmapFactory.decodeStream(new FileInputStream(f), null, options), 400), f.getAbsolutePath());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return bitmap;
    }
}
