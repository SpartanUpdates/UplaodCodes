package com.kotlinz.videoCollage.flying.poiphoto.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Album;
import com.kotlinz.videoCollage.flying.poiphoto.ui.custom.SquareImageView;
import com.kotlinz.videoeditor.R;

import java.util.List;

public class AlbumAdapter extends Adapter<AlbumAdapter.AlbumViewHolder> {
    private List<Album> mData;
    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(View view, int i);
    }

    public static class AlbumViewHolder extends ViewHolder {
        LinearLayout mAlbumContainer;
        SquareImageView mIvPhoto;
        TextView mTvTitle;

        public AlbumViewHolder(View view) {
            super(view);
            this.mIvPhoto = (SquareImageView) view.findViewById(R.id.iv_photo);
            this.mTvTitle = (TextView) view.findViewById(R.id.tv_title);
            this.mAlbumContainer = (LinearLayout) view.findViewById(R.id.album_container);
        }
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public List<Album> getData() {
        return this.mData;
    }

    public void refreshData(List<Album> list) {
        this.mData = list;
        notifyDataSetChanged();
    }

    public AlbumViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new AlbumViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.poiphoto_item_album, viewGroup, false));
    }

    public void onBindViewHolder(final AlbumViewHolder albumViewHolder, int i) {
        albumViewHolder.mTvTitle.setText(((Album) this.mData.get(i)).getName());
        ((RequestBuilder) Glide.with(albumViewHolder.itemView.getContext()).load(((Album) this.mData.get(i)).getCoverPath()).centerCrop()).into(albumViewHolder.mIvPhoto);
        albumViewHolder.mAlbumContainer.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (AlbumAdapter.this.mOnItemClickListener != null) {
                    AlbumAdapter.this.mOnItemClickListener.onItemClick(view, albumViewHolder.getAdapterPosition());
                }
            }
        });
    }

    public String getBuckedId(int i) {
        List list = this.mData;
        return (list == null || list.size() < i) ? "null" : ((Album) this.mData.get(i)).getId();
    }

    public int getItemCount() {
        List list = this.mData;
        return list == null ? 0 : list.size();
    }
}
