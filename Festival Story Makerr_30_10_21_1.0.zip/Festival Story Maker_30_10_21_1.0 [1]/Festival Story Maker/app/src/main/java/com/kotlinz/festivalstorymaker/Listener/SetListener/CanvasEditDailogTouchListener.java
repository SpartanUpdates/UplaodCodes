package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;


public class CanvasEditDailogTouchListener implements View.OnTouchListener
{
    public final  GestureDetector gestureDetector;
    public final  TextView textView;
    public final CanvasEditorActivity activity;

    public CanvasEditDailogTouchListener(final CanvasEditorActivity g, final GestureDetector e, final TextView f) {
        this.activity = g;
        this.gestureDetector = e;
        this.textView = f;
    }

    public boolean onTouch(final View view, final MotionEvent motionEvent) {
        if (this.gestureDetector.onTouchEvent(motionEvent)) {
            return true;
        }
        final CanvasEditorActivity g = this.activity;
        if (!g.f1) {
            if (this.textView.getBackground() != null) {
                final int actionMasked = motionEvent.getActionMasked();
                if (actionMasked != 0) {
                    if (actionMasked != 1) {
                        if (actionMasked == 2) {
                            this.activity.scroll.requestDisallowInterceptTouchEvent(true);
                            view.setY(motionEvent.getRawY() + this.activity.i1);
                            view.setX(motionEvent.getRawX() + this.activity.h1);
                            return true;
                        }
                        if (actionMasked != 6) {
                            return false;
                        }
                    }
                    this.textView.setBackground((Drawable)null);
                    return true;
                }
                this.activity.scroll.requestDisallowInterceptTouchEvent(true);
                this.activity.h1 = view.getX() - motionEvent.getRawX();
                this.activity.i1 = view.getY() - motionEvent.getRawY();
            }
            return true;
        }
        return g.f1 = false;
    }
}
