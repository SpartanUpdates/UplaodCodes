package com.xyz.vehiclemanager.favourite.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.favourite.fragment.BikeFragment;
import com.xyz.vehiclemanager.favourite.fragment.CarFragment;
import com.xyz.vehiclemanager.adapter.HomeFragmentPageAdapter;

public class FavouriteTabActivity extends AppCompatActivity {
    Activity activity = FavouriteTabActivity.this;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ImageView iv_back;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite_tab);
        iv_back = findViewById(R.id.iv_back);

        viewPager = findViewById(R.id.viewPager);
        setViewPager();
        PutAnalyticsEvent();
        BannerAds();
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);
        CreateTab();

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void setViewPager() {
        HomeFragmentPageAdapter HomePageAdapter = new HomeFragmentPageAdapter(getSupportFragmentManager());
        HomePageAdapter.addFragment(new CarFragment(), "Car");
        HomePageAdapter.addFragment(new BikeFragment(), "Bike");
        viewPager.setAdapter(HomePageAdapter);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "FavouriteTabActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void CreateTab() {
        TextView Car = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        Car.setText("Car");
        tabLayout.getTabAt(0).setCustomView(Car);

        TextView Bike = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        Bike.setText("Bike");
        tabLayout.getTabAt(1).setCustomView(Bike);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}