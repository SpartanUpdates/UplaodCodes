package com.mbit.VideoMaker.Activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.UnityPlayerActivity;
import com.mbit.VideoMaker.application.AppFontStyle;

public class ExitActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = ExitActivity.this;
    ImageButton ibClose, ibInstall, ibExit, ibRate;
    TextView tvAppName;
    FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exit);
        BindView();
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ExitActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
    }

    private void BindView() {
        tvAppName = findViewById(R.id.tvAppName);
        ibClose = findViewById(R.id.btnClose);
        ibInstall = findViewById(R.id.btnInstall);
        ibExit = findViewById(R.id.btnExit);
        ibRate = findViewById(R.id.btnRate);
        ibClose.setOnClickListener(this);
        ibInstall.setOnClickListener(this);
        ibExit.setOnClickListener(this);
        ibRate.setOnClickListener(this);
        AppFontStyle.Textfont(activity, tvAppName);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btnClose:
                CloseApp();
                break;

            case R.id.btnInstall:
                OpenOtherApp();
                break;
            case R.id.btnExit:
                CloseApp();
                break;
            case R.id.btnRate:
                RateApp();
                break;
        }
    }

    private void CloseApp() {
        finishAffinity();
        if (UnityPlayerActivity.mUnityPlayer != null) {
            UnityPlayerActivity.mUnityPlayer.quit();
        }
    }

    private void OpenOtherApp() {
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MoreAppClick");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
        Uri uri = Uri.parse("market://details?id=com.Pk.master.photo.video.slidehsow");
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=com.Pk.master.photo.video.slidehsow")));
        }
    }

    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }
}
