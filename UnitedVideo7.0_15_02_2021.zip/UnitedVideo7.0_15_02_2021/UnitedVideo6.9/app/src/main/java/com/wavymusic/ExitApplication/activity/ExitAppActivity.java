package com.wavymusic.ExitApplication.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.R;
import com.wavymusic.UnityPlayerActivity;

public class ExitAppActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = ExitAppActivity.this;
    ImageView ivClose;
    RatingBar ratingBar;
    TextView tvExit, tvSubmit;
    private Float rating;

    private NativeBannerAd mNativeBannerAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exit_app);
        PutAnalyticsEvent();
        LoadNativeAds();
        BindView();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ExitAppActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BindView() {
        tvExit = findViewById(R.id.tv_exit);
        tvSubmit = findViewById(R.id.tv_submit);
        ratingBar = findViewById(R.id.rateBar);
        ivClose = findViewById(R.id.iv_close);
        tvExit.setOnClickListener(this);
        tvSubmit.setOnClickListener(this);
        ivClose.setOnClickListener(this);
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                if (!b) {
                    return;
                }
                rating = v;
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                startActivity(new Intent(activity, DashbordActivity.class));
                finish();
                break;
            case R.id.tv_submit:
                if (rating < 4.0f) {
                    CloseApp();
                    ratingBar.setRating(0.0f);
                    return;
                }
                RateApp();
                ratingBar.setRating(0.0f);
                break;
            case R.id.tv_exit:
                CloseApp();
                break;
        }
    }

    private void LoadNativeAds(){
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(activity, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                FrameLayout nativeBannerAdContainer =findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();
    }

    private void CloseApp() {
        finishAffinity();
        if (UnityPlayerActivity.mUnityPlayer != null) {
            UnityPlayerActivity.mUnityPlayer.quit();
        }
    }

    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(activity, DashbordActivity.class));
        finish();
    }
}