package com.esc.howtomakeschoolsupplies.pojo;

import android.os.Parcel;
import android.os.Parcelable;
import kotlin.jvm.internal.Intrinsics;

public class Category implements Parcelable {
    public static final CREATOR CREATOR = new CREATOR();
    private String description;
    private int id;
    private String image;
    private int newArticleSize;

    public static final class CREATOR implements Creator<Category> {
        private CREATOR() {
        }

        public Category createFromParcel(Parcel parcel) {
            Intrinsics.checkParameterIsNotNull(parcel, "parcel");
            return new Category(parcel);
        }

        public Category[] newArray(int i) {
            return new Category[i];
        }
    }

    public static Category copy$default(Category category, int i, String str, String str2, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i = category.id;
        }
        if ((i3 & 2) != 0) {
            str = category.description;
        }
        if ((i3 & 4) != 0) {
            str2 = category.image;
        }
        if ((i3 & 8) != 0) {
            i2 = category.newArticleSize;
        }
        return category.copy(i, str, str2, i2);
    }

    public final int component1() {
        return this.id;
    }

    public final String component2() {
        return this.description;
    }

    public final String component3() {
        return this.image;
    }

    public final int component4() {
        return this.newArticleSize;
    }

    public final Category copy(int i, String str, String str2, int i2) {
        return new Category(i, str, str2, i2);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof Category) {
                Category category = (Category) obj;
                if ((this.id == category.id ? 1 : null) != null && Intrinsics.areEqual(this.description, category.description) && Intrinsics.areEqual(this.image, category.image)) {
                    if ((this.newArticleSize == category.newArticleSize ? 1 : null) != null) {
                        return true;
                    }
                }
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        int i = this.id * 31;
        String str = this.description;
        int i2 = 0;
        i = (i + (str != null ? str.hashCode() : 0)) * 31;
        str = this.image;
        if (str != null) {
            i2 = str.hashCode();
        }
        return ((i + i2) * 31) + this.newArticleSize;
    }

    public String toString() {
        return "Category(id=" + this.id + ", description=" + this.description + ", image=" + this.image + ", newArticleSize=" + this.newArticleSize + ")";
    }

    public Category(int i, String str, String str2, int i2) {
        this.id = i;
        this.description = str;
        this.image = str2;
        this.newArticleSize = i2;
    }

    public final int getId() {
        return this.id;
    }

    public final String getDescription() {
        return this.description;
    }

    public final String getImage() {
        return this.image;
    }

    public final int getNewArticleSize() {
        return this.newArticleSize;
    }

    public final void setNewArticleSize(int i) {
        this.newArticleSize = i;
    }

    public Category(Parcel parcel) {
        this(parcel.readInt(), parcel.readString(), parcel.readString(), parcel.readInt());
        Intrinsics.checkParameterIsNotNull(parcel, "parcel");
    }

    public void writeToParcel(Parcel parcel, int i) {
        Intrinsics.checkParameterIsNotNull(parcel, "parcel");
        parcel.writeInt(this.id);
        parcel.writeString(this.description);
        parcel.writeString(this.image);
        parcel.writeInt(this.newArticleSize);
    }
}
