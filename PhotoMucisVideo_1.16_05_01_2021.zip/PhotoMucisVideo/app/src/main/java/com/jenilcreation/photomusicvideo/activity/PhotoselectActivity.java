package com.jenilcreation.photomusicvideo.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.jenilcreation.photomusicvideo.MyApplication;
import com.jenilcreation.photomusicvideo.R;
import com.jenilcreation.photomusicvideo.adapters.AlbumAdapterById;
import com.jenilcreation.photomusicvideo.adapters.ImageByAlbumAdapter;
import com.jenilcreation.photomusicvideo.adapters.OnItemClickListner;
import com.jenilcreation.photomusicvideo.adapters.SelectedImageAdapter;
import com.jenilcreation.photomusicvideo.data.ImageData;
import com.jenilcreation.photomusicvideo.util.ActivityAnimUtil;
import com.jenilcreation.photomusicvideo.util.Utils;
import com.jenilcreation.photomusicvideo.view.EmptyRecyclerView;
import com.jenilcreation.photomusicvideo.view.ExpandIconView;
import com.jenilcreation.photomusicvideo.view.VerticalSlidingPanel;
import com.jenilcreation.photomusicvideo.view.VerticalSlidingPanel.PanelSlideListener;

import java.io.File;
import java.util.ArrayList;

public class PhotoselectActivity extends AppCompatActivity implements PanelSlideListener {
    private EmptyRecyclerView rvSelectedImage;
    //    ImageView ivDownarrow;
    public static final String EXTRA_FROM_PREVIEW = "extra_from_preview";
    public static boolean isForFirst = false;
    public static ArrayList<ImageData> tempImage = new ArrayList();
    private View parent;
    private RecyclerView rvAlbum;
    //    private RecyclerView rvAlbumImages;
    private SelectedImageAdapter selectedImageAdapter;
    private Toolbar toolbar;
    public static TextView tvImageCount;
    private AlbumAdapterById albumAdapter;
    private ImageByAlbumAdapter albumImagesAdapter;
    private MyApplication application;
    private TextView btnClear;
    private ExpandIconView expandIcon;
    public boolean isFromCameraNotification = false;
    public boolean isFromPreview = false;
    boolean isPause = false;
    private VerticalSlidingPanel verticalSlidingPanel;
    TextView tvDone;
    public static LinearLayout fregmentLayouts;
    public static ArrayList<String> arrayListID;

    public void onPanelAnchored(View view) {
    }

    public void onPanelShown(View view) {
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.image_select_activity);
        this.application = MyApplication.getInstance();
        this.isFromPreview = getIntent().hasExtra("extra_from_preview");

        this.isFromCameraNotification = getIntent().hasExtra("isFromCameraNotification");
        bindView();
        init();
        addListner();
        loadAd();
        arrayListID = new ArrayList<>();
        PutAnalyticsEvent();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "PhotoselectActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    public void scrollToPostion(final int i) {
        this.rvAlbum.postDelayed(new Runnable() {
            public void run() {
                PhotoselectActivity.this.rvAlbum.scrollToPosition(i);
            }
        }, 300);
    }

    private void init() {
        setSupportActionBar(this.toolbar);
        TextView textView = (TextView) this.toolbar.findViewById(R.id.toolbar_title);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        textView.setText(getString(R.string.select_images));
        Utils.setFont(this, textView);
        if (this.isFromCameraNotification) {
            AsyncTaskRunner runner = new AsyncTaskRunner();
            runner.execute("");

        }
        this.albumAdapter = new AlbumAdapterById(this);
        this.albumImagesAdapter = new ImageByAlbumAdapter(this);
        this.selectedImageAdapter = new SelectedImageAdapter(this);
//        this.rvAlbum.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
        this.rvAlbum.setHasFixedSize(true);
        this.rvAlbum.setLayoutManager(new GridLayoutManager(getApplicationContext(), 3));
        this.rvAlbum.setItemAnimator(new DefaultItemAnimator());
        this.rvAlbum.setAdapter(this.albumAdapter);

//        this.rvAlbumImages.setLayoutManager(new GridLayoutManager(getApplicationContext(), 3));
//        this.rvAlbumImages.setItemAnimator(new DefaultItemAnimator());
//        this.rvAlbumImages.setAdapter(this.albumImagesAdapter);
        this.rvSelectedImage.setLayoutManager(new GridLayoutManager(getApplicationContext(), 4));
        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
        this.rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
    }

    private class AsyncTaskRunner extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            application.getFolderList();
            return "";
        }

        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
        }


        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(PhotoselectActivity.this,
                    "ProgressDialog",
                    "Please Wait...");
        }


        @Override
        protected void onProgressUpdate(String... text) {

        }
    }

    private void bindView() {
        this.tvImageCount = (TextView) findViewById(R.id.tvImageCount);
        this.tvDone = (TextView) findViewById(R.id.tvDone);
        this.expandIcon = (ExpandIconView) findViewById(R.id.settings_drag_arrow);
        this.rvAlbum = (RecyclerView) findViewById(R.id.rvAlbum);
//        this.rvAlbumImages = (RecyclerView) findViewById(R.id.rvImageAlbum);
        this.rvSelectedImage = (EmptyRecyclerView) findViewById(R.id.rvSelectedImagesList);
        this.verticalSlidingPanel = (VerticalSlidingPanel) findViewById(R.id.overview_panel);
        this.verticalSlidingPanel.setEnableDragViewTouchEvents(true);
        this.verticalSlidingPanel.setDragView(findViewById(R.id.settings_pane_header));
        this.verticalSlidingPanel.setPanelSlideListener(this);
        this.parent = findViewById(R.id.default_home_screen_panel);
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.btnClear = (TextView) findViewById(R.id.btnClear);
//        this.ivDownarrow = (ImageView) findViewById(R.id.ivDownarrow);
        tvDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (application.getSelectedImages().size() > 2) {
                    loadDone();
                    return;
                }
                else{
                Toast.makeText(PhotoselectActivity.this, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();
                }
            }
        });
        fregmentLayouts = (LinearLayout) findViewById(R.id.fregmentspace);
        if(isFromPreview){
            btnClear.setVisibility(View.GONE);
        }
    }

    public int getItemCount() {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).size();
    }

    public ImageData getItem(final int n) {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).get(n);
    }

//    private void Allselect() {
//        int ii = 0;
//        while (getItemCount() != ii) {
//            final ImageData item = this.getItem(ii);
//            this.application.addSelectedImage(item);
//            this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
//            albumImagesAdapter.notifyDataSetChanged();
//            selectedImageAdapter.notifyDataSetChanged();
//            ++ii;
//        }
//
//        Animation animation = AnimationUtils.loadAnimation(PhotoselectActivity.this, R.anim.bottom_down_slow);
//        ivDownarrow.startAnimation(animation);
//        animation.setAnimationListener(new Animation.AnimationListener() {
//            @Override
//            public void onAnimationStart(Animation animation) {
//
//            }
//
//            @Override
//            public void onAnimationEnd(Animation animation) {
//                ivDownarrow.setVisibility(View.GONE);
//            }
//
//            @Override
//            public void onAnimationRepeat(Animation animation) {
//
//            }
//        });
//    }

    private void addListner() {
        this.btnClear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                PhotoselectActivity.this.clearData();
            }
        });
        this.albumAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object o) {
                PhotoselectActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
        this.albumImagesAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                PhotoselectActivity.this.tvImageCount.setText(String.valueOf(PhotoselectActivity.this.application.getSelectedImages().size()));
                PhotoselectActivity.this.selectedImageAdapter.notifyDataSetChanged();
            }
        });
        this.selectedImageAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                PhotoselectActivity.this.tvImageCount.setText(String.valueOf(PhotoselectActivity.this.application.getSelectedImages().size()));
                PhotoselectActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 999 && i2 == -1) {
            this.application.selectedImages.remove(MyApplication.TEMP_POSITION);
            ImageData imgData = new ImageData();
            imgData.setImagePath(intent.getExtras().getString("ImgPath"));
            this.application.selectedImages.add(MyApplication.TEMP_POSITION, imgData);
            setupAdapter();
        }
    }

    private void setupAdapter() {
        this.selectedImageAdapter = new SelectedImageAdapter(this);
        this.rvSelectedImage.setLayoutManager(new GridLayoutManager(getApplicationContext(), 4));
        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
        this.rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
    }

    protected void onResume() {
        super.onResume();
        if (this.isPause) {
            this.isPause = false;
            this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
            this.albumImagesAdapter.notifyDataSetChanged();
            this.selectedImageAdapter.notifyDataSetChanged();
        }
    }

    protected void onPause() {
        super.onPause();
        this.isPause = true;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_selection, menu);
//        menu.removeItem(R.id.menu_done);
        if (this.isFromPreview) {
            menu.removeItem(R.id.menu_clear);
        }
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            SubMenu subMenu = item.getSubMenu();
            if (subMenu != null && subMenu.size() > 0) {
                for (int i2 = 0; i2 < subMenu.size(); i2++) {
                    Utils.applyFontToMenuItem(getApplicationContext(), subMenu.getItem(i2));
                }
            }
            Utils.applyFontToMenuItem(getApplicationContext(), item);
        }
        return true;
    }

    private boolean isEndFrameExist() {
        if (Fragment_EndFrame.lastsaveTempPath == null) {
            return false;
        }
        return new File(Fragment_EndFrame.lastsaveTempPath).exists();
    }

    public boolean onOptionsItemSelected(final MenuItem menuItem) {
        final int itemId = menuItem.getItemId();
        if (itemId != android.R.id.home) {
            switch (itemId) {
                case R.id.menu_done: {
                    if (this.application.getSelectedImages().size() > 2) {
                        this.loadDone();
                        break;
                    }
                    Toast.makeText(this, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();
                    break;
                }
                case R.id.menu_clear: {
                    this.clearData();
                    break;
                }
            }
        } else {
            this.onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private boolean loadDone() {
        final boolean isFromPreview = this.isFromPreview;
        int i = 0;
        if (isFromPreview) {
            if (this.isEndFrameExist()) {
                ImageData imageData = null;
                final ArrayList<ImageData> list = new ArrayList<ImageData>();
                list.addAll(this.application.selectedImages);
                this.application.selectedImages.clear();
                while (i < list.size()) {
                    if (list.get(i).imagePath.equals(Fragment_EndFrame.lastsaveTempPath)) {
                        imageData = list.get(i);
                    } else {
                        this.application.selectedImages.add(list.get(i));
                    }
                    ++i;
                }
                if (imageData != null) {
                    this.application.selectedImages.add(imageData);
                }
            }
            this.setResult(-1);
            this.finish();
            return true;
        } else {
            nextDialog();
        }
        return false;
    }

    private void nextDialog() {
        final Dialog dialog = new Dialog(PhotoselectActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.imageselection_done_dialog);
        final NativeBannerAd mNativeBannerAd;
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                dialog.findViewById(R.id.tvLoadingads).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(PhotoselectActivity.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) dialog.findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);

            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();
        Button btnLatter = (Button) dialog.findViewById(R.id.btnLater);
        Button btnSubmit = (Button) dialog.findViewById(R.id.btnSubmit);
        btnLatter.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                id = 100;
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    dialogAd.show();
                    AdsDialogShow();
                } else {
                    final Intent intent = new Intent(PhotoselectActivity.this, (Class) Activity_ArrangeImage.class);
                    intent.putExtra("isFromCameraNotification", false);
                    intent.putExtra("KEY", "FromImageSelection");
                    startActivity(intent);

                }
                dialog.dismiss();
            }
        });
        btnSubmit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                id = 101;
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    dialogAd.show();
                    AdsDialogShow();
                } else {
                    Intent intent = new Intent(PhotoselectActivity.this, AddTitleActivity.class);
                    intent.putExtra("ISFROMPREVIEW", isFromPreview);
                    ActivityAnimUtil.startActivitySafely(toolbar, intent);
                    if (isFromPreview) {
                        finish();
                    }
                }
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public final ArrayList<ImageData> selectedImages = new ArrayList<ImageData>();

    public void onBackPressed() {
        if (findViewById(R.id.fregmentspace).getVisibility() == View.VISIBLE) {
            findViewById(R.id.fregmentspace).setVisibility(View.GONE);
            return;
        }
        if (this.verticalSlidingPanel.isExpanded()) {
            this.verticalSlidingPanel.collapsePane();
        } else if (this.isFromCameraNotification) {
            startActivity(new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            this.application.clearAllSelection();
            finish();
        } else if (this.isFromPreview) {
            if (application.getSelectedImages().size() > 2) {
                loadDone();
                return;
            }
            Toast.makeText(PhotoselectActivity.this, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();

        } else {
            this.application.videoImages.clear();
            this.application.clearAllSelection();
            startActivity(new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            finish();
            super.onBackPressed();
        }
    }

    public void onPanelSlide(final View view, final float n) {
        if (this.expandIcon != null) {
            this.expandIcon.setFraction(n, false);
        }
        if (n >= 0.005f) {
            if (this.parent != null && this.parent.getVisibility() != View.VISIBLE) {
                this.parent.setVisibility(View.VISIBLE);
            }
        } else if (this.parent != null && this.parent.getVisibility() == View.VISIBLE) {
            this.parent.setVisibility(View.GONE);
        }
    }

    public void onPanelCollapsed(View view) {
        if (this.parent != null) {
            this.parent.setVisibility(View.VISIBLE);
        }
        this.selectedImageAdapter.isExpanded = false;
        this.selectedImageAdapter.notifyDataSetChanged();
    }

    public void onPanelExpanded(View view) {
        if (this.parent != null) {
            this.parent.setVisibility(View.GONE);
        }
        this.selectedImageAdapter.isExpanded = true;
        this.selectedImageAdapter.notifyDataSetChanged();
    }

    private void clearData() {
        for (int size = this.application.getSelectedImages().size() - 1; size >= 0; size--) {
            this.application.removeSelectedImage(size);
        }
        this.tvImageCount.setText("0");
//        this.chbAllSelect.setChecked(false);
        this.selectedImageAdapter.notifyDataSetChanged();
        this.albumImagesAdapter.notifyDataSetChanged();
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                interstitialAd.show();
                dialogAd.dismiss();
            }
        }, 2000);
    }

    private NativeBannerAd mNativeBannerAd;
    private int id;
    private InterstitialAd interstitialAd;
    Dialog dialogAd;

    private void loadAd() {

        dialogAd = new Dialog(PhotoselectActivity.this);
        dialogAd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogAd.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialogAd.getWindow().setGravity(Gravity.CENTER);
        dialogAd.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialogAd.setContentView(R.layout.dialog_layout_progress);
        dialogAd.setCanceledOnTouchOutside(false);


        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(PhotoselectActivity.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });

        mNativeBannerAd.loadAd();
        interstitialAd = new InterstitialAd(this, getResources().getString(R.string.FB_inter1));
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                dialogAd.dismiss();
                switch (id) {
                    case 100:
                        final Intent intent = new Intent(PhotoselectActivity.this, (Class) Activity_ArrangeImage.class);
                        intent.putExtra("isFromCameraNotification", false);
                        intent.putExtra("KEY", "FromImageSelection");
                        startActivity(intent);

                        break;
                    case 101:
                        Intent intent1 = new Intent(PhotoselectActivity.this, AddTitleActivity.class);
                        intent1.putExtra("ISFROMPREVIEW", isFromPreview);
                        ActivityAnimUtil.startActivitySafely(toolbar, intent1);
                        if (isFromPreview) {
                            finish();
                        }
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        interstitialAd.loadAd();
    }

    private void requestNewInterstitial() {
        interstitialAd.loadAd();
    }
}
