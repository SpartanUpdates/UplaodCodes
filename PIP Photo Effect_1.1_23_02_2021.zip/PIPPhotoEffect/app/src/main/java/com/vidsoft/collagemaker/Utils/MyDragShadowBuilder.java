package com.vidsoft.collagemaker.Utils;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.view.View;
import android.view.View.DragShadowBuilder;

public class MyDragShadowBuilder extends DragShadowBuilder
{
  Paint mPaint = new Paint();

  public MyDragShadowBuilder(View paramView)
  {
    super(paramView);
    this.mPaint.setColor(0);
    this.mPaint.setAntiAlias(true);
    this.mPaint.setStyle(Style.STROKE);
  }

  public void onDrawShadow(Canvas paramCanvas)
  {
    super.onDrawShadow(paramCanvas);
    paramCanvas.drawRect(0.0F, 0.0F, paramCanvas.getWidth(), paramCanvas.getHeight(), this.mPaint);
  }

  public void onProvideShadowMetrics(Point paramPoint1, Point paramPoint2)
  {
    super.onProvideShadowMetrics(paramPoint1, paramPoint2);
  }
}