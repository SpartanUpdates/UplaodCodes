package com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.activity;

import static com.kotlinz.vehiclemanager.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.adapter.VehicleExpenseList;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.database.ExpenseSqlite;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.model.VehicleExpense;
import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;

public class VehicleExpenseActivity extends AppCompatActivity implements View.OnClickListener {
    private Activity activity = VehicleExpenseActivity.this;
    ImageView iv_addexpense;
    LinearLayout ll_empty;
    ExpandableListView listView;
    TextView tvTotal, title_tv;
    ImageView iv_back;
    ExpenseSqlite sqlite;
    VehicleExpenseList expenseListAdapter;
    ArrayList<VehicleExpense> expenseModels = new ArrayList();

    private NativeAd nativeAd;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_expense);
        sqlite = new ExpenseSqlite(getApplicationContext());
        PutAnalyticsEvent();
        BindView();
        TotalAmount();
        SetListener();
        LoadNativeAds();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            setupDarkMode();
        }
        DarkTheame darkTheame = new DarkTheame(VehicleExpenseActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            setupDarkMode();
        }
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VehicleExpenseActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (VehicleExpenseActivity.this.nativeAd != null) {
                            VehicleExpenseActivity.this.nativeAd.destroy();
                        }
                        VehicleExpenseActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    private void setupDarkMode() {
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        ll_empty.setBackgroundResource(R.drawable.ic_expense_bg_dark);
        tvTotal.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        listView.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
    }

    public void BindView() {
        iv_addexpense = findViewById(R.id.iv_addexpense);
        ll_empty = findViewById(R.id.ll_emplty);
        listView = findViewById(R.id.listview);
        tvTotal = findViewById(R.id.tv_total);
        iv_back = findViewById(R.id.iv_back);
        title_tv = findViewById(R.id.title_tv);

        iv_addexpense.setOnClickListener(this);
        iv_back.setOnClickListener(this);
    }

    public void SetListener() {
        listView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                listView.setIndicatorBounds(listView.getMeasuredWidth() - 80, listView.getMeasuredWidth());
            }
        });

        listView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            public boolean onGroupClick(ExpandableListView expandableListView, View view, int i, long j) {
                return false;
            }
        });

        this.listView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i2, long j) {
                try {
                    final VehicleExpense vehicleExpenseModel = VehicleExpenseActivity.this.expenseModels.get(i).getExpenseModels().get(i2);
                    view = ((LayoutInflater) VehicleExpenseActivity.this.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.vehicleexpanse_dialog, null);
                    AlertDialog.Builder builder = new AlertDialog.Builder(VehicleExpenseActivity.this);
                    builder.setView(view);
                    builder.setCancelable(true);
                    final AlertDialog create = builder.create();
                    create.show();

                    LinearLayout mainLayout = view.findViewById(R.id.mainLayout);
                    DarkTheame darkTheame = new DarkTheame(VehicleExpenseActivity.this);
                    if (darkTheame.modeData().equals("nightMode")) {
                        mainLayout.setBackgroundColor(Color.parseColor("#4E4E4E"));
                    }

                    Button button = view.findViewById(R.id.btnDeleteBill);
                    view.findViewById(R.id.btnEditBill).setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {
                            create.dismiss();
                            Intent intent = new Intent(VehicleExpenseActivity.this, VehicleExpenseDetailAtivity.class);
                            intent.putExtra("BID", vehicleExpenseModel.getBid());
                            intent.putExtra("BPAYEE", vehicleExpenseModel.getPayee());
                            intent.putExtra("BAMOUNT", vehicleExpenseModel.getAmount());
                            intent.putExtra("BCATNAME", vehicleExpenseModel.getCatname());
                            intent.putExtra("BCATICON", vehicleExpenseModel.getCaticon());
                            intent.putExtra("BNOTE", vehicleExpenseModel.getNotes());
                            intent.putExtra("BDUEDATE", vehicleExpenseModel.getDuedate());
                            intent.putExtra("btn", "UPDATE");
                            VehicleExpenseActivity.this.startActivity(intent);
                        }
                    });
                    button.setOnClickListener(new View.OnClickListener() {

                        public void onClick(View view) {
                            create.dismiss();
                            view = ((LayoutInflater) VehicleExpenseActivity.this.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.vehicleexpanse_delete_itemdialog, null);
                            AlertDialog.Builder builder = new AlertDialog.Builder(VehicleExpenseActivity.this);
                            builder.setView(view);
                            builder.setCancelable(true);
                            final AlertDialog dialog = builder.create();
                            dialog.show();

                            TextView tv_delete = view.findViewById(R.id.tv_delete);
                            TextView tv_cancel = view.findViewById(R.id.tv_cancel);

                            tv_delete.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (sqlite.dlt(vehicleExpenseModel.getBid()) > 0) {
                                        TotalAmount();
                                    }
                                    dialog.dismiss();
                                }
                            });

                            tv_cancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });
                        }
                    });
                } catch (Exception unused) {
                    unused.printStackTrace();
                }
                return false;
            }
        });
    }

    public void TotalAmount() {
        String rawQuery = this.sqlite.rawQuery();
        int i = 0;
        if (rawQuery != null) {
            this.ll_empty.setVisibility(View.GONE);
            this.tvTotal.setVisibility(View.VISIBLE);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Total Amount: ");
            stringBuilder.append(getString(R.string.rs));
            stringBuilder.append(" ");
            stringBuilder.append(rawQuery);
            tvTotal.setText(stringBuilder.toString());
        } else {
            this.tvTotal.setVisibility(View.GONE);
            this.ll_empty.setVisibility(View.VISIBLE);
        }
        this.expenseModels = this.sqlite.list();
        this.expenseListAdapter = new VehicleExpenseList(this, this.expenseModels);
        this.listView.setAdapter(this.expenseListAdapter);
        while (i < this.expenseListAdapter.getGroupCount()) {
            try {
                this.listView.expandGroup(i);
                i++;
            } catch (Exception unused) {
                return;
            }
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.iv_addexpense:
                if (MyApplication.isShowAd == 1) {
                    startActivity(new Intent(VehicleExpenseActivity.this, VehicleExpenseCategory.class));
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 27;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        startActivity(new Intent(VehicleExpenseActivity.this, VehicleExpenseCategory.class));
                    }
                }
                break;

            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }

    public void onResume() {
        super.onResume();
        TotalAmount();
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(VehicleExpenseActivity.this, MainActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 20;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(VehicleExpenseActivity.this, MainActivity.class));
                finish();
            }
        }
    }
}