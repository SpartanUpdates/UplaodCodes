package com.kotlinz.festivalstorymaker.Model.FestivalPoster.categoryWiseData;

import com.google.gson.annotations.SerializedName;

public class CategoryWiseData {

	@SerializedName("theme_thumbnail")
	private String themeThumbnail;

	@SerializedName("festival_name")
	private String festivalName;

	@SerializedName("updated_at")
	private String updatedAt;

	@SerializedName("is_pro")
	private String isPro;

	@SerializedName("theme_id")
	private int themeId;

	@SerializedName("created_at")
	private String createdAt;

	@SerializedName("module_name")
	private String moduleName;

	@SerializedName("application_id")
	private String applicationId;

	@SerializedName("datafile")
	private String datafile;

	@SerializedName("version")
	private String version;

	public void setThemeThumbnail(String themeThumbnail){
		this.themeThumbnail = themeThumbnail;
	}

	public String getThemeThumbnail(){
		return themeThumbnail;
	}

	public void setFestivalName(String festivalName){
		this.festivalName = festivalName;
	}

	public String getFestivalName(){
		return festivalName;
	}

	public void setUpdatedAt(String updatedAt){
		this.updatedAt = updatedAt;
	}

	public String getUpdatedAt(){
		return updatedAt;
	}

	public void setIsPro(String isPro){
		this.isPro = isPro;
	}

	public String getIsPro(){
		return isPro;
	}

	public void setThemeId(int themeId){
		this.themeId = themeId;
	}

	public int getThemeId(){
		return themeId;
	}

	public void setCreatedAt(String createdAt){
		this.createdAt = createdAt;
	}

	public String getCreatedAt(){
		return createdAt;
	}

	public void setModuleName(String moduleName){
		this.moduleName = moduleName;
	}

	public String getModuleName(){
		return moduleName;
	}

	public void setApplicationId(String applicationId){
		this.applicationId = applicationId;
	}

	public String getApplicationId(){
		return applicationId;
	}

	public void setDatafile(String datafile){
		this.datafile = datafile;
	}

	public String getDatafile(){
		return datafile;
	}

	public void setVersion(String version){
		this.version = version;
	}

	public String getVersion(){
		return version;
	}
}