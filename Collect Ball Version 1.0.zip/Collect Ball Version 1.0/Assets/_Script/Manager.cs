﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace BallCollect
{
    public class Manager : MonoBehaviour
    {
        public static Manager instance;

        [HideInInspector]
        public int levelFinishCount=0, restartCount=0;
        [HideInInspector]
        public int isLastColor=0,colorNo=0,oceneNo=0;
        [HideInInspector]
        public int setIsGameRestart = 0;
        [HideInInspector]
        public bool isNetWorkOn = false;

        public string strLike="market://details?id=com.example.android";

        public string strRateUs = "market://details?id=com.example.android";

        public string strMoreApp = "market://details?id=com.example.android";

        public string strPrivacyPolicy = "http://google.com/";

        public string strShareApp = "http://google.com/";

        public string unityGameId;

        public string unityBannerId, unityInterstitialId, unityRewaredId;

        public string fbBannerId= "745022042898053_745025799564344", fbInterstitialId= "745022042898053_745023389564585", fbRewaredId= "745022042898053_745026299564294";

        [HideInInspector]
        public bool isFbAdsShow, isUnityAdsShow = false;


        void Awake()
        {
            if (instance == null)
            {
                instance = this;
                DontDestroyOnLoad(this.gameObject);
            }
            else
            {
                Destroy(this.gameObject);
            }

            if (Application.internetReachability != NetworkReachability.NotReachable)
            {
                isNetWorkOn = true;
            }
            else
            {
                isNetWorkOn = false;
            }
        }
    }
}