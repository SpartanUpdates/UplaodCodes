package com.xyz.vehiclemanager.bikedetails.bikeservice.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bikedetails.bikeservice.model.BikeService;

import java.util.ArrayList;
import androidx.recyclerview.widget.RecyclerView;

public class BikeServiceDetailAdapter extends RecyclerView.Adapter<BikeServiceDetailAdapter.MyViewHolder>
{
    Context mcontext;
    ArrayList<BikeService> bikeServiceDetailslist;

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView tv_name;
        TextView tv_address;
        TextView tv_contact;
        public MyViewHolder(View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_address = itemView.findViewById(R.id.tv_address);
            tv_contact = itemView.findViewById(R.id.tv_contact);
        }
    }

    public BikeServiceDetailAdapter(Context mcontext, ArrayList<BikeService> bikeServiceDetails) {
        this.mcontext = mcontext;
        this.bikeServiceDetailslist = bikeServiceDetails;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_bikeservicedetails,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position)
    {
        BikeService bikeServiceDetails = bikeServiceDetailslist.get(position);
        String contactNo = bikeServiceDetails.getContactNo();
        String address = bikeServiceDetails.getAddress();
        holder.tv_name.setText(bikeServiceDetails.getName());
        if(contactNo==null)
        {
            holder.tv_contact.setVisibility(View.GONE);
        }
        else
        {
            holder.tv_contact.setText(contactNo);
        }
        if(address==null)
        {
            holder.tv_address.setVisibility(View.GONE);
        }
        else
        {
            holder.tv_address.setText(address);
        }
    }

    @Override
    public int getItemCount() {
        return bikeServiceDetailslist.size();
    }
}
