package com.esc.dailyrandomfacts.usecases;

import com.esc.dailyrandomfacts.helpers.QuoteHelper;

public class AddReadQuoteUsecase implements Usecase {
    private String mQuote;

    public AddReadQuoteUsecase(String str) {
        this.mQuote = str;
    }

    public void execute() {
        QuoteHelper.getInstance().addReadQuote(this.mQuote);
    }
}
