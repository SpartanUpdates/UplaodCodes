package com.kotlinz.festivalstorymaker.Adapter.Poster;


import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Model.PosterMaker.PosterMainCategory;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Utils;
import com.kotlinz.festivalstorymaker.activity.PosterMakerActivity;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PosterCategoryAdapter extends RecyclerView.Adapter<PosterCategoryAdapter.MyViewHolder> {

    public PosterMakerActivity PosterActivity;
    public String h = "0";
    public int SelectedPosition = 0;
    public ArrayList<PosterMainCategory> posterCategoryList;

    public PosterCategoryAdapter(Context context, ArrayList<PosterMainCategory> posterCategoryList) {
        this.PosterActivity = (PosterMakerActivity) context;
        this.posterCategoryList = posterCategoryList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_poster_category, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        if (SelectedPosition == position) {
            Glide.with(PosterActivity).load(Utils.PosterMakerCategoryPress(posterCategoryList.get(position).getCatName())).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivCategoryThumb);
        } else {
            Glide.with(PosterActivity).load(Utils.PosterMakerCategory(posterCategoryList.get(position).getCatName())).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivCategoryThumb);
        }
        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectedPosition = position;
                PosterActivity.ParentCatId = String.valueOf(posterCategoryList.get(position).getCatId());
                PosterActivity.SetPosterParentCategory(position, posterCategoryList);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return posterCategoryList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.ivCategoryThumb)
        public ImageView ivCategoryThumb;
        @BindView(R.id.llMain)
        public LinearLayout llMain;
        @BindView(R.id.tvCategoryName)
        public TextView tvCategoryName;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
