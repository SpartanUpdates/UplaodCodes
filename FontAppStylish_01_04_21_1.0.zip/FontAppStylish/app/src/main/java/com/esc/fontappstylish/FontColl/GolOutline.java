package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class GolOutline implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"Ⓐ", "Ⓑ", "Ⓒ", "Ⓓ", "Ⓔ", "Ⓕ", "Ⓖ", "Ⓗ", "Ⓘ", "Ⓙ", "Ⓚ", "Ⓛ", "Ⓜ", "Ⓝ", "Ⓞ", "Ⓟ", "Ⓠ", "Ⓡ", "Ⓢ", "Ⓣ", "Ⓤ", "Ⓥ", "Ⓦ", "Ⓧ", "Ⓨ", "Ⓩ"};
    }

    public String getName() {
        return "ⒶⒷⒸ";
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"Ⓐ", "Ⓑ", "Ⓒ", "Ⓓ", "Ⓔ", "Ⓕ", "Ⓖ", "Ⓗ", "Ⓘ", "Ⓙ", "Ⓚ", "Ⓛ", "Ⓜ", "Ⓝ", "Ⓞ", "Ⓟ", "Ⓠ", "Ⓡ", "Ⓢ", "Ⓣ", "Ⓤ", "Ⓥ", "Ⓦ", "Ⓧ", "Ⓨ", "Ⓩ"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public float getSizeFactorKeys() {
        return DefaultImpls.getSizeFactorKeys(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
