package com.wavymusic.Favourite.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.Favourite.Model.MytemplateModelWavy;
import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class DatabaseHelperwavy extends SQLiteOpenHelper {

    private static String DATABASE = "databaseWavy.db";
    private static String TABLE = "mytable";
    private static String THEME_ID = "id";
    private static String CATEGORY_ID = "category";
    private static String THEME_NAME = "theme_name";
    private static String THEME_THUMBNAIL = "theme_thumbnail";
    private static String THEME_THUMBNAIL_SMALL = "small_thumbnail";
    private static String SOUND_FILE = "sound_file";
    private static String SOUND_FILENAME = "sound_file_name";
    private static String SOUND_FILESIZE = "sound_size";
    private static String GAME_OBJECTNAME = "game_object";
    private static String TOTAL_DOWNLOAD = "downloads";
    private static String IS_RELEASE = "is_release";

    public DatabaseHelperwavy(Context context) {
        super(context, DATABASE, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(" CREATE TABLE " + TABLE + " (" +
                THEME_ID + " TEXT , " +
                CATEGORY_ID + " TEXT , " +
                THEME_NAME + " TEXT , " +
                THEME_THUMBNAIL + " TEXT , " +
                THEME_THUMBNAIL_SMALL + " TEXT , " +
                SOUND_FILE + " TEXT , " +
                SOUND_FILENAME + " TEXT , " +
                SOUND_FILESIZE + " TEXT , " +
                GAME_OBJECTNAME + " TEXT , " +
                TOTAL_DOWNLOAD + " TEXT , " +
                IS_RELEASE + " TEXT );"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE + " ;");
    }

    public void insertdataWavy(String themeid, String Categoryid, String VideoName, String Thethumbnail, String ThemeSmallthumbnail, String SoundFile, String SoundFileName, String SoundFileSize, String GameObjectName, String TotalDownload, String Isrelese) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(THEME_ID, themeid);
        contentValues.put(CATEGORY_ID, Categoryid);
        contentValues.put(THEME_NAME, VideoName);
        contentValues.put(THEME_THUMBNAIL, Thethumbnail);
        contentValues.put(THEME_THUMBNAIL_SMALL, ThemeSmallthumbnail);
        contentValues.put(SOUND_FILE, SoundFile);
        contentValues.put(SOUND_FILENAME, SoundFileName);
        contentValues.put(SOUND_FILESIZE, SoundFileSize);
        contentValues.put(GAME_OBJECTNAME, GameObjectName);
        contentValues.put(TOTAL_DOWNLOAD, TotalDownload);
        contentValues.put(IS_RELEASE, Isrelese);
        db.insert(TABLE, null, contentValues);
    }

    public void deleteThemeWavy(String name) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE, THEME_NAME + "=?", new String[]{name});
    }

    public List<MytemplateModelWavy> getdataWavy() {
        List<MytemplateModelWavy> data = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE + " ;", null);
        StringBuffer stringBuffer = new StringBuffer();
        MytemplateModelWavy dataModel = null;
        while (cursor.moveToNext()) {
            dataModel = new MytemplateModelWavy();
            dataModel.setThemeid(cursor.getString(cursor.getColumnIndexOrThrow("id")));
            dataModel.setCategoryid(cursor.getString(cursor.getColumnIndexOrThrow("category")));
            dataModel.setThemeName(cursor.getString(cursor.getColumnIndexOrThrow("theme_name")));
            dataModel.setImage(cursor.getString(cursor.getColumnIndexOrThrow("theme_thumbnail")));
            dataModel.setSmall_Thumbnail(cursor.getString(cursor.getColumnIndexOrThrow("small_thumbnail")));
            dataModel.setAnimsoundurl(cursor.getString(cursor.getColumnIndexOrThrow("sound_file")));
            dataModel.setAnimSoundname(cursor.getString(cursor.getColumnIndexOrThrow("sound_file_name")));
            dataModel.setAnimSoundPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + dataModel.getAnimSoundname());
            dataModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + dataModel.getAnimSoundname());
            dataModel.setAnimSoundfilesize(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("sound_size"))));
            dataModel.setGameobjectName(cursor.getString(cursor.getColumnIndexOrThrow("game_object")));
            dataModel.setThemeCounter(cursor.getString(cursor.getColumnIndexOrThrow("downloads")));
            dataModel.setNewRealise(cursor.getString(cursor.getColumnIndexOrThrow("is_release")));
            stringBuffer.append(dataModel);
            data.add(dataModel);
        }
        return data;
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

    public boolean RecordExistsWavy(String model) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = null;
        String checkQuery = "SELECT " + THEME_NAME + " FROM " + TABLE + " WHERE " + THEME_NAME + "= '" + model + "'";
        cursor = db.rawQuery(checkQuery, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }
}
