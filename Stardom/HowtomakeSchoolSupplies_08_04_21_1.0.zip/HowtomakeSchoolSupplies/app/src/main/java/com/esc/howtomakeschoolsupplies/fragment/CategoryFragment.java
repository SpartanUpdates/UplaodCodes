package com.esc.howtomakeschoolsupplies.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.esc.howtomakeschoolsupplies.activity.CategoryFragmentinitLayoutManager;
import com.esc.howtomakeschoolsupplies.activity.Constants;
import com.esc.howtomakeschoolsupplies.R;
import com.esc.howtomakeschoolsupplies.activity.MainActivity;
import com.esc.howtomakeschoolsupplies.adapter.CategoryAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import com.esc.howtomakeschoolsupplies.network.ConnectToServer;
import com.esc.howtomakeschoolsupplies.network.ConnectToServer.LoadingRecommended;
import com.esc.howtomakeschoolsupplies.network.Recommended;
import com.esc.howtomakeschoolsupplies.pojo.Category;

public class CategoryFragment extends Fragment implements LoadingRecommended {
    public static final Companion Companion = new Companion();
    private static final String KEY_CATEGORY = "category";
    private HashMap findViewCache;
    private CategoryAdapter categoryadapter;
    public boolean isPostShowRecommended;
    private EventUpdateCategory mEventUpdateCategory;
    private RecyclerView mRecyclerView;
    TextView tvtitle;
    private View inflate;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    public static String Title;
    private ImageView iv_back;

    public static final class Companion {
        private Companion() {
        }

        public final CategoryFragment newInstance(ArrayList<Category> arrayList, String title) {
            Intrinsics.checkParameterIsNotNull(arrayList, "categories");
            Title = title;
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList(CategoryFragment.KEY_CATEGORY, arrayList);
            CategoryFragment categoryFragment = new CategoryFragment();
            categoryFragment.setArguments(bundle);
            return categoryFragment;
        }
    }

    public interface EventUpdateCategory {
        void updateCategory();
    }

    public void clearFindViewByIdCache() {
        HashMap hashMap = this.findViewCache;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    public View findCachedViewById(int i) {
        if (this.findViewCache == null) {
            this.findViewCache = new HashMap();
        }
        View view = (View) this.findViewCache.get(Integer.valueOf(i));
        if (view == null) {
            view = getView();
            if (view == null) {
                return null;
            }
            view = view.findViewById(i);
            this.findViewCache.put(Integer.valueOf(i), view);
        }
        return view;
    }

    public void onDestroyView() {
        super.onDestroyView();
        clearFindViewByIdCache();
    }

    public static final CategoryAdapter accessgetAdapterp(CategoryFragment categoryFragment) {
        CategoryAdapter categoryAdapter = categoryFragment.categoryadapter;
        if (categoryAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
        }
        return categoryAdapter;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Intrinsics.checkParameterIsNotNull(layoutInflater, "inflater");
        inflate = layoutInflater.inflate(R.layout.fragment_category, viewGroup, false);
        ArrayList parcelableArrayList = requireArguments().getParcelableArrayList(KEY_CATEGORY);
        Intrinsics.checkExpressionValueIsNotNull(inflate, "rootView");
        FragmentActivity activity = getActivity();
        if (activity != null) {
            this.mEventUpdateCategory = (EventUpdateCategory) activity;
            RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.recyclerview);
            Intrinsics.checkExpressionValueIsNotNull(recyclerView, "rootView.recyclerview");
            this.mRecyclerView = recyclerView;
            FragmentActivity requireActivity = requireActivity();
            String str = "requireActivity()";
            Intrinsics.checkExpressionValueIsNotNull(requireActivity, str);
            FragmentActivity requireActivity2 = requireActivity();
            Intrinsics.checkExpressionValueIsNotNull(requireActivity2, str);
            Context context = requireActivity2;
            if (parcelableArrayList == null) {
                Intrinsics.throwNpe();
            }
            List list = parcelableArrayList;
            requireActivity = requireActivity();
            Intrinsics.checkExpressionValueIsNotNull(requireActivity, str);
            FragmentManager supportFragmentManager = requireActivity.getSupportFragmentManager();
            Intrinsics.checkExpressionValueIsNotNull(supportFragmentManager, "requireActivity().supportFragmentManager");
            mRecyclerView = (RecyclerView) inflate.findViewById(R.id.recyclerview);
            tvtitle=inflate.findViewById(R.id.tv_title);
            tvtitle.setText(Title);
            iv_back = inflate.findViewById(R.id.iv_back);

            iv_back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), MainActivity.class);
                    startActivity(intent);
                }
            });
            this.categoryadapter = new CategoryAdapter(context, list, supportFragmentManager);

            String str2 = "mRecyclerView";
            if (mRecyclerView == null) {
                Intrinsics.throwUninitializedPropertyAccessException(str2);
            }
            String str3 = "mRecyclerView.recyclerview";
            Intrinsics.checkExpressionValueIsNotNull(mRecyclerView, str3);
            String str4 = "adapter";
            if (categoryadapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException(str4);
            }
            mRecyclerView.setAdapter(categoryadapter);
            LayoutAnimationController loadLayoutAnimation = AnimationUtils.loadLayoutAnimation(getActivity(), R.anim.layout_animation);
            if (mRecyclerView == null) {
                Intrinsics.throwUninitializedPropertyAccessException(str2);
            }
            Intrinsics.checkExpressionValueIsNotNull(recyclerView, str3);
            recyclerView.setLayoutAnimation(loadLayoutAnimation);
            requireActivity2 = requireActivity();
            Intrinsics.checkExpressionValueIsNotNull(requireActivity2, str);
            if (categoryadapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException(str4);
            }
            initLayoutManager(categoryadapter.getItemCount() - 1);
            return inflate;
        }
        BannerAds();
        throw new TypeCastException("null cannot be cast to non-null type com.esc.howtomakeschoolsupplies.fragment.CategoryFragment.EventUpdateCategory");
    }

    private final void initLayoutManager(int i) {
        final GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        gridLayoutManager.setSpanSizeLookup(new CategoryFragmentinitLayoutManager(this));

        String str = "mRecyclerView";
        if (mRecyclerView == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str);
        }
        mRecyclerView.setLayoutManager(gridLayoutManager);
        if (mRecyclerView == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str);
        }

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int i1, int i2) {
                super.onScrolled(recyclerView, i1, i2);
                Intrinsics.checkParameterIsNotNull(recyclerView, "recyclerView");
                if (gridLayoutManager.findLastCompletelyVisibleItemPosition() == i1 && isPostShowRecommended) {

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                ConnectToServer.Companion companion = ConnectToServer.Companion;
                                StringBuilder append = new StringBuilder().append(Constants.SERVER_ADDRESS_RECOMMENDED).append("countShow/?appLinkAndroid=");
                                FragmentActivity activity = getActivity();
                                companion.postOnServer(append.append(activity != null ? activity.getPackageName() : null).toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });

                    isPostShowRecommended = false;
                }
            }
        });
    }

    public void onResume() {
        super.onResume();
        ((RecyclerView) findCachedViewById(R.id.recyclerview)).scheduleLayoutAnimation();
        EventUpdateCategory eventUpdateCategory = this.mEventUpdateCategory;
        if (eventUpdateCategory == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mEventUpdateCategory");
        }
        eventUpdateCategory.updateCategory();
    }

    public void initRecommended(List<Recommended> list) {
        Intrinsics.checkParameterIsNotNull(list, "recommendedList");
        String str = "adapter";
        if (categoryadapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str);
        }
        categoryadapter.setRecommendedList(list);
        if (categoryadapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str);
        }
        if (categoryadapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str);
        }
        categoryadapter.notifyItemChanged(categoryadapter.getItemCount() - 1);
        this.isPostShowRecommended = true;
    }

    private void BannerAds() {
        if (isAdded()) {
            try {
                adContainerView = inflate.findViewById(R.id.banner_ad_view_container);
                Display defaultDisplay = getActivity().getWindowManager().getDefaultDisplay();
                DisplayMetrics displayMetrics = new DisplayMetrics();
                defaultDisplay.getMetrics(displayMetrics);
                float f = displayMetrics.density;
                float width = (float) adContainerView.getWidth();
                if (width == 0.0f) {
                    width = (float) displayMetrics.widthPixels;
                }
                adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(getActivity(), (int) (width / f));
                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
                layoutParams.height = adSize.getHeightInPixels(getActivity());
                adContainerView.setLayoutParams(layoutParams);
                adContainerView.post(new Runnable() {
                    public final void run() {
                        ShowAds();
                    }
                });
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(getActivity());
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
