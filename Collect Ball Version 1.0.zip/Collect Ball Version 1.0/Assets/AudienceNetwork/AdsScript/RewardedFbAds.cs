﻿using UnityEngine;
using UnityEngine.UI;
using AudienceNetwork;
using UnityEngine.SceneManagement;
using AudienceNetwork.Utility;
using UnityEngine.Analytics;

namespace BallCollect
{
    public class RewardedFbAds : MonoBehaviour
    {

        public static RewardedFbAds instance;

        private RewardedVideoAd rewardedVideoAd;

        [HideInInspector]
        public bool isFBRewaredLoaded;

        private bool didClose;


        private void Awake()
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        private void Start()
        {
            AudienceNetworkAds.Initialize();
            LoadRewardedVideo();
        }
        public void LoadRewardedVideo()
        {
            Analytics.CustomEvent("FBRewaredRequestCome");
            rewardedVideoAd = new RewardedVideoAd(Manager.instance.fbRewaredId);

            RewardData rewardData = new RewardData
            {
                UserId = "111111",
                Currency = "300"
            };
#pragma warning disable 0219
            RewardedVideoAd s2sRewardedVideoAd = new RewardedVideoAd(Manager.instance.fbRewaredId, rewardData);
#pragma warning restore 0219

            rewardedVideoAd.Register(gameObject);

            rewardedVideoAd.RewardedVideoAdDidLoad = delegate ()
            {
                Analytics.CustomEvent("FBRewaredLoad");
                isFBRewaredLoaded = true;
                didClose = false;
            };
            rewardedVideoAd.RewardedVideoAdDidFailWithError = delegate (string error)
            {
                Analytics.CustomEvent("FBRewaredRequestFail");

            };
            rewardedVideoAd.RewardedVideoAdWillLogImpression = delegate ()
            {
            };
            rewardedVideoAd.RewardedVideoAdDidClick = delegate ()
            {
            };

            rewardedVideoAd.RewardedVideoAdDidSucceed = delegate ()
            {
            };

            rewardedVideoAd.RewardedVideoAdDidFail = delegate ()
            {
            };

            rewardedVideoAd.RewardedVideoAdDidClose = delegate ()
            {
                if (MainMenu.instance.isRewardSetting)
                {
                    MainMenu.instance.isRewardDone = true;
                    MainMenu.instance.RewardDone();
                    Analytics.CustomEvent("FBRewaredCoinsDone");
                }
                else
                {
                    GameController.instance.SaveMe();
                    Analytics.CustomEvent("FBRewaredSaveMeDone");
                }

                didClose = true;

                isFBRewaredLoaded = false;

                if (rewardedVideoAd != null)
                {
                    rewardedVideoAd.Dispose();
                }
                LoadRewardedVideo();
            };

#if UNITY_ANDROID
            rewardedVideoAd.RewardedVideoAdActivityDestroyed = delegate ()
            {
                if (MainMenu.instance.isRewardSetting)
                {
                    MainMenu.instance.isRewardDone = false;
                    MainMenu.instance.RewardDone();
                    Analytics.CustomEvent("FBRewaredCoinsDone");
                }
                else
                {
                    GameController.instance.SkipVideoAdd();
                    Analytics.CustomEvent("FBRewaredSaveMeDone");
                }

                if (!didClose)
                {
                }
            };
#endif
            rewardedVideoAd.LoadAd();
        }

        public void ShowRewardedVideo()
        {
            rewardedVideoAd.Show();
        }

        void OnDestroy()
        {
            if (rewardedVideoAd != null)
            {
                rewardedVideoAd.Dispose();
            }
        }
    }
}