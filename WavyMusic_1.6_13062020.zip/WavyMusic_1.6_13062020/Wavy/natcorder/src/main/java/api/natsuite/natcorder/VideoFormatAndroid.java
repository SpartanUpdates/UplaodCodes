package api.natsuite.natcorder;

import android.media.MediaFormat;
import java.nio.ByteBuffer;

public class VideoFormatAndroid extends VideoFormat {
    private MediaFormat mediaFormat;

    VideoFormatAndroid(MediaFormat mediaFormat) {
        this.mediaFormat = mediaFormat;
        this.setVideoFrameSize(mediaFormat.getInteger("width"), mediaFormat.getInteger("height"));
        this.setVideoCodec(mediaFormat.getString("mime"));
    }

    public VideoFormatAndroid(String mimeType, int width, int height) {
        if (width > 1280 || height > 1280) {
            if (width > height) {
                width = 1280;
                height = 720;
            } else {
                width = 720;
                height = 1280;
            }
        }

        this.mediaFormat = MediaFormat.createVideoFormat(mimeType, width, height);
        this.setVideoFrameSize(width, height);
        this.setVideoCodec(mimeType);
    }

    public MediaFormat getNativeFormat() {
        return this.mediaFormat;
    }

    public ByteBuffer getByteBuffer(String key) {
        return this.mediaFormat.getByteBuffer(key);
    }

    public void setInteger(String key, int value) {
        this.mediaFormat.setInteger(key, value);
    }

    public int getInteger(String key) {
        return this.mediaFormat.getInteger(key);
    }

    protected long getLong(String key) {
        return this.mediaFormat.getLong(key);
    }

    protected String getString(String key) {
        return this.mediaFormat.getString(key);
    }
}