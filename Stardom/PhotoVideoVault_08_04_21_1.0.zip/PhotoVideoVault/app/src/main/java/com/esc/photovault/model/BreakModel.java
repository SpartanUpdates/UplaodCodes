package com.esc.photovault.model;

import java.io.File;

public class BreakModel {

    String date;
    File file;
    String image_name;
    double lang;
    double lat;
    String password;
    String path_break;

    public String getPath_break() {
        return this.path_break;
    }

    public void setPath_break(String path_break) {
        this.path_break = path_break;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getImage_name() {
        return this.image_name;
    }

    public void setImage_name(String image_name) {
        this.image_name = image_name;
    }

    public File getFile() {
        return this.file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public double getLat() {
        return this.lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLang() {
        return this.lang;
    }

    public void setLang(double lang) {
        this.lang = lang;
    }
}
