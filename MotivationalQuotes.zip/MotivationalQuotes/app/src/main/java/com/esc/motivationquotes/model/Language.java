package com.esc.motivationquotes.model;

public class Language {
    public static final String TAG = "language";
    private String code;
    private String name;

    public Language(String str, String str2) {
        this.name = str;
        this.code = str2;
    }

    public String getName() {
        return this.name;
    }

    public String getCode() {
        return this.code;
    }
}
