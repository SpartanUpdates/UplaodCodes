package game.kidspop.gk.quiz.info;

import android.app.Application;

import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;

public class MyApplication extends Application {
    private static MyApplication instance;
    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        AdSettings.addTestDevice("c708c7fb-d647-43a2-b1a6-301b139991c2");
        AudienceNetworkAds.initialize(this);
    }
}
