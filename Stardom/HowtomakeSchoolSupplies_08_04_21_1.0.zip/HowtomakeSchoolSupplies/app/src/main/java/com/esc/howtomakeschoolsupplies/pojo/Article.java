package com.esc.howtomakeschoolsupplies.pojo;

import android.os.Parcel;
import android.os.Parcelable;
import kotlin.jvm.internal.Intrinsics;

public class Article implements Parcelable {
    public static final CREATOR CREATOR = new CREATOR();
    private Category category;
    private String description;
    private int id;
    private boolean isOldArticle;
    private boolean isOldArticleInCategory;
    private int likes;
    private String preview;

    public Article() {
    }

    public static final class CREATOR implements Creator<Article> {
        private CREATOR() {
        }

        public Article createFromParcel(Parcel parcel) {
            Intrinsics.checkParameterIsNotNull(parcel, "parcel");
            return new Article(parcel);
        }

        public Article[] newArray(int i) {
            return new Article[i];
        }
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof Article) {
                Article article = (Article) obj;
                if ((this.id == article.id ? 1 : null) != null && Intrinsics.areEqual(this.description, article.description) && Intrinsics.areEqual(this.category, article.category) && Intrinsics.areEqual(this.preview, article.preview)) {
                    if ((this.likes == article.likes ? 1 : null) != null) {
                        if ((this.isOldArticle == article.isOldArticle ? 1 : null) != null) {
                            if ((this.isOldArticleInCategory == article.isOldArticleInCategory ? 1 : null) != null) {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        int i = this.id * 31;
        String str = this.description;
        int i2 = 0;
        int hashCode = (i + (str != null ? str.hashCode() : 0)) * 31;
        Category category2 = this.category;
        int hashCode2 = (hashCode + (category2 != null ? category2.hashCode() : 0)) * 31;
        String str2 = this.preview;
        if (str2 != null) {
            i2 = str2.hashCode();
        }
        int i3 = (((hashCode2 + i2) * 31) + this.likes) * 31;
        boolean z = this.isOldArticle;
        boolean z2 = true;
        if (z) {
            z = true;
        }
        int i4 = (i3 + (z ? 1 : 0)) * 31;
        boolean z3 = this.isOldArticleInCategory;
        if (!z3) {
            z2 = z3;
        }
        return i4 + (z2 ? 1 : 0);
    }

    public String toString() {
        return "Article(id=" + this.id + ", description=" + this.description + ", category=" + this.category + ", preview=" + this.preview + ", likes=" + this.likes + ", isOldArticle=" + this.isOldArticle + ", isOldArticleInCategory=" + this.isOldArticleInCategory + ")";
    }

    public Article(int i, String str, Category category, String str2, int i2, boolean z, boolean z2) {
        this.id = i;
        this.description = str;
        this.category = category;
        this.preview = str2;
        this.likes = i2;
        this.isOldArticle = z;
        this.isOldArticleInCategory = z2;
    }

    public final int getId() {
        return this.id;
    }

    public final String getDescription() {
        return this.description;
    }

    public final Category getCategory() {
        return this.category;
    }

    public final String getPreview() {
        return this.preview;
    }

    public final int getLikes() {
        return this.likes;
    }

    public final boolean isOldArticle() {
        return this.isOldArticle;
    }

    public final void setOldArticle(boolean z) {
        this.isOldArticle = z;
    }

    public Article(int i, String str, Category category2, String str2, int i2, boolean z, boolean z2, int i3) {
        this(i, str, category2, str2, i2, (i3 & 32) != 0 ? false : z, (i3 & 64) != 0 ? false : z2);
    }

    public final boolean isOldArticleInCategory() {
        return this.isOldArticleInCategory;
    }

    public final void setOldArticleInCategory(boolean z) {
        this.isOldArticleInCategory = z;
    }

    public Article(Parcel parcel) {
        this(parcel.readInt(), parcel.readString(), (Category) parcel.readParcelable(Category.class.getClassLoader()), parcel.readString(), parcel.readInt(), true, parcel.readByte() != 0);
        Intrinsics.checkParameterIsNotNull(parcel, "parcel");
    }

    public void writeToParcel(Parcel parcel, int i) {
        Intrinsics.checkParameterIsNotNull(parcel, "parcel");
        parcel.writeInt(this.id);
        parcel.writeString(this.description);
        parcel.writeParcelable(this.category, i);
        parcel.writeString(this.preview);
        parcel.writeInt(this.likes);
        parcel.writeByte(this.isOldArticle ? (byte) 1 : 0);
        parcel.writeByte(this.isOldArticleInCategory ? (byte) 1 : 0);
    }
}
