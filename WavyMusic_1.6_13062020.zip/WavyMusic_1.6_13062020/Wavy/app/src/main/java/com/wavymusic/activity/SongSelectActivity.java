package com.wavymusic.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import com.google.android.material.tabs.TabLayout;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wavymusic.Fragment.SongByCatFragment;
import com.wavymusic.Model.SongCatModel;
import com.wavymusic.Preferences.LanguagePref;
import com.wavymusic.ProgressBar.kprogresshud.KProgressHUD;
import com.wavymusic.R;
import com.wavymusic.Retrofit.APIClient;
import com.wavymusic.Retrofit.APIInterface;
import com.wavymusic.Retrofit.AppConstant;
import com.wavymusic.Utils.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.application.MyApplication;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SongSelectActivity extends AppCompatActivity {

    Activity activity = SongSelectActivity.this;
    public LanguagePref sharedpreferences;
    public int id;
//    public String FinalSongPath;
//    public InterstitialAd mInterstitialAd;
    public KProgressHUD hud;
    ViewPagerAdapter adp;
    ArrayList<SongCatModel> SongList = new ArrayList<>();
    String offlienResopnseData;
    RelativeLayout rlLoadingTheme;
    LinearLayout layoutSongSdCard;
    ImageView ivBack;
    AdRequest adRequest;
    AdView adView;
    Button btnRetry;
    LinearLayout llRetry;
//    Long timestamps;
    APIInterface apiInterface;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_select);
        sharedpreferences = LanguagePref.a(this);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        ivBack = findViewById(R.id.ivBack);
        tabLayout = findViewById(R.id.tab_layout_song_online);
        viewPager = findViewById(R.id.vp_song_online);
        layoutSongSdCard = findViewById(R.id.ll_from_storage);
        rlLoadingTheme = findViewById(R.id.rl_load_song_online);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SongSelectActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        BannerAds();
//        InterstitialAds();
        adListener();
        getOfflineCategory(activity, "offlineResponse");
        if (offlienResopnseData != null) {
            new LoadOfflineData().execute();
        } else {
            rlLoadingTheme.setVisibility(View.GONE);
            llRetry.setVisibility(View.VISIBLE);
        }

    }

    private void adListener() {
        layoutSongSdCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(activity, PhoneSongActivity.class), 101);
            }
        });
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(activity, false)) {
                    llRetry.setVisibility(View.GONE);
                    GetSongCategory();
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void BannerAds() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

//    private void InterstitialAds() {
//        mInterstitialAd = new InterstitialAd(activity);
//        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
//        mInterstitialAd.loadAd(new AdRequest.Builder().build());
//        mInterstitialAd.setAdListener(new AdListener() {
//            @Override
//            public void onAdClosed() {
//                switch (id) {
//                    case 203:
//                        UnityPlayer.UnitySendMessage("StackManager", "ReturnAudio", FinalSongPath);
//                        finish();
//                        break;
//                }
//            }
//
//            @Override
//            public void onAdLoaded() {
//                super.onAdLoaded();
//
//            }
//
//            @Override
//            public void onAdFailedToLoad(int i) {
//                super.onAdFailedToLoad(i);
//
//            }
//        });
//    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
            View customView = tab.getCustomView();
            if (tab.getPosition() == 0) {
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.VISIBLE);
            }
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.VISIBLE);
                StopSong();
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.GONE);
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void StopSong() {
        try {
            if (SongByCatFragment.mediaPlayer != null) {
                SongByCatFragment.mediaPlayer.stop();
                SongByCatFragment.mediaPlayer.release();
                SongByCatFragment.mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setUpPagerNew() {
        adp = new ViewPagerAdapter(getSupportFragmentManager());
        viewPager.setOffscreenPageLimit(0);
        viewPager.setAdapter(adp);
        tabLayout.setupWithViewPager(viewPager);
    }



    private void getOfflineCategory(Context ctx, String key) {
        SharedPreferences pref = PreferenceManager
                .getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
//        timestamps = pref.getLong(key + "_value", 0);
    }

    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        final StringBuilder sb = new StringBuilder();
        sb.append("onlinemusic act onact result requestcode ");
        sb.append(n);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("onlinemusic act onact result resultcode ");
        sb2.append(n2);
        if (n2 == -1) {
            if (n != 101) {
                return;
            }
            intent.getExtras().getString("audio_path");
            UnityPlayer.UnitySendMessage("StackManager", "ReturnAudio", intent.getExtras().getString("audio_path"));
            this.setResult(-1);
            this.finish();
        }
    }

    private void GetSongCategory() {
        rlLoadingTheme.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.GetAllTheme(AppConstant.Token, AppConstant.ApplicationId, AppConstant.DefaultCategoryId + LanguagePref.a(this).a("pref_key_language_list", "22"));
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject songJSONObject = jsonArray.getJSONObject(i);
                            SongCatModel songCatModel = new SongCatModel();
                            songCatModel.setSongCatId(songJSONObject.getString("id"));
                            songCatModel.setSongCatName(songJSONObject.getString("name"));
                            SongList.add(songCatModel);
                        }
                        setUpPagerNew();
                        SetTabLayout();
                        rlLoadingTheme.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    private class LoadOfflineData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlienResopnseData);
                JSONArray jsonArray = jsonObj.getJSONArray("category");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject songJSONObject = jsonArray.getJSONObject(i);
                    SongCatModel songCatModel = new SongCatModel();
                    songCatModel.setSongCatId(songJSONObject.getString("id"));
                    songCatModel.setSongCatName(songJSONObject.getString("name"));
                    SongList.add(songCatModel);
                }
            } catch (final JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            setUpPagerNew();
            SetTabLayout();
            rlLoadingTheme.setVisibility(View.GONE);
        }
    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return (SongByCatFragment.getInstance(Integer.parseInt(SongList.get(position).getSongCatId())));
        }

        @Override
        public int getCount() {
            return SongList.size();
        }

        public View getTabView(int position) {
            View tab = LayoutInflater.from(activity).inflate(
                    R.layout.row_song_cat, null);
            TextView tv = tab.findViewById(R.id.custom_text);
            tv.setText(SongList.get(position).getSongCatName());
            return tab;
        }
    }

    @Override
    protected void onDestroy() {
        if (MyApplication.fbinterstitialAd != null) {
            MyApplication.fbinterstitialAd.destroy();
        }
        super.onDestroy();
    }
}
