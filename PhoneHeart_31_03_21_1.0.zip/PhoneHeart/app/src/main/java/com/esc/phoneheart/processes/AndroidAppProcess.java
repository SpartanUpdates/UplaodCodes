package com.esc.phoneheart.processes;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Parcel;
import com.esc.phoneheart.utility.AndroidProcesses;
import java.io.File;
import java.io.IOException;
import java.util.regex.Pattern;

public class AndroidAppProcess extends AndroidProcess {
    public static final Creator<AndroidAppProcess> CREATOR = new Creator<AndroidAppProcess>() {
        public AndroidAppProcess createFromParcel(Parcel parcel) {
            return new AndroidAppProcess(parcel);
        }

        public AndroidAppProcess[] newArray(int i) {
            return new AndroidAppProcess[i];
        }
    };
    public static final Pattern PROCESS_NAME_PATTERN = Pattern.compile("^([A-Za-z]{1}[A-Za-z0-9_]*[\\.|:])*[A-Za-z][A-Za-z0-9_]*$");
    public static final boolean SYS_SUPPORTS_SCHEDGROUPS = new File("/dev/cpuctl/tasks").exists();
    public final boolean foreground;
    public final int uid;

    public static final class NotAndroidAppProcessException extends Exception {
        public NotAndroidAppProcessException(int i) {
            super(String.format("The process %d does not belong to any application", new Object[]{Integer.valueOf(i)}));
        }
    }

    public AndroidAppProcess(int i) throws IOException, NotAndroidAppProcessException {
        super(i);
        String str = this.name;
        if (str != null && PROCESS_NAME_PATTERN.matcher(str).matches()) {
            if (new File("/data/data", getPackageName()).exists()) {
                boolean contains;
                int parseInt;
                if (SYS_SUPPORTS_SCHEDGROUPS) {
                    Cgroup cgroup = cgroup();
                    ControlGroup group = cgroup.getGroup("cpuacct");
                    ControlGroup group2 = cgroup.getGroup("cpu");
                    String str2 = "/";
                    String str3 = "bg_non_interactive";
                    if (VERSION.SDK_INT >= 21) {
                        if (group2 == null || group == null || !group.group.contains("pid_")) {
                            throw new NotAndroidAppProcessException(i);
                        }
                        contains = group2.group.contains(str3) ^ true;
                        try {
                            parseInt = Integer.parseInt(group.group.split(str2)[1].replace("uid_", ""));
                        } catch (Exception unused) {
                            parseInt = status().getUid();
                        }
                        AndroidProcesses.log("name=%s, pid=%d, uid=%d, foreground=%KeyGrd, cpuacct=%s, cpu=%s", this.name, Integer.valueOf(i), Integer.valueOf(parseInt), Boolean.valueOf(contains), group.toString(), group2.toString());
                    } else if (group2 == null || group == null || !group2.group.contains("apps")) {
                        throw new NotAndroidAppProcessException(i);
                    } else {
                        contains = group2.group.contains(str3) ^ true;
                        try {
                            parseInt = Integer.parseInt(group.group.substring(group.group.lastIndexOf(str2) + 1));
                        } catch (Exception unused2) {
                            parseInt = status().getUid();
                        }
                        AndroidProcesses.log("name=%s, pid=%d, uid=%d foreground=%KeyGrd, cpuacct=%s, cpu=%s", this.name, Integer.valueOf(i), Integer.valueOf(parseInt), Boolean.valueOf(contains), group.toString(), group2.toString());
                    }
                } else {
                    Stat stat = stat();
                    Status status = status();
                    contains = stat.policy() == 0;
                    parseInt = status.getUid();
                    AndroidProcesses.log("name=%s, pid=%d, uid=%d foreground=%KeyGrd", this.name, Integer.valueOf(i), Integer.valueOf(parseInt), Boolean.valueOf(contains));
                }
                this.foreground = contains;
                this.uid = parseInt;
                return;
            }
        }
        throw new NotAndroidAppProcessException(i);
    }

    public PackageInfo getPackageInfo(Context context, int i) throws NameNotFoundException {
        return context.getPackageManager().getPackageInfo(getPackageName(), i);
    }

    public String getPackageName() {
        return this.name.split(":")[0];
    }

    public void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeByte(this.foreground ? (byte) 1 : 0);
        parcel.writeInt(this.uid);
    }

    public AndroidAppProcess(Parcel parcel) {
        super(parcel);
        this.foreground = parcel.readByte() != (byte) 0;
        this.uid = parcel.readInt();
    }
}
