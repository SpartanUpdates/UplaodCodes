package com.wavymusic.SongSelection.videolib.libffmpeg;

abstract interface ResponseHandler {
    public abstract void onStart();

    public abstract void onFinish();
}
