package com.kotlinz.puzzlecreator.model;

import java.util.List;

public class puzzle_get_set {
    String Id,ansstatus,Puzzleimg, Question, Ans1, Ans2, Ans3, Ans4, Hint, Trueans, Puzzletype, Status,viewfor,level,reviewerstatus,reason,total_view,solvecount;
    public boolean IsNativeAds = false;

    public String getAnsstatus() {
        return ansstatus;
    }

    public void setAnsstatus(String ansstatus) {
        this.ansstatus = ansstatus;
    }

    public String getReviewerstatus() {
        return reviewerstatus;
    }

    public void setReviewerstatus(String reviewerstatus) {
        this.reviewerstatus = reviewerstatus;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getTotal_view() {
        return total_view;
    }

    public void setTotal_view(String total_view) {
        this.total_view = total_view;
    }

    public String getSolvecount() {
        return solvecount;
    }

    public void setSolvecount(String solvecount) {
        this.solvecount = solvecount;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    private List<String> options = null;

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }
    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getViewfor() {
        return viewfor;
    }

    public void setViewfor(String viewfor) {
        this.viewfor = viewfor;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getPuzzletype() {
        return Puzzletype;
    }

    public void setPuzzletype(String puzzletype) {
        Puzzletype = puzzletype;
    }

    public String getPuzzleimg() {
        return Puzzleimg;
    }

    public void setPuzzleimg(String puzzleimg) {
        Puzzleimg = puzzleimg;
    }

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String question) {
        Question = question;
    }

    public String getAns1() {
        return Ans1;
    }

    public void setAns1(String ans1) {
        Ans1 = ans1;
    }

    public String getAns2() {
        return Ans2;
    }

    public void setAns2(String ans2) {
        Ans2 = ans2;
    }

    public String getAns3() {
        return Ans3;
    }

    public void setAns3(String ans3) {
        Ans3 = ans3;
    }

    public String getAns4() {
        return Ans4;
    }

    public void setAns4(String ans4) {
        Ans4 = ans4;
    }

    public String getHint() {
        return Hint;
    }

    public void setHint(String hint) {
        Hint = hint;
    }

    public String getTrueans() {
        return Trueans;
    }

    public void setTrueans(String trueans) {
        Trueans = trueans;
    }

    public boolean isNativeAds() {
        return IsNativeAds;
    }

    public void setNativeAds(boolean nativeAds) {
        IsNativeAds = nativeAds;
    }
}
