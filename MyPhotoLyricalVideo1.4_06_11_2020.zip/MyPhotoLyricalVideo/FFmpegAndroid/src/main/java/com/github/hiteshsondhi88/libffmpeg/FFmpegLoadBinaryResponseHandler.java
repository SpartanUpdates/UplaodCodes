package com.github.hiteshsondhi88.libffmpeg;

public interface FFmpegLoadBinaryResponseHandler extends ResponseHandler {


    public void onFailure();


    public void onSuccess();

}
