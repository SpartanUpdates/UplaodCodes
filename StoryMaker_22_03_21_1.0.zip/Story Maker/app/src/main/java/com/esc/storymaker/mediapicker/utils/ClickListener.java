package com.esc.storymaker.mediapicker.utils;

import android.view.View;

public interface ClickListener {
    void onClick(View view, int i);

    void onLongClick(View view, int i);
}
