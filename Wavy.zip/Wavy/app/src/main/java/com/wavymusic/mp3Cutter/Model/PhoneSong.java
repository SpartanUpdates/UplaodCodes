package com.wavymusic.mp3Cutter.Model;


import java.util.ArrayList;
import java.util.List;

public class PhoneSong {
    private String folderName;
    private List<SongCropModel> localTracks;

    public PhoneSong(String folderName, List<SongCropModel> localTracks) {
        this.folderName = folderName;
        this.localTracks = localTracks;
    }

    public PhoneSong(String folderName) {
        this.folderName = folderName;
        localTracks = new ArrayList<>();
    }

    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public List<SongCropModel> getLocalTracks() {
        return localTracks;
    }

    public void setLocalTracks(List<SongCropModel> localTracks) {
        this.localTracks = localTracks;
    }


}
