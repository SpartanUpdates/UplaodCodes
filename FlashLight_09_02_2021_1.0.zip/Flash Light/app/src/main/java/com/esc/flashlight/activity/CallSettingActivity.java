package com.esc.flashlight.activity;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import com.esc.flashlight.App.APP;
import com.esc.flashlight.R;
import com.esc.flashlight.flashlight.FlashService;
import com.esc.flashlight.util.FALib;
import com.esc.flashlight.util.PrefManager;
import com.esc.flashlight.view.StrobeSettingView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class CallSettingActivity extends BaseActivity {

    Activity activity = CallSettingActivity.this;
    private TextView btnTestOff;
    private TextView btnTestOn;
    private int intervalOff;
    private int intervalOn;
    MyFlashServiceListener onFlashServiceListener;
    private PrefManager pref;
    private StrobeSettingView ssvOff;
    private StrobeSettingView ssvOn;

    ImageView ivback;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    private class MyClickListener implements OnClickListener {
        private MyClickListener() {
        }

        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.btn_test_off:
                    FALib.sendBroadcastFlashActionIntent(CallSettingActivity.this.getApplicationContext(), "flash.light.shine.off");
                    return;
                case R.id.btn_test_on:
                    FALib.sendBroadcastFlashActionIntent(CallSettingActivity.this.getApplicationContext(), "flash.light.shine.ringing");
                    return;
                default:
                    return;
            }
        }
    }

    private class MyOffChangeListener implements OnSeekBarChangeListener {
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        public void onStopTrackingTouch(SeekBar seekBar) {

        }

        private MyOffChangeListener() {

        }

        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            CallSettingActivity.this.intervalOff = i + 1;
            CallSettingActivity.this.pref.setOffIntervalCall(CallSettingActivity.this.intervalOff);
            CallSettingActivity callSettingActivity = CallSettingActivity.this;
            callSettingActivity.displayIntervalOff(callSettingActivity.intervalOff);
        }
    }

    private class MyOnChangeListener implements OnSeekBarChangeListener {
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
        }

        private MyOnChangeListener() {
        }

        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            CallSettingActivity.this.intervalOn = i + 1;
            CallSettingActivity.this.pref.setOnIntervalCall(CallSettingActivity.this.intervalOn);
            CallSettingActivity callSettingActivity = CallSettingActivity.this;
            callSettingActivity.displayIntervalOn(callSettingActivity.intervalOn);
        }
    }

    private class MyFlashServiceListener implements FlashService.OnFlashServiceListener {
        public void onIgnore() {
        }

        private MyFlashServiceListener() {
        }

        public void onStart() {
            CallSettingActivity.this.btnTestOn.setEnabled(false);
            CallSettingActivity.this.btnTestOn.setClickable(false);
            CallSettingActivity.this.btnTestOn.setFocusable(false);
            CallSettingActivity.this.btnTestOff.setEnabled(true);
            CallSettingActivity.this.btnTestOff.setClickable(true);
            CallSettingActivity.this.btnTestOff.setFocusable(true);
        }

        public void onEnd() {
            CallSettingActivity.this.btnTestOn.setEnabled(true);
            CallSettingActivity.this.btnTestOn.setClickable(true);
            CallSettingActivity.this.btnTestOn.setFocusable(true);
            CallSettingActivity.this.btnTestOff.setEnabled(false);
            CallSettingActivity.this.btnTestOff.setClickable(false);
            CallSettingActivity.this.btnTestOff.setFocusable(false);
        }
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return super.onCreateView(view, str, context, attributeSet);
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return super.onCreateView(str, context, attributeSet);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.av_setting_strobe_call);
        initDatas();
        initViews();
        BannerAds();
    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() == 82) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            finish();
        }
        return true;
    }

    public void onResume() {
        super.onResume();
        FlashService.addOnFlashServiceListener(this.onFlashServiceListener);
    }

    public void onPause() {
        super.onPause();
        FALib.sendBroadcastFlashActionIntent(getApplicationContext(), "flash.light.shine.off");
        FlashService.removeOnFlashServiceListener(this.onFlashServiceListener);
    }

    private void initDatas() {
        PrefManager prefManager = APP.getPrefManager();
        this.pref = prefManager;
        this.intervalOn = prefManager.getOnIntervalCall();
        this.intervalOff = this.pref.getOffIntervalCall();
        this.onFlashServiceListener = new MyFlashServiceListener();
    }

    private void initViews() {
        ivback=findViewById(R.id.iv_back);
        this.btnTestOn = findViewById(R.id.btn_test_on);
        this.btnTestOff = findViewById(R.id.btn_test_off);
        this.btnTestOn.setOnClickListener(new MyClickListener());
        this.btnTestOff.setOnClickListener(new MyClickListener());
        this.ssvOn = findViewById(R.id.ssv_on);
        this.ssvOff = findViewById(R.id.ssv_off);
        this.ssvOn.setMax(29);
        this.ssvOff.setMax(29);
        this.ssvOn.setProgress(this.intervalOn);
        this.ssvOff.setProgress(this.intervalOff);
        this.ssvOn.setOnSeekBarChangeListener(new MyOnChangeListener());
        this.ssvOff.setOnSeekBarChangeListener(new MyOffChangeListener());
        Resources resources = getResources();
        this.ssvOn.setTitle(resources.getString(R.string.setting_time_on));
        this.ssvOff.setTitle(resources.getString(R.string.setting_time_off));
        displayIntervalOn(this.intervalOn);
        displayIntervalOff(this.intervalOff);
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void displayIntervalOff(int i) {
        this.ssvOff.setDesc(new StringBuilder(String.valueOf(((long) i) * 50)).append("ms").toString());
    }

    private void displayIntervalOn(int i) {
        this.ssvOn.setDesc(new StringBuilder(String.valueOf(((long) i) * 50)).append("ms").toString());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
