package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.activity.CollageMakerDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;

public class CollageTextOperationListener implements ImageStickerViewNew.c {
    CollageMakerDetailActivity collageMakerDetailActivity;

    public final  ImageStickerViewNew imageStickerViewNew;
    public final  CollageMakerDetailActivity.i b;

    public CollageTextOperationListener(CollageMakerDetailActivity collageMakerDetailActivity, CollageMakerDetailActivity.i iVar, ImageStickerViewNew imageStickerViewNew) {
        this.collageMakerDetailActivity = collageMakerDetailActivity;
        this.b = iVar;
        this.imageStickerViewNew = imageStickerViewNew;
    }

    public void a(ImageStickerViewNew imageStickerViewNew) {
        collageMakerDetailActivity.SvScroll.requestDisallowInterceptTouchEvent(true);
        ImageStickerViewNew imageStickerViewNew2 = collageMakerDetailActivity.p0;
        if (imageStickerViewNew2 != null) {
            imageStickerViewNew2.setInEdit(false);
        }
        imageStickerViewNew.setInEdit(true);
        collageMakerDetailActivity.p0 = imageStickerViewNew;
    }

    public void b(ImageStickerViewNew imageStickerViewNew) {
        collageMakerDetailActivity.rlFull.removeView(imageStickerViewNew);
    }

    public void c(Boolean bool) {
        collageMakerDetailActivity.SvScroll.requestDisallowInterceptTouchEvent(bool.booleanValue());
        if (bool.booleanValue()) {
            collageMakerDetailActivity.p0 = this.imageStickerViewNew;
        }
    }

    public void d(ImageStickerViewNew imageStickerViewNew) {
    }
}
