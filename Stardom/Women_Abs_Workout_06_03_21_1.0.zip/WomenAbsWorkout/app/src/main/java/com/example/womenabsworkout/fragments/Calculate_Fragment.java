package com.example.womenabsworkout.fragments;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.activities.CalculateActivity;
import com.example.womenabsworkout.activities.DayActivity;
import com.example.womenabsworkout.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;


public class Calculate_Fragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public float Heightincms = 0.0f;

    public TextView calculate;
    public RadioButton female;
    public EditText ft;
    public int height;
    public EditText inches;

    public RadioButton kg;
    public RadioButton lbs;
    public SharedPreferences mSharedPreferences;
    public RadioButton male;
    public Editor prefsEditor;
    public EditText weight;
    public int width;
    public EditText year;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    private float calculateHeightinCentimeter(float f) {
        return (float) ((int) (f * 100.0f));
    }

    public int calculateBMI(float f, float f2) {
        return (int) (f2 / (f * f));
    }

    public static Calculate_Fragment newInstance(String str, String str2) {
        Calculate_Fragment calculate_Fragment = new Calculate_Fragment();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_PARAM1, str);
        bundle.putString(ARG_PARAM2, str2);
        calculate_Fragment.setArguments(bundle);
        return calculate_Fragment;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_calculator, viewGroup, false);

        interstitialAd();

        this.mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        this.lbs = (RadioButton) inflate.findViewById(R.id.lbs);
        this.kg = (RadioButton) inflate.findViewById(R.id.kg);
        this.male = (RadioButton) inflate.findViewById(R.id.male);
        this.female = (RadioButton) inflate.findViewById(R.id.female);
        this.ft = (EditText) inflate.findViewById(R.id.feet);
        this.inches = (EditText) inflate.findViewById(R.id.inches);
        this.year = (EditText) inflate.findViewById(R.id.year);
        this.weight = (EditText) inflate.findViewById(R.id.weight);
        calculate = inflate.findViewById(R.id.calculate);

        calculate.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {

                CharSequence charSequence;
                String str = "";
                if (Calculate_Fragment.this.year.getText().toString().equals(str) || Calculate_Fragment.this.ft.getText().toString().equals(str) || Calculate_Fragment.this.inches.getText().toString().equals(str) || Calculate_Fragment.this.weight.getText().toString().equals(str)) {
                    charSequence = "Please fill all the fields";
                    Toast.makeText(Calculate_Fragment.this.getContext(), charSequence, Toast.LENGTH_SHORT).show();
                } else if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(getActivity())
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Calick();
                }

            }
        });
        return inflate;
    }

    public void Calick() {
        CharSequence charSequence;
        String str = "";
        if (Calculate_Fragment.this.year.getText().toString().matches(str) || Integer.parseInt(Calculate_Fragment.this.year.getText().toString()) < 5 || Integer.parseInt(Calculate_Fragment.this.year.getText().toString()) > 100) {
            charSequence = "Age should be in range 5-100 years";
        } else if (Calculate_Fragment.this.ft.getText().toString().matches(str) || Integer.parseInt(Calculate_Fragment.this.ft.getText().toString()) < 2 || Integer.parseInt(Calculate_Fragment.this.ft.getText().toString()) > 7) {
            charSequence = "Feet should be in range 2-7";
        } else if (Calculate_Fragment.this.inches.getText().toString().matches(str) || Integer.parseInt(Calculate_Fragment.this.inches.getText().toString()) < 0 || Integer.parseInt(Calculate_Fragment.this.inches.getText().toString()) > 12) {
            charSequence = "Inches should be in range 0-12";
        } else {
            Calculate_Fragment calculate_Fragment;
            Intent intent;
            String str2 = "HEIGHT";
            String str3 = "BMI";
            Calculate_Fragment calculate_Fragment2;
            float calculateMetres;
            if (Calculate_Fragment.this.kg.isChecked()) {
                if (!Calculate_Fragment.this.weight.getText().toString().matches(str) && Integer.parseInt(Calculate_Fragment.this.weight.getText().toString()) >= 5 && Integer.parseInt(Calculate_Fragment.this.weight.getText().toString()) <= 100) {
                    calculate_Fragment2 = Calculate_Fragment.this;
                    calculateMetres = calculate_Fragment2.calculateMetres(Float.parseFloat(calculate_Fragment2.ft.getText().toString()), Float.parseFloat(Calculate_Fragment.this.inches.getText().toString()));
                    calculate_Fragment = Calculate_Fragment.this;
                    int calculateBMI = calculate_Fragment.calculateBMI(calculateMetres, calculate_Fragment.calculateweight(Float.parseFloat(calculate_Fragment.weight.getText().toString())));
                    calculate_Fragment = Calculate_Fragment.this;
                    calculate_Fragment.prefsEditor = calculate_Fragment.mSharedPreferences.edit();
                    Calculate_Fragment.this.prefsEditor.putFloat(str3, (float) calculateBMI);
                    Calculate_Fragment.this.prefsEditor.putFloat(str2, Calculate_Fragment.this.Heightincms);
                    Calculate_Fragment.this.prefsEditor.apply();
                    intent = new Intent(Calculate_Fragment.this.getContext(), CalculateActivity.class);
                    Calculate_Fragment.this.getActivity().finish();
                    calculate_Fragment = Calculate_Fragment.this;
                    calculate_Fragment.startActivity(intent.putExtra(str3, calculate_Fragment.mSharedPreferences.getFloat(str3, 0.0f)).putExtra(str2, Calculate_Fragment.this.mSharedPreferences.getFloat(str2, 0.0f)));
                    return;
                }
            } else if (!Calculate_Fragment.this.lbs.isChecked()) {
                return;
            } else {
                if (!Calculate_Fragment.this.weight.getText().toString().matches(str) && Integer.parseInt(Calculate_Fragment.this.weight.getText().toString()) >= 11 && Integer.parseInt(Calculate_Fragment.this.weight.getText().toString()) <= 220) {
                    calculate_Fragment2 = Calculate_Fragment.this;
                    calculateMetres = calculate_Fragment2.calculateMetres(Float.parseFloat(calculate_Fragment2.ft.getText().toString()), Float.parseFloat(Calculate_Fragment.this.inches.getText().toString()));
                    calculate_Fragment = Calculate_Fragment.this;
                    calculateMetres = (float) calculate_Fragment.calculateBMI(calculateMetres, calculate_Fragment.calculateweight(Float.parseFloat(calculate_Fragment.weight.getText().toString())));
                    calculate_Fragment = Calculate_Fragment.this;
                    calculate_Fragment.prefsEditor = calculate_Fragment.mSharedPreferences.edit();
                    Calculate_Fragment.this.prefsEditor.putFloat(str3, calculateMetres);
                    Calculate_Fragment.this.prefsEditor.putFloat(str2, Calculate_Fragment.this.Heightincms);
                    Calculate_Fragment.this.prefsEditor.apply();
                    intent = new Intent(Calculate_Fragment.this.getContext(), CalculateActivity.class);
                    Calculate_Fragment.this.getActivity().finish();
                    calculate_Fragment = Calculate_Fragment.this;
                    calculate_Fragment.startActivity(intent.putExtra(str3, calculate_Fragment.mSharedPreferences.getFloat(str3, 0.0f)).putExtra(str2, Calculate_Fragment.this.mSharedPreferences.getFloat(str2, 0.0f)));
                    return;
                }
            }
            intent = null;
            calculate_Fragment = Calculate_Fragment.this;
            calculate_Fragment.startActivity(intent.putExtra(str3, calculate_Fragment.mSharedPreferences.getFloat(str3, 0.0f)).putExtra(str2, Calculate_Fragment.this.mSharedPreferences.getFloat(str2, 0.0f)));
            return;
        }
        Toast.makeText(Calculate_Fragment.this.getContext(), charSequence, Toast.LENGTH_SHORT).show();
    }

    public float calculateMetres(float f, float f2) {
        double d = (double) (f + (f2 / 12.0f));
        Double.isNaN(d);
        f = (float) (d / 3.28d);
        this.Heightincms = calculateHeightinCentimeter(f);
        return f;
    }

    public float calculateweight(float f) {
        if (!this.lbs.isChecked()) {
            return f;
        }
        double d = (double) f;
        Double.isNaN(d);
        return (float) (d * 0.453592d);
    }


    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(getActivity());
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        Calick();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(getActivity());
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
