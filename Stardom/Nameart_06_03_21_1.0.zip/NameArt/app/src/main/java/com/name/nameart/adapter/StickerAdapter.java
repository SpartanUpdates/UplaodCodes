package com.name.nameart.adapter;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.name.nameart.FavDesign.NameEditing;
import com.name.nameart.R;
import com.name.nameart.sticker.StickerView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class StickerAdapter extends RecyclerView.Adapter<StickerAdapter.ViewHolder> {
    public static StickerView mCurrentView;
    Context context;
    int index = -1;
    public List<String> items;
    String path;
    String sticker_type;
    String[] stickers_1;
    String[] stickers_10;
    String[] stickers_11;
    String[] stickers_12;
    String[] stickers_13;
    String[] stickers_14;
    String[] stickers_15;
    String[] stickers_16;
    String[] stickers_17;
    String[] stickers_2;
    String[] stickers_3;
    String[] stickers_4;
    String[] stickers_5;
    String[] stickers_6;
    String[] stickers_7;
    String[] stickers_8;
    String[] stickers_9;
    boolean z = false;

    public StickerAdapter(Context context2, String str) throws IOException {
        char c;
        this.context = context2;
        this.sticker_type = str;
        try {
            this.stickers_1 = context2.getAssets().list(this.context.getString(R.string.king));
            this.stickers_2 = this.context.getAssets().list(this.context.getString(R.string.hipster));
            this.stickers_3 = this.context.getAssets().list(this.context.getString(R.string.love));
            this.stickers_4 = this.context.getAssets().list(this.context.getString(R.string.lines));
            this.stickers_5 = this.context.getAssets().list(this.context.getString(R.string.feather));
            this.stickers_6 = this.context.getAssets().list(this.context.getString(R.string.angle));
            this.stickers_7 = this.context.getAssets().list(this.context.getString(R.string.devil));
            this.stickers_8 = this.context.getAssets().list(this.context.getString(R.string.smily));
            this.stickers_9 = this.context.getAssets().list(this.context.getString(R.string.lion));
            this.stickers_10 = this.context.getAssets().list(this.context.getString(R.string.flower));
            this.stickers_11 = this.context.getAssets().list(this.context.getString(R.string.butterfly));
            this.stickers_12 = this.context.getAssets().list(this.context.getString(R.string.star));
            this.stickers_13 = this.context.getAssets().list(this.context.getString(R.string.panda));
            this.stickers_14 = this.context.getAssets().list(this.context.getString(R.string.micky_mouse));
            this.stickers_15 = this.context.getAssets().list(this.context.getString(R.string.ear));
            this.stickers_16 = this.context.getAssets().list(this.context.getString(R.string.city));
            this.stickers_17 = this.context.getAssets().list(this.context.getString(R.string.diwali));
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch (str.hashCode()) {
            case -1331440692:
                if (str.equals("diwali")) {
                    c = 16;
                    break;
                }
            case -1271629221:
                if (str.equals("flower")) {
                    c = '\t';
                    break;
                }
            case -979220317:
                if (str.equals("feather")) {
                    c = 4;
                    break;
                }
            case 100182:
                if (str.equals("ear")) {
                    c = 14;
                    break;
                }
            case 2467443:
                if (str.equals("butterfly")) {
                    c = '\n';
                    break;
                }
            case 3053931:
                if (str.equals("city")) {
                    c = 15;
                    break;
                }
            case 3292055:
                if (str.equals("king")) {
                    c = 0;
                    break;
                }
            case 3321884:
                if (str.equals("lion")) {
                    c = '\b';
                    break;
                }
            case 3327858:
                if (str.equals("love")) {
                    c = 2;
                    break;
                }
            case 3540562:
                if (str.equals("star")) {
                    c = 11;
                    break;
                }
            case 37147099:
                if (str.equals("micky_mouse")) {
                    c = '\r';
                    break;
                }
            case 92960979:
                if (str.equals("angle")) {
                    c = 5;
                    break;
                }
            case 95477752:
                if (str.equals("devil")) {
                    c = 6;
                    break;
                }
            case 102977279:
                if (str.equals("lines")) {
                    c = 3;
                    break;
                }
            case 106432986:
                if (str.equals("panda")) {
                    c = '\f';
                    break;
                }
            case 109556508:
                if (str.equals("smily")) {
                    c = 7;
                    break;
                }
            case 924138205:
                if (str.equals("hipster")) {
                    c = 1;
                    break;
                }
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                this.path = this.context.getString(R.string.king);
                List<String> list = this.items;
                if (list == null || list.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_1));
                notifyDataSetChanged();
                return;
            case 1:
                this.path = this.context.getString(R.string.hipster);
                List<String> list2 = this.items;
                if (list2 == null || list2.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_2));
                notifyDataSetChanged();
                return;
            case 2:
                this.path = this.context.getString(R.string.love);
                List<String> list3 = this.items;
                if (list3 == null || list3.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_3));
                notifyDataSetChanged();
                return;
            case 3:
                this.path = this.context.getString(R.string.lines);
                List<String> list4 = this.items;
                if (list4 == null || list4.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_4));
                notifyDataSetChanged();
                return;
            case 4:
                this.path = this.context.getString(R.string.feather);
                List<String> list5 = this.items;
                if (list5 == null || list5.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_5));
                notifyDataSetChanged();
                return;
            case 5:
                this.path = this.context.getString(R.string.angle);
                List<String> list6 = this.items;
                if (list6 == null || list6.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_6));
                notifyDataSetChanged();
                return;
            case 6:
                this.path = this.context.getString(R.string.devil);
                List<String> list7 = this.items;
                if (list7 == null || list7.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_7));
                notifyDataSetChanged();
                return;
            case 7:
                this.path = this.context.getString(R.string.smily);
                List<String> list8 = this.items;
                if (list8 == null || list8.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_8));
                notifyDataSetChanged();
                return;
            case '\b':
                this.path = this.context.getString(R.string.lion);
                List<String> list9 = this.items;
                if (list9 == null || list9.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_9));
                notifyDataSetChanged();
                return;
            case '\t':
                this.path = this.context.getString(R.string.flower);
                List<String> list10 = this.items;
                if (list10 == null || list10.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_10));
                notifyDataSetChanged();
                return;
            case '\n':
                this.path = this.context.getString(R.string.butterfly);
                List<String> list11 = this.items;
                if (list11 == null || list11.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_11));
                notifyDataSetChanged();
                return;
            case 11:
                this.path = this.context.getString(R.string.star);
                List<String> list12 = this.items;
                if (list12 == null || list12.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_12));
                notifyDataSetChanged();
                return;
            case '\f':
                this.path = this.context.getString(R.string.panda);
                List<String> list13 = this.items;
                if (list13 == null || list13.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_13));
                notifyDataSetChanged();
                return;
            case '\r':
                this.path = this.context.getString(R.string.micky_mouse);
                List<String> list14 = this.items;
                if (list14 == null || list14.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_14));
                notifyDataSetChanged();
                return;
            case 14:
                this.path = this.context.getString(R.string.ear);
                List<String> list15 = this.items;
                if (list15 == null || list15.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_15));
                notifyDataSetChanged();
                return;
            case 15:
                this.path = this.context.getString(R.string.city);
                List<String> list16 = this.items;
                if (list16 == null || list16.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_16));
                notifyDataSetChanged();
                return;
            case 16:
                this.path = this.context.getString(R.string.diwali);
                List<String> list17 = this.items;
                if (list17 == null || list17.size() <= 0) {
                    this.items = new ArrayList();
                } else {
                    this.items.clear();
                }
                this.items.addAll(Arrays.asList(this.stickers_17));
                notifyDataSetChanged();
                return;
            default:
                return;
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public View parentLayout;
        public ConstraintLayout row_sticker;
        public ImageView sticker_img;

        public ViewHolder(View view) {
            super(view);
            this.sticker_img = (ImageView) view.findViewById(R.id.sticker_img);
            this.row_sticker = (ConstraintLayout) view.findViewById(R.id.row_sticker);
        }

        public ImageView getImage() {
            return this.sticker_img;
        }
    }
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i)
    {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.sticker_adapter, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        try {
            RequestManager with = Glide.with(this.context);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("file:///android_asset/");
            stringBuilder.append(this.path);
            stringBuilder.append("/");
            stringBuilder.append((String) this.items.get(i));
            with.load(Uri.parse(stringBuilder.toString())).into(viewHolder.sticker_img);

            viewHolder.sticker_img.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    InputStream open;
                    StickerAdapter.this.index = i;
                    StickerAdapter.this.otherUnSelect();
                    try {
                        AssetManager assets = StickerAdapter.this.context.getAssets();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(StickerAdapter.this.path);
                        stringBuilder.append("/");
                        stringBuilder.append((String) StickerAdapter.this.items.get(i));
                        open = assets.open(stringBuilder.toString());
                    } catch (IOException e) {
                        e.printStackTrace();
                        open = null;
                    }
                    StickerAdapter.this.addStickerView(BitmapFactory.decodeStream(open));
                }
            });
            if (this.index == i) {
                viewHolder.row_sticker.setBackgroundResource(R.drawable.bg_selected);
            } else {
                viewHolder.row_sticker.setBackgroundColor(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addStickerView(Bitmap bitmap) {
        NameEditing nameEditing = (NameEditing) this.context;
        int i = 0;
//        NameEditing.recycle_color_sticker_tint.setVisibility(View.VISIBLE);
        while (i < NameEditing.contain_sticker.getChildCount()) {
            if ((NameEditing.contain_sticker.getChildAt(i) instanceof StickerView) && ((StickerView) NameEditing.contain_sticker.getChildAt(i)).getEditMode()) {
                ((StickerView) NameEditing.contain_sticker.getChildAt(i)).replaceBitmap(bitmap);
                this.z = true;
                break;
            }
            i++;
        }
        if (!this.z) {
            final StickerView stickerView = new StickerView(this.context);
            stickerView.setBitmap(bitmap);
            stickerView.setOperationListener(new StickerView.OperationListener() {
                public void onDeleteClick() {
                    NameEditing.mViews.remove(stickerView);
                    NameEditing.contain_sticker.removeView(stickerView);
                }

                public void onEdit(StickerView stickerView) {
                    StickerAdapter.mCurrentView.setInEdit(false);
                    StickerAdapter.mCurrentView = stickerView;
                    StickerAdapter.mCurrentView.setInEdit(true);
                    if (NameEditing.contain_sticker.getChildCount() == 0) {
                       NameEditing nameEditing = (NameEditing) StickerAdapter.this.context;
                        //NameEditing.recycle_color_sticker_tint.setVisibility(View.GONE);
                    } else {
                        NameEditing  nameEditing2 = (NameEditing) StickerAdapter.this.context;
                      //  NameEditing.recycle_color_sticker_tint.setVisibility(View.VISIBLE);
                    }
                    StickerAdapter.this.otherUnSelect();
                }

                public void onTop(StickerView stickerView) {
                    int indexOf = NameEditing.mViews.indexOf(stickerView);
                    if (indexOf != NameEditing.mViews.size() - 1) {
                        NameEditing.mViews.add(NameEditing.mViews.size(), (StickerView) NameEditing.mViews.remove(indexOf));
                    }
                }
            });
            NameEditing.contain_sticker.addView(stickerView, new LayoutParams(-1, -1));
            NameEditing.mViews.add(stickerView);
            setCurrentEdit(stickerView);
        }
    }

    private void setCurrentEdit(StickerView stickerView) {
        StickerView stickerView2 = mCurrentView;
        if (stickerView2 != null) {
            stickerView2.setInEdit(false);
        }
        mCurrentView = stickerView;
        stickerView.setInEdit(true);
    }

    public int getItemCount() {
        return this.items.size();
    }

    public void otherUnSelect() {
        for (int i = 0; i < ((NameEditing) this.context).dynamicStickerFrame.getChildCount(); i++) {
            ((NameEditing) this.context).dynamicStickerFrame.getChildAt(i).findViewById(R.id.ll_view1).setBackground((Drawable) null);
            ((ImageView) ((NameEditing) this.context).dynamicStickerFrame.getChildAt(i).findViewById(R.id.delete_text)).setVisibility(View.INVISIBLE);
            ((NameEditing) this.context).invisibleeditlayouts(Boolean.valueOf(false));
        }
        if (((NameEditing) this.context).mCurrentView_pic != null) {
            ((NameEditing) this.context).mCurrentView_pic.setInEdit(false);
        }
    }
}
