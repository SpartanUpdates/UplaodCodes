package com.Pulse.VideoStatus.Model;

public class ThemelModel {
    public boolean isAvailableOffline = false;
    public boolean isDownloading = false;
    private String categoryid;
    private String themeid;
    private String ThemeName;
    private String image;
    private String Animsoundurl;
    private String AnimSoundPath;
    private String AnimSoundname;
    private int AnimSoundfilesize;
    private int img_no_of;
    private String GameobjectName;
    private String ThemeCounter;
    public boolean IsNativeAds = false;
    public boolean o;
    public boolean p;
    private String isNewRealise;
    public String getCategoryid() {
        return categoryid;
    }

    public void setCategoryid(String categoryid) {
        this.categoryid = categoryid;
    }

    public String getThemeid() {
        return themeid;
    }

    public void setThemeid(String themeid) {
        this.themeid = themeid;
    }

    public String getThemeName() {
        return ThemeName;
    }

    public void setThemeName(String themeName) {
        ThemeName = themeName;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAnimsoundurl() {
        return Animsoundurl;
    }

    public void setAnimsoundurl(String animsoundurl) {
        Animsoundurl = animsoundurl;
    }

    public String getAnimSoundPath() {
        return AnimSoundPath;
    }

    public void setAnimSoundPath(String animSoundPath) {
        AnimSoundPath = animSoundPath;
    }

    public String getAnimSoundname() {
        return AnimSoundname;
    }

    public void setAnimSoundname(String animSoundname) {
        AnimSoundname = animSoundname;
    }

    public int getAnimSoundfilesize() {
        return AnimSoundfilesize;
    }

    public void setAnimSoundfilesize(int animSoundfilesize) {
        AnimSoundfilesize = animSoundfilesize;
    }

    public int getImg_no_of() {
        return img_no_of;
    }

    public void setImg_no_of(int img_no_of) {
        this.img_no_of = img_no_of;
    }

    public String getGameobjectName() {
        return GameobjectName;
    }

    public void setGameobjectName(String gameobjectName) {
        GameobjectName = gameobjectName;
    }

    public String getThemeCounter() {
        return ThemeCounter;
    }

    public void setThemeCounter(String themeCounter) {
        ThemeCounter = themeCounter;
    }

    public boolean isAvailableOffline() {
        return isAvailableOffline;
    }

    public void setAvailableOffline(boolean availableOffline) {
        isAvailableOffline = availableOffline;
    }

    public boolean isDownloading() {
        return isDownloading;
    }

    public void setDownloading(boolean downloading) {
        isDownloading = downloading;
    }

    public boolean isNativeAds() {
        return IsNativeAds;
    }

    public void setNativeAds(boolean nativeAds) {
        IsNativeAds = nativeAds;
    }
    public String isNewRealise() {
        return isNewRealise;
    }

    public void setNewRealise(String newRealise) {
        isNewRealise = newRealise;
    }
}
