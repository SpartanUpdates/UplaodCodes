package com.kotlinz.puzzlecreator.Download;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.content.FileProvider;

import com.kotlinz.puzzlecreator.Utils.Utils;
import com.kotlinz.puzzlecreator.model.puzzle_get_set;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadPuzzleImage {
    private Context activity;
    private String PuzzleImagePath;
    private String PuzzleImageSaveFileName;
    puzzle_get_set puzzle;

    public DownloadPuzzleImage(Context activity, String puzzleImagePath, String puzzleImageSaveFileName, puzzle_get_set puzzle) {
        this.activity = activity;
        this.PuzzleImagePath = puzzleImagePath;
        this.PuzzleImageSaveFileName = puzzleImageSaveFileName;
        this.puzzle = puzzle;
        //Download Template
        new DownloadingTemplateImageTask().execute();
    }

    @SuppressLint("StaticFieldLeak")
    private class DownloadingTemplateImageTask extends AsyncTask<Void, Void, Void> {

        File apkStorage = null;
        File outputFile = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        protected void onPostExecute(Void result) {
            try {
                if (outputFile != null) {
                    File PuzzleShareFile = new File(Utils.INSTANCE.getPuzzleImage() + PuzzleImageSaveFileName);
                    String ans;
                    if (puzzle.getPuzzletype().equalsIgnoreCase("manual")) {
                        ans = "Type Answer manually";
                    } else {
                        ans = String.join("\n=> ", puzzle.getOptions());
                    }
                    String text = "Hey ! \n" +
                            "\n" +
                            "Solve this puzzle\n "
                            + "----------------------------\n"
                            + puzzle.getQuestion() + "\n"
                            + "----------------------------\n=> "
                            + ans
                            + "\n----------------------------\n" +
                            " from  https://play.google.com/store/apps/details?id=" + activity.getPackageName() + " and earn points";
                    Intent shareIntent = new Intent();
                    shareIntent.setAction(Intent.ACTION_SEND);
                    shareIntent.setType("image/*");
                    final Uri ShareUri = FileProvider.getUriForFile(activity, String.valueOf(activity.getPackageName()) + ".provider", PuzzleShareFile);
                    shareIntent.putExtra(Intent.EXTRA_STREAM, ShareUri);
                    shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    activity.startActivity(Intent.createChooser(shareIntent, "Share Puzzle..."));
                } else {
                    DeleteFileIfInterupt(Utils.INSTANCE.getPuzzleImage() + File.separator + PuzzleImageSaveFileName);
                }
            } catch (Exception e) {
                e.printStackTrace();
                DeleteFileIfInterupt(Utils.INSTANCE.getPuzzleImage() + File.separator + PuzzleImageSaveFileName);
            }
            super.onPostExecute(result);
        }


        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                URL url = new URL(PuzzleImagePath);
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.connect();
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.e("TAG", "Server returned HTTP " + c.getResponseCode() + " " + c.getResponseMessage());
                }
                //Get File if SD card is present
                if (new CheckForSDCard().isSDCardPresent()) {
                    apkStorage = new File(Utils.INSTANCE.getPuzzleImage());
                } else
                    Toast.makeText(activity, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
                if (!apkStorage.exists()) {
                    apkStorage.mkdir();
                }

                outputFile = new File(apkStorage, PuzzleImageSaveFileName);
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                }

                FileOutputStream fos = new FileOutputStream(outputFile);
                InputStream is = c.getInputStream();
                byte[] buffer = new byte[1024];
                int len1 = 0;
                while ((len1 = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len1);
                }
                fos.close();
                is.close();
            } catch (Exception e) {
                e.printStackTrace();
                outputFile = null;
            }
            return null;
        }
    }

    private void DeleteFileIfInterupt(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            file.delete();
        }
    }
}
