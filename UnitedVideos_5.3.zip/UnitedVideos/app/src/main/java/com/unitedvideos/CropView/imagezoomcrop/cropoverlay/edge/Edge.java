package com.unitedvideos.CropView.imagezoomcrop.cropoverlay.edge;

public enum Edge {
    LEFT,
    TOP,
    RIGHT,
    BOTTOM;
    private float mCoordinate;

    public void setCoordinate(float coordinate) {
        mCoordinate = coordinate;
    }

    public float getCoordinate() {
        return mCoordinate;
    }

    public static float getWidth() {
        return RIGHT.getCoordinate() - LEFT.getCoordinate();
    }

    public static float getHeight() {
        return BOTTOM.getCoordinate() - TOP.getCoordinate();
    }
}
