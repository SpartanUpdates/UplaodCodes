package com.wavymusic.activity;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.wavymusic.R;
import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.io.IOException;

public class WallpaperSetActivity extends AppCompatActivity {

    Activity activity = WallpaperSetActivity.this;
    ImageView ivback;
    TextView tvTitle;
    ImageView ivshare, ivPreview;
    Button btnShareWallpapper;
    String wpPreviewPath;

    private AdView adView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallpaper_set);
        if (getIntent() != null) {
            wpPreviewPath = getIntent().getStringExtra("WpPreviewPath");
        }
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "WallpaperSetActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        BindView();
        BannerAds();
        Log.e("TAG", "Preview Path" + wpPreviewPath);
        Glide.with(activity).load(wpPreviewPath).into(ivPreview);
    }

    private void BannerAds() {
        adView = new AdView(this, getResources().getString(R.string.fb_banner), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = findViewById(R.id.banner_container);
        adContainer.addView(adView);
        adView.loadAd();
    }

    private void BindView() {
        ivback = findViewById(R.id.ivBack);
        tvTitle = findViewById(R.id.tv_title);
        ivshare = findViewById(R.id.ivWallpaperShare);
        ivPreview = findViewById(R.id.ivImagePreview);
        btnShareWallpapper = findViewById(R.id.btnSetAsWallpaper);
        Glide.with(activity).load(wpPreviewPath).into(ivPreview);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        ivshare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(wpPreviewPath);
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("image/*");
                intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.app_name));
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(getString(R.string.get_free));
                stringBuilder.append(getString(R.string.app_name));
                stringBuilder.append(" Music at here : https://play.google.com/store/apps/details?id=");
                stringBuilder.append(getPackageName());
                intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                intent.putExtra("android.intent.extra.TITLE", "Wavy Music : Particle.ly Video Status Maker");
                intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(activity, getPackageName(), file));
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, getString(R.string.wallpaper_share)));

            }
        });
        btnShareWallpapper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (wpPreviewPath != null) {
                    SetImageAsWallPapper(activity, wpPreviewPath);
                }
            }
        });
    }

    private void SetImageAsWallPapper(Context context, String str) {
        if (!(context == null || str == null)) {
            WallpaperManager myWallpaperManager = WallpaperManager.getInstance(context);
            try {
                myWallpaperManager.setBitmap(BitmapFactory.decodeFile(str));
                Toast.makeText(context, context.getString(R.string.wallpaper_done), Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public void onBackPressed() {
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }

}
