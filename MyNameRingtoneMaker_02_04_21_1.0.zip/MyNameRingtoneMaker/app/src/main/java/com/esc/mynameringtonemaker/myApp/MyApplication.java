package com.esc.mynameringtonemaker.myApp;

import android.app.Application;
import android.os.Build;
import android.os.StrictMode;
import android.text.TextUtils;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.esc.mynameringtonemaker.OpenAds.AppOpenManager;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class MyApplication extends Application {

    AppOpenManager appOpenManager;

    public static MyApplication context;
    private RequestQueue mRequestQueue;
    public static final String TAG = MyApplication.class.getSimpleName();

    public void onCreate() {
        super.onCreate();
        context = this;
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        AudienceNetworkAds.initialize(this);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        appOpenManager = new AppOpenManager(this);
        if (Build.VERSION.SDK_INT >= 24) {
            final StrictMode.VmPolicy.Builder strictModeVmPolicyBuilder = new StrictMode.VmPolicy.Builder();
            strictModeVmPolicyBuilder.detectFileUriExposure();
            StrictMode.setVmPolicy(strictModeVmPolicyBuilder.build());
        }
    }

    public static synchronized MyApplication getInstance() {

        return context;
    }

    public static MyApplication getContext() {
        return context;
    }

    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }

        return mRequestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req, String tag) {
        req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
        getRequestQueue().add(req);
    }
}
