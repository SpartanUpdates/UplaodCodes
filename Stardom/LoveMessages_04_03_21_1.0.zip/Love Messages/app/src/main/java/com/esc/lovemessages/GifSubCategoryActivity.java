package com.esc.lovemessages;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import java.util.ArrayList;

public class GifSubCategoryActivity extends AppCompatActivity {
    Activity activity = GifSubCategoryActivity.this;
    private String category = "birthday";
    private GifDataBaseHelper db;
    private LayoutManager layoutManager;
    private Adapter mAdapter;
    private RecyclerView recyclerView;
    private ArrayList<String> subcategories;
    private ArrayList<String> subcategorycount;
    Typeface typeface;
    String value;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_gifsubcategory);
        this.typeface = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Bold.ttf");
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        String str = null;
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.action_bar_title, null);
        getSupportActionBar().setCustomView(inflate);
        TextView textView = (TextView) inflate.findViewById(R.id.action_bar_title);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            str = extras.getString("title");
        }
        this.value = str;
        textView.setTypeface(this.typeface);
        textView.setText(R.string.appname);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.db = new GifDataBaseHelper(this);
        this.subcategories = new ArrayList();
        this.subcategorycount = new ArrayList();
        this.subcategories = this.db.GetAllSubCategories(this.category);
        this.subcategorycount = this.db.GetAllSubCategoriesCount(this.category);
        this.recyclerView = (RecyclerView) findViewById(R.id.subcategory_recyclerview);
        this.layoutManager = new LinearLayoutManager(this);
        this.recyclerView.setLayoutManager(this.layoutManager);
        this.mAdapter = new GifSubCategoryAdapter(this, this.subcategories, this.subcategorycount);
        this.recyclerView.setAdapter(this.mAdapter);
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(28.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        BannerAds();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.favorite, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
        } else if (itemId == R.id.favmenu) {
            startActivity(new Intent(this, GifFavoriteActivity.class));
        }
        return super.onOptionsItemSelected(menuItem);
    }

}
