package com.kotlinz.photoslideshow.activity;

import static com.kotlinz.photoslideshow.view.CustomNativeAd.populateUnifiedNativeAdView;
import static com.kotlinz.photoslideshow.view.CustomNativeAd.populateUnifiedNativeAdViewbig;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.kotlinz.photoslideshow.util.EPreferences;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.photoslideshow.MyApplication;
import com.kotlinz.photoslideshow.R;
import com.kotlinz.photoslideshow.adapters.ImageEditAdapter;
import com.kotlinz.photoslideshow.adapters.OnItemClickListner;
import com.kotlinz.photoslideshow.data.ImageData;
import com.kotlinz.photoslideshow.util.ActivityAnimUtil;
import com.kotlinz.photoslideshow.util.ImageEditor;
import com.kotlinz.photoslideshow.util.Utils;
import com.kotlinz.photoslideshow.view.EmptyRecyclerView;
import java.io.File;

public class Activity_ArrangeImage extends AppCompatActivity {
    private Activity activity = Activity_ArrangeImage.this;
    public static boolean isEdit = false;
    RelativeLayout rlToolbar;
    ImageView ivback, ivnext;
    private EPreferences ePreferences;
    private MyApplication application;
    private ImageEditAdapter imageEditAdapter;
    private boolean isFromCameraNotification;
    private EmptyRecyclerView rvSelectedImages;
    String tempImgPath;

    private NativeAd nativeAd;

    Callback callback = new Callback() {
        @Override
        public boolean onMove(RecyclerView recyclerView, ViewHolder viewHolder, ViewHolder viewHolder2) {
            return true;
        }

        @Override
        public void onSwiped(ViewHolder viewHolder, int i) {
        }

        @Override
        public void onSelectedChanged(ViewHolder viewHolder, int i) {
            if (i == 0) {
                Activity_ArrangeImage.this.imageEditAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public void onMoved(final RecyclerView recyclerView, final ViewHolder recyclerView$ViewHolder, final int n, final ViewHolder recyclerView$ViewHolder2, final int n2, final int n3, final int n4) {
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isStartFrameExist() && n == 0) {
                return;
            }
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isEndFrameExist() && n == Activity_ArrangeImage.this.application.selectedImages.size() - 1) {
                return;
            }
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isStartFrameExist() && n2 == 0) {
                return;
            }
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isEndFrameExist() && n2 == Activity_ArrangeImage.this.application.selectedImages.size() - 1) {
                return;
            }
            Activity_ArrangeImage.this.imageEditAdapter.swap(recyclerView$ViewHolder.getAdapterPosition(), recyclerView$ViewHolder2.getAdapterPosition());
            Activity_ArrangeImage.this.application.min_pos = Math.min(Activity_ArrangeImage.this.application.min_pos, Math.min(n, n2));
            MyApplication.isBreak = true;
        }

        public int getMovementFlags(RecyclerView recyclerView, ViewHolder viewHolder) {
            return makeFlag(2, 51);
        }
    };

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_arrange_images);
        if (Utils.checkPermission(this)) {
            this.application = MyApplication.getInstance();
            this.application.isEditModeEnable = true;
            application.isFromPreview = getIntent().hasExtra("extra_from_preview");
            bindView();
            init();
            addListener();
            loadAd();
            return;
        }
        PutAnalyticsEvent();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void bindView() {
        rvSelectedImages = findViewById(R.id.rvVideoAlbum);
        rlToolbar = findViewById(R.id.rl_toolbar);
        ivback = findViewById(R.id.iv_back);
        ivnext = findViewById(R.id.iv_next);

    }

    private void addListener() {
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 102;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        onBackPressed();
                    }
                }
            }
        });

        ivnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MyApplication.isShowAd == 1) {
                    addTitle();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null ) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 103;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        addTitle();
                    }
                }
            }
        });
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "Activity_ArrangeImage");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void init() {
        setupAdapter();
        new ItemTouchHelper(this.callback).attachToRecyclerView(this.rvSelectedImages);
        Utils.setFont(this, R.id.toolbar_title);
        this.isFromCameraNotification = getIntent().getExtras().getBoolean("isFromCameraNotification");
        if (getIntent().getExtras().getString("KEY").equals("FromImageSelection") || getIntent().getExtras().getString("KEY").equals("FromCameraService") || getIntent().getExtras().getString("KEY").equals("FromPreview")) {
            isEdit = true;
        }
    }

    private void setupAdapter() {
        LayoutManager gridLayoutManager = new GridLayoutManager(this, 2, RecyclerView.VERTICAL, false);
        this.imageEditAdapter = new ImageEditAdapter(Activity_ArrangeImage.this);
        this.rvSelectedImages.setLayoutManager(gridLayoutManager);
        this.rvSelectedImages.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImages.setEmptyView(findViewById(R.id.list_empty));
        this.rvSelectedImages.setAdapter(this.imageEditAdapter);
        this.imageEditAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                Integer.parseInt((String) view.getTag());
            }
        });
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == ImageEditor.IMAGE_EDIT_ACTIVITY_TEXT_AND_STICKER && i2 == -1) {
            this.application.selectedImages.remove(MyApplication.TEMP_POSITION);
            ImageData idata = new ImageData();
            idata.setImagePath(intent.getExtras().getString("ImgPath"));
            this.application.selectedImages.add(MyApplication.TEMP_POSITION, idata);
            setupAdapter();
        }
    }

    protected void onResume() {
        super.onResume();
        if (Utils.checkPermission(this)) {
            this.application.isEditModeEnable = true;
            if (this.imageEditAdapter != null) {
                this.imageEditAdapter.notifyDataSetChanged();
                return;
            }
            return;
        }
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private boolean isEndFrameExist() {
        return Fragment_EndFrame.lastsaveTempPath != null && new File(Fragment_EndFrame.lastsaveTempPath).exists();
    }

    private boolean isStartFrameExist() {
        return new File(Fragment_StartFrame.lastsaveTempPath).exists();
    }


    private void done() {
        this.application.isEditModeEnable = false;
        if (application.isFromPreview) {
            activity.setResult(-1);
            activity.finish();
            return;
        }
        ActivityAnimUtil.startActivitySafely(this.rlToolbar, new Intent(this, PreviewActivity.class));
    }

    public void addTitle() {
        Intent intent = new Intent(activity, AddTitleActivity.class);
        intent.putExtra("ISFROMPREVIEW", application.isFromPreview);
        startActivity(intent);
        if (application.isFromPreview) {
            activity.finish();
        }
    }

    public void onBackPressed() {
        isEdit = false;
        if (application.isFromPreview && !this.isFromCameraNotification) {
            addTitleAlert();
        }
        if (this.isFromCameraNotification) {
            Intent intent = new Intent(activity, PhotoselectActivity.class);
            intent.putExtra("isFromImageEditActivity", true);
            startActivity(intent);
            activity.finish();
            return;
        }
        onBackDialog();
    }

    private void addTitleAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AppAlertDialog);
        builder.setTitle(R.string.add_story_title);
        builder.setMessage(R.string.do_you_want_to_add_title_frame_);
        builder.setPositiveButton(R.string.yes, new OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialogInterface, final int n) {
                Activity_ArrangeImage.this.application.isEditModeEnable = false;
                final Intent intent = new Intent(Activity_ArrangeImage.this, AddTitleActivity.class);
                intent.putExtra("ISFROMPREVIEW", application.isFromPreview);
                ActivityAnimUtil.startActivitySafely(Activity_ArrangeImage.this.rlToolbar, intent);
                if (application.isFromPreview) {
                    Activity_ArrangeImage.this.finish();
                }
            }
        });
        builder.setNegativeButton(R.string.skip, new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Activity_ArrangeImage.this.done();
            }
        });
        builder.show();
    }

    private void onBackDialog() {
        new AlertDialog.Builder(this, R.style.Theme_MovieMaker_AlertDialog).setTitle(R.string.app_name).setMessage(R.string.your_changes_on_images_will_be_removed_are_you_sure_to_go_back_).setPositiveButton(R.string.go_back, new OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialogInterface, final int n) {
                if (application.isFromPreview && !Activity_ArrangeImage.this.isFromCameraNotification) {
                    Activity_ArrangeImage.this.done();
                    return;
                }
                final Intent intent = new Intent(Activity_ArrangeImage.this, PhotoselectActivity.class);
                intent.putExtra("isFromImageEditActivity", true);
                Activity_ArrangeImage.this.startActivity(intent);
                Activity_ArrangeImage.this.finish();
            }
        }).setNegativeButton(R.string.stay_here, null).create().show();
    }



    private void loadAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (Activity_ArrangeImage.this.nativeAd != null) {
                            Activity_ArrangeImage.this.nativeAd.destroy();
                        }
                        Activity_ArrangeImage.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }
}
