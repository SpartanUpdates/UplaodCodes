package com.esc.gesturelockscreen.Other;

public interface Actions
{
  public static final String BROADCAST_LOCK_DISABLED = "DISABLED";
  public static final String BROADCAST_LOCK_ENABLED = "ENABLED";
  public static final String SERVICE_PREVIEW_LOCK = "PREVIEW_LOCK";
}
