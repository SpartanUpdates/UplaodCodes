package com.kotlinz.puzzlecreator.introslider;

import android.os.Bundle;

import com.kotlinz.puzzlecreator.activity.BaseActivity;
import com.kotlinz.puzzlecreator.R;

public class WelcomeActivity2 extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome2);
    }
}