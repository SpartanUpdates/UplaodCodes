package com.esc.fontappstylish.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.esc.fontappstylish.utils.Const;
import com.esc.fontappstylish.utils.ImageUtils;
import com.esc.fontappstylish.R;
import com.isseiaoki.simplecropview.CropImageView;
import com.isseiaoki.simplecropview.CropImageView.CropMode;

public class CropActivity extends AppCompatActivity implements OnClickListener {
    private String croppedImagePath;
    private Bundle extras;
    private RelativeLayout loutBack;
    private CropImageView mCropView;
    private ImageView routdone;
    private String s;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_crop);
        findViewByid();
        routdone.setOnClickListener(this);
        loutBack.setOnClickListener(this);
        mCropView.setCropMode(CropMode.FREE);
        bundle = getIntent().getExtras();
        extras = bundle;
        if (bundle != null) {
            this.s = bundle.getString("picturePath");
            Bitmap compressedBitmap22 = ImageUtils.getInstant().getCompressedBitmap22(this.s);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("onCreate: ");
            stringBuilder.append(compressedBitmap22);
            mCropView.setImageBitmap(compressedBitmap22);
        }
    }

    private void findViewByid() {
        this.routdone = (ImageView) findViewById(R.id.routdone);
        this.mCropView = (CropImageView) findViewById(R.id.cropImageView);
        this.loutBack = (RelativeLayout) findViewById(R.id.routBack);
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.routBack) {
            finish();
        } else if (id == R.id.routdone) {
            croppedImagePath = Const.saveImageToInternalStorage(getApplicationContext(), mCropView.getCroppedBitmap(), "img.png").toString();
            Intent intent = new Intent();
            intent.putExtra("myResult", this.croppedImagePath);
            setResult(1111, intent);
            finish();
        }
    }
}
