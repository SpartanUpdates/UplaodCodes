package com.kotlinz.festivalstorymaker.TypeFace;

import android.graphics.Shader;
import android.graphics.Typeface;

public class Font {

    public int a;
    public float b;
    public Typeface c;
/*
    public a(int a, float b, Typeface c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }*/

    public Font() {
        final Shader.TileMode mirror = Shader.TileMode.MIRROR;
    }
}
