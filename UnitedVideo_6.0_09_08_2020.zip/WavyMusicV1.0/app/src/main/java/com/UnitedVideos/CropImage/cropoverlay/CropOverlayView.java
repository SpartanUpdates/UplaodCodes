package com.UnitedVideos.CropImage.cropoverlay;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Path.Direction;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region.Op;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;

import com.UnitedVideos.CropImage.cropoverlay.edge.Edge;
import com.UnitedVideos.CropImage.cropoverlay.utils.PaintUtil;
import com.UnitedVideos.CropImage.photoview.IGetImageBounds;
import com.wavymusic.R;

public class CropOverlayView
        extends View
        implements IGetImageBounds {
    private boolean DEFAULT_GUIDELINES = true;
    private int DEFAULT_MARGINTOP = 100;
    private int DEFAULT_MARGINSIDE = 50;
    private int DEFAULT_MIN_WIDTH = 500;
    private int DEFAULT_MAX_WIDTH = 700;
    private int DEFAULT_CROPWIDTH = 600;
    private static final int DEFAULT_CORNER_RADIUS = 6;
    private static final int DEFAULT_OVERLAY_COLOR = Color.argb(204, 41, 48, 63);
    private Paint mBackgroundPaint;
    private Paint mBorderPaint;
    private Paint mGuidelinePaint;
    private Path mClipPath;
    private RectF mBitmapRect;
    private int cropHeight = 400;
    private int cropWidth = 100;
    private boolean mGuidelines;
    private int mMarginTop;
    private int mMarginSide;
    private int mMinWidth;
    private int mMaxWidth;
    private int mCornerRadius;
    private int mOverlayColor;
    private Context mContext;
    public static int uWidth = 200;
    public static int uHeight = 200;

    public CropOverlayView(Context context) {
        super(context);
        init(context);
        mContext = context;
    }

    public CropOverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        TypedArray ta = context.obtainStyledAttributes(attrs,
                R.styleable.CropOverlayView, 0, 0);
        try {
            mGuidelines = ta.getBoolean(R.styleable.CropOverlayView_guideLines,
                    DEFAULT_GUIDELINES);
            mMarginTop = ta.getDimensionPixelSize(
                    R.styleable.CropOverlayView_marginTop, DEFAULT_MARGINTOP);
            mMarginSide = ta.getDimensionPixelSize(
                    R.styleable.CropOverlayView_marginSide, DEFAULT_MARGINSIDE);
            mMinWidth = ta.getDimensionPixelSize(
                    R.styleable.CropOverlayView_minWidth, DEFAULT_MIN_WIDTH);
            mMaxWidth = ta.getDimensionPixelSize(
                    R.styleable.CropOverlayView_maxWidth, DEFAULT_MAX_WIDTH);
            float defaultRadius = TypedValue.applyDimension(
                    1, 6.0F,
                    mContext.getResources().getDisplayMetrics());
            mCornerRadius = ta.getDimensionPixelSize(
                    R.styleable.CropOverlayView_cornerRadius,
                    (int) defaultRadius);
            mOverlayColor = ta.getColor(
                    R.styleable.CropOverlayView_overlayColor,
                    DEFAULT_OVERLAY_COLOR);
        } finally {
            ta.recycle();
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (mBitmapRect != null) {
            int saveCount = canvas.save();
            mBitmapRect.left = Edge.LEFT.getCoordinate();
            mBitmapRect.top = Edge.TOP.getCoordinate();
            mBitmapRect.right = Edge.RIGHT.getCoordinate();
            mBitmapRect.bottom = Edge.BOTTOM.getCoordinate();

            mClipPath.addRoundRect(mBitmapRect, mCornerRadius, mCornerRadius,
                    Direction.CW);
            canvas.clipPath(mClipPath, Op.DIFFERENCE);
            canvas.drawColor(mOverlayColor);
            mClipPath.reset();

            if (VERSION.SDK_INT < 23) {
                canvas.restore();
            }
            invalidate();

            canvas.drawRoundRect(mBitmapRect, mCornerRadius, mCornerRadius,
                    mBorderPaint);

            if (mGuidelines) {
                drawRuleOfThirdsGuidelines(canvas);
            }
        }
    }

    public Rect getImageBounds() {
        return new Rect((int) Edge.LEFT.getCoordinate(),
                (int) Edge.TOP.getCoordinate(),
                (int) Edge.RIGHT.getCoordinate(),
                (int) Edge.BOTTOM.getCoordinate());
    }

    public static void setHW(int h, int w) {
        uWidth = w;
        uHeight = h;
        Log.d("SSS", "setHW() uWidth = " + uWidth + " uHeight = " + uHeight);
    }

    public int getToolBarHeight(Context context) {
        int actionBarHeight = 48;

        TypedValue tv = new TypedValue();

        if (context.getTheme().resolveAttribute(16843499, tv, true)) {
            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data,
                    getResources().getDisplayMetrics());
        }

        return actionBarHeight;
    }

    public void init(Context context) {
        cropWidth = uWidth;
        cropHeight = uHeight;

        Log.d("SSS", "cropWidth = " + cropWidth + " cropHeight =" + cropHeight);
        Log.d("SSS", "uWidth = " + uWidth + " uHeight = " + uHeight);
        int w = context.getResources().getDisplayMetrics().widthPixels;
        int ScreenHalf = w / 2;
        int WindowHalf = cropWidth / 2;

        mMarginSide = (ScreenHalf - WindowHalf);

        int hh = context.getResources().getDisplayMetrics().heightPixels;
        ;
        int ScreenHalfHight = hh / 2;
        int WindowHalfHight = cropHeight / 2;
        mMarginTop = (ScreenHalfHight - WindowHalfHight);
        int toolbatH = getToolBarHeight(context);
        mMarginTop -= toolbatH;

        int edgeT = mMarginTop;
        int edgeB = mMarginTop + cropHeight;
        int edgeL = mMarginSide;
        int edgeR = mMarginSide + cropWidth;
        mBackgroundPaint = PaintUtil.newBackgroundPaint(context);
        mBorderPaint = PaintUtil.newBorderPaint(context);
        mGuidelinePaint = PaintUtil.newGuidelinePaint();
        Edge.TOP.setCoordinate(edgeT);
        Edge.BOTTOM.setCoordinate(edgeB);
        Edge.LEFT.setCoordinate(edgeL);
        Edge.RIGHT.setCoordinate(edgeR);
        mBitmapRect = new RectF(edgeL, edgeT, edgeR, edgeB);
        mClipPath = new Path();
    }

    private void drawRuleOfThirdsGuidelines(Canvas canvas) {
        float left = Edge.LEFT.getCoordinate();
        float top = Edge.TOP.getCoordinate();
        float right = Edge.RIGHT.getCoordinate();
        float bottom = Edge.BOTTOM.getCoordinate();
        float oneThirdCropWidth = Edge.getWidth() / 3.0F;
        float x1 = left + oneThirdCropWidth;
        canvas.drawLine(x1, top, x1, bottom, mGuidelinePaint);
        float x2 = right - oneThirdCropWidth;
        canvas.drawLine(x2, top, x2, bottom, mGuidelinePaint);


        float oneThirdCropHeight = Edge.getHeight() / 3.0F;

        float y1 = top + oneThirdCropHeight;
        canvas.drawLine(left, y1, right, y1, mGuidelinePaint);
        float y2 = bottom - oneThirdCropHeight;
        canvas.drawLine(left, y2, right, y2, mGuidelinePaint);
    }
}
