package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.Typeface;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;
import com.kotlinz.festivalstorymaker.texteditor.FontListAdapter.a;


public final class HDFontListener implements a {
    public final HighlightDetailsDetailActivity activity;

    public HDFontListener(HighlightDetailsDetailActivity highlightDetailsDetailActivity) {
        this.activity = highlightDetailsDetailActivity;
    }

    public final void B(Typeface typeface, int i) {
        this.activity.B(typeface, i);
    }
}
