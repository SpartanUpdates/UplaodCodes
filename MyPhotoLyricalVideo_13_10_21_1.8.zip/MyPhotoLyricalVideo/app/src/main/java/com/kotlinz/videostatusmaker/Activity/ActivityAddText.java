package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import com.larswerkman.holocolorpicker.ColorPicker;
import com.larswerkman.holocolorpicker.OpacityBar;
import com.larswerkman.holocolorpicker.SVBar;
import com.kotlinz.videostatusmaker.adapter.TextAdapter;

public class ActivityAddText extends Activity {
    ActivityAddText activity = ActivityAddText.this;
    private SVBar bar;
    TextView tvText;
    TextView tvTitle;
    ImageView linearlyAdd;
    ImageView ivBack;
    ImageView linearly_size;
    SeekBar sizeSeek;
    ImageView linearStyle;
    String[] styles;
    private OpacityBar opacityBar;
    int pickColor;
    private ColorPicker colorPicker;
    RelativeLayout rely_seek;
    ImageView LinearlyColor;
    TextView tvDone;
    boolean first;
    Typeface typeface;
    TextAdapter textAdapter;

    public ActivityAddText() {
        this.first = true;
        this.pickColor = -8323328;
    }

    void DialogColor() {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.pop_color);
        final LinearLayout linearLayout = dialog.findViewById(R.id.mainLay);
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.getResources().getDisplayMetrics().heightPixels;
        linearLayout.setLayoutParams(new RelativeLayout.LayoutParams(widthPixels * 900 / 1080, heightPixels * 1310 / 1920));
        final TextView textView = dialog.findViewById(R.id.title);
        final ImageView imageView = dialog.findViewById(R.id.cancel);
        final ImageView imageView2 = dialog.findViewById(R.id.ok);
        final ImageView imageView3 = dialog.findViewById(R.id.close);
        final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams(widthPixels * 310 / 1080, heightPixels * 100 / 1920);
        relativeLayout$LayoutParams.addRule(13);
        imageView.setLayoutParams(relativeLayout$LayoutParams);
        imageView2.setLayoutParams(relativeLayout$LayoutParams);
        textView.setTypeface(this.typeface);
        final int n = widthPixels * 40 / 1080;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 65 / 1080, heightPixels * 65 / 1920);
        layoutParams.addRule(15);
        layoutParams.addRule(11);
        layoutParams.setMargins(0, 0, n, 0);
        imageView3.setLayoutParams(layoutParams);
        this.colorPicker = dialog.findViewById(R.id.picker);
        this.bar = dialog.findViewById(R.id.svbar);
        this.opacityBar = dialog.findViewById(R.id.opacitybar);
        final LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(widthPixels * 650 / 1080, heightPixels * 650 / 1920);
        layoutParams2.gravity = 17;
        this.colorPicker.setLayoutParams(layoutParams2);
        this.colorPicker.addSVBar(this.bar);
        this.colorPicker.addOpacityBar(this.opacityBar);
        this.colorPicker.setOldCenterColor(this.pickColor);
        this.colorPicker.setColor(this.pickColor);
        this.bar.setColor(this.pickColor);
        this.opacityBar.setColor(this.pickColor);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                dialog.dismiss();
            }
        });
        imageView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityAddText.this.pickColor = ActivityAddText.this.colorPicker.getColor();
                ActivityAddText.this.tvText.setTextColor(ActivityAddText.this.pickColor);
                dialog.dismiss();
            }
        });
        imageView3.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    void dialog() {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.custom_dialog);
        final LinearLayout linearLayout = dialog.findViewById(R.id.mainLay);
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.getResources().getDisplayMetrics().heightPixels;
        linearLayout.setLayoutParams(new RelativeLayout.LayoutParams(widthPixels * 842 / 1080, heightPixels * 579 / 1920));
        final TextView textView = dialog.findViewById(R.id.title);
        dialog.getWindow().setSoftInputMode(5);
        final ImageView imageView = dialog.findViewById(R.id.cancel);
        final ImageView imageView2 = dialog.findViewById(R.id.submit);
        final ImageView imageView3 = dialog.findViewById(R.id.close);
        final EditText editText = dialog.findViewById(R.id.entertext);
        final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams(widthPixels * 310 / 1080, heightPixels * 100 / 1920);
        relativeLayout$LayoutParams.addRule(13);
        imageView.setLayoutParams(relativeLayout$LayoutParams);
        imageView2.setLayoutParams(relativeLayout$LayoutParams);
        textView.setTypeface(this.typeface);
        editText.setTypeface(this.typeface);
        final int n = widthPixels * 40 / 1080;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 65 / 1080, heightPixels * 65 / 1920);
        layoutParams.addRule(15);
        layoutParams.addRule(11);
        layoutParams.setMargins(0, 0, n, 0);
        imageView3.setLayoutParams(layoutParams);
        editText.setText(this.tvText.getText());
        editText.setSelection(editText.getText().length());
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (ActivityAddText.this.first) {
                    ActivityAddText.this.onBackPressed();
                }
                dialog.dismiss();
            }
        });
        imageView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                final String string = editText.getText().toString();
                if (string.equals("")) {
                    editText.setError("Enter Text");
                    return;
                }
                ActivityAddText.this.first = false;
                ActivityAddText.this.tvText.setText(string);
                dialog.dismiss();
            }
        });
        imageView3.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_addtext);
        this.getWindow().addFlags(1024);
        this.rely_seek = findViewById(R.id.seek_lay);
        (this.ivBack = this.findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.interstitialAd != null && MyApplication.interstitialAd.isAdLoaded()) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 7;
                        MyApplication.interstitialAd.show();
                        MyApplication.isShowAd = 1;
                    } else {
                        onBackPressed();
                    }
                }
            }
        });
        PutAnalyticsEvent();
        bindview();
        init();
        this.setLayout();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityAddText");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void init() {
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        (this.sizeSeek = this.findViewById(R.id.size_seek)).setMax(100);
        this.sizeSeek.setProgress(40);
        this.tvText.setTextSize(50.0f);
        this.sizeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
                ActivityAddText.this.tvText.setTextSize((float) (n + 10));
            }

            public void onStartTrackingTouch(final SeekBar seekBar) {
            }

            public void onStopTrackingTouch(final SeekBar seekBar) {
            }
        });
        this.linearly_size.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (ActivityAddText.this.rely_seek.getVisibility() == View.GONE) {
                    ActivityAddText.this.rely_seek.setVisibility(View.VISIBLE);
                    return;
                }
                ActivityAddText.this.rely_seek.setVisibility(View.GONE);
            }
        });
        this.dialog();
        try {
            this.styles = this.getResources().getAssets().list("fonts");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.textAdapter = new TextAdapter(this.getApplicationContext(), this.styles);
        this.tvText.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityAddText.this.dialog();
                ActivityAddText.this.rely_seek.setVisibility(View.GONE);
            }
        });
        this.linearlyAdd.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityAddText.this.dialog();
                ActivityAddText.this.rely_seek.setVisibility(View.GONE);
            }
        });
        this.tvDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (MyApplication.isShowAd == 1) {
                    GoToNext();
                    setResult(-1);
                    finish();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.interstitialAd != null && MyApplication.interstitialAd.isAdLoaded()) {
                        MyApplication.activity = activity;
                        GoToNext();
                        MyApplication.AdsId = 6;
                        MyApplication.interstitialAd.show();
                        MyApplication.isShowAd = 1;
                    } else {
                        GoToNext();
                        setResult(-1);
                        finish();
                    }
                }
            }
        });
        this.linearStyle.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityAddText.this.sel_text_dialog();
                ActivityAddText.this.rely_seek.setVisibility(View.GONE);
            }
        });
        this.LinearlyColor.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityAddText.this.DialogColor();
                ActivityAddText.this.rely_seek.setVisibility(View.GONE);
            }
        });
    }

    private void GoToNext() {
        final int height = ActivityAddText.this.tvText.getHeight();
        final int width = ActivityAddText.this.tvText.getWidth();
        ActivityAddText.this.tvText.setBackgroundColor(0);
        final Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        final Canvas canvas = new Canvas(bitmap);
        ActivityAddText.this.tvText.layout(0, 0, width, height);
        ActivityAddText.this.tvText.draw(canvas);
        ActivityEditImage.birmapSticker = bitmap;
    }

    private void bindview() {

        this.tvDone = findViewById(R.id.done);
        this.linearStyle = findViewById(R.id.style);
        this.LinearlyColor = findViewById(R.id.color);
        this.linearlyAdd = findViewById(R.id.add);
        this.linearly_size = findViewById(R.id.size);
        this.tvTitle = findViewById(R.id.title);
        this.tvText = findViewById(R.id.text);

    }

    void sel_text_dialog() {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.activity_select_text);
        final LinearLayout linearLayout = dialog.findViewById(R.id.mainLay);
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.getResources().getDisplayMetrics().heightPixels;
        linearLayout.setLayoutParams(new RelativeLayout.LayoutParams(widthPixels * 900 / 1080, heightPixels * 1310 / 1920));
        ((TextView) dialog.findViewById(R.id.title)).setTypeface(this.typeface);
        final ImageView imageView = dialog.findViewById(R.id.close);
        final int n = widthPixels * 40 / 1080;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 65 / 1080, heightPixels * 65 / 1920);
        layoutParams.addRule(15);
        layoutParams.addRule(11);
        layoutParams.setMargins(0, 0, n, 0);
        imageView.setLayoutParams(layoutParams);
        final GridView gridView = dialog.findViewById(R.id.stylelist);
        gridView.setAdapter(this.textAdapter);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                final TextView text = ActivityAddText.this.tvText;
                final AssetManager assets = ActivityAddText.this.getAssets();
                final StringBuilder sb = new StringBuilder();
                sb.append("fonts/");
                sb.append(ActivityAddText.this.styles[n]);
                text.setTypeface(Typeface.createFromAsset(assets, sb.toString()));
                dialog.dismiss();
            }
        });
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    void setLayout() {
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.getResources().getDisplayMetrics().heightPixels;
        final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams(widthPixels * 100 / 1080, heightPixels * 100 / 1920);
        relativeLayout$LayoutParams.addRule(13);
        final int n = widthPixels * 200 / 1080;
        final int n2 = heightPixels * 170 / 1920;
        final RelativeLayout.LayoutParams relativeLayout$LayoutParams2 = new RelativeLayout.LayoutParams(n, n2);
        relativeLayout$LayoutParams2.addRule(13);
        this.linearlyAdd.setLayoutParams(relativeLayout$LayoutParams2);
        this.LinearlyColor.setLayoutParams(relativeLayout$LayoutParams2);
        this.linearly_size.setLayoutParams(relativeLayout$LayoutParams2);
        this.linearStyle.setLayoutParams(relativeLayout$LayoutParams2);
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, n2);
        layoutParams.addRule(12);
        layoutParams.setMargins(0, 0, 0, heightPixels * 20 / 1920);
        this.rely_seek.setLayoutParams(layoutParams);
        final Bitmap decodeResource = BitmapFactory.decodeResource(this.getResources(), R.drawable.thumb);
        this.sizeSeek.setThumb(new BitmapDrawable(this.getResources(), Bitmap.createScaledBitmap(decodeResource, widthPixels * decodeResource.getWidth() / 1080, heightPixels * decodeResource.getHeight() / 1920, true)));
    }

}
