package com.unikapp.faceappeditor.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.unikapp.faceappeditor.Utils.Effect;
import com.unikapp.faceage.editorapp.R;

import java.util.ArrayList;

public class Adapter_Effects extends BaseAdapter {
	private ArrayList<Integer> effectList = new ArrayList();
	private Context context;

	static class Viewholder {
		ImageView imageView;
		Viewholder() {
		}
	}

	public Adapter_Effects(Context c, ArrayList<Integer> effect) {
		this.context = c;
		this.effectList = effect;
	}

	public int getCount() {
		return this.effectList.size();
	}

	public Object getItem(int i) {
		return null;
	}

	public long getItemId(int i) {
		return 0;
	}

	public View getView(int position, View convertView, ViewGroup viewGroup) {
		Viewholder holder;
		View row = convertView;
		if (row == null) {
			row = LayoutInflater.from(this.context).inflate(
					R.layout.effect, viewGroup, false);
			holder = new Viewholder();
			holder.imageView = (ImageView) row.findViewById(R.id.img);
			row.setTag(holder);
		} else {
			holder = (Viewholder) row.getTag();
		}
		holder.imageView.setImageResource(((Integer) this.effectList
				.get(position)).intValue());
		if (position == 0) {
			Effect.applyEffectNone(holder.imageView);
		}
		if (position == 1) {
			Effect.applyEffect1(holder.imageView);
		}
		if (position == 2) {
			Effect.applyEffect2(holder.imageView);
		}
		if (position == 3) {
			Effect.applyEffect4(holder.imageView);
		}
		if (position == 4) {
			Effect.applyEffect5(holder.imageView);
		}
		if (position == 5) {
			Effect.applyEffect6(holder.imageView);
		}
		if (position == 6) {
			Effect.applyEffect7(holder.imageView);
		}
		if (position == 7) {
			Effect.applyEffect9(holder.imageView);
		}
		if (position == 8) {
			Effect.applyEffect11(holder.imageView);
		}
		if (position == 9) {
			Effect.applyEffect12(holder.imageView);
		}
		if (position == 10) {
			Effect.applyEffect14(holder.imageView);
		}
		if (position == 11) {
			Effect.applyEffect15(holder.imageView);
		}
		if (position == 12) {
			Effect.applyEffect16(holder.imageView);
		}
		if (position == 13) {
			Effect.applyEffect17(holder.imageView);
		}
		if (position == 14) {
			Effect.applyEffect18(holder.imageView);
		}
		if (position == 15) {
			Effect.applyEffect19(holder.imageView);
		}
		if (position == 16) {
			Effect.applyEffect20(holder.imageView);
		}
		if (position == 17) {
			Effect.applyEffect21(holder.imageView);
		}
		if (position == 18) {
			Effect.applyEffect22(holder.imageView);
		}
		return row;
	}
}
