package com.xyz.vehiclemanager.cardetails.carservice.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.cardetails.carservice.activity.CarServiceSelectStateActivity;
import com.xyz.vehiclemanager.model.CarBrands;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CarBrandServiceAdapter extends RecyclerView.Adapter<CarBrandServiceAdapter.MyViewHolder> {

    private Context mcontext;
    private ArrayList<CarBrands> carBrandslist;

    public CarBrandServiceAdapter(Context context, ArrayList<CarBrands> carBrandslist) {
        this.mcontext = context;
        this.carBrandslist = carBrandslist;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_carbrandsname;
        ImageView iv_carbrands;
        LinearLayout ll_carbrand;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_carbrandsname = itemView.findViewById(R.id.tv_carbrandsname);
            iv_carbrands = itemView.findViewById(R.id.iv_carbrands);
            ll_carbrand = itemView.findViewById(R.id.ll_carbrand);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_carbrads,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        final CarBrands carServiceBrands = carBrandslist.get(position);
        holder.tv_carbrandsname.setText(carServiceBrands.getBrandName());

        Glide.with(mcontext)
                .load(carServiceBrands.getImageUrl())
                .placeholder(R.drawable.ic_car)
                .into(holder.iv_carbrands);

        final String brandid = carServiceBrands.getId();

        holder.ll_carbrand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println(brandid);
                Intent intent = new Intent(mcontext, CarServiceSelectStateActivity.class);
                intent.putExtra("brandId",brandid);
                mcontext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return carBrandslist.size();
    }
}
