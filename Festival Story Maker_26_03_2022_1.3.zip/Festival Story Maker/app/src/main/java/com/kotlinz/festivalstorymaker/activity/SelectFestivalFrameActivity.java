package com.kotlinz.festivalstorymaker.activity;

import androidx.recyclerview.widget.RecyclerView;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.kotlinz.festivalstorymaker.Adapter.SelectLogoAdapter;
import com.kotlinz.festivalstorymaker.Other.AppConstant;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ReturnMode;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Collections;
import java.util.List;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SelectFestivalFrameActivity extends BaseActivity implements SelectLogoAdapter.LogoInterface {

    public SelectLogoAdapter R;
    public List<String> S;
    public boolean T = false;
    public SelectLogoAdapter.LogoInterface selectLogoListener;
    public boolean V;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgBlur)
    public ImageView imgBlur;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listLogo)
    public RecyclerView listLogo;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llMain)
    public LinearLayout llMain;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rlList)
    public RelativeLayout rlList;
    @BindView(com.kotlinz.festivalstorymaker.R.id.txtMessage)
    public TextView txtMessage;


    public class b extends AsyncTask<Void, Void, Void> {

        public b(a aVar) {

        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            rlList.setVisibility(S.size() > 0 ? View.VISIBLE : View.GONE);
            R = new SelectLogoAdapter(activity, S, selectLogoListener);
            listLogo.setAdapter(R);
            SelectFestivalFrameActivity.this.llMain.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            Void[] voidArr = (Void[]) voids;
            SelectFestivalFrameActivity selectFestivalFrameActivity = SelectFestivalFrameActivity.this;
            selectFestivalFrameActivity.S = Utils.u(selectFestivalFrameActivity);
            selectFestivalFrameActivity = SelectFestivalFrameActivity.this;
            selectFestivalFrameActivity.T = selectFestivalFrameActivity.S.size() == 0;
            return null;
        }

        public void onPreExecute() {
            super.onPreExecute();
        }
    }


    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 160) {
            if (intent != null) {
                try {
                    String[] strArr = new String[]{"_data"};
                    Cursor query = getContentResolver().query(intent.getData(), strArr, null, null, null);
                    query.moveToFirst();
                    String string = query.getString(query.getColumnIndex(strArr[0]));
                    query.close();
                    v0(new File(string), Utils.o0());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else if (ImagePicker.shouldHandle(i, i2, intent)) {
            v0(new File(ImagePicker.getFirstImageOrNull(intent).path), Utils.o0());
        } else if (i2 == 90 && intent != null && intent.getBooleanExtra("isRefresh", false)) {
            new b(null).execute(new Void[0]);
        }
    }

    @OnClick({com.kotlinz.festivalstorymaker.R.id.imgBlur, com.kotlinz.festivalstorymaker.R.id.llMain, com.kotlinz.festivalstorymaker.R.id.rlList, com.kotlinz.festivalstorymaker.R.id.imgFolderLogo, com.kotlinz.festivalstorymaker.R.id.imgSelecteLogo})
    public void onClick(View view) {
        Intent intent;
        int i;
        switch (view.getId()) {
            case com.kotlinz.festivalstorymaker.R.id.imgBlur:
            case com.kotlinz.festivalstorymaker.R.id.llMain:
            case com.kotlinz.festivalstorymaker.R.id.rlList:
                finish();
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgFolderLogo:
                intent = new Intent("android.intent.action.PICK");
                intent.setType("image/*");
                intent.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/jpeg", "image/png"});
                i = 160;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgSelecteLogo:
                final ImagePicker.ImagePickerWithActivity a = new ImagePicker.ImagePickerWithActivity(this);
                final ReturnMode f = ReturnMode.GALLERY_ONLY;
                final ImagePickerConfig a2 = a.config;
                a2.returnMode = f;
                a2.folderMode = true;
                a2.folderTitle = "Folder";
                a2.imageTitle = "Tap to select";
                a2.arrowColor = -16777216;
                a.single();
                a.showCamera(a.config.showCamera = false);
                a.start();
                return;
            default:
                return;
        }
        startActivityForResult(intent, i);
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.kotlinz.festivalstorymaker.R.layout.select_logo_dialog);
        ButterKnife.bind(this);
        this.V = getIntent().getBooleanExtra("fromHome", false);
        byte[] byteArrayExtra = getIntent().getByteArrayExtra("image");
        if (byteArrayExtra != null) {
            this.imgBlur.setImageBitmap(BitmapFactory.decodeByteArray(byteArrayExtra, 0, byteArrayExtra.length));
        }
        this.txtMessage.setText(getResources().getString(com.kotlinz.festivalstorymaker.R.string.select_frame_from));
        this.selectLogoListener = this;
        new b(null).execute(new Void[0]);

    }

    public void u0(List<String> list) {
        Context applicationContext = getApplicationContext();
        String str = AppConstant.k0;
        getApplicationContext();
        int i = 0;
        SharedPreferences.Editor edit = applicationContext.getSharedPreferences("Festival_Frame_list", 0).edit();
        edit.putString("FestivalFrames", new Gson().toJson(list));
        edit.apply();
        RelativeLayout relativeLayout = this.rlList;
        if (this.S.size() <= 0) {
            i = 8;
        }
        relativeLayout.setVisibility(i);
    }

    public void v0(File file, File file2) {
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            byte[] bArr = new byte[1024];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read <= 0) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            fileInputStream.close();
            fileOutputStream.close();
            this.S.add(file2.getPath());
            u0(this.S);
            this.R.notifyDataSetChanged();
            if (this.T && !this.V) {
                String str = (String) this.S.get(0);
                Intent intent = new Intent();
                intent.putExtra("path", str);
                int i = AppConstant.c0;
                setResult(7024, intent);
                finish();
            }
            if (this.V) {
                Intent intent2 = new Intent();
                int i2 = AppConstant.c0;
                setResult(7024, intent2);
                finish();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void K(String p0, boolean p1) {
        if (p1) {
            new File(p0).delete();
            this.S.remove(p0);
            u0(this.S);
            this.R.notifyDataSetChanged();
            return;
        }
        Intent intent = new Intent();
        intent.putExtra("path", p0);
        int i = AppConstant.c0;
        setResult(7024, intent);
        finish();
    }

    @Override
    public void u(int p0, int p1) {
        Collections.swap(this.S, p0, p1);
        u0(this.S);
        this.R.notifyDataSetChanged();
    }
}