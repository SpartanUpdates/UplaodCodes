package com.xyz.vehiclemanager.car.CarVarianDetails.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.model.Item;

import java.util.ArrayList;

public class CarFeaturesAttrAdapter extends RecyclerView.Adapter<CarFeaturesAttrAdapter.ViewHolder> {
    Context context;
    ArrayList<Item> itemlist;

    public CarFeaturesAttrAdapter(Context context, ArrayList<Item> itemlist) {
        this.context = context;
        this.itemlist = itemlist;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView attrName,attrValue;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            attrName=itemView.findViewById(R.id.tv_attrName);
            attrValue=itemView.findViewById(R.id.tv_attrValue);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_attrskey,parent,false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
      Item  item = itemlist.get(position);
      holder.attrName.setText(item.getAttrName());
      holder.attrValue.setText(item.getAttrValue());
    }
    @Override
    public int getItemCount() {
        return itemlist.size();
    }
}
