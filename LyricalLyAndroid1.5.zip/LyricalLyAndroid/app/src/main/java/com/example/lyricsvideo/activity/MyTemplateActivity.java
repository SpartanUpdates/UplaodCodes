package com.example.lyricsvideo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.lyricsvideo.Adapter.MyTemplateAdapter;
import com.example.lyricsvideo.Model.MytemplateModel;
import com.example.lyricsvideo.Database.DatabaseHelper;
import com.example.lyricsvideo.R;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.ArrayList;
import java.util.List;

public class MyTemplateActivity extends AppCompatActivity {

    Activity activity = MyTemplateActivity.this;
    DatabaseHelper database;
    RecyclerView rvMyTemplate;
    LinearLayout llNoTemplate;
    ImageView ivBack;
    MyTemplateAdapter templateAdapter;
    List<MytemplateModel> mytemplateList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_template);
        mytemplateList = new ArrayList<>();
        ivBack=findViewById(R.id.ivBack);
        llNoTemplate=findViewById(R.id.ll_no_template);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MyTemplateActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        rvMyTemplate = findViewById(R.id.rv_my_template);
        database = new DatabaseHelper(activity);
        mytemplateList = database.getdata();
        templateAdapter = new MyTemplateAdapter(activity, mytemplateList);
        StaggeredGridLayoutManager gridLayoutManager = new StaggeredGridLayoutManager(1, 1);
        rvMyTemplate.setLayoutManager(gridLayoutManager);
        rvMyTemplate.setAdapter(templateAdapter);
        if (mytemplateList.size() > 0) {
            llNoTemplate.setVisibility(View.GONE);
        } else {
            llNoTemplate.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(activity, MainActivity.class));
        finish();
    }
}
