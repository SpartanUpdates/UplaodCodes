package com.example.womenabsworkout.utils;

import java.util.ArrayList;

public class Constants {
    public static String APP_BANNER_URL = "app_banner_url";
    public static String APP_PACKAGE_NAME = "app_package_name";
    public static ArrayList<Integer> DayFixed = new ArrayList();
    public static String FCM_CROSS_PROMO_PREF = "fcm_cross_promo_pref";
    public static String KEY_PROGRESS = "Progress";
    public static long READY_TO_GO_TIMT = 10;
    public static int REST_TIME = 30;
    public static int TOTAL_DAYS = 30;
    public static boolean adOfTheDay = false;
    public static boolean tipOfTheDay = false;

    public static int Position=-1;
}
