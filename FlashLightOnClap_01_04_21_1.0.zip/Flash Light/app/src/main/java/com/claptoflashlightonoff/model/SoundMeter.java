package com.claptoflashlightonoff.model;

import java.io.IOException;

import android.media.MediaRecorder;

public class SoundMeter {
    private double mEMA;
    private MediaRecorder mRecorder;

    public SoundMeter() {
        super();
        this.mRecorder = null;
        this.mEMA = 0.0;
    }

    public double getAmplitude() {
        if (this.mRecorder != null) {
            return this.mRecorder.getMaxAmplitude() / 2700.0;
        }
        return 0.0;
    }

    public void start() {
        if (this.mRecorder != null) {
            return;
        }
        (this.mRecorder = new MediaRecorder()).setAudioSource(MediaRecorder.AudioSource.MIC);
        this.mRecorder.setOutputFormat(1);
        this.mRecorder.setAudioEncoder(1);
        this.mRecorder.setOutputFile("/dev/null");
        while (true) {
            try {
                this.mRecorder.prepare();
                this.mRecorder.start();
                this.mEMA = 0.0;
            } catch (IllegalStateException ex) {
                ex.printStackTrace();
                continue;
            } catch (IOException ex2) {
                ex2.printStackTrace();
                continue;
            }
            break;
        }
    }

    public void stop() {
        if (this.mRecorder != null) {
            this.mRecorder.stop();
            this.mRecorder.release();
            this.mRecorder = null;
        }
    }
}
