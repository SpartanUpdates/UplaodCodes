package com.vidsoft.videostatusmaker.Others.fragment;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import androidx.annotation.Nullable;
import com.google.android.material.snackbar.Snackbar;
import androidx.fragment.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Locale;

import com.vidsoft.videostatusmaker.Activity.ActivitySelectLyrics;
import com.vidsoft.videostatusmaker.adapter.LyricstextAdapter;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class Sad_Fragment
        extends Fragment {
    LyricstextAdapter lyricstextAdapter;
    Context context;
    ListView lyricList;
    int pos;
    EditText etSearch;
    Snackbar snackbar;
    ArrayList<String> ArrayListSongs = new ArrayList<>();
    ArrayList<String> ArrayListSongsLyrics = new ArrayList<>();

    private boolean isNetworkAvailable() {
        final NetworkInfo activeNetworkInfo = ((ConnectivityManager) this.getActivity().getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    String getVideoList() {
        final OkHttpClient okHttpClient = new OkHttpClient();
        final Request build = new Request.Builder().url("https://raw.githubusercontent.com/VidSoft/MyPhotoLyricalSongs/master/Sad/Sad.json").build();
        try {
            final Response execute = okHttpClient.newCall(build).execute();
            if (execute.isSuccessful()) {
                return execute.body().string();
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("Unexpected code ");
            sb.append(execute);
            throw new IOException(sb.toString());
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflate, @Nullable final ViewGroup viewGroup, @Nullable final Bundle bundle) {
        View inflateLayout = inflate.inflate(R.layout.song_list_fragment, viewGroup, false);
        this.lyricList = (ListView) ((View) inflateLayout).findViewById(R.id.lyric_list);
        this.etSearch = (EditText) ((View) inflateLayout).findViewById(R.id.search);
        this.ArrayListSongsLyrics.clear();
        this.ArrayListSongs.clear();
        try {
            this.lyricstextAdapter = new LyricstextAdapter((Context) this.getActivity(), this.ArrayListSongsLyrics);
            this.lyricList.setAdapter((ListAdapter) this.lyricstextAdapter);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.etSearch.addTextChangedListener((TextWatcher) new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
                Sad_Fragment.this.lyricstextAdapter.filter(Sad_Fragment.this.etSearch.getText().toString().toLowerCase(Locale.getDefault()));
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }
        });
        this.lyricList.setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int pos, final long n) {
                Sad_Fragment.this.lyricList.setEnabled(false);
                Sad_Fragment.this.pos = pos;
                if (Sad_Fragment.this.snackbar != null) {
                    Sad_Fragment.this.snackbar.dismiss();
                }
                ActivitySelectLyrics.progressDialog.setMessage((CharSequence) "Downloading...");
                final StringBuilder sb = new StringBuilder();
                sb.append(Environment.getExternalStorageDirectory());
                sb.append("/");
                sb.append(Sad_Fragment.this.getResources().getString(R.string.app_name));
                final String string = sb.toString();
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append("/");
                sb2.append(Sad_Fragment.this.getString(R.string.temp_folder));
                sb2.append("/mysong.mp3");
                ActivitySelectLyrics.strMusicPath = sb2.toString();
                Log.e("CALL", "111=====" + ActivitySelectLyrics.strMusicPath);
                final StringBuilder sb3 = new StringBuilder();
                sb3.append(string);
                sb3.append("/");
                sb3.append(Sad_Fragment.this.getString(R.string.temp_folder));
                sb3.append("/mytxt.txt");
                ActivitySelectLyrics.StrTxt_path = sb3.toString();
                final StringBuilder sb4 = new StringBuilder();
                sb4.append(string);
                sb4.append("/");
                sb4.append(Sad_Fragment.this.getString(R.string.temp_folder));
                new File(sb4.toString()).mkdir();
                int i = 0;
                int n2 = 0;
                while (i < Sad_Fragment.this.ArrayListSongs.size()) {
                    if (Sad_Fragment.this.ArrayListSongs.get(i).contains(Sad_Fragment.this.ArrayListSongsLyrics.get(pos))) {
                        n2 = i;
                    }
                    ++i;
                }
                final String s = Sad_Fragment.this.ArrayListSongs.get(n2);
                final StringBuilder sb5 = new StringBuilder();
                sb5.append("");
                final String string2 = sb5.toString();
                final StringBuilder sb6 = new StringBuilder();
                sb6.append("");
                final String replace = s.replace(string2, sb6.toString()).replace(".mp3", ".txt");
                if (Sad_Fragment.this.isNetworkAvailable()) {
                    new LayricsDownloader().execute(new String[]{replace, ActivitySelectLyrics.StrTxt_path});
                    new songDownloader().execute(new String[]{Sad_Fragment.this.ArrayListSongs.get(n2), ActivitySelectLyrics.strMusicPath});
                    return;
                }
                final Snackbar setAction = Snackbar.make((View) ActivitySelectLyrics.relativeLayout, "No Internet Connection", -2).setAction("Retry", (View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view) {
                    }
                });
                setAction.setActionTextColor(-65536);
                setAction.show();
                Sad_Fragment.this.snackbar = setAction;
            }
        });
        this.context = (Context) this.getActivity();
        if (this.isNetworkAvailable()) {
            new OkHttpAync().execute();
            return (View) inflateLayout;
        }
        return (View) inflateLayout;
    }

    class songDownloader extends AsyncTask<String, Long, Boolean> {
        private File file;

        protected Boolean doInBackground(final String... strArr) {
            long contentLength;
            long j;
            try {
                URL url = new URL(strArr[0]);
                URLConnection openConnection = url.openConnection();
                openConnection.connect();
                contentLength = (long) openConnection.getContentLength();
                try {
                    OutputStream fileOutputStream;
                    OkHttpClient okHttpClient = new OkHttpClient();
                    Request.Builder builder = new Request.Builder();
                    ResponseBody body = okHttpClient.newCall(builder.url(url).build()).execute().body();
                    body.source();
                    BufferedInputStream bufferedInputStream = new BufferedInputStream(body.byteStream());
                    this.file = new File(strArr[1]);
                    fileOutputStream = new FileOutputStream(this.file);
                    long contentLength2 = body.contentLength();
                    byte[] bArr = new byte[1024];
                    long j2 = 0;
                    while (true) {
                        int read = bufferedInputStream.read(bArr);
                        if (read == -1) {
                            break;
                        }
                        j = contentLength;
                        long j3 = j2 + ((long) read);
                        try {
                            fileOutputStream.write(bArr, 0, read);
                            contentLength = j;
                            j2 = j3;
                        } catch (Exception e3) {
                            contentLength = j;
                        }
                    }
                    j = contentLength;
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    bufferedInputStream.close();
                } catch (Exception e4) {
                    Exception e3 = e4;
                }
            } catch (Exception e32) {
            }
            return false;
        }

        protected void onPostExecute(final Boolean b) {
            super.onPostExecute(b);
            ActivitySelectLyrics.progressDialog.dismiss();
            if (this.file != null && this.file.exists()) {
                ActivitySelectLyrics.play_popup(Sad_Fragment.this.ArrayListSongsLyrics.get(Sad_Fragment.this.pos));
            }
            Sad_Fragment.this.lyricList.setEnabled(true);
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ActivitySelectLyrics.progressDialog.show();
        }
    }

    private class OkHttpAync extends AsyncTask<Object, Void, String> {
        protected String doInBackground(Object... objArr) {
            Sad_Fragment Sad_Fragment = Sad_Fragment.this;
            return Sad_Fragment.getVideoList();
        }


        protected void onPostExecute(final String s) {
            super.onPostExecute(s);
            if (s != null) {
                try {
                    final JSONObject jsonObject = new JSONObject(s).getJSONObject("data");
                    final ArrayList<String> list = new ArrayList<String>();
                    if (jsonObject != null) {
                        final JSONArray jsonArray = jsonObject.getJSONArray("posts");
                        for (int i = 0; i < jsonArray.length(); ++i) {
                            final JSONObject jsonObject2 = jsonArray.getJSONObject(i);
                            final String string = jsonObject2.getString("file_name");
                            jsonObject2.getString("filesize");
                            final String substring = string.substring(string.lastIndexOf("/") + 1, string.lastIndexOf("."));
                            Sad_Fragment.this.ArrayListSongsLyrics.add(substring);
                            list.add(substring);
                            Sad_Fragment.this.ArrayListSongs.add(string);
                        }
                        Sad_Fragment.this.lyricstextAdapter.addITEMS(list);
                        Sad_Fragment.this.lyricstextAdapter.notifyDataSetChanged();
                        return;
                    }
                    Snackbar.make((View) ActivitySelectLyrics.relativeLayout, "Network Error", -1).show();
                    return;
                } catch (JSONException ex) {
                }
            }
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }
    }

    class LayricsDownloader extends AsyncTask<String, Long, Boolean> {
        private File mediaFile;

        protected Boolean doInBackground(final String... strArr) {
            long contentLength;
            long j;
            Log.e("TextPath", "" + strArr[1]);
            try {
                URL url = new URL(strArr[0]);
                URLConnection openConnection = url.openConnection();
                openConnection.connect();
                contentLength = (long) openConnection.getContentLength();
                try {
                    OutputStream fileOutputStream;
                    OkHttpClient okHttpClient = new OkHttpClient();
                    Request.Builder builder = new Request.Builder();
                    ResponseBody body = okHttpClient.newCall(builder.url(url).build()).execute().body();
                    body.source();
                    BufferedInputStream bufferedInputStream = new BufferedInputStream(body.byteStream());
                    this.mediaFile = new File(strArr[1]);
                    fileOutputStream = new FileOutputStream(this.mediaFile);
                    long contentLength2 = body.contentLength();
                    byte[] bArr = new byte[1024];
                    long j2 = 0;
                    while (true) {
                        int read = bufferedInputStream.read(bArr);
                        if (read == -1) {
                            break;
                        }
                        j = contentLength;
                        long j3 = j2 + ((long) read);
                        try {
                            fileOutputStream.write(bArr, 0, read);
                            contentLength = j;
                            j2 = j3;
                        } catch (Exception e3) {
                            contentLength = j;
                        }
                    }
                    j = contentLength;
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    bufferedInputStream.close();
                } catch (Exception e4) {
                    Exception e3 = e4;
                }
            } catch (Exception e32) {
            }
            return false;
        }

        protected void onPostExecute(final Boolean b) {
            super.onPostExecute(b);
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }
    }
}

