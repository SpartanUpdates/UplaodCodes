package com.MV.Lyrics.VideoPlay.activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.TrackInfo;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings.SettingNotFoundException;
import android.provider.Settings.System;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.FileProvider;

import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.MyStudio.activity.YourVideoActivity;
import com.MV.Lyrics.R;
import com.MV.Lyrics.SelectImage.Model.VideoModel;
import com.MV.Lyrics.VideoPlay.View.GestureDetection;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.h6ah4i.android.widget.verticalseekbar.VerticalSeekBar;
import com.root.UnitySendValue.AndroidUnityCall;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class VideoPlayActivity extends Activity implements GestureDetection.SimpleGestureListener {

    Activity activity = VideoPlayActivity.this;
    private static final int DRAW_OVER_OTHER_APP_PERMISSION = 2084;
    public int oneTimeOnly;
    public int vari;
    List<Integer> audioTracksIndexes;
    List<String> audioTracksList;
    public VerticalSeekBar brightbar;
    private int brightness;
    private ContentResolver cResolver;
    Context context;
    int count;
    int currentPosition;
    TextView current_position;
    public Handler durationHandler = new Handler();
    String VideoDuration;
    TextView tvEndTime;
    Bundle extras;
    boolean f3097aa = true;
    private String filename;
    public double finalTime = 0.0d;
    ImageView forward_btn;
    private GestureDetector gestureDetector;

    ImageView hundred_screensize;
    ImageView imgBright;
    ImageView imgSound;
    boolean isPlaying = false;
    ImageView ivg;
    ImageButton land;
    Long lastSeekUpdateTime = null;
    Long lastVolumeUpdateTime = null;
    LinearLayout laylock;
    SeekBar left_press;
    ImageView ivUnlock;
    boolean lock_click = false;
    ImageView ivLock;
    public AudioManager mAudioManager;
    private Activity mContext;
    private float mCurBrightness = -1.0f;
    private int mCurVolume = -1;
    Handler mHandlerss;
    private boolean mIsScrolling = false;
    public int mMaxVolume;
    MediaPlayer mediaPlayer;
    View MusicBottomPanel;
    ImageView pause_btn;
    ImageView play_btn;
    ImageButton playbutton;
    ImageButton portrat;
    int VideoCurrentPosition;
    ImageView rewind_btn;
    SeekBar right_press;
    TextView screen_sizes;
    TextView scroll_position;
    public SeekBar seekbar;
    SeekBar seekbar_vplay;
    int selectedAudioTrack;

    ArrayList<VideoModel> AllVideolist;
    public static boolean IsFromAndroidlist;

    ImageView size_screen;
    ImageView size_screenback;
    int stopPosition = -1;
    TextView textbrightness;
    TextView textvolume;
    public double timeElapsed = 0.0d;
    private String videoDisplayName;
    private int video_column_index;
    View video_header_controls;
    TextView VideoTitle;
    VideoView videoview;
    public VerticalSeekBar volumebar;
    private Window window;
    ImageView ivback;
    ImageView ivShare;
    public Runnable hideScreenControllsRunnable = new Runnable() {
        public void run() {
            if (MusicBottomPanel.getVisibility() == View.VISIBLE) {
                MusicBottomPanel.setVisibility(View.GONE);
            }
            if (video_header_controls.getVisibility() == View.VISIBLE) {
                video_header_controls.setVisibility(View.GONE);
            }
            vari = 1;
            MusicBottomPanel.removeCallbacks(hideScreenControllsRunnable);
        }
    };
    public Runnable horizontalScrollRunnable = new Runnable() {
        public void run() {
            if (Long.valueOf(SystemClock.uptimeMillis()).longValue() >= lastSeekUpdateTime.longValue() + 1000) {
                mAudioManager.setStreamMute(3, false);
                scroll_position.setVisibility(View.GONE);
                if (videoview.isPlaying()) {
                    MusicBottomPanel.setVisibility(View.GONE);
                }
                videoview.removeCallbacks(horizontalScrollRunnable);
                return;
            }
            videoview.postDelayed(horizontalScrollRunnable, 1000);
        }
    };
    public Runnable updateSeekBarTime = new Runnable() {
        @SuppressLint({"NewApi"})
        public void run() {
            CharSequence format;
            durationHandler.removeCallbacks(updateSeekBarTime);
            VideoPlayActivity videoViewActivity = VideoPlayActivity.this;
            videoViewActivity.timeElapsed = videoViewActivity.videoview.getCurrentPosition();
            if (videoview.getCurrentPosition() > 0) {
                seekbar_vplay.setMax(videoview.getDuration());
                seekbar_vplay.setProgress(videoview.getCurrentPosition());
            }
            double d = timeElapsed;
            TextView textView = current_position;
            double d2 = d % 3600000.0d;
            int i = (int) (d2 / 60000.0d);
            int i2 = (int) ((d2 % 60000.0d) / 1000.0d);
            if (((int) (d / 3600000.0d)) > 0) {
                format = String.format("%02d:%02d:%02d", Integer.valueOf((int) (d / 3600000.0d)), Integer.valueOf(i), Integer.valueOf(i2));
            } else {
                format = String.format("%02d:%02d", Integer.valueOf(i), Integer.valueOf(i2));
            }
            textView.setText(format);
            scroll_position.setText(format);
            durationHandler.postDelayed(this, 100);
        }
    };
    SimpleOnGestureListener simpleOnGestureListener = new SimpleOnGestureListener() {
        @SuppressLint({"NewApi"})
        @TargetApi(11)
        public boolean onDoubleTap(MotionEvent motionEvent) {
            if (videoview.isPlaying()) {
                MusicBottomPanel.setVisibility(View.GONE);
                video_header_controls.setVisibility(View.GONE);
                getWindow().clearFlags(2048);
                getWindow().addFlags(1024);
                vari = 1;
            }
            return true;
        }

        public boolean isFullScreen() {
            return (getWindow().getAttributes().flags & 1024) == 1024;
        }

        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            MusicBottomPanel.removeCallbacks(hideScreenControllsRunnable);
            if (!lock_click && videoview.isPlaying()) {
                if (MusicBottomPanel.getVisibility() == View.GONE) {
                    MusicBottomPanel.setVisibility(View.VISIBLE);
                } else {
                    MusicBottomPanel.setVisibility(View.GONE);
                }
                if (video_header_controls.getVisibility() == View.GONE) {
                    video_header_controls.setVisibility(View.VISIBLE);
                } else {
                    video_header_controls.setVisibility(View.GONE);
                }
                MusicBottomPanel.postDelayed(hideScreenControllsRunnable, 5000);
                if (isFullScreen()) {
                    getWindow().clearFlags(1024);
                    getWindow().addFlags(2048);
                    vari = 0;
                } else {
                    getWindow().clearFlags(2048);
                    getWindow().addFlags(1024);
                    vari = 1;
                }
            }
            return super.onSingleTapConfirmed(motionEvent);
        }

        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
            f = motionEvent.getRawX() - motionEvent2.getRawX();
            f2 = motionEvent.getRawY() - motionEvent2.getRawY();
            Long valueOf = Long.valueOf(SystemClock.uptimeMillis());
            setGestureListener();
            VideoPlayActivity videoViewActivity;
            if (Math.abs(f) > Math.abs(f2)) {
                if (Math.abs(f) > 20.0f && valueOf.longValue() >= lastVolumeUpdateTime.longValue() + 1000) {
                    videoViewActivity = VideoPlayActivity.this;
                    videoViewActivity.lastSeekUpdateTime = valueOf;
                    videoViewActivity.onHorizontalScroll(f < 0.0f);
                }
            } else if (((double) Math.abs(f2)) > 60.0d && valueOf.longValue() >= lastSeekUpdateTime.longValue() + 1000) {
                double x = motionEvent.getX();
                double deviceWidth = VideoPlayActivity.getDeviceWidth(context);
                Double.isNaN(deviceWidth);
                Double.isNaN(deviceWidth);
                if (x < deviceWidth * 0.5d) {
                    videoViewActivity = VideoPlayActivity.this;
                    videoViewActivity.lastVolumeUpdateTime = valueOf;
                    videoViewActivity.onVerticalScroll(f2 / ((float) VideoPlayActivity.getDeviceHeight(videoViewActivity.context)), 1);
                } else {
                    x = motionEvent.getX();
                    deviceWidth = VideoPlayActivity.getDeviceWidth(context);
                    Double.isNaN(deviceWidth);
                    Double.isNaN(deviceWidth);
                    if (x > deviceWidth * 0.5d) {
                        videoViewActivity = VideoPlayActivity.this;
                        videoViewActivity.lastVolumeUpdateTime = valueOf;
                        videoViewActivity.onVerticalScroll(f2 / ((float) VideoPlayActivity.getDeviceHeight(videoViewActivity.context)), 2);
                    }
                }
            }
            return true;
        }
    };

    public void onStart(Boolean bool) {
    }

    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        hideSystemUI(getWindow());
    }

    public static void hideSystemUI(Window window) {
        window.getDecorView().setSystemUiVisibility(4871);
    }

    @SuppressLint({"NewApi"})
    public void onCreate(Bundle bundle) {
        hideSystemUI(getWindow());
        super.onCreate(bundle);
        gestureDetector = new GestureDetector(simpleOnGestureListener);
        Long valueOf = Long.valueOf(SystemClock.uptimeMillis());
        lastVolumeUpdateTime = valueOf;
        lastSeekUpdateTime = valueOf;
        setContentView(R.layout.activity_video_play);
        PutAnalyticsEvent();
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        AllVideolist = new ArrayList();
        getAllVideo();
        BindeView();
        SetListener();
        playbutton.performClick();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoPlayActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void SetListener() {
        getWindowManager().getDefaultDisplay();
        MusicBottomPanel.postDelayed(hideScreenControllsRunnable, 3000);
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivShare.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ShareVideo(AllVideolist.get(VideoCurrentPosition).getVideoFullPath());
            }
        });
        ivLock.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                VideoPlayActivity videoViewActivity = VideoPlayActivity.this;
                videoViewActivity.f3097aa = false;
                videoViewActivity.lock_click = true;
                videoViewActivity.MusicBottomPanel.setVisibility(View.GONE);
                video_header_controls.setVisibility(View.GONE);
                ivUnlock.setVisibility(View.VISIBLE);
                laylock.setEnabled(false);
                size_screenback.setEnabled(false);
                hundred_screensize.setEnabled(false);
                screen_sizes.setEnabled(false);
                left_press.setEnabled(false);
                right_press.setEnabled(false);
                volumebar.setEnabled(false);
                brightbar.setEnabled(false);
                seekbar_vplay.setEnabled(false);
                rewind_btn.setEnabled(false);
                play_btn.setEnabled(false);
                forward_btn.setEnabled(false);
                ivLock.setTag("a");
                MusicBottomPanel.setEnabled(false);
            }
        });
        hundred_screensize.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                screen_sizes.setVisibility(View.VISIBLE);
                screen_sizes.setText("100%");
                screen_sizes.postDelayed(new Runnable() {
                    public void run() {
                        screen_sizes.setVisibility(View.GONE);
                    }
                }, 2000);
                size_screenback.setVisibility(View.GONE);
                hundred_screensize.setVisibility(View.GONE);
                size_screen.setVisibility(View.VISIBLE);
                DisplayMetrics displayMetrics = new DisplayMetrics();
                getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                LayoutParams layoutParams = (LayoutParams) videoview.getLayoutParams();
                layoutParams.width = (int) (displayMetrics.density * 1000.0f);
                layoutParams.leftMargin = 150;
                layoutParams.rightMargin = 150;
                layoutParams.topMargin = 0;
                layoutParams.bottomMargin = 0;
                videoview.setLayoutParams(layoutParams);
            }
        });
        size_screenback.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                screen_sizes.setVisibility(View.VISIBLE);
                screen_sizes.setText("FIT TO SCREEN");
                screen_sizes.postDelayed(new Runnable() {
                    public void run() {
                        screen_sizes.setVisibility(View.GONE);
                    }
                }, 2000);
                size_screenback.setVisibility(View.GONE);
                size_screen.setVisibility(View.GONE);
                hundred_screensize.setVisibility(View.VISIBLE);
                DisplayMetrics displayMetrics = new DisplayMetrics();
                getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                LayoutParams layoutParams = (LayoutParams) videoview.getLayoutParams();
                layoutParams.width = displayMetrics.widthPixels;
                layoutParams.height = displayMetrics.heightPixels;
                layoutParams.leftMargin = 0;
                layoutParams.rightMargin = 0;
                layoutParams.topMargin = 0;
                layoutParams.bottomMargin = 0;
                videoview.setLayoutParams(layoutParams);
            }
        });
        size_screen.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                screen_sizes.setVisibility(View.VISIBLE);
                screen_sizes.setText("CROP");
                screen_sizes.postDelayed(new Runnable() {
                    public void run() {
                        screen_sizes.setVisibility(View.GONE);
                    }
                }, 2000);
                size_screenback.setVisibility(View.VISIBLE);
                size_screen.setVisibility(View.GONE);
                hundred_screensize.setVisibility(View.GONE);
                DisplayMetrics displayMetrics = new DisplayMetrics();
                getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                LayoutParams layoutParams = (LayoutParams) videoview.getLayoutParams();
                layoutParams.width = (int) (displayMetrics.density * 400.0f);
                double d = displayMetrics.density;
                Double.isNaN(d);
                Double.isNaN(d);
                layoutParams.height = (int) (d * 300.0d);
                layoutParams.leftMargin = 150;
                layoutParams.rightMargin = 150;
                layoutParams.topMargin = 150;
                layoutParams.bottomMargin = 150;
                videoview.setLayoutParams(layoutParams);
            }
        });
        ivUnlock.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                f3097aa = true;
                laylock.setEnabled(true);
                ivUnlock.setVisibility(View.GONE);
                left_press.setEnabled(true);
                right_press.setEnabled(true);
                volumebar.setEnabled(true);
                brightbar.setEnabled(true);
                MusicBottomPanel.setEnabled(true);
                seekbar_vplay.setEnabled(true);
                rewind_btn.setEnabled(true);
                play_btn.setEnabled(true);
                forward_btn.setEnabled(true);
                lock_click = false;
                ivUnlock.setTag("b");
                seekbar_vplay.setVisibility(View.VISIBLE);
                rewind_btn.setVisibility(View.VISIBLE);
                forward_btn.setVisibility(View.VISIBLE);
                MusicBottomPanel.setVisibility(View.VISIBLE);
                video_header_controls.setVisibility(View.VISIBLE);
                if (videoview.isPlaying()) {
                    pause_btn.setVisibility(View.VISIBLE);
                    play_btn.setVisibility(View.INVISIBLE);
                    return;
                }
                pause_btn.setVisibility(View.GONE);
                play_btn.setVisibility(View.VISIBLE);
            }
        });
        pause_btn.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MusicBottomPanel.setVisibility(View.VISIBLE);
                play_btn.setVisibility(View.VISIBLE);
                pause_btn.setVisibility(View.GONE);
                MusicBottomPanel.removeCallbacks(hideScreenControllsRunnable);
                videoview.pause();
            }
        });
        play_btn.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                pause_btn.setVisibility(View.VISIBLE);
                play_btn.setVisibility(View.INVISIBLE);
                playbutton.setVisibility(View.GONE);
                MusicBottomPanel.postDelayed(hideScreenControllsRunnable, 1000);
                vari = 1;
                videoview.start();
            }
        });
        forward_btn.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                f3097aa = false;
                videoview.stopPlayback();
                VideoNext();
                if (oneTimeOnly == 0) {
                    seekbar_vplay.setMax((int) finalTime);
                    oneTimeOnly = 1;
                }
                seekbar_vplay.setMax((int) finalTime);
                playbutton.setVisibility(View.GONE);
                play_btn.setVisibility(View.INVISIBLE);
                pause_btn.setVisibility(View.VISIBLE);
                seekbar_vplay.setVisibility(View.VISIBLE);
                videoview.setZOrderOnTop(false);
                videoview.start();
                timeElapsed = videoview.getCurrentPosition();
                seekbar_vplay.setProgress((int) timeElapsed);
                durationHandler.postDelayed(updateSeekBarTime, 100);
                MusicBottomPanel.setVisibility(View.VISIBLE);
                MusicBottomPanel.postDelayed(hideScreenControllsRunnable, 3000);
            }
        });
        rewind_btn.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                f3097aa = false;
                VideoPrevious();
                if (oneTimeOnly == 0) {
                    seekbar_vplay.setMax((int) finalTime);
                    oneTimeOnly = 1;
                }
                seekbar_vplay.setMax((int) finalTime);
                playbutton.setVisibility(View.GONE);
                play_btn.setVisibility(View.INVISIBLE);
                pause_btn.setVisibility(View.VISIBLE);
                seekbar_vplay.setVisibility(View.VISIBLE);
                videoview.setZOrderOnTop(false);
                videoview.start();
                timeElapsed = videoview.getCurrentPosition();
                seekbar_vplay.setProgress((int) timeElapsed);
                durationHandler.postDelayed(updateSeekBarTime, 100);
                MusicBottomPanel.setVisibility(View.VISIBLE);
                MusicBottomPanel.postDelayed(hideScreenControllsRunnable, 3000);
            }
        });
        seekbar_vplay.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            int progress = 0;

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (videoview != null && z) {
                    progress = i;
                    videoview.seekTo(progress);
                }
            }
        });
        videoview.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                if (VideoCurrentPosition + 1 == count) {
                    play_btn.setVisibility(View.VISIBLE);
                    pause_btn.setVisibility(View.GONE);
                    playbutton.setVisibility(View.VISIBLE);
                    MusicBottomPanel.post(hideScreenControllsRunnable);
                    return;
                }
                forward_btn.performClick();
            }
        });
        mHandlerss = new Handler();
        videoview.setKeepScreenOn(true);
        portrat.setOnClickListener(new OnClickListener() {
            @SuppressLint({"WrongConstant"})
            public void onClick(View view) {
                land.setVisibility(View.VISIBLE);
                portrat.setVisibility(View.GONE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        });
        land.setOnClickListener(new OnClickListener() {
            @SuppressLint({"WrongConstant"})
            public void onClick(View view) {
                land.setVisibility(View.GONE);
                portrat.setVisibility(View.VISIBLE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            }
        });
        window = getWindow();
        brightbar.setMax(100);
        right_press.setMax(100);
        volumebar.setMax(mAudioManager.getStreamMaxVolume(3));
        volumebar.setProgress(mAudioManager.getStreamVolume(3));
        volumebar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                mAudioManager.setStreamVolume(3, i, 0);
                if (i > 0) {
                    i = (i * 100) / mMaxVolume;
                }
                textvolume.setText(String.valueOf(i));
            }
        });
        volumebar.setKeyProgressIncrement(1);
        brightbar.setKeyProgressIncrement(1);
        try {
            brightness = System.getInt(cResolver, "screen_brightness");
        } catch (SettingNotFoundException e) {
            e.printStackTrace();
        }
        videoview.requestFocus();
        MusicBottomPanel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        playbutton.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (videoview.isPlaying()) {
                    videoview.stopPlayback();
                    videoview.setZOrderOnTop(true);
                    return;
                }
                finalTime = videoview.getDuration();
                seekbar_vplay.setMax((int) finalTime);
                playbutton.setVisibility(View.GONE);
                getWindow().clearFlags(2048);
                getWindow().addFlags(1024);
                vari = 1;
                play_btn.setVisibility(View.INVISIBLE);
                pause_btn.setVisibility(View.VISIBLE);
                seekbar_vplay.setVisibility(View.VISIBLE);
                videoview.setZOrderOnTop(false);
                videoview.start();
                if (getIntent().hasExtra("START_FROM")) {
                    videoview.seekTo(extras.getInt("START_FROM"));
                    getIntent().removeExtra("START_FROM");
                }
                timeElapsed = videoview.getCurrentPosition();
                seekbar_vplay.setProgress((int) timeElapsed);
                durationHandler.postDelayed(updateSeekBarTime, 10);
                MusicBottomPanel.setVisibility(View.VISIBLE);
                video_header_controls.setVisibility(View.VISIBLE);
                if (oneTimeOnly == 0) {
                    seekbar_vplay.setMax((int) finalTime);
                    oneTimeOnly = 1;
                }
            }
        });
        videoview.setOnPreparedListener(new OnPreparedListener() {
            @SuppressLint({"WrongConstant"})
            public void onPrepared(MediaPlayer mediaPlayer) {
                videoview.setBackgroundColor(0);
                audioTracksList = new ArrayList();
                audioTracksIndexes = new ArrayList();
                selectedAudioTrack = -1;
                if (VERSION.SDK_INT >= 16) {
                    TrackInfo[] trackInfo = mediaPlayer.getTrackInfo();
                    int i = 0;
                    for (int i2 = 0; i2 < trackInfo.length; i2++) {
                        if (trackInfo[i2].getTrackType() == 2) {
                            Object stringBuilder;
                            String language = trackInfo[i2].getLanguage();
                            if (language.equals("und") || language.isEmpty()) {
                                i++;
                                StringBuilder stringBuilder2 = new StringBuilder();
                                stringBuilder2.append("Audio track #");
                                stringBuilder2.append(i);
                                stringBuilder = stringBuilder2.toString();
                            } else {
                                Locale locale = new Locale(language);
                                stringBuilder = locale.getDisplayLanguage(locale);
                            }
                            audioTracksList.add(String.valueOf(stringBuilder));
                            audioTracksIndexes.add(Integer.valueOf(i2));
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(i2);
                            stringBuilder3.append(" : ");
                            stringBuilder3.append(stringBuilder);
                        }
                    }
                    if (!audioTracksIndexes.isEmpty()) {
                        VideoPlayActivity videoViewActivity = VideoPlayActivity.this;
                        videoViewActivity.selectedAudioTrack = videoViewActivity.audioTracksIndexes.get(0).intValue();
                    }
                    VideoPlayActivity.this.mediaPlayer = mediaPlayer;
                }
            }
        });
    }


    @SuppressLint({"WrongConstant"})
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i != DRAW_OVER_OTHER_APP_PERMISSION) {
            super.onActivityResult(i, i2, intent);
        } else if (i2 != -1) {
            Toast.makeText(this, "Draw over other app permission not available. Closing the application", Toast.LENGTH_SHORT).show();
        }
    }

    private void ShareVideo(String VideoPath) {
        File file = new File(VideoPath);
        final Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/*");
        final StringBuilder sb = new StringBuilder();
        sb.append(this.getResources().getString(R.string.app_name));
        sb.append(": ");
        sb.append(this.getString(R.string.get_free));
        sb.append(this.getString(R.string.app_name));
        sb.append(" Music at here : https://play.google.com/store/apps/details?id=");
        sb.append(this.getPackageName());
        final Uri ShareUri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".provider", file);
        intent.putExtra("android.intent.extra.TEXT", sb.toString());
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        this.startActivity(Intent.createChooser(intent, (CharSequence) this.getString(R.string.share_video)));
    }

    private void VideoNext() throws IllegalStateException {
        if (!(VideoCurrentPosition + 1 < AllVideolist.size())) {
            startActivity(new Intent(activity, YourVideoActivity.class));
            finish();
            return;
        }
        VideoCurrentPosition++;
        videoview.stopPlayback();
        setVideoPath(VideoCurrentPosition);
    }

    private void VideoPrevious() throws IllegalStateException {
        if ((VideoCurrentPosition - 1 == -1)) {
            startActivity(new Intent(activity, YourVideoActivity.class));
            finish();
            return;
        }
        VideoCurrentPosition--;
        videoview.stopPlayback();
        setVideoPath(VideoCurrentPosition);
    }

    private void setVideoPath(int position) {
        String format;
        int i2 = (int) AllVideolist.get(position).getVideoDuration();
        int i3 = i2 % 3600000;
        int i4 = i3 / 60000;
        i3 = (i3 % 60000) / 1000;
        if (i2 / 3600000 > 0) {
            format = String.format("%02d:%02d:%02d", Integer.valueOf(i2 / 3600000), Integer.valueOf(i4), Integer.valueOf(i3));
        } else {
            format = String.format("%02d:%02d", Integer.valueOf(i4), Integer.valueOf(i3));
        }
        VideoDuration = format;

        volumebar.setEnabled(false);
        brightbar.setEnabled(false);
        f3097aa = true;
        videoview.stopPlayback();
        videoview.setVideoPath(AllVideolist.get(position).getVideoFullPath());
        VideoTitle.setText(AllVideolist.get(position).getVideoName());

        videoview.seekTo(100);
        current_position.setText("00:00");
        tvEndTime.setText(String.valueOf(Utils.INSTANCE.TimeCaculate(AllVideolist.get(position).getVideoDuration())));
        current_position.setText(format);
        scroll_position.setText(format);
    }

    private void getAllVideo() {
        AllVideolist.clear();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final Cursor cur = activity.getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getAPPFOLDER() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final VideoModel videoInfo = new VideoModel();
                videoInfo.videoDuration = cur.getLong(bucketColumn);
                videoInfo.videoFullPath = cur.getString(data);
                videoInfo.videoName = cur.getString(name);
                videoInfo.dateTaken = cur.getLong(dateTaken);
                if (new File(videoInfo.videoFullPath).exists()) {
                    AllVideolist.add(videoInfo);
                }
            } while (cur.moveToNext());
        }
    }


    private void BindeView() {
        ivback = findViewById(R.id.ivBack);
        ivShare = findViewById(R.id.iv_share);
        VideoTitle = findViewById(R.id.tv_playertitle);
        video_header_controls = findViewById(R.id.video_header);
        context = this;
        mContext = this;
        extras = getIntent().getExtras();
        filename = extras.getString("VideoUrl");
        videoDisplayName = extras.getString("VideoName");
        VideoCurrentPosition = extras.getInt("VideoPosition", 0);
        IsFromAndroidlist = getIntent().getBooleanExtra("IsVideoFromAndroidList", false);
        if (IsFromAndroidlist) {
            VideoDuration = extras.getString("VideoDuration");
        } else {
            VideoDuration = Utils.INSTANCE.TimeCaculate(AllVideolist.get(0).getVideoDuration());
        }
        scroll_position = findViewById(R.id.scroll_position);
        current_position = findViewById(R.id.tv_starttime);
        tvEndTime = findViewById(R.id.tb_endtime);
        tvEndTime.setText(VideoDuration);
        videoview = findViewById(R.id.videoView);
        playbutton = findViewById(R.id.iv_playmain);
        left_press = findViewById(R.id.left_press);
        right_press = findViewById(R.id.right_press);
        portrat = findViewById(R.id.iv_portrait);
        land = findViewById(R.id.iv_landscape);
        textvolume = findViewById(R.id.textvolume);
        textbrightness = findViewById(R.id.textbrightness);
        pause_btn = findViewById(R.id.iv_pause);
        play_btn = findViewById(R.id.iv_play);
        play_btn.setVisibility(View.INVISIBLE);
        pause_btn.setVisibility(View.VISIBLE);
        forward_btn = findViewById(R.id.iv_next);
        rewind_btn = findViewById(R.id.iv_previous);
        seekbar_vplay = findViewById(R.id.sb_video);
        ivUnlock = findViewById(R.id.iv_unlock);
        ivLock = findViewById(R.id.iv_lock);
        laylock = findViewById(R.id.laylock);
        MusicBottomPanel = findViewById(R.id.layout_songhandling);
        MusicBottomPanel.setVisibility(View.GONE);
        videoview.setVideoPath(filename);
        VideoTitle.setText(videoDisplayName);
        brightbar = findViewById(R.id.sb_brightness);
        imgBright = findViewById(R.id.iv_brightness);
        volumebar = findViewById(R.id.sb_volume);
        imgSound = findViewById(R.id.iv_volume);
        cResolver = getContentResolver();
        brightbar.setVisibility(View.GONE);
        imgBright.setVisibility(View.GONE);
        volumebar.setVisibility(View.GONE);
        imgSound.setVisibility(View.GONE);
        textvolume.setVisibility(View.GONE);
        textbrightness.setVisibility(View.GONE);
        land.setVisibility(View.VISIBLE);
        portrat.setVisibility(View.GONE);
        seekbar_vplay.setVisibility(View.GONE);
        setVolumeControlStream(3);
        size_screen = findViewById(R.id.iv_screensize);
        size_screenback = findViewById(R.id.iv_fullscreen);
        screen_sizes = findViewById(R.id.screen_sizes);
        size_screen.setVisibility(View.VISIBLE);
        screen_sizes.setVisibility(View.GONE);
        size_screenback.setVisibility(View.GONE);
        hundred_screensize = findViewById(R.id.iv_hundredscreen);
        hundred_screensize.setVisibility(View.GONE);
    }

    public void onPause() {
        super.onPause();
        stopPosition = videoview.getCurrentPosition();
        if (videoview.isPlaying()) {
            videoview.pause();
            isPlaying = true;
            return;
        }
        isPlaying = false;
    }

    public void onResume() {
        super.onResume();
        int i = stopPosition;
        if (i > 0) {
            videoview.seekTo(i);
            if (isPlaying) {
                videoview.start();
            }
        }
    }


    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            mCurVolume = -1;
            mCurBrightness = -1.0f;
            volumebar.postDelayed(new Runnable() {
                public void run() {
                    volumebar.setVisibility(View.GONE);
                    imgSound.setVisibility(View.GONE);
                }
            }, 3000);
            textvolume.postDelayed(new Runnable() {
                public void run() {
                    textvolume.setVisibility(View.GONE);
                }
            }, 3000);
            brightbar.postDelayed(new Runnable() {
                public void run() {
                    brightbar.setVisibility(View.GONE);
                    imgBright.setVisibility(View.GONE);
                }
            }, 3000);
            textbrightness.postDelayed(new Runnable() {
                public void run() {
                    textbrightness.setVisibility(View.GONE);
                }
            }, 3000);
        }
        gestureDetector.onTouchEvent(motionEvent);
        return true;
    }

    public void onSwipe(int i) {
        switch (i) {
            case 1:
                return;
            case 2:
                return;
            case 3:
                currentPosition = videoview.getCurrentPosition();
                currentPosition = videoview.getCurrentPosition() + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
                videoview.seekTo(currentPosition);
                return;
            case 4:
                Log.d("111-SWIPE_RIGHT-111", "111-SWIPE_RIGHT-111");
                currentPosition = videoview.getCurrentPosition();
                currentPosition = videoview.getCurrentPosition() + 1000;
                videoview.seekTo(currentPosition);
                return;
            default:
                return;
        }
    }

    public void setGestureListener() {
        mMaxVolume = mAudioManager.getStreamMaxVolume(3);
    }

    public static int getDeviceWidth(Context context) {
        WindowManager windowManager = (WindowManager) context.getSystemService(WINDOW_SERVICE);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics.widthPixels;
    }

    public static int getDeviceHeight(Context context) {
        WindowManager windowManager = (WindowManager) context.getSystemService(WINDOW_SERVICE);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics.heightPixels;
    }

    public void onVerticalScroll(float f, int i) {
        if (i == 1) {
            changeBrightness(f * 2.0f);
        } else {
            changeVolume(f * 2.0f);
        }
    }

    public void onHorizontalScroll(boolean z) {
        if (((z && videoview.canSeekForward()) || (!z && videoview.canSeekBackward())) && f3097aa) {
            if (MusicBottomPanel.getVisibility() == View.GONE) {
                MusicBottomPanel.setVisibility(View.VISIBLE);
            }
            mAudioManager.setStreamMute(3, true);
            videoview.removeCallbacks(horizontalScrollRunnable);
            if (scroll_position.getVisibility() == View.GONE) {
                scroll_position.setVisibility(View.VISIBLE);
            }
            videoview.postDelayed(horizontalScrollRunnable, 1000);
            if (z) {
                currentPosition = videoview.getCurrentPosition();
                currentPosition = videoview.getCurrentPosition() + 128;
                videoview.seekTo(currentPosition);
                return;
            }
            currentPosition = videoview.getCurrentPosition();
            currentPosition = videoview.getCurrentPosition() - 700;
            videoview.seekTo(currentPosition);
        }
    }

    private void changeBrightness(float f) {
        if (mCurBrightness == -1.0f) {
            mCurBrightness = mContext.getWindow().getAttributes().screenBrightness;
            if (mCurBrightness <= 0.01f) {
                mCurBrightness = 0.01f;
            }
        }
        brightbar.setVisibility(View.VISIBLE);
        imgBright.setVisibility(View.VISIBLE);
        textbrightness.setVisibility(View.VISIBLE);
        WindowManager.LayoutParams attributes = mContext.getWindow().getAttributes();
        attributes.screenBrightness = mCurBrightness + f;
        if (attributes.screenBrightness >= 1.0f) {
            attributes.screenBrightness = 1.0f;
        } else if (attributes.screenBrightness <= 0.01f) {
            attributes.screenBrightness = 0.01f;
        }
        mContext.getWindow().setAttributes(attributes);
        int i = (int) (attributes.screenBrightness * 100.0f);
        brightbar.setProgress(i);
        textbrightness.setText(String.valueOf(i));
    }

    private void changeVolume(float f) {
        volumebar.setVisibility(View.VISIBLE);
        imgSound.setVisibility(View.VISIBLE);
        textvolume.setVisibility(View.VISIBLE);
        if (mCurVolume == -1) {
            mCurVolume = mAudioManager.getStreamVolume(3);
            if (((float) mCurVolume) < 0.01f) {
                mCurVolume = 0;
            }
        }
        int i = mMaxVolume;
        int i2 = ((int) (((float) i) * f)) + mCurVolume;
        if (i2 > i) {
            i2 = i;
        }
        if (((float) i2) < 0.01f) {
            i2 = 0;
        }
        volumebar.setProgress(i2);
    }

        public void onBackPressed() {
            super.onBackPressed();
            VideoView videoView = videoview;
            if (videoView != null && videoView.isPlaying()) {
                videoview.stopPlayback();
            }
            if (MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
                MyApplication.AdsId = 3;
                MyApplication.AdsShowContext = activity;
                MyApplication.mInterstitialAd.show();
            } else {
                GoBack();
            }
        }


        private void GoBack() {
            if (IsFromAndroidlist) {
                Intent intent = new Intent(activity, YourVideoActivity.class);
                startActivity(intent);
                finish();
            } else {
                AndroidUnityCall.ScanVideoList(activity, MyApplication.VideoPath);
                Intent intent = new Intent(activity, YourVideoActivity.class);
                startActivity(intent);
                finish();
            }
        }
}