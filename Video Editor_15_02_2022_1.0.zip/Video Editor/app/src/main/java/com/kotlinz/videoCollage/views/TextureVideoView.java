package com.kotlinz.videoCollage.views;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.media.MediaExtractor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnVideoSizeChangedListener;
import android.net.Uri;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.TextureView.SurfaceTextureListener;

import com.google.android.exoplayer2.util.MimeTypes;

import java.io.IOException;

public class TextureVideoView extends TextureView implements OnBufferingUpdateListener, OnCompletionListener, OnErrorListener, OnInfoListener, OnPreparedListener, OnVideoSizeChangedListener, Callback, SurfaceTextureListener {
    private static final boolean b_boolean = false;
    private static HandlerThread mainHandler = new HandlerThread("VideoPlayThread");
    public Alignment alignment = Alignment.FIT_CENTER;
    private AudioManager audioManager;
    private volatile int c_int = 0;
    private Context context;
    private volatile int d_int = 0;
    public mediaInterface j_interface;
    private Handler k_handler;
    private Handler l_handler;
    private boolean m_boolean;
    public MediaPlayer mediaPlayer;
    private boolean mute;
    private boolean n_boolean;
    private boolean o_boolean = true;
    public boolean p_boolean;
    private Surface surface;
    SurfaceTextureListener surfaceTextureListener;
    private Uri uri;


    static  class AnonymousClass8 {
        static final  int[] $SwitchMap$fcom$collage$imagevideo$views$TextureVideoView$Alignment = new int[0];

        static {
        }
    }

    private enum Align {
        LEFT_TOP,
        CENTER,
        CENTER_BOTTOM
    }

    public enum Alignment {
        CENTER_CROP,
        CENTER,
        FIT_XY,
        FIT_CENTER,
        NONE,
        CENTER_BOTTOM
    }

    /* renamed from: fcom.collage.imagevideo.views.TextureVideoView$AnonymousClass8 */
    static class C0000AnonymousClass8 {
        static final int[] b_int;

        C0000AnonymousClass8() {
        }

        static {
            int[] iArr = new int[Align.values().length];
            b_int = iArr;
            try {
                iArr[Align.LEFT_TOP.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                b_int[Align.CENTER.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                b_int[Align.CENTER_BOTTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            int[] iArr2 = new int[Alignment.values().length];
            iArr2[Alignment.NONE.ordinal()] = 1;
            iArr2[Alignment.FIT_XY.ordinal()] = 2;
            iArr2[Alignment.FIT_CENTER.ordinal()] = 3;
            iArr2[Alignment.CENTER.ordinal()] = 4;
            iArr2[Alignment.CENTER_CROP.ordinal()] = 5;
            try {
                iArr2[Alignment.CENTER_BOTTOM.ordinal()] = 6;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    private static class Inner_E_Class {
        private int a_int;
        private int b_int;

        public Inner_E_Class(int i, int i2) {
            this.a_int = i;
            this.b_int = i2;
        }

        public int a() {
            return this.a_int;
        }

        public int b() {
            return this.b_int;
        }
    }

    private static class Inter_C_Class {
        private Inner_E_Class inner_e_class;
        private Inner_E_Class inner_e_class1;

        public Inter_C_Class(Inner_E_Class inner_E_Class, Inner_E_Class inner_E_Class2) {
            this.inner_e_class = inner_E_Class;
            this.inner_e_class1 = inner_E_Class2;
        }

        public Matrix a(Alignment alignment) {
            switch (AnonymousClass8.$SwitchMap$fcom$collage$imagevideo$views$TextureVideoView$Alignment[alignment.ordinal()]) {
                case 1:
                    return a();
                case 2:
                    return b();
                case 3:
                    return c();
                case 4:
                    return b(Align.CENTER);
                case 5:
                    return c(Align.CENTER);
                case 6:
                    return c(Align.CENTER_BOTTOM);
                default:
                    return null;
            }
        }

        private Matrix a(float f, float f2, float f3, float f4) {
            Matrix matrix = new Matrix();
            matrix.setScale(f, f2, f3, f4);
            return matrix;
        }

        private Matrix a(float f, float f2, Align align) {
            int i = C0000AnonymousClass8.b_int[align.ordinal()];
            if (i == 1) {
                return a(f, f2, 0.0f, 0.0f);
            }
            if (i == 2) {
                return a(f, f2, ((float) this.inner_e_class.a()) / 2.0f, ((float) this.inner_e_class.b()) / 2.0f);
            }
            if (i == 3) {
                return a(f, f2, ((float) this.inner_e_class.a()) / 2.0f, (float) this.inner_e_class.b());
            }
            throw new IllegalArgumentException("Illegal PivotPoint");
        }

        private Matrix a() {
            return a(((float) this.inner_e_class1.a()) / ((float) this.inner_e_class.a()), ((float) this.inner_e_class1.b()) / ((float) this.inner_e_class.b()), Align.CENTER);
        }

        private Matrix a(Align align) {
            float a = ((float) this.inner_e_class.a()) / ((float) this.inner_e_class1.a());
            float b = ((float) this.inner_e_class.b()) / ((float) this.inner_e_class1.b());
            float min = Math.min(a, b);
            return a(min / a, min / b, align);
        }

        private Matrix b() {
            return a(1.0f, 1.0f, Align.LEFT_TOP);
        }

        private Matrix c() {
            return a(Align.CENTER);
        }

        private Matrix b(Align align) {
            return a(((float) this.inner_e_class1.a()) / ((float) this.inner_e_class.a()), ((float) this.inner_e_class1.b()) / ((float) this.inner_e_class.b()), align);
        }

        private Matrix c(Align align) {
            float a = ((float) this.inner_e_class.a()) / ((float) this.inner_e_class1.a());
            float b = ((float) this.inner_e_class.b()) / ((float) this.inner_e_class1.b());
            float max = Math.max(a, b);
            return a(max / a, max / b, align);
        }
    }

    public interface mediaInterface {
        void a(MediaPlayer mediaPlayer);

        void a(MediaPlayer mediaPlayer, int i);

        void a(MediaPlayer mediaPlayer, int i, int i2);

        void b(MediaPlayer mediaPlayer);

        boolean b(MediaPlayer mediaPlayer, int i, int i2);

        boolean c(MediaPlayer mediaPlayer, int i, int i2);
    }

    static {
        Log.e("pieceTextureVideoView", " static");
        mainHandler.start();
    }

    public TextureVideoView(Context context) {
        super(context);
        Log.e("pieceTextureVideoView", " TextureVideoView 1");
        init();
    }

    public TextureVideoView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Log.e("pieceTextureVideoView", " TextureVideoView 2");
        init();
    }

    public TextureVideoView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Log.e("pieceTextureVideoView", " TextureVideoView 3");
        init();
    }

    public TextureVideoView(Context context, String str) {
        super(context);
        Log.e("pieceTextureVideoView", " TextureVideoView 1");
        init();
    }

    public void setMediaPlayerCallback(mediaInterface mediainterface) {
        this.j_interface = mediainterface;
        if (mediainterface == null) {
            this.k_handler.removeCallbacksAndMessages(null);
        }
    }

    public boolean handleMessage(Message message) {
        synchronized (TextureVideoView.class) {
            int i = message.what;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" handleMessage :: ");
            stringBuilder.append(i);
            Log.e("pieceTextureVideoView", stringBuilder.toString());
            if (i == 1) {
                this.d_int = 3;
                mediaInit();
            } else if (i == 2) {
                this.d_int = 5;
                if (this.mediaPlayer != null) {
                    this.mediaPlayer.start();
                }
            } else if (i == 4) {
                this.d_int = 4;
                if (this.mediaPlayer != null) {
                    this.mediaPlayer.pause();
                }
                this.c_int = 4;
            } else if (i == 6) {
                this.d_int = 5;
                mediaRelease(true);
            }
        }
        return false;
    }

    private void init() {
        Log.e("pieceTextureVideoView", " init");
        this.context = getContext();
        this.c_int = 0;
        this.d_int = 3;
        this.k_handler = new Handler();
        this.l_handler = new Handler(mainHandler.getLooper(), this);
        setSurfaceTextureListener(this);
    }

    private void mediaRelease(boolean z) {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            this.mediaPlayer.reset();
            this.mediaPlayer.release();
            this.mediaPlayer = null;
            this.c_int = 0;
            if (z) {
                this.d_int = 0;
            }
        }
    }

    @SuppressLint("WrongConstant")
    public void mediaInit() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" mediaInit uri ::-> ");
        stringBuilder.append(this.uri);
        String str = "pieceTextureVideoView";
        Log.e(str, stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(" mediaInit d_int ::-> ");
        stringBuilder.append(this.d_int);
        Log.e(str, stringBuilder.toString());
        StringBuilder stringBuilder2;
        if (this.uri == null || this.surface == null || this.d_int != 3) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("openVideo error ");
            stringBuilder.append(this.uri);
            String str2 = " ";
            stringBuilder.append(str2);
            stringBuilder.append(this.surface);
            stringBuilder.append(str2);
            stringBuilder.append(this.d_int);
            Log.e("TextureVideoView", stringBuilder.toString());
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(" mediaInit :: if ::-> ");
            stringBuilder2.append(stringBuilder.toString());
            Log.e(str, stringBuilder2.toString());
            return;
        }
        this.audioManager = (AudioManager) this.context.getSystemService(MimeTypes.BASE_TYPE_AUDIO);
        int i = 0;
        mediaRelease(false);
        try {
            Log.e(str, " mediaInit :: try ::-> ");
            MediaPlayer mediaPlayer = new MediaPlayer();
            this.mediaPlayer = mediaPlayer;
            mediaPlayer.setOnPreparedListener(this);
            this.mediaPlayer.setOnVideoSizeChangedListener(this);
            this.mediaPlayer.setOnCompletionListener(this);
            this.mediaPlayer.setOnErrorListener(this);
            this.mediaPlayer.setOnInfoListener(this);
            this.mediaPlayer.setOnBufferingUpdateListener(this);
            this.mediaPlayer.setDataSource(this.context, this.uri);
            this.mediaPlayer.setSurface(this.surface);
            this.mediaPlayer.setAudioStreamType(3);
            this.mediaPlayer.setLooping(this.o_boolean);
            this.mediaPlayer.prepareAsync();
            this.c_int = 1;
            this.d_int = 1;
            MediaExtractor mediaExtractor = new MediaExtractor();
            mediaExtractor.setDataSource(this.context, this.uri, null);
            this.n_boolean = false;
            while (i < mediaExtractor.getTrackCount()) {
                if (mediaExtractor.getTrackFormat(i).getString("mime").startsWith("audio/")) {
                    this.n_boolean = true;
                    break;
                }
                i++;
            }
        } catch (IOException | IllegalArgumentException | IllegalStateException | SecurityException e) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(" mediaInit :: catch ::-> ");
            stringBuilder2.append(e);
            Log.e(str, stringBuilder2.toString());
            this.c_int = -1;
            this.d_int = -1;
            if (this.j_interface != null) {
                this.k_handler.post(new Runnable() {
                    public void run() {
                        if (TextureVideoView.this.j_interface != null) {
                            TextureVideoView.this.j_interface.c(TextureVideoView.this.mediaPlayer, 1, 0);
                        }
                    }
                });
            }
        }
    }

    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
        Log.e("pieceTextureVideoView", " onSurfaceTextureAvailable");
        this.surface = new Surface(surfaceTexture);
        if (this.d_int == 3) {
            Log.i("TextureVideoView", "onSurfaceTextureAvailable start");
            mediaRelease();
        }
        SurfaceTextureListener surfaceTextureListener = this.surfaceTextureListener;
        if (surfaceTextureListener != null) {
            surfaceTextureListener.onSurfaceTextureAvailable(surfaceTexture, i, i2);
        }
    }

    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
        Log.e("pieceTextureVideoView", " onSurfaceTextureSizeChanged");
        SurfaceTextureListener surfaceTextureListener = this.surfaceTextureListener;
        if (surfaceTextureListener != null) {
            surfaceTextureListener.onSurfaceTextureSizeChanged(surfaceTexture, i, i2);
        }
    }

    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        Log.e("pieceTextureVideoView", " onSurfaceTextureDestroyed");
        this.surface = null;
        stop();
        SurfaceTextureListener surfaceTextureListener = this.surfaceTextureListener;
        if (surfaceTextureListener != null) {
            surfaceTextureListener.onSurfaceTextureDestroyed(surfaceTexture);
        }
        return true;
    }

    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        SurfaceTextureListener surfaceTextureListener = this.surfaceTextureListener;
        if (surfaceTextureListener != null) {
            surfaceTextureListener.onSurfaceTextureUpdated(surfaceTexture);
        }
        requestLayout();
        invalidate();
    }

    public void setVideoPath(String str) {
        setVideoURI(Uri.parse(str));
    }

    public void setVideoURI(Uri uri) {
        this.uri = uri;
    }

    public void setScaleType(Alignment alignment) {
        this.alignment = alignment;
    }

    public void mediaRelease() {
        if (mediaPlayerNotNull()) {
            this.l_handler.obtainMessage(6).sendToTarget();
        }
        if (this.uri == null || this.surface == null) {
            this.d_int = 3;
        } else {
            this.l_handler.obtainMessage(1).sendToTarget();
        }
    }

    public void b() {
        Log.e("pieceTextureVideoView", " b");
        this.l_handler.obtainMessage(1).sendToTarget();
    }

    public void pause() {
        this.l_handler.obtainMessage(4).sendToTarget();
    }

    public void start() {
        this.l_handler.obtainMessage(2).sendToTarget();
    }

    public void stop() {
        Log.e("pieceTextureVideoView", " stop");
        if (mediaPlayerNotNull()) {
            this.l_handler.obtainMessage(6).sendToTarget();
        }
    }

    public void setMute(boolean z) {
        this.mute = z;
    }

    public boolean isMute() {
        return this.mute;
    }

    public int getVideoDuration() {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        return mediaPlayer != null ? mediaPlayer.getDuration() : 0;
    }

    public void seekTo(int i) {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            mediaPlayer.seekTo(i);
        }
    }

    public void setVolume(float f, float f2) {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            try {
                mediaPlayer.setVolume(f, f2);
            } catch (IllegalStateException e) {
                Log.e("pieceTextureVideoView", e.toString());
            }
        }
    }

    public boolean isPlaying() {
        return mediaPlayerNotNull() && this.mediaPlayer.isPlaying();
    }

    public void volume() {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            try {
                mediaPlayer.setVolume(1.0f, 1.0f);
                this.m_boolean = true;
            } catch (IllegalStateException e) {
                Log.i("TextureVideoView", e.toString());
            }
        }
    }

    public void f() {
        AudioManager audioManager = this.audioManager;
        if (audioManager != null && this.mediaPlayer != null) {
            audioManager.requestAudioFocus(null, 3, 1);
            float log = (float) (1.0d - (0.0d / Math.log(100.0d)));
            try {
                this.mediaPlayer.setVolume(log, log);
            } catch (Exception unused) {
            }
            this.m_boolean = false;
        }
    }

    private boolean mediaPlayerNotNull() {
        return (this.mediaPlayer == null || this.c_int == -1 || this.c_int == 0 || this.c_int == 1) ? false : true;
    }

    public void onCompletion(final MediaPlayer mediaPlayer) {
        this.c_int = 5;
        this.d_int = 5;
        if (this.j_interface != null) {
            this.k_handler.post(new Runnable() {
                public void run() {
                    if (TextureVideoView.this.j_interface != null) {
                        TextureVideoView.this.j_interface.b(mediaPlayer);
                    }
                }
            });
        }
    }

    public boolean onError(final MediaPlayer mediaPlayer, final int i, final int i2) {
        this.c_int = -1;
        this.d_int = -1;
        if (this.j_interface != null) {
            this.k_handler.post(new Runnable() {
                public void run() {
                    if (TextureVideoView.this.j_interface != null) {
                        TextureVideoView.this.j_interface.c(mediaPlayer, i, i2);
                    }
                }
            });
        }
        return true;
    }

    public void onPrepared(final MediaPlayer mediaPlayer) {
        String str = "pieceTextureVideoView";
        Log.e(str, " onPrepared :: false");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" c_int :: ");
        stringBuilder.append(this.c_int);
        Log.e(str, stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(" d_int :: ");
        stringBuilder.append(this.d_int);
        Log.e(str, stringBuilder.toString());
        if (this.d_int == 1 && this.c_int == 1) {
            this.c_int = 2;
            if (mediaPlayerNotNull()) {
                volume();
                this.mediaPlayer.start();
                this.c_int = 3;
                this.d_int = 3;
            }
            if (this.j_interface != null) {
                this.k_handler.post(new Runnable() {
                    public void run() {
                        if (TextureVideoView.this.j_interface != null) {
                            TextureVideoView.this.j_interface.a(mediaPlayer);
                        }
                    }
                });
            }
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("onPrepared error targetState ");
        stringBuilder2.append(this.d_int);
        stringBuilder2.append(" currentState ");
        stringBuilder2.append(this.c_int);
        Log.e("TextureVideoView", stringBuilder2.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(" sb2.toString() :: ");
        stringBuilder.append(stringBuilder2.toString());
        Log.e(str, stringBuilder.toString());
    }

    public void onVideoSizeChanged(final MediaPlayer mediaPlayer, final int i, final int i2) {
        if (this.j_interface != null) {
            this.k_handler.post(new Runnable() {
                public void run() {
                    if (i != 0 && i2 != 0 && !TextureVideoView.this.p_boolean) {
                        Matrix a = new Inter_C_Class(new Inner_E_Class(TextureVideoView.this.getWidth(), TextureVideoView.this.getHeight()), new Inner_E_Class(i, i2)).a(TextureVideoView.this.alignment);
                        if (a != null) {
                            TextureVideoView.this.setTransform(a);
                        }
                        if (TextureVideoView.this.j_interface != null) {
                            TextureVideoView.this.j_interface.a(mediaPlayer, i, i2);
                        }
                    }
                }
            });
        }
    }

    public void onBufferingUpdate(final MediaPlayer mediaPlayer, final int i) {
        if (this.j_interface != null) {
            this.k_handler.post(new Runnable() {
                public void run() {
                    if (TextureVideoView.this.j_interface != null) {
                        TextureVideoView.this.j_interface.a(mediaPlayer, i);
                    }
                }
            });
        }
    }

    public boolean onInfo(final MediaPlayer mediaPlayer, final int i, final int i2) {
        if (this.j_interface != null) {
            this.k_handler.post(new Runnable() {
                public void run() {
                    if (TextureVideoView.this.j_interface != null) {
                        TextureVideoView.this.j_interface.b(mediaPlayer, i, i2);
                    }
                }
            });
        }
        return true;
    }
}
