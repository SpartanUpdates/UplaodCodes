package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class n5 implements View.OnTouchListener {
    public final GestureDetector e;

    public n5(final FrameEditorNewDesign frameEditorNewDesign, final GestureDetector e) {
        this.e = e;
    }

    public boolean onTouch(final View view, final MotionEvent motionEvent) {
        this.e.onTouchEvent(motionEvent);
        return true;
    }
}
