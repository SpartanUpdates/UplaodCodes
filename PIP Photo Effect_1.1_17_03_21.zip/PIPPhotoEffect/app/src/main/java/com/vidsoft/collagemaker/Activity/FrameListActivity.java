package com.vidsoft.collagemaker.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Adapters.pipframelistAdapter;
import com.vidsoft.collagemaker.Utils.Stickers.Utility;

public class FrameListActivity extends Activity {
    public static int int_selected_images;
    private pipframelistAdapter piPAdapter;
    private Typeface typeface;
    private GridView gridView;
    private TextView textView;

    static {
        FrameListActivity.int_selected_images = 0;
    }

    private void CameraDialog(final Context context) {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.getWindow().setBackgroundDrawable(
                (Drawable) new ColorDrawable(0));
        final ImageView imageView = (ImageView) dialog
                .findViewById(R.id.dialog_img_camera);
        final ImageView imageView2 = (ImageView) dialog
                .findViewById(R.id.dialog_img_gallery);
        imageView
                .setOnClickListener((View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view) {
                        pipactivity.strImageType = "2";
                        FrameListActivity.this.startActivity(new Intent(
                                (Context) FrameListActivity.this,
                                (Class) pipactivity.class));
                        dialog.dismiss();
                    }
                });
        imageView2
                .setOnClickListener((View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view) {
                        pipactivity.strImageType = "1";
                        FrameListActivity.this.startActivity(new Intent(
                                (Context) FrameListActivity.this,
                                (Class) pipactivity.class));
                        dialog.dismiss();
                    }
                });
        dialog.setOnKeyListener((DialogInterface.OnKeyListener) new DialogInterface.OnKeyListener() {
            public boolean onKey(final DialogInterface dialogInterface,
                                 final int n, final KeyEvent keyEvent) {
                if (n == 4) {
                    FrameListActivity.this.finish();
                    dialog.dismiss();
                }
                return true;
            }
        });
        dialog.show();
    }

    private void initControls() {
        this.gridView = (GridView) this.findViewById(R.id.Img_gridView);
        this.piPAdapter = new pipframelistAdapter((Context) this);
        this.gridView.setAdapter((ListAdapter) this.piPAdapter);
        this.gridView
                .setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
                    public void onItemClick(final AdapterView<?> adapterView,
                                            final View view, final int n, final long n2) {
                        Utility.int_pip_type = n + 1;
                        FrameListActivity.this
                                .CameraDialog((Context) FrameListActivity.this);
                    }
                });
    }

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.gridimageview);
        this.typeface = Typeface.createFromAsset(this.getResources().getAssets(),
                "fonts/header.otf");
        this.textView = (TextView) this.findViewById(R.id.headertitle);
        this.initControls();
    }

    public void onResume() {
        super.onResume();
    }

}
