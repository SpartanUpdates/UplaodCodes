package com.example.womenabsworkout.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.example.womenabsworkout.R;

import java.util.Locale;

public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.ViewHolder> {
    public String[] arr;
    public int[] arr_image;
    public SharedPreferences b;
    public SharedPreferences c;
    public Context context;
    public String d;
    public String[] e = new String[]{"en", "zh", "ru", "fr", "es", "ar", "ja", "de", "ko", "pt", "it", "in", "nl"};
    public SharedPreferences f876a;
    public Editor prefsEditor;

    class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public RadioButton b;
        public RelativeLayout c;
        public TextView f878a;

        public ViewHolder(View view) {
            super(view);
            LanguageAdapter.this.f876a = LanguageAdapter.this.context.getSharedPreferences("radio_button", 0);
            this.f878a = (TextView) view.findViewById(R.id.language_name);
            this.b = (RadioButton) view.findViewById(R.id.radio_button);
            this.c = (RelativeLayout) view.findViewById(R.id.flag_layout);
        }
    }

    public LanguageAdapter(int[] iArr, String[] strArr, Context context) {
        this.arr = strArr;
        this.context = context;
        this.arr_image = iArr;
    }

    public void updateLocale(String str) {
        Locale locale = new Locale(str);
        Resources resources = this.context.getResources();
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        Configuration configuration = resources.getConfiguration();
        configuration.locale = locale;
        resources.updateConfiguration(configuration, displayMetrics);
    }

    public int getItemCount() {
        return this.arr.length;
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        viewHolder.f878a.setText(this.arr[i]);
        boolean z = false;
        SharedPreferences sharedPreferences = this.context.getSharedPreferences("radio_button", 0);
        this.c = sharedPreferences;
        final Editor edit = sharedPreferences.edit();
        RadioButton radioButton = viewHolder.b;
        if (i == this.f876a.getInt("position", 0)) {
            z = true;
        }
        radioButton.setChecked(z);
        viewHolder.c.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                LanguageAdapter.this.notifyDataSetChanged();
                ((Activity) LanguageAdapter.this.context).finish();
                LanguageAdapter languageAdapter = LanguageAdapter.this;
                languageAdapter.d = languageAdapter.e[i];
                edit.putInt("position", i);
                edit.apply();
                languageAdapter = LanguageAdapter.this;
                languageAdapter.b = PreferenceManager.getDefaultSharedPreferences(languageAdapter.context.getApplicationContext());
                languageAdapter = LanguageAdapter.this;
                languageAdapter.prefsEditor = languageAdapter.b.edit();
                LanguageAdapter.this.prefsEditor.putString("languageToLoad", LanguageAdapter.this.d);
                LanguageAdapter.this.prefsEditor.apply();
                languageAdapter = LanguageAdapter.this;
                languageAdapter.updateLocale(languageAdapter.d);
                LanguageAdapter.this.context.startActivity(((Activity) LanguageAdapter.this.context).getIntent());
            }
        });
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.language_row, viewGroup, false));
    }
}
