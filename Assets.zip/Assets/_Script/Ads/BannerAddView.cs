﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using GoogleMobileAds.Api;
public class BannerAddView : MonoBehaviour
{
    public static BannerAddView instance;

    private BannerView bannerView;

    //string bannerID = "ca-app-pub-3940256099942544/6300978111";

    public void Awake()
    {
        instance = this;
        DontDestroyOnLoad(this.gameObject);
        RequestBanner();
    }

    private void OnEnable()
    {
        this.bannerView.OnAdLoaded += this.OnBannerAdLoaded;
        this.bannerView.OnAdFailedToLoad += this.OnBannerAdFailedToLoad;
        this.bannerView.OnAdOpening += this.OnBannerAdOpened;
        this.bannerView.OnAdClosed += this.OnBannerAdClosed;
        this.bannerView.OnAdLeavingApplication += this.OnBannerAdLeavingApplication;
    }

    private void OnDisable()
    {
        bannerView.Destroy();
        this.bannerView.OnAdLoaded -= this.OnBannerAdLoaded;
        this.bannerView.OnAdFailedToLoad -= this.OnBannerAdFailedToLoad;
        this.bannerView.OnAdOpening -= this.OnBannerAdOpened;
        this.bannerView.OnAdClosed -= this.OnBannerAdClosed;
        this.bannerView.OnAdLeavingApplication -= this.OnBannerAdLeavingApplication;
    }
    private void RequestBanner()
    {
        this.bannerView = new BannerView(Manager.instance.bannerID, AdSize.SmartBanner, AdPosition.Bottom);

        AdRequest request = new AdRequest.Builder().Build();

        this.bannerView.LoadAd(request);
    }

    public void ShowBannerAdd()
    {
        this.bannerView.Show();
    }

    public void DestroyBannerAdd()
    {
        bannerView.Hide();
    }


    //Banner Add
    public void OnBannerAdLoaded(object sender, EventArgs args)
    {
        if (!MainSceneManager.instance.shopPanel.activeSelf)
            this.bannerView.Show();
    }

    public void OnBannerAdFailedToLoad(object sender, AdFailedToLoadEventArgs args)
    {
        RequestBanner();
    }

    public void OnBannerAdOpened(object sender, EventArgs args)
    {
    }

    public void OnBannerAdClosed(object sender, EventArgs args)
    {
    }

    public void OnBannerAdLeavingApplication(object sender, EventArgs args)
    {
    }
}
