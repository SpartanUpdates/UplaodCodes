package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.util.Log;
import android.widget.FrameLayout;
import com.kotlinz.festivalstorymaker.activity.CollageMakerDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class CollageTextSticker implements com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1.a {
    public final FrameLayout frameLayout;
    public final TextStickerViewNew1 textStickerViewNew1;
    public final CollageMakerDetailActivity activity;

    public CollageTextSticker(CollageMakerDetailActivity collageMakerDetailActivity, FrameLayout frameLayout, TextStickerViewNew1 textStickerViewNew1) {
        this.frameLayout = frameLayout;
        this.textStickerViewNew1 = textStickerViewNew1;
        this.activity = collageMakerDetailActivity;
    }

    public void a(TextStickerViewNew1 textStickerViewNew1) {
        Log.e("TAG","A Called");
        this.activity.SvScroll.requestDisallowInterceptTouchEvent(true);
        TextStickerViewNew1 textStickerViewNew12 = activity.n0;
        if (textStickerViewNew12 != null) {
            textStickerViewNew12.setInEdit(false);
            this.activity.n0.setShowHelpBox(false);
        }
        this.activity.n0 = textStickerViewNew1;
        textStickerViewNew1.setInEdit(true);
        this.activity.n0.setShowHelpBox(true);
    }

    public void b(TextStickerViewNew1 textStickerViewNew1) {
        Log.e("TAG","B Called");
        this.activity.g0(frameLayout, this.textStickerViewNew1);
    }

    public void c(TextStickerViewNew1 textStickerViewNew1) {
        Log.e("TAG","C Called");
        if (this.activity.n0 != null && textStickerViewNew1.getTag().equals(this.activity.n0.getTag()) && textStickerViewNew1.u) {
            frameLayout.removeView(textStickerViewNew1);
        }
    }

    public void d(TextStickerViewNew1 textStickerViewNew1) {
        Log.e("TAG","D Called");
        activity.o0 = true;
        activity.n0 = textStickerViewNew1;
        activity.r0(true);
    }
}

