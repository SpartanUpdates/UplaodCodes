package com.esc.dailyrandomfacts.util;

import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.Lifecycle.Event;

public class AppLifecycleObserver implements LifecycleObserver {
    @OnLifecycleEvent(Event.ON_START)
    public void onEnterForeground() {
        Quotes.isInBackground = false;
    }

    @OnLifecycleEvent(Event.ON_STOP)
    public void onEnterBackground() {
        Quotes.isInBackground = true;
    }

    @OnLifecycleEvent(Event.ON_DESTROY)
    public void onCloseApp() {
        Quotes.isInBackground = true;
    }
}
