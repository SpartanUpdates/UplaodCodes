package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import android.view.ViewTreeObserver;

import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class o5 implements ViewTreeObserver.OnGlobalLayoutListener {
    public final View e;
    public final FrameEditorNewDesign f;

    public o5(final FrameEditorNewDesign f, final View e) {
        this.f = f;
        this.e = e;
    }

    public void onGlobalLayout() {
        this.e.getViewTreeObserver().removeOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener) this);
        final int size = this.f.n0.size();
        final FrameEditorNewDesign f = this.f;
        final int d0 = f.d0;
        if (size > d0) {
            this.e.setX((float) f.n0.get(d0));
            final View e = this.e;
            final FrameEditorNewDesign f2 = this.f;
            final float floatValue = f2.o0.get(f2.d0);
            final FrameEditorNewDesign f3 = this.f;
            e.setY(f3.p0.get(f3.d0) + floatValue - this.e.getHeight());
        }
    }
}
