package com.esc.lovemessages;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class GifDataBaseHelper extends SQLiteOpenHelper {
    private static String DB_NAME = "lovegifs.db";
    private static String DB_PATH = "";
    private static String TAG = "DataBaseHelper";
    private final Context mContext;
    private SQLiteDatabase mDataBase;
    ArrayList<String> qid;


    public void onCreate(SQLiteDatabase sQLiteDatabase) {
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    public GifDataBaseHelper(Context context) {
        super(context, DB_NAME, null, 1);
        this.mContext = context;
        String str = "/databases/";
        StringBuilder stringBuilder;
        if (VERSION.SDK_INT >= 17) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(context.getApplicationInfo().dataDir);
            stringBuilder.append(str);
            DB_PATH = stringBuilder.toString();
            return;
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append("/data/data/");
        stringBuilder.append(context.getPackageName());
        stringBuilder.append(str);
        DB_PATH = stringBuilder.toString();
    }


    public void createDataBase() throws IOException {
        if (!checkDataBase()) {
            getReadableDatabase();
            close();
            try {
                copyDataBase();
                Log.e(TAG, "createDatabase database created");
                int i = 0;
                while (i < this.qid.size()) {
                    try {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("favorite", Integer.valueOf(1));
                        this.mDataBase = getWritableDatabase();
                        try {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("msg_id=");
                            stringBuilder.append((String) this.qid.get(i));
                            this.mDataBase.update("message", contentValues, stringBuilder.toString(), null);
                        } catch (Exception unused) {
                            unused.printStackTrace();
                        }
                        i++;
                    } catch (Exception unused2) {
                        return;
                    }
                }
            } catch (IOException e) {
                String str = TAG;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("");
                stringBuilder2.append(e);
                Log.e(str, stringBuilder2.toString());
                throw new Error("ErrorCopyingDataBase");
            }
        }

    }


    private boolean checkDataBase() {

        return true;
    }

    private void copyDataBase() throws IOException {
        InputStream open = this.mContext.getAssets().open(DB_NAME);
        byte[] bArr = new byte[2048];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DB_PATH);
        stringBuilder.append(DB_NAME);
        FileOutputStream fileOutputStream = new FileOutputStream(stringBuilder.toString());
        while (open.read(bArr) > 0) {
            fileOutputStream.write(bArr);
        }
        open.close();
        fileOutputStream.flush();
        fileOutputStream.close();
    }

    public boolean openDataBase() throws SQLException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DB_PATH);
        stringBuilder.append(DB_NAME);
        this.mDataBase = SQLiteDatabase.openDatabase(stringBuilder.toString(), null, 0);
        if (this.mDataBase != null) {
            return true;
        }
        return false;
    }

    public synchronized void close() {
        if (this.mDataBase != null) {
            this.mDataBase.close();
        }
        super.close();
    }

    public ArrayList<String> GetAllSubCategories(String str) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select subsectionname from pageinfo order by SubSectionId DESC", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> GetAllSubCategoriesCount(String str) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select count(mid) from messagedetails GROUP by SubSectionId ORDER by SubSectionId DESC", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public int GetSubSectionId(String str) {
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select SubSectionId from pageinfo where subsectionname = '");
        stringBuilder.append(str);
        stringBuilder.append("'");
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        int i = 0;
        while (rawQuery.moveToNext()) {
            i = rawQuery.getInt(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return i;
    }

    public ArrayList<String> GetAllGifText(int i) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select m.message from messages m, messagedetails d where m.mid=d.mid and d.SubSectionId = ");
        stringBuilder.append(i);
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<Integer> GetAllGifID(int i) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select m.mid from messages m, messagedetails d where m.mid=d.mid and d.SubSectionId = ");
        stringBuilder.append(i);
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(Integer.valueOf(rawQuery.getInt(0)));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<Integer> GetAllFavoriteGif(int i) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select m.favorite from messages m, messagedetails d where m.mid=d.mid and d.SubSectionId = ");
        stringBuilder.append(i);
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(Integer.valueOf(rawQuery.getInt(0)));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public String GetsectionIdForURL(int i) {
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select sectionId from pageinfo where SubSectionId=");
        stringBuilder.append(i);
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        String str = "";
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }

    public String GetURL(int i) {
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select Url from pageinfo where SubSectionId=");
        stringBuilder.append(i);
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        String str = "";
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }

    public boolean updateFavorite(int i, int i2) {
        String str = " ";
        String str2 = "Update";
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("favorite", Integer.valueOf(i));
            this.mDataBase = getWritableDatabase();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("mid=");
            stringBuilder.append(i2);
            int update = this.mDataBase.update("messages", contentValues, stringBuilder.toString(), null);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("informationupdated ");
            stringBuilder2.append(Integer.toString(update));
            stringBuilder2.append(str);
            stringBuilder2.append(Integer.toString(i2));
            stringBuilder2.append(str);
            stringBuilder2.append(Integer.toString(i));
            Log.e(str2, stringBuilder2.toString());
            this.mDataBase.close();
            return true;
        } catch (Exception e) {
            Log.d(str2, e.toString());
            this.mDataBase.close();
            return false;
        }
    }

    public ArrayList<String> GetAllFavoriteGifText() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select message from messages where favorite = 1 ORDER BY mid", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<Integer> GetAllFavoriteGifID() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select mid from messages where favorite = 1 ORDER BY mid", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(Integer.valueOf(rawQuery.getInt(0)));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<Integer> GetAllFavoriteGifF() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select favorite from messages where favorite = 1 ORDER BY mid", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(Integer.valueOf(rawQuery.getInt(0)));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> GetAllFavoriteURL() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("SELECT p.Url from pageinfo p, messagedetails d, messages m \nWHERE m.mid=d.mid AND d.SubSectionId=p.SubSectionId AND m.favorite=1 ORDER BY m.mid", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> GetsectionIdForFavoriteURL() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("SELECT p.sectionId from pageinfo p, messagedetails d, messages m \nWHERE m.mid=d.mid AND d.SubSectionId=p.SubSectionId AND m.favorite=1 ORDER BY m.mid", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }
}
