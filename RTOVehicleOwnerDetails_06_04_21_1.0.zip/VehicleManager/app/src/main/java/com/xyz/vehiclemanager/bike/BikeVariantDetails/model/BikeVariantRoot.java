package com.xyz.vehiclemanager.bike.BikeVariantDetails.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class BikeVariantRoot
{
    @SerializedName("statusCode")
    public String statusCode;
    @SerializedName("statusMessage")
    public String statusMessage;
    @SerializedName("details")
    public Details details;

    public class Details
    {
        @SerializedName("id")
        public int id;
        @SerializedName("variantName")
        public String variantName;
        @SerializedName("variantSlug")
        public String variantSlug;
        @SerializedName("variantSpecs")
        public String variantSpecs;
        @SerializedName("engineDisplacement")
        public String engineDisplacement;
        @SerializedName("mileage")
        public String mileage;
        @SerializedName("maxPower")
        public String maxPower;
        @SerializedName("kerbWeight")
        public String kerbWeight;
        @SerializedName("variantPrice")
        public String variantPrice;
        public ArrayList<BikeOverview> overview;
        public ArrayList<BikeSpecification> specifications;
        public ArrayList<BikeFeatures> features;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getVariantName() {
            return variantName;
        }

        public void setVariantName(String variantName) {
            this.variantName = variantName;
        }

        public String getVariantSlug() {
            return variantSlug;
        }

        public void setVariantSlug(String variantSlug) {
            this.variantSlug = variantSlug;
        }

        public String getVariantSpecs() {
            return variantSpecs;
        }

        public void setVariantSpecs(String variantSpecs) {
            this.variantSpecs = variantSpecs;
        }

        public String getEngineDisplacement() {
            return engineDisplacement;
        }

        public void setEngineDisplacement(String engineDisplacement) {
            this.engineDisplacement = engineDisplacement;
        }

        public String getMileage() {
            return mileage;
        }

        public void setMileage(String mileage) {
            this.mileage = mileage;
        }

        public String getMaxPower() {
            return maxPower;
        }

        public void setMaxPower(String maxPower) {
            this.maxPower = maxPower;
        }

        public String getKerbWeight() {
            return kerbWeight;
        }

        public void setKerbWeight(String kerbWeight) {
            this.kerbWeight = kerbWeight;
        }

        public String getVariantPrice() {
            return variantPrice;
        }

        public void setVariantPrice(String variantPrice) {
            this.variantPrice = variantPrice;
        }

        public ArrayList<BikeOverview> getOverview() {
            return overview;
        }

        public void setOverview(ArrayList<BikeOverview> overview) {
            this.overview = overview;
        }

        public ArrayList<BikeSpecification> getSpecifications() {
            return specifications;
        }

        public void setSpecifications(ArrayList<BikeSpecification> specifications) {
            this.specifications = specifications;
        }

        public ArrayList<BikeFeatures> getFeatures() {
            return features;
        }

        public void setFeatures(ArrayList<BikeFeatures> features) {
            this.features = features;
        }
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public Details getDetails() {
        return details;
    }

    public void setDetails(Details details) {
        this.details = details;
    }
}
