package com.esc.phoneheart.activity;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.esc.phoneheart.R;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.pref.SharedPrefUtil;
import com.esc.phoneheart.utility.TimerView;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.DecimalFormat;
import java.util.Timer;
import java.util.TimerTask;

public class JunkDeleteAnimationScreen extends BaseActivity {
    public LinearLayout clippedLayout;
    public ImageView imgBin;
    public boolean isfirsttime;
    public float mmmmmm;
    public String size;
    public TimerView tView;
    public TextView txtSize;
    public String type;

    private void init() {
        this.clippedLayout = (LinearLayout) findViewById(R.id.delete_layout);
        this.imgBin = (ImageView) findViewById(R.id.delete_icon_junkanim);
        this.txtSize = (TextView) findViewById(R.id.tv_size_junkdelete);
        this.tView = (TimerView) findViewById(R.id.tView);
    }

    private void loadInterstitialORnot() {
        char c;
        String str = this.type;
        switch (str.hashCode()) {
            case -1813183603:
                if (str.equals("Social")) {
                    c = 1;
                    break;
                }
            case -1382453013:
                if (str.equals("NOTIFICATION")) {
                    c = 0;
                    break;
                }
            case 2288712:
                if (str.equals("JUNK")) {
                    c = 3;
                    break;
                }
            case 63384451:
                if (str.equals("BOOST")) {
                    c = 4;
                    break;
                }
            case 1993540022:
                if (str.equals("COOLER")) {
                    c = 2;
                    break;
                }
            default:
                c = 65535;
                break;
        }
        if (c == 0 || c == 1) {
            switchScreen();
        } else if (c == 2) {
            StringBuilder sb = new StringBuilder();
            sb.append("wwwww");
            sb.append(this.type);
            Log.e("!!!!!!CPU", sb.toString());
            switchScreen();
        } else if (c == 3) {
            try {
                switchScreen();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (c != 4) {
            try {
                switchScreen();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                switchScreen();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
    }

    private float readUsage() {
        IOException e;
        String str = " +";
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("/proc/stat", "r");
            String[] split = randomAccessFile.readLine().split(str);
            long parseLong = Long.parseLong(split[4]);
            long parseLong2 = ((((Long.parseLong(split[2]) + Long.parseLong(split[3])) + Long.parseLong(split[5])) + Long.parseLong(split[6])) + Long.parseLong(split[7])) + Long.parseLong(split[8]);
            try {
                Thread.sleep(360);
            } catch (Exception unused) {
            }
            randomAccessFile.seek(0);
            String readLine = randomAccessFile.readLine();
            randomAccessFile.close();
            String[] split2 = readLine.split(str);
            long parseLong3 = ((((Long.parseLong(split2[2]) + Long.parseLong(split2[3])) + Long.parseLong(split2[5])) + Long.parseLong(split2[6])) + Long.parseLong(split2[7])) + Long.parseLong(split2[8]);
            float parseLong4 = ((float) (parseLong3 - parseLong2)) / ((float) ((parseLong3 + Long.parseLong(split2[4])) - (parseLong2 + parseLong)));
            this.mmmmmm = parseLong4;
            return parseLong4;
        } catch (IOException e3) {
            e = e3;
            e.printStackTrace();
            return 0.0f;
        }
    }

    private void setAnimation() {
        new Handler().postDelayed(new Runnable() {
            public void run() {
                JunkDeleteAnimationScreen.this.clippedLayout.setVisibility(View.VISIBLE);
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(JunkDeleteAnimationScreen.this.imgBin, "rotationY", new float[]{0.0f, 180.0f});
                ofFloat.setDuration(1500);
                ofFloat.setInterpolator(new AccelerateDecelerateInterpolator());
                ofFloat.start();
                if (JunkDeleteAnimationScreen.this.type.equalsIgnoreCase("junk")) {
                    JunkDeleteAnimationScreen.this.txtSize.setVisibility(View.VISIBLE);
                    JunkDeleteAnimationScreen.this.txtSize.setAnimation(AnimationUtils.loadAnimation(JunkDeleteAnimationScreen.this.getApplicationContext(), R.anim.zoom_in));
                    if (JunkDeleteAnimationScreen.this.size != null) {
                        JunkDeleteAnimationScreen.this.size.toLowerCase().contains("folder");
                    }
                } else if (JunkDeleteAnimationScreen.this.type.equalsIgnoreCase("Social")) {
                    JunkDeleteAnimationScreen.this.txtSize.setVisibility(View.VISIBLE);
                    JunkDeleteAnimationScreen.this.txtSize.setAnimation(AnimationUtils.loadAnimation(JunkDeleteAnimationScreen.this.getApplicationContext(), R.anim.zoom_in));
                } else if (JunkDeleteAnimationScreen.this.type.equalsIgnoreCase("boost")) {
                    JunkDeleteAnimationScreen.this.txtSize.setVisibility(View.VISIBLE);
                    JunkDeleteAnimationScreen.this.txtSize.setAnimation(AnimationUtils.loadAnimation(JunkDeleteAnimationScreen.this.getApplicationContext(), R.anim.zoom_in));
                } else if (JunkDeleteAnimationScreen.this.type.equalsIgnoreCase("AV")) {
                    JunkDeleteAnimationScreen.this.txtSize.setVisibility(View.VISIBLE);
                    JunkDeleteAnimationScreen.this.txtSize.setAnimation(AnimationUtils.loadAnimation(JunkDeleteAnimationScreen.this.getApplicationContext(), R.anim.zoom_in));
                } else if (JunkDeleteAnimationScreen.this.type.equalsIgnoreCase("NOTIFICATION")) {
                    JunkDeleteAnimationScreen.this.txtSize.setVisibility(View.VISIBLE);
                    if (JunkDeleteAnimationScreen.this.size.equalsIgnoreCase("1")) {
                        JunkDeleteAnimationScreen.this.txtSize.setText(JunkDeleteAnimationScreen.this.getResources().getString(R.string.cleaning));
                    } else {
                        TextView f = JunkDeleteAnimationScreen.this.txtSize;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("");
                        stringBuilder.append(JunkDeleteAnimationScreen.this.size);
                        stringBuilder.append(" ");
                        f.setText(stringBuilder.toString());
                    }
                    JunkDeleteAnimationScreen.this.txtSize.setAnimation(AnimationUtils.loadAnimation(JunkDeleteAnimationScreen.this.getApplicationContext(), R.anim.zoom_in));
                } else {
                    JunkDeleteAnimationScreen.this.findViewById(R.id.tv_size_junkdelete).setVisibility(View.GONE);
                    JunkDeleteAnimationScreen.this.txtSize.setVisibility(View.INVISIBLE);
                }
            }
        }, 1000);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                JunkDeleteAnimationScreen.this.tView.start(1);
            }
        }, 200);
    }

    private void switchScreen() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("switchScreen ");
        stringBuilder.append(this.type);
        Log.e("----------MMMMM", stringBuilder.toString());
        String str = "COOLER";
        boolean equalsIgnoreCase = this.type.equalsIgnoreCase(str);
        String str2 = "TYPE";
        String str3 = GlobalData.REDIRECTNOTI;
        String str4 = "";
        String str5 = "DATA";
        Intent intent;
        StringBuilder stringBuilder2;
        if (equalsIgnoreCase) {
            intent = new Intent(this, FinalScreen.class);
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str4);
            stringBuilder2.append(this.size);
            intent.putExtra(str5, stringBuilder2.toString());
            intent.putExtra(str3, true);
            intent.putExtra(str2, str);
            finish();
            startActivity(intent);
            return;
        }
        str = "JUNK";
        if (this.type.equalsIgnoreCase(str)) {
            intent = new Intent(this, FinalScreen.class);
            this.isfirsttime = false;
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str4);
            stringBuilder2.append(this.size);
            intent.putExtra(str5, stringBuilder2.toString());
            intent.putExtra(str2, str);
            intent.putExtra(str3, true);
            finish();
            startActivity(intent);
            Log.d("TAG", "The interstitial wasn't loaded yet.");
            return;
        }
        str = "AV";
        if (this.type.equalsIgnoreCase(str)) {
            intent = new Intent(this, FinalScreen.class);
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(str4);
            stringBuilder3.append(this.size);
            intent.putExtra(str5, stringBuilder3.toString());
            intent.putExtra(str2, str);
            finish();
            startActivity(intent);
            return;
        }
        str = "NOTIFICATION";
        StringBuilder stringBuilder4;
        if (this.type.equalsIgnoreCase(str)) {
            intent = new Intent(this, FinalScreen.class);
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str4);
            stringBuilder2.append(this.size);
            intent.putExtra(str5, stringBuilder2.toString());
            intent.putExtra(str2, str);
            intent.putExtra(str3, true);
            finish();
            startActivity(intent);
        } else if (this.type.equalsIgnoreCase("Social")) {
            intent = new Intent(this, FinalScreen.class);
            stringBuilder4 = new StringBuilder();
            stringBuilder4.append(str4);
            stringBuilder4.append(this.size);
            intent.putExtra(str5, stringBuilder4.toString());
            intent.putExtra(str3, getIntent().getBooleanExtra(str3, false));
            String str6 = "FROMNOTI";
            intent.putExtra(str6, getIntent().getBooleanExtra(str6, false));
            intent.putExtra(str2, "SOCIAL");
            finish();
            startActivity(intent);
        } else {
            intent = new Intent(this, FinalScreen.class);
            this.isfirsttime = false;
            stringBuilder4 = new StringBuilder();
            stringBuilder4.append(str4);
            stringBuilder4.append(this.size);
            intent.putExtra(str5, stringBuilder4.toString());
            intent.putExtra(str2, "BOOST");
            intent.putExtra(str3, true);
            startActivity(intent);
            finish();
        }
    }

    public void onBackPressed() {
    }

    public void onCreate(Bundle bundle) {
        String str = "";
        super.onCreate(bundle);
        GlobalData.SETAPPLAnguage(this);
        setContentView(R.layout.activity_junk_delete_animation_screen);
        this.isfirsttime = true;
        try {
            SharedPrefUtil sharedPrefUtil = new SharedPrefUtil(this);
            String str2 = SharedPrefUtil.LASTTIMEJUNKCLEANED;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(System.currentTimeMillis());
            stringBuilder.append(str);
            sharedPrefUtil.saveString(str2, stringBuilder.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.type = getIntent().getStringExtra("TYPE");
        this.size = getIntent().getStringExtra("DATA");
        init();
        findViewById(R.id.activity_junk_delete_animation_screen).setPadding(0, (BaseActivity.displaymetrics.heightPixels * 20) / 100, 0, 0);
        if (this.type.equalsIgnoreCase("AV")) {
            this.txtSize.setText(this.size);
            this.txtSize.setTextSize(15.0f);
        } else {
            String[] split = this.size.split(" ");
            TextView textView2;
            StringBuilder stringBuilder2;
            if (this.type.equalsIgnoreCase("COOLER")) {
                textView2 = this.txtSize;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(this.size);
                textView2.setText(stringBuilder2.toString());
            } else {
                try {
                    if (this.size == null || !this.size.toLowerCase().contains("folder")) {
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(split[0]);
                        stringBuilder3.append("<sup><small><small>");
                        stringBuilder3.append(split[1]);
                        stringBuilder3.append("<small></small></sup>");
                        txtSize.setText(Html.fromHtml(stringBuilder3.toString()));
                    } else {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(this.size);
                        stringBuilder2.append(str);
                        txtSize.setText(stringBuilder2.toString());
                    }
                } catch (Exception e2) {
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append(str);
                    stringBuilder4.append(this.size);
                    txtSize.setText(stringBuilder4.toString());
                    e2.printStackTrace();
                }
            }
            StringBuilder stringBuilder5 = new StringBuilder();
            stringBuilder5.append(str);
            stringBuilder5.append(this.size);
            Log.e("------", stringBuilder5.toString());
        }
        setAnimation();
        new Timer().schedule(new TimerTask() {
            public void run() {
                JunkDeleteAnimationScreen.this.readUsage();
                JunkDeleteAnimationScreen.this.runOnUiThread(new Runnable() {
                    public void run() {
                        try {
                            new DecimalFormat(".0#").format((double) JunkDeleteAnimationScreen.this.mmmmmm).replace(".", "");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        }, 3000, 5000);
        loadInterstitialORnot();
    }
}
