package com.example.postermaker.textitems;

import android.view.View;
import android.view.View.OnClickListener;
import com.example.postermaker.eaz_EditActivity;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar.OnProgressChangeListener;

public class eaz_TextShadow implements OnClickListener, OnProgressChangeListener {
    public void onStartTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public void onStopTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public void showShadowItems()
    {
        eaz_EditActivity.textshadowLayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.shadowup.setOnProgressChangeListener(this);
        eaz_EditActivity.shadowdown.setOnProgressChangeListener(this);
        eaz_EditActivity.okshadow.setOnClickListener(this);
        eaz_EditActivity.cancelshadow.setOnClickListener(this);
    }

    public void onClick(View view)
    {
        if (view.equals(eaz_EditActivity.okshadow))
        {
            eaz_EditActivity.textshadowLayout.setVisibility(View.GONE);
        }
        else if (view.equals(eaz_EditActivity.cancelshadow))
        {
            eaz_EditActivity.logoText.setShadowLayer(0.0f, 0.0f, 0.0f, -16777216);
            eaz_EditActivity.textshadowLayout.setVisibility(View.GONE);
        }
    }

    public void onProgressChanged(DiscreteSeekBar discreteSeekBar, int i, boolean z)
    {
        float f;
        if (discreteSeekBar.equals(eaz_EditActivity.shadowdown))
        {
            float f2 = (float) i;
            f = (float) (-i);
            eaz_EditActivity.logoText.setShadowLayer(f2, f, f, -16777216);
        } else if (discreteSeekBar.equals(eaz_EditActivity.shadowup))
        {
            f = (float) i;
            eaz_EditActivity.logoText.setShadowLayer(f, f, f, -16777216);
        }
    }
}
