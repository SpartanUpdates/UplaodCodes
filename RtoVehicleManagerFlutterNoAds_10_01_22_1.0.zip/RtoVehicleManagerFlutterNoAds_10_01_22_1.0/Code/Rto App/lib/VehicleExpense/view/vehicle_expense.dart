import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:rto_app/Home%20Screen/themes.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:rto_app/VehicleExpense/controller/vehicle_expense_controller.dart';
import 'package:rto_app/VehicleExpense/model/vehicle_expense_model.dart';
import 'package:rto_app/VehicleExpense/view/vehicle_expense_category.dart';
import 'package:velocity_x/src/flutter/center.dart';
import 'package:velocity_x/src/flutter/padding.dart';
import 'package:velocity_x/src/flutter/text.dart';

class VehicleExpense extends StatelessWidget {
  static bool isDataAvailable = false;
  VehicleExpenseController controller = Get.put(VehicleExpenseController());

  loadData() async {
    controller.getAllData();
    controller.getDateWiseData();
    controller.getTotal();
  }

  @override
  Widget build(BuildContext context) {
    loadData();
    return WillPopScope(
      onWillPop: () {
        Future.delayed(const Duration(milliseconds: 350), () {
          Navigator.pop(context);
        });
        return Future.value(false);
      },
      child: Material(
        child: SafeArea(
          child: Scaffold(
            backgroundColor: Theme.of(context).primaryColor,
            body: NestedScrollView(
              physics: BouncingScrollPhysics(),
              floatHeaderSlivers: true,
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return <Widget>[
                  SliverAppBar(
                    backgroundColor: Theme.of(context).primaryColor,
                    title: Text(
                      "Vehicle Expense",
                      style: TextStyle(
                          fontSize: 16.5,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Bold"),
                    ).centered(),
                    leading: Container(
                      padding: EdgeInsets.all(10),
                      child: Material(
                        color: Colors.transparent,
                        shape: CircleBorder(),
                        clipBehavior: Clip.hardEdge,
                        child: IconButton(
                            padding: EdgeInsets.zero,
                            onPressed: () {
                              Future.delayed(const Duration(milliseconds: 350),
                                  () {
                                Navigator.pop(context);
                              });
                            },
                            icon: Hero(
                              tag: "vehicleexpense",
                              transitionOnUserGestures: true,
                              child: Icon(
                                Icons.arrow_back_ios_rounded,
                                color: Theme.of(context).dividerColor,
                                size: 20,
                              ).pOnly(left: 5),
                            )),
                      ),
                    ),
                    actions: [
                      IconButton(
                        onPressed: () {
                          Get.to(VehicleExpenseCategory());
                        },
                        icon: Hero(
                            tag: "expense",
                            transitionOnUserGestures: true,
                            child: (Icon(
                              CupertinoIcons.add_circled,
                              color: Theme.of(context).dividerColor,
                              size: 24,
                            ))),
                        iconSize: 30,
                      ).pOnly(right: 8),
                    ],
                  )
                ];
              },
              body: GetBuilder<VehicleExpenseController>(
                builder: (controller) {
                  return controller.dateList.length <= 0
                      ? Container(
                          color: Theme.of(context).primaryColor,
                          child: Center(
                            child: noExpenseMethod(),
                          ),
                        )
                      : Expanded(
                          child: Container(
                            padding: EdgeInsets.only(top: 15),
                            color: Theme.of(context).primaryColor,
                            child: Column(
                              children: [
                                Container(
                                  height: 75,
                                  child: Card(
                                      margin: EdgeInsets.zero,
                                      elevation: 0,
                                      color: Theme.of(context).canvasColor,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(8)),
                                      child: Row(
                                        children: [
                                          Card(
                                            color:
                                                Theme.of(context).primaryColor,
                                            elevation: 0,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(25),
                                                side: BorderSide(
                                                    width: 0.3,
                                                    color: Theme.of(context)
                                                        .primaryColor)),
                                            child: Container(
                                              padding: EdgeInsets.all(3),
                                              height: 40,
                                              width: 40,
                                              child: Image.asset(
                                                  "assets/images/rupee.png"),
                                            ),
                                          ).px(20),
                                          Expanded(
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                          "Total Amount : ${controller.total.toString()}",
                                                          style: TextStyle(
                                                              fontFamily:
                                                                  "Circular Medium",
                                                              color: Theme.of(
                                                                      context)
                                                                  .accentColor))
                                                      .text
                                                      .size(16)
                                                      .make(),
                                                ).py(2),
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                          "From ${controller.allDataList[0].date} to ${controller.allDataList[controller.allDataList.length - 1].date}",
                                                          style: TextStyle(
                                                              fontFamily:
                                                                  "Circular Medium",
                                                              color:
                                                                  Colors.grey))
                                                      .text
                                                      .size(14)
                                                      .make(),
                                                ).py(2),
                                              ],
                                            ),
                                          )
                                        ],
                                      )).px(20).py(5),
                                ),
                                Expanded(
                                  child: GetBuilder<VehicleExpenseController>(
                                    builder: (controller) {
                                      return Container(
                                        width: double.infinity,
                                        child: Card(
                                                margin: EdgeInsets.zero,
                                                elevation: 0,
                                                color: Theme.of(context)
                                                    .primaryColor,
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            12)),
                                                child:
                                                    ShowExpenseData(controller))
                                            .px(17)
                                            .py(10),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ShowExpenseData extends StatelessWidget {
  VehicleExpenseController controller;
  ShowExpenseData(this.controller);
  @override
  Widget build(BuildContext context) {
    return Container(
      child: GetBuilder<VehicleExpenseController>(
        builder: (controller) {
          return ListView.builder(
              shrinkWrap: true,
              physics: BouncingScrollPhysics(),
              itemCount: controller.dateList.length,
              itemBuilder: (context, index) {
                VehicleExpenseModel model = controller.dateList[index];
                List<VehicleExpenseModel> subList = [];
                for (int i = 0; i < controller.allDataList.length; i++) {
                  if (model.date == controller.allDataList[i].date) {
                    subList.add(controller.allDataList[i]);
                  }
                }
                return Card(
                  color: Theme.of(context).canvasColor,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                  child: InkWell(
                    customBorder: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                    onTap: () {},
                    splashColor: MyThemes.skyBlue,
                    child: Theme(
                      data: Theme.of(context)
                          .copyWith(dividerColor: Colors.transparent),
                      child: ExpansionTile(
                        title: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            controller.dateList[index].date.toString(),
                            style: TextStyle(
                                fontSize: 15.5,
                                color: Theme.of(context).accentColor,
                                fontFamily: "Circular Medium"),
                          ),
                        ).pOnly(top: 3),
                        trailing: Card(
                          color: Theme.of(context).primaryColor,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25),
                              side: BorderSide(
                                  width: 0.3,
                                  color: Theme.of(context).primaryColor)),
                          child: Container(
                            padding: EdgeInsets.all(1),
                            height: 40,
                            width: 40,
                            child: Icon(
                              Icons.date_range_rounded,
                              color: Theme.of(context).dividerColor,
                            ),
                          ),
                        ),
                        children: <Widget>[
                          ListView.builder(
                            physics: BouncingScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: subList.length,
                            itemBuilder: (context, index2) {
                              return Card(
                                color: Theme.of(context).primaryColor,
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: InkWell(
                                    customBorder: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8)),
                                    onTap: () {
                                      CommanDialog.deleteMileageDataDialog(
                                          context,
                                          "Are you sure want to delete ?",
                                          controller,
                                          subList[index2].randomId,
                                          "");
                                    },
                                    splashColor: MyThemes.skyBlue,
                                    child: Container(
                                      padding: EdgeInsets.all(0),
                                      child: ListTile(
                                        leading: Container(
                                            child: subList[index2].type == "1"
                                                ? Image.asset(
                                                    "assets/images/assesories.png",
                                                    height: 40,
                                                    width: 40,
                                                  )
                                                : subList[index2].type == "2"
                                                    ? Image.asset(
                                                        "assets/images/cleaning.png",
                                                        height: 40,
                                                        width: 40)
                                                    : subList[index2].type ==
                                                            "3"
                                                        ? Image.asset(
                                                            "assets/images/car_fuel.png",
                                                            height: 40,
                                                            width: 40)
                                                        : subList[index2]
                                                                    .type ==
                                                                "4"
                                                            ? Image.asset(
                                                                "assets/images/maintenance.png",
                                                                height: 40,
                                                                width: 40)
                                                            : Image.asset(
                                                                "assets/images/other.png",
                                                                height: 40,
                                                                width: 40)),
                                        title: Text(subList[index2].itemName,
                                                style: TextStyle(
                                                    fontFamily:
                                                        "Circular Medium",
                                                    color: Theme.of(context)
                                                        .accentColor))
                                            .text
                                            .size(16)
                                            .make()
                                            .py(3.5),
                                        subtitle: Text(subList[index2].note,
                                                style: TextStyle(
                                                    fontFamily:
                                                        "Circular Medium",
                                                    color: Colors.grey))
                                            .text
                                            .size(14)
                                            .make()
                                            .py(3.5),
                                        trailing: Text(
                                                "₹ ${subList[index2].amount}",
                                                style: TextStyle(
                                                    fontFamily:
                                                        "Circular Medium",
                                                    color: Colors.redAccent))
                                            .text
                                            .size(15)
                                            .make(),
                                      ),
                                    )),
                              ).px(5).pOnly(bottom: 3);
                            },
                          ),
                        ],
                        onExpansionChanged: (bool expanded) {},
                      ),
                    ),
                  ),
                );
              });
        },
      ),
    );
  }
}

noExpenseMethod() {
  return Container(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Lottie.asset(
          "assets/lottie/add_data.json",
          height: 200,
          width: 200,
        ),
        Text("Please add expense data",
            style: TextStyle(
                fontFamily: "Circular Medium",
                fontSize: 12,
                color: Colors.grey))
      ],
    ).pOnly(bottom: 80),
  );
}
