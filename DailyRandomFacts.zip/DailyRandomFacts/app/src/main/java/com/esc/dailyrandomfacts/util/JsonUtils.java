package com.esc.dailyrandomfacts.util;

import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.esc.dailyrandomfacts.model.Theme;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class JsonUtils {
    public static String getThemesJson(Context context) {
        try {
            InputStream open = context.getAssets().open("themes.json");
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            return new String(bArr, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static ArrayList<Theme> getThemes(Context context) {
        return (ArrayList) new Gson().fromJson(getThemesJson(context), new TypeToken<ArrayList<Theme>>() {
        }.getType());
    }
}
