﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class SoundManger : MonoBehaviour
{
    public static SoundManger instance;

    public AudioSource btnClick, keyGet, inkGet, objHit, gameOver, gameFinish, itemPurchase, coinGet;

    public AudioSource bgMainMusic, bgPlayMusic;

    public bool isVibrate = true;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            Destroy(this.gameObject);
        }
       
        MuteSound();
        MuteMusic();
        if (PlayerPrefs.GetInt("VibrateOn") == 0)
        {
            isVibrate = true;
        }
        else
        {
            isVibrate = false;
        }

    }
    public void Vibrate()
    {
        if (isVibrate)
            Vibration.Vibrate(40);
    }
    public void MuteMusic()
    {
        if (PlayerPrefs.GetInt("MusicOn") == 0)
        {
            bgMainMusic.mute = false;
            bgPlayMusic.mute = false;
        }
        else
        {
            bgPlayMusic.mute = true;
            bgMainMusic.mute = true;
        }
    }
    public void MuteSound()
    {
        if (PlayerPrefs.GetInt("SoundOn") == 0)
        {
            btnClick.mute = false;
            keyGet.mute = false;
            inkGet.mute = false;
            objHit.mute = false;
            gameOver.mute = false;
            gameFinish.mute = false;
            itemPurchase.mute = false;
            coinGet.mute = false;
        }
        else
        {
            btnClick.mute = true;
            keyGet.mute = true;
            inkGet.mute = true;
            objHit.mute = true;
            gameOver.mute = true;
            gameFinish.mute = true;
            itemPurchase.mute = true;
            coinGet.mute = true;
        }
    }
}

    //void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    //{
    //    if (PlayerPrefs.GetInt("MusicOn") == 0)
    //    {
    //        if (SceneManager.GetActiveScene().name == "MainScene")
    //        {
    //            bgMainMusic.Play();
    //            bgPlayMusic.Stop();
    //        }
    //        else
    //        {

    //        }
    //    }
    //}
    //void OnDisable()
    //{
    //    SceneManager.sceneLoaded -= OnSceneLoaded;
    //}
    //void OnEnable()
    //{
    //    SceneManager.sceneLoaded += OnSceneLoaded;
    //}
