package com.esc.socialmediacleaner.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

public class SavedData {
    private static final String ACCEPT = "ACCEPT";
    private static final String ADS_PRIORITY = "ads_priority";
    private static final String FIRST_LAUNCH = "first_launch";
    private static String LOGIN_STATUS = "login_status";
    public static final String RATED = "RATED";
    public static final String RATED_AT = "RATED_AT";
    private static final String REFFER_CODE = "reffer";
    public static final String RES_VCOUNT = "RES_VCOUNT";
    private static final String USER_SP = "def_spr";
    public static final String VISIT_COUNT = "VISIT_COUNT";
    private Context mContext;
    private SharedPreferences sharedPreferences;

    public SavedData(Context context) {
        this.mContext = context;
        try {
            this.sharedPreferences = context.getSharedPreferences(USER_SP, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveString(String str, String str2) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        edit.putString(str, str2);
        edit.apply();
    }

    public String getString(String str) {
        return this.mContext.getSharedPreferences(USER_SP, 0).getString(str, null);
    }

    public void saveBoolean(String str, boolean z) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        edit.putBoolean(str, z);
        edit.apply();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(z);
        Log.e(str, stringBuilder.toString());
    }

    public boolean getBooleanToggle(String str) {
        return this.mContext.getSharedPreferences(USER_SP, 0).getBoolean(str, true);
    }

    public void saveBooleanToggle(String str, boolean z) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        edit.putBoolean(str, z);
        edit.apply();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(z);
        Log.e(str, stringBuilder.toString());
    }

    public boolean getBoolean(String str) {
        SharedPreferences sharedPreferences = this.mContext.getSharedPreferences(USER_SP, 0);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(sharedPreferences.getBoolean(str, false));
        Log.e(str, stringBuilder.toString());
        return sharedPreferences.getBoolean(str, false);
    }

    public void saveInt(String str, int i) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        edit.putInt(str, i);
        edit.apply();
    }

    public int getInt(String str) {
        return this.mContext.getSharedPreferences(USER_SP, 0).getInt(str, 0);
    }

    public void saveLong(String str, long j) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        edit.putLong(str, j);
        edit.apply();
    }

    public long getLong(String str) {
        return this.mContext.getSharedPreferences(USER_SP, 0).getLong(str, 0);
    }

    public static void clearPreferences(Context context) {
        Editor edit = context.getSharedPreferences(USER_SP, 0).edit();
        edit.clear();
        edit.apply();
    }

    public int[] getAdsPriority() {
        int i = 0;
        String string = this.mContext.getSharedPreferences(USER_SP, 0).getString(ADS_PRIORITY, null);
        if (string == null) {
            return new int[]{1, 2, 10};
        }
        try {
            String[] split = new JSONObject(string).getString("priority").split(",");
            int[] iArr = new int[split.length];
            while (i < split.length) {
                iArr[i] = Integer.parseInt(split[i]);
                i++;
            }
            return iArr;
        } catch (JSONException e) {
            e.printStackTrace();
            return new int[]{1, 2, 10};
        }
    }

    public void setAccepted() {
        saveBoolean(ACCEPT, true);
    }

    public boolean isAccepted() {
        return getBoolean(ACCEPT);
    }

    public void savePriority(String str) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(str);
        edit.putString(ADS_PRIORITY, stringBuilder.toString());
        edit.apply();
    }
}
