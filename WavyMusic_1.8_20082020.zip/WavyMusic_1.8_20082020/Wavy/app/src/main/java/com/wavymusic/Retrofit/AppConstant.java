package com.wavymusic.Retrofit;

public class AppConstant {
    public static String BASEURL ="http://beatsadmin.trendinganimations.com/public/api/";
    public static String Token = "aciativtyksdfhal5215ajal";
    public static String ApplicationId = "5";

    public static String ThemeThumburl = "https://beatsadmin.s3.ap-south-1.amazonaws.com/thumb/";
    public static String SmallThemeThumbrl = "https://beatsadmin.s3.ap-south-1.amazonaws.com/small_thumb/";
    public static String SoundUrl="https://beatsadmin.s3.ap-south-1.amazonaws.com/sounds/";

    public static String DefaultCategoryId="13,14,38,21,15,19,20,18,12,23,16,37,17,26,";
    public static String AssetPath="https://raw.githubusercontent.com/githubupdatesdemo/WavyMusic/master/Particles/v1.7/asset_json_v1.7.txt";
//    public static String AssetPath="https://raw.githubusercontent.com/githubupdatesdemo/WavyMusic/master/Particles/v1.6/asset_json_v1.6.json";
//    public static String AssetPath="https://raw.githubusercontent.com/githubupdatesdemo/WavyMusic/master/Particles/asset_json_v1.6.json";
//    public static String AssetPath="https://raw.githubusercontent.com/githubupdatesdemo/WavyMusic/master/Particles/asset_json.json";
//    public static String AssetPath="https://raw.githubusercontent.com/githubupdatesdemo/WavyMusic/master/Particles/asset_json_testing.json";
}
