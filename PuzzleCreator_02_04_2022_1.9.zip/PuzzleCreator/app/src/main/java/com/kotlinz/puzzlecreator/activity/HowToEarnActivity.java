package com.kotlinz.puzzlecreator.activity;

import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.kotlinz.puzzlecreator.R;

public class HowToEarnActivity extends BaseActivity {
    Button btnInvite;
    ImageView imgcopy;
    TextView txtreferal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how_to_earn);
        setToolbar("How To Earn");

        btnInvite = (Button) findViewById(R.id.btn_invite);
        imgcopy = (ImageView) findViewById(R.id.imgcopy);
        txtreferal = (TextView) findViewById(R.id.txtreferalcode);
        txtreferal.setText(sessionManager.getReferalCode());

        btnInvite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle params = new Bundle();
                mFirebaseAnalytics.logEvent("Referral_Code_Share", params);
                String text = " Hey!!\n" +
                        "\n" +
                        "I find something interested download app from here " +
                        "https://play.google.com/store/apps/details?id=" + getPackageName() + " and " +
                        "register your self with my referral code " + sessionManager.getReferalCode() + " and play puzzle" +
                        "this platform rewarded us with 50 points ";
                Intent shareIntent = new Intent();
                shareIntent.setAction(Intent.ACTION_SEND);
                shareIntent.putExtra(Intent.EXTRA_TEXT,text);
                shareIntent.setType("text/*");
                startActivity(Intent.createChooser(shareIntent, "Share Puzzle..."));
            }
        });

        imgcopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                clipboard.setText(txtreferal.getText().toString());
                Toast.makeText(HowToEarnActivity.this, "Copied", Toast.LENGTH_LONG).show();
            }
        });
    }
}