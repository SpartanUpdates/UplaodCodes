package com.UnitedVideos.TextChange.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import androidx.recyclerview.widget.RecyclerView;
import com.UnitedVideos.TextChange.activity.TextEditActivityUv;
import com.wavymusic.R;

import java.util.ArrayList;

public class TextAdapterU extends RecyclerView.Adapter<TextHolderUv> {
    private static Context context;
    private ArrayList<String> listtext;

    public TextAdapterU(ArrayList<String> arrayList, Context context) {
        this.listtext = arrayList;
        TextAdapterU.context = context;
    }

    public TextHolderUv a(ViewGroup viewGroup, int i) {
        return new TextHolderUv(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_text_edit, null));
    }

    public void a() {
        ((TextEditActivityUv) context).f();
    }

    public void a(int i) {
        ((TextEditActivityUv) context).a(i);
    }

    @SuppressLint("ClickableViewAccessibility")
    public void a(final TextHolderUv textHolderUvVar, final int is) {
        EditText editText;
        int i2;
        textHolderUvVar.a.setHint((CharSequence) this.listtext.get(is));
        if (is == this.listtext.size() - 1) {
            editText = textHolderUvVar.a;
            i2 = 268435462;
        } else {
            editText = textHolderUvVar.a;
            i2 = 5;
        }
        editText.setImeOptions(i2);
        textHolderUvVar.a.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                listtext.set(is, textHolderUvVar.a.getText().toString());
            }
        });
        textHolderUvVar.a.setOnEditorActionListener(new OnEditorActionListener() {

            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i == 5) {
                    a(i);
                    return true;
                } else if (i != 6) {
                    return false;
                } else {
                    a();
                    return true;
                }
            }
        });
        textHolderUvVar.a.setOnTouchListener(new OnTouchListener() {

            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (!textHolderUvVar.a.hasFocus()) {
                    return false;
                }
                view.getParent().requestDisallowInterceptTouchEvent(true);
                if ((motionEvent.getAction() & 255) != 8) {
                    return false;
                }
                view.getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            }
        });
    }

    public int getItemCount() {
        return this.listtext.size();

    }

    public int getItemViewType(int i) {
        return i;
    }


    public void onBindViewHolder(TextHolderUv viewHolder, int i) {
        a(viewHolder, i);
    }

    public TextHolderUv onCreateViewHolder(ViewGroup viewGroup, int i) {
        return a(viewGroup, i);
    }
}