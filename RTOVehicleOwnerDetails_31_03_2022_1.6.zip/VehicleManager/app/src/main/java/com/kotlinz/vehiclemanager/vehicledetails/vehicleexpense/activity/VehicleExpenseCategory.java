package com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.activity;

import static com.kotlinz.vehiclemanager.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import androidx.appcompat.app.AppCompatActivity;

public class VehicleExpenseCategory extends AppCompatActivity implements View.OnClickListener {
    private Activity activity = VehicleExpenseCategory.this;

    ImageView iv_accessories;
    ImageView iv_carfuel;
    ImageView iv_cleanlines;
    ImageView iv_maintenance;
    ImageView iv_otherexpense;
    ImageView iv_back, iv_home;
    TextView title_tv;

    private NativeAd nativeAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_expense_category);
        PutAnalyticsEvent();
        BindView();
        LoadNativeAds();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            title_tv.setTextColor(Color.parseColor("#FFFFFF"));
            iv_accessories.setImageResource(R.drawable.ic_accessoriestunning_selector_dark);
            iv_cleanlines.setImageResource(R.drawable.ic_cleanlinesandcomfort_selector_dark);
            iv_otherexpense.setImageResource(R.drawable.ic_other_expense_selector_dark);
            iv_carfuel.setImageResource(R.drawable.ic_carfuel_selector_dark);
            iv_maintenance.setImageResource(R.drawable.ic_maintenence_selector_dark);
        }
        DarkTheame darkTheame = new DarkTheame(VehicleExpenseCategory.this);
        if (darkTheame.modeData().equals("nightMode")) {
            title_tv.setTextColor(Color.parseColor("#FFFFFF"));
            iv_accessories.setImageResource(R.drawable.ic_accessoriestunning_selector_dark);
            iv_cleanlines.setImageResource(R.drawable.ic_cleanlinesandcomfort_selector_dark);
            iv_otherexpense.setImageResource(R.drawable.ic_other_expense_selector_dark);
            iv_carfuel.setImageResource(R.drawable.ic_carfuel_selector_dark);
            iv_maintenance.setImageResource(R.drawable.ic_maintenence_selector_dark);
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VehicleExpenseCategory");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (VehicleExpenseCategory.this.nativeAd != null) {
                            VehicleExpenseCategory.this.nativeAd.destroy();
                        }
                        VehicleExpenseCategory.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    public void BindView() {
        iv_accessories = findViewById(R.id.iv_accessories);
        iv_carfuel = findViewById(R.id.iv_carfuel);
        iv_cleanlines = findViewById(R.id.iv_cleanlines);
        iv_maintenance = findViewById(R.id.iv_maintenance);
        iv_otherexpense = findViewById(R.id.iv_otherexpense);
        iv_back = findViewById(R.id.iv_back);
        title_tv = findViewById(R.id.title_tv);
        iv_home = findViewById(R.id.iv_home);

        iv_back.setOnClickListener(this);
        iv_home.setOnClickListener(this);
        iv_accessories.setOnClickListener(this);
        iv_carfuel.setOnClickListener(this);
        iv_cleanlines.setOnClickListener(this);
        iv_maintenance.setOnClickListener(this);
        iv_otherexpense.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.iv_accessories:
                if (MyApplication.isShowAd == 1) {
                    intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                    intent.putExtra("categoryname", "Accessories & Tuning");
                    intent.putExtra("categoryimg", R.drawable.ic_accessories_tuning);
                    intent.putExtra("btn", "SAVE");
                    startActivity(intent);
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 28;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                        intent.putExtra("categoryname", "Accessories & Tuning");
                        intent.putExtra("categoryimg", R.drawable.ic_accessories_tuning);
                        intent.putExtra("btn", "SAVE");
                        startActivity(intent);
                    }
                }
                break;

            case R.id.iv_cleanlines:
                if (MyApplication.isShowAd == 1) {
                    intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                    intent.putExtra("categoryname", "Cleanlines & comfort");
                    intent.putExtra("categoryimg", R.drawable.ic_cleanlines_comfort);
                    intent.putExtra("btn", "SAVE");
                    startActivity(intent);
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 29;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                        intent.putExtra("categoryname", "Cleanlines & comfort");
                        intent.putExtra("categoryimg", R.drawable.ic_cleanlines_comfort);
                        intent.putExtra("btn", "SAVE");
                        startActivity(intent);
                    }
                }
                break;

            case R.id.iv_carfuel:
                if (MyApplication.isShowAd == 1) {
                    intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                    intent.putExtra("categoryname", "Car Fuel");
                    intent.putExtra("categoryimg", R.drawable.ic_carfuel);
                    intent.putExtra("btn", "SAVE");
                    startActivity(intent);
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 30;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                        intent.putExtra("categoryname", "Car Fuel");
                        intent.putExtra("categoryimg", R.drawable.ic_carfuel);
                        intent.putExtra("btn", "SAVE");
                        startActivity(intent);
                    }
                }
                break;

            case R.id.iv_maintenance:
                if (MyApplication.isShowAd == 1) {
                    intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                    intent.putExtra("categoryname", "Maintenance");
                    intent.putExtra("categoryimg", R.drawable.ic_maintenance);
                    intent.putExtra("btn", "SAVE");
                    startActivity(intent);
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 31;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                        intent.putExtra("categoryname", "Maintenance");
                        intent.putExtra("categoryimg", R.drawable.ic_maintenance);
                        intent.putExtra("btn", "SAVE");
                        startActivity(intent);
                    }
                }
                break;

            case R.id.iv_otherexpense:
                if (MyApplication.isShowAd == 1) {
                    intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                    intent.putExtra("categoryname", "Other expense");
                    intent.putExtra("categoryimg", R.drawable.ic_otherexpense);
                    intent.putExtra("btn", "SAVE");
                    startActivity(intent);
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 32 ;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                        intent.putExtra("categoryname", "Other expense");
                        intent.putExtra("categoryimg", R.drawable.ic_otherexpense);
                        intent.putExtra("btn", "SAVE");
                        startActivity(intent);
                    }
                }
                break;

            case R.id.iv_back:
                onBackPressed();
                break;

            case R.id.iv_home:
                if (MyApplication.isShowAd == 1) {
                    startActivity(new Intent(VehicleExpenseCategory.this, MainActivity.class));
                    finish();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 20 ;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        startActivity(new Intent(VehicleExpenseCategory.this, MainActivity.class));
                        finish();
                    }
                }
                break;
        }
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(VehicleExpenseCategory.this, VehicleExpenseActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 33;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(VehicleExpenseCategory.this, VehicleExpenseActivity.class));
                finish();
            }
        }
    }
}