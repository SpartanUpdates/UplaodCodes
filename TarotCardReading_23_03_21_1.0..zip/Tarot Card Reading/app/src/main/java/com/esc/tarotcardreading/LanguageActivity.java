package com.esc.tarotcardreading;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class LanguageActivity extends AppCompatActivity {
    Activity activity = LanguageActivity.this;
    public static Editor editor;
    public static String languageToLoad;
    public static SharedPreferences sharedPreferences;
    int[] img = new int[]{R.drawable.english, R.drawable.dutch, R.drawable.filipino, R.drawable.finnish, R.drawable.french, R.drawable.german, R.drawable.greek, R.drawable.hindi, R.drawable.indonesian, R.drawable.italian, R.drawable.malay, R.drawable.norwegian, R.drawable.portuguese, R.drawable.russian, R.drawable.spanish, R.drawable.swedish, R.drawable.vietnamese, R.drawable.turkish, R.drawable.chineseflag, R.drawable.koreaflag, R.drawable.danish, R.drawable.polish, R.drawable.japanflag, R.drawable.thaiflag};
    String[] lang = new String[]{"English", "Dutch - Nederlands", "Filipino - Filipino", "Finnish - Suomalainen", "French - Français", "German - Deutsche", "Greek - Ελληνικά", "Hindi - हिंदी", "Indonesian - Bahasa Indonesia", "Italian - Italiano", "Malay - Malay", "Norwegian - Norsk", "Portuguese - Português", "Russian - русский", "Spanish - Español", "Swedish - Svenska", "Vietnamese - Tiếng Việt", "Turkish - Türkçe", "Chinese - 中文", "Korean - 한국어", "Danish - Dansk", "Polish - Polski", "Japanese-日本語", "Thai-ไทย"};
    String[] langcode = new String[]{"en", "nl", "tl", "fi", "fr", "de", "el", "hi", "in", "it", "ms", "nb", "pt", "ru", "es", "sv", "vi", "tr", "zh", "ko", "da", "pl", "ja", "th"};
    Languageadatper languageadatper;
    ListView listView;
    public String locale = "";
    Typeface typeface;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public class Languageadatper extends BaseAdapter {
        Context cont;
        int[] flagicon;
        ViewHolder holder;
        LayoutInflater inflater;
        String[] languagetxt;

        class ViewHolder {
            public ImageView fimg;
            public TextView language_txt;

            ViewHolder() {
            }
        }

        public long getItemId(int i) {
            return 0;
        }

        public Languageadatper(Context context, String[] strArr, int[] iArr) {
            this.languagetxt = strArr;
            this.cont = context;
            this.inflater = LayoutInflater.from(context);
            this.flagicon = iArr;
        }

        public int getCount() {
            return this.languagetxt.length;
        }

        public Object getItem(int i) {
            return Integer.valueOf(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = this.inflater.inflate(R.layout.language_list_items, null);
                ViewHolder viewHolder = new ViewHolder();
                this.holder = viewHolder;
                viewHolder.language_txt = view.findViewById(R.id.languagetxt);
                this.holder.fimg = view.findViewById(R.id.languageimg);
                view.setTag(this.holder);
            } else {
                this.holder = (ViewHolder) view.getTag();
            }
            this.holder.language_txt.setText(this.languagetxt[i]);
            this.holder.fimg.setImageResource(this.flagicon[i]);
            this.holder.language_txt.setTypeface(LanguageActivity.this.typeface);
            return view;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public LanguageActivity() {
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_language);
        this.locale = getResources().getConfiguration().locale.getLanguage();
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("MyPref", 0);
        sharedPreferences = sharedPreferences;
        editor = sharedPreferences.edit();
        if (this.locale.contains("hi")) {
            this.typeface = Typeface.createFromAsset(getAssets(), "fonts/MANGAL.TTF");
        } else {
            this.typeface = Typeface.createFromAsset(getAssets(), "fonts/georgiar.ttf");
        }
        if (VERSION.SDK_INT >= 21) {
            getWindow().addFlags(Integer.MIN_VALUE);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_1));
        }
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        View inflate = LayoutInflater.from(this).inflate(R.layout.titleview, null);
        ((TextView) inflate.findViewById(R.id.title)).setTypeface(this.typeface);
        getSupportActionBar().setCustomView(inflate);
        this.listView = findViewById(R.id.list_language);
        Languageadatper languageadatper = new Languageadatper(getApplicationContext(), this.lang, this.img);
        this.languageadatper = languageadatper;
        this.listView.setAdapter(languageadatper);
        this.listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                LanguageActivity.languageToLoad = LanguageActivity.this.langcode[i];
                LanguageActivity.editor.putString("languagetoload", LanguageActivity.languageToLoad);
                LanguageActivity.editor.commit();
                Locale locale = new Locale(LanguageActivity.languageToLoad);
                Locale.setDefault(locale);
                Configuration configuration = new Configuration();
                configuration.locale = locale;
                LanguageActivity.this.getApplicationContext().getResources().updateConfiguration(configuration, LanguageActivity.this.getApplicationContext().getResources().getDisplayMetrics());
                Intent intent = new Intent(LanguageActivity.this, SplashActivity.class);
                LanguageActivity.this.startActivity(intent);
                Toast.makeText(LanguageActivity.this.getApplicationContext(), LanguageActivity.this.lang[i], 1).show();
                Map hashMap = new HashMap();
                hashMap.put("language", LanguageActivity.this.lang[i]);
                LanguageActivity.editor.putString("lang", LanguageActivity.this.langcode[i]);
                LanguageActivity.editor.apply();
            }
        });
        BannerAds();
    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }


    public void attachBaseContext(Context context) {
        super.attachBaseContext(Utils.changeLang(context, context.getApplicationContext().getSharedPreferences("MyPref", 0).getString("languagetoload", "en")));
    }
}
