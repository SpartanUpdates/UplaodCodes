package com.kotlinz.videoCollage;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.adpaters.BGImageAdapter;
import com.kotlinz.videoCollage.adpaters.BgColorAdapter;
import com.kotlinz.videoCollage.adpaters.DrawColorAdapter;
import com.kotlinz.videoCollage.adpaters.EmojiStickerAdapter;
import com.kotlinz.videoCollage.adpaters.FilterAdapter;
import com.kotlinz.videoCollage.adpaters.FrameAdapter;
import com.kotlinz.videoCollage.adpaters.MsgTextStickerAdapter;
import com.kotlinz.videoCollage.adpaters.PartyStickerAdapter;
import com.kotlinz.videoCollage.adpaters.RatioAdapter;
import com.kotlinz.videoCollage.adpaters.TextBGColorAdapter;
import com.kotlinz.videoCollage.adpaters.TextBGImageAdapter;
import com.kotlinz.videoCollage.adpaters.TextBorderColorAdapter;
import com.kotlinz.videoCollage.adpaters.TextColorAdapter;
import com.kotlinz.videoCollage.adpaters.TextFontAdapter;
import com.kotlinz.videoCollage.adpaters.TextShadowColorAdapter;
import com.kotlinz.videoCollage.adpaters.WatermarkPicVidAdapter;
import com.kotlinz.videoCollage.adpaters.WatermarkSocialAdapter;
import com.kotlinz.videoCollage.flying.poiphoto.Define;
import com.kotlinz.videoCollage.flying.poiphoto.PhotoPicker;
import com.kotlinz.videoCollage.flying.poiphoto.VideoPicker;
import com.kotlinz.videoCollage.flying.puzzle.PuzzleLayout;
import com.kotlinz.videoCollage.flying.puzzle.PuzzlePiece;
import com.kotlinz.videoCollage.flying.puzzle.PuzzleView;
import com.kotlinz.videoCollage.flying.puzzle.slant.SlantPuzzleLayout;
import com.kotlinz.videoCollage.fragments.EditTextDialogFragment;
import com.kotlinz.videoCollage.fragments.ListFragment;
import com.kotlinz.videoCollage.interfaces.BGColorAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.BGImageAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.DrawColorAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.EmojiStickerAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.FilterAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.FrameAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.MsgTextStickerAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.OnSetImageStickerInterface;
import com.kotlinz.videoCollage.interfaces.PartyStickerAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.PicVidWatermarkAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.RatioAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.SocVidWatermarkAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.TextBGColorAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.TextBGImageAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.TextBorderColorAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.TextColorAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.TextFontAdapterCallBackInterface;
import com.kotlinz.videoCollage.interfaces.TextShadowColorAdapterCallBackInterface;
import com.kotlinz.videoCollage.other.Constants;
import com.kotlinz.videoCollage.other.ImageUtils;
import com.kotlinz.videoCollage.other.RealPathUtil;
import com.kotlinz.videoCollage.other.Util;
import com.kotlinz.videoCollage.puzzleview.FileUtils;
import com.kotlinz.videoCollage.puzzleview.PuzzleAdapter;
import com.kotlinz.videoCollage.puzzleview.PuzzleUtils;
import com.kotlinz.videoCollage.scal.SubSamplingScaleImageView;
import com.kotlinz.videoCollage.sticker.ComponentInfo;
import com.kotlinz.videoCollage.sticker.ResizableStickerView;
import com.kotlinz.videoCollage.textmodule.AutofitTextRel;
import com.kotlinz.videoCollage.textmodule.TextInfo;
import com.kotlinz.videoCollage.views.ColorFilterGenerator;
import com.kotlinz.videoCollage.views.FixedAspectRatioFrameLayout;
import com.kotlinz.videoCollage.views.GuidelineImageView;
import com.kotlinz.videoCollage.views.MaskableFrameLayout;
import com.kotlinz.videoCollage.views.TextureVideoView;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Picasso.LoadedFrom;
import com.squareup.picasso.Target;
import com.theartofdev.edmodo.cropper.CropImage;

import net.alhazmy13.imagefilter.ImageFilter;
import net.alhazmy13.imagefilter.ImageFilter.Filter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import ja.burhanrashid52.photoeditor.OnPhotoEditorListener;
import ja.burhanrashid52.photoeditor.PhotoEditor;
import ja.burhanrashid52.photoeditor.PhotoEditor.OnSaveListener;
import ja.burhanrashid52.photoeditor.PhotoEditorView;
import ja.burhanrashid52.photoeditor.SaveSettings;
import ja.burhanrashid52.photoeditor.ViewType;

public class GridActivity extends AppCompatActivity implements OnClickListener, AutofitTextRel.TouchEventListener, ResizableStickerView.TouchEventListener, OnSetImageStickerInterface {
    Activity activity = GridActivity.this;
    private static final int ADD_ADJUST_ON_PICTURE = 904;
    private static final int ADD_FILTER_ON_PICTURE = 903;
    private static final int FLAG_CONTROL_CORNER = 2;
    private static final int FLAG_CONTROL_LINE_SIZE = 1;
    private static final int SELECT_MUSIC = 905;
    private static final int SELECT_PICTURE_FROM_GALLERY_FOR_GRID = 902;
    private static final int SELECT_PICTURE_FROM_GALLERY_FOR_IMAGE_STICKER = 901;
    public static GridActivity gridActivity;
    private boolean adjustFlag;
    private FrameLayout allStickerFrame;
    private int baseViewHeight;
    private int baseViewWidth;
    private int bgAlpha;
    private BottomSheetBehavior bgBottomSheetBehavior;
    private int bgColor;
    private BgColorAdapter bgColorAdapter;
    private String[] bgColorList;
    private RecyclerView bgColorRecycler;
    private String bgDrawable;
    private BGImageAdapter bgImageAdapter;
    private String[] bgImageList;
    private RecyclerView bgImageRecycler;
    private List<String> bitmapPaint;
    private BottomSheetBehavior borderBottomSheetBehavior;
    private int borderColor;
    private LinearLayout bottomSheetBG;
    private LinearLayout bottomSheetBorder;
    private LinearLayout bottomSheetDraw;
    private LinearLayout bottomSheetSticker;
    private LinearLayout bottomSheetWatermark;
    private int brightnessProgress;
    private SeekBar charSeekPac;
    private String color_Type;
    private Context context;
    private int contrastProgress;
    private int curColor;
    private int curCorner = 0;
    private int curFrame;
    private int curImage;
    private int curPiecePad = 0;
    private int curViewPad = 0;
    private PuzzlePiece currentPiece;
    private int deviceWidth = 0;
    private BottomSheetBehavior drawBottomSheetBehavior;
    private DrawColorAdapter drawColorAdapter;
    private boolean drawColorFlag;
    private RecyclerView drawColorRecyclerView;
    private boolean drawEraseFlag;
    private final boolean drawFlag;
    private int drawLineColor;
    private String drawMode;
    private boolean editMode;
    private EditTextDialogFragment editTextDialogFragment;
    private EmojiStickerAdapter emojiStickerAdapter;
    private String[] emojiStickerList;
    private FilterAdapter filterAdapter;
    private boolean filterFlag;
    private int filterPosition;
    private RecyclerView filterRecycler;
    private final Handler first;
    private final View focusedCopy;
    private View focusedView;
    private String fontName;
    private FixedAspectRatioFrameLayout frame;
    private FrameAdapter frameAdapter;
    private FrameLayout frameBrightness;
    private FrameLayout frameContrast;
    private FrameLayout frameHue;
    private String[] frameList;
    private ImageView frameMainBg;
    private ImageView frameMainColorBG;
    private RecyclerView frameRecycler;
    private FrameLayout frameSaturation;
    private boolean fromPause;
    private GuidelineImageView guideline;
    final Handler handler;
    private HorizontalScrollView horizontalMainScrollView;
    private LinearLayout horizontalSingleImageScrollView;
    private LinearLayout horizontalSingleVideoScrollView;
    private LinearLayout horizontalTextScrollView;
    private int hueProgress;
    private ImageView imgAdjust;
    private ImageView imgBG;
    private ImageView imgBGBack;
    private ImageView imgBGDone;
    private ImageView imgBack;
    ImageView iv_done;
    private ImageView imgBorder;
    private ImageView imgBrightness;
    private ImageView imgContrast;
    private ImageView imgDraw;
    private ImageView imgDrawCancel;
    private ImageView imgDrawColor;
    private ImageView imgDrawDone;
    private ImageView imgDrawErase;
    private ImageView imgDrawRedo;
    private ImageView imgDrawSizeFive;
    private ImageView imgDrawSizeFour;
    private ImageView imgDrawSizeOne;
    private ImageView imgDrawSizeThree;
    private ImageView imgDrawSizeTwo;
    private ImageView imgDrawUndo;
    private ImageView imgFilter;
    private ImageView imgGridBack;
    private ImageView imgGridDone;
    private ImageView imgHue;
    private ImageView imgImage;
    private ImageView imgLayout;
    private ImageView imgMusic;
    private ImageView imgMusicRemove;
    private ImageView imgPlayOrder;
    private ImageView imgRatio;
    private ImageView imgResetBrightness;
    private ImageView imgSaturation;
    private ImageView imgSinImgAdjust;
    private ImageView imgSinImgBack;
    private ImageView imgSinImgClipPhoto;
    private ImageView imgSinImgCrop;
    private ImageView imgSinImgDelete;
    private ImageView imgSinImgFilter;
    private ImageView imgSinImgFitOut;
    private ImageView imgSinImgHoriFlip;
    private ImageView imgSinImgReplace;
    private ImageView imgSinImgRotate;
    private ImageView imgSinImgRotateL10;
    private ImageView imgSinImgRotateR10;
    private ImageView imgSinImgSwap;
    private ImageView imgSinImgVerFlip;
    private ImageView imgSinImgZoomIn;
    private ImageView imgSinImgZoomOut;
    private ImageView imgSinVidBack;
    private ImageView imgSinVidDelete;
    private ImageView imgSinVidFitOut;
    private ImageView imgSinVidMute;
    private ImageView imgSinVidReplace;
    private ImageView imgSinVidRotate;
    private ImageView imgSinVidSwap;
    private ImageView imgSinVidTrim;
    private ImageView imgSticker;
    private ImageView imgStickerBack;
    private ImageView imgStickerCateForAdd;
    private ImageView imgStickerCateOne;
    private ImageView imgStickerCateThree;
    private ImageView imgStickerCateTwo;
    private ImageView imgStickerImageClip;
    private ImageView imgText;
    private ImageView imgTextAlign;
    private ImageView imgTextAlignC;
    private ImageView imgTextAlignL;
    private ImageView imgTextAlignR;
    private ImageView imgTextBG;
    private ImageView imgTextBack;
    private ImageView imgTextColor;
    private ImageView imgTextCopy;
    private ImageView imgTextEdit;
    private ImageView imgTextFont;
    private ImageView imgTextOpacity;
    private ImageView imgTextStyle;
    private ImageView imgWatermark;
    private ImageView imgWatermarkBack;
    private ImageView imgWatermarkDone;
    private boolean inOrder;
    private boolean isImageSwapEnable;
    private boolean isMute;
    private boolean isVideoSwapEnable;
    private int lastPositionSwap;
    private FrameLayout layContainer;
    private boolean layoutFlag = false;
    private RecyclerView layoutRecyclerView;
    private LinearLayout linAdjust;
    private LinearLayout linAdjustView;
    private LinearLayout linBG;
    private LinearLayout linBorder;
    private LinearLayout linCorner;
    private LinearLayout linDraw;
    private LinearLayout linDrawColor;
    private LinearLayout linDrawDelete;
    private LinearLayout linDrawSizeFive;
    private LinearLayout linDrawSizeFour;
    private LinearLayout linDrawSizeFullView;
    private LinearLayout linDrawSizeOne;
    private LinearLayout linDrawSizeThree;
    private LinearLayout linDrawSizeTwo;
    private LinearLayout linDrawView;
    private LinearLayout linFilter;
    private LinearLayout linImage;
    private LinearLayout linImageAdd;
    private LinearLayout linImageAddAsSticker;
    private LinearLayout linLayout;
    private LinearLayout linMainBorder;
    private LinearLayout linMainColor;
    private LinearLayout linMainFrame;
    private LinearLayout linMainImage;
    private LinearLayout linMainTextBGColor;
    private LinearLayout linMainTextBGImage;
    private LinearLayout linMainTextBorder;
    private LinearLayout linMainTextShadow;
    private LinearLayout linMusic;
    private LinearLayout linMusicLayout;
    private LinearLayout linPlayOrder;
    private LinearLayout linRatio;
    private LinearLayout linSinImgAdjust;
    private LinearLayout linSinImgBack;
    private LinearLayout linSinImgClipPhoto;
    private LinearLayout linSinImgCrop;
    private LinearLayout linSinImgDelete;
    private LinearLayout linSinImgFilter;
    private LinearLayout linSinImgFitOut;
    private LinearLayout linSinImgHoriFlip;
    private LinearLayout linSinImgReplace;
    private LinearLayout linSinImgRotate;
    private LinearLayout linSinImgRotateL10;
    private LinearLayout linSinImgRotateR10;
    private LinearLayout linSinImgSwap;
    private LinearLayout linSinImgVerFlip;
    private LinearLayout linSinImgZoomIn;
    private LinearLayout linSinImgZoomOut;
    private LinearLayout linSinVidBack;
    private LinearLayout linSinVidDelete;
    private LinearLayout linSinVidFitOut;
    private LinearLayout linSinVidMute;
    private LinearLayout linSinVidReplace;
    private LinearLayout linSinVidRotate;
    private LinearLayout linSinVidSwap;
    private LinearLayout linSinVidTrim;
    private LinearLayout linSticker;
    private LinearLayout linStickerCatForAdd;
    private LinearLayout linText;
    private LinearLayout linTextAlign;
    private LinearLayout linTextAlignMain;
    private LinearLayout linTextBG;
    private LinearLayout linTextBGMain;
    private LinearLayout linTextBack;
    private LinearLayout linTextColor;
    private LinearLayout linTextCopy;
    private LinearLayout linTextEdit;
    private LinearLayout linTextFont;
    private LinearLayout linTextLayerMain;
    private LinearLayout linTextOpacity;
    private LinearLayout linTextOpacityMain;
    private LinearLayout linTextStyle;
    private LinearLayout linTextStyleMain;
    private LinearLayout linWatermark;
    private SeekBar lineSeekPac;
    private ArrayList<String> listEmojiSticker;
    public ListFragment listFragment;
    private ArrayList<String> listFrames;
    ArrayList<String> listImages;
    private ArrayList<String> listMsgTextSticker;
    private ArrayList<String> listPartySticker;
    private ArrayList<String> listThumb;
    private ArrayList<String> listWatermark;
    private ArrayList<String> listWatermarkSoc;
    private int longestTime = 0;
    private String mDrawableName;
    private LinearLayout mainLinear;
    private FrameLayout maskBGFrame;
    private MaskableFrameLayout maskableFrameLayout;
    private MediaPlayer mediaPlayer;
    private MsgTextStickerAdapter msgTextStickerAdapter;
    private String[] msgTextStickerList;
    private boolean musicFlag;
    private String musicPath;
    private List<String> originalBitmapPaint;
    private PartyStickerAdapter partyStickerAdapter;
    private String[] partyStickerList;
    private PhotoEditor photoEditor;
    private PhotoEditorView photoEditorView;
    private int process;
    private PuzzleLayout puzzleLayout;
    private PuzzleView puzzleView;
    private boolean ratioFlag = false;
    //private final int[] ratioIconImages = new int[]{R.drawable.ic_1_1_unpress, R.drawable.ic_ratio_4_5_unpress, R.drawable.ic_ratio_9_6_unpress, R.drawable.ic_ratio_3_4_unpress, R.drawable.youtube_16by9_unpress, R.drawable.facebook_4by3_unpress, R.drawable.fb_cover_unpress, R.drawable.post_unpress, R.drawable.ic_5by7_unpress, R.drawable.ic_7by5_unpress, R.drawable.ic_5by4_unpress, R.drawable.ic_3by5_unpress, R.drawable.ic_5by3_unpress, R.drawable.ic_2by3_unpess, R.drawable.ic_3by2_unpess, R.drawable.twitter_cover_u, R.drawable.ic_11by91_unpress};

    private final int[] ratioImages = new int[]{R.drawable.one_one, R.drawable.four_five, R.drawable.nine_sixteen, R.drawable.three_four, R.drawable.sixteen_nine, R.drawable.four_three, R.drawable.two_one, R.drawable.five_two, R.drawable.five_seven, R.drawable.seven_five, R.drawable.five_four, R.drawable.three_five, R.drawable.five_three, R.drawable.two_three, R.drawable.three_two, R.drawable.three_one, R.drawable.one_two};
    private RecyclerView ratioRecycler;
    private View resizableStickerView;
    Runnable runnable;
    final Runnable runnableFirst;
    private int saturationProgress;
    private boolean saveClick;
    float screenHeight;
    float screenWidth;
    private SeekBar seekBarBrightness;
    private SeekBar seekBarContrast;
    private SeekBar seekBarHue;
    private SeekBar seekBarSaturation;
    private SeekBar seekBarShadowBlur;
    private SeekBar seekBarTextBorder;
    private SeekBar seekBarXYPos;
    private SeekBar seekCorner;
    private SeekBar seekMusic;
    private SeekBar seekOpacity;
    private SeekBar seekPiecePadding;
    private SeekBar seekViewPadding;
    private int selectedColor = 1;
    private int selectedFrame = 0;
    private int selectedImage = 0;
    private int selectedLineSize;
    private int selectedPiecePosition;
    private int selectedThemeId = 0;
    private int shadowColor;
    private int shadowProg;
    private int shadowXYProg;
    private BottomSheetBehavior stickerBottomSheetBehavior;
    private RecyclerView stickerRecyclerCatOne;
    private RecyclerView stickerRecyclerCatThree;
    private RecyclerView stickerRecyclerCatTwo;
    private int stkrColorSet;
    private int tAlpha;
    private int tColor;
    private final List<Target> targets = new ArrayList();
    private final ArrayList<View> temp;
    private final ArrayList<Integer> tempPos;
    private TextView tempTextForAdjust;
    private boolean textAlignFlag;
    private TextBGColorAdapter textBGColorAdapter;
    private RecyclerView textBGColorRecyclerView;
    private boolean textBGFlag;
    private TextBGImageAdapter textBGImageAdapter;
    private RecyclerView textBGImageRecyclerView;
    private SeekBar textBGOpacity;
    private TextBorderColorAdapter textBorderColorAdapter;
    private RecyclerView textBorderColorRecyclerView;
    private TextColorAdapter textColorAdapter;
    private boolean textColorFlag;
    private RecyclerView textColorRecyclerView;
    private int textColorSet;
    private TextFontAdapter textFontAdapter;
    private boolean textFontFlag;
    private RecyclerView textFontRecyclerView;
    private final boolean textLayerFlag;
    private boolean textOpacityFlag;
    private TextShadowColorAdapter textShadowColorAdapter;
    private RecyclerView textShadowColorRecyclerView;
    private boolean textStyleFlag;
    private int themeId = 0;
    private String[] thumbImageList;
    private int totalTime = 0;
    private boolean touchChange;
    private TextView txtAdjust;
    private TextView txtBG;
    private TextView txtBorder;
    private float txtCharSpacing;
    private TextView txtCorner;
    private TextView txtDraw;
    private TextView txtFilter;
    private String txtGravity;
    private TextView txtImage;
    private TextView txtLayout;
    private float txtLineSpacing;
    private TextView txtMainBorder;
    private TextView txtMainColor;
    private TextView txtMainFrame;
    private TextView txtMainImage;
    private TextView txtMainTextBGColor;
    private TextView txtMainTextBGImage;
    private TextView txtMainTextBorder;
    private TextView txtMainTextShadow;
    private TextView txtMusic;
    private TextView txtMusicName;
    private TextView txtPiecePadding;
    private TextView txtPlayOrder;
    private TextView txtRatio;
    private TextView txtSinImgAdjust;
    private TextView txtSinImgBack;
    private TextView txtSinImgClipPhoto;
    private TextView txtSinImgCrop;
    private TextView txtSinImgDelete;
    private TextView txtSinImgFilter;
    private TextView txtSinImgFitOut;
    private TextView txtSinImgHoriFlip;
    private TextView txtSinImgReplace;
    private TextView txtSinImgRotate;
    private TextView txtSinImgRotateL10;
    private TextView txtSinImgRotateR10;
    private TextView txtSinImgSwap;
    private TextView txtSinImgSwapInfo;
    private TextView txtSinImgVerFlip;
    private TextView txtSinImgZoomIn;
    private TextView txtSinImgZoomOut;
    private TextView txtSinVidBack;
    private TextView txtSinVidDelete;
    private TextView txtSinVidFitOut;
    private TextView txtSinVidMute;
    private TextView txtSinVidReplace;
    private TextView txtSinVidRotate;
    private TextView txtSinVidSwap;
    private TextView txtSinVidSwapInfo;
    private TextView txtSinVidTrim;
    private TextView txtSticker;
    private RelativeLayout txtStickerRel;
    private TextView txtText;
    private TextView txtTextAlign;
    private TextView txtTextBG;
    private TextView txtTextBack;
    private TextView txtTextColor;
    private TextView txtTextCopy;
    private TextView txtTextEdit;
    private TextView txtTextFont;
    private TextView txtTextOpacity;
    private TextView txtTextOpacityPer;
    private TextView txtTextStyle;
    //    private TextView txtVideoDuration;
    private TextView txtViewPadding;
    private TextView txtWatermark;
    private TextView txtWatermarkPicVid;
    private TextView txtWatermarkSocial;
    private RelativeLayout txtWatermarkStickerRel;
    private int videoCount;
    private int videoPos;
    private View viewBrightness;
    private View viewContrast;
    private View viewHue;
    private final List<View> viewPieces = new ArrayList();
    private View viewSaturation;
    private BottomSheetBehavior watermarkBottomSheetBehavior;
    private String[] watermarkList;
    private WatermarkPicVidAdapter watermarkPicVidAdapter;
    private RecyclerView watermarkPicVidRecyclerView;
    private String[] watermarkSocList;
    private WatermarkSocialAdapter watermarkSocialAdapter;
    private RecyclerView watermarkSocialRecyclerView;
    private final float zoomInScale;
    private final float zoomOutScale;


    private class AdjustAllAsyncTask extends AsyncTask<Void, Void, Void> {
        private Bitmap bitmapOrg;
        private final String from;
        private ProgressDialog progressDialog;

        public AdjustAllAsyncTask(final String from) {
            this.from = from;
        }

        protected Void doInBackground(final Void... array) {
            for (int i = 0; i < GridActivity.this.bitmapPaint.size(); ++i) {
                final View view = GridActivity.this.viewPieces.get(i);
                final Bitmap decodeFile = BitmapFactory.decodeFile(GridActivity.this.bitmapPaint.get(i));
                this.bitmapOrg = decodeFile;
                int finalI = i;
                GridActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        final View val$view = view;
                        if (val$view instanceof LinearLayout) {
                            final View child = ((LinearLayout) val$view).getChildAt(0);
                            if (child instanceof ImageView) {
                                final ImageView imageView = (ImageView) child;
                                imageView.setImageBitmap(decodeFile);
                                if (AdjustAllAsyncTask.this.from.equalsIgnoreCase("brightness")) {
                                    GridActivity.this.contrastProgress = 0;
                                    GridActivity.this.saturationProgress = 0;
                                    GridActivity.this.hueProgress = 0;
                                } else if (AdjustAllAsyncTask.this.from.equalsIgnoreCase("contrast")) {
                                    GridActivity.this.brightnessProgress = 0;
                                    GridActivity.this.saturationProgress = 0;
                                    GridActivity.this.hueProgress = 0;
                                } else if (AdjustAllAsyncTask.this.from.equalsIgnoreCase("saturation")) {
                                    GridActivity.this.brightnessProgress = 0;
                                    GridActivity.this.contrastProgress = 0;
                                    GridActivity.this.hueProgress = 0;
                                } else {
                                    GridActivity.this.brightnessProgress = 0;
                                    GridActivity.this.contrastProgress = 0;
                                    GridActivity.this.saturationProgress = 0;
                                }
                                imageView.setColorFilter(ColorFilterGenerator.adjustColor(GridActivity.this.brightnessProgress, GridActivity.this.contrastProgress, GridActivity.this.saturationProgress, GridActivity.this.hueProgress));
                            }
                        }
                        view.requestLayout();
                        final LinearLayout access$10100 = GridActivity.this.mainLinear;
                        final View val$view2 = view;
                        access$10100.updateViewLayout(val$view2, val$view2.getLayoutParams());
                        GridActivity.this.viewPieces.set(finalI, view);
                        GridActivity.this.puzzleView.replace(view, "");
                    }
                });
            }
            return null;
        }
    }

    private class AdjustResetAsyncTask extends AsyncTask<Void, Void, Void> {
        private Bitmap bitmapOrg;
        private ProgressDialog progressDialog;

        private AdjustResetAsyncTask() {
        }

        AdjustResetAsyncTask(GridActivity gridActivity) {
            this();
        }


        public void onPreExecute() {
            super.onPreExecute();
            ProgressDialog progressDialog = new ProgressDialog(GridActivity.this.context);
            this.progressDialog = progressDialog;
            progressDialog.setMessage("Please wait...It is applying filter");
            this.progressDialog.setIndeterminate(false);
            this.progressDialog.setCancelable(false);
            this.progressDialog.setCanceledOnTouchOutside(false);
            this.progressDialog.show();
        }


        public Void doInBackground(Void... voidArr) {
            for (int i = 0; i < GridActivity.this.bitmapPaint.size(); i++) {
                final View view = GridActivity.this.viewPieces.get(i);
                final Bitmap decodeFile = BitmapFactory.decodeFile(GridActivity.this.bitmapPaint.get(i));
                this.bitmapOrg = decodeFile;
                final int finalI = i;
                GridActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        View view = null;
                        if (view instanceof LinearLayout) {
                            view = ((LinearLayout) view).getChildAt(0);
                            if (view instanceof ImageView) {
                                ImageView imageView = (ImageView) view;
                                imageView.setImageBitmap(decodeFile);
                                GridActivity.this.brightnessProgress = 0;
                                GridActivity.this.contrastProgress = 0;
                                GridActivity.this.saturationProgress = 0;
                                GridActivity.this.hueProgress = 0;
                                imageView.setColorFilter(ColorFilterGenerator.adjustColor(GridActivity.this.brightnessProgress, GridActivity.this.contrastProgress, GridActivity.this.saturationProgress, GridActivity.this.hueProgress));
                            }
                        }
                        view.requestLayout();
                        LinearLayout access$10100 = GridActivity.this.mainLinear;
                        View view2 = view;
                        access$10100.updateViewLayout(view2, view2.getLayoutParams());
                        GridActivity.this.viewPieces.set(finalI, view);
                        GridActivity.this.puzzleView.replace(view, "");
                    }
                });
            }
            return null;
        }


        public void onPostExecute(Void voidR) {
            super.onPostExecute(voidR);
            GridActivity.this.puzzleView.requestLayout();
            this.progressDialog.dismiss();
        }
    }

    private class FilterAsyncTask extends AsyncTask<Void, Void, Void> {
        static final boolean $assertionsDisabled = false;
        private Bitmap bitmapOrg;
        private boolean isPositionZero = false;
        private final int position;
        private ProgressDialog progressDialog;
        private final ArrayList<String> temp;


        public FilterAsyncTask(int i) {
            this.position = i;
            this.temp = new ArrayList();
        }


        public void onPreExecute() {
            super.onPreExecute();
            ProgressDialog progressDialog = new ProgressDialog(GridActivity.this.context);
            this.progressDialog = progressDialog;
            progressDialog.setMessage("Please wait...It is applying filter");
            this.progressDialog.setIndeterminate(false);
            this.progressDialog.setCancelable(false);
            this.progressDialog.setCanceledOnTouchOutside(false);
            this.progressDialog.show();
        }


        public Void doInBackground(Void... voidArr) {
            for (int i = 0; i < GridActivity.this.originalBitmapPaint.size(); i++) {
                final View view = GridActivity.this.viewPieces.get(i);
                Bitmap decodeFile = BitmapFactory.decodeFile(GridActivity.this.originalBitmapPaint.get(i));
                this.bitmapOrg = decodeFile;
                int i2 = this.position;
                if (i2 == 0) {
                    final int finalI1 = i;
                    final Bitmap finalDecodeFile = decodeFile;
                    GridActivity.this.runOnUiThread(new Runnable() {
                        public void run() {
                            View view = null;
                            if (view instanceof LinearLayout) {
                                view = ((LinearLayout) view).getChildAt(0);
                                if (view instanceof ImageView) {
                                    ((ImageView) view).setImageBitmap(finalDecodeFile);
                                }
                            }
                            view.requestLayout();
                            LinearLayout access$10100 = GridActivity.this.mainLinear;
                            View view2 = view;
                            access$10100.updateViewLayout(view2, view2.getLayoutParams());
                            GridActivity.this.viewPieces.set(finalI1, view);
                            GridActivity.this.puzzleView.replace(view, "");
                        }
                    });
                    this.isPositionZero = true;
                } else if (i2 == 1) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.GRAY);
                } else if (i2 == 2) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.NEON, Integer.valueOf(Callback.DEFAULT_DRAG_ANIMATION_DURATION), Integer.valueOf(50), Integer.valueOf(100));
                } else if (i2 == 3) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.TV);
                } else if (i2 == 4) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.INVERT);
                } else if (i2 == 5) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.BLOCK);
                } else if (i2 == 6) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.OLD);
                } else if (i2 == 7) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.SKETCH);
                } else if (i2 == 8) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.GOTHAM);
                } else if (i2 == 9) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.OIL, Integer.valueOf(10));
                } else if (i2 == 10) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.AVERAGE_BLUR, Integer.valueOf(9));
                } else if (i2 == 11) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.SHARPEN);
                } else if (i2 == 12) {
                    int width = decodeFile.getWidth();
                    i2 = this.bitmapOrg.getHeight();
                    Bitmap bitmap = this.bitmapOrg;
                    Filter filter = Filter.LIGHT;
                    Object[] objArr = new Object[3];
                    width /= 2;
                    objArr[0] = Integer.valueOf(width);
                    i2 /= 2;
                    objArr[1] = Integer.valueOf(i2);
                    objArr[2] = Integer.valueOf(Math.min(width, i2));
                    this.bitmapOrg = ImageFilter.applyFilter(bitmap, filter, objArr);
                } else if (i2 == 13) {
                    double width2 = ((decodeFile.getWidth() / 2) * 95) / 100;
                    this.bitmapOrg = ImageFilter.applyFilter(this.bitmapOrg, Filter.LOMO, Double.valueOf(width2));
                } else if (i2 == 14) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.HDR);
                } else if (i2 == 15) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.GAUSSIAN_BLUR, Double.valueOf(1.2d));
                } else if (i2 == 16) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.SOFT_GLOW, Double.valueOf(0.6d));
                } else if (i2 == 17) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.PIXELATE, Integer.valueOf(9));
                } else if (i2 == 18) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.MOTION_BLUR, Integer.valueOf(5), Integer.valueOf(1));
                } else if (i2 == 19) {
                    this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.RELIEF);
                }
                decodeFile = this.bitmapOrg;
                if (!this.isPositionZero) {
                    final int finalI = i;
                    final Bitmap finalDecodeFile1 = decodeFile;
                    GridActivity.this.runOnUiThread(new Runnable() {
                        public void run() {
                            View view = null;
                            if (view instanceof LinearLayout) {
                                view = ((LinearLayout) view).getChildAt(0);
                                if (view instanceof ImageView) {
                                    ((ImageView) view).setImageBitmap(finalDecodeFile1);
                                }
                            }
                            view.requestLayout();
                            LinearLayout access$10100 = GridActivity.this.mainLinear;
                            View view2 = view;
                            access$10100.updateViewLayout(view2, view2.getLayoutParams());
                            GridActivity.this.viewPieces.set(finalI, view);
                            GridActivity.this.puzzleView.replace(view, "");
                        }
                    });
                }
                int nextInt = new Random().nextInt(10000);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Image-");
                stringBuilder.append(nextInt);
                stringBuilder.append(".jpg");
                String stringBuilder2 = stringBuilder.toString();
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append(GridActivity.this.context.getCacheDir());
                stringBuilder3.append("/temp");
                File file = new File(stringBuilder3.toString());
                if (!file.exists()) {
                    file.mkdirs();
                }
                File file2 = new File(file, stringBuilder2);
                if (file2.exists()) {
                    file2.delete();
                }
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    decodeFile.compress(CompressFormat.JPEG, 100, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                this.temp.add(file2.getAbsolutePath());
            }
            return null;
        }


        public void onPostExecute(Void voidR) {
            super.onPostExecute(voidR);
            GridActivity.this.puzzleView.requestLayout();
            GridActivity.this.bitmapPaint.clear();
            GridActivity.this.bitmapPaint = (ArrayList) this.temp.clone();
            this.progressDialog.dismiss();
        }
    }

    private void updateStickerPos() {
    }

    public void onDoubleTap() {
    }

    public void onEdit(View view, Uri uri) {
    }

    public void onRotateMove(View view) {
    }

    public void onScaleMove(View view) {
    }

    public void onTouchMove(View view) {
    }

    @SuppressLint("Range")
    public GridActivity() {
        String str = "";
        this.mDrawableName = str;
        this.color_Type = "colored";
        this.filterFlag = false;
        this.filterPosition = 0;
        this.adjustFlag = false;
        this.brightnessProgress = 0;
        this.contrastProgress = 0;
        this.saturationProgress = 0;
        this.hueProgress = 0;
        this.drawColorFlag = false;
        String str2 = "#000000";
        this.drawLineColor = Color.parseColor(str2);
        this.selectedLineSize = 1;
        this.drawEraseFlag = false;
        this.drawMode = "draw";
        this.drawFlag = false;
        this.inOrder = true;
        this.first = new Handler();
        this.temp = new ArrayList();
        this.tempPos = new ArrayList();
        this.videoCount = 0;
        this.videoPos = 0;
        this.musicFlag = false;
        this.musicPath = str;
        this.handler = new Handler();
        this.focusedCopy = null;
        this.fontName = str;
        this.tColor = Color.parseColor(str2);
        this.tAlpha = 100;
        this.borderColor = Color.parseColor(str2);
        this.shadowColor = Color.parseColor(str2);
        this.shadowProg = 0;
        this.shadowXYProg = 0;
        this.bgAlpha = 0;
        this.bgColor = 0;
        this.bgDrawable = "0";
        this.editMode = false;
        this.touchChange = false;
        str = "#ffffff";
        this.stkrColorSet = Color.parseColor(str);
        this.textColorSet = Color.parseColor(str);
        this.textFontFlag = false;
        this.textColorFlag = false;
        this.textStyleFlag = false;
        this.textBGFlag = false;
        this.textAlignFlag = false;
        this.txtGravity = "C";
        this.txtCharSpacing = 0.0f;
        this.txtLineSpacing = 0.0f;
        this.textOpacityFlag = false;
        this.textLayerFlag = false;
        this.lastPositionSwap = 0;
        this.isImageSwapEnable = false;
        this.zoomInScale = 0.0f;
        this.zoomOutScale = 0.0f;
        this.isVideoSwapEnable = false;
        this.isMute = true;
        this.fromPause = false;
        this.saveClick = true;
        this.baseViewWidth = 0;
        this.baseViewHeight = 0;
        this.selectedPiecePosition = -1;
        this.runnableFirst = new Runnable() {
            public void run() {
                if (GridActivity.this.videoCount <= 0) {
                    return;
                }
                GridActivity gridActivity;
                if (GridActivity.this.videoCount == 4) {
                    if (GridActivity.this.videoPos == 4) {
                        gridActivity = GridActivity.this;
                        gridActivity.videoPos = gridActivity.videoPos - 1;
                        if (((TextureVideoView) GridActivity.this.temp.get(3)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(3)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(3)).seekTo(0);
                        }
                        if (((TextureVideoView) GridActivity.this.temp.get(2)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(2)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(2)).seekTo(0);
                        }
                        if (((TextureVideoView) GridActivity.this.temp.get(1)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(1)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(1)).seekTo(0);
                        }
                        ((TextureVideoView) GridActivity.this.temp.get(0)).seekTo(0);
                        ((TextureVideoView) GridActivity.this.temp.get(0)).start();
                        GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, ((TextureVideoView) GridActivity.this.temp.get(0)).getVideoDuration());
                    } else if (GridActivity.this.videoPos == 3) {
                        gridActivity = GridActivity.this;
                        gridActivity.videoPos = gridActivity.videoPos - 1;
                        if (((TextureVideoView) GridActivity.this.temp.get(3)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(3)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(3)).seekTo(0);
                        }
                        if (((TextureVideoView) GridActivity.this.temp.get(2)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(2)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(2)).seekTo(0);
                        }
                        ((TextureVideoView) GridActivity.this.temp.get(1)).seekTo(0);
                        ((TextureVideoView) GridActivity.this.temp.get(1)).start();
                        if (((TextureVideoView) GridActivity.this.temp.get(0)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(0)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(0)).seekTo(0);
                        }
                        GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, ((TextureVideoView) GridActivity.this.temp.get(1)).getVideoDuration());
                    } else if (GridActivity.this.videoPos == 2) {
                        gridActivity = GridActivity.this;
                        gridActivity.videoPos = gridActivity.videoPos - 1;
                        if (((TextureVideoView) GridActivity.this.temp.get(3)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(3)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(3)).seekTo(0);
                        }
                        ((TextureVideoView) GridActivity.this.temp.get(2)).seekTo(0);
                        ((TextureVideoView) GridActivity.this.temp.get(2)).start();
                        if (((TextureVideoView) GridActivity.this.temp.get(1)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(1)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(1)).seekTo(0);
                        }
                        if (((TextureVideoView) GridActivity.this.temp.get(0)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(0)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(0)).seekTo(0);
                        }
                        GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, ((TextureVideoView) GridActivity.this.temp.get(2)).getVideoDuration());
                    } else {
                        gridActivity = GridActivity.this;
                        gridActivity.videoPos = gridActivity.videoCount;
                        ((TextureVideoView) GridActivity.this.temp.get(3)).seekTo(0);
                        ((TextureVideoView) GridActivity.this.temp.get(3)).start();
                        if (((TextureVideoView) GridActivity.this.temp.get(2)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(2)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(2)).seekTo(0);
                        }
                        if (((TextureVideoView) GridActivity.this.temp.get(1)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(1)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(1)).seekTo(0);
                        }
                        if (((TextureVideoView) GridActivity.this.temp.get(0)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(0)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(0)).seekTo(0);
                        }
                        GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, ((TextureVideoView) GridActivity.this.temp.get(3)).getVideoDuration());
                    }
                } else if (GridActivity.this.videoCount == 3) {
                    if (GridActivity.this.videoPos == 3) {
                        gridActivity = GridActivity.this;
                        gridActivity.videoPos = gridActivity.videoPos - 1;
                        if (((TextureVideoView) GridActivity.this.temp.get(2)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(2)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(2)).seekTo(0);
                        }
                        if (((TextureVideoView) GridActivity.this.temp.get(1)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(1)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(1)).seekTo(0);
                        }
                        ((TextureVideoView) GridActivity.this.temp.get(0)).seekTo(0);
                        ((TextureVideoView) GridActivity.this.temp.get(0)).start();
                        GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, ((TextureVideoView) GridActivity.this.temp.get(0)).getVideoDuration());
                    } else if (GridActivity.this.videoPos == 2) {
                        gridActivity = GridActivity.this;
                        gridActivity.videoPos = gridActivity.videoPos - 1;
                        if (((TextureVideoView) GridActivity.this.temp.get(2)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(2)).pause();
                            ((TextureVideoView) GridActivity.this.temp.get(2)).seekTo(0);
                        }
                        ((TextureVideoView) GridActivity.this.temp.get(1)).seekTo(0);
                        ((TextureVideoView) GridActivity.this.temp.get(1)).start();
                        if (((TextureVideoView) GridActivity.this.temp.get(0)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(0)).seekTo(0);
                            ((TextureVideoView) GridActivity.this.temp.get(0)).pause();
                        }
                        GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, ((TextureVideoView) GridActivity.this.temp.get(1)).getVideoDuration());
                    } else {
                        gridActivity = GridActivity.this;
                        gridActivity.videoPos = gridActivity.videoCount;
                        ((TextureVideoView) GridActivity.this.temp.get(2)).seekTo(0);
                        ((TextureVideoView) GridActivity.this.temp.get(2)).start();
                        if (((TextureVideoView) GridActivity.this.temp.get(1)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(1)).seekTo(0);
                            ((TextureVideoView) GridActivity.this.temp.get(1)).pause();
                        }
                        if (((TextureVideoView) GridActivity.this.temp.get(0)).isPlaying()) {
                            ((TextureVideoView) GridActivity.this.temp.get(0)).seekTo(0);
                            ((TextureVideoView) GridActivity.this.temp.get(0)).pause();
                        }
                        GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, ((TextureVideoView) GridActivity.this.temp.get(2)).getVideoDuration());
                    }
                } else if (GridActivity.this.videoCount != 2) {
                    gridActivity = GridActivity.this;
                    gridActivity.videoPos = gridActivity.videoCount;
                    ((TextureVideoView) GridActivity.this.temp.get(0)).seekTo(0);
                    ((TextureVideoView) GridActivity.this.temp.get(0)).start();
                    GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, ((TextureVideoView) GridActivity.this.temp.get(0)).getVideoDuration());
                } else if (GridActivity.this.videoPos == 2) {
                    gridActivity = GridActivity.this;
                    gridActivity.videoPos = gridActivity.videoPos - 1;
                    if (((TextureVideoView) GridActivity.this.temp.get(1)).isPlaying()) {
                        ((TextureVideoView) GridActivity.this.temp.get(1)).pause();
                        ((TextureVideoView) GridActivity.this.temp.get(1)).seekTo(0);
                    }
                    ((TextureVideoView) GridActivity.this.temp.get(0)).seekTo(0);
                    ((TextureVideoView) GridActivity.this.temp.get(0)).start();
                    GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, ((TextureVideoView) GridActivity.this.temp.get(0)).getVideoDuration());
                } else {
                    gridActivity = GridActivity.this;
                    gridActivity.videoPos = gridActivity.videoCount;
                    ((TextureVideoView) GridActivity.this.temp.get(1)).seekTo(0);
                    ((TextureVideoView) GridActivity.this.temp.get(1)).start();
                    if (((TextureVideoView) GridActivity.this.temp.get(0)).isPlaying()) {
                        ((TextureVideoView) GridActivity.this.temp.get(0)).seekTo(0);
                        ((TextureVideoView) GridActivity.this.temp.get(0)).pause();
                    }
                    GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, ((TextureVideoView) GridActivity.this.temp.get(1)).getVideoDuration());
                }
            }
        };
        this.runnable = new Runnable() {
            public void run() {
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(" progress :: ");
                    stringBuilder.append(GridActivity.this.mediaPlayer.getCurrentPosition());
                    GridActivity.this.seekMusic.setProgress(GridActivity.this.mediaPlayer.getCurrentPosition());
                    GridActivity.this.handler.postDelayed(this, 1);
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                }
            }
        };
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_grid);
        this.context = this;
        gridActivity = this;
        MyApplication.getInstance().KeepScreenOn(activity);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        PutAnalyticsEvent();
        screenWidth = (float) displayMetrics.widthPixels;
        screenHeight = (float) (displayMetrics.heightPixels - ImageUtils.dpToPx(this, 105));
        deviceWidth = getResources().getDisplayMetrics().widthPixels;
        int intExtra = getIntent().getIntExtra("type", 0);
        int intExtra2 = getIntent().getIntExtra("piece_size", 0);
        int intExtra3 = getIntent().getIntExtra("theme_id", 0);
        bitmapPaint = getIntent().getStringArrayListExtra("photo_path");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" type :: ");
        stringBuilder.append(intExtra);
        String str = "init";
        stringBuilder = new StringBuilder();
        stringBuilder.append(" pieceSize :: ");
        stringBuilder.append(intExtra2);
        Log.e(str, stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(" themeId :: ");
        stringBuilder.append(intExtra3);
        Log.e(str, stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(" Util.selectedVid ::");
        stringBuilder.append(Util.selectedVid);
        Log.e(str, stringBuilder.toString());
        this.themeId = intExtra3;
        this.selectedThemeId = intExtra3;
        stringBuilder = new StringBuilder();
        stringBuilder.append(" this.themeId :: ");
        stringBuilder.append(this.themeId);
        this.originalBitmapPaint = new ArrayList(this.bitmapPaint);
        this.puzzleLayout = PuzzleUtils.getPuzzleLayout(intExtra, intExtra2, intExtra3);
        initView();
        getBaseViewDimension();
        this.puzzleView.post(new Runnable() {
            public void run() {
                loadPhotoAndVideos();
            }
        });
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "GridActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private String getAndSaveAllSticker() {
        if (this.txtStickerRel.getChildCount() <= 0 && this.txtWatermarkStickerRel.getChildCount() <= 0) {
            return "";
        }
        int nextInt = new Random().nextInt(10000);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Sticker-");
        stringBuilder.append(nextInt);
        stringBuilder.append(".png");
        String stringBuilder2 = stringBuilder.toString();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(this.context.getCacheDir());
        stringBuilder3.append("/tempstikerimages");
        File file = new File(stringBuilder3.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(file, stringBuilder2);
        if (file2.exists()) {
            file2.delete();
        }
        this.allStickerFrame.buildDrawingCache();
        Bitmap copy = this.allStickerFrame.getDrawingCache().copy(Config.ARGB_8888, false);
        this.allStickerFrame.destroyDrawingCache();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            copy.compress(CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return file2.getAbsolutePath();
    }

    private String getAndSaveBGImageColorFrame() {
        int nextInt = new Random().nextInt(10000);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("BG-");
        stringBuilder.append(nextInt);
        stringBuilder.append(".png");
        String stringBuilder2 = stringBuilder.toString();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(this.context.getCacheDir());
        stringBuilder3.append("/tempbgimages");
        File file = new File(stringBuilder3.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(file, stringBuilder2);
        if (file2.exists()) {
            file2.delete();
        }
        this.maskBGFrame.setDrawingCacheEnabled(true);
        this.maskBGFrame.buildDrawingCache();
        Bitmap copy = this.maskBGFrame.getDrawingCache().copy(Config.ARGB_8888, false);
        this.maskBGFrame.destroyDrawingCache();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            copy.compress(CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return file2.getAbsolutePath();
    }

    public String saveAllImageAsBitmap() {
        this.puzzleView.buildDrawingCache();
        Bitmap copy = this.puzzleView.getDrawingCache().copy(Config.ARGB_8888, false);
        this.puzzleView.destroyDrawingCache();
        int nextInt = new Random().nextInt(10000);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Img-");
        stringBuilder.append(nextInt);
        stringBuilder.append(".png");
        String stringBuilder2 = stringBuilder.toString();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(this.context.getCacheDir());
        stringBuilder3.append("/tempgridimages");
        File file = new File(stringBuilder3.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(file, stringBuilder2);
        if (file2.exists()) {
            file2.delete();
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            copy.compress(CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return file2.getAbsolutePath();
    }

    public void onBackPressed() {
        if (this.borderBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED && this.bgBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED && this.horizontalTextScrollView.getVisibility() != View.VISIBLE && this.stickerBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED && this.drawBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED && this.watermarkBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED && this.horizontalSingleImageScrollView.getVisibility() != View.VISIBLE && this.horizontalSingleVideoScrollView.getVisibility() != View.VISIBLE) {
            backConfirmationDialog();
        } else if (this.borderBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
            this.imgGridBack.performClick();
        } else if (this.bgBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
            this.imgBGBack.performClick();
        } else if (this.horizontalTextScrollView.getVisibility() == View.VISIBLE) {
            this.imgTextBack.performClick();
        } else if (this.stickerBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
            this.imgStickerBack.performClick();
        } else if (this.drawBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
            this.imgDrawCancel.performClick();
        } else if (this.watermarkBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
            this.imgWatermarkBack.performClick();
        } else if (this.horizontalSingleImageScrollView.getVisibility() == View.VISIBLE) {
            this.imgSinImgBack.performClick();
        } else if (this.horizontalSingleVideoScrollView.getVisibility() == View.VISIBLE) {
            this.imgSinVidBack.performClick();
        }
    }

    private void backConfirmationDialog() {
        new AlertDialog.Builder(this).setMessage("All changes will be discarded.").setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                GridActivity.this.stopAllTextureViewVideo();
                GridActivity.this.finish();
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }

    private void stopAllTextureViewVideo() {
        for (int i = 0; i < this.bitmapPaint.size(); i++) {
            if (Util.isVideoFile(this.bitmapPaint.get(i))) {
                View view = this.viewPieces.get(i);
                if (view instanceof RelativeLayout) {
                    view = ((RelativeLayout) view).getChildAt(0);
                    if (view instanceof TextureVideoView) {
                        Log.e("save", " stop");
                        TextureVideoView textureVideoView = (TextureVideoView) view;
                        textureVideoView.stop();
                        textureVideoView.setMediaPlayerCallback(null);
                    }
                }
            }
        }
    }


    public void onResume() {
        super.onResume();
        String str = "grid";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" onResume fromPause ::: ");
        stringBuilder.append(this.fromPause);
        stringBuilder.append("----  saveClick :: ");
        stringBuilder.append(this.saveClick);
        Log.e(str, stringBuilder.toString());
        if (this.fromPause && this.saveClick) {
            if (this.inOrder) {
                this.first.removeCallbacks(this.runnableFirst);
                startOrStopAllVideo("start");
            } else {
                this.first.removeCallbacks(this.runnableFirst);
                this.first.postDelayed(this.runnableFirst, 10);
            }
            if (!this.musicPath.equals("")) {
                MediaPlayer mediaPlayer = this.mediaPlayer;
                if (mediaPlayer != null) {
                    mediaPlayer.start();
                }
            }
            updateTextureView();
        }
    }


    public void onPause() {
        super.onPause();
        this.fromPause = true;
        startOrStopAllVideo("pause");
        this.first.removeCallbacks(this.runnableFirst);
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            this.mediaPlayer.pause();
        }
    }


    public void onStop() {
        super.onStop();
    }

    public void onDestroy() {
        super.onDestroy();
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            this.mediaPlayer.reset();
            this.mediaPlayer.release();
            this.mediaPlayer = null;
        }
        this.handler.removeCallbacks(this.runnable);
    }

    private void loadPhotoAndVideos() {
        final int areaCount = this.bitmapPaint.size() > this.puzzleLayout.getAreaCount() ? this.puzzleLayout.getAreaCount() : this.bitmapPaint.size();
        for (int i = 0; i < areaCount; i++) {
            Target anonymousClass5 = new Target() {
                public void onBitmapFailed(Drawable drawable) {
                }

                public void onPrepareLoad(Drawable drawable) {
                }

                public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
                    if (viewPieces.size() == areaCount) {
                        if (bitmapPaint.size() < puzzleLayout.getAreaCount()) {
                            for (int i = 0; i < puzzleLayout.getAreaCount(); i++) {
                                puzzleView.addPiece(viewPieces.get(i % areaCount));
                            }
                        } else {
                            puzzleView.addPieces(viewPieces);
                        }
                    }
                    targets.remove(this);
                }

                @Override
                public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                }
            };
            Picasso.get().load(R.drawable.demo9).config(Config.RGB_565).into(anonymousClass5);
            this.targets.add(anonymousClass5);
        }
    }

    private void initView() {
        this.mainLinear = findViewById(R.id.main_layout);
        this.frame = findViewById(R.id.frame_main);
        this.maskBGFrame = findViewById(R.id.frame_main_bg_t);
        this.maskableFrameLayout = findViewById(R.id.mask_frame);
        this.frameMainBg = findViewById(R.id.frame_main_bg);
        this.frameMainColorBG = findViewById(R.id.frame_main_color_bg);
        this.horizontalMainScrollView = findViewById(R.id.main_horizontal);
        this.horizontalTextScrollView = findViewById(R.id.horizontal_text);
        this.horizontalSingleImageScrollView = findViewById(R.id.horizontal_single_image);
        this.horizontalSingleVideoScrollView = findViewById(R.id.horizontal_single_video);
        this.puzzleView = findViewById(R.id.puzzle_view);
        imgBack = findViewById(R.id.img_tool_back);
        iv_done = findViewById(R.id.iv_done);
        this.txtStickerRel = findViewById(R.id.txt_sticker_rel);
        this.allStickerFrame = findViewById(R.id.sticker_save_frame);
        this.linImageAdd = findViewById(R.id.lin_image_add_grid);
        this.linLayout = findViewById(R.id.lin_layout);
        this.txtLayout = findViewById(R.id.txt_layout);
        this.imgLayout = findViewById(R.id.img_layout);
        this.layoutRecyclerView = findViewById(R.id.layout_recycler);
        this.linImage = findViewById(R.id.lin_image);
        this.txtImage = findViewById(R.id.txt_image);
        this.imgImage = findViewById(R.id.img_image);
        this.linBorder = findViewById(R.id.lin_border);
        this.txtBorder = findViewById(R.id.txt_border);
        this.imgBorder = findViewById(R.id.img_border);
        LinearLayout linearLayout = findViewById(R.id.bottom_sheet_border);
        this.bottomSheetBorder = linearLayout;
        BottomSheetBehavior from = BottomSheetBehavior.from(linearLayout);
        this.borderBottomSheetBehavior = from;
        this.seekViewPadding = findViewById(R.id.seek_grid_padding);
        this.seekPiecePadding = findViewById(R.id.seek_piece_padding);
        this.seekCorner = findViewById(R.id.seek_corner);
        this.txtViewPadding = findViewById(R.id.txt_view_padding_per);
        this.txtPiecePadding = findViewById(R.id.txt_piece_pacing_per);
        this.txtCorner = findViewById(R.id.txt_corner_per);
        this.txtMainBorder = findViewById(R.id.txt_main_border);
        this.txtMainFrame = findViewById(R.id.txt_main_frame);
        this.linCorner = findViewById(R.id.lin_corner);
        this.linMainBorder = findViewById(R.id.lin_main_border);
        this.linMainFrame = findViewById(R.id.lin_main_frame);
        this.frameRecycler = findViewById(R.id.frame_recycler);
        this.imgGridBack = findViewById(R.id.img_back);
        this.imgGridDone = findViewById(R.id.img_done);
        this.txtMainBorder.setOnClickListener(this);
        this.txtMainFrame.setOnClickListener(this);
        this.imgGridBack.setOnClickListener(this);
        this.imgGridDone.setOnClickListener(this);
        this.linRatio = findViewById(R.id.lin_ratio);
        this.txtRatio = findViewById(R.id.txt_ratio);
        this.imgRatio = findViewById(R.id.img_ratio);
        this.ratioRecycler = findViewById(R.id.ratio_recycler);
        this.linBG = findViewById(R.id.lin_bg);
        this.txtBG = findViewById(R.id.txt_bg);
        this.imgBG = findViewById(R.id.img_bg);
        linearLayout = findViewById(R.id.bottom_sheet_bg);
        this.bottomSheetBG = linearLayout;
        from = BottomSheetBehavior.from(linearLayout);
        this.bgBottomSheetBehavior = from;
        this.txtMainImage = findViewById(R.id.txt_main_image);
        this.txtMainColor = findViewById(R.id.txt_main_color);
        this.linMainImage = findViewById(R.id.lin_main_image);
        this.linMainColor = findViewById(R.id.lin_main_color);
        this.bgImageRecycler = findViewById(R.id.image_recycler);
        this.bgColorRecycler = findViewById(R.id.bg_color_recycler);
        this.imgBGBack = findViewById(R.id.img_bg_back);
        this.imgBGDone = findViewById(R.id.img_bg_done);
        this.txtMainImage.setOnClickListener(this);
        this.txtMainColor.setOnClickListener(this);
        this.imgBGBack.setOnClickListener(this);
        this.imgBGDone.setOnClickListener(this);
        this.linText = findViewById(R.id.lin_text);
        this.txtText = findViewById(R.id.txt_text);
        this.imgText = findViewById(R.id.img_text);
        this.guideline = findViewById(R.id.guidelines);
        this.linSticker = findViewById(R.id.lin_sticker);
        this.txtSticker = findViewById(R.id.txt_sticker);
        this.imgSticker = findViewById(R.id.img_sticker);
        linearLayout = findViewById(R.id.bottom_sheet_sticker);
        this.bottomSheetSticker = linearLayout;
        from = BottomSheetBehavior.from(linearLayout);
        this.stickerBottomSheetBehavior = from;
        this.imgStickerBack = findViewById(R.id.img_sticker_back);
        this.imgStickerImageClip = findViewById(R.id.img_sticker_image_clip);
        this.imgStickerCateOne = findViewById(R.id.img_sticker_category_one);
        this.imgStickerCateTwo = findViewById(R.id.img_sticker_category_two);
        this.imgStickerCateThree = findViewById(R.id.img_sticker_category_thee);
        this.imgStickerCateForAdd = findViewById(R.id.img_sticker_category_for_add);
        this.stickerRecyclerCatOne = findViewById(R.id.sticker_cat_one_recycler);
        this.stickerRecyclerCatTwo = findViewById(R.id.sticker_cat_two_recycler);
        this.stickerRecyclerCatThree = findViewById(R.id.sticker_cat_three_recycler);
        this.linStickerCatForAdd = findViewById(R.id.lin_sticker_cat_for_add);
        this.linImageAddAsSticker = findViewById(R.id.lin_main_image_add_sticker);
        this.imgStickerBack.setOnClickListener(this);
        this.imgStickerImageClip.setOnClickListener(this);
        this.imgStickerCateOne.setOnClickListener(this);
        this.imgStickerCateTwo.setOnClickListener(this);
        this.imgStickerCateThree.setOnClickListener(this);
        this.imgStickerCateForAdd.setOnClickListener(this);
        this.linImageAddAsSticker.setOnClickListener(this);
        this.linFilter = findViewById(R.id.lin_filter);
        this.txtFilter = findViewById(R.id.txt_filter);
        this.imgFilter = findViewById(R.id.img_filter);
        this.filterRecycler = findViewById(R.id.filter_recycler);
        this.linAdjust = findViewById(R.id.lin_adjust);
        this.txtAdjust = findViewById(R.id.txt_adjust);
        this.imgAdjust = findViewById(R.id.img_adjust);
        this.linAdjustView = findViewById(R.id.lin_adjust_view);
        this.frameBrightness = findViewById(R.id.frame_brightness);
        this.imgBrightness = findViewById(R.id.img_brightness);
        this.viewBrightness = findViewById(R.id.view_brightness);
        this.frameContrast = findViewById(R.id.frame_contrast);
        this.imgContrast = findViewById(R.id.img_contrast);
        this.viewContrast = findViewById(R.id.view_contrast);
        this.frameSaturation = findViewById(R.id.frame_saturation);
        this.imgSaturation = findViewById(R.id.img_saturation);
        this.viewSaturation = findViewById(R.id.view_saturation);
        this.frameHue = findViewById(R.id.frame_hue);
        this.imgHue = findViewById(R.id.img_hue);
        this.viewHue = findViewById(R.id.view_hue);
        this.tempTextForAdjust = findViewById(R.id.temp_text_view_for_adjust);
        this.frameBrightness.setOnClickListener(this);
        this.frameContrast.setOnClickListener(this);
        this.frameSaturation.setOnClickListener(this);
        this.frameHue.setOnClickListener(this);
        this.seekBarBrightness = findViewById(R.id.seek_brightness);
        this.seekBarContrast = findViewById(R.id.seek_contrast);
        this.seekBarSaturation = findViewById(R.id.seek_saturation);
        this.seekBarHue = findViewById(R.id.seek_hue);
        ImageView imageView = findViewById(R.id.img_reset_all);
        this.imgResetBrightness = imageView;
        imageView.setOnClickListener(this);
        this.linDraw = findViewById(R.id.lin_draw);
        this.txtDraw = findViewById(R.id.txt_draw);
        this.imgDraw = findViewById(R.id.img_draw);
        linearLayout = findViewById(R.id.bottom_sheet_draw);
        this.bottomSheetDraw = linearLayout;
        from = BottomSheetBehavior.from(linearLayout);
        this.drawBottomSheetBehavior = from;

        this.photoEditorView = findViewById(R.id.photo_editor_view);
        this.drawColorRecyclerView = findViewById(R.id.draw_color_recycler);
        this.linDrawView = findViewById(R.id.lin_draw_view);
        this.linDrawDelete = findViewById(R.id.lin_draw_delete);
        this.linDrawSizeFullView = findViewById(R.id.lin_draw_size_view);
        this.linDrawColor = findViewById(R.id.lin_draw_color);
        this.imgDrawCancel = findViewById(R.id.img_draw_cancel);
        this.imgDrawDone = findViewById(R.id.img_draw_done);
        this.imgDrawUndo = findViewById(R.id.img_draw_undo);
        this.imgDrawRedo = findViewById(R.id.img_draw_redo);
        this.imgDrawColor = findViewById(R.id.img_draw_color);
        this.imgDrawErase = findViewById(R.id.img_erase);
        this.linDrawSizeOne = findViewById(R.id.lin_draw_size_one);
        this.linDrawSizeTwo = findViewById(R.id.lin_draw_size_two);
        this.linDrawSizeThree = findViewById(R.id.lin_draw_size_three);
        this.linDrawSizeFour = findViewById(R.id.lin_draw_size_four);
        this.linDrawSizeFive = findViewById(R.id.lin_draw_size_five);
        this.imgDrawSizeOne = findViewById(R.id.img_draw_size_one);
        this.imgDrawSizeTwo = findViewById(R.id.img_draw_size_two);
        this.imgDrawSizeThree = findViewById(R.id.img_draw_size_three);
        this.imgDrawSizeFour = findViewById(R.id.img_draw_size_four);
        this.imgDrawSizeFive = findViewById(R.id.img_draw_size_five);
        this.imgDrawCancel.setOnClickListener(this);
        this.imgDrawDone.setOnClickListener(this);
        this.imgDrawUndo.setOnClickListener(this);
        this.imgDrawRedo.setOnClickListener(this);
        this.imgDrawColor.setOnClickListener(this);
        this.imgDrawErase.setOnClickListener(this);
        this.linDrawDelete.setOnClickListener(this);
        this.linDrawSizeOne.setOnClickListener(this);
        this.linDrawSizeTwo.setOnClickListener(this);
        this.linDrawSizeThree.setOnClickListener(this);
        this.linDrawSizeFour.setOnClickListener(this);
        this.linDrawSizeFive.setOnClickListener(this);
        this.txtWatermarkStickerRel = findViewById(R.id.txt_watermark_sticker_rel);
        this.linWatermark = findViewById(R.id.lin_watermark);
        this.txtWatermark = findViewById(R.id.txt_watermark);
        this.imgWatermark = findViewById(R.id.img_watermark);
        linearLayout = findViewById(R.id.bottom_sheet_watermark);
        this.bottomSheetWatermark = linearLayout;
        from = BottomSheetBehavior.from(linearLayout);
        this.watermarkBottomSheetBehavior = from;
        this.watermarkPicVidRecyclerView = findViewById(R.id.picvid_watermark_recycler);
        this.watermarkSocialRecyclerView = findViewById(R.id.social_watermark_recycler);
        this.imgWatermarkBack = findViewById(R.id.img_watermark_back);
        this.imgWatermarkDone = findViewById(R.id.img_watermark_done);
        this.txtWatermarkPicVid = findViewById(R.id.txt_main_watermark_vidmak);
        this.txtWatermarkSocial = findViewById(R.id.txt_main_watermark_social);
        this.imgWatermarkBack.setOnClickListener(this);
        this.imgWatermarkDone.setOnClickListener(this);
        this.txtWatermarkPicVid.setOnClickListener(this);
        this.txtWatermarkSocial.setOnClickListener(this);
        this.linMusic = findViewById(R.id.lin_music);
        this.txtMusic = findViewById(R.id.txt_music);
        this.imgMusic = findViewById(R.id.img_music);
        this.linMusicLayout = findViewById(R.id.lin_music_view);
        this.txtMusicName = findViewById(R.id.txt_music_name);
        this.seekMusic = findViewById(R.id.seek_music);
        imageView = findViewById(R.id.img_remove_music);
        this.imgMusicRemove = imageView;
        imageView.setOnClickListener(this);
        this.linPlayOrder = findViewById(R.id.lin_inorder);
        this.txtPlayOrder = findViewById(R.id.txt_inorder);
        this.imgPlayOrder = findViewById(R.id.img_inorder);
        this.linTextBack = findViewById(R.id.lin_text_back);
        this.imgTextBack = findViewById(R.id.img_text_back);
        this.linTextEdit = findViewById(R.id.lin_text_edit);
        this.txtTextEdit = findViewById(R.id.txt_text_edit);
        this.imgTextEdit = findViewById(R.id.img_text_edit);
        this.linTextFont = findViewById(R.id.lin_text_font);
        this.txtTextFont = findViewById(R.id.txt_text_font);
        this.imgTextFont = findViewById(R.id.img_text_font);
        this.textFontRecyclerView = findViewById(R.id.text_font_recycler);
        this.linTextColor = findViewById(R.id.lin_text_color);
        this.txtTextColor = findViewById(R.id.txt_text_color);
        this.imgTextColor = findViewById(R.id.img_text_color);
        this.textColorRecyclerView = findViewById(R.id.text_color_recycler);
        this.linTextStyle = findViewById(R.id.lin_text_style);
        this.txtTextStyle = findViewById(R.id.txt_text_style);
        this.imgTextStyle = findViewById(R.id.img_text_style);
        this.linTextStyleMain = findViewById(R.id.lin_text_style_main);
        this.txtMainTextBorder = findViewById(R.id.txt_main_text_border);
        this.txtMainTextShadow = findViewById(R.id.txt_main_text_shadow);
        this.linMainTextBorder = findViewById(R.id.lin_main_text_border);
        this.linMainTextShadow = findViewById(R.id.lin_main_text_shadow);
        this.seekBarTextBorder = findViewById(R.id.seek_border_thik);
        this.textBorderColorRecyclerView = findViewById(R.id.text_border_color_recycler);
        this.seekBarXYPos = findViewById(R.id.seek_shadow_x);
        this.seekBarShadowBlur = findViewById(R.id.seek_shadow_y);
        this.textShadowColorRecyclerView = findViewById(R.id.text_shadow_color_recycler);
        this.txtMainTextBorder.setOnClickListener(this);
        this.txtMainTextShadow.setOnClickListener(this);
        this.linTextBG = findViewById(R.id.lin_text_bg);
        this.txtTextBG = findViewById(R.id.txt_text_bg);
        this.imgTextBG = findViewById(R.id.img_text_bg);
        this.linTextBGMain = findViewById(R.id.lin_text_bg_main);
        this.txtMainTextBGImage = findViewById(R.id.txt_main_text_bg_image);
        this.txtMainTextBGColor = findViewById(R.id.txt_main_text_bg_color);
        this.linMainTextBGImage = findViewById(R.id.lin_main_text_bg_image);
        this.linMainTextBGColor = findViewById(R.id.lin_main_text_bg_color);
        this.textBGOpacity = findViewById(R.id.seek_bg_opacity);
        this.textBGImageRecyclerView = findViewById(R.id.text_bg_image_recycler);
        this.textBGColorRecyclerView = findViewById(R.id.text_bg_color_recycler);
        this.txtMainTextBGImage.setOnClickListener(this);
        this.txtMainTextBGColor.setOnClickListener(this);
        this.linTextAlign = findViewById(R.id.lin_text_align);
        this.txtTextAlign = findViewById(R.id.txt_text_align);
        this.imgTextAlign = findViewById(R.id.img_text_align);
        this.linTextAlignMain = findViewById(R.id.lin_text_align_main);
        this.imgTextAlignL = findViewById(R.id.img_main_text_align_L);
        this.imgTextAlignC = findViewById(R.id.img_main_text_align_C);
        this.imgTextAlignR = findViewById(R.id.img_main_text_align_R);
        this.charSeekPac = findViewById(R.id.seek_bg_char_spacing);
        this.lineSeekPac = findViewById(R.id.seek_bg_line_spacing);
        this.imgTextAlignL.setOnClickListener(this);
        this.imgTextAlignC.setOnClickListener(this);
        this.imgTextAlignR.setOnClickListener(this);
        this.linTextOpacity = findViewById(R.id.lin_text_opacity);
        this.txtTextOpacity = findViewById(R.id.txt_text_opacity);
        this.imgTextOpacity = findViewById(R.id.img_text_opacity);
        this.linTextOpacityMain = findViewById(R.id.lin_text_opacity_main);
        this.seekOpacity = findViewById(R.id.seek_text_opacity);
        this.txtTextOpacityPer = findViewById(R.id.txt_view_opacity_per);
        this.linTextLayerMain = findViewById(R.id.lin_text_layer_main);
        this.layContainer = findViewById(R.id.lay_container);
        ListFragment listFragment = new ListFragment();
        this.listFragment = listFragment;
        listFragment.setRelativeLayout(this.txtStickerRel, this.layContainer);
        showFragment(this.listFragment);
        this.linTextCopy = findViewById(R.id.lin_text_copy);
        this.txtTextCopy = findViewById(R.id.txt_text_copy);
        this.imgTextCopy = findViewById(R.id.img_text_copy);
        this.linSinImgBack = findViewById(R.id.lin_sin_img_back);
        this.imgSinImgBack = findViewById(R.id.img_sin_img_back);
        this.linSinImgSwap = findViewById(R.id.lin_sin_img_swap);
        this.txtSinImgSwap = findViewById(R.id.txt_sin_img_swap);
        this.imgSinImgSwap = findViewById(R.id.img_sin_img_swap);
        this.txtSinImgSwapInfo = findViewById(R.id.txt_sin_img_swap_info);
        this.linSinImgFitOut = findViewById(R.id.lin_sin_img_fitout);
        this.txtSinImgFitOut = findViewById(R.id.txt_sin_img_fitout);
        this.imgSinImgFitOut = findViewById(R.id.img_sin_img_fitout);
        this.linSinImgCrop = findViewById(R.id.lin_sin_img_crop);
        this.txtSinImgCrop = findViewById(R.id.txt_sin_img_crop);
        this.imgSinImgCrop = findViewById(R.id.img_sin_img_crop);
        this.linSinImgRotate = findViewById(R.id.lin_sin_img_rotate);
        this.txtSinImgRotate = findViewById(R.id.txt_sin_img_rotate);
        this.imgSinImgRotate = findViewById(R.id.img_sin_img_rotate);
        this.linSinImgHoriFlip = findViewById(R.id.lin_sin_img_hflip);
        this.txtSinImgHoriFlip = findViewById(R.id.txt_sin_img_hflip);
        this.imgSinImgHoriFlip = findViewById(R.id.img_sin_img_hflip);
        this.linSinImgVerFlip = findViewById(R.id.lin_sin_img_vflip);
        this.txtSinImgVerFlip = findViewById(R.id.txt_sin_img_vflip);
        this.imgSinImgVerFlip = findViewById(R.id.img_sin_img_vflip);
        this.linSinImgFilter = findViewById(R.id.lin_sin_img_filter);
        this.txtSinImgFilter = findViewById(R.id.txt_sin_img_filter);
        this.imgSinImgFilter = findViewById(R.id.img_sin_img_filter);
        this.linSinImgAdjust = findViewById(R.id.lin_sin_img_adjust);
        this.txtSinImgAdjust = findViewById(R.id.txt_sin_img_adjust);
        this.imgSinImgAdjust = findViewById(R.id.img_sin_img_adjust);
        this.linSinImgDelete = findViewById(R.id.lin_sin_img_delete);
        this.txtSinImgDelete = findViewById(R.id.txt_sin_img_delete);
        this.imgSinImgDelete = findViewById(R.id.img_sin_img_delete);
        this.linSinImgReplace = findViewById(R.id.lin_sin_img_replace);
        this.txtSinImgReplace = findViewById(R.id.txt_sin_img_replace);
        this.imgSinImgReplace = findViewById(R.id.img_sin_img_replace);
        this.linSinImgClipPhoto = findViewById(R.id.lin_sin_img_clip);
        this.txtSinImgClipPhoto = findViewById(R.id.txt_sin_img_clip);
        this.imgSinImgClipPhoto = findViewById(R.id.img_sin_img_clip);
        this.linSinImgZoomIn = findViewById(R.id.lin_sin_img_zoomin);
        this.txtSinImgZoomIn = findViewById(R.id.txt_sin_img_zoomin);
        this.imgSinImgZoomIn = findViewById(R.id.img_sin_img_zoomin);
        this.linSinImgZoomOut = findViewById(R.id.lin_sin_img_zoomout);
        this.txtSinImgZoomOut = findViewById(R.id.txt_sin_img_zoomout);
        this.imgSinImgZoomOut = findViewById(R.id.img_sin_img_zoomout);
        this.linSinImgRotateL10 = findViewById(R.id.lin_sin_img_rotate_mten);
        this.txtSinImgRotateL10 = findViewById(R.id.txt_sin_img_rotate_mten);
        this.imgSinImgRotateL10 = findViewById(R.id.img_sin_img_rotate_mten);
        this.linSinImgRotateR10 = findViewById(R.id.lin_sin_img_rotate_pten);
        this.txtSinImgRotateR10 = findViewById(R.id.txt_sin_img_rotate_pten);
        this.imgSinImgRotateR10 = findViewById(R.id.img_sin_img_rotate_pten);
        this.linSinVidBack = findViewById(R.id.lin_sin_vid_back);
        this.imgSinVidBack = findViewById(R.id.img_sin_vid_back);
        this.linSinVidTrim = findViewById(R.id.lin_sin_vid_trim);
        this.txtSinVidTrim = findViewById(R.id.txt_sin_vid_trim);
        this.imgSinVidTrim = findViewById(R.id.img_sin_vid_trim);
        this.linSinVidSwap = findViewById(R.id.lin_sin_vid_swap);
        this.txtSinVidSwap = findViewById(R.id.txt_sin_vid_swap);
        this.imgSinVidSwap = findViewById(R.id.img_sin_vid_swap);
        this.txtSinVidSwapInfo = findViewById(R.id.txt_sin_vid_swap_info);
        this.linSinVidReplace = findViewById(R.id.lin_sin_vid_replace);
        this.txtSinVidReplace = findViewById(R.id.txt_sin_vid_replace);
        this.imgSinVidReplace = findViewById(R.id.img_sin_vid_replace);
        this.linSinVidFitOut = findViewById(R.id.lin_sin_vid_fitout);
        this.txtSinVidFitOut = findViewById(R.id.txt_sin_vid_fitout);
        this.imgSinVidFitOut = findViewById(R.id.img_sin_vid_fitout);
        this.linSinVidRotate = findViewById(R.id.lin_sin_vid_rotate);
        this.txtSinVidRotate = findViewById(R.id.txt_sin_vid_rotate);
        this.imgSinVidRotate = findViewById(R.id.img_sin_vid_rotate);
        this.linSinVidMute = findViewById(R.id.lin_sin_vid_mute);
        this.txtSinVidMute = findViewById(R.id.txt_sin_vid_mute);
        this.imgSinVidMute = findViewById(R.id.img_sin_vid_mute);
        this.linSinVidDelete = findViewById(R.id.lin_sin_vid_delete);
        this.txtSinVidDelete = findViewById(R.id.txt_sin_vid_delete);
        this.imgSinVidDelete = findViewById(R.id.img_sin_vid_delete);
        this.imgBack.setOnClickListener(this);
        iv_done.setOnClickListener(this);
        this.linImageAdd.setOnClickListener(this);
        this.linLayout.setOnClickListener(this);
        this.linBorder.setOnClickListener(this);
        this.linRatio.setOnClickListener(this);
        this.linBG.setOnClickListener(this);
        this.linText.setOnClickListener(this);
        this.linImage.setOnClickListener(this);
        this.linSticker.setOnClickListener(this);
        this.linFilter.setOnClickListener(this);
        this.linAdjust.setOnClickListener(this);
        this.linDraw.setOnClickListener(this);
        this.linWatermark.setOnClickListener(this);
        this.linMusic.setOnClickListener(this);
        this.linPlayOrder.setOnClickListener(this);
        this.imgTextBack.setOnClickListener(this);
        this.linTextBack.setOnClickListener(this);
        this.linTextEdit.setOnClickListener(this);
        this.linTextFont.setOnClickListener(this);
        this.linTextColor.setOnClickListener(this);
        this.linTextStyle.setOnClickListener(this);
        this.linTextBG.setOnClickListener(this);
        this.linTextAlign.setOnClickListener(this);
        this.linTextOpacity.setOnClickListener(this);
        this.linTextCopy.setOnClickListener(this);
        this.imgSinImgBack.setOnClickListener(this);
        this.linSinImgSwap.setOnClickListener(this);
        this.linSinImgFitOut.setOnClickListener(this);
        this.linSinImgCrop.setOnClickListener(this);
        this.linSinImgRotate.setOnClickListener(this);
        this.linSinImgHoriFlip.setOnClickListener(this);
        this.linSinImgVerFlip.setOnClickListener(this);
        this.linSinImgFilter.setOnClickListener(this);
        this.linSinImgAdjust.setOnClickListener(this);
        this.linSinImgDelete.setOnClickListener(this);
        this.linSinImgReplace.setOnClickListener(this);
        this.linSinImgClipPhoto.setOnClickListener(this);
        this.linSinImgZoomIn.setOnClickListener(this);
        this.linSinImgZoomOut.setOnClickListener(this);
        this.linSinImgRotateL10.setOnClickListener(this);
        this.linSinImgRotateR10.setOnClickListener(this);
        this.imgSinVidBack.setOnClickListener(this);
        this.linSinVidTrim.setOnClickListener(this);
        this.linSinVidSwap.setOnClickListener(this);
        this.linSinVidReplace.setOnClickListener(this);
        this.linSinVidFitOut.setOnClickListener(this);
        this.linSinVidRotate.setOnClickListener(this);
        this.linSinVidMute.setOnClickListener(this);
        this.linSinVidDelete.setOnClickListener(this);
        if (Util.selectedVid > 0) {
            this.linCorner.setVisibility(View.GONE);
            this.linFilter.setVisibility(View.GONE);
            this.linAdjust.setVisibility(View.GONE);
            this.linDraw.setVisibility(View.GONE);
            this.linMusic.setVisibility(View.VISIBLE);
            if (Util.selectedVid == 1) {
                this.linPlayOrder.setVisibility(View.GONE);
            } else {
                this.linPlayOrder.setVisibility(View.VISIBLE);
            }
        } else {
            this.linCorner.setVisibility(View.VISIBLE);
            this.linMusic.setVisibility(View.GONE);
            this.linPlayOrder.setVisibility(View.GONE);
        }
        addLayout();
        puzzleViewMethod();
        layoutView();
        borderView();
        frameView();
        ratioView();
        bgImageView();
        bgColorView();
        stickerEmojiCategoryOneView();
        stickerMsgTextCategoryOneView();
        stickerPartyCategoryOneView();
        filterView();
        adjustView();
        drawView();
        musicView();
        watermarkView();
        textFontView();
        textColorView();
        textBorderColorView();
        textShadowColorView();
        textBgImageView();
        textBgColorView();
        textAlignView();
        textOpacityView();
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            Rect rect;
            if (this.borderBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                rect = new Rect();
                this.bottomSheetBorder.getGlobalVisibleRect(rect);
                if (!rect.contains((int) motionEvent.getRawX(), (int) motionEvent.getRawY())) {
                    this.imgGridBack.performClick();
                    return true;
                }
            }
            if (this.bgBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                rect = new Rect();
                this.bottomSheetBG.getGlobalVisibleRect(rect);
                if (!rect.contains((int) motionEvent.getRawX(), (int) motionEvent.getRawY())) {
                    this.imgBGBack.performClick();
                    return true;
                }
            }
            if (this.stickerBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                rect = new Rect();
                this.bottomSheetSticker.getGlobalVisibleRect(rect);
                if (!rect.contains((int) motionEvent.getRawX(), (int) motionEvent.getRawY())) {
                    this.imgStickerBack.performClick();
                    return true;
                }
            }
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    private void showFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.lay_container, fragment, "fragment").commit();
    }

    private void puzzleViewMethod() {
        this.puzzleView.setPuzzleLayout(this.puzzleLayout);
        this.puzzleView.setTouchEnable(true);
        this.puzzleView.setNeedDrawLine(false);
        this.puzzleView.setNeedDrawOuterLine(false);
        this.puzzleView.setLineSize(8);
        this.puzzleView.setLineColor(getResources().getColor(R.color.puzzleLineColor));
        this.puzzleView.setSelectedLineColor(getResources().getColor(R.color.puzzleSelectedLineColor));
        this.puzzleView.setHandleBarColor(getResources().getColor(R.color.puzzleHandelColor));
        this.puzzleView.setAnimateDuration(300);
        this.puzzleView.setOnPieceSelectedListener(new PuzzleView.OnPieceSelectedListener() {
            public void onPieceSelected(PuzzlePiece puzzlePiece, int i) {
                GridActivity.this.selectedPiecePosition = i;
                GridActivity.this.currentPiece = puzzlePiece;
                View view = GridActivity.this.viewPieces.get(GridActivity.this.selectedPiecePosition);
                if (view instanceof RelativeLayout) {
                    view = ((RelativeLayout) view).getChildAt(0);
                    if (view instanceof TextureVideoView) {
                        if (((TextureVideoView) view).isMute()) {
                            GridActivity.this.isMute = false;
                            GridActivity.this.imgSinVidMute.setImageResource(0);
                            GridActivity.this.imgSinVidMute.setImageResource(R.drawable.ic_sound_unselect);
                            GridActivity.this.txtSinVidMute.setText("On");
                        } else {
                            GridActivity.this.isMute = true;
                            GridActivity.this.imgSinVidMute.setImageResource(0);
                            GridActivity.this.imgSinVidMute.setImageResource(R.drawable.ic_mute_unselect);
                            GridActivity.this.txtSinVidMute.setText("Off");
                        }
                    }
                }
                GridActivity.this.hideLayoutView(false);
                GridActivity.this.hideRatioView(false);
                GridActivity.this.hideFilterView(false);
                GridActivity.this.hideAdjustView(false);
                GridActivity.this.hideMusicView(false);
                GridActivity.this.imgTextBack.performClick();
                if (GridActivity.this.bitmapPaint.size() != 1) {
                    boolean isVideoFile = Util.isVideoFile(GridActivity.this.bitmapPaint.get(i));
                    String str = "start";
                    if (isVideoFile) {
                        if (GridActivity.this.isImageSwapEnable) {
                            GridActivity.this.isImageSwapEnable = false;
                            GridActivity.this.puzzleView.swapPiece(GridActivity.this.lastPositionSwap, i);
                            GridActivity.this.puzzleView.requestLayout();
                            GridActivity.this.pieceUnSelect();
                            GridActivity.this.imgSinImgBack.performClick();
                            GridActivity.this.singleImageOptionShow(false);
                        } else if (GridActivity.this.isVideoSwapEnable) {
                            GridActivity.this.isVideoSwapEnable = false;
                            GridActivity.this.puzzleView.swapPiece(GridActivity.this.lastPositionSwap, i);
                            GridActivity.this.puzzleView.requestLayout();
                            GridActivity.this.pieceUnSelect();
                            GridActivity.this.imgSinVidBack.performClick();
                            GridActivity.this.singleVideoOptionShow(false);
                            GridActivity.this.startOrStopAllVideo(str);
                        } else {
                            GridActivity.this.startOrStopOnlySelectedVideo();
                            GridActivity.this.singleVideoOptionShow(true);
                        }
                    } else if (GridActivity.this.isImageSwapEnable) {
                        GridActivity.this.isImageSwapEnable = false;
                        GridActivity.this.puzzleView.swapPiece(GridActivity.this.lastPositionSwap, i);
                        GridActivity.this.puzzleView.requestLayout();
                        GridActivity.this.pieceUnSelect();
                        GridActivity.this.imgSinImgBack.performClick();
                        GridActivity.this.singleImageOptionShow(false);
                    } else if (GridActivity.this.isVideoSwapEnable) {
                        GridActivity.this.isVideoSwapEnable = false;
                        GridActivity.this.puzzleView.swapPiece(GridActivity.this.lastPositionSwap, i);
                        GridActivity.this.puzzleView.requestLayout();
                        GridActivity.this.pieceUnSelect();
                        GridActivity.this.imgSinVidBack.performClick();
                        GridActivity.this.singleVideoOptionShow(false);
                        GridActivity.this.startOrStopAllVideo(str);
                    } else {
                        GridActivity.this.startOrStopAllVideo("pause");
                        GridActivity.this.singleImageOptionShow(true);
                    }
                } else if (Util.isVideoFile(GridActivity.this.bitmapPaint.get(0))) {
                    if (GridActivity.this.isImageSwapEnable) {
                        GridActivity.this.isImageSwapEnable = false;
                        GridActivity.this.puzzleView.swapPiece(GridActivity.this.lastPositionSwap, i);
                        GridActivity.this.puzzleView.requestLayout();
                        GridActivity.this.pieceUnSelect();
                        GridActivity.this.imgSinImgBack.performClick();
                        GridActivity.this.singleImageOptionShow(false);
                    } else if (GridActivity.this.isVideoSwapEnable) {
                        GridActivity.this.isVideoSwapEnable = false;
                        GridActivity.this.puzzleView.swapPiece(GridActivity.this.lastPositionSwap, i);
                        GridActivity.this.puzzleView.requestLayout();
                        GridActivity.this.pieceUnSelect();
                        GridActivity.this.imgSinVidBack.performClick();
                        GridActivity.this.singleVideoOptionShow(false);
                    } else {
                        GridActivity.this.singleVideoOptionShow(true);
                    }
                } else if (GridActivity.this.isImageSwapEnable) {
                    GridActivity.this.isImageSwapEnable = false;
                    GridActivity.this.puzzleView.swapPiece(GridActivity.this.lastPositionSwap, i);
                    GridActivity.this.puzzleView.requestLayout();
                    GridActivity.this.pieceUnSelect();
                    GridActivity.this.imgSinImgBack.performClick();
                    GridActivity.this.singleImageOptionShow(false);
                } else if (GridActivity.this.isVideoSwapEnable) {
                    GridActivity.this.isVideoSwapEnable = false;
                    GridActivity.this.puzzleView.swapPiece(GridActivity.this.lastPositionSwap, i);
                    GridActivity.this.puzzleView.requestLayout();
                    GridActivity.this.pieceUnSelect();
                    GridActivity.this.imgSinVidBack.performClick();
                    GridActivity.this.singleVideoOptionShow(false);
                } else {
                    GridActivity.this.singleImageOptionShow(true);
                }
                GridActivity.this.first.removeCallbacks(GridActivity.this.runnableFirst);
            }

            public void onPieceUnSelected() {
                Log.e("swap", "onPieceUnSelected");
                GridActivity.this.selectedPiecePosition = -1;
                GridActivity.this.singleImageOptionShow(false);
                GridActivity.this.singleVideoOptionShow(false);
                if (GridActivity.this.inOrder) {
                    GridActivity.this.first.removeCallbacks(GridActivity.this.runnableFirst);
                    GridActivity.this.startOrStopAllVideo("start");
                    return;
                }
                GridActivity.this.first.removeCallbacks(GridActivity.this.runnableFirst);
                GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, 10);
            }
        });
        this.puzzleView.setOnPieceSwapListener(new PuzzleView.OnPieceSwapListener() {
            public void onPieceSwap(int i, int i2) {
                Collections.swap(GridActivity.this.bitmapPaint, i, i2);
                Collections.swap(GridActivity.this.originalBitmapPaint, i, i2);
                Collections.swap(GridActivity.this.viewPieces, i, i2);
            }
        });
    }

    private void addLayout() {
        for (int i = 0; i < bitmapPaint.size(); i++) {
            Bitmap createVideoThumbnail;
            Bitmap scaleBitmap;
            ViewGroup.LayoutParams layoutParams;
            if (Util.isVideoFile(bitmapPaint.get(i))) {
                RelativeLayout relativeLayout = new RelativeLayout(this);
                createVideoThumbnail = ThumbnailUtils.createVideoThumbnail(bitmapPaint.get(i), 2);
                scaleBitmap = scaleBitmap(createVideoThumbnail);
                if (createVideoThumbnail != null) {
                    layoutParams = new RelativeLayout.LayoutParams(scaleBitmap.getWidth(), scaleBitmap.getHeight());
                } else {
                    layoutParams = new RelativeLayout.LayoutParams(1, 1);
                }
                TextureVideoView textureVideoView = new TextureVideoView(this);
                textureVideoView.setVideoURI(FileProvider.getUriForFile(this, "com.kotlinz.videoeditor.provider", new File(this.bitmapPaint.get(i))));
                temp.add(textureVideoView);
                relativeLayout.setLayoutParams(layoutParams);
                relativeLayout.addView(textureVideoView);
                viewPieces.add(relativeLayout);
                mainLinear.addView(relativeLayout);
            } else {
                LinearLayout linearLayout = new LinearLayout(this);
                createVideoThumbnail = BitmapFactory.decodeFile(bitmapPaint.get(i));
                scaleBitmap = Util.resize(Util.rotateBitmapSam(createVideoThumbnail, bitmapPaint.get(i)), bitmapPaint.get(i));
                Bitmap scaleBitmap2 = scaleBitmap(scaleBitmap);
                if (createVideoThumbnail != null) {
                    layoutParams = new RelativeLayout.LayoutParams(scaleBitmap2.getWidth(), scaleBitmap2.getHeight());
                } else {
                    layoutParams = new RelativeLayout.LayoutParams(1, 1);
                }
                ImageView imageView = new ImageView(this);
                imageView.setImageBitmap(scaleBitmap);
                linearLayout.setLayoutParams(layoutParams);
                linearLayout.addView(imageView);
                viewPieces.add(linearLayout);
                mainLinear.addView(linearLayout);
            }
        }
        calculateVideoDuration();
    }

    private Bitmap scaleBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Width and height are ");
        stringBuilder.append(width);
        String str = "--";
        stringBuilder.append(str);
        stringBuilder.append(height);
        String str2 = "play";
        Log.e(str2, stringBuilder.toString());
        int i = 50;
        if (width > height) {
            width = (int) (((float) height) / (((float) width) / 50.0f));
        } else {
            if (height > width) {
                i = (int) (((float) width) / (((float) height) / 50.0f));
            }
            width = 50;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("after scaling Width and height are ");
        stringBuilder2.append(i);
        stringBuilder2.append(str);
        stringBuilder2.append(width);
        Log.e(str2, stringBuilder2.toString());
        return Bitmap.createScaledBitmap(bitmap, i, width, true);
    }

    private void getBaseViewDimension() {
        this.frame.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                baseViewWidth = frame.getWidth();
                baseViewHeight = frame.getHeight();
                setBGImage(selectedImage);
            }
        });
    }

    private void layoutView() {
        PuzzleAdapter puzzleAdapter = new PuzzleAdapter(this, "grid");
        puzzleAdapter.setPos(this.themeId);
        this.layoutRecyclerView.setAdapter(puzzleAdapter);
        this.layoutRecyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        this.layoutRecyclerView.setHasFixedSize(true);
        puzzleAdapter.refreshData(PuzzleUtils.getPuzzleLayouts(this.bitmapPaint.size()), null);
        puzzleAdapter.setOnItemClickListener(new PuzzleAdapter.OnItemClickListener() {
            public void onItemClick(PuzzleLayout puzzleLayout, int i) {
                if (puzzleLayout instanceof SlantPuzzleLayout) {
                    puzzleLayout = PuzzleUtils.getPuzzleLayout(0, GridActivity.this.bitmapPaint.size(), i);
                } else {
                    puzzleLayout = PuzzleUtils.getPuzzleLayout(1, GridActivity.this.bitmapPaint.size(), i);
                }
                GridActivity.this.puzzleView.setPuzzleLayout(puzzleLayout);
                GridActivity.this.puzzleView.invalidate();
                GridActivity.this.puzzleView.requestLayout();
                GridActivity.this.puzzleView.post(new Runnable() {
                    public void run() {
                        loadPhotoAndVideos();
                    }
                });
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(" pieceSize :: ");
                stringBuilder.append(GridActivity.this.bitmapPaint.size());
                String str = "init";
                stringBuilder = new StringBuilder();
                stringBuilder.append(" themeId :: ");
                stringBuilder.append(i);
                GridActivity.this.selectedThemeId = i;
                stringBuilder = new StringBuilder();
                stringBuilder.append(" selectedThemeId :: ");
                stringBuilder.append(GridActivity.this.selectedThemeId);
            }
        });
    }

    private void borderView() {
        this.curViewPad = this.seekViewPadding.getProgress();
        this.curPiecePad = this.seekPiecePadding.getProgress();
        this.curCorner = this.seekCorner.getProgress();
        TextView textView = this.txtViewPadding;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.curViewPad);
        String str = " %";
        stringBuilder.append(str);
        textView.setText(stringBuilder.toString());
        textView = this.txtPiecePadding;
        stringBuilder = new StringBuilder();
        stringBuilder.append(this.curPiecePad);
        stringBuilder.append(str);
        textView.setText(stringBuilder.toString());
        textView = this.txtCorner;
        stringBuilder = new StringBuilder();
        stringBuilder.append(this.curCorner);
        stringBuilder.append(str);
        textView.setText(stringBuilder.toString());
        this.seekViewPadding.setProgress(0);
        this.seekViewPadding.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            public void onStopTrackingTouch(SeekBar seekBar) {

            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                TextView access$3900 = GridActivity.this.txtViewPadding;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(i);
                stringBuilder.append(" %");
                access$3900.setText(stringBuilder.toString());
                float f = GridActivity.this.getResources().getDisplayMetrics().density;
                if (i % 2 != 0) {
                    i++;
                }
                int i2 = (int) ((((float) i) * f) + 0.5f);
                LayoutParams layoutParams = (LayoutParams) GridActivity.this.puzzleView.getLayoutParams();
                layoutParams.setMargins(i2, i2, i2, i2);
                GridActivity.this.puzzleView.setLayoutParams(layoutParams);
            }
        });
        this.seekPiecePadding.setProgress((int) this.puzzleView.getPiecePadding());
        this.seekPiecePadding.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                TextView access$4000 = GridActivity.this.txtPiecePadding;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(i);
                stringBuilder.append(" %");
                access$4000.setText(stringBuilder.toString());
                if (i % 2 == 0) {
                    GridActivity.this.puzzleView.setPiecePadding((float) i);
                } else {
                    GridActivity.this.puzzleView.setPiecePadding((float) (i + 1));
                }
            }
        });
        this.seekCorner.setProgress((int) this.puzzleView.getPieceRadian());
        this.seekCorner.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                TextView access$4100 = GridActivity.this.txtCorner;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(i);
                stringBuilder.append(" %");
                access$4100.setText(stringBuilder.toString());
                GridActivity.this.puzzleView.setPieceRadian((float) i);
            }
        });
    }

    private void frameView() {
        this.curFrame = this.selectedFrame;
        try {
            this.frameList = getAssets().list("frame");
            this.listFrames = new ArrayList(Arrays.asList(this.frameList));
        } catch (IOException e) {
            e.printStackTrace();
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.frameRecycler.setLayoutManager(linearLayoutManager);
        FrameAdapter frameAdapter = new FrameAdapter(this.listFrames, this, new FrameAdapterCallBackInterface() {
            public void itemClick(int i) {
                GridActivity.this.selectedFrame = i;
                GridActivity.this.setFrame(i);
            }
        });
        this.frameAdapter = frameAdapter;
        this.frameRecycler.setAdapter(frameAdapter);
    }

    private void setFrame(int i) {
        InputStream open;
        try {
            AssetManager assets = getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("frame/");
            stringBuilder.append(this.listFrames.get(i));
            open = assets.open(stringBuilder.toString());
        } catch (IOException e) {
            e.printStackTrace();
            e.getMessage();
            open = null;
        }

        Drawable createFromStream = Drawable.createFromStream(open, null);
        if (i == 0) {
            this.maskBGFrame.setBackgroundColor(getResources().getColor(R.color.transparent));
            this.maskableFrameLayout.setMask(R.color.transparent);
            return;
        }
        this.maskBGFrame.setBackgroundColor(getResources().getColor(R.color.colorWhite));
        this.maskableFrameLayout.setMask(createFromStream);
    }


    private void ratioView() {
        final String[] stringArray = getResources().getStringArray(R.array.ratioArray);
        this.ratioRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        RatioAdapter ratioAdapter2 = new RatioAdapter(stringArray, ratioImages, this, new RatioAdapterCallBackInterface() {
            public void itemClick(int i) {
                int i2;
                int i3 = 0;
                if (i == 6 || i == 7 || i == 15 || i == 16) {
                    i2 = 0;
                } else {
                    String[] split = stringArray[i].split(":");
                    i3 = Integer.parseInt(split[0]);
                    i2 = Integer.valueOf(split[1]);
                }
                if (i == 0) {
                    GridActivity.this.seekViewPadding.setMax(70);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 1) {
                    GridActivity.this.seekViewPadding.setMax(70);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 2) {
                    GridActivity.this.seekViewPadding.setMax(50);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 3) {
                    GridActivity.this.seekViewPadding.setMax(70);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 4) {
                    GridActivity.this.seekViewPadding.setMax(40);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 5) {
                    GridActivity.this.seekViewPadding.setMax(50);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 6) {
                    GridActivity.this.seekViewPadding.setMax(30);
                    GridActivity.this.frame.setRatioWidthAndHeight(103, 39);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 7) {
                    GridActivity.this.seekViewPadding.setMax(30);
                    GridActivity.this.frame.setRatioWidthAndHeight(5, 2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 8) {
                    GridActivity.this.seekViewPadding.setMax(60);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 9) {
                    GridActivity.this.seekViewPadding.setMax(60);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 10) {
                    GridActivity.this.seekViewPadding.setMax(60);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 11) {
                    GridActivity.this.seekViewPadding.setMax(50);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 12) {
                    GridActivity.this.seekViewPadding.setMax(50);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 13) {
                    GridActivity.this.seekViewPadding.setMax(50);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 14) {
                    GridActivity.this.seekViewPadding.setMax(50);
                    GridActivity.this.frame.setRatioWidthAndHeight(i3, i2);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 15) {
                    GridActivity.this.seekViewPadding.setMax(30);
                    GridActivity.this.frame.setRatioWidthAndHeight(3, 1);
                    GridActivity.this.getBaseViewDimension();
                } else if (i == 16) {
                    GridActivity.this.seekViewPadding.setMax(30);
                    GridActivity.this.frame.setRatioWidthAndHeight(40, 100);
                    GridActivity.this.getBaseViewDimension();
                } else {
                    Log.e("ratio", " else position :: ");
                }
                LayoutParams layoutParams = new LayoutParams(-2, -2);
                layoutParams.gravity = 17;
                GridActivity.this.frame.setLayoutParams(layoutParams);
                GridActivity.this.updateStickerPos();
            }
        });
        this.ratioRecycler.setAdapter(ratioAdapter2);
    }

    private void bgImageView() {
        this.curImage = this.selectedImage;
        try {
            this.bgImageList = getAssets().list("background");
            this.listImages = new ArrayList(Arrays.asList(this.bgImageList));
        } catch (IOException e) {
            e.printStackTrace();
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.bgImageRecycler.setLayoutManager(linearLayoutManager);
        BGImageAdapter bGImageAdapter = new BGImageAdapter(this.listImages, this, new BGImageAdapterCallBackInterface() {
            public void itemClick(int i) {
                GridActivity.this.selectedImage = i;
                Util.bgImageSelected = true;
                Util.bgColorSelected = false;
                GridActivity.this.frameMainBg.setVisibility(View.VISIBLE);
                GridActivity.this.frameMainColorBG.setVisibility(View.GONE);
                GridActivity.this.setBGImage(i);
            }
        });
        this.bgImageAdapter = bGImageAdapter;
        this.bgImageRecycler.setAdapter(bGImageAdapter);
    }


    public void setBGImage(int i) {
        InputStream inputStream;
        try {
            inputStream = getAssets().open("background/" + this.listImages.get(i));
        } catch (IOException e) {
            e.printStackTrace();
            inputStream = null;
        }
        Bitmap decodeStream = BitmapFactory.decodeStream(inputStream);
        if (i == 0) {
            this.frameMainBg.setImageBitmap(null);
            return;
        }
        ImageView imageView = this.frameMainBg;
        imageView.setImageBitmap(getTiledBitmap(decodeStream, imageView.getWidth(), this.frameMainBg.getHeight()));
    }

    private Bitmap getTiledBitmap(Bitmap bitmap, int i, int i2) {
        Rect rect = new Rect(0, 0, i, i2);
        Paint paint = new Paint();
        paint.setShader(new BitmapShader(bitmap, TileMode.REPEAT, TileMode.REPEAT));
        Bitmap createBitmap = Bitmap.createBitmap(i, i2, Config.ARGB_8888);
        new Canvas(createBitmap).drawRect(rect, paint);
        return createBitmap;
    }

    private void bgColorView() {
        this.curColor = this.selectedColor;
        this.bgColorList = getResources().getStringArray(R.array.bgColorArray);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        bgColorRecycler.setLayoutManager(linearLayoutManager);
        BgColorAdapter bgColorAdapter = new BgColorAdapter(bgColorList, this, new BGColorAdapterCallBackInterface() {
            public void itemClick(int i) {
                selectedColor = i;
                Util.bgColorSelected = true;
                Util.bgImageSelected = false;
                frameMainBg.setVisibility(View.GONE);
                frameMainColorBG.setVisibility(View.VISIBLE);
                GradientDrawable gradientDrawable = (GradientDrawable) frameMainColorBG.getBackground();
                gradientDrawable.setColor(Color.parseColor(bgColorList[i]));
                frameMainColorBG.setBackground(gradientDrawable);
            }
        });
        this.bgColorAdapter = bgColorAdapter;
        this.bgColorRecycler.setAdapter(bgColorAdapter);
    }

    private void hideLayoutView(boolean z) {
        if (z) {
            this.layoutFlag = true;
            this.layoutRecyclerView.setVisibility(View.VISIBLE);
            return;
        }
        this.layoutFlag = false;
        this.layoutRecyclerView.setVisibility(View.GONE);
    }

    private void borderBottomSheetState(boolean z) {
        if (!z) {
            this.borderBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        } else if (this.borderBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
            this.borderBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        } else {
            this.borderBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }
    }

    private void hideOrShowBorderView(boolean z) {
        if (z) {
            this.linMainBorder.setVisibility(View.VISIBLE);
            this.txtMainBorder.setBackgroundResource(R.drawable.border_ractangle_bg_press);
            this.txtMainBorder.setTextColor(getResources().getColor(R.color.optionTextPressColor));
            return;
        }
        this.linMainBorder.setVisibility(View.GONE);
        this.txtMainBorder.setBackgroundResource(R.drawable.border_ractangle_bg_unpress);
        this.txtMainBorder.setTextColor(getResources().getColor(R.color.optionTextUnPressColor));
    }

    private void hideOrShowFrameView(boolean z) {
        if (z) {
            this.linMainFrame.setVisibility(View.VISIBLE);
            this.txtMainFrame.setBackgroundResource(R.drawable.frame_ractangle_bg_press);
            this.txtMainFrame.setTextColor(getResources().getColor(R.color.optionTextPressColor));
            return;
        }
        this.linMainFrame.setVisibility(View.GONE);
        this.txtMainFrame.setBackgroundResource(R.drawable.frame_ractangle_bg_unpress);
        this.txtMainFrame.setTextColor(getResources().getColor(R.color.optionTextUnPressColor));
    }

    private void hideRatioView(boolean z) {
        if (z) {
            this.ratioFlag = true;
            this.ratioRecycler.setVisibility(View.VISIBLE);
            return;
        }
        this.ratioFlag = false;
        this.ratioRecycler.setVisibility(View.GONE);
    }

    private void bgBottomSheetState(boolean z) {
        if (!z) {
            this.bgBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        } else if (this.bgBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
            this.bgBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        } else {
            this.bgBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }
    }

    private void hideOrShowImageView(boolean z) {
        if (z) {
            this.linMainImage.setVisibility(View.VISIBLE);
            this.txtMainImage.setBackgroundResource(R.drawable.border_ractangle_bg_press);
            this.txtMainImage.setTextColor(getResources().getColor(R.color.optionTextPressColor));
            return;
        }
        this.linMainImage.setVisibility(View.GONE);
        this.txtMainImage.setBackgroundResource(R.drawable.border_ractangle_bg_unpress);
        this.txtMainImage.setTextColor(getResources().getColor(R.color.optionTextUnPressColor));
    }

    private void hideOrShowColorView(boolean z) {
        if (z) {
            this.linMainColor.setVisibility(View.VISIBLE);
            this.txtMainColor.setBackgroundResource(R.drawable.frame_ractangle_bg_press);
            this.txtMainColor.setTextColor(getResources().getColor(R.color.optionTextPressColor));
            return;
        }
        this.linMainColor.setVisibility(View.GONE);
        this.txtMainColor.setBackgroundResource(R.drawable.frame_ractangle_bg_unpress);
        this.txtMainColor.setTextColor(getResources().getColor(R.color.optionTextUnPressColor));
    }

    private void textFontView() {
        this.textFontAdapter = new TextFontAdapter(this, getResources().getStringArray(R.array.textFontArray), new TextFontAdapterCallBackInterface() {
            public void itemClick(int i, String str) {
                GridActivity.this.setTextFonts(str);
            }
        });
        this.textFontRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        this.textFontRecyclerView.setAdapter(this.textFontAdapter);
    }

    private void textColorView() {
        final String[] stringArray = getResources().getStringArray(R.array.bgColorArray);
        this.textColorAdapter = new TextColorAdapter(stringArray, this, new TextColorAdapterCallBackInterface() {
            public void itemClick(int i) {
                GridActivity.this.updateColor(stringArray[i]);
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.textColorRecyclerView.setLayoutManager(linearLayoutManager);
        this.textColorRecyclerView.setAdapter(this.textColorAdapter);
    }

    private void textBorderColorView() {
        this.textBorderColorAdapter = new TextBorderColorAdapter(getResources().getStringArray(R.array.bgColorArray), this, new TextBorderColorAdapterCallBackInterface() {
            public void itemClick(int i) {
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.textBorderColorRecyclerView.setLayoutManager(linearLayoutManager);
        this.textBorderColorRecyclerView.setAdapter(this.textBorderColorAdapter);
    }

    private void textShadowColorView() {
        final String[] stringArray = getResources().getStringArray(R.array.bgColorArray);
        this.textShadowColorAdapter = new TextShadowColorAdapter(stringArray, this, new TextShadowColorAdapterCallBackInterface() {
            public void itemClick(int i) {
                updateShadow(stringArray[i]);
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.textShadowColorRecyclerView.setLayoutManager(linearLayoutManager);
        this.textShadowColorRecyclerView.setAdapter(this.textShadowColorAdapter);
        this.seekBarShadowBlur.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                GridActivity.this.seekBarXYPos.setProgress(20);
                int childCount = GridActivity.this.txtStickerRel.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    View childAt = GridActivity.this.txtStickerRel.getChildAt(i2);
                    if (childAt instanceof AutofitTextRel) {
                        AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                        if (autofitTextRel.getBorderVisibility()) {
                            autofitTextRel.setTextShadowProg(i);
                            GridActivity.this.shadowProg = i;
                        }
                    }
                }
            }
        });
        this.seekBarXYPos.setProgress(20);
        this.seekBarXYPos.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                int childCount = GridActivity.this.txtStickerRel.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    View childAt = GridActivity.this.txtStickerRel.getChildAt(i2);
                    if (childAt instanceof AutofitTextRel) {
                        AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                        if (autofitTextRel.getBorderVisibility()) {
                            autofitTextRel.setTextShadowXY(i - 20);
                            GridActivity.this.shadowXYProg = i;
                        }
                    }
                }
            }
        });
    }

    private void textBgImageView() {
        ArrayList arrayList;
        try {
            arrayList = new ArrayList(Arrays.asList(getAssets().list("background")));
        } catch (IOException e) {
            e.printStackTrace();
            arrayList = null;
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.textBGImageRecyclerView.setLayoutManager(linearLayoutManager);
        final ArrayList finalArrayList = arrayList;
        TextBGImageAdapter textBGImageAdapter = new TextBGImageAdapter(arrayList, this, new TextBGImageAdapterCallBackInterface() {
            public void itemClick(int i) {
                setTextBgTexture((String) finalArrayList.get(i));
            }
        });
        this.textBGImageAdapter = textBGImageAdapter;
        this.textBGImageRecyclerView.setAdapter(textBGImageAdapter);
        this.textBGOpacity.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                int childCount = GridActivity.this.txtStickerRel.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    View childAt = GridActivity.this.txtStickerRel.getChildAt(i2);
                    if (childAt instanceof AutofitTextRel) {
                        AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                        if (autofitTextRel.getBorderVisibility()) {
                            if (autofitTextRel.getBgColor() == 0 && autofitTextRel.getBgDrawable().equals("0")) {
                                String str = "#000000";
                                autofitTextRel.setBgColor(Color.parseColor(str));
                                autofitTextRel.getTextInfo().setBG_COLOR(Color.parseColor(str));
                                GridActivity.this.bgColor = Color.parseColor(str);
                            }
                            autofitTextRel.setBgAlpha(i);
                            GridActivity.this.bgAlpha = i;
                        }
                    }
                }
            }
        });
    }

    private void textBgColorView() {
        final String[] stringArray = getResources().getStringArray(R.array.bgColorArray);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.textBGColorRecyclerView.setLayoutManager(linearLayoutManager);
        TextBGColorAdapter textBGColorAdapter = new TextBGColorAdapter(stringArray, this, new TextBGColorAdapterCallBackInterface() {
            public void itemClick(int i) {
                GridActivity.this.updateBgColor(stringArray[i]);
            }
        });
        this.textBGColorAdapter = textBGColorAdapter;
        this.textBGColorRecyclerView.setAdapter(textBGColorAdapter);
    }

    private void textAlignView() {
        this.charSeekPac.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {

            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                GridActivity.this.setCharSpacing(((float) i) / 10.0f);
            }
        });
        this.lineSeekPac.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                GridActivity.this.setLineSpacing((float) i);
            }
        });
    }

    private void textOpacityView() {
        SeekBar seekBar = this.seekOpacity;
        seekBar.setProgress(seekBar.getProgress());
        this.seekOpacity.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                TextView access$6400 = GridActivity.this.txtTextOpacityPer;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(i);
                stringBuilder.append(" %");
                access$6400.setText(stringBuilder.toString());
                GridActivity.this.setTextOpacity(i);
            }
        });
    }

    private void hideOrShowTextOption(boolean z) {
        if (z) {
            this.horizontalMainScrollView.setVisibility(View.GONE);
            this.horizontalSingleImageScrollView.setVisibility(View.GONE);
            this.horizontalSingleVideoScrollView.setVisibility(View.GONE);
            this.horizontalTextScrollView.setVisibility(View.VISIBLE);
            return;
        }
        removeImageViewController();
        removeWatermarkImageViewController();
        this.horizontalMainScrollView.setVisibility(View.VISIBLE);
        this.horizontalTextScrollView.setVisibility(View.GONE);
    }

    private void hideOrShowTextOptionEdit(boolean z) {
        if (z) {
            this.txtTextEdit.setVisibility(View.VISIBLE);
            this.imgTextEdit.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
            return;
        }
        this.txtTextEdit.setVisibility(View.GONE);
        this.imgTextEdit.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
    }

    private void hideOrShowTextOptionFont(boolean z) {
        if (z) {
            this.textFontFlag = true;
            this.textFontRecyclerView.setVisibility(View.VISIBLE);
            this.txtTextFont.setVisibility(View.VISIBLE);
            this.imgTextFont.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
            return;
        }
        this.textFontFlag = false;
        this.textFontRecyclerView.setVisibility(View.GONE);
        this.txtTextFont.setVisibility(View.GONE);
        this.imgTextFont.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
    }

    private void hideOrShowTextOptionColor(boolean z) {
        if (z) {
            this.textColorFlag = true;
            this.textColorRecyclerView.setVisibility(View.VISIBLE);
            this.txtTextColor.setVisibility(View.VISIBLE);
            this.imgTextColor.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
            return;
        }
        this.textColorFlag = false;
        this.textColorRecyclerView.setVisibility(View.GONE);
        this.txtTextColor.setVisibility(View.GONE);
        this.imgTextColor.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
    }

    private void hideOrShowTextOptionStyle(boolean z) {
        if (z) {
            this.textStyleFlag = true;
            this.txtTextStyle.setVisibility(View.VISIBLE);
            this.linTextStyleMain.setVisibility(View.VISIBLE);
            this.imgTextStyle.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
            return;
        }
        this.textStyleFlag = false;
        this.txtTextStyle.setVisibility(View.GONE);
        this.linTextStyleMain.setVisibility(View.GONE);
        this.imgTextStyle.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
    }

    private void hideOrShowTextOptionBorder(boolean z) {
        if (z) {
            this.linMainTextBorder.setVisibility(View.VISIBLE);
            this.txtMainTextBorder.setBackgroundResource(R.drawable.border_ractangle_bg_press);
            this.txtMainTextBorder.setTextColor(getResources().getColor(R.color.optionTextPressColor));
            return;
        }
        this.linMainTextBorder.setVisibility(View.GONE);
        this.txtMainTextBorder.setBackgroundResource(R.drawable.border_ractangle_bg_unpress);
        this.txtMainTextBorder.setTextColor(getResources().getColor(R.color.optionTextUnPressColor));
    }

    private void hideOrShowTextOptionShadow(boolean z) {
        if (z) {
            this.linMainTextShadow.setVisibility(View.VISIBLE);
            this.txtMainTextShadow.setBackgroundResource(R.drawable.frame_ractangle_bg_press);
            this.txtMainTextShadow.setTextColor(getResources().getColor(R.color.optionTextPressColor));
            return;
        }
        this.linMainTextShadow.setVisibility(View.GONE);
        this.txtMainTextShadow.setBackgroundResource(R.drawable.frame_ractangle_bg_unpress);
        this.txtMainTextShadow.setTextColor(getResources().getColor(R.color.optionTextUnPressColor));
    }

    private void hideOrShowTextOptionBG(boolean z) {
        if (z) {
            this.textBGFlag = true;
            this.txtTextBG.setVisibility(View.VISIBLE);
            this.linTextBGMain.setVisibility(View.VISIBLE);
            this.imgTextBG.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
            return;
        }
        this.textBGFlag = false;
        this.txtTextBG.setVisibility(View.GONE);
        this.linTextBGMain.setVisibility(View.GONE);
        this.imgTextBG.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
    }

    private void hideOrShowTextOptionBGImage(boolean z) {
        if (z) {
            this.linMainTextBGImage.setVisibility(View.VISIBLE);
            this.txtMainTextBGImage.setBackgroundResource(R.drawable.border_ractangle_bg_press);
            this.txtMainTextBGImage.setTextColor(getResources().getColor(R.color.optionTextPressColor));
            return;
        }
        this.linMainTextBGImage.setVisibility(View.GONE);
        this.txtMainTextBGImage.setBackgroundResource(R.drawable.border_ractangle_bg_unpress);
        this.txtMainTextBGImage.setTextColor(getResources().getColor(R.color.optionTextUnPressColor));
    }

    private void hideOrShowTextOptionBGColor(boolean z) {
        if (z) {
            this.linMainTextBGColor.setVisibility(View.VISIBLE);
            this.txtMainTextBGColor.setBackgroundResource(R.drawable.frame_ractangle_bg_press);
            this.txtMainTextBGColor.setTextColor(getResources().getColor(R.color.optionTextPressColor));
            return;
        }
        this.linMainTextBGColor.setVisibility(View.GONE);
        this.txtMainTextBGColor.setBackgroundResource(R.drawable.frame_ractangle_bg_unpress);
        this.txtMainTextBGColor.setTextColor(getResources().getColor(R.color.optionTextUnPressColor));
    }

    private void hideOrShowTextOptionAlign(boolean z) {
        if (z) {
            this.textAlignFlag = true;
            this.txtTextAlign.setVisibility(View.VISIBLE);
            this.linTextAlignMain.setVisibility(View.VISIBLE);
            this.imgTextAlign.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
            return;
        }
        this.textAlignFlag = false;
        this.txtTextAlign.setVisibility(View.GONE);
        this.linTextAlignMain.setVisibility(View.GONE);
        this.imgTextAlign.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
    }

    private void hideOrShowTextOptionOpacity(boolean z) {
        if (z) {
            this.textOpacityFlag = true;
            this.txtTextOpacity.setVisibility(View.VISIBLE);
            this.linTextOpacityMain.setVisibility(View.VISIBLE);
            this.imgTextOpacity.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
            return;
        }
        this.textOpacityFlag = false;
        this.txtTextOpacity.setVisibility(View.GONE);
        this.linTextOpacityMain.setVisibility(View.GONE);
        this.imgTextOpacity.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
    }

    private void hideOrShowTextOptionCopy() {
        this.txtTextCopy.setVisibility(View.VISIBLE);
        this.imgTextCopy.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                GridActivity.this.txtTextCopy.setVisibility(View.GONE);
                GridActivity.this.imgTextCopy.setColorFilter(GridActivity.this.getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
            }
        }, 500);
    }

    private void stickerBottomSheetState(boolean z) {
        if (!z) {
//            this.txtSticker.setVisibility(View.GONE);
            this.stickerBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        } else if (this.stickerBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
//            this.txtSticker.setVisibility(View.VISIBLE);
            this.stickerBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        } else {
//            this.txtSticker.setVisibility(View.GONE);
            this.stickerBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }
    }

    private void stickerEmojiCategoryOneView() {
        try {
            this.emojiStickerList = getAssets().list("stickers/emoji");
            this.listEmojiSticker = new ArrayList(Arrays.asList(this.emojiStickerList));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.stickerRecyclerCatOne.setLayoutManager(new GridLayoutManager(this.context, 4));
        EmojiStickerAdapter emojiStickerAdapter = new EmojiStickerAdapter(this.listEmojiSticker, this, new EmojiStickerAdapterCallBackInterface() {
            public void itemClick(int i) {
                GridActivity gridActivity = GridActivity.this;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("stickers/emoji/");
                stringBuilder.append(GridActivity.this.listEmojiSticker.get(i));
                gridActivity.mDrawableName = stringBuilder.toString();
                GridActivity.this.setDrawable();
            }
        });
        this.emojiStickerAdapter = emojiStickerAdapter;
        this.stickerRecyclerCatOne.setAdapter(emojiStickerAdapter);
    }

    private void stickerMsgTextCategoryOneView() {
        try {
            this.msgTextStickerList = getAssets().list("stickers/message_text");
            this.listMsgTextSticker = new ArrayList(Arrays.asList(this.msgTextStickerList));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.stickerRecyclerCatTwo.setLayoutManager(new GridLayoutManager(this.context, 4));
        MsgTextStickerAdapter msgTextStickerAdapter = new MsgTextStickerAdapter(this.listMsgTextSticker, this, new MsgTextStickerAdapterCallBackInterface() {
            public void itemClick(int i) {
                GridActivity gridActivity = GridActivity.this;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("stickers/message_text/");
                stringBuilder.append(GridActivity.this.listMsgTextSticker.get(i));
                gridActivity.mDrawableName = stringBuilder.toString();
                setDrawable();
            }
        });
        this.msgTextStickerAdapter = msgTextStickerAdapter;
        this.stickerRecyclerCatTwo.setAdapter(msgTextStickerAdapter);
    }

    private void stickerPartyCategoryOneView() {
        try {
            this.partyStickerList = getAssets().list("stickers/party");
            this.listPartySticker = new ArrayList(Arrays.asList(this.partyStickerList));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.stickerRecyclerCatThree.setLayoutManager(new GridLayoutManager(this.context, 4));
        PartyStickerAdapter partyStickerAdapter = new PartyStickerAdapter(this.listPartySticker, this, new PartyStickerAdapterCallBackInterface() {
            public void itemClick(int i) {
                GridActivity gridActivity = GridActivity.this;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("stickers/party/");
                stringBuilder.append(GridActivity.this.listPartySticker.get(i));
                gridActivity.mDrawableName = stringBuilder.toString();
                GridActivity.this.setDrawable();
            }
        });
        this.partyStickerAdapter = partyStickerAdapter;
        this.stickerRecyclerCatThree.setAdapter(partyStickerAdapter);
    }

    private void hideOrShowStickerEmoji(boolean z) {
        if (z) {
            this.emojiStickerAdapter.setPos(-1);
            this.stickerRecyclerCatOne.setVisibility(View.VISIBLE);
            this.imgStickerCateOne.setBackgroundResource(R.drawable.black_round_bg_press_sticker);
            return;
        }
        this.stickerRecyclerCatOne.setVisibility(View.GONE);
        this.imgStickerCateOne.setBackgroundResource(R.drawable.black_round_bg_unpress_sticker);
    }

    private void hideOrShowStickerMsgText(boolean z) {
        if (z) {
            this.msgTextStickerAdapter.setPos(-1);
            this.stickerRecyclerCatTwo.setVisibility(View.VISIBLE);
            this.imgStickerCateTwo.setBackgroundResource(R.drawable.black_round_bg_press_sticker);
            return;
        }
        this.stickerRecyclerCatTwo.setVisibility(View.GONE);
        this.imgStickerCateTwo.setBackgroundResource(R.drawable.black_round_bg_unpress_sticker);
    }

    private void hideOrShowStickerParty(boolean z) {
        if (z) {
            this.partyStickerAdapter.setPos(-1);
            this.stickerRecyclerCatThree.setVisibility(View.VISIBLE);
            this.imgStickerCateThree.setBackgroundResource(R.drawable.black_round_bg_press_sticker);
            return;
        }
        this.stickerRecyclerCatThree.setVisibility(View.GONE);
        this.imgStickerCateThree.setBackgroundResource(R.drawable.black_round_bg_unpress_sticker);
    }

    private void hideOrShowStickerAdd(boolean z) {
        if (z) {
            this.linStickerCatForAdd.setVisibility(View.VISIBLE);
            this.imgStickerCateForAdd.setBackgroundResource(R.drawable.black_round_bg_press_sticker);
            return;
        }
        this.linStickerCatForAdd.setVisibility(View.GONE);
        this.imgStickerCateForAdd.setBackgroundResource(R.drawable.black_round_bg_unpress_sticker);
    }

    private void filterView() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.filterRecycler.setLayoutManager(linearLayoutManager);
        try {
            this.thumbImageList = getAssets().list("effectthumb");
            this.listThumb = new ArrayList(Arrays.asList(this.thumbImageList));
        } catch (IOException e) {
            e.printStackTrace();
        }
        FilterAdapter filterAdapter = new FilterAdapter(this.listThumb, this, new FilterAdapterCallBackInterface() {
            public void itemClick(int i) {
                if (GridActivity.this.filterPosition != i) {
                    GridActivity.this.filterPosition = i;
                    GridActivity.this.puzzleView.clearHandling();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(GridActivity.this.getCacheDir());
                    stringBuilder.append("/temp");
                    Util.deleteTempDir(new File(stringBuilder.toString()));
                    new FilterAsyncTask(i).execute();
                }
            }
        });
        this.filterAdapter = filterAdapter;
        this.filterRecycler.setAdapter(filterAdapter);
    }

    private void pieceUnSelect() {
        selectedPiecePosition = -1;
        puzzleView.clearHandling();
        puzzleView.requestLayout();
    }

    private void hideFilterView(boolean z) {
        if (z) {
            filterFlag = true;
            txtFilter.setVisibility(View.VISIBLE);
            filterRecycler.setVisibility(View.VISIBLE);
            imgFilter.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
            imgAdjust.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
            imgDraw.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
            imgWatermark.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
            return;
        }
        filterFlag = false;
        txtFilter.setVisibility(View.GONE);
        filterRecycler.setVisibility(View.GONE);
        imgFilter.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
    }

    private void adjustView() {
        SeekBar seekBar = this.seekBarBrightness;
        seekBar.setProgress(seekBar.getProgress());
        this.seekBarBrightness.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                brightnessProgress = i - (gridActivity.seekBarBrightness.getMax() / 2);
                tempTextForAdjust.setText(String.valueOf(brightnessProgress));
                imgAdjust.setColorFilter(ColorFilterGenerator.adjustColor(brightnessProgress, 0, 0, 0));
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                GridActivity.this.tempTextForAdjust.setVisibility(View.VISIBLE);
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                tempTextForAdjust.setVisibility(View.GONE);
                new AdjustAllAsyncTask("brightness").execute();
            }
        });
        seekBar = this.seekBarContrast;
        seekBar.setProgress(seekBar.getProgress());
        this.seekBarContrast.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                contrastProgress = i - (gridActivity.seekBarContrast.getMax() / 2);
                tempTextForAdjust.setText(String.valueOf(contrastProgress));
                imgAdjust.setColorFilter(ColorFilterGenerator.adjustColor(0, contrastProgress, 0, 0));
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                tempTextForAdjust.setVisibility(View.VISIBLE);
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                tempTextForAdjust.setVisibility(View.GONE);
                new AdjustAllAsyncTask("contrast").execute();
            }
        });
        seekBar = this.seekBarSaturation;
        seekBar.setProgress(seekBar.getProgress());
        this.seekBarSaturation.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                saturationProgress = i - (seekBarSaturation.getMax() / 2);
                tempTextForAdjust.setText(String.valueOf(saturationProgress));
                imgAdjust.setColorFilter(ColorFilterGenerator.adjustColor(0, 0, saturationProgress, 0));
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                GridActivity.this.tempTextForAdjust.setVisibility(View.VISIBLE);
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                GridActivity.this.tempTextForAdjust.setVisibility(View.GONE);
                new AdjustAllAsyncTask("saturation").execute();
            }
        });
        seekBar = this.seekBarHue;
        seekBar.setProgress(seekBar.getProgress());
        this.seekBarHue.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                GridActivity.this.hueProgress = i;
                GridActivity.this.tempTextForAdjust.setText(String.valueOf(GridActivity.this.hueProgress));
                GridActivity.this.imgAdjust.setColorFilter(ColorFilterGenerator.adjustColor(0, 0, 0, GridActivity.this.hueProgress));
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                GridActivity.this.tempTextForAdjust.setVisibility(View.VISIBLE);
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                GridActivity.this.tempTextForAdjust.setVisibility(View.GONE);
                new AdjustAllAsyncTask("hue").execute();
            }
        });
    }

    private void hideAdjustView(boolean z) {
        if (z) {
            this.adjustFlag = true;
            this.txtAdjust.setVisibility(View.VISIBLE);
            this.linAdjustView.setVisibility(View.VISIBLE);
            this.imgFilter.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
            this.imgAdjust.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
            this.imgDraw.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
            this.imgWatermark.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
            return;
        }
        this.adjustFlag = false;
        this.txtAdjust.setVisibility(View.GONE);
        this.linAdjustView.setVisibility(View.GONE);
        this.imgAdjust.setColorFilter(getResources().getColor(R.color.unSelectIconColor), Mode.SRC_IN);
    }

    private void hideOrShowBrightness() {
        this.viewBrightness.setVisibility(View.VISIBLE);
        this.viewContrast.setVisibility(View.GONE);
        this.viewSaturation.setVisibility(View.GONE);
        this.viewHue.setVisibility(View.GONE);
        this.seekBarBrightness.setVisibility(View.VISIBLE);
        this.seekBarContrast.setVisibility(View.GONE);
        this.seekBarSaturation.setVisibility(View.GONE);
        this.seekBarHue.setVisibility(View.GONE);
        this.imgBrightness.setColorFilter(getResources().getColor(R.color.colorAccent), Mode.SRC_IN);
        this.imgContrast.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgSaturation.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
    }

    private void hideOrShowContrast() {
        this.viewBrightness.setVisibility(View.GONE);
        this.viewContrast.setVisibility(View.VISIBLE);
        this.viewSaturation.setVisibility(View.GONE);
        this.viewHue.setVisibility(View.GONE);
        this.seekBarBrightness.setVisibility(View.GONE);
        this.seekBarContrast.setVisibility(View.VISIBLE);
        this.seekBarSaturation.setVisibility(View.GONE);
        this.seekBarHue.setVisibility(View.GONE);
        this.imgBrightness.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgContrast.setColorFilter(getResources().getColor(R.color.colorAccent), Mode.SRC_IN);
        this.imgSaturation.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
    }

    private void hideOrShowSaturation() {
        this.viewBrightness.setVisibility(View.GONE);
        this.viewContrast.setVisibility(View.GONE);
        this.viewSaturation.setVisibility(View.VISIBLE);
        this.viewHue.setVisibility(View.GONE);
        this.seekBarBrightness.setVisibility(View.GONE);
        this.seekBarContrast.setVisibility(View.GONE);
        this.seekBarSaturation.setVisibility(View.VISIBLE);
        this.seekBarHue.setVisibility(View.GONE);
        this.imgBrightness.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgContrast.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgSaturation.setColorFilter(getResources().getColor(R.color.colorAccent), Mode.SRC_IN);
    }

    private void hideOrShowHue() {
        this.viewBrightness.setVisibility(View.GONE);
        this.viewContrast.setVisibility(View.GONE);
        this.viewSaturation.setVisibility(View.GONE);
        this.viewHue.setVisibility(View.VISIBLE);
        this.seekBarBrightness.setVisibility(View.GONE);
        this.seekBarContrast.setVisibility(View.GONE);
        this.seekBarSaturation.setVisibility(View.GONE);
        this.seekBarHue.setVisibility(View.VISIBLE);
        this.imgBrightness.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgContrast.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgSaturation.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
    }

    private void drawView() {
        PhotoEditor build = new PhotoEditor.Builder(this, this.photoEditorView).setPinchTextScalable(true).build();
        this.photoEditor = build;
        build.setBrushSize(getResources().getDimension(R.dimen._3sdp));
        this.photoEditor.setOnPhotoEditorListener(new OnPhotoEditorListener() {
            public void onAddViewListener(ViewType viewType, int i) {
            }

            public void onEditTextChangeListener(View view, String str, int i) {
            }

            public void onRemoveViewListener(ViewType viewType, int i) {
            }

            public void onStopViewChangeListener(ViewType viewType) {
            }

            public void onStartViewChangeListener(ViewType viewType) {
                GridActivity.this.imgDrawRedo.setVisibility(View.VISIBLE);
                GridActivity.this.imgDrawUndo.setVisibility(View.VISIBLE);
            }
        });
        updateSelectedColor(this.selectedLineSize);
        final String[] stringArray = getResources().getStringArray(R.array.bgColorArray);
        this.drawColorAdapter = new DrawColorAdapter(stringArray, this, new DrawColorAdapterCallBackInterface() {
            public void itemClick(int i) {
                GridActivity.this.drawLineColor = Color.parseColor(stringArray[i]);
                GridActivity.this.photoEditor.setBrushColor(GridActivity.this.drawLineColor);
                GridActivity gridActivity = GridActivity.this;
                gridActivity.updateSelectedColor(gridActivity.selectedLineSize);
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.drawColorRecyclerView.setLayoutManager(linearLayoutManager);
        this.drawColorRecyclerView.setAdapter(this.drawColorAdapter);
        this.photoEditor.setBrushDrawingMode(false);
    }

    private void drawBottomSheetState(boolean z) {
        if (!z) {
            this.txtDraw.setVisibility(View.GONE);
            this.photoEditor.setBrushDrawingMode(false);
            this.drawBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        } else if (this.drawBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
            this.txtDraw.setVisibility(View.VISIBLE);
            this.photoEditor.setBrushDrawingMode(true);
            this.drawBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        } else {
            this.txtDraw.setVisibility(View.GONE);
            this.photoEditor.setBrushDrawingMode(false);
            this.drawBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }
    }

    private void hideDrawColorRecyclerView(boolean z) {
        if (z) {
            this.drawColorFlag = true;
            this.drawColorRecyclerView.setVisibility(View.VISIBLE);
            this.imgDrawColor.setColorFilter(getResources().getColor(R.color.colorAccent), Mode.SRC_IN);
            return;
        }
        this.drawColorFlag = false;
        this.drawColorRecyclerView.setVisibility(View.GONE);
        this.imgDrawColor.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
    }

    private void hideDrawEraseView(boolean z) {
        PhotoEditor photoEditor;
        if (z) {
            this.drawMode = "erase";
            this.drawEraseFlag = true;
            this.imgDrawErase.setImageResource(R.drawable.ic_draw_unselect);
            this.imgDrawErase.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
            this.linDrawColor.setVisibility(View.GONE);
            hideDrawColorRecyclerView(false);
            this.linDrawDelete.setVisibility(View.VISIBLE);
            photoEditor = this.photoEditor;
            photoEditor.setBrushEraserSize(photoEditor.getBrushSize());
            updateSelectedColor(this.selectedLineSize);
            this.photoEditor.brushEraser();
            return;
        }
        this.drawMode = "draw";
        this.drawEraseFlag = false;
        this.imgDrawErase.setImageResource(R.drawable.ic_eraser_unselect);
        this.imgDrawErase.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.linDrawColor.setVisibility(View.VISIBLE);
        this.linDrawDelete.setVisibility(View.GONE);
        photoEditor = this.photoEditor;
        photoEditor.setBrushSize(photoEditor.getEraserSize());
        updateSelectedColor(this.selectedLineSize);
        this.photoEditor.setBrushDrawingMode(true);
    }

    private void updateSelectedColor(int i) {
        String str = "draw";
        GradientDrawable gradientDrawable;
        if (i == 1) {
            gradientDrawable = (GradientDrawable) this.imgDrawSizeOne.getBackground();
            if (this.drawMode.equalsIgnoreCase(str)) {
                gradientDrawable.setColor(this.drawLineColor);
            } else {
                gradientDrawable.setColor(getResources().getColor(R.color.colorWhite));
            }
            this.imgDrawSizeOne.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeTwo.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeTwo.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeThree.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeThree.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeFour.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeFour.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeFive.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeFive.setBackground(gradientDrawable);
        } else if (i == 2) {
            gradientDrawable = (GradientDrawable) this.imgDrawSizeOne.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeOne.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeTwo.getBackground();
            if (this.drawMode.equalsIgnoreCase(str)) {
                gradientDrawable.setColor(this.drawLineColor);
            } else {
                gradientDrawable.setColor(getResources().getColor(R.color.colorWhite));
            }
            this.imgDrawSizeTwo.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeThree.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeThree.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeFour.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeFour.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeFive.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeFive.setBackground(gradientDrawable);
        } else if (i == 3) {
            gradientDrawable = (GradientDrawable) this.imgDrawSizeOne.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeOne.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeTwo.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeTwo.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeThree.getBackground();
            if (this.drawMode.equalsIgnoreCase(str)) {
                gradientDrawable.setColor(this.drawLineColor);
            } else {
                gradientDrawable.setColor(getResources().getColor(R.color.colorWhite));
            }
            this.imgDrawSizeThree.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeFour.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeFour.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeFive.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeFive.setBackground(gradientDrawable);
        } else if (i == 4) {
            gradientDrawable = (GradientDrawable) this.imgDrawSizeOne.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeOne.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeTwo.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeTwo.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeThree.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeThree.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeFour.getBackground();
            if (this.drawMode.equalsIgnoreCase(str)) {
                gradientDrawable.setColor(this.drawLineColor);
            } else {
                gradientDrawable.setColor(getResources().getColor(R.color.colorWhite));
            }
            this.imgDrawSizeFour.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeFive.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeFive.setBackground(gradientDrawable);
        } else if (i == 5) {
            gradientDrawable = (GradientDrawable) this.imgDrawSizeOne.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeOne.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeTwo.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeTwo.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeThree.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeThree.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeFour.getBackground();
            gradientDrawable.setColor(getResources().getColor(R.color.colorGray));
            this.imgDrawSizeFour.setBackground(gradientDrawable);
            gradientDrawable = (GradientDrawable) this.imgDrawSizeFive.getBackground();
            if (this.drawMode.equalsIgnoreCase(str)) {
                gradientDrawable.setColor(this.drawLineColor);
            } else {
                gradientDrawable.setColor(getResources().getColor(R.color.colorWhite));
            }
            this.imgDrawSizeFive.setBackground(gradientDrawable);
        }
    }

    @SuppressLint("MissingPermission")
    private void saveDrawLine() {
        int nextInt = new Random().nextInt(10000);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Image-");
        stringBuilder.append(nextInt);
        stringBuilder.append(".png");
        String stringBuilder2 = stringBuilder.toString();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(this.context.getCacheDir());
        stringBuilder3.append("/tempdraw");
        File file = new File(stringBuilder3.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(file, stringBuilder2);
        if (file2.exists()) {
            file2.delete();
        }
        this.photoEditor.saveAsFile(file2.getAbsolutePath(), new SaveSettings.Builder().setClearViewsEnabled(false).setTransparencyEnabled(true).build(), new OnSaveListener() {
            public void onFailure(Exception exception) {
            }

            public void onSuccess(String str) {
                GridActivity.this.photoEditorView.getSource().setImageURI(Uri.fromFile(new File(str)));
            }
        });
    }

    private void watermarkView() {
        try {
            this.watermarkList = getAssets().list("Watermark");
            this.listWatermark = new ArrayList(Arrays.asList(this.watermarkList));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.watermarkPicVidRecyclerView.setLayoutManager(new GridLayoutManager(this.context, 2));
        WatermarkPicVidAdapter watermarkPicVidAdapter = new WatermarkPicVidAdapter(this.listWatermark, this, new PicVidWatermarkAdapterCallBackInterface() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
            public void itemClick(int i) {
                if (i != 0) {
                    GridActivity gridActivity = GridActivity.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Watermark/");
                    stringBuilder.append(GridActivity.this.listWatermark.get(i));
                    gridActivity.mDrawableName = stringBuilder.toString();
                    GridActivity.this.color_Type = "colored";
                    GridActivity gridActivity2 = GridActivity.this;
                    gridActivity2.addSticker(gridActivity2.mDrawableName);
                } else if (GridActivity.this.txtWatermarkStickerRel == null) {
                } else {
                    if (GridActivity.this.txtWatermarkStickerRel.getChildCount() <= 0) {
                        Toast.makeText(GridActivity.this.context, "No watermark added at", Toast.LENGTH_SHORT).show();
                    } else {
                        GridActivity.this.txtWatermarkStickerRel.removeAllViews();
                    }
                }
            }
        });
        this.watermarkPicVidAdapter = watermarkPicVidAdapter;
        this.watermarkPicVidRecyclerView.setAdapter(watermarkPicVidAdapter);
        try {
            this.watermarkSocList = getAssets().list("WatermarkSoc");
            this.listWatermarkSoc = new ArrayList(Arrays.asList(this.watermarkSocList));
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        this.watermarkSocialRecyclerView.setLayoutManager(new GridLayoutManager(this.context, 2));
        this.watermarkSocialAdapter = new WatermarkSocialAdapter(this.listWatermarkSoc, this, new SocVidWatermarkAdapterCallBackInterface() {
            @SuppressLint("NewApi")
            public void itemClick(int i) {
                if (i != 0) {
                    GridActivity gridActivity = GridActivity.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("WatermarkSoc/");
                    stringBuilder.append(GridActivity.this.listWatermarkSoc.get(i));
                    gridActivity.mDrawableName = stringBuilder.toString();
                    GridActivity.this.color_Type = "colored";
                    GridActivity gridActivity2 = GridActivity.this;
                    gridActivity2.addSticker(gridActivity2.mDrawableName);
                } else if (GridActivity.this.txtWatermarkStickerRel == null) {
                } else {
                    if (GridActivity.this.txtWatermarkStickerRel.getChildCount() <= 0) {
                        Toast.makeText(GridActivity.this.context, "No watermark added at", Toast.LENGTH_SHORT).show();
                    } else {
                        GridActivity.this.txtWatermarkStickerRel.removeAllViews();
                    }
                }
            }
        });
        this.watermarkSocialRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        this.watermarkSocialRecyclerView.setAdapter(this.watermarkSocialAdapter);
    }

    private void watermarkBottomSheetState(boolean z) {
        if (!z) {
            this.txtWatermark.setVisibility(View.GONE);
            this.watermarkBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        } else if (this.watermarkBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
            this.txtWatermark.setVisibility(View.VISIBLE);
            this.watermarkBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        } else {
            this.txtWatermark.setVisibility(View.GONE);
            this.watermarkBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }
    }

    private void hideOrShowWatermarkPicVidView(boolean z) {
        if (z) {
            this.watermarkPicVidRecyclerView.setVisibility(View.VISIBLE);
            this.txtWatermarkPicVid.setBackgroundResource(R.drawable.border_ractangle_bg_press);
            this.txtWatermarkPicVid.setTextColor(getResources().getColor(R.color.optionTextPressColor));
            return;
        }
        this.watermarkPicVidRecyclerView.setVisibility(View.GONE);
        this.txtWatermarkPicVid.setBackgroundResource(R.drawable.border_ractangle_bg_unpress);
        this.txtWatermarkPicVid.setTextColor(getResources().getColor(R.color.optionTextUnPressColor));
    }

    private void hideOrShowWatermarkSocialView(boolean z) {
        if (z) {
            this.watermarkSocialRecyclerView.setVisibility(View.VISIBLE);
            this.txtWatermarkSocial.setBackgroundResource(R.drawable.frame_ractangle_bg_press);
            this.txtWatermarkSocial.setTextColor(getResources().getColor(R.color.optionTextPressColor));
            return;
        }
        this.watermarkSocialRecyclerView.setVisibility(View.GONE);
        this.txtWatermarkSocial.setBackgroundResource(R.drawable.frame_ractangle_bg_unpress);
        this.txtWatermarkSocial.setTextColor(getResources().getColor(R.color.optionTextUnPressColor));
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    private void addSticker(String str) {
        ComponentInfo componentInfo = new ComponentInfo();
        componentInfo.setWIDTH((ImageUtils.dpToPx(this, Callback.DEFAULT_DRAG_ANIMATION_DURATION) * 2) / 2);
        componentInfo.setHEIGHT(ImageUtils.dpToPx(this, Callback.DEFAULT_DRAG_ANIMATION_DURATION) / 2);
        componentInfo.setPOS_X((float) ((this.frame.getWidth() / 2) - (componentInfo.getWIDTH() / 2)));
        componentInfo.setPOS_Y((float) ((this.frame.getHeight() / 2) - (componentInfo.getHEIGHT() / 2)));
        componentInfo.setROTATION(0.0f);
        componentInfo.setRES_ID(str);
        componentInfo.setBITMAP(null);
        componentInfo.setCOLORTYPE(this.color_Type);
        componentInfo.setTYPE("SHAPE");
        componentInfo.setSTC_OPACITY(100);
        componentInfo.setSTC_COLOR(0);
        componentInfo.setSTKR_PATH("");
        componentInfo.setFIELD_TWO("0,0");
        componentInfo.setXRotateProg(45);
        componentInfo.setYRotateProg(45);
        componentInfo.setZRotateProg(SubSamplingScaleImageView.ORIENTATION_180);
        componentInfo.setScaleProg(10);
        ResizableStickerView resizableStickerView = new ResizableStickerView(this, "watermark");
        resizableStickerView.setOnTouchCallbackListener(this);
        resizableStickerView.optimizeScreen(this.screenWidth, this.screenHeight);
        resizableStickerView.setComponentInfo(componentInfo);
        resizableStickerView.setId(View.generateViewId());
        resizableStickerView.setMainLayoutWH((float) this.frame.getWidth(), (float) this.frame.getHeight());
        txtWatermarkStickerRel.removeAllViews();
        txtWatermarkStickerRel.addView(resizableStickerView);
        resizableStickerView.setWatermarkVisibility(true);
        resizableStickerView.setBorderVisibility(true);
    }

    private void singleImageOptionShow(boolean z) {
        if (z) {
            if (horizontalMainScrollView.getVisibility() == View.VISIBLE) {
                horizontalMainScrollView.setVisibility(View.GONE);
            }
            if (horizontalTextScrollView.getVisibility() == View.VISIBLE) {
                imgTextBack.performClick();
            }
            if (horizontalSingleVideoScrollView.getVisibility() == View.VISIBLE) {
                horizontalSingleVideoScrollView.setVisibility(View.GONE);
            }
            horizontalSingleImageScrollView.setVisibility(View.VISIBLE);
            return;
        }
        horizontalSingleImageScrollView.setVisibility(View.GONE);
        if (horizontalTextScrollView.getVisibility() == View.VISIBLE) {
            imgTextBack.performClick();
        }
        if (horizontalSingleVideoScrollView.getVisibility() == View.VISIBLE) {
            horizontalSingleVideoScrollView.setVisibility(View.GONE);
        }
        horizontalMainScrollView.setVisibility(View.VISIBLE);
    }

    private void swapImageTextViewInfoShowOrHide(int i) {
        linSinImgSwap.setVisibility(i);
        linSinImgRotate.setVisibility(i);
        linSinImgHoriFlip.setVisibility(i);
        linSinImgVerFlip.setVisibility(i);
        linSinImgFilter.setVisibility(i);
        linSinImgAdjust.setVisibility(i);
        linSinImgDelete.setVisibility(i);
        linSinImgReplace.setVisibility(i);
        linSinImgRotateL10.setVisibility(i);
        linSinImgRotateR10.setVisibility(i);
    }

    private void singleVideoOptionShow(boolean z) {
        if (z) {
            if (this.horizontalMainScrollView.getVisibility() == View.VISIBLE) {
                this.horizontalMainScrollView.setVisibility(View.GONE);
            }
            if (this.horizontalTextScrollView.getVisibility() == View.VISIBLE) {
                this.imgTextBack.performClick();
            }
            if (this.horizontalSingleImageScrollView.getVisibility() == View.VISIBLE) {
                this.horizontalSingleImageScrollView.setVisibility(View.GONE);
            }
            this.horizontalSingleVideoScrollView.setVisibility(View.VISIBLE);
            return;
        }
        this.horizontalSingleVideoScrollView.setVisibility(View.GONE);
        if (this.horizontalTextScrollView.getVisibility() == View.VISIBLE) {
            this.imgTextBack.performClick();
        }
        if (this.horizontalSingleImageScrollView.getVisibility() == View.VISIBLE) {
            this.horizontalSingleImageScrollView.setVisibility(View.GONE);
        }
        this.horizontalMainScrollView.setVisibility(View.VISIBLE);
    }

    private void swapVideoTextViewInfoShowOrHide(int i) {
        this.linSinVidTrim.setVisibility(i);
        this.linSinVidSwap.setVisibility(i);
        this.linSinVidRotate.setVisibility(i);
        this.linSinVidDelete.setVisibility(i);
        this.linSinVidMute.setVisibility(i);
        this.linSinVidReplace.setVisibility(i);
    }

    private void muteOnlySelectedVideo(boolean z) {
        View view = this.viewPieces.get(this.selectedPiecePosition);
        if (view instanceof RelativeLayout) {
            view = ((RelativeLayout) view).getChildAt(0);
            if (!(view instanceof TextureVideoView)) {
                return;
            }
            if (z) {
                ((TextureVideoView) view).setVolume(0.0f, 0.0f);
            } else {
                ((TextureVideoView) view).setVolume(1.0f, 1.0f);
            }
        }
    }

    private void muteIconAndTextChange(boolean z) {
        View view = this.viewPieces.get(this.selectedPiecePosition);
        View childAt;
        if (z) {
            if (view instanceof RelativeLayout) {
                childAt = ((RelativeLayout) view).getChildAt(0);
                if (childAt instanceof TextureVideoView) {
                    ((TextureVideoView) childAt).setMute(true);
                }
            }
            this.imgSinVidMute.setImageResource(0);
            this.imgSinVidMute.setImageResource(R.drawable.ic_sound_unselect);
            this.txtSinVidMute.setText("On");
            return;
        }
        if (view instanceof RelativeLayout) {
            childAt = ((RelativeLayout) view).getChildAt(0);
            if (childAt instanceof TextureVideoView) {
                ((TextureVideoView) childAt).setMute(false);
            }
        }
        this.imgSinVidMute.setImageResource(0);
        this.imgSinVidMute.setImageResource(R.drawable.ic_mute_unselect);
        this.txtSinVidMute.setText("Off");
    }

    private void startOrStopAllVideo(String str) {
        for (int i = 0; i < this.bitmapPaint.size(); i++) {
            if (Util.isVideoFile(this.bitmapPaint.get(i))) {
                View view = this.viewPieces.get(i);
                if (view instanceof RelativeLayout) {
                    view = ((RelativeLayout) view).getChildAt(0);
                    if (view instanceof TextureVideoView) {
                        if (str.equalsIgnoreCase("pause")) {
                            ((TextureVideoView) view).pause();
                        } else if (this.selectedPiecePosition != -1) {
                            startOrStopOnlySelectedVideo();
                        } else {
                            ((TextureVideoView) view).start();
                        }
                    }
                }
            }
        }
    }

    private void startOrStopOnlySelectedVideo() {
        for (int i = 0; i < this.bitmapPaint.size(); i++) {
            if (Util.isVideoFile(this.bitmapPaint.get(i))) {
                int i2 = this.selectedPiecePosition;
                View view;
                if (i == i2) {
                    view = this.viewPieces.get(i2);
                    if (view instanceof RelativeLayout) {
                        view = ((RelativeLayout) view).getChildAt(0);
                        if (view instanceof TextureVideoView) {
                            ((TextureVideoView) view).start();
                        }
                    }
                } else {
                    view = this.viewPieces.get(i);
                    if (view instanceof RelativeLayout) {
                        view = ((RelativeLayout) view).getChildAt(0);
                        if (view instanceof TextureVideoView) {
                            ((TextureVideoView) view).pause();
                        }
                    }
                }
            }
        }
    }

    private void hideMusicView(boolean z) {
        if (z) {
            this.musicFlag = true;
            if (this.musicPath.equals("")) {
                startActivityForResult(new Intent(this, MusicActivity.class), SELECT_MUSIC);
            } else {
                this.linMusicLayout.setVisibility(View.VISIBLE);
            }
            return;
        }
        this.musicFlag = false;
        this.linMusicLayout.setVisibility(View.GONE);
    }

    private void musicView() {
        MediaPlayer mediaPlayer = new MediaPlayer();
        this.mediaPlayer = mediaPlayer;
        mediaPlayer.setLooping(true);
        this.seekMusic.setEnabled(false);
        this.seekMusic.setProgress(0);
        this.seekMusic.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        this.mediaPlayer.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                GridActivity.this.seekMusic.setProgress(0);
                GridActivity.this.mediaPlayer.start();
            }
        });
    }

    public void playAudio() {
        try {
            if (this.mediaPlayer == null) {
                this.mediaPlayer = new MediaPlayer();
            }
            this.mediaPlayer.reset();
            this.mediaPlayer.setDataSource(this, Uri.parse(this.musicPath));
            this.mediaPlayer.prepare();
            this.mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.seekMusic.setMax(this.mediaPlayer.getDuration());
        this.handler.postDelayed(this.runnable, 1);
    }

    private void calculateVideoDuration() {
        int i = 0;
        this.longestTime = 0;
        this.totalTime = 0;
        while (i < this.bitmapPaint.size()) {
            if (Util.isVideoFile(this.bitmapPaint.get(i))) {
                MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
                mediaMetadataRetriever.setDataSource(this.bitmapPaint.get(i));
                long parseLong = Long.parseLong(mediaMetadataRetriever.extractMetadata(9));
                if (parseLong > ((long) this.longestTime)) {
                    this.longestTime = (int) parseLong;
                }
                this.totalTime = (int) (((long) this.totalTime) + parseLong);
            }
            i++;
        }
        String str = "sec";
        String str2 = "Duration : ";
        StringBuilder stringBuilder;
        if (this.inOrder) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str2);
            stringBuilder.append(TimeUnit.MILLISECONDS.toSeconds(this.longestTime));
            stringBuilder.append(str);
            return;
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append(str2);
        stringBuilder.append(TimeUnit.MILLISECONDS.toSeconds(this.totalTime));
        stringBuilder.append(str);
    }

    public void onClick(View view) {
        this.layContainer.setVisibility(View.GONE);
        int id = view.getId();
        String str = "path";
        String str2 = "Select picture";
        String str3 = "android.intent.action.GET_CONTENT";
        String str4 = "image/*";
        String str5 = "";
        String str6 = "start";
        String str7 = "draw";
        RelativeLayout relativeLayout;
        int i;
        View childAt;
        Intent intent;
        StringBuilder stringBuilder;
        String str8;
        Intent intent2;
        switch (id) {
            case R.id.frame_brightness:
                hideOrShowBrightness();
                return;
            case R.id.frame_contrast:
                hideOrShowContrast();
                return;
            case R.id.frame_hue:
                hideOrShowHue();
                return;
            case R.id.frame_saturation:
                hideOrShowSaturation();
                return;
            case R.id.img_back:
                this.seekViewPadding.setProgress(this.curViewPad);
                this.seekPiecePadding.setProgress(this.curPiecePad);
                this.seekCorner.setProgress(this.curCorner);
                this.frameAdapter.setPos(this.curFrame);
                this.frameAdapter.notifyDataSetChanged();
                borderBottomSheetState(true);
                return;
            case R.id.img_bg_back:
                this.bgColorAdapter.setPos(this.curColor);
                this.bgColorAdapter.notifyDataSetChanged();
                setBGImage(this.curImage);
                this.bgImageAdapter.setPos(this.curImage);
                this.bgImageAdapter.notifyDataSetChanged();
                bgBottomSheetState(true);
                return;
            case R.id.img_bg_done:
                this.curColor = this.selectedColor;
                this.curImage = this.selectedImage;
                bgBottomSheetState(true);
                return;
            case R.id.img_done:
                this.curFrame = this.selectedFrame;
                this.curViewPad = this.seekViewPadding.getProgress();
                this.curPiecePad = this.seekPiecePadding.getProgress();
                this.curCorner = this.seekCorner.getProgress();
                borderBottomSheetState(true);
                return;
            case R.id.img_draw_cancel:
                this.photoEditor.clearAllViews();
                drawBottomSheetState(false);
                return;
            case R.id.img_draw_color:
                if (this.drawColorFlag) {
                    hideDrawColorRecyclerView(false);
                    return;
                } else {
                    hideDrawColorRecyclerView(true);
                    return;
                }
            case R.id.img_draw_done:
                saveDrawLine();
                drawBottomSheetState(false);
                return;
            case R.id.img_erase:
                if (this.drawEraseFlag) {
                    hideDrawEraseView(false);
                    return;
                } else {
                    hideDrawEraseView(true);
                    return;
                }
            case R.id.img_main_text_align_C:
                this.imgTextAlignL.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
                this.imgTextAlignC.setColorFilter(getResources().getColor(R.color.fontSelectColor), Mode.SRC_IN);
                this.imgTextAlignR.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
                setGravityText("C");
                return;
            case R.id.img_main_text_align_L:
                this.imgTextAlignL.setColorFilter(getResources().getColor(R.color.fontSelectColor), Mode.SRC_IN);
                this.imgTextAlignC.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
                this.imgTextAlignR.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
                setGravityText("L");
                return;
            case R.id.img_main_text_align_R:
                this.imgTextAlignL.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
                this.imgTextAlignC.setColorFilter(getResources().getColor(R.color.selectIconColor), Mode.SRC_IN);
                this.imgTextAlignR.setColorFilter(getResources().getColor(R.color.fontSelectColor), Mode.SRC_IN);
                setGravityText("R");
                return;
            case R.id.img_remove_music:
                this.musicPath = str5;
                MediaPlayer mediaPlayer = this.mediaPlayer;
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    this.mediaPlayer.stop();
                    this.mediaPlayer.reset();
                    this.mediaPlayer.release();
                    this.mediaPlayer = null;
                }
                this.seekMusic.setProgress(0);
                this.handler.removeCallbacks(this.runnable);
                hideMusicView(false);
                return;
            case R.id.img_reset_all:
                SeekBar seekBar = this.seekBarBrightness;
                seekBar.setProgress(seekBar.getMax() / 2);
                this.brightnessProgress = 0;
                seekBar = this.seekBarContrast;
                seekBar.setProgress(seekBar.getMax() / 2);
                this.contrastProgress = 0;
                seekBar = this.seekBarSaturation;
                seekBar.setProgress(seekBar.getMax() / 2);
                this.saturationProgress = 0;
                this.seekBarHue.setProgress(0);
                this.hueProgress = 0;
                new AdjustResetAsyncTask(this).execute();
                return;
            case R.id.img_sin_img_back:
                if (this.txtSinImgSwapInfo.getVisibility() == View.VISIBLE) {
                    this.txtSinImgSwapInfo.setVisibility(View.GONE);
                    swapImageTextViewInfoShowOrHide(0);
                    this.isImageSwapEnable = false;
                    return;
                }
                pieceUnSelect();
                singleImageOptionShow(false);
                if (this.inOrder) {
                    this.first.removeCallbacks(this.runnableFirst);
                    startOrStopAllVideo(str6);
                    return;
                }
                this.first.removeCallbacks(this.runnableFirst);
                this.first.postDelayed(this.runnableFirst, 10);
                return;
            case R.id.img_sin_vid_back:
                if (this.txtSinVidSwapInfo.getVisibility() == View.VISIBLE) {
                    this.txtSinVidSwapInfo.setVisibility(View.GONE);
                    swapVideoTextViewInfoShowOrHide(0);
                    this.isVideoSwapEnable = false;
                    return;
                }
                pieceUnSelect();
                if (this.inOrder) {
                    this.first.removeCallbacks(this.runnableFirst);
                    startOrStopAllVideo(str6);
                } else {
                    this.first.removeCallbacks(this.runnableFirst);
                    this.first.postDelayed(this.runnableFirst, 10);
                }
                singleVideoOptionShow(false);
                return;
            case R.id.img_sticker_back:
                stickerBottomSheetState(true);
                return;
            case R.id.img_sticker_category_for_add:
                hideOrShowStickerEmoji(false);
                hideOrShowStickerMsgText(false);
                hideOrShowStickerParty(false);
                hideOrShowStickerAdd(true);
                return;
            case R.id.img_sticker_category_one:
                hideOrShowStickerEmoji(true);
                hideOrShowStickerMsgText(false);
                hideOrShowStickerParty(false);
                hideOrShowStickerAdd(false);
                return;
            case R.id.img_sticker_category_thee:
                hideOrShowStickerEmoji(false);
                hideOrShowStickerMsgText(false);
                hideOrShowStickerParty(true);
                hideOrShowStickerAdd(false);
                return;
            case R.id.img_sticker_category_two:
                hideOrShowStickerEmoji(false);
                hideOrShowStickerMsgText(true);
                hideOrShowStickerParty(false);
                hideOrShowStickerAdd(false);
                return;
            case R.id.img_text_back:
                removeImageViewController();
                removeWatermarkImageViewController();
                hideOrShowTextOptionFont(false);
                hideOrShowTextOptionColor(false);
                hideOrShowTextOptionStyle(false);
                hideOrShowTextOptionBG(false);
                hideOrShowTextOptionAlign(false);
                hideOrShowTextOptionOpacity(false);
                hideOrShowTextOption(false);
                return;
            case R.id.img_tool_back:
                onBackPressed();
                return;
            case R.id.iv_done:
                pieceUnSelect();
                if (borderBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED && bgBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
                    horizontalTextScrollView.getVisibility();
                }
                if (stickerBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED && drawBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED && watermarkBottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED && horizontalSingleImageScrollView.getVisibility() != View.VISIBLE) {
                    horizontalSingleVideoScrollView.getVisibility();
                }
            {
                removeImageViewController();
                removeWatermarkImageViewController();
                if (Util.selectedVid > 0) {
                    int iNew;
                    this.saveClick = false;
                    this.first.removeCallbacks(this.runnableFirst);
                    startOrStopAllVideo("pause");
                    MediaPlayer mediaPlayers = this.mediaPlayer;
                    if (mediaPlayers != null && mediaPlayers.isPlaying()) {
                        this.mediaPlayer.pause();
                    }
                    this.handler.removeCallbacks(this.runnable);
                    stopAllTextureViewVideo();
                    String andSaveAllSticker = getAndSaveAllSticker();
                    StringBuilder stringBuildernew = new StringBuilder();
                    stringBuildernew.append(" sticker path ::");
                    stringBuildernew.append(andSaveAllSticker);
                    String andSaveBGImageColorFrame = getAndSaveBGImageColorFrame();
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(" bg path ::");
                    stringBuilder2.append(andSaveBGImageColorFrame);
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(" musicPath  ::");
                    stringBuilder2.append(this.musicPath);
                    int i2 = ((LayoutParams) this.puzzleView.getLayoutParams()).rightMargin;
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(" padding  ::");
                    stringBuilder2.append(i2);
                    if (this.inOrder) {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(" longestTime  ::");
                        stringBuilder2.append(this.longestTime);
                        iNew = this.longestTime;
                    } else {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(" totalTime  ::");
                        stringBuilder2.append(this.totalTime);
                        iNew = this.totalTime;
                    }
                    int i3 = iNew;
                    String saveAllImageAsBitmap = saveAllImageAsBitmap();
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("all image path ::");
                    stringBuilder2.append(saveAllImageAsBitmap);
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("selectedThemeId ::");
                    stringBuilder2.append(this.selectedThemeId);
                    String str2New = saveAllImageAsBitmap;
                    new ProcessVideo(this.context, this.bitmapPaint, this.viewPieces, this.puzzleView, this.baseViewWidth, this.baseViewHeight, i2, i3, andSaveAllSticker, this.musicPath, andSaveBGImageColorFrame, str2New, this.inOrder, this.selectedThemeId).execute();
                } else {
                    removeImageViewController();
                    removeWatermarkImageViewController();
                    FileUtils.savePuzzle(this.puzzleView, this.frame, FileUtils.getNewFile(this, "Photo"), 100, new com.kotlinz.videoCollage.puzzleview.Callback() {
                        public void onSuccess(String str) {
                            SelectActivity.selectedPath.clear();
                            SelectActivity.viewPieces.clear();
                            Util.bgImageSelected = false;
                            Util.bgColorSelected = false;
                            Util.selectedVid = 0;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(GridActivity.this.getCacheDir());
                            stringBuilder.append("/temp");
                            Util.deleteTempDir(new File(stringBuilder.toString()));
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(GridActivity.this.getCacheDir());
                            stringBuilder.append("/tempdraw");
                            Util.deleteTempDir(new File(stringBuilder.toString()));
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(GridActivity.this.getCacheDir());
                            stringBuilder.append("/filtertemp");
                            Util.deleteTempDir(new File(stringBuilder.toString()));
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(GridActivity.this.getCacheDir());
                            stringBuilder.append("/adjusttemp");
                            Util.deleteTempDir(new File(stringBuilder.toString()));
                            Intent intent = new Intent(GridActivity.this.context, ShareActivity.class);
                            intent.putExtra("SELECTED_PATH", str);
                            intent.putExtra("FROM", "GRID");
                            GridActivity.this.startActivity(intent);
                            GridActivity.this.finish();
                            Toast.makeText(GridActivity.this, "save successfully", Toast.LENGTH_SHORT).show();
                        }

                        public void onFailed() {
                            Toast.makeText(GridActivity.this, "save failed", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
            if (this.borderBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                this.imgGridBack.performClick();
            } else if (this.bgBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                this.imgBGBack.performClick();
            } else if (this.horizontalTextScrollView.getVisibility() == View.VISIBLE) {
                this.imgTextBack.performClick();
            } else if (this.stickerBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                this.imgStickerBack.performClick();
            } else if (this.drawBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                this.imgDrawCancel.performClick();
            } else if (this.watermarkBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                this.imgWatermarkBack.performClick();
            } else if (this.horizontalSingleImageScrollView.getVisibility() == View.VISIBLE) {
                this.imgSinImgBack.performClick();
            } else if (this.horizontalSingleVideoScrollView.getVisibility() == View.VISIBLE) {
                this.imgSinVidBack.performClick();
            }
            break;
            case R.id.img_watermark_back:
                this.puzzleView.setTouchEnable(true);
                relativeLayout = this.txtWatermarkStickerRel;
                if (relativeLayout != null) {
                    id = relativeLayout.getChildCount();
                    for (i = 0; i < id; i++) {
                        StringBuilder stringBuilder2;
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(" for i :: ");
                        stringBuilder3.append(i);
                        str2 = "water";
                        Log.e(str2, stringBuilder3.toString());
                        childAt = this.txtWatermarkStickerRel.getChildAt(i);
                        if (childAt instanceof AutofitTextRel) {
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(" AutofitTextRel :: ");
                            stringBuilder2.append(i);
                            Log.e(str2, stringBuilder2.toString());
                            ((AutofitTextRel) childAt).setBorderVisibility(false);
                        }
                        if (childAt instanceof ResizableStickerView) {
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(" ResizableStickerView :: ");
                            ResizableStickerView resizableStickerView = (ResizableStickerView) childAt;
                            stringBuilder2.append(resizableStickerView.isMultiTouchEnabled);
                            Log.e(str2, stringBuilder2.toString());
                            if (!resizableStickerView.isMultiTouchEnabled) {
                                this.txtWatermarkStickerRel.removeAllViews();
                            }
                        }
                    }
                }
                watermarkBottomSheetState(false);
                return;
            case R.id.img_watermark_done:
                this.puzzleView.setTouchEnable(true);
                relativeLayout = this.txtWatermarkStickerRel;
                if (relativeLayout != null) {
                    id = relativeLayout.getChildCount();
                    for (i = 0; i < id; i++) {
                        childAt = this.txtWatermarkStickerRel.getChildAt(i);
                        if (childAt instanceof AutofitTextRel) {
                            ((AutofitTextRel) childAt).setBorderVisibility(false);
                        }
                        if (childAt instanceof ResizableStickerView) {
                            ((ResizableStickerView) childAt).setDefaultTouchListener(false);
                        }
                    }
                }
                removeWatermarkImageViewController();
                watermarkBottomSheetState(false);
                return;
            case R.id.lin_adjust:
                pieceUnSelect();
                hideLayoutView(false);
                hideRatioView(false);
                hideFilterView(false);
                hideMusicView(false);
                if (this.adjustFlag) {
                    hideAdjustView(false);
                    return;
                } else {
                    hideAdjustView(true);
                    return;
                }
            case R.id.lin_bg:
                pieceUnSelect();
                this.layoutFlag = false;
                this.ratioFlag = false;
                hideLayoutView(false);
                hideRatioView(false);
                hideFilterView(false);
                hideAdjustView(false);
                hideMusicView(false);
                this.txtMainImage.performClick();
                bgBottomSheetState(true);
                return;
            case R.id.lin_border:
                pieceUnSelect();
                hideLayoutView(false);
                hideRatioView(false);
                hideFilterView(false);
                hideAdjustView(false);
                hideMusicView(false);
                this.txtMainBorder.performClick();
                borderBottomSheetState(true);
                return;
            case R.id.lin_draw:
                pieceUnSelect();
                hideLayoutView(false);
                hideRatioView(false);
                hideFilterView(false);
                hideAdjustView(false);
                hideMusicView(false);
                drawBottomSheetState(true);
                return;
            case R.id.lin_draw_delete:
                this.photoEditor.clearAllViews();
                this.imgDrawErase.performClick();
                return;
            case R.id.lin_draw_size_five:
                this.selectedLineSize = 5;
                if (this.drawMode.equalsIgnoreCase(str7)) {
                    this.photoEditor.setBrushSize(getResources().getDimension(R.dimen._15sdp));
                    this.photoEditor.setBrushDrawingMode(true);
                } else {
                    this.photoEditor.setBrushEraserSize(getResources().getDimension(R.dimen._15sdp));
                    this.photoEditor.brushEraser();
                }
                updateSelectedColor(5);
                return;
            case R.id.lin_draw_size_four:
                this.selectedLineSize = 4;
                if (this.drawMode.equalsIgnoreCase(str7)) {
                    this.photoEditor.setBrushSize(getResources().getDimension(R.dimen._12sdp));
                    this.photoEditor.setBrushDrawingMode(true);
                } else {
                    this.photoEditor.setBrushEraserSize(getResources().getDimension(R.dimen._12sdp));
                    this.photoEditor.brushEraser();
                }
                updateSelectedColor(4);
                return;
            case R.id.lin_draw_size_one:
                this.selectedLineSize = 1;
                if (this.drawMode.equalsIgnoreCase(str7)) {
                    this.photoEditor.setBrushSize(getResources().getDimension(R.dimen._3sdp));
                    this.photoEditor.setBrushDrawingMode(true);
                } else {
                    this.photoEditor.setBrushEraserSize(getResources().getDimension(R.dimen._3sdp));
                    this.photoEditor.brushEraser();
                }
                updateSelectedColor(1);
                return;
            case R.id.lin_draw_size_three:
                this.selectedLineSize = 3;
                if (this.drawMode.equalsIgnoreCase(str7)) {
                    this.photoEditor.setBrushSize(getResources().getDimension(R.dimen._9sdp));
                    this.photoEditor.setBrushDrawingMode(true);
                } else {
                    this.photoEditor.setBrushEraserSize(getResources().getDimension(R.dimen._9sdp));
                    this.photoEditor.brushEraser();
                }
                updateSelectedColor(3);
                return;
            case R.id.lin_draw_size_two:
                this.selectedLineSize = 2;
                if (this.drawMode.equalsIgnoreCase(str7)) {
                    this.photoEditor.setBrushSize(getResources().getDimension(R.dimen._6sdp));
                    this.photoEditor.setBrushDrawingMode(true);
                } else {
                    this.photoEditor.setBrushEraserSize(getResources().getDimension(R.dimen._6sdp));
                    this.photoEditor.brushEraser();
                }
                updateSelectedColor(2);
                return;
            case R.id.lin_filter:
                pieceUnSelect();
                hideLayoutView(false);
                hideRatioView(false);
                hideAdjustView(false);
                hideMusicView(false);
                if (this.filterFlag) {
                    hideFilterView(false);
                    return;
                } else {
                    hideFilterView(true);
                    return;
                }
            case R.id.lin_image:
                pieceUnSelect();
                hideLayoutView(false);
                hideRatioView(false);
                hideFilterView(false);
                hideAdjustView(false);
                hideMusicView(false);
                return;
            case R.id.lin_image_add_grid:
                if (this.bitmapPaint.size() >= 4) {
                    Toast.makeText(this, "Maximum 4 photos/videos allowed.", Toast.LENGTH_LONG).show();
                    return;
                }
                this.txtImage.setVisibility(View.VISIBLE);
                intent = new Intent();
                intent.setType(str4);
                intent.setAction(str3);
                startActivityForResult(Intent.createChooser(intent, str2), SELECT_PICTURE_FROM_GALLERY_FOR_GRID);
                return;
            case R.id.lin_inorder:
                if (this.inOrder) {
                    this.inOrder = false;
                    Toast.makeText(this.context, "Play video one by one", Toast.LENGTH_SHORT).show();
                    startOrStopAllVideo("pause");
                    this.videoCount = this.temp.size();
                    this.videoPos = this.temp.size();
                    this.first.postDelayed(this.runnableFirst, 10);
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("Duration : ");
                    stringBuilder.append(TimeUnit.MILLISECONDS.toSeconds(this.totalTime));
                    stringBuilder.append("sec");
                    return;
                }
                this.inOrder = true;
                Toast.makeText(this.context, "Play all video", Toast.LENGTH_SHORT).show();
                this.first.removeCallbacks(this.runnableFirst);
                startOrStopAllVideo(str6);
                stringBuilder = new StringBuilder();
                stringBuilder.append("Duration : ");
                stringBuilder.append(TimeUnit.MILLISECONDS.toSeconds(this.longestTime));
                stringBuilder.append("sec");
                return;
            case R.id.lin_layout:
                pieceUnSelect();
                hideRatioView(false);
                hideFilterView(false);
                hideAdjustView(false);
                hideMusicView(false);
                if (this.layoutFlag) {
                    hideLayoutView(false);
                    return;
                } else {
                    hideLayoutView(true);
                    return;
                }
            case R.id.lin_main_image_add_sticker:
                this.imgStickerBack.performClick();
                intent = new Intent();
                intent.setType(str4);
                intent.setAction(str3);
                startActivityForResult(Intent.createChooser(intent, str2), SELECT_PICTURE_FROM_GALLERY_FOR_IMAGE_STICKER);
                return;
            case R.id.lin_music:
                pieceUnSelect();
                hideLayoutView(false);
                hideRatioView(false);
                hideFilterView(false);
                hideAdjustView(false);
                if (musicFlag) {
                    hideMusicView(false);
                    return;
                } else {
                    hideMusicView(true);
                    return;
                }
            case R.id.lin_ratio:
                pieceUnSelect();
                hideLayoutView(false);
                hideFilterView(false);
                hideAdjustView(false);
                hideMusicView(false);
                if (this.ratioFlag) {
                    hideRatioView(false);
                    return;
                } else {
                    hideRatioView(true);
                    return;
                }
            case R.id.lin_sin_img_adjust:
                str8 = this.bitmapPaint.get(this.selectedPiecePosition);
                intent2 = new Intent(this, AdjustActivity.class);
                intent2.putExtra(str, str8);
                startActivityForResult(intent2, ADD_ADJUST_ON_PICTURE);
                return;
            case R.id.lin_sin_img_delete:
                if (this.bitmapPaint.size() == 2) {
                    Toast.makeText(this, "Minimum 2 photos/videos required.", Toast.LENGTH_LONG).show();
                    return;
                }
                str = "No";
                new AlertDialog.Builder(this).setMessage("Do you want to delete?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        GridActivity gridActivity;
                        View view = GridActivity.this.viewPieces.get(GridActivity.this.selectedPiecePosition);
                        if (view instanceof RelativeLayout) {
                            View childAt = ((RelativeLayout) view).getChildAt(0);
                            if (childAt instanceof TextureVideoView) {
                                TextureVideoView textureVideoView = (TextureVideoView) childAt;
                                textureVideoView.stop();
                                textureVideoView.setMediaPlayerCallback(null);
                                GridActivity.this.temp.remove(childAt);
                                Util.selectedVid--;
                            }
                        }
                        GridActivity.this.mainLinear.removeView(view);
                        GridActivity.this.mainLinear.requestLayout();
                        GridActivity.this.bitmapPaint.remove(GridActivity.this.selectedPiecePosition);
                        GridActivity.this.originalBitmapPaint.remove(GridActivity.this.selectedPiecePosition);
                        GridActivity.this.viewPieces.remove(GridActivity.this.selectedPiecePosition);
                        if (GridActivity.this.bitmapPaint.size() >= 4) {
                            gridActivity = GridActivity.this;
                            gridActivity.puzzleLayout = PuzzleUtils.getPuzzleLayout(1, gridActivity.bitmapPaint.size(), 0);
                        } else if (Util.selectedVid != 0) {
                            gridActivity = GridActivity.this;
                            gridActivity.puzzleLayout = PuzzleUtils.getPuzzleLayout(1, gridActivity.bitmapPaint.size(), 0);
                        } else {
                            gridActivity = GridActivity.this;
                            gridActivity.puzzleLayout = PuzzleUtils.getPuzzleLayout(0, gridActivity.bitmapPaint.size(), 0);
                        }
                        GridActivity.this.themeId = 0;
                        GridActivity.this.puzzleView.setPuzzleLayout(GridActivity.this.puzzleLayout);
                        GridActivity.this.puzzleView.invalidate();
                        GridActivity.this.puzzleView.requestLayout();
                        GridActivity.this.puzzleView.post(new Runnable() {
                            public void run() {
                                loadPhotoAndVideos();
                            }
                        });
                        GridActivity.this.layoutView();
                        gridActivity = GridActivity.this;
                        gridActivity.selectedThemeId = gridActivity.themeId;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(" selectedThemeId :: ");
                        stringBuilder.append(GridActivity.this.selectedThemeId);
                        GridActivity.this.singleImageOptionShow(false);
                        GridActivity.this.singleVideoOptionShow(false);
                        GridActivity.this.selectedPiecePosition = -1;
                        gridActivity = GridActivity.this;
                        gridActivity.videoCount = gridActivity.temp.size();
                        gridActivity = GridActivity.this;
                        gridActivity.videoPos = gridActivity.temp.size();
                        if (GridActivity.this.inOrder) {
                            GridActivity.this.first.removeCallbacks(GridActivity.this.runnableFirst);
                            GridActivity.this.startOrStopAllVideo("start");
                        } else {
                            GridActivity.this.first.removeCallbacks(GridActivity.this.runnableFirst);
                            GridActivity.this.first.postDelayed(GridActivity.this.runnableFirst, 10);
                        }
                        if (Util.selectedVid > 0) {
                            GridActivity.this.linCorner.setVisibility(View.GONE);
                            GridActivity.this.linFilter.setVisibility(View.GONE);
                            GridActivity.this.linAdjust.setVisibility(View.GONE);
                            GridActivity.this.linDraw.setVisibility(View.GONE);
                            GridActivity.this.linMusic.setVisibility(View.VISIBLE);
                            if (Util.selectedVid == 1) {
                                GridActivity.this.linPlayOrder.setVisibility(View.GONE);
                            } else {
                                GridActivity.this.linPlayOrder.setVisibility(View.VISIBLE);
                            }
                        } else {
                            GridActivity.this.linCorner.setVisibility(View.VISIBLE);
                            GridActivity.this.linMusic.setVisibility(View.GONE);
                            GridActivity.this.linPlayOrder.setVisibility(View.GONE);
                        }
                        GridActivity.this.calculateVideoDuration();
                        GridActivity.this.updateTextureView();
                    }
                }).setNegativeButton(str, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).show();
                return;
            case R.id.lin_sin_img_filter:
                str8 = this.bitmapPaint.get(this.selectedPiecePosition);
                intent2 = new Intent(this, FilterActivity.class);
                intent2.putExtra(str, str8);
                startActivityForResult(intent2, ADD_FILTER_ON_PICTURE);
                return;
            case R.id.lin_sin_img_hflip:
                this.puzzleView.flipHorizontally();
                return;
            case R.id.lin_sin_img_replace:
                showSelectedPhotoDialog();
                return;
            case R.id.lin_sin_img_rotate:
                this.puzzleView.rotate(90.0f);
                return;
            case R.id.lin_sin_img_rotate_mten:
                this.puzzleView.rotate(-10.0f);
                return;
            case R.id.lin_sin_img_rotate_pten:
                this.puzzleView.rotate(10.0f);
                return;
            case R.id.lin_sin_img_swap:
                this.txtSinImgSwapInfo.setVisibility(View.VISIBLE);
                swapImageTextViewInfoShowOrHide(8);
                this.lastPositionSwap = this.selectedPiecePosition;
                this.isImageSwapEnable = true;
                return;
            case R.id.lin_sin_img_vflip:
                this.puzzleView.flipVertically();
                return;
            case R.id.lin_sin_vid_delete:
                this.linSinImgDelete.performClick();
                return;
            case R.id.lin_sin_vid_mute:
                if (this.isMute) {
                    this.isMute = false;
                    muteOnlySelectedVideo(true);
                    muteIconAndTextChange(true);
                    return;
                }
                this.isMute = true;
                muteOnlySelectedVideo(false);
                muteIconAndTextChange(false);
                return;
            case R.id.lin_sin_vid_replace:
                showSelectedVideoDialog();
                return;
            case R.id.lin_sin_vid_rotate:
                this.linSinImgRotate.performClick();
                return;
            case R.id.lin_sin_vid_swap:
                this.txtSinVidSwapInfo.setVisibility(View.VISIBLE);
                swapVideoTextViewInfoShowOrHide(8);
                this.lastPositionSwap = this.selectedPiecePosition;
                this.isVideoSwapEnable = true;
                return;
            case R.id.lin_sin_vid_trim:
                stringBuilder = new StringBuilder();
                stringBuilder.append(this.context.getCacheDir());
                stringBuilder.append("/temptrimvideo");
                File file = new File(stringBuilder.toString());
                if (!file.exists()) {
                    file.mkdirs();
                }
                /*TrimVideo.activity((String) this.bitmapPaint.get(this.selectedPiecePosition)).setDestination(file.getAbsolutePath()).start(this);*/
                return;
            case R.id.lin_sticker:
                pieceUnSelect();
                removeImageViewController();
                removeWatermarkImageViewController();
                hideLayoutView(false);
                hideRatioView(false);
                hideFilterView(false);
                hideAdjustView(false);
                hideMusicView(false);
                stickerBottomSheetState(true);
                return;
            case R.id.lin_text:
                pieceUnSelect();
                hideLayoutView(false);
                hideRatioView(false);
                hideFilterView(false);
                hideAdjustView(false);
                hideMusicView(false);
                EditTextDialogFragment editTextDialogFragment = new EditTextDialogFragment(this.context, str5);
                editTextDialogFragment = editTextDialogFragment;
                editTextDialogFragment.show(getSupportFragmentManager(), EditTextDialogFragment.class.getSimpleName());
                removeImageViewController();
                removeWatermarkImageViewController();
                return;
            case R.id.lin_text_align:
                pieceUnSelect();
                hideOrShowTextOptionFont(false);
                hideOrShowTextOptionColor(false);
                hideOrShowTextOptionStyle(false);
                hideOrShowTextOptionBG(false);
                hideOrShowTextOptionOpacity(false);
                if (this.textAlignFlag) {
                    hideOrShowTextOptionAlign(false);
                    return;
                } else {
                    hideOrShowTextOptionAlign(true);
                    return;
                }
            case R.id.lin_text_bg:
                pieceUnSelect();
                hideOrShowTextOptionFont(false);
                hideOrShowTextOptionColor(false);
                hideOrShowTextOptionStyle(false);
                hideOrShowTextOptionAlign(false);
                hideOrShowTextOptionOpacity(false);
                if (this.textBGFlag) {
                    hideOrShowTextOptionBG(false);
                    return;
                } else {
                    hideOrShowTextOptionBG(true);
                    return;
                }
            case R.id.lin_text_color:
                pieceUnSelect();
                hideOrShowTextOptionFont(false);
                hideOrShowTextOptionStyle(false);
                hideOrShowTextOptionBG(false);
                hideOrShowTextOptionAlign(false);
                hideOrShowTextOptionOpacity(false);
                if (this.textColorFlag) {
                    hideOrShowTextOptionColor(false);
                    return;
                } else {
                    hideOrShowTextOptionColor(true);
                    return;
                }
            case R.id.lin_text_copy:
                pieceUnSelect();
                hideOrShowTextOptionFont(false);
                hideOrShowTextOptionColor(false);
                hideOrShowTextOptionStyle(false);
                hideOrShowTextOptionBG(false);
                hideOrShowTextOptionAlign(false);
                hideOrShowTextOptionOpacity(false);
                hideOrShowTextOptionCopy();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    setTextCopy();
                }
                return;
            case R.id.lin_text_edit:
                pieceUnSelect();
                hideOrShowTextOptionEdit(false);
                editText();
                return;
            case R.id.lin_text_font:
                pieceUnSelect();
                hideOrShowTextOptionColor(false);
                hideOrShowTextOptionStyle(false);
                hideOrShowTextOptionBG(false);
                hideOrShowTextOptionAlign(false);
                hideOrShowTextOptionOpacity(false);
                if (this.textFontFlag) {
                    hideOrShowTextOptionFont(false);
                    return;
                } else {
                    hideOrShowTextOptionFont(true);
                    return;
                }
            case R.id.lin_text_opacity:
                pieceUnSelect();
                hideOrShowTextOptionFont(false);
                hideOrShowTextOptionColor(false);
                hideOrShowTextOptionStyle(false);
                hideOrShowTextOptionBG(false);
                hideOrShowTextOptionAlign(false);
                if (this.textOpacityFlag) {
                    hideOrShowTextOptionOpacity(false);
                    return;
                } else {
                    hideOrShowTextOptionOpacity(true);
                    return;
                }
            case R.id.lin_text_style:
                pieceUnSelect();
                hideOrShowTextOptionFont(false);
                hideOrShowTextOptionColor(false);
                hideOrShowTextOptionBG(false);
                hideOrShowTextOptionAlign(false);
                hideOrShowTextOptionOpacity(false);
                if (this.textStyleFlag) {
                    hideOrShowTextOptionStyle(false);
                    return;
                } else {
                    hideOrShowTextOptionStyle(true);
                    return;
                }
            case R.id.lin_watermark:
                this.puzzleView.setTouchEnable(false);
                removeImageViewController();
                pieceUnSelect();
                hideLayoutView(false);
                hideRatioView(false);
                hideFilterView(false);
                hideAdjustView(false);
                hideMusicView(false);
                watermarkBottomSheetState(true);
                return;
            case R.id.txt_main_border:
                hideOrShowBorderView(true);
                hideOrShowFrameView(false);
                return;
            case R.id.txt_main_color:
                if (this.bgColorAdapter != null && Util.bgImageSelected) {
                    this.bgColorAdapter.setPos(-1);
                    this.bgColorAdapter.notifyDataSetChanged();
                }
                this.bgColorRecycler.smoothScrollToPosition(this.curColor);
                hideOrShowImageView(false);
                hideOrShowColorView(true);
                return;
            case R.id.txt_main_frame:
                this.frameRecycler.smoothScrollToPosition(this.curFrame);
                hideOrShowBorderView(false);
                hideOrShowFrameView(true);
                return;
            case R.id.txt_main_image:
                if (this.bgImageAdapter != null && Util.bgColorSelected) {
                    this.bgImageAdapter.setPos(-1);
                    this.bgImageAdapter.notifyDataSetChanged();
                }
                this.bgImageRecycler.smoothScrollToPosition(this.curImage);
                hideOrShowImageView(true);
                hideOrShowColorView(false);
                return;
            case R.id.txt_main_text_bg_color:
                hideOrShowTextOptionBGImage(false);
                hideOrShowTextOptionBGColor(true);
                return;
            case R.id.txt_main_text_bg_image:
                hideOrShowTextOptionBGImage(true);
                hideOrShowTextOptionBGColor(false);
                return;
            case R.id.txt_main_text_border:
                hideOrShowTextOptionShadow(false);
                hideOrShowTextOptionBorder(true);
                return;
            case R.id.txt_main_text_shadow:
                hideOrShowTextOptionShadow(true);
                hideOrShowTextOptionBorder(false);
                return;
            case R.id.txt_main_watermark_social:
                hideOrShowWatermarkPicVidView(false);
                hideOrShowWatermarkSocialView(true);
                return;
            case R.id.txt_main_watermark_vidmak:
                hideOrShowWatermarkPicVidView(true);
                hideOrShowWatermarkSocialView(false);
                return;
            default:
                return;
        }
    }

    private void showSelectedPhotoDialog() {
        PhotoPicker.newInstance().setMaxCount(1).pickImage(this);
    }

    private void showSelectedVideoDialog() {
        VideoPicker.newInstance().setMaxCount(1).pickVideo(this);
    }


    public void onActivityResult(int i, int i2, Intent intent) {
        String str = null;
        String str1 = null;
        super.onActivityResult(i, i2, intent);
        if (i == 94 && i2 == -1) {
            str1 = intent.getStringArrayListExtra(Define.PATHS).get(0);
            final String finalStr2 = str1;
            Picasso.get().load(R.drawable.demo9).config(Config.RGB_565).into(new Target() {
                public void onPrepareLoad(Drawable drawable) {

                }

                @SuppressLint("WrongConstant")
                public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
                    View view = viewPieces.get(selectedPiecePosition);
                    Bitmap resize = Util.resize(Util.rotateBitmapSam(BitmapFactory.decodeFile(finalStr2), finalStr2), finalStr2);
                    Bitmap access$11300 = scaleBitmap(resize);
                    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                    layoutParams.width = access$11300.getWidth();
                    layoutParams.height = access$11300.getHeight();
                    if (view instanceof LinearLayout) {
                        View childAt = ((LinearLayout) view).getChildAt(0);
                        if (childAt instanceof ImageView) {
                            ((ImageView) childAt).setImageBitmap(resize);
                        }
                    }
                    view.setLayoutParams(layoutParams);
                    view.measure(MeasureSpec.makeMeasureSpec(access$11300.getWidth(), 1073741824), MeasureSpec.makeMeasureSpec(access$11300.getHeight(), 1073741824));
                    view.requestLayout();
                    mainLinear.updateViewLayout(view, layoutParams);
                    viewPieces.set(selectedPiecePosition, view);
                    bitmapPaint.set(selectedPiecePosition, finalStr2);
                    originalBitmapPaint.set(selectedPiecePosition, finalStr2);
                    puzzleView.replace(view, "");
                    puzzleView.invalidate();
                    puzzleView.requestLayout();
                }

                @Override
                public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                }

                public void onBitmapFailed(Drawable drawable) {
                    Snackbar.make(puzzleView, "Replace Failed!", BaseTransientBottomBar.LENGTH_SHORT).show();
                }
            });
        }
        if (i == 95 && i2 == -1) {
            str1 = intent.getStringExtra("video_path");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" grid activity path :: ");
            stringBuilder.append(str1);
            final String finalStr = str1;
            Picasso.get().load(R.drawable.demo9).config(Config.RGB_565).into(new Target() {
                public void onPrepareLoad(Drawable drawable) {

                }

                public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
                    View view = viewPieces.get(selectedPiecePosition);
                    Bitmap access$11300 = scaleBitmap(ThumbnailUtils.createVideoThumbnail(finalStr, 2));
                    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                    layoutParams.width = access$11300.getWidth();
                    layoutParams.height = access$11300.getHeight();
                    Uri uriForFile = FileProvider.getUriForFile(GridActivity.this.context, "com.kotlinz.videoeditor.provider", new File(finalStr));
                    if (view instanceof RelativeLayout) {
                        View childAt = ((RelativeLayout) view).getChildAt(0);
                        if (childAt instanceof TextureVideoView) {
                            ((TextureVideoView) childAt).setVideoURI(uriForFile);
                        }
                    }
                    view.setLayoutParams(layoutParams);
                    view.measure(MeasureSpec.makeMeasureSpec(access$11300.getWidth(), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(access$11300.getHeight(), MeasureSpec.EXACTLY));
                    view.requestLayout();
                    mainLinear.updateViewLayout(view, layoutParams);
                    viewPieces.set(selectedPiecePosition, view);
                    bitmapPaint.set(selectedPiecePosition, finalStr);
                    originalBitmapPaint.set(selectedPiecePosition, finalStr);
                    puzzleView.replace(view, "");
                    puzzleView.invalidate();
                    puzzleView.requestLayout();
                    calculateVideoDuration();
                }

                @Override
                public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                    Snackbar.make(GridActivity.this.puzzleView, "Replace Failed!", BaseTransientBottomBar.LENGTH_SHORT).show();
                }
            });
        }
        if (i == SELECT_PICTURE_FROM_GALLERY_FOR_IMAGE_STICKER && i2 == -1) {
            Uri data = intent.getData();
            if (data != null) {
                CropImage.activity(data).start(activity);
            } else {
                Toast.makeText(activity, "Select Image First...", Toast.LENGTH_SHORT).show();
            }
        }

        if (i == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            Uri resultUri;
            CropImage.ActivityResult result = CropImage.getActivityResult(intent);
            resultUri = result.getUri();
            if (resultUri != null) {
                try {
                    color_Type = "colored";
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(activity.getContentResolver(), resultUri);
                        addSticker("0", Constants.saveBitmapObjectSticker(bitmap));
                    }
                } catch (Error | Exception e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(activity, "Select Image First...", Toast.LENGTH_SHORT).show();
            }
        }

        if (i == SELECT_PICTURE_FROM_GALLERY_FOR_GRID && i2 == -1) {
            txtImage.setVisibility(View.GONE);
            str1 = RealPathUtil.getRealPath(this, intent.getData());
            bitmapPaint.add(str1);
            originalBitmapPaint.add(str1);
            Bitmap scaleBitmap;
            if (Util.isVideoFile(str1)) {
                ViewGroup.LayoutParams layoutParams2;
                RelativeLayout relativeLayout = new RelativeLayout(this);
                scaleBitmap = scaleBitmap(ThumbnailUtils.createVideoThumbnail(str1, 2));
                if (scaleBitmap != null) {
                    layoutParams2 = new RelativeLayout.LayoutParams(scaleBitmap.getWidth(), scaleBitmap.getHeight());
                } else {
                    layoutParams2 = new RelativeLayout.LayoutParams(1, 1);
                }
                TextureVideoView textureVideoView = new TextureVideoView(this);
                textureVideoView.setVideoURI(FileProvider.getUriForFile(context, getPackageName() + ".provider", new File(str1)));
                relativeLayout.setLayoutParams(layoutParams2);
                relativeLayout.addView(textureVideoView);
                viewPieces.add(relativeLayout);
                mainLinear.addView(relativeLayout);
                temp.add(textureVideoView);
                calculateVideoDuration();
            } else {
                LinearLayout linearLayout = new LinearLayout(this);
                Bitmap resize = Util.resize(Util.rotateBitmapSam(BitmapFactory.decodeFile(str1), str1), str1);
                scaleBitmap = scaleBitmap(resize);
                RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(scaleBitmap.getWidth(), scaleBitmap.getHeight());
                ImageView imageView = new ImageView(this);
                imageView.setImageBitmap(resize);
                linearLayout.setLayoutParams(layoutParams3);
                linearLayout.addView(imageView);
                viewPieces.add(linearLayout);
                mainLinear.addView(linearLayout);
            }
            if (bitmapPaint.size() >= 4) {
                puzzleLayout = PuzzleUtils.getPuzzleLayout(1, bitmapPaint.size(), 0);
            } else if (Util.selectedVid != 0) {
                puzzleLayout = PuzzleUtils.getPuzzleLayout(1, bitmapPaint.size(), 0);
            } else {
                puzzleLayout = PuzzleUtils.getPuzzleLayout(0, bitmapPaint.size(), 0);
            }
            themeId = 0;
            puzzleView.setPuzzleLayout(this.puzzleLayout);
            puzzleView.invalidate();
            puzzleView.requestLayout();
            puzzleView.post(new Runnable() {
                public void run() {
                    loadPhotoAndVideos();
                }
            });
            layoutView();
            selectedThemeId = this.themeId;
        }
        if (i == ADD_FILTER_ON_PICTURE && i2 == -1) {
            str1 = intent.getStringExtra("filter_path");
            final String finalStr1 = str1;
            Picasso.get().load(R.drawable.demo9).config(Config.RGB_565).into(new Target() {
                public void onPrepareLoad(Drawable drawable) {
                }

                public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
                    View view = GridActivity.this.viewPieces.get(GridActivity.this.selectedPiecePosition);
                    Bitmap resize = Util.resize(BitmapFactory.decodeFile(finalStr1), finalStr1);
                    Bitmap access$11300 = GridActivity.this.scaleBitmap(resize);
                    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                    layoutParams.width = access$11300.getWidth();
                    layoutParams.height = access$11300.getHeight();
                    if (view instanceof LinearLayout) {
                        View childAt = ((LinearLayout) view).getChildAt(0);
                        if (childAt instanceof ImageView) {
                            ((ImageView) childAt).setImageBitmap(resize);
                        }
                    }
                    view.setLayoutParams(layoutParams);
                    view.measure(MeasureSpec.makeMeasureSpec(access$11300.getWidth(), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(access$11300.getHeight(), MeasureSpec.EXACTLY));
                    view.requestLayout();
                    GridActivity.this.mainLinear.updateViewLayout(view, layoutParams);
                    GridActivity.this.viewPieces.set(GridActivity.this.selectedPiecePosition, view);
                    GridActivity.this.bitmapPaint.set(GridActivity.this.selectedPiecePosition, finalStr1);
                    GridActivity.this.originalBitmapPaint.set(GridActivity.this.selectedPiecePosition, finalStr1);
                    GridActivity.this.puzzleView.replace(view, "");
                }

                @Override
                public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                }

                public void onBitmapFailed(Drawable drawable) {
                    Snackbar.make(GridActivity.this.puzzleView, "Replace Failed!", BaseTransientBottomBar.LENGTH_SHORT).show();
                }
            });
        }
        if (i == ADD_ADJUST_ON_PICTURE && i2 == -1) {
            str1 = intent.getStringExtra("adjust_path");
            final String finalStr3 = str;
            Picasso.get().load(R.drawable.demo9).config(Config.RGB_565).into(new Target() {
                public void onPrepareLoad(Drawable drawable) {

                }

                @SuppressLint("WrongConstant")
                public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
                    View view = GridActivity.this.viewPieces.get(GridActivity.this.selectedPiecePosition);
                    Bitmap resize = Util.resize(BitmapFactory.decodeFile(finalStr3), finalStr3);
                    Bitmap access$11300 = GridActivity.this.scaleBitmap(resize);
                    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                    layoutParams.width = access$11300.getWidth();
                    layoutParams.height = access$11300.getHeight();
                    if (view instanceof LinearLayout) {
                        View childAt = ((LinearLayout) view).getChildAt(0);
                        if (childAt instanceof ImageView) {
                            ((ImageView) childAt).setImageBitmap(resize);
                        }
                    }
                    view.setLayoutParams(layoutParams);
                    view.measure(MeasureSpec.makeMeasureSpec(access$11300.getWidth(), 1073741824), MeasureSpec.makeMeasureSpec(access$11300.getHeight(), 1073741824));
                    view.requestLayout();
                    GridActivity.this.mainLinear.updateViewLayout(view, layoutParams);
                    GridActivity.this.viewPieces.set(GridActivity.this.selectedPiecePosition, view);
                    GridActivity.this.bitmapPaint.set(GridActivity.this.selectedPiecePosition, finalStr3);
                    GridActivity.this.originalBitmapPaint.set(GridActivity.this.selectedPiecePosition, finalStr3);
                    GridActivity.this.puzzleView.replace(view, "");
                }

                @Override
                public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                }

                public void onBitmapFailed(Drawable drawable) {
                    Snackbar.make(GridActivity.this.puzzleView, "Replace Failed!", BaseTransientBottomBar.LENGTH_SHORT).show();
                }
            });
        }
        str = str1;
       /* if (i == TrimVideo.VIDEO_TRIMMER_REQ_CODE && i2 == -1) {
            String uri = Uri.parse(TrimVideo.getTrimmedVideoPath(intent)).toString();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(" trim ::: ");
            stringBuilder2.append(uri);
            Log.e("temp", stringBuilder2.toString());
            View view = (View) this.viewPieces.get(this.selectedPiecePosition);
            if (view instanceof RelativeLayout) {
                view = ((RelativeLayout) view).getChildAt(0);
                if (view instanceof TextureVideoView) {
                    TextureVideoView textureVideoView2 = (TextureVideoView) view;
                    textureVideoView2.setVideoURI(FileProvider.getUriForFile(this.context, str2, new File(uri)));
                    this.bitmapPaint.set(this.selectedPiecePosition, uri);
                    this.originalBitmapPaint.set(this.selectedPiecePosition, uri);
                    this.puzzleView.invalidate();
                    this.puzzleView.requestLayout();
                    calculateVideoDuration();
                }
            }
        }*/
        if (i == SELECT_MUSIC && i2 == -1) {
            musicPath = intent.getStringExtra("music_path");
            txtMusicName.setText(intent.getStringExtra("music_name"));
//            txtMusic.setVisibility(View.VISIBLE);
            linMusicLayout.setVisibility(View.VISIBLE);
            playAudio();
        } else {
            hideMusicView(false);
        }
        updateTextureView();
    }

    private void updateTextureView() {
        for (int i = 0; i < this.bitmapPaint.size(); i++) {
            if (Util.isVideoFile(this.bitmapPaint.get(i))) {
                View view = this.viewPieces.get(i);
                if (view instanceof RelativeLayout) {
                    view = ((RelativeLayout) view).getChildAt(0);
                    if (view instanceof TextureVideoView) {
                        ((TextureVideoView) view).b();
                    }
                }
            }
        }
    }

    public byte[] getResBytes(Context context, String str) {
        byte[] bArr = null;
        try {
            Bitmap bitmap = ((BitmapDrawable) Drawable.createFromStream(getResources().getAssets().open(str), null)).getBitmap();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(CompressFormat.PNG, 100, byteArrayOutputStream);
            bArr = byteArrayOutputStream.toByteArray();
            return bArr;
        } catch (Exception unused) {
            return bArr;
        }
    }

    public void onCenterX(View view) {
        this.guideline.setCenterValues(true, false);
    }

    public void onCenterXY(View view) {
        this.guideline.setCenterValues(true, true);
    }

    public void onCenterY(View view) {
        this.guideline.setCenterValues(false, true);
    }

    public void onDelete() {
        this.imgTextBack.performClick();
    }

    public void onOtherXY(View view) {
        this.guideline.setCenterValues(false, false);
    }

    public void onRotateDown(View view) {
        touchDown(view, "view border");
    }

    public void onRotateUp(View view) {
        touchUp(view);
    }

    public void onScaleDown(View view) {
        touchDown(view, "view border");
    }

    public void onScaleUp(View view) {
        touchUp(view);
    }

    public void onTouchDown(View view) {
        touchDown(view, "hide border");
    }

    public void onTouchUp(View view) {
        touchUp(view);
    }

    public void showController() {
        if (this.horizontalTextScrollView.getVisibility() == View.VISIBLE) {
            addImageViewController();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    public void textAdd(String str) {
        if (str.length() > 0) {
            TextInfo textInfo = new TextInfo();
            textInfo.setPOS_X((float) ((this.txtStickerRel.getWidth() / 2) - Util.dpToPx(this, 100)));
            textInfo.setPOS_Y((float) ((this.txtStickerRel.getHeight() / 2) - Util.dpToPx(this, 100)));
            textInfo.setWIDTH(Util.dpToPx(this, Callback.DEFAULT_DRAG_ANIMATION_DURATION));
            textInfo.setHEIGHT(Util.dpToPx(this, Callback.DEFAULT_DRAG_ANIMATION_DURATION));
            textInfo.setTEXT(str.replace("\n", " "));
            textInfo.setFONT_NAME(this.fontName);
            textInfo.setTEXT_COLOR(this.tColor);
            textInfo.setTEXT_ALPHA(this.tAlpha);
            textInfo.setBORDER_COLOR(this.borderColor);
            textInfo.setSHADOW_COLOR(this.shadowColor);
            textInfo.setSHADOW_PROG(this.shadowProg);
            textInfo.setSHADOW_XY_PROG(this.shadowXYProg);
            textInfo.setBG_COLOR(this.bgColor);
            textInfo.setBG_DRAWABLE(this.bgDrawable);
            textInfo.setBG_ALPHA(this.bgAlpha);
            textInfo.setROTATION(0.0f);
            textInfo.setTEXT_GRAVITY(this.txtGravity);
            textInfo.setCharSpacing(this.txtCharSpacing);
            textInfo.setLineSpacing(this.txtLineSpacing);
            View view = null;
            int childCount;
            AutofitTextRel autofitTextRel;
            if (this.editMode) {
                this.touchChange = false;
                RelativeLayout relativeLayout = this.txtStickerRel;
                textInfo.setXRotateProg(((AutofitTextRel) relativeLayout.getChildAt(relativeLayout.getChildCount() - 1)).getXRotateProg());
                relativeLayout = this.txtStickerRel;
                textInfo.setYRotateProg(((AutofitTextRel) relativeLayout.getChildAt(relativeLayout.getChildCount() - 1)).getYRotateProg());
                relativeLayout = this.txtStickerRel;
                textInfo.setZRotateProg(((AutofitTextRel) relativeLayout.getChildAt(relativeLayout.getChildCount() - 1)).getZRotateProg());
                relativeLayout = this.txtStickerRel;
                textInfo.setCurveRotateProg(((AutofitTextRel) relativeLayout.getChildAt(relativeLayout.getChildCount() - 1)).getCurveRotateProg());
                relativeLayout = this.txtStickerRel;
                ((AutofitTextRel) relativeLayout.getChildAt(relativeLayout.getChildCount() - 1)).setTextInfo(textInfo, false);
                childCount = this.txtStickerRel.getChildCount();
                if (childCount != 0) {
                    view = this.txtStickerRel.getChildAt(childCount - 1);
                    if (view instanceof AutofitTextRel) {
                        autofitTextRel = (AutofitTextRel) view;
                        autofitTextRel.setBorderVisibility(false);
                        if (!autofitTextRel.getBorderVisibility()) {
                            autofitTextRel.setBorderVisibility(true);
                        }
                    }
                }
                this.editMode = false;
                hideOrShowTextOptionEdit(false);
            } else {
                this.touchChange = true;
                textInfo.setXRotateProg(45);
                textInfo.setYRotateProg(45);
                textInfo.setZRotateProg(SubSamplingScaleImageView.ORIENTATION_180);
                textInfo.setCurveRotateProg(0);
                AutofitTextRel autofitTextRel2 = new AutofitTextRel(this);
                this.txtStickerRel.addView(autofitTextRel2);
                autofitTextRel2.setTextInfo(textInfo, false);
                autofitTextRel2.setId(View.generateViewId());
                autofitTextRel2.setMainLayoutWH((float) this.frame.getWidth(), (float) this.frame.getHeight());
                autofitTextRel2.setOnTouchCallbackListener(this);
                autofitTextRel2.setBorderVisibility(false);
                childCount = this.txtStickerRel.getChildCount();
                if (childCount != 0) {
                    view = this.txtStickerRel.getChildAt(childCount - 1);
                    if (view instanceof AutofitTextRel) {
                        autofitTextRel = (AutofitTextRel) view;
                        if (!autofitTextRel.getBorderVisibility()) {
                            autofitTextRel.setBorderVisibility(true);
                        }
                    }
                }
            }
            this.focusedView = view;
            hideOrShowTextOption(true);
            return;
        }
        Toast.makeText(this, "Please enter text.", Toast.LENGTH_SHORT).show();
    }

    private void setTextFonts(String str) {
        this.fontName = str;
        int childCount = this.txtStickerRel.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.txtStickerRel.getChildAt(i);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    autofitTextRel.setTextFont(str);
                }
            }
        }
    }

    public void removeImageViewController() {
        RelativeLayout relativeLayout = this.txtStickerRel;
        if (relativeLayout != null) {
            int childCount = relativeLayout.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = this.txtStickerRel.getChildAt(i);
                if (childAt instanceof AutofitTextRel) {
                    ((AutofitTextRel) childAt).setBorderVisibility(false);
                }
                if (childAt instanceof ResizableStickerView) {
                    ((ResizableStickerView) childAt).setBorderVisibility(false);
                }
            }
        }
    }

    public void removeWatermarkImageViewController() {
        RelativeLayout relativeLayout = this.txtWatermarkStickerRel;
        if (relativeLayout != null) {
            int childCount = relativeLayout.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = this.txtWatermarkStickerRel.getChildAt(i);
                if (childAt instanceof AutofitTextRel) {
                    ((AutofitTextRel) childAt).setBorderVisibility(false);
                }
                if (childAt instanceof ResizableStickerView) {
                    ((ResizableStickerView) childAt).setBorderVisibility(false);
                }
            }
        }
    }

    public void addImageViewController() {
        RelativeLayout relativeLayout = this.txtStickerRel;
        if (relativeLayout != null) {
            int childCount = relativeLayout.getChildCount();
            for (int i = 0; i < childCount; i++) {
                this.txtStickerRel.getChildAt(i);
                View view = this.focusedView;
                if (view instanceof AutofitTextRel) {
                    ((AutofitTextRel) view).setBorderVisibility(true);
                }
                view = this.focusedView;
                if (view instanceof ResizableStickerView) {
                    ((ResizableStickerView) view).setBorderVisibility(true);
                }
            }
        }
    }

    private void editText() {
        removeImageViewController();
        removeWatermarkImageViewController();
        this.editMode = true;
        textSelectionDialog();
    }

    private void textSelectionDialog() {
        if (this.editMode) {
            RelativeLayout relativeLayout = this.txtStickerRel;
            TextInfo textInfo = ((AutofitTextRel) relativeLayout.getChildAt(relativeLayout.getChildCount() - 1)).getTextInfo();
            textInfo.setPOS_X(textInfo.getPOS_X());
            textInfo.setPOS_Y(textInfo.getPOS_Y());
            textInfo.setWIDTH(textInfo.getWIDTH());
            textInfo.setHEIGHT(textInfo.getHEIGHT());
            textInfo.setTEXT(textInfo.getTEXT());
            textInfo.setFONT_NAME(textInfo.getFONT_NAME());
            textInfo.setTEXT_COLOR(textInfo.getTEXT_COLOR());
            textInfo.setTEXT_ALPHA(textInfo.getTEXT_ALPHA());
            textInfo.setBORDER_COLOR(this.borderColor);
            textInfo.setSHADOW_COLOR(textInfo.getSHADOW_COLOR());
            textInfo.setSHADOW_PROG(textInfo.getSHADOW_PROG());
            textInfo.setSHADOW_XY_PROG(this.shadowXYProg);
            textInfo.setBG_COLOR(textInfo.getBG_COLOR());
            textInfo.setBG_DRAWABLE(textInfo.getBG_DRAWABLE());
            textInfo.setBG_ALPHA(textInfo.getBG_ALPHA());
            textInfo.setROTATION(textInfo.getROTATION());
            textInfo.setTEXT_GRAVITY(textInfo.getTEXT_GRAVITY());
            new EditTextDialogFragment(this.context, textInfo.getTEXT()).show(getSupportFragmentManager(), EditTextDialogFragment.class.getSimpleName());
        }
    }

    private void updateColor(String str) {
        int childCount = this.txtStickerRel.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.txtStickerRel.getChildAt(i);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    autofitTextRel.setTextColor(Color.parseColor(str));
                    this.tColor = Color.parseColor(str);
                    this.textColorSet = Color.parseColor(str);
                }
            }
            if (childAt instanceof ResizableStickerView) {
                ResizableStickerView resizableStickerView = (ResizableStickerView) childAt;
                if (resizableStickerView.getBorderVisbilty()) {
                    resizableStickerView.setColorType("white");
                    resizableStickerView.setColor(Color.parseColor(str));
                    this.stkrColorSet = Color.parseColor(str);
                }
            }
        }
    }

    private void updateBorder(String str) {
        int childCount = this.txtStickerRel.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.txtStickerRel.getChildAt(i);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    autofitTextRel.setTextBorderColor(Color.parseColor(str));
                    this.borderColor = Color.parseColor(str);
                }
            }
            if (childAt instanceof ResizableStickerView) {
                ResizableStickerView resizableStickerView = (ResizableStickerView) childAt;
                if (resizableStickerView.getBorderVisbilty()) {
                    resizableStickerView.setColorType("white");
                    resizableStickerView.setColor(Color.parseColor(str));
                    this.stkrColorSet = Color.parseColor(str);
                }
            }
        }
    }

    private void updateShadow(String str) {
        int childCount = this.txtStickerRel.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.txtStickerRel.getChildAt(i);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    if (this.seekBarShadowBlur.getProgress() == 0) {
                        this.seekBarShadowBlur.setProgress(5);
                    }
                    autofitTextRel.setTextShadowColor(Color.parseColor(str));
                    this.shadowColor = Color.parseColor(str);
                }
            }
        }
    }

    private void setTextBgTexture(String str) {
        int childCount = this.txtStickerRel.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.txtStickerRel.getChildAt(i);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    if (this.textBGOpacity.getProgress() == 0) {
                        this.textBGOpacity.setProgress(127);
                    }
                    autofitTextRel.setBgDrawable(str);
                    autofitTextRel.setBgAlpha(this.textBGOpacity.getProgress());
                    this.bgColor = 0;
                    ((AutofitTextRel) this.txtStickerRel.getChildAt(i)).getTextInfo().setBG_DRAWABLE(str);
                    this.bgDrawable = autofitTextRel.getBgDrawable();
                    this.bgAlpha = this.textBGOpacity.getProgress();
                }
            }
        }
    }

    private void updateBgColor(String str) {
        int childCount = this.txtStickerRel.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.txtStickerRel.getChildAt(i);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    if (this.textBGOpacity.getProgress() == 0) {
                        this.textBGOpacity.setProgress(127);
                    }
                    autofitTextRel.setBgAlpha(this.textBGOpacity.getProgress());
                    autofitTextRel.setBgColor(Color.parseColor(str));
                    this.bgColor = Color.parseColor(str);
                    this.bgDrawable = "0";
                }
            }
        }
    }

    private void setGravityText(String str) {
        int childCount = this.txtStickerRel.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.txtStickerRel.getChildAt(i);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    autofitTextRel.setTextGravity(str);
                    this.txtGravity = str;
                }
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void setCharSpacing(float f) {
        int childCount = this.txtStickerRel.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.txtStickerRel.getChildAt(i);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    autofitTextRel.setCharSpacing(f);
                    this.txtCharSpacing = f;
                }
            }
        }
    }

    private void setLineSpacing(float f) {
        int childCount = this.txtStickerRel.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.txtStickerRel.getChildAt(i);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    autofitTextRel.setLineSpacing(f);
                    this.txtLineSpacing = f;
                }
            }
        }
    }

    private void setTextOpacity(int i) {
        this.process = i;
        int childCount = this.txtStickerRel.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = this.txtStickerRel.getChildAt(i2);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    autofitTextRel.setTextAlpha(i);
                }
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    private void setTextCopy() {
        int childCount = this.txtStickerRel.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.txtStickerRel.getChildAt(i);
            if (childAt instanceof AutofitTextRel) {
                AutofitTextRel autofitTextRel = (AutofitTextRel) childAt;
                if (autofitTextRel.getBorderVisibility()) {
                    AutofitTextRel autofitTextRel2 = new AutofitTextRel(this);
                    this.resizableStickerView = autofitTextRel2;
                    this.txtStickerRel.addView(autofitTextRel2);
                    ((AutofitTextRel) this.resizableStickerView).setMainLayoutWH((float) this.frame.getWidth(), (float) this.frame.getHeight());
                    removeImageViewController();
                    removeWatermarkImageViewController();
                    ((AutofitTextRel) this.resizableStickerView).setTextInfo(autofitTextRel.getTextInfo(), false);
                    this.resizableStickerView.setId(View.generateViewId());
                    ((AutofitTextRel) this.resizableStickerView).setOnTouchCallbackListener(this);
                    ((AutofitTextRel) this.resizableStickerView).setBorderVisibility(true);
                }
            }
        }
    }

    private void touchUp(View view) {
        if (this.layContainer.getVisibility() == View.VISIBLE) {
            this.layContainer.setVisibility(View.GONE);
        }
        if (view instanceof AutofitTextRel) {
            int i = this.process;
            if (i != 0) {
                this.seekOpacity.setProgress(i);
            }
        }
        if (this.guideline.getVisibility() == View.VISIBLE) {
            this.guideline.setVisibility(View.GONE);
        }
    }

    private void touchDown(View view, String str) {
        if (this.layContainer.getVisibility() == View.VISIBLE) {
            this.layContainer.setVisibility(View.GONE);
        }
        pieceUnSelect();
        this.focusedView = view;
        if (str.equals("hide border")) {
            removeImageViewController();
            removeWatermarkImageViewController();
        }
        if (view instanceof ResizableStickerView) {
            this.imgTextBack.performClick();
            hideLayoutView(false);
            hideRatioView(false);
            hideFilterView(false);
            hideAdjustView(false);
            hideMusicView(false);
            borderBottomSheetState(false);
            bgBottomSheetState(false);
            drawBottomSheetState(false);
            singleImageOptionShow(false);
            singleVideoOptionShow(false);
            this.stkrColorSet = ((ResizableStickerView) view).getColor();
        }
        if (view instanceof AutofitTextRel) {
            hideLayoutView(false);
            hideRatioView(false);
            hideFilterView(false);
            hideAdjustView(false);
            hideMusicView(false);
            borderBottomSheetState(false);
            bgBottomSheetState(false);
            hideOrShowTextOption(true);
            drawBottomSheetState(false);
            AutofitTextRel autofitTextRel = (AutofitTextRel) view;
            this.textColorSet = autofitTextRel.getTextColor();
            this.fontName = autofitTextRel.getFontName();
            this.tColor = autofitTextRel.getTextColor();
            this.borderColor = autofitTextRel.getTextBorderColor();
            this.shadowColor = autofitTextRel.getTextShadowColor();
            this.shadowProg = autofitTextRel.getTextShadowProg();
            this.shadowXYProg = autofitTextRel.getTextShadowXY();
            this.tAlpha = autofitTextRel.getTextAlpha();
            this.bgDrawable = autofitTextRel.getBgDrawable();
            this.bgAlpha = autofitTextRel.getBgAlpha();
            this.bgColor = autofitTextRel.getBgColor();
            this.txtGravity = autofitTextRel.getTextGravity();
            this.txtCharSpacing = autofitTextRel.getCharSpacing();
            this.txtLineSpacing = autofitTextRel.getLineSpacing();
            this.seekOpacity.setProgress(this.tAlpha);
            this.seekBarShadowBlur.setProgress(this.shadowProg);
            this.seekBarXYPos.setProgress(this.shadowXYProg);
            this.textBGOpacity.setProgress(this.bgAlpha);
        }
        if (this.guideline.getVisibility() == View.GONE) {
            this.guideline.setVisibility(View.VISIBLE);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    public void onGetSticker(Bitmap bitmap) {
        try {
            color_Type = "colored";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                addSticker("0", Constants.saveBitmapObjectSticker(bitmap));
            }
        } catch (Error | Exception e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("onGetSticker  catch ");
            stringBuilder.append(e.toString());
            Log.e("TAG", stringBuilder.toString());
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    private void addSticker(String str, String str2) {
        ComponentInfo componentInfo = new ComponentInfo();
        componentInfo.setPOS_X((float) ((this.frame.getWidth() / 2) - ImageUtils.dpToPx(this, 100)));
        componentInfo.setPOS_Y((float) ((this.frame.getHeight() / 2) - ImageUtils.dpToPx(this, 100)));
        componentInfo.setWIDTH(ImageUtils.dpToPx(this, Callback.DEFAULT_DRAG_ANIMATION_DURATION));
        componentInfo.setHEIGHT(ImageUtils.dpToPx(this, Callback.DEFAULT_DRAG_ANIMATION_DURATION));
        componentInfo.setROTATION(0.0f);
        componentInfo.setRES_ID(str);
        componentInfo.setBITMAP(null);
        componentInfo.setCOLORTYPE(this.color_Type);
        componentInfo.setTYPE("STICKER");
        componentInfo.setSTC_OPACITY(100);
        componentInfo.setSTC_COLOR(0);
        componentInfo.setSTKR_PATH(str2);
        componentInfo.setFIELD_TWO("0,0");
        componentInfo.setXRotateProg(45);
        componentInfo.setYRotateProg(45);
        componentInfo.setZRotateProg(SubSamplingScaleImageView.ORIENTATION_180);
        componentInfo.setScaleProg(10);
        ResizableStickerView resizableStickerView = new ResizableStickerView(this, "sticker");
        resizableStickerView.setOnTouchCallbackListener(this);
        resizableStickerView.optimizeScreen(this.screenWidth, this.screenHeight);
        resizableStickerView.setComponentInfo(componentInfo);
        resizableStickerView.setId(View.generateViewId());
        resizableStickerView.setMainLayoutWH((float) this.frame.getWidth(), (float) this.frame.getHeight());
        this.txtStickerRel.addView(resizableStickerView);
        resizableStickerView.setWatermarkVisibility(false);
        resizableStickerView.setBorderVisibility(true);
    }

    private void setDrawable() {
        this.color_Type = "colored";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            addSticker(mDrawableName, "");
        }
    }
}
