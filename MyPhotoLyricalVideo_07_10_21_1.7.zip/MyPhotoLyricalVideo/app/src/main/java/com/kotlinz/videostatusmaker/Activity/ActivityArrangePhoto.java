package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration.Builder;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import com.kotlinz.videostatusmaker.Utils.FastBlur;
import com.kotlinz.videostatusmaker.Utils.gridview.DynamicGridView;
import com.kotlinz.videostatusmaker.Utils.gridview.DynamicGridView.OnDragListener;
import com.kotlinz.videostatusmaker.Utils.gridview.DynamicGridView.OnDropListener;
import com.kotlinz.videostatusmaker.adapter.GalleryAdapter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ActivityArrangePhoto extends Activity {
    ArrayList<String> saveArray = new ArrayList();
    List<Object> temp;
    TextView title;
    int width;
    public static Activity activity;
    public Activity MyActivity = ActivityArrangePhoto.this;
    public static ProgressDialog progressDialog;
    GalleryAdapter galleryAdapter;
    DynamicGridView dynamicGridView;
    ImageView ivBack;
    ImageView ivCrop;
    TextView tvDone;
    String strFolderName;
    int height;
    ImageLoader imageLoader;
    File[] listFile = null;
    ArrayList<String> arrayListPhoto = new ArrayList();
    ImageView ivRegular;
    Typeface typeface;

    GGAdview gg_banner;


    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.arrenge_list);
        initImageLoader();
        this.width = getResources().getDisplayMetrics().widthPixels;
        this.height = getResources().getDisplayMetrics().heightPixels;
        getWindow().addFlags(1024);
        activity = this;
        GalleryAdapter.st = "r";
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        BannerAds();
        this.strFolderName = getResources().getString(R.string.app_name);
        this.ivCrop = findViewById(R.id.c_crop);
        this.ivRegular = findViewById(R.id.regular);
        this.title = findViewById(R.id.title);
        this.title.setTextSize(18.0f);
        this.ivBack = findViewById(R.id.back);
        this.tvDone = findViewById(R.id.done);
        this.typeface = Typeface.createFromAsset(getAssets(), "Montserrat-Regular_0.otf");
        this.title.setTypeface(this.typeface);
        PutAnalyticsEvent();
        this.dynamicGridView = findViewById(R.id.arrange_grid);
        this.ivBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.interstitialAd != null && MyApplication.interstitialAd.isAdLoaded()) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 8;
                        MyApplication.interstitialAd.show();
                        MyApplication.isShowAd = 1;
                    } else {
                        onBackPressed();
                    }
                }
            }
        });
        this.tvDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.isShowAd == 1) {
                    new CreateVideo().execute();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.interstitialAd != null && MyApplication.interstitialAd.isAdLoaded()) {
                        MyApplication.activity = MyActivity;
                        MyApplication.AdsId = 1;
                        MyApplication.interstitialAd.show();
                        MyApplication.isShowAd = 1;
                        new CreateVideoFroShowAds().execute();
                    } else {
                        new CreateVideo().execute();
                    }
                }

            }
        });
        getFromSdcard();
        this.galleryAdapter = new GalleryAdapter(this, this.arrayListPhoto, 2);
        this.dynamicGridView.setAdapter(this.galleryAdapter);
        this.dynamicGridView.setOnItemLongClickListener(new OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                ActivityArrangePhoto.this.dynamicGridView.startEditMode(i);
                return true;
            }
        });
        this.dynamicGridView.setOnDragListener(new OnDragListener() {
            @Override
            public void onDragStarted(int position) {

            }

            @Override
            public void onDragPositionsChanged(int i, int i2) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(i);
                Log.e("Old pos : ", stringBuilder.toString());
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("");
                stringBuilder2.append(i2);
                Log.e("New pos : ", stringBuilder2.toString());
            }
        });
        this.ivRegular.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                GalleryAdapter.st = "r";
                ActivityArrangePhoto.this.galleryAdapter.notifyDataSetChanged();
            }
        });
        this.ivCrop.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                GalleryAdapter.st = "c";
                ActivityArrangePhoto.this.galleryAdapter.notifyDataSetChanged();
            }
        });
        this.dynamicGridView.setOnDropListener(new OnDropListener() {
            @Override
            public void onActionDrop() {
                ActivityArrangePhoto.this.dynamicGridView.stopEditMode();
            }
        });
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.getResources().getDisplayMetrics().heightPixels;
        final int n = widthPixels * 70 / 1080;
        final int n2 = heightPixels * 70 / 1920;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(n, n2);
        layoutParams.addRule(15);
        final int n3 = widthPixels * 40 / 1080;
        layoutParams.setMargins(n3, 0, 0, 0);
        final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(n, n2);
        layoutParams2.addRule(15);
        layoutParams2.addRule(11);
        layoutParams2.setMargins(0, 0, n3, 0);
        final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams(widthPixels * 350 / 1080, heightPixels * 101 / 1920);
        relativeLayout$LayoutParams.addRule(13);
        this.ivRegular.setLayoutParams(relativeLayout$LayoutParams);
        this.ivCrop.setLayoutParams(relativeLayout$LayoutParams);
    }

    private void BannerAds() {
        gg_banner = findViewById(R.id.ggAdView_banner);
        gg_banner.setUnitId(getResources().getString(R.string.BannerAd));
        gg_banner.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityArrangePhoto");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public void getFromSdcard() {
        File externalStorageDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.strFolderName);
        stringBuilder.append("/");
        stringBuilder.append(getString(R.string.temp_folder));
        File file = new File(externalStorageDirectory, stringBuilder.toString());
        if (file.isDirectory()) {
            this.listFile = file.listFiles();
            int i = 0;
            for (int i2 = 0; i2 < this.listFile.length; i2++) {
                if (this.listFile[i2].getName().contains("zim")) {
                    this.arrayListPhoto.add(this.listFile[i2].getAbsolutePath());
                    ArrayList arrayList = this.saveArray;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(file.getAbsolutePath());
                    stringBuilder2.append("/d");
                    i++;
                    stringBuilder2.append(i);
                    stringBuilder2.append(".jpg");
                    arrayList.add(stringBuilder2.toString());
                }
            }
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }


    public class CreateVideo extends AsyncTask<String, String, String> {
        protected String doInBackground(final String... array) {
            final boolean equals = GalleryAdapter.st.equals("r");
            int i = 1;
            if (equals) {
                while (i <= ActivityArrangePhoto.this.arrayListPhoto.size()) {
                    ActivityArrangePhoto.this.Save(ActivityArrangePhoto.this.bitmapResize(ActivityArrangePhoto.this.createSquaredBitmap(BitmapFactory.decodeFile(ActivityArrangePhoto.this.arrayListPhoto.get(i - 1))), ActivityArrangePhoto.this.width), i);
                    ++i;
                }
            } else {
                for (int j = 1; j <= ActivityArrangePhoto.this.arrayListPhoto.size(); ++j) {
                    final Bitmap decodeFile = BitmapFactory.decodeFile(ActivityArrangePhoto.this.arrayListPhoto.get(j - 1));
                    Bitmap bitmap;
                    if (MainActivity.anInt == 1) {
                        bitmap = ActivityArrangePhoto.this.scaleCenterCrop(decodeFile, ActivityArrangePhoto.this.height, ActivityArrangePhoto.this.width);
                    } else {
                        bitmap = ActivityArrangePhoto.this.scaleCenterCrop(decodeFile, ActivityArrangePhoto.this.width, ActivityArrangePhoto.this.width);
                    }
                    ActivityArrangePhoto.this.Save(bitmap, j);
                }
            }
            return null;
        }

        protected void onPostExecute(final String s) {
            super.onPostExecute(s);
        }

        protected void onPreExecute() {
            ActivityArrangePhoto.progressDialog.show();
            super.onPreExecute();
        }
    }

    public Bitmap scaleCenterCrop(final Bitmap bitmap, final int n, final int n2) {
        final int width = bitmap.getWidth();
        final int height = bitmap.getHeight();
        final float n3 = n2;
        final float n4 = width;
        final float n5 = n3 / n4;
        final float n6 = n;
        final float n7 = height;
        final float max = Math.max(n5, n6 / n7);
        final float n8 = n4 * max;
        final float n9 = max * n7;
        final float n10 = (n3 - n8) / 2.0f;
        final float n11 = (n6 - n9) / 2.0f;
        final RectF rectF = new RectF(n10, n11, n8 + n10, n9 + n11);
        final Bitmap bitmap2 = Bitmap.createBitmap(n2, n, bitmap.getConfig());
        new Canvas(bitmap2).drawBitmap(bitmap, null, rectF, null);
        return bitmap2;
    }

    private Bitmap createSquaredBitmap(Bitmap bitmap) {
        if (MainActivity.anInt == 1) {
            return ConvetrSameSizeNew(this, bitmap, scaleCenterCropblur(bitmap, this.width, this.height), this.width, this.height);
        }
        return ConvetrSameSizeNew(this, bitmap, scaleCenterCropblur(bitmap, this.width, this.width), this.width, this.width);
    }

    public void Save(final Bitmap bitmap, int i) {
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
        sb.append("/");
        sb.append(this.getResources().getString(R.string.app_name));
        final String string = sb.toString();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("f");
        sb2.append(i);
        sb2.append(".jpg");
        final String string2 = sb2.toString();
        final StringBuilder sb3 = new StringBuilder();
        sb3.append(string);
        sb3.append(File.separator);
        sb3.append(this.getString(R.string.temp_folder));
        final File file = new File(sb3.toString());
        file.mkdirs();
        final File file2 = new File(file, string2);
        if (file2.exists()) {
            file2.delete();
        }
        try {
            final FileOutputStream fileOutputStream = new FileOutputStream(file2);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            if (i == 0) {
                new File(file2.getAbsolutePath()).renameTo(new File(file2.getAbsolutePath().replace("f", "d")));
            }
            if (i == this.arrayListPhoto.size() + 1) {
                new File(file2.getAbsolutePath()).renameTo(new File(file2.getAbsolutePath().replace("f", "d")));
            }
            if (i == arrayListPhoto.size()) {
                try {
                    this.temp = this.galleryAdapter.getItems();
                    for (i = 0; i < this.temp.size(); ++i) {
                        new File(this.temp.get(i).toString().replace("zim", "f")).renameTo(new File(this.saveArray.get(i)));
                    }
                } catch (Exception ex) {
                    ex.toString();
                }
                ActivityArrangePhoto.progressDialog.dismiss();
                startActivity(new Intent(this.getApplicationContext(), ActivitySelectLyrics.class));
                return;
            }
            return;
        } catch (Exception ex2) {
            ex2.printStackTrace();
        }
    }

    public class CreateVideoFroShowAds extends AsyncTask<String, String, String> {
        protected String doInBackground(final String... array) {
            final boolean equals = GalleryAdapter.st.equals("r");
            int i = 1;
            if (equals) {
                while (i <= ActivityArrangePhoto.this.arrayListPhoto.size()) {
                    ActivityArrangePhoto.this.SaveForAdsShow(ActivityArrangePhoto.this.bitmapResize(ActivityArrangePhoto.this.createSquaredBitmap(BitmapFactory.decodeFile(ActivityArrangePhoto.this.arrayListPhoto.get(i - 1))), ActivityArrangePhoto.this.width), i);
                    ++i;
                }
            } else {
                for (int j = 1; j <= ActivityArrangePhoto.this.arrayListPhoto.size(); ++j) {
                    final Bitmap decodeFile = BitmapFactory.decodeFile(ActivityArrangePhoto.this.arrayListPhoto.get(j - 1));
                    Bitmap bitmap;
                    if (MainActivity.anInt == 1) {
                        bitmap = ActivityArrangePhoto.this.scaleCenterCrop(decodeFile, ActivityArrangePhoto.this.height, ActivityArrangePhoto.this.width);
                    } else {
                        bitmap = ActivityArrangePhoto.this.scaleCenterCrop(decodeFile, ActivityArrangePhoto.this.width, ActivityArrangePhoto.this.width);
                    }
                    ActivityArrangePhoto.this.SaveForAdsShow(bitmap, j);
                }
            }
            return null;
        }

        protected void onPostExecute(final String s) {
            super.onPostExecute(s);
        }

        protected void onPreExecute() {
            ActivityArrangePhoto.progressDialog.show();
            super.onPreExecute();
        }
    }

    public void SaveForAdsShow(final Bitmap bitmap, int i) {
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
        sb.append("/");
        sb.append(this.getResources().getString(R.string.app_name));
        final String string = sb.toString();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("f");
        sb2.append(i);
        sb2.append(".jpg");
        final String string2 = sb2.toString();
        final StringBuilder sb3 = new StringBuilder();
        sb3.append(string);
        sb3.append(File.separator);
        sb3.append(this.getString(R.string.temp_folder));
        final File file = new File(sb3.toString());
        file.mkdirs();
        final File file2 = new File(file, string2);
        if (file2.exists()) {
            file2.delete();
        }
        try {
            final FileOutputStream fileOutputStream = new FileOutputStream(file2);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            if (i == 0) {
                new File(file2.getAbsolutePath()).renameTo(new File(file2.getAbsolutePath().replace("f", "d")));
            }
            if (i == this.arrayListPhoto.size() + 1) {
                new File(file2.getAbsolutePath()).renameTo(new File(file2.getAbsolutePath().replace("f", "d")));
            }
            if (i == arrayListPhoto.size()) {
                try {
                    this.temp = this.galleryAdapter.getItems();
                    for (i = 0; i < this.temp.size(); ++i) {
                        new File(this.temp.get(i).toString().replace("zim", "f")).renameTo(new File(this.saveArray.get(i)));
                    }
                } catch (Exception ex) {
                    ex.toString();
                }
                ActivityArrangePhoto.progressDialog.dismiss();
                return;
            }
            return;
        } catch (Exception ex2) {
            ex2.printStackTrace();
        }
    }

    public Bitmap bitmapResize(Bitmap bitmap, int i) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        if (width >= height) {
            width = (height * i) / width;
            if (width > i) {
                width = (i * i) / width;
            }
            return Bitmap.createScaledBitmap(bitmap, i, width, true);
        }
        width = (width * i) / height;
        if (width > i) {
            width = (i * i) / width;
            return Bitmap.createScaledBitmap(bitmap, i, width, true);
        }
        int i2 = width;
        width = i;
        i = i2;
        return Bitmap.createScaledBitmap(bitmap, i, width, true);
    }

    public static Bitmap ConvetrSameSizeNew(final Context context, final Bitmap bitmap, final Bitmap bitmap2, final int n, final int n2) {
        final Bitmap doBlur = FastBlur.doBlur(context, bitmap2, 25, true);
        final Canvas canvas = new Canvas(doBlur);
        final Paint paint = new Paint();
        final float n3 = bitmap.getWidth();
        final float n4 = bitmap.getHeight();
        final float n5 = n;
        float n6 = n5 / n3;
        final float n7 = n2;
        final float n8 = n7 / n4;
        float n9 = (n7 - n4 * n6) / 2.0f;
        float n12;
        if (n9 < 0.0f) {
            final float n10 = (n5 - n3 * n8) / 2.0f;
            n6 = n8;
            final float n11 = 0.0f;
            n12 = n10;
            n9 = n11;
        } else {
            n12 = 0.0f;
        }
        final Matrix matrix = new Matrix();
        matrix.postTranslate(n12, n9);
        matrix.preScale(n6, n6);
        canvas.drawBitmap(bitmap, matrix, paint);
        return doBlur;
    }

    public static Bitmap scaleCenterCropblur(final Bitmap bitmap, final int n, final int n2) {
        final int width = bitmap.getWidth();
        final int height = bitmap.getHeight();
        if (width == n && height == n2) {
            return bitmap;
        }
        final float n3 = n;
        final float n4 = width;
        final float n5 = n2;
        final float n6 = height;
        final float max = Math.max(n3 / n4, n5 / n6);
        final float n7 = n4 * max;
        final float n8 = max * n6;
        final float n9 = (n3 - n7) / 2.0f;
        final float n10 = (n5 - n8) / 2.0f;
        final RectF rectF = new RectF(n9, n10, n7 + n9, n8 + n10);
        final Bitmap bitmap2 = Bitmap.createBitmap(n, n2, bitmap.getConfig());
        new Canvas(bitmap2).drawBitmap(bitmap, null, rectF, null);
        return bitmap2;
    }

    private void initImageLoader() {
        this.imageLoader = ImageLoader.getInstance();
        this.imageLoader.init(new Builder(this).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).build()).build());
    }
}
