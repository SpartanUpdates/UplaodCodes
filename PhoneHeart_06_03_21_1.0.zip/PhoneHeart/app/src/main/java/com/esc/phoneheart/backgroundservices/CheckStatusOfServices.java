package com.esc.phoneheart.backgroundservices;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import com.esc.phoneheart.pref.SharedPrefUtil;

public class CheckStatusOfServices extends IntentService {
    public CheckStatusOfServices(String str) {
        super(str);
    }

    public void onHandleIntent(Intent intent) {
        Log.d("TIMMMMM1", "calllled");
        new SharedPrefUtil(getBaseContext()).saveBoolean(SharedPrefUtil.RETEN_TRACKED, true);
    }

    public CheckStatusOfServices() {
        super("CheckStatusOfServices");
    }
}
