package com.kotlinz.videoeditor.videorotate;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore.Images.Media;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.bumptech.glide.Glide;
import com.edmodo.cropper.CropImageView;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.Utils.UtilCommand;
import com.kotlinz.videoeditor.activity.TrimVideoPrivewActivity;
import com.kotlinz.videoeditor.view.VideoPlayerState;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar;
import com.kotlinz.videoeditor.editvideo.activity.EditActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.text.ParseException;
import java.util.concurrent.TimeUnit;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.kotlinz.videoeditor.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

@SuppressLint({"NewApi", "ResourceType"})
public class VideoRotateActivity extends AppCompatActivity {

    Activity activity = VideoRotateActivity.this;
    static final boolean H = true;
    private ImageView ivThumbnail;
    OnClickListener E = new OnClickListener() {
        @Override
        public void onClick(View view) {
            if (VideoRotateActivity.this.o.booleanValue()) {
                VideoRotateActivity.this.a.setBackgroundResource(R.drawable.ic_play_upress);
                VideoRotateActivity.this.o = Boolean.valueOf(false);
            } else {
                VideoRotateActivity.this.a.setBackgroundResource(R.drawable.ic_pause_unpresss);
                VideoRotateActivity.this.o = Boolean.valueOf(VideoRotateActivity.H);
            }
            VideoRotateActivity.this.e();
        }
    };
    Runnable F = new Runnable() {
        @SuppressLint({"SetTextI18n"})
        public void run() {
            if (VideoRotateActivity.this.videoView.isPlaying()) {
                int currentPosition = VideoRotateActivity.this.videoView.getCurrentPosition();
                VideoRotateActivity.this.p.setProgress(currentPosition);
                try {
                    TextView textView = VideoRotateActivity.this.r;
                    StringBuilder sb = new StringBuilder();
                    sb.append("");
                    sb.append(VideoRotateActivity.formatTimeUnit(currentPosition));
                    textView.setText(sb.toString());
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (currentPosition == VideoRotateActivity.this.b) {
                    VideoRotateActivity.this.p.setProgress(0);
                    VideoRotateActivity.this.r.setText("00:00");
                    VideoRotateActivity.this.l.removeCallbacks(VideoRotateActivity.this.F);
                    return;
                }
                VideoRotateActivity.this.l.postDelayed(VideoRotateActivity.this.F, 500);
                return;
            }
            VideoRotateActivity.this.p.setProgress(VideoRotateActivity.this.b);
            try {
                TextView textView2 = VideoRotateActivity.this.r;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("");
                sb2.append(VideoRotateActivity.formatTimeUnit(VideoRotateActivity.this.b));
                textView2.setText(sb2.toString());
            } catch (ParseException e2) {
                e2.printStackTrace();
            }
            VideoRotateActivity.this.l.removeCallbacks(VideoRotateActivity.this.F);
        }
    };
    Runnable G = new Runnable() {
        public void run() {
            VideoRotateActivity.this.k.removeCallbacks(VideoRotateActivity.this.G);

        }
    };

    public VideoPlayerState I = new VideoPlayerState();
    private final a J = new a();
    ImageView a;
    int b = 0;
    int c = 0;
    int d = 0;
    String e;
    String f;
    String Rotation = "";
    String h = "00";
    String i;
    String j = "";
    Handler k = new Handler();
    Handler l = new Handler();
    boolean m = false;
    Context n;
    Boolean o = Boolean.valueOf(false);
    SeekBar p;
    TextView q;
    TextView r;
    VideoSliceSeekBar t;
    VideoView videoView;
    ImageView ivRotate180;
    ImageView ivRotate90;


    CropImageView cropperView;

    ImageView ivback, ivDone;
    TextView tvToolbarName;

    private NativeAd nativeAd;

    private class a extends Handler {
        private boolean b;
        private final Runnable c;

        private a() {
            this.b = false;
            this.c = new Runnable() {
                public void run() {
                    VideoRotateActivity.a.this.a();
                }
            };
        }


        public void a() {
            if (!this.b) {
                this.b = VideoRotateActivity.H;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            this.b = false;
            VideoRotateActivity.this.t.videoPlayingProgress(VideoRotateActivity.this.videoView.getCurrentPosition());
            if (!VideoRotateActivity.this.videoView.isPlaying() || VideoRotateActivity.this.videoView.getCurrentPosition() >= VideoRotateActivity.this.t.getRightProgress()) {
                if (VideoRotateActivity.this.videoView.isPlaying()) {
                    VideoRotateActivity.this.videoView.pause();
                    VideoRotateActivity.this.a.setBackgroundResource(R.drawable.ic_play_upress);
                    VideoRotateActivity.this.o = Boolean.valueOf(false);
                }
                VideoRotateActivity.this.t.setSliceBlocked(false);
                VideoRotateActivity.this.t.removeVideoStatusThumb();
                return;
            }
            postDelayed(this.c, 50);
        }
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.videorotateactivity);
        PutAnalyticsEvent();
        LoadNativeAds();
        Intent intent = getIntent();
        this.n = this;
        this.j = intent.getStringExtra("videoPath");
        this.t = findViewById(R.id.sbVideo);
        this.videoView = findViewById(R.id.vvScreen);
        this.ivThumbnail = findViewById(R.id.iv_thumbnail);
        this.r = findViewById(R.id.tvStartVideo);
        this.q = findViewById(R.id.tvEndVideo);
        this.f = this.j.substring(this.j.lastIndexOf(".") + 1);
        MediaScannerConnection.scanFile(this, new String[]{new File(this.j).getAbsolutePath()}, new String[]{this.f}, null);
        d();
        cropperView = findViewById(R.id.cropperView);
        ivback = findViewById(R.id.iv_back);
        ivDone = findViewById(R.id.iv_done);
        tvToolbarName = findViewById(R.id.tv_app_name);
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (videoView != null && videoView.isPlaying()) {
                    videoView.pause();
                }
                if (!Rotation.equals("")) {
                    if (MyApplication.isShowAd == 1) {
                        GoToPreview();
                        MyApplication.isShowAd = 0;
                    } else {
                        if (MyApplication.mInterstitialAd != null) {
                            MyApplication.activity = activity;
                            MyApplication.AdsId = 10;
                            MyApplication.mInterstitialAd.show(activity);
                            MyApplication.isShowAd = 1;

                        } else {
                            GoToPreview();
                        }
                    }
                } else {
                    Toast.makeText(activity, "Please Select At least One Rotation First", Toast.LENGTH_SHORT).show();
                }
            }
        });
        this.a = findViewById(R.id.btnPlayVideo);
        this.a.setOnClickListener(this.E);
        ivRotate90 = findViewById(R.id.iv_rotate90);
        ivRotate180 = findViewById(R.id.iv_rotate180);
        ivRotate90.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (videoView != null && videoView.isPlaying()) {
                    videoView.pause();
                }
                Rotation = "90";
                rotatecommand(true);
            }
        });
        ivRotate180.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (videoView != null && videoView.isPlaying()) {
                    videoView.pause();
                }
                cropperView.setAspectRatio(8, 16);
                Rotation = "180";
                rotatecommand(true);
            }
        });
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoRotateActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (VideoRotateActivity.this.nativeAd != null) {
                            VideoRotateActivity.this.nativeAd.destroy();
                        }
                        VideoRotateActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void GoToPreview() {
        Intent intent = new Intent(activity, TrimVideoPrivewActivity.class);
        intent.putExtra("videofilename", i);
        startActivity(intent);
        finish();
    }

    public void rotatecommand(boolean IsPreview) {
        String valueOf = String.valueOf(this.I.getStart() / 1000);
        String valueOf2 = String.valueOf(this.I.getDuration() / 1000);
        Log.e("start", valueOf);
        Log.e("end", valueOf2);
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb.append("/");
        sb.append(getResources().getString(R.string.MainFolderName));
        sb.append("/");
        sb.append(getResources().getString(R.string.VideoRotate));
        File file = new File(sb.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb2.append("/");
        sb2.append(getResources().getString(R.string.MainFolderName));
        sb2.append("/");
        sb2.append(getResources().getString(R.string.VideoRotate));
        sb2.append("/");
        sb2.append(System.currentTimeMillis());
        sb2.append(".mp4");
        i = sb2.toString();
        MyApplication.getInstance().VideoFileNameRotate = i;
        StringBuilder sb3 = new StringBuilder();
        sb3.append("rotate=");
        sb3.append(Rotation);
        sb3.append("*PI/180");
        a(IsPreview, new String[]{"-y", "-ss", valueOf, "-t", valueOf2, "-i", this.j, "-filter_complex", "transpose=1", "-c:a", "copy", this.i}, this.i);
    }

    private void a(boolean IsPreview, String[] strArr, final String str) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();
        String ffmpegCommand = UtilCommand.main(strArr);
        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {

            @Override
            public void apply(final long executionId, final int returnCode) {
                progressDialog.dismiss();
                if (returnCode == RETURN_CODE_SUCCESS) {
                    progressDialog.dismiss();
                    if (IsPreview) {
                        videoView.setVideoPath(i);
                        videoView.start();
                    } else {
                        GoToPreview();
                        refreshGallery(str);
                    }

                } else if (returnCode == RETURN_CODE_CANCEL) {
                    try {
                        new File(str).delete();
                        VideoRotateActivity.this.deleteFromGallery(str);
                        Toast.makeText(VideoRotateActivity.this.getApplicationContext(), "Error Creating Video", 0).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                } else {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Toast.makeText(VideoRotateActivity.this.getApplicationContext(), "Error Creating Video", 0).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }
            }
        });
        getWindow().clearFlags(16);
    }

    private void d() {
        Glide.with(activity).asBitmap().load((j)).into(ivThumbnail);
        videoView.setVideoURI(Uri.parse(j));
        videoView.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                a.setBackgroundResource(R.drawable.play2);
                o = Boolean.valueOf(false);
            }
        });

        this.videoView.setOnErrorListener(new OnErrorListener() {
            public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                Toast.makeText(activity, "Video Player Not Supporting", Toast.LENGTH_SHORT).show();
                m = false;
                return H;
            }
        });

        this.videoView.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                VideoRotateActivity.this.t.setSeekBarChangeListener(new VideoSliceSeekBar.SeekBarChangeListener() {
                    public void SeekBarValueChanged(int i, int i2) {
                        if (VideoRotateActivity.this.t.getSelectedThumb() == 1) {
                            VideoRotateActivity.this.videoView.seekTo(VideoRotateActivity.this.t.getLeftProgress());
                        }
                        VideoRotateActivity.this.r.setText(VideoRotateActivity.getTimeForTrackFormat(i, VideoRotateActivity.H));
                        VideoRotateActivity.this.q.setText(VideoRotateActivity.getTimeForTrackFormat(i2, VideoRotateActivity.H));
                        VideoRotateActivity.this.h = VideoRotateActivity.getTimeForTrackFormat(i, VideoRotateActivity.H);
                        VideoRotateActivity.this.I.setStart(i);
                        VideoRotateActivity.this.e = VideoRotateActivity.getTimeForTrackFormat(i2, VideoRotateActivity.H);
                        VideoRotateActivity.this.I.setStop(i2);
                        VideoRotateActivity.this.d = i;
                        VideoRotateActivity.this.c = i2;
                    }
                });
                VideoRotateActivity.this.e = VideoRotateActivity.getTimeForTrackFormat(mediaPlayer.getDuration(), VideoRotateActivity.H);
                VideoRotateActivity.this.t.setMaxValue(mediaPlayer.getDuration());
                VideoRotateActivity.this.t.setLeftProgress(0);
                VideoRotateActivity.this.t.setRightProgress(mediaPlayer.getDuration());
                VideoRotateActivity.this.t.setProgressMinDiff(0);
                VideoRotateActivity.this.a.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        videoView.setVisibility(View.VISIBLE);
                        ivThumbnail.setVisibility(View.INVISIBLE);
                        if (VideoRotateActivity.this.o.booleanValue()) {
                            VideoRotateActivity.this.a.setBackgroundResource(R.drawable.ic_play_upress);
                            VideoRotateActivity.this.o = Boolean.valueOf(false);
                        } else {
                            VideoRotateActivity.this.a.setBackgroundResource(R.drawable.ic_pause_unpresss);
                            VideoRotateActivity.this.o = Boolean.valueOf(VideoRotateActivity.H);
                        }
                        VideoRotateActivity.this.e();
                    }
                });
            }
        });
        this.e = getTimeForTrackFormat(this.videoView.getDuration(), H);
    }


    public void e() {
        if (this.videoView.isPlaying()) {
            this.videoView.pause();
            this.t.setSliceBlocked(false);
            this.t.removeVideoStatusThumb();
            return;
        }
        this.videoView.seekTo(this.t.getLeftProgress());
        this.videoView.start();
        this.a.setBackgroundResource(R.drawable.ic_pause_unpresss);
        this.t.videoPlayingProgress(this.t.getLeftProgress());
        this.J.a();
    }

    @SuppressLint({"DefaultLocale"})
    public static String formatTimeUnit(long j2) throws ParseException {
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }

    public static String getTimeForTrackFormat(int i2, boolean z2) {
        int i3 = i2 / 3600000;
        int i4 = i2 / 60000;
        int i5 = (i2 - ((i4 * 60) * 1000)) / 1000;
        String str = (!z2 || i3 >= 10) ? "" : "0";
        StringBuilder sb = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        sb2.append(str);
        sb2.append(i3);
        sb2.append(":");
        sb.append(sb2.toString());
        String str2 = (!z2 || i4 >= 10) ? "" : "0";
        StringBuilder sb3 = new StringBuilder();
        sb.append(str2);
        sb3.append(sb.toString());
        sb3.append(i4 % 60);
        sb3.append(":");
        String sb4 = sb3.toString();
        if (i5 < 10) {
            StringBuilder sb5 = new StringBuilder();
            sb5.append(sb4);
            sb5.append("0");
            sb5.append(i5);
            return sb5.toString();
        }
        StringBuilder sb6 = new StringBuilder();
        sb6.append(sb4);
        sb6.append(i5);
        return sb6.toString();
    }


    public void g() {
        new AlertDialog.Builder(this).setIcon(17301543).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                VideoRotateActivity.this.finish();
            }
        }).create().show();
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        File file = new File(j);
        MediaScannerConnection.scanFile(this, new String[]{file.getPath()},
                null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                    }
                });
        Intent intent = new Intent(getApplicationContext(), EditActivity.class);
        intent.putExtra("videofilename", j);
        startActivity(intent);
        finish();
    }

    @Override
    public void onDestroy() {
        getWindow().clearFlags(128);
        super.onDestroy();
    }
}
