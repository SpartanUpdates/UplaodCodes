package flash.light.shine.com.util;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import java.util.Arrays;
import java.util.EventListener;
import java.util.List;

public class RakeInstalledPackage {
    private Context context;
    private RakeInstalledPackageListener rakeInstalledPackageListener;

    private class MyThread extends Thread {

        class C01991 implements Runnable {
            C01991() {
            }

            public void run() {
                if (RakeInstalledPackage.this.rakeInstalledPackageListener != null) {
                    RakeInstalledPackage.this.rakeInstalledPackageListener.onStart();
                }
            }
        }

        class C02002 implements Runnable {
            private final PackageData[] val$list;

            C02002(PackageData[] packageDataArr) {
                this.val$list = packageDataArr;
            }

            public void run() {
                if (RakeInstalledPackage.this.rakeInstalledPackageListener != null) {
                    RakeInstalledPackage.this.rakeInstalledPackageListener.onComplete(this.val$list);
                }
            }
        }

        private MyThread() {
        }

        public void run() {
            super.run();
            ((Activity) RakeInstalledPackage.this.context).runOnUiThread(createActionStart());
            PackageManager packageManager = RakeInstalledPackage.this.context.getPackageManager();
            List installedPackages = packageManager.getInstalledPackages(128);
            int size = installedPackages.size();
            PackageData[] packageDataArr = new PackageData[size];
            for (int i = 0; i < size; i++) {
                PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
                boolean z = true;
                boolean z2 = (packageInfo.applicationInfo.flags & 1) == 0;
                if ((packageInfo.applicationInfo.flags & 262144) == 0) {
                    z = false;
                }
                packageDataArr[i] = new PackageData(packageInfo.packageName, packageInfo.applicationInfo.loadLabel(packageManager).toString(), z2, z);
            }
            Arrays.sort(packageDataArr);
            for (int i2 = 0; i2 < size; i2++) {
                Log.i("app", packageDataArr[i2].packageName);
            }
            ((Activity) RakeInstalledPackage.this.context).runOnUiThread(createActionComplete(packageDataArr));
        }

        private Runnable createActionStart() {
            return new C01991();
        }

        private Runnable createActionComplete(PackageData[] packageDataArr) {
            return new C02002(packageDataArr);
        }
    }

    public interface RakeInstalledPackageListener extends EventListener {
        void onComplete(PackageData[] packageDataArr);

        void onStart();
    }

    public RakeInstalledPackageListener getRakeInstalledPackageListener() {
        return this.rakeInstalledPackageListener;
    }

    public void setRakeInstalledPackageListener(RakeInstalledPackageListener rakeInstalledPackageListener) {
        this.rakeInstalledPackageListener = rakeInstalledPackageListener;
    }

    public RakeInstalledPackage(Activity activity) {
        this.context = activity;
    }

    public void rakeUp() {
        new MyThread().start();
    }
}
