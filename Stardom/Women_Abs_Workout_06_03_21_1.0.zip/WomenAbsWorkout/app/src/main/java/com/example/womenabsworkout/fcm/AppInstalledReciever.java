package com.example.womenabsworkout.fcm;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.example.womenabsworkout.utils.Constants;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.analytics.FirebaseAnalytics.Event;
import com.google.firebase.analytics.FirebaseAnalytics.Param;

public class AppInstalledReciever extends BroadcastReceiver {
    @SuppressLint("MissingPermission")
    public void onReceive(Context context, Intent intent) {
        String encodedSchemeSpecificPart = intent.getData().getEncodedSchemeSpecificPart();
        String string = context.getSharedPreferences(Constants.FCM_CROSS_PROMO_PREF, 0).getString("appPackageNameFromFCM", "");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("packageName outside if: ");
        stringBuilder.append(encodedSchemeSpecificPart);
        String str = "onReceive ";
        Log.i(str, stringBuilder.toString());
        try {
            StringBuilder stringBuilder2;
            if (encodedSchemeSpecificPart.equalsIgnoreCase(string)) {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("packageName inside if: ");
                stringBuilder2.append(encodedSchemeSpecificPart);
                Log.i(str, stringBuilder2.toString());
                Bundle bundle = new Bundle();
                bundle.putString(Param.ITEM_ID, encodedSchemeSpecificPart);
                String str2 = Param.ITEM_NAME;
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("installed-");
                stringBuilder3.append(encodedSchemeSpecificPart);
                bundle.putString(str2, stringBuilder3.toString());
                bundle.putString(Param.CONTENT_TYPE, "image");
                FirebaseAnalytics.getInstance(context).logEvent(Event.SELECT_CONTENT, bundle);
            }
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("packageName inside try: ");
            stringBuilder2.append(encodedSchemeSpecificPart);
            Log.i(str, stringBuilder2.toString());
            context.unregisterReceiver(this);
        } catch (Exception e) {
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append("packageName inside catch: ");
            stringBuilder4.append(e.getMessage());
            Log.i(str, stringBuilder4.toString());
            e.printStackTrace();
        }
    }
}
