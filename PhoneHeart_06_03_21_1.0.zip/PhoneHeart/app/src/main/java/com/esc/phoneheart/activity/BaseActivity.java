package com.esc.phoneheart.activity;

import android.annotation.SuppressLint;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;

import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.Util;

import java.util.ArrayList;
import java.util.regex.Pattern;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {
    public static DisplayMetrics displaymetrics;
    public Context k;
    public long lastClickedTime = 0;

    public void clearNotification(int[] iArr) {
        try {
            @SuppressLint("WrongConstant") NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
            if (notificationManager != null) {
                for (int cancel : iArr) {
                    notificationManager.cancel(cancel);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean doubleClicked() {
        long elapsedRealtime = SystemClock.elapsedRealtime() - this.lastClickedTime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("diff ");
        stringBuilder.append(elapsedRealtime);
        Log.e("TTTTTTTTT", stringBuilder.toString());
        this.lastClickedTime = SystemClock.elapsedRealtime();
        return elapsedRealtime < 600;
    }

    public ArrayList getIgnoredData() {
        try {
            return (ArrayList) GlobalData.getObj(this.k, "ignored_apps");
        } catch (Exception e) {
            ArrayList arrayList = new ArrayList();
            e.printStackTrace();
            return arrayList;
        }
    }

    public boolean isEmailValid(String str) {
        return Pattern.compile("^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$", 2).matcher(str).matches();
    }

    public void onCreate(Bundle bundle) {
        displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        super.onCreate(bundle);
        Util.isHome = false;
        this.k = this;
    }
}
