package com.vidsoft.collagemaker.Utils;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore.Files;
import android.view.View;
import android.widget.Toast;

import com.vidsoft.collagemaker.pipphotoeffect.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SaveImage {
    public static void takeScreenshot(String storePath, View view, Activity activity) {
        view.setDrawingCacheEnabled(true);
        Bitmap bitmap = view.getDrawingCache();
        File file = null;
        if (Environment.getExternalStorageState().equals("mounted")) {
            File directory = new File(new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().toString())).append(File.separator).append(activity.getResources().getString(R.string.app_name)).toString());
            if (!directory.exists()) {
                directory.mkdirs();
            }
            file = new File(directory.getAbsolutePath() + "/" + storePath + "_" + new SimpleDateFormat("yyyyMMdd_HH_mm_ss").format(new Date()) + ".png");
            Const.imgSharePath = String.valueOf(file);
        }
        try {
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        activity.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file)));
        Toast.makeText(activity, activity.getString(R.string.img_save), Toast.LENGTH_SHORT).show();
    }

    public static void deleteFileFromMediaStore(ContentResolver contentResolver, File file) {
        String canonicalPath;
        try {
            canonicalPath = file.getCanonicalPath();
        } catch (IOException e) {
            canonicalPath = file.getAbsolutePath();
        }
        Uri uri = Files.getContentUri("external");
        if (contentResolver.delete(uri, "_data=?", new String[]{canonicalPath}) == 0) {
            if (!file.getAbsolutePath().equals(canonicalPath)) {
                contentResolver.delete(uri, "_data=?", new String[]{file.getAbsolutePath()});
            }
        }
    }

    public static void copyDirectoryOneLocationToAnotherLocation(File sourceLocation, File targetLocation) throws IOException {
        if (sourceLocation.isDirectory()) {
            if (!targetLocation.exists()) {
                targetLocation.mkdir();
            }
            String[] children = sourceLocation.list();
            for (int i = 0; i < sourceLocation.listFiles().length; i++) {
                copyDirectoryOneLocationToAnotherLocation(new File(sourceLocation, children[i]), new File(targetLocation, children[i]));
            }
            return;
        }
        InputStream in = new FileInputStream(sourceLocation);
        OutputStream out = new FileOutputStream(targetLocation);
        byte[] buf = new byte[1024];
        while (true) {
            int len = in.read(buf);
            if (len > 0) {
                out.write(buf, 0, len);
            } else {
                in.close();
                out.close();
                return;
            }
        }
    }
}