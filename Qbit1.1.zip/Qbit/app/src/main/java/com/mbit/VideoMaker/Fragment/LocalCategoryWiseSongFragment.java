package com.mbit.VideoMaker.Fragment;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.mbit.VideoMaker.Activity.LocalSongActivity;
import com.mbit.VideoMaker.Adapter.SongByFolderAdapter;
import com.mbit.VideoMaker.Model.LocalTrack;
import com.mbit.VideoMaker.Model.MusicFolder;
import com.mbit.VideoMaker.R;
import java.util.List;

import static com.mbit.VideoMaker.Activity.LocalSongActivity.allMusicFolders;


@SuppressLint("ValidFragment")
public class LocalCategoryWiseSongFragment extends Fragment {

    public List<LocalTrack> tempFolderContent;
    public MusicFolder tempMusicFolder;
    Integer Folderid = -1;
    Integer TabIndex = -1;
    RecyclerView allFoldersRecycler;
    SongByFolderAdapter mfAdapter;

    public static Fragment getInstance(int Folderid, int TabIndex) {
        Bundle bundle = new Bundle();
        bundle.putInt("Folderid", Folderid);
        bundle.putInt("TabIndex", TabIndex);
        LocalCategoryWiseSongFragment songFragment = new LocalCategoryWiseSongFragment();
        songFragment.setArguments(bundle);
        return songFragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Folderid = getArguments().getInt("Folderid");
        TabIndex = getArguments().getInt("TabIndex");
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_catwise_song, container, false);
        tempMusicFolder = allMusicFolders.getMusicFolders().get(Folderid);
        tempFolderContent = tempMusicFolder.getLocalTracks();
        allFoldersRecycler = view.findViewById(R.id.rv_recycler_view);
        mfAdapter = new SongByFolderAdapter(getContext(), tempFolderContent);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        allFoldersRecycler.setLayoutManager(mLayoutManager);
        allFoldersRecycler.setItemAnimator(new DefaultItemAnimator());
        this.mfAdapter.Music(new musicInterface());
        allFoldersRecycler.setAdapter(mfAdapter);
        return view;
    }

    class musicInterface implements SongByFolderAdapter.LocalmusicInterface {

        public void a() {
            ((LocalSongActivity)getActivity()).Getcontent();


        }

        public void a(LocalTrack musicRes, int i) {
            SongByFolderAdapter.FirstSelected = musicRes.a();
            ((LocalSongActivity)getActivity()).Music(musicRes);
            ((LocalSongActivity)getActivity()).mediacontroler.f();
            if (allFoldersRecycler != null && !allFoldersRecycler.isComputingLayout()) {
                mfAdapter.notifyDataSetChanged();
            }

        }
    }


}
