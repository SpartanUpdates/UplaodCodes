package com.esc.poems;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView.Adapter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SecondRecyclerViewAdapter extends Adapter<SecondRecyclerViewAdapter.ViewHolder> {
    private String TAG = "SecondRecyclerViewAdapter";
    private final ArrayList<String> catname;
    Context context;
    private int f;
    private final ArrayList<Integer> fav;
    ViewHolder holder;
    ImageView im;
    private final List<Object> mRecyclerViewItems_v;
    private String msg2;
    private int nooftimes_resultviewd = 0;
    private final ArrayList<String> quotes;
    private final ArrayList<String> quotesid;
    Typeface type1;
    private final int ww;

    public class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public ImageView fimg;
        public ImageView imgmsg;
        public TextView quotetxt;
        public Button sharebtnimg;
        public Button sharebtntxt;

        public ViewHolder(View view) {
            super(view);
            this.quotetxt = (TextView) view.findViewById(R.id.quotestxt);
            this.fimg = (ImageView) view.findViewById(R.id.favimg);
            this.imgmsg = (ImageView) view.findViewById(R.id.imgmsg);
            this.sharebtntxt = (Button) view.findViewById(R.id.sharetxt);
            this.sharebtnimg = (Button) view.findViewById(R.id.sharebtnimg);
        }
    }


    public SecondRecyclerViewAdapter(Context context, int i, int i2, ArrayList<String> arrayList, ArrayList<String> arrayList2, ArrayList<Integer> arrayList3, ArrayList<String> arrayList4, ArrayList<String> arrayList5, List<Object> list) {
        this.mRecyclerViewItems_v = list;
        this.ww = i2;
        this.quotes = arrayList;
        this.quotesid = arrayList2;
        this.catname = arrayList5;
        this.fav = arrayList3;
        this.type1 = Typeface.createFromAsset(context.getAssets(), "fonts/roboto_light.ttf");
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        return new ViewHolder(from.inflate(R.layout.messages_list, viewGroup, false));
    }

    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        if (((Integer) this.fav.get(i)).intValue() == 0) {
            viewHolder.fimg.setImageResource(R.drawable.inactive1);
        } else {
            viewHolder.fimg.setImageResource(R.drawable.stars);
        }
        this.im = viewHolder.imgmsg;
        if (getItemViewType(i) == 1) {
            viewHolder.sharebtnimg.setTag(Integer.valueOf(i));
        } else {
            viewHolder.imgmsg.setImageDrawable(null);
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) viewHolder.imgmsg.getLayoutParams();
            viewHolder.imgmsg.getLayoutParams().height = 0;
            viewHolder.imgmsg.getLayoutParams().width = 0;
        }
        viewHolder.quotetxt.setTypeface(this.type1);
        viewHolder.quotetxt.setText(Html.fromHtml(((String) this.quotes.get(i)).toString()));
        viewHolder.quotetxt.setTag(Integer.valueOf(i));
        viewHolder.fimg.setTag(Integer.valueOf(i));
        viewHolder.sharebtntxt.setTag(Integer.valueOf(i));
        viewHolder.sharebtnimg.setTag(Integer.valueOf(i));
        viewHolder.imgmsg.setTag(Integer.valueOf(i));
        viewHolder.fimg.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ImageView imageView = (ImageView) view.findViewById(R.id.favimg);
                imageView.setTag(viewHolder.fimg.getTag());
                SecondRecyclerViewAdapter secondRecyclerViewAdapter = SecondRecyclerViewAdapter.this;
                secondRecyclerViewAdapter.f = ((Integer) secondRecyclerViewAdapter.fav.get(i)).intValue();
                if (SecondRecyclerViewAdapter.this.f == 0) {
                    imageView.setImageResource(R.drawable.stars);
                    Second1.baseHelper.updateFavorite(1, Integer.parseInt((String) SecondRecyclerViewAdapter.this.quotesid.get(i)));
                    Toast.makeText(SecondRecyclerViewAdapter.this.context, "Marked as a Favorite", Toast.LENGTH_SHORT).show();
                    imageView.invalidate();
                    SecondRecyclerViewAdapter.this.notifyDataSetChanged();
                    SecondRecyclerViewAdapter.this.fav.set(i, Integer.valueOf(1));
                } else if (SecondRecyclerViewAdapter.this.f == 1) {
                    imageView.setImageResource(R.drawable.inactive1);
                    Second1.baseHelper.updateFavorite(0, Integer.parseInt((String) SecondRecyclerViewAdapter.this.quotesid.get(i)));
                    Toast.makeText(SecondRecyclerViewAdapter.this.context, "Favorite Unmarked", Toast.LENGTH_SHORT).show();
                    imageView.invalidate();
                    SecondRecyclerViewAdapter.this.notifyDataSetChanged();
                    SecondRecyclerViewAdapter.this.fav.set(i, Integer.valueOf(0));
                }
            }
        });
        viewHolder.sharebtntxt.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = "firstvisit";
                if (Second1.sharedPreferences1.getInt(str, 0) == 0) {
                    Second1.editor1.putInt(str, 0);
                    Second1.editor1.commit();
                }
                String str2 = "count";
                SecondRecyclerViewAdapter.this.nooftimes_resultviewd = Second1.sharedPreferences1.getInt(str2, 0);
                Second1.editor1.putInt(str2, SecondRecyclerViewAdapter.this.nooftimes_resultviewd + 1);
                Second1.editor1.commit();
                Bundle bundle = new Bundle();
                str = SecondRecyclerViewAdapter.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("tracker - share text");
                stringBuilder.append((String) SecondRecyclerViewAdapter.this.catname.get(i));
                Log.e(str, stringBuilder.toString());
                bundle.putString("ShareText", (String) SecondRecyclerViewAdapter.this.catname.get(i));
                String obj = Html.fromHtml((String) SecondRecyclerViewAdapter.this.quotes.get(i)).toString();
                SecondRecyclerViewAdapter secondRecyclerViewAdapter = SecondRecyclerViewAdapter.this;
                stringBuilder = new StringBuilder();
                stringBuilder.append(obj);
                stringBuilder.append("\n");
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("<br>Do read this poem. I found it at <br>");
                stringBuilder2.append(MyApplication.appLink);
                stringBuilder2.append(context.getPackageName());
                stringBuilder.append(Html.fromHtml(stringBuilder2.toString()));
                secondRecyclerViewAdapter.msg2 = stringBuilder.toString();
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", "Poems For All Occasions");
                intent.putExtra("android.intent.extra.TEXT", SecondRecyclerViewAdapter.this.msg2);
                SecondRecyclerViewAdapter.this.context.startActivity(Intent.createChooser(intent, "Share via"));
                SecondRecyclerViewAdapter.this.copyText();
            }
        });
        viewHolder.sharebtnimg.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = "firstvisit";
                if (Second1.sharedPreferences1.getInt(str, 0) == 0) {
                    Second1.editor1.putInt(str, 0);
                    Second1.editor1.commit();
                }
                String str2 = "count";
                SecondRecyclerViewAdapter.this.nooftimes_resultviewd = Second1.sharedPreferences1.getInt(str2, 0);
                Second1.editor1.putInt(str2, SecondRecyclerViewAdapter.this.nooftimes_resultviewd + 1);
                Second1.editor1.commit();
                Bundle bundle = new Bundle();
                str = SecondRecyclerViewAdapter.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("tracker -copy ");
                stringBuilder.append((String) SecondRecyclerViewAdapter.this.catname.get(i));
                Log.e(str, stringBuilder.toString());
                bundle.putString("CopyText", (String) SecondRecyclerViewAdapter.this.catname.get(i));
                String obj = Html.fromHtml((String) SecondRecyclerViewAdapter.this.quotes.get(i)).toString();
                SecondRecyclerViewAdapter secondRecyclerViewAdapter = SecondRecyclerViewAdapter.this;
                stringBuilder = new StringBuilder();
                stringBuilder.append(obj);
                stringBuilder.append("\n");
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("<br>Do read this poem. I found it at <br>");
                stringBuilder2.append(MyApplication.appLink);
                stringBuilder2.append(context.getPackageName());
                stringBuilder.append(Html.fromHtml(stringBuilder2.toString()));
                secondRecyclerViewAdapter.msg2 = stringBuilder.toString();
                SecondRecyclerViewAdapter.this.copyText();
            }
        });
    }

    public int getItemCount() {
        return this.mRecyclerViewItems_v.size();
    }


    public void copyText() {
        ((ClipboardManager) this.context.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("label", Html.fromHtml(this.msg2)));
        Toast.makeText(this.context, "Copied to Clipboard", Toast.LENGTH_SHORT).show();
    }
}
