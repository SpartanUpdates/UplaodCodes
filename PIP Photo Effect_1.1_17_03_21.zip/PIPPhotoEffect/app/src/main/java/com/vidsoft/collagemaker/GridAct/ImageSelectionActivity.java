package com.vidsoft.collagemaker.GridAct;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Process;
import android.provider.MediaStore.Images.Media;
import androidx.appcompat.app.AlertDialog.Builder;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.appcompat.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.vidsoft.collagemaker.Model.Album;
import com.vidsoft.collagemaker.Model.Image;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Const;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;

import me.zhanghai.android.materialprogressbar.BuildConfig;

public class ImageSelectionActivity extends AppCompatActivity {
    Activity activity;
    ArrayList<Album> albumArrayList;
    AlbumSelectAdapter albumSelectAdapter;
    int currentCount;
    GridView gridView;
    ArrayList<Image> imageArrayList;
    ImageSelectAdapter imageSelectAdapter;
    LinearLayoutManager linearLayoutManager;
    ListView listView;
    private final String[] projection;
    RecyclerView recyclerView;
    SelectedImageAdapter selectedImageAdapter;
    ArrayList<String> selectedImageList;
    TextView textView;
    int totalCount;
    TextView textView1;

    public class AlbumSelectAdapter extends BaseAdapter {
        ArrayList<Album> albumArrayList;
        Context context;

        public class Holder {
            ImageView album_img;
            TextView album_name;
            TextView album_total;
        }

        public AlbumSelectAdapter(Context context, ArrayList<Album> albumArrayList) {
            this.albumArrayList = albumArrayList;
            this.context = context;
        }

        public int getCount() {
            return this.albumArrayList.size();
        }

        public Object getItem(int position) {
            return Integer.valueOf(position);
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = LayoutInflater.from(this.context).inflate(R.layout.album_select_adapter, parent, false);
            Holder holder = new Holder();
            holder.album_img = convertView.findViewById(R.id.album_img);
            holder.album_name = convertView.findViewById(R.id.tv_albumname);
            holder.album_total = convertView.findViewById(R.id.tv_albumtotal);
            holder.album_name.setText(this.albumArrayList.get(position).getName());
            Glide.with(this.context).load(this.albumArrayList.get(position).getCover()).placeholder(R.drawable.placeholder).into(holder.album_img);
            holder.album_total.setText("(" + this.albumArrayList.get(position).getCount() + ")");
            return convertView;
        }
    }

    public class ImageSelectAdapter extends BaseAdapter {
        Context context;
        ArrayList<Image> imageArrayList;

        public class Holder {
            ImageView imageView;
        }

        public ImageSelectAdapter(Context context, ArrayList<Image> imageArrayList) {
            this.imageArrayList = imageArrayList;
            this.context = context;
        }

        public int getCount() {
            return this.imageArrayList.size();
        }

        public Object getItem(int i) {
            return Integer.valueOf(i);
        }

        public long getItemId(int i) {
            return i;
        }

        public View getView(int position, View view, ViewGroup viewGroup) {
            view = LayoutInflater.from(this.context).inflate(R.layout.adapter_image_select, viewGroup, false);
            Holder holder = new Holder();
            holder.imageView = view.findViewById(R.id.imageView);
            Glide.with(this.context).load(this.imageArrayList.get(position).path).placeholder(R.drawable.placeholder).into(holder.imageView);
            return view;
        }
    }

    public class SelectedImageAdapter extends Adapter<SelectedImageAdapter.ViewHolder> {
        Context context;
        ArrayList<String> selectedImageList;


        public class ViewHolder extends RecyclerView.ViewHolder {
            RelativeLayout delete_img;
            ImageView imageView;

            public ViewHolder(View itemView) {
                super(itemView);
                this.imageView = itemView.findViewById(R.id.imageView);
                this.delete_img = itemView.findViewById(R.id.delete_img);
            }
        }

        public SelectedImageAdapter(Context context, ArrayList<String> selectedImageList) {
            this.selectedImageList = selectedImageList;
            this.context = context;
        }

        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(this.context).inflate(R.layout.adapter_selected_image, parent, false));
        }

        public void onBindViewHolder(ViewHolder holder, final int position) {
            Glide.with(this.context).load(this.selectedImageList.get(position)).placeholder(R.drawable.placeholder).into(holder.imageView);
            holder.delete_img.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    SelectedImageAdapter.this.selectedImageList.remove(position);
                    SelectedImageAdapter.this.notifyDataSetChanged();
                    ImageSelectionActivity imageSelectionActivity = ImageSelectionActivity.this;
                    imageSelectionActivity.currentCount--;
                    ImageSelectionActivity.this.textView1.setText(ImageSelectionActivity.this.currentCount + "/" + ImageSelectionActivity.this.totalCount);

                }
            });
        }

        public int getItemCount() {
            return this.selectedImageList.size();
        }
    }

    public ImageSelectionActivity() {
        this.activity = this;
        this.currentCount = 0;
        this.imageArrayList = new ArrayList();
        this.albumArrayList = new ArrayList();
        this.selectedImageList = new ArrayList();
        this.projection = new String[]{"bucket_id", "bucket_display_name", "_data"};
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_imageselection);
        bindToolbar();
        bindControls();
        fetchAlbumData();
        clickEvent();
    }

    private void bindToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.back_btn_selector);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.textView = toolbar.findViewById(R.id.toolbar_title);
        this.textView.setText(getResources().getString(R.string.ImageSelectionActivity_Title));
    }

    private void fetchAlbumData() {
        Process.setThreadPriority(10);
        Cursor cursor = this.activity.getContentResolver().query(Media.EXTERNAL_CONTENT_URI, this.projection, null, null, "date_added");
        if (cursor == null) {
            Builder alertDialogbuilder = new Builder(this);
            alertDialogbuilder.setMessage(getResources().getString(R.string.sdcard_error));
            alertDialogbuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    ImageSelectionActivity.this.finish();
                }
            });
            alertDialogbuilder.setCancelable(false);
            alertDialogbuilder.show();
            return;
        }
        ArrayList<Album> arrayList = new ArrayList(cursor.getCount());
        HashSet<Long> albumSet = new HashSet();
        if (cursor.moveToLast()) {
            while (!Thread.interrupted()) {
                long albumId = cursor.getLong(cursor.getColumnIndex(this.projection[0]));
                String album = cursor.getString(cursor.getColumnIndex(this.projection[1]));
                String image = cursor.getString(cursor.getColumnIndex(this.projection[2]));
                if (album != null) {
                    if (!albumSet.contains(Long.valueOf(albumId)) && new File(image).exists()) {
                        Cursor tempCursor = getContentResolver().query(Media.EXTERNAL_CONTENT_URI, this.projection, "bucket_display_name =?", new String[]{album}, "date_added");
                        arrayList.add(new Album(album, image, tempCursor.getCount() + BuildConfig.FLAVOR));
                        albumSet.add(Long.valueOf(albumId));
                        tempCursor.close();
                    }
                }
                if (!cursor.moveToPrevious()) {
                    cursor.close();
                    if (this.albumArrayList == null) {
                        this.albumArrayList = new ArrayList();
                    }
                    this.albumArrayList.clear();
                    this.albumArrayList.addAll(arrayList);
                    this.albumSelectAdapter = new AlbumSelectAdapter(this.activity, this.albumArrayList);
                    this.listView.setAdapter(this.albumSelectAdapter);
                    return;
                }
            }
            return;
        }
    }

    private void fetchImageData(String album) {
        HashSet<Long> selectedImages = new HashSet();
        if (this.imageArrayList != null) {
            int l = this.imageArrayList.size();
            for (int i = 0; i < l; i++) {
                Image image = this.imageArrayList.get(i);
                if (new File(image.path).exists() && image.isSelected) {
                    selectedImages.add(Long.valueOf(image.id));
                }
            }
        }
        Cursor cursor = getContentResolver().query(Media.EXTERNAL_CONTENT_URI, this.projection, "bucket_display_name =?", new String[]{album}, "date_added");
        int tempCountSelected = 0;
        ArrayList<Image> temp = new ArrayList(cursor.getCount());
        if (cursor.moveToLast()) {
            while (!Thread.interrupted()) {
                long id = cursor.getLong(cursor.getColumnIndex(this.projection[0]));
                String name = cursor.getString(cursor.getColumnIndex(this.projection[1]));
                String path = cursor.getString(cursor.getColumnIndex(this.projection[2]));
                boolean isSelected = selectedImages.contains(Long.valueOf(id));
                if (isSelected) {
                    tempCountSelected++;
                }
                if (new File(path).exists()) {
                    temp.add(new Image(id, name, path, isSelected));
                }
                if (!cursor.moveToPrevious()) {
                    cursor.close();
                    if (this.imageArrayList == null) {
                        this.imageArrayList = new ArrayList();
                    }
                    this.imageArrayList.clear();
                    this.imageArrayList.addAll(temp);
                    this.imageSelectAdapter = new ImageSelectAdapter(this.activity, this.imageArrayList);
                    this.gridView.setAdapter(this.imageSelectAdapter);
                    return;
                }
            }
            return;
        }
    }

    private void clickEvent() {
        this.textView1.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (ImageSelectionActivity.this.textView1.getText().equals("0/9")) {
                    Toast.makeText(ImageSelectionActivity.this.activity, "Please select image(s)", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent(ImageSelectionActivity.this.activity, GridActivity.class);
                intent.putStringArrayListExtra(Const.imgList, ImageSelectionActivity.this.selectedImageList);
                ImageSelectionActivity.this.startActivity(intent);
                ImageSelectionActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
            }
        });
        this.listView.setOnItemClickListener(new OnItemClickListener() {

            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ImageSelectionActivity.this.listView.setVisibility(View.GONE);
                ImageSelectionActivity.this.textView.setText(ImageSelectionActivity.this.albumArrayList.get(position).getName());
                ImageSelectionActivity.this.fetchImageData(ImageSelectionActivity.this.albumArrayList.get(position).getName());
            }
        });
        this.gridView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                if (ImageSelectionActivity.this.textView1.getText().equals(ImageSelectionActivity.this.getResources().getString(R.string.done))) {
                    Toast.makeText(ImageSelectionActivity.this.activity, "Can't select more than " + ImageSelectionActivity.this.totalCount + " image(s)", Toast.LENGTH_SHORT).show();
                    return;
                }
                ImageSelectionActivity imageSelectionActivity;
                if (ImageSelectionActivity.this.currentCount == ImageSelectionActivity.this.totalCount - 1) {
                    imageSelectionActivity = ImageSelectionActivity.this;
                    imageSelectionActivity.currentCount++;
                    ImageSelectionActivity.this.textView1.setText(ImageSelectionActivity.this.getResources().getString(R.string.done));
                } else {
                    imageSelectionActivity = ImageSelectionActivity.this;
                    imageSelectionActivity.currentCount++;
                    ImageSelectionActivity.this.textView1.setText(ImageSelectionActivity.this.currentCount + "/" + ImageSelectionActivity.this.totalCount);
                }
                ImageSelectionActivity.this.selectedImageList.add(ImageSelectionActivity.this.imageArrayList.get(position).path);
                if (ImageSelectionActivity.this.selectedImageList.size() == 1) {
                    ImageSelectionActivity.this.selectedImageAdapter = new SelectedImageAdapter(ImageSelectionActivity.this.activity, ImageSelectionActivity.this.selectedImageList);
                    ImageSelectionActivity.this.recyclerView.setAdapter(ImageSelectionActivity.this.selectedImageAdapter);
                    return;
                }
                ImageSelectionActivity.this.selectedImageAdapter.notifyDataSetChanged();
            }
        });
    }

    private void bindControls() {
        this.totalCount = Integer.parseInt(getIntent().getExtras().getString(Const.imgId));
        this.textView1 = findViewById(R.id.txtTotalImg);
        this.gridView = findViewById(R.id.gridView);
        this.listView = findViewById(R.id.imglistView);
        this.recyclerView = findViewById(R.id.recyclerView);
        this.linearLayoutManager = new LinearLayoutManager(this, 0, false);
        this.recyclerView.setLayoutManager(this.linearLayoutManager);
        this.textView1.setText(this.currentCount + "/" + this.totalCount);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 16908332:
                if (this.textView.getText().equals(getResources().getString(R.string.ImageSelectionActivity_Title))) {
                    finish();
                    overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
                }
                this.textView.setText(getResources().getString(R.string.ImageSelectionActivity_Title));
                this.listView.setVisibility(View.VISIBLE);
                return true;
            default:
                return false;
        }
    }

    public void onBackPressed() {
        if (this.textView.getText().equals(getResources().getString(R.string.ImageSelectionActivity_Title))) {
            finish();
            overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
            super.onBackPressed();
            return;
        }
        this.textView.setText(getResources().getString(R.string.ImageSelectionActivity_Title));
        this.listView.setVisibility(View.VISIBLE);
    }
}