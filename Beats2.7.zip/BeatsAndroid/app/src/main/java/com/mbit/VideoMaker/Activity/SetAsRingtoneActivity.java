package com.mbit.VideoMaker.Activity;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.R;

import java.io.File;
import java.io.IOException;

public class SetAsRingtoneActivity extends AppCompatActivity {

    Activity activity = SetAsRingtoneActivity.this;
    ImageView ivback;
    ImageView ivCd, ivPlayPause;
    TextView tvSongName, tvStartTime, tvEndTime;
    SeekBar sbSong;
    Button btnSetasringtone;
    AdRequest adRequest;
    AdView adView;
    String SongName, SongPath;
    Animation u;
    MediaPlayer mediaPlayer = new MediaPlayer();
    private Handler w = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_as_ringtone);
        if (getIntent() != null) {
            SongName = getIntent().getStringExtra("SongName");
            SongPath = getIntent().getStringExtra("SongPath");
        }
        BindView();
        loadAd();
        SetAnimation();
        if (SongName != null) {
            tvSongName.setText(SongName);
        }
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnSetasringtone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String SoundPath = Utils.INSTANCE.getThemeFolderPath() + File.separator + SongPath;
                try {
                    if (Build.VERSION.SDK_INT < 23) {
                        RingTonePtah(SoundPath, activity);
                    } else if (!Utils.INSTANCE.SetPermission(activity)) {
                        Toast.makeText(activity, activity.getString(R.string.sys_setings_msg), Toast.LENGTH_LONG).show();
                    } else if (!(activity == null)) {
                        RingTonePtah(SoundPath, activity);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(activity, activity.getString(R.string.unable_to_set_ringtone), Toast.LENGTH_SHORT).show();
                }
            }
        });
        if (SongPath != null) {
            try {
                i();
                ivPlayPause.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.icon_pause_ringtone_set));
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }

        }
        sbSong.setClickable(false);
        sbSong.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                TextView textView;
                String str;
                int ceil = (int) Math.ceil((double) (((float) i) / 1000.0f));
                if (ceil < 10) {
                    textView = tvStartTime;
                    str = "0:0";
                } else {
                    textView = tvStartTime;
                    str = "0:";
                }
                textView.setText(str.concat(String.valueOf(ceil)));
                double d = (double) i;
                double max = (double) seekBar.getMax();
                Double.isNaN(d);
                Double.isNaN(max);
                d /= max;
                max = (double) (seekBar.getWidth() - (seekBar.getThumbOffset() * 2));
                Double.isNaN(max);
                Math.round(d * max);
                if (i > 0 && mediaPlayer != null && !mediaPlayer.isPlaying()) {
                    ivPlayPause.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.icon_play_ringtone));
                    sbSong.setProgress(0);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.seekTo(seekBar.getProgress());
                }

            }
        });
    }

    private void i() {
        try {
            if (this.mediaPlayer != null && this.mediaPlayer.isPlaying()) {
                this.mediaPlayer.pause();
                this.k();
                this.w.removeCallbacksAndMessages(null);
                ivPlayPause.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.icon_play_ringtone_set));
                return;
            }
            if (this.mediaPlayer == null) {
                mediaPlayer = MediaPlayer.create(activity, Uri.parse(this.SongPath));
                SetAnimation();
                this.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    public final void onCompletion(final MediaPlayer mediaPlayer) {
                        w.removeCallbacksAndMessages(null);
                        mediaPlayer.stop();
                        mediaPlayer.reset();
                        SetAsRingtoneActivity.this.mediaPlayer = null;
                        k();
                        sbSong.setProgress(0);
                        tvStartTime.setText("0:00");
                        w.removeCallbacksAndMessages(null);
                        ivPlayPause.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.icon_play_ringtone_set));
                    }
                });
                this.sbSong.setMax(this.mediaPlayer.getDuration() / 100);
                final TextView r = this.tvEndTime;
                final StringBuilder sb = new StringBuilder("0:");
                sb.append(this.mediaPlayer.getDuration() / 1000);
                r.setText(sb.toString());
                this.runOnUiThread(new Runnable() {
                    @Override
                    public final void run() {
                        if (SetAsRingtoneActivity.this.mediaPlayer != null) {
                            SetAsRingtoneActivity.this.sbSong.setProgress(SetAsRingtoneActivity.this.mediaPlayer.getCurrentPosition() / 100);
                            final int n = SetAsRingtoneActivity.this.mediaPlayer.getCurrentPosition() / 1000;
                            TextView textView;
                            String s;
                            if (n < 10) {
                                textView = SetAsRingtoneActivity.this.tvStartTime;
                                s = "0:0";
                            } else {
                                textView = SetAsRingtoneActivity.this.tvStartTime;
                                s = "0:";
                            }
                            textView.setText(s.concat(String.valueOf(n)));
                        }
                        SetAsRingtoneActivity.this.w.postDelayed(this, 100L);
                    }
                });
                ivPlayPause.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.icon_pause_ringtone_set));
                return;
            }
            this.mediaPlayer.start();
        } catch (IllegalStateException ex) {
            ex.printStackTrace();
        }
    }

    private void BindView() {
        ivback = findViewById(R.id.ivBack);
        tvSongName = findViewById(R.id.tvSongName);
        ivCd = findViewById(R.id.ivCd);
        ivPlayPause = findViewById(R.id.ivPlayPause);
        tvStartTime = findViewById(R.id.tvStartCounter);
        tvEndTime = findViewById(R.id.tvEndCounter);
        sbSong = findViewById(R.id.seekbarSong);
        btnSetasringtone = findViewById(R.id.btnSetAsringtone);
    }

    private void loadAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    public void RingTonePtah(final String SongfilePath, final Context context) {
        new Thread(new Runnable() {
            public final void run() {
                try {
                    if (SongfilePath != null) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(Utils.d);
                        stringBuilder.append(File.separator);
                        stringBuilder.append("Ringtone");
                        stringBuilder.append(File.separator);
                        stringBuilder.append("ringtone.mp3");
                        String stringBuilder2 = stringBuilder.toString();
                        File file = new File(stringBuilder2);
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(Utils.d);
                        stringBuilder3.append(File.separator);
                        stringBuilder3.append("Ringtone");
                        Utils.INSTANCE.CopyFileToStorage(SongfilePath, stringBuilder2, stringBuilder3.toString());
                        stringBuilder3 = new StringBuilder("path : ");
                        stringBuilder3.append(SongfilePath);
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("_data", file.getAbsolutePath());
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append(file.getName());
                        contentValues.put("title", stringBuilder4.toString());
                        contentValues.put("is_ringtone", Boolean.TRUE);
                        contentValues.put("mime_type", "audio/mp3");
                        stringBuilder3 = new StringBuilder("file://");
                        stringBuilder3.append(file.getAbsolutePath());
                        Uri contentUriForPath = MediaStore.Audio.Media.getContentUriForPath(stringBuilder3.toString());
                        ContentResolver contentResolver = context.getContentResolver();
                        StringBuilder stringBuilder5 = new StringBuilder("_data=\"");
                        stringBuilder5.append(file.getAbsolutePath());
                        stringBuilder5.append("\"");
                        contentResolver.delete(contentUriForPath, stringBuilder5.toString(), null);
                        Uri insert = context.getContentResolver().insert(contentUriForPath, contentValues);
                        RingtoneManager.setActualDefaultRingtoneUri(context, 1, insert);
                        ((Activity) context).runOnUiThread(new Runnable() {
                            public final void run() {
                                Toast.makeText(context, context.getString(R.string.rintone_seted), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void SetAnimation() {
        this.u = AnimationUtils.loadAnimation(this, R.anim.loader_rotation);
        runOnUiThread(new Runnable() {

            public final void run() {
                u.setRepeatCount(-1);
                ivCd.startAnimation(u);
            }
        });
    }

    private void k() {
        this.u = AnimationUtils.loadAnimation(this, R.anim.loader_rotation);
        this.ivCd.clearAnimation();
    }

    public void onPause() {
        super.onPause();
        try {
            if (this.mediaPlayer != null && this.mediaPlayer.isPlaying()) {
                this.mediaPlayer.stop();
                this.mediaPlayer.reset();
                k();
                ivPlayPause.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.icon_play_ringtone_set));
            }
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }
}
