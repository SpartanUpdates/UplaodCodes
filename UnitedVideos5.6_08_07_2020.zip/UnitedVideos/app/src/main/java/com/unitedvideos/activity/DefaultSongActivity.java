package com.unitedvideos.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unitedvideos.R;
import com.unitedvideos.Utils.Utils;
import com.unitedvideos.application.MyApplication;
import com.unity3d.player.UnityPlayer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class DefaultSongActivity extends AppCompatActivity {

    Activity activity = DefaultSongActivity.this;

    final int[] SongList = new int[]
            {R.raw.birthday_music,
                    R.raw.color_party_music,
                    R.raw.dubstep_music,
                    R.raw.energy_beat_music,
                    R.raw.funday_music,
            };
    public MediaPlayer Mplayer;
    public DefaultSongtAdapter defaultSongtAdapter;
    LinearLayout layoutSongSdCard;
    ListView lvDefaultSong;
    ImageView ivBack;
    TextView tvDone;
    String SongPath;
    ArrayList<String> songNameList;
    private MyApplication application;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_default_song);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "DefaultSongActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        bindView();
        init();
        BannerAds();
        defaultSongtAdapter = new DefaultSongtAdapter(DefaultSongActivity.this, this.songNameList);
        lvDefaultSong.setAdapter(this.defaultSongtAdapter);
    }

    private void BannerAds() {
//        adView = findViewById(R.id.adView);
//        AdRequest adRequest = new AdRequest.Builder().build();
//        adView.loadAd(adRequest);
        try {
            this.adContainerView = (FrameLayout) findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay;
            defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }
    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void init() {
        application = MyApplication.getInstance();
        songNameList = new ArrayList<>();
        songNameList.add("Birthday Music");
        songNameList.add("Color Party Music");
        songNameList.add("Dubstep Music");
        songNameList.add("Energy Beat Music");
        songNameList.add("Funday Music");
    }

    private void bindView() {
        ivBack = findViewById(R.id.ivBack);
        tvDone = findViewById(R.id.tv_done);
        lvDefaultSong = findViewById(R.id.lv_default_song);
        layoutSongSdCard = findViewById(R.id.ll_from_storage);
        tvDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlaying(Mplayer);
                new SelectSong().start();
            }
        });
        layoutSongSdCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(activity, PhoneSongActivity.class), 101);
            }
        });
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        stopPlaying(Mplayer);
    }

    public void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setMusic(int pos) {
        this.SongPath = "android.resource://" + getPackageName() + "/" + this.SongList[pos];
        this.application.posForAddMusicDialog = pos;
        stopPlaying(this.Mplayer);
        this.Mplayer = MediaPlayer.create(DefaultSongActivity.this, this.SongList[pos]);
        this.Mplayer.start();
    }


    public void SetMusic() {
        try {
            String path = Utils.INSTANCE.getMusicFolderPath();
            File dir = new File(path);
            if (dir.mkdirs() || dir.isDirectory()) {
                String str_song_name = songNameList.get(this.application.posForAddMusicDialog) + ".mp3";
                CopyRAWtoSDCard(SongList[this.application.posForAddMusicDialog], path + File.separator + str_song_name);
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("TAG", "setMusic: " + e.getMessage());
        }

    }

    private void CopyRAWtoSDCard(int id, String path) throws IOException {
        InputStream in = getResources().openRawResource(id);
        FileOutputStream out = new FileOutputStream(path);
        UnityPlayer.UnitySendMessage("StackManager", "AudioPathFun", path);
        Log.e("TAG", "CopyRAWtoSDCard: " + path);
        byte[] buff = new byte[1024];
        int read = 0;
        try {
            while ((read = in.read(buff)) > 0) {
                out.write(buff, 0, read);
            }
        } finally {
            in.close();
            out.close();
        }
    }


    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        final StringBuilder sb = new StringBuilder();
        sb.append("onlinemusic act onact result requestcode ");
        sb.append(n);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("onlinemusic act onact result resultcode ");
        sb2.append(n2);
        if (n2 == -1) {
            if (n != 101) {
                return;
            }
            intent.getExtras().getString("audio_path");
            UnityPlayer.UnitySendMessage("StackManager", "AudioPathFun", intent.getExtras().getString("audio_path"));
            this.setResult(-1);
            this.finish();
        }
    }

    public class SelectSong extends Thread {
        public void run() {
            runOnUiThread(new Runnable() {
                public void run() {
                    SetMusic();
                    finish();
                }
            });
        }

    }

    public class DefaultSongtAdapter extends BaseAdapter {
        Context context;
        ArrayList<String> songName;
        public int SelectedPosition = -1;

        public DefaultSongtAdapter(Context cnx, ArrayList<String> name) {
            this.context = cnx;
            this.songName = name;
        }

        public int getCount() {
            return this.songName.size();
        }

        public Object getItem(int arg0) {
            return this.songName.get(arg0);
        }

        public long getItemId(int arg0) {
            return (long) arg0;
        }

        public View getView(final int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(this.context).inflate(R.layout.row_default_song, parent, false);
            }
            LinearLayout layoutSongSelect = convertView.findViewById(R.id.layout_songselect);
            TextView tvUseMusic = convertView.findViewById(R.id.tvUseMusic);
            final CheckBox cbSelectSong = convertView.findViewById(R.id.ivImageSong);
            if (SelectedPosition != position) {
                tvUseMusic.setBackgroundResource(R.drawable.bg_song_phone_use_noraml);
            } else {
                tvUseMusic.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
            }
            cbSelectSong.setText(this.songName.get(position));
            layoutSongSelect.setOnClickListener(new View.OnClickListener() {
                public void onClick(final View arg0) {
                    SelectedPosition = position;
                    setMusic(SelectedPosition);
                    notifyDataSetChanged();
                }
            });
            return convertView;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        UnityPlayer.UnitySendMessage("UserData", "ResumeUnity", "");
        finish();
    }
}
