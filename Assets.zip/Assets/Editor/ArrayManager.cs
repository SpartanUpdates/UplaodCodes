﻿using UnityEngine;
using System.Collections;
using UnityEditor;

[CustomEditor(typeof(WayPoints))]
public class ArrayManager : Editor
{
    public GameObject[] a;
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        WayPoints myScript = (WayPoints)target;
        //if (GUILayout.Button("Create Main Array"))
        //{
        //    myScript.MainArray();
        //}
        //if (GUILayout.Button("Create Sub Array"))
        //{
        //    myScript.SubArray();
        //}
        //if (GUILayout.Button("Final Array"))
        //{
        //    myScript.FinalArray();
        //}
    }
}
