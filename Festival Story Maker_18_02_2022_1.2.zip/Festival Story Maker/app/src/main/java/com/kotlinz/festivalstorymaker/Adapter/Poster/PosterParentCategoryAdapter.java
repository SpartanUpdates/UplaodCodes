package com.kotlinz.festivalstorymaker.Adapter.Poster;


import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Model.PosterMaker.PosterChildCategory;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.PosterMakerActivity;

import java.util.ArrayList;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PosterParentCategoryAdapter extends RecyclerView.Adapter<PosterParentCategoryAdapter.MyViewHolder> {

    public PosterMakerActivity PosterActivity;
    public int SelectedPosition = 0;
    public ArrayList<PosterChildCategory> posterParentCategoryList;
    public boolean IsDefaultCategory = false;

    public PosterParentCategoryAdapter(Context context, ArrayList<PosterChildCategory> posterParentCategoryList) {
        this.PosterActivity = (PosterMakerActivity) context;
        this.posterParentCategoryList = posterParentCategoryList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_poster_parentcategory, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        if (posterParentCategoryList.get(position).getChildCatName().equals("Default")) {
            holder.llMain.setVisibility(View.GONE);
        } else {
            holder.tvParentCategoryName.setText(posterParentCategoryList.get(position).getChildCatName());
        }
        if (SelectedPosition == position) {
            holder.llMain.setBackground(PosterActivity.getResources().getDrawable(R.drawable.bg_childcat_press));
            holder.tvParentCategoryName.setTextColor(PosterActivity.getResources().getColor(R.color.child_cat_text_press));
        } else {
            holder.llMain.setBackground(null);
            holder.tvParentCategoryName.setTextColor(PosterActivity.getResources().getColor(R.color.child_cat_text_unpress));
        }


        if (!IsDefaultCategory) {
            if (posterParentCategoryList.get(position).getChildCatName().equals("Default")) {
                SelectedPosition = position;
                if (Utils.checkConnectivity(PosterActivity, false)) {
                    if (ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(position).getChildCatId()).equalsIgnoreCase("")) {
                        PosterActivity.GetPosterCategoryDataByID(PosterActivity.ParentCatId, String.valueOf(posterParentCategoryList.get(position).getChildCatId()));
                    } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(PosterActivity, ThemeDataPreferences.PosterMakerThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                        PosterActivity.GetPosterCategoryDataByID(PosterActivity.ParentCatId, String.valueOf(posterParentCategoryList.get(position).getChildCatId()));
                    } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(position).getChildCatId()).equalsIgnoreCase("")) {
                        PosterActivity.SetOfflineParentCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(position).getChildCatId()));
                    }
                } else {
                    if (ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(position).getChildCatId()).equalsIgnoreCase("")) {
                        PosterActivity.rlMainData.setVisibility(View.GONE);
                        PosterActivity.llRetry.setVisibility(View.VISIBLE);
                    } else {
                        PosterActivity.SetOfflineParentCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(position).getChildCatId()));
                    }
                }
            } else {
                SelectedPosition = position;
                if (Utils.checkConnectivity(PosterActivity, false)) {
                    if (ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(0).getChildCatId()).equalsIgnoreCase("")) {
                        PosterActivity.GetPosterCategoryDataByID(PosterActivity.ParentCatId, String.valueOf(posterParentCategoryList.get(0).getChildCatId()));
                    } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(PosterActivity, ThemeDataPreferences.PosterMakerThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                        PosterActivity.GetPosterCategoryDataByID(PosterActivity.ParentCatId, String.valueOf(posterParentCategoryList.get(0).getChildCatId()));
                    } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(0).getChildCatId()).equalsIgnoreCase("")) {
                        PosterActivity.SetOfflineParentCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(0).getChildCatId()));
                    }
                } else {
                    if (ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(0).getChildCatId()).equalsIgnoreCase("")) {
                        PosterActivity.rlMainData.setVisibility(View.GONE);
                        PosterActivity.llRetry.setVisibility(View.VISIBLE);
                    } else {
                        PosterActivity.SetOfflineParentCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(0).getChildCatId()));
                    }
                }
            }
        }

        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectedPosition = position;
                IsDefaultCategory = true;
                if (Utils.checkConnectivity(PosterActivity, false)) {
                    if (ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(position).getChildCatId()).equalsIgnoreCase("")) {
                        PosterActivity.GetPosterCategoryDataByID(PosterActivity.ParentCatId, String.valueOf(posterParentCategoryList.get(position).getChildCatId()));
                    } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(PosterActivity, ThemeDataPreferences.PosterMakerThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                        PosterActivity.GetPosterCategoryDataByID(PosterActivity.ParentCatId, String.valueOf(posterParentCategoryList.get(position).getChildCatId()));
                    } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(position).getChildCatId()).equalsIgnoreCase("")) {
                        PosterActivity.SetOfflineParentCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(position).getChildCatId()));
                    }
                } else {
                    if (ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(position).getChildCatId()).equalsIgnoreCase("")) {
                        PosterActivity.rlMainData.setVisibility(View.GONE);
                        PosterActivity.llRetry.setVisibility(View.VISIBLE);
                    } else {
                        PosterActivity.SetOfflineParentCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(PosterActivity, ThemeDataPreferences.PosterMakerTheme + PosterActivity.ParentCatId + posterParentCategoryList.get(position).getChildCatId()));
                    }
                }
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return posterParentCategoryList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.llMain)
        public LinearLayout llMain;

        @BindView(R.id.tvParentCategoryName)
        public TextView tvParentCategoryName;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
