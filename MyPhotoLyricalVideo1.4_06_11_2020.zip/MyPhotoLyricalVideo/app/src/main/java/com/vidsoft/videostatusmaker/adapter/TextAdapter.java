package com.vidsoft.videostatusmaker.adapter;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

public class TextAdapter extends BaseAdapter {
    Typeface typeface;
    LayoutInflater layoutInflater;
    private Context context;
    private String[] posterimgs;

    public TextAdapter(final Context context, final String[] posterimgs) {
        this.layoutInflater = null;
        this.context = context;
        this.posterimgs = posterimgs;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return this.posterimgs.length;
    }

    public Object getItem(final int n) {
        return n;
    }

    public long getItemId(final int n) {
        return n;
    }

    public View getView(final int n, final View view, final ViewGroup viewGroup) {
        View inflate = view;
        if (view == null) {
            inflate = this.layoutInflater.inflate(R.layout.text_adapter, (ViewGroup) null);
        }
        final LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.mainlay);
        final int widthPixels = this.context.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.context.getResources().getDisplayMetrics().heightPixels;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 1024 / 1080, heightPixels * 136 / 1920);
        layoutParams.addRule(14);
        final int n2 = heightPixels * 10 / 1920;
        if (n == this.posterimgs.length - 1) {
            layoutParams.setMargins(0, n2, 0, n2);
        } else {
            layoutParams.setMargins(0, n2, 0, 0);
        }
        linearLayout.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.arrow);
        final ImageView imageView2 = (ImageView) inflate.findViewById(R.id.music_icon);
        final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(widthPixels * 40 / 1080, heightPixels * 40 / 1920);
        layoutParams2.addRule(13);
        imageView.setLayoutParams((ViewGroup.LayoutParams) layoutParams2);
        final RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(widthPixels * 30 / 1080, heightPixels * 30 / 1920);
        layoutParams3.addRule(13);
        imageView2.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        final TextView textView = (TextView) inflate.findViewById(R.id.t);
        final AssetManager assets = this.context.getAssets();
        final StringBuilder sb = new StringBuilder();
        sb.append("fonts/");
        sb.append(this.posterimgs[n]);
        textView.setTypeface(this.typeface = Typeface.createFromAsset(assets, sb.toString()));
        return inflate;
    }
}
