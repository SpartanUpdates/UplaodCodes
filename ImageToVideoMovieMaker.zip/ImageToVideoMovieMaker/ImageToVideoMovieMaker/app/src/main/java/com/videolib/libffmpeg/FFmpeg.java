package com.videolib.libffmpeg;

import android.content.Context;
import android.text.TextUtils;


import com.videolib.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.videolib.libffmpeg.exceptions.FFmpegNotSupportedException;

import java.lang.reflect.Array;
import java.util.Map;

public class FFmpeg implements FFmpegInterface {
    private static int[] $SWITCH_TABLE$com$videolib$libffmpeg$CpuArch = null;
    private static final long MINIMUM_TIMEOUT = 10000;
    private static FFmpeg instance;
    private final Context context;
    private FFmpegExecuteAsyncTask abcExecuteAsyncTask;
    private FFmpegLoadLibraryAsyncTask abcLoadLibraryAsyncTask;
    private long timeout;

    static int[] $SWITCH_TABLE$com$videolib$libffmpeg$CpuArch() {
        int[] iArr = $SWITCH_TABLE$com$videolib$libffmpeg$CpuArch;
        if (iArr == null) {
            iArr = new int[CpuAr.values().length];
            try {
                iArr[CpuAr.ARMv7.ordinal()] = 2;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[CpuAr.NONE.ordinal()] = 3;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[CpuAr.x86.ordinal()] = 1;
            } catch (NoSuchFieldError e3) {
            }
            $SWITCH_TABLE$com$videolib$libffmpeg$CpuArch = iArr;
        }
        return iArr;
    }

    static {
        instance = null;
    }

    private FFmpeg(Context context) {
        this.timeout = Long.MAX_VALUE;
        this.context = context.getApplicationContext();
    }

    public static FFmpeg getInstance(Context context) {
        if (instance == null) {
            instance = new FFmpeg(context);
        }
        return instance;
    }

    public void loadBinary(
            FFmpegLoadBinaryResponseHandler ffmpegLoadBinaryResponseHandler)
            throws FFmpegNotSupportedException {
        String cpuArchNameFromAssets = null;
        switch ($SWITCH_TABLE$com$videolib$libffmpeg$CpuArch()[CpuArchHelper
                .getCpuArch().ordinal()]) {
            case 1:
                cpuArchNameFromAssets = "x86";
                break;
            case 2:
                cpuArchNameFromAssets = "armeabi-v7a";
                break;
            case 3:
                throw new FFmpegNotSupportedException("Device not supported");
        }
        if (TextUtils.isEmpty(cpuArchNameFromAssets)) {
            throw new FFmpegNotSupportedException("Device not supported");
        }
        this.abcLoadLibraryAsyncTask = new FFmpegLoadLibraryAsyncTask(
                this.context, cpuArchNameFromAssets,
                ffmpegLoadBinaryResponseHandler);
        this.abcLoadLibraryAsyncTask.execute(new Void[0]);
    }

    public void execute(Map<String, String> environvenmentVars, String[] cmd,
                        FFmpegExecuteResponseHandler ffmpegExecuteResponseHandler)
            throws FFmpegCommandAlreadyRunningException {
        if (this.abcExecuteAsyncTask != null
                && !this.abcExecuteAsyncTask.isProcessCompleted()) {
            throw new FFmpegCommandAlreadyRunningException(
                    "FFmpeg command is already running, you are only allowed to run single command at a time");
        } else if (cmd.length != 0) {
            this.abcExecuteAsyncTask = new FFmpegExecuteAsyncTask(
                    (String[]) concatenate(new String[]{FileUtils.getFFmpeg(
                            this.context, environvenmentVars)}, cmd),
                    this.timeout, ffmpegExecuteResponseHandler);
            this.abcExecuteAsyncTask.execute(new Void[0]);
        } else {
            throw new IllegalArgumentException("shell command cannot be empty");
        }
    }

    public <T> T[] concatenate(final T[] array, final T[] array2) {
        final int length = array.length;
        final int length2 = array2.length;
        final Object[] array3 = (Object[]) Array.newInstance(array.getClass()
                .getComponentType(), length + length2);
        System.arraycopy(array, 0, array3, 0, length);
        System.arraycopy(array2, 0, array3, length, length2);
        return (T[]) array3;
    }

    public void execute(String[] cmd,
                        FFmpegExecuteResponseHandler ffmpegExecuteResponseHandler)
            throws FFmpegCommandAlreadyRunningException {
        execute(null, cmd, ffmpegExecuteResponseHandler);
    }

    public String getDeviceFFmpegVersion()
            throws FFmpegCommandAlreadyRunningException {
        CommandResult commandResult = new ShellCommand()
                .runWaitFor(new String[]{FileUtils.getFFmpeg(this.context),
                        "-version"});
        if (commandResult.success) {
            return commandResult.output.split(" ")[2];
        }
        return "";
    }

    public String getLibraryFFmpegVersion() {
        return "n2.4.2";
    }

    public boolean isFFmpegCommandRunning() {
        return (this.abcExecuteAsyncTask == null || this.abcExecuteAsyncTask
                .isProcessCompleted()) ? false : true;
    }

    public boolean killRunningProcesses() {
        return Util.killAsync(this.abcLoadLibraryAsyncTask)
                || Util.killAsync(this.abcExecuteAsyncTask);
    }

    public void setTimeout(long timeout) {
        if (timeout >= MINIMUM_TIMEOUT) {
            this.timeout = timeout;
        }
    }
}
