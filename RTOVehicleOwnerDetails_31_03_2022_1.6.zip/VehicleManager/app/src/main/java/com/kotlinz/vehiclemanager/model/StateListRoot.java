package com.kotlinz.vehiclemanager.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class StateListRoot {
    @SerializedName("data")
    public ArrayList<StateList> data;

    public ArrayList<StateList> getData() {
        return data;
    }

    public void setData(ArrayList<StateList> data) {
        this.data = data;
    }
}
