package com.vidsoft.uvideostatus.clasees;

public class CategoryItemClass {
    private String categories;
    private String languages;
    private String status;

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public String getCategories() {
        return this.categories;
    }

    public void setCategories(String str) {
        this.categories = str;
    }

    public String getLanguages() {
        return this.languages;
    }

    public void setLanguages(String str) {
        this.languages = str;
    }
}
