package com.esc.storymaker.mediapicker.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.OnItemTouchListener;

import com.esc.storymaker.R;
import com.esc.storymaker.help.ConnectionDetector;
import com.esc.storymaker.help.Utils;
import com.esc.storymaker.mediapicker.Gallery;
import com.esc.storymaker.mediapicker.adapters.MediaAdapter;
import com.esc.storymaker.mediapicker.utils.ClickListener;
import com.google.android.gms.ads.AdRequest.Builder;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.List;

public class GalleryDetailFrag extends Fragment {
    public static final String mypreference = "myprefadmob";
    public static List<Boolean> selected = new ArrayList();
    private ImageView ImageOverlayadview;
    Activity activity;
    LinearLayout adContainer;
    private AdView bannerAdView;
    private LinearLayout bannerContainer;
    ConnectionDetector connectionDetector;
    int displayad;
    public String from;
    AdView mAdView;
    private MediaAdapter mAdapter;
    private List<String> mediaList = new ArrayList();
    private View rootView;
    private RecyclerView rvDetail;
    SharedPreferences sharedpreferences;
    private TextView tbTitle;
    public String title;
    int whichAdFirst;

    public static class RecyclerTouchListener implements OnItemTouchListener {
        private ClickListener clickListener;
        private GestureDetector gestureDetector;

        public void onRequestDisallowInterceptTouchEvent(boolean z) {
        }

        public void onTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {
        }

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ClickListener clickListener) {
            this.clickListener = clickListener;
            this.gestureDetector = new GestureDetector(context, new SimpleOnGestureListener() {
                public boolean onSingleTapUp(MotionEvent motionEvent) {
                    return true;
                }

                public void onLongPress(MotionEvent motionEvent) {
                    View findChildViewUnder = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());
                    if (findChildViewUnder != null) {
                        if (clickListener != null) {
                            clickListener.onLongClick(findChildViewUnder, recyclerView.getChildPosition(findChildViewUnder));
                        }
                    }
                }
            });
        }

        public boolean onInterceptTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {
            View findChildViewUnder = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());
            if (!(findChildViewUnder == null || this.clickListener == null || !this.gestureDetector.onTouchEvent(motionEvent))) {
                this.clickListener.onClick(findChildViewUnder, recyclerView.getChildPosition(findChildViewUnder));
            }
            return false;
        }
    }

    public static GalleryDetailFrag getInstance(String str, String str2) {
        GalleryDetailFrag galleryDetailFrag = new GalleryDetailFrag();
        galleryDetailFrag.title = str;
        galleryDetailFrag.from = str2;
        return galleryDetailFrag;
    }

    private void init() {
        this.tbTitle = (TextView) this.rootView.findViewById(R.id.tb_title);
        this.tbTitle.setText(this.title);
        this.rootView.findViewById(R.id.tb_back).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                GalleryDetailFrag.this.getActivity().onBackPressed();
            }
        });
        this.mediaList.clear();
        selected.clear();
        if (this.from == null) {
            getActivity().onBackPressed();
        }
        if (this.from.equals("Images")) {
            this.mediaList.addAll(ImagesFrag.imagesList);
            selected.addAll(ImagesFrag.selected);
        } else {
            this.mediaList.addAll(VideosFrag.videosList);
            selected.addAll(VideosFrag.selected);
        }
        this.rvDetail = (RecyclerView) this.rootView.findViewById(R.id.rv_detail);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rootView = layoutInflater.inflate(R.layout.fragment_gallery_detail, viewGroup, false);
        this.sharedpreferences = getActivity().getSharedPreferences("myprefadmob", 0);
        this.activity = getActivity();
        this.connectionDetector = new ConnectionDetector(this.activity.getApplicationContext());
        boolean isConnectingToInternet = this.connectionDetector.isConnectingToInternet();
        this.displayad = this.sharedpreferences.getInt("displayad", 3);
        this.whichAdFirst = this.sharedpreferences.getInt("whichAdFirst", 2);
        this.adContainer = (LinearLayout) this.rootView.findViewById(R.id.adView);
        this.bannerContainer = (LinearLayout) this.rootView.findViewById(R.id.banner_container);
        this.ImageOverlayadview = (ImageView) this.rootView.findViewById(R.id.Image_overlayadview);
        this.ImageOverlayadview.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        if (isConnectingToInternet) {
            int i = this.displayad;
            if (i == 1) {
                showHideG();
            } else if (i == 2) {
                showHideF();
            } else {
                showHideG();
                showHideF();
            }
        } else {
            this.rootView.findViewById(R.id.adLAyout).setVisibility(View.GONE);
        }
        init();
        populateRecyclerView();
        return this.rootView;
    }

    private void populateRecyclerView() {
        if (this.from.equals("Images")) {
            this.mAdapter = new MediaAdapter(getActivity(), this.mediaList, selected, false);
        } else {
            this.mAdapter = new MediaAdapter(getActivity(), this.mediaList, selected, true);
        }
        this.rvDetail.setLayoutManager(new GridLayoutManager(getContext(), 3));
        this.rvDetail.getItemAnimator().setChangeDuration(0);
        this.rvDetail.setAdapter(this.mAdapter);
        this.rvDetail.addOnItemTouchListener(new RecyclerTouchListener(getContext(), this.rvDetail, new ClickListener() {
            public void onLongClick(View view, int i) {
            }

            public void onClick(View view, int i) {
                ((Gallery) GalleryDetailFrag.this.getActivity()).sendResult((String) GalleryDetailFrag.this.mediaList.get(i));
            }
        }));
    }


    public void showHideG() {
        /*if (new Utils(this.activity).bId() != null) {
            AdView adView = this.bannerAdView;
            if (adView != null) {
                adView.destroy();
                this.bannerAdView = null;
            }
            addBannerLoding();
            this.bannerContainer.setVisibility(View.GONE);
            this.adContainer.setVisibility(View.VISIBLE);
            checkDisplayOverlayBannerG();
        } else if (new Utils(this.activity).fbadId() != null) {
            com.google.android.gms.ads.AdView adView2 = this.mAdView;
            if (adView2 != null) {
                adView2.destroy();
                this.mAdView = null;
            }
            addBannerLodingFB();
            this.adContainer.setVisibility(View.GONE);
            this.bannerContainer.setVisibility(View.VISIBLE);
            checkDisplayOverlayBannerFB();
        } else {
            this.adContainer.setVisibility(View.GONE);
            this.bannerContainer.setVisibility(View.GONE);
            this.rootView.findViewById(R.id.adLAyout).setVisibility(View.GONE);
        }*/
    }


    public void checkDisplayOverlayBannerG() {
        if (new Utils(this.activity).checkTimeB()) {
            this.ImageOverlayadview.setVisibility(View.GONE);
        } else {
            this.ImageOverlayadview.setVisibility(View.VISIBLE);
        }
    }


    public void checkDisplayOverlayBannerFB() {
        if (new Utils(this.activity).checkTimeBf()) {
            this.ImageOverlayadview.setVisibility(View.GONE);
        } else {
            this.ImageOverlayadview.setVisibility(View.VISIBLE);
        }
    }


    public void showHideF() {
/*        if (new Utils(this.activity).fbbanneradId() != null) {
            com.google.android.gms.ads.AdView adView = this.mAdView;
            if (adView != null) {
                adView.destroy();
            }
            checkDisplayOverlayBannerFB();
            addBannerLodingFB();
            this.adContainer.setVisibility(8);
            this.bannerContainer.setVisibility(0);
        } else if (new Utils(this.activity).bId() != null) {
            AdView adView2 = this.bannerAdView;
            if (adView2 != null) {
                adView2.destroy();
                this.bannerAdView = null;
            }
            checkDisplayOverlayBannerG();
            addBannerLoding();
            this.bannerContainer.setVisibility(8);
            this.adContainer.setVisibility(0);
        } else {
            this.adContainer.setVisibility(8);
            this.bannerContainer.setVisibility(8);
            this.rootView.findViewById(R.id.adLAyout).setVisibility(8);
        }*/
    }

    private void addBannerLodingFB() {
       /* AdView adView = this.bannerAdView;
        if (adView != null) {
            adView.destroy();
            this.bannerAdView = null;
        }
        if (this.bannerContainer.getChildCount() > 0) {
            this.bannerContainer.removeAllViews();
        }
        Context context = this.activity;
        this.bannerAdView = new AdView(context, new Utils(context).fbbanneradId(), AdSize.BANNER_HEIGHT_50);
        AdSettings.addTestDevice("fa3be27b-20b9-4d8d-9bf1-c9724a55c6fb");
        this.bannerContainer.addView(this.bannerAdView);
        this.bannerAdView.setAdListener(new AdListener() {
            public void onLoggingImpression(Ad ad) {
            }

            public void onError(Ad ad, AdError adError) {
                GalleryDetailFrag.this.bannerAdView;
                GalleryDetailFrag.this.showHideG();
            }

            public void onAdLoaded(Ad ad) {
                GalleryDetailFrag.this.bannerAdView;
            }

            public void onAdClicked(Ad ad) {
                GalleryDetailFrag.this.ImageOverlayadview.setVisibility(0);
                new Utils(GalleryDetailFrag.this.activity).setLastTimeBf();
            }
        });
        this.bannerAdView.loadAd();*/
    }

    public void addBannerLoding() {
       /* if (this.adContainer.getChildCount() > 0) {
            this.adContainer.removeAllViews();
        }
        this.mAdView = new com.google.android.gms.ads.AdView(this.activity);
        this.mAdView.setAdSize(com.google.android.gms.ads.AdSize.BANNER);
        this.mAdView.setAdUnitId(new Utils(this.activity).bId());
        this.adContainer.addView(this.mAdView);
        this.mAdView.loadAd(new Builder().addTestDevice("B3EEABB8EE11C2BE770B684D95219ECB").addTestDevice("6EE36877D3E7CA526E12D0D16E87D51D").build());
        this.mAdView.setAdListener(new com.google.android.gms.ads.AdListener() {
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
                GalleryDetailFrag.this.showHideF();
            }

            public void onAdClosed() {
                super.onAdClosed();
            }

            public void onAdLoaded() {
                super.onAdLoaded();
            }

            public void onAdLeftApplication() {
                super.onAdLeftApplication();
                GalleryDetailFrag.this.ImageOverlayadview.setVisibility(0);
                new Utils(GalleryDetailFrag.this.activity).setLastTimeB();
            }
        });*/
    }

   /* public void onDestroy() {
        super.onDestroy();
        AdView adView = this.bannerAdView;
        if (adView != null) {
            adView.destroy();
            this.bannerAdView = null;
        }
    }*/
}
