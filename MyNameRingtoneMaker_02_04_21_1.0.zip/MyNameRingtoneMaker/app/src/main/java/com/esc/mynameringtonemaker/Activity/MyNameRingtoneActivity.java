package com.esc.mynameringtonemaker.Activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.esc.mynameringtonemaker.Adapter.PrefixPostfixAdapter;
import com.esc.mynameringtonemaker.Common.ItemClickListener;
import com.esc.mynameringtonemaker.Common.Methods;
import com.esc.mynameringtonemaker.Model.RingtoneModel;
import com.esc.mynameringtonemaker.R;
import com.esc.mynameringtonemaker.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class MyNameRingtoneActivity extends AppCompatActivity implements OnClickListener {

    private Activity activity;
    private Button btnPlay;
    private Button btnPostfix;
    private Button btnPrefix;
    private Button btnSave;
    private Button btnShare;
    private EditText etName;
    private ArrayList<String> listPostfix = new ArrayList();
    private ArrayList<String> listPrefix = new ArrayList();
    private String name;
    private String postfix;
    private String prefix;
    private SeekBar sbVolume;
    private TextToSpeech textToSpeech;
    private TextView tvPostfix;
    private TextView tvPrefix;
    private TextView tvVolume;
    private ImageView iv_back;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int Adid;

    class SaveRingtone extends AsyncTask<Void, Void, Boolean> {
        String destination;
        String fileName;
        ProgressDialog progressDialog = null;

        SaveRingtone() {
        }

        public void onPreExecute() {
            ProgressDialog progressDialog = new ProgressDialog(MyNameRingtoneActivity.this.activity);
            this.progressDialog = progressDialog;
            progressDialog.setMessage("Please Wait , Creating Ringtone ...");
            this.progressDialog.setCancelable(false);
            this.progressDialog.show();
        }

        public Boolean doInBackground(Void... voidArr) {
            StringBuilder stringBuilder = new StringBuilder();
            String str = "None";
            if (!MyNameRingtoneActivity.this.prefix.equals(str)) {
                stringBuilder.append(MyNameRingtoneActivity.this.prefix);
            }
            if (!MyNameRingtoneActivity.this.name.equals("")) {
                stringBuilder.append(MyNameRingtoneActivity.this.name);
            }
            if (!MyNameRingtoneActivity.this.postfix.equals(str)) {
                stringBuilder.append(MyNameRingtoneActivity.this.postfix);
            }
            HashMap hashMap = new HashMap();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(MyNameRingtoneActivity.this.name);
            stringBuilder2.append("_");
            stringBuilder2.append(System.currentTimeMillis());
            stringBuilder2.append(".mp3");
            this.fileName = stringBuilder2.toString();
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(Methods.getDirectory("Ringtone"));
            stringBuilder2.append("/");
            stringBuilder2.append(this.fileName);
            this.destination = stringBuilder2.toString();
            hashMap.put("utteranceId", stringBuilder.toString());
            MyNameRingtoneActivity.this.textToSpeech.synthesizeToFile(stringBuilder.toString(), hashMap, this.destination);
            return Boolean.valueOf(true);
        }

        public void onPostExecute(Boolean bool) {
            ProgressDialog progressDialog = this.progressDialog;
            if (progressDialog != null && progressDialog.isShowing()) {
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        SaveRingtone.this.progressDialog.dismiss();
                        ArrayList arrayList = new ArrayList();
                        RingtoneModel ringtoneModel = new RingtoneModel();
                        ringtoneModel.setName(SaveRingtone.this.fileName);
                        ringtoneModel.setMp3Url(SaveRingtone.this.destination);
                        arrayList.add(ringtoneModel);
                        Intent intent = new Intent(MyNameRingtoneActivity.this.activity, RingtonePlayerActivity.class);
                        intent.putExtra("list", arrayList);
                        intent.putExtra("selectedPos", 0);
                        MyNameRingtoneActivity.this.startActivity(intent);
                    }
                }, 4000);
            }
        }
    }

    class ShareRingtone extends AsyncTask<Void, Void, Boolean> {
        String destination;
        ProgressDialog progressDialog = null;

        ShareRingtone() {
        }

        public void onPreExecute() {
            ProgressDialog progressDialog = new ProgressDialog(MyNameRingtoneActivity.this.activity);
            this.progressDialog = progressDialog;
            progressDialog.setMessage("Please Wait , Creating Ringtone ...");
            this.progressDialog.setCancelable(false);
            this.progressDialog.show();
        }

        public Boolean doInBackground(Void... voidArr) {
            StringBuilder stringBuilder = new StringBuilder();
            String str = "None";
            if (!MyNameRingtoneActivity.this.prefix.equals(str)) {
                stringBuilder.append(MyNameRingtoneActivity.this.prefix);
            }
            if (!MyNameRingtoneActivity.this.name.equals("")) {
                stringBuilder.append(MyNameRingtoneActivity.this.name);
            }
            if (!MyNameRingtoneActivity.this.postfix.equals(str)) {
                stringBuilder.append(MyNameRingtoneActivity.this.postfix);
            }
            File file = new File(Methods.getDirectory("Ringtone"));
            HashMap hashMap = new HashMap();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(file);
            stringBuilder2.append("/");
            stringBuilder2.append(MyNameRingtoneActivity.this.name);
            stringBuilder2.append("_");
            stringBuilder2.append(System.currentTimeMillis());
            stringBuilder2.append(".mp3");
            this.destination = stringBuilder2.toString();
            hashMap.put("utteranceId", stringBuilder.toString());
            MyNameRingtoneActivity.this.textToSpeech.synthesizeToFile(stringBuilder.toString(), hashMap, this.destination);
            return Boolean.valueOf(true);
        }

        public void onPostExecute(Boolean bool) {
            ProgressDialog progressDialog = this.progressDialog;
            if (progressDialog != null && progressDialog.isShowing()) {
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ShareRingtone.this.progressDialog.dismiss();
                        try {
                            Intent intent = new Intent(Intent.ACTION_SEND);
                            intent.setType("audio/*");
                            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(ShareRingtone.this.destination));
                            MyNameRingtoneActivity.this.startActivity(Intent.createChooser(intent, "Share File"));
                        } catch (Exception e) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Error :: ");
                            stringBuilder.append(e.getMessage());
                        }
                    }
                }, 3000);
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setSoftInputMode(2);
        setContentView(R.layout.activity_my_name_ringtone);
        this.activity = this;
        loadAd();
        BannerAds();

        this.tvPrefix = (TextView) findViewById(R.id.tvPrefix);
        this.tvPostfix = (TextView) findViewById(R.id.tvPostfix);
        this.btnPrefix = (Button) findViewById(R.id.btnPrefix);
        this.btnPostfix = (Button) findViewById(R.id.btnPostfix);
        this.etName = (EditText) findViewById(R.id.etName);
        this.sbVolume = (SeekBar) findViewById(R.id.sbVolume);
        this.tvVolume = (TextView) findViewById(R.id.tvVolume);
        this.btnPlay = (Button) findViewById(R.id.btnPlay);
        this.btnSave = (Button) findViewById(R.id.btnSave);
        this.btnShare = (Button) findViewById(R.id.btnShare);
        String str = "None";
        this.listPrefix.add(str);
        this.listPrefix.add("Hey");
        this.listPrefix.add("Hi");
        this.listPrefix.add("Mister");
        this.listPrefix.add("Miss");
        this.listPrefix.add("Doctor");
        this.listPrefix.add("Dear");
        this.listPrefix.add("Excuse me");
        this.listPrefix.add("Officer");
        this.listPrefix.add("Detective");
        this.listPrefix.add("Cornel");
        this.listPrefix.add("Chief");
        this.listPrefix.add("What’s up");
        this.listPostfix.add(str);
        this.listPostfix.add("Your Phone is ringing , please answer the phone");
        this.listPostfix.add("Please answer the phone");
        this.listPostfix.add("Your phone is ringing");
        this.listPostfix.add("Please pick up call");
        this.listPostfix.add("Someone is calling you, take your phone");
        this.listPostfix.add("Please receive your call");
        this.listPostfix.add("Please check your phone, Call is receiving");
        this.listPostfix.add("Your phone is ringing please take a look");
        this.prefix = (String) this.listPrefix.get(1);
        this.name = "";
        this.postfix = (String) this.listPostfix.get(1);
        this.tvPrefix.setText(this.prefix);
        this.tvPostfix.setText(this.postfix);
        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitial !=null && interstitial.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                Adid = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                }else {
                    startActivity(new Intent(MyNameRingtoneActivity.this, HomeActivity.class));
                    finish();
                }
            }
        });

        this.etName.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                MyNameRingtoneActivity.this.name = charSequence.toString();
            }
        });
        final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        float streamVolume = ((float) (audioManager.getStreamVolume(3) * 100)) / 15.0f;
        TextView textView = this.tvVolume;
        StringBuilder stringBuilder = new StringBuilder();
        int i = (int) streamVolume;
        stringBuilder.append(i);
        stringBuilder.append("%");
        textView.setText(stringBuilder.toString());
        this.sbVolume.setProgress(i);
        this.sbVolume.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                float f = ((float) (i * 15)) / 100.0f;
                TextView access$100 = MyNameRingtoneActivity.this.tvVolume;
                StringBuilder stringBuilder = new StringBuilder(String.valueOf(i));
                stringBuilder.append("%");
                access$100.setText(stringBuilder.toString());
                MyNameRingtoneActivity.this.setVolumeControlStream(3);
                audioManager.setStreamVolume(3, (int) f, 0);
            }
        });
        this.textToSpeech = new TextToSpeech(this.activity, new OnInitListener() {
            public void onInit(int i) {
                if (i == 0) {
                    i = MyNameRingtoneActivity.this.textToSpeech.setLanguage(Locale.US);
                    if (i == -1 || i == -2) {
                        Toast.makeText(MyNameRingtoneActivity.this.activity, "This Language is not supported", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
        this.btnPrefix.setOnClickListener(this);
        this.btnPostfix.setOnClickListener(this);
        this.btnPlay.setOnClickListener(this);
        this.btnSave.setOnClickListener(this);
        this.btnShare.setOnClickListener(this);
    }

    public void onClick(View view) {
        int id = view.getId();
        String str = "Please enter name";
        String str2 = "";
        if (id != R.id.btnShare) {
            switch (id) {
                case R.id.btnPlay:
                    StringBuilder stringBuilder = new StringBuilder();
                    str = "None";
                    if (!this.prefix.equals(str)) {
                        stringBuilder.append(this.prefix);
                    }
                    if (!this.name.equals(str2)) {
                        stringBuilder.append(this.name);
                    }
                    if (!this.postfix.equals(str)) {
                        stringBuilder.append(this.postfix);
                    }
                    this.textToSpeech.speak(stringBuilder.toString(), 0, null);
                    return;
                case R.id.btnPostfix:
                    Methods.alertDialog(this.activity, R.layout.layout_dialog_prefix_postfix, new Methods.DialogCreated() {
                        public void onDialogCreated(final AlertDialog alertDialog) {
                            RecyclerView recyclerView = (RecyclerView) alertDialog.findViewById(R.id.recyclerView);
                            recyclerView.setLayoutManager(new LinearLayoutManager(MyNameRingtoneActivity.this.activity));
                            recyclerView.setAdapter(new PrefixPostfixAdapter(MyNameRingtoneActivity.this.activity, MyNameRingtoneActivity.this.listPostfix, new ItemClickListener() {
                                public void onItemClick(View view, int i) {
                                    MyNameRingtoneActivity.this.postfix = (String) MyNameRingtoneActivity.this.listPostfix.get(i);
                                    MyNameRingtoneActivity.this.tvPostfix.setText(MyNameRingtoneActivity.this.postfix);
                                    alertDialog.dismiss();
                                }
                            }));
                        }
                    });
                    return;
                case R.id.btnPrefix:
                    Methods.alertDialog(this.activity, R.layout.layout_dialog_prefix_postfix, new Methods.DialogCreated() {
                        public void onDialogCreated(final AlertDialog alertDialog) {
                            RecyclerView recyclerView = (RecyclerView) alertDialog.findViewById(R.id.recyclerView);
                            recyclerView.setLayoutManager(new LinearLayoutManager(MyNameRingtoneActivity.this.activity));
                            recyclerView.setAdapter(new PrefixPostfixAdapter(MyNameRingtoneActivity.this.activity, MyNameRingtoneActivity.this.listPrefix, new ItemClickListener() {
                                public void onItemClick(View view, int i) {
                                    MyNameRingtoneActivity.this.prefix = (String) MyNameRingtoneActivity.this.listPrefix.get(i);
                                    MyNameRingtoneActivity.this.tvPrefix.setText(MyNameRingtoneActivity.this.prefix);
                                    alertDialog.dismiss();
                                }
                            }));
                        }
                    });
                    return;
                case R.id.btnSave:
                    if (this.name.equals(str2)) {
                        Toast.makeText(this.activity, str, Toast.LENGTH_LONG).show();
                        return;
                    } else {
                        new SaveRingtone().execute(new Void[0]);
                        return;
                    }
                default:
                    return;
            }
        } else if (this.name.equals(str2)) {
            Toast.makeText(this.activity, str, Toast.LENGTH_LONG).show();
        } else {
            new ShareRingtone().execute(new Void[0]);
        }
    }

    private void loadAd() {

        //InterstitialAd
        interstitial = new InterstitialAd(MyNameRingtoneActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        startActivity(new Intent(MyNameRingtoneActivity.this, HomeActivity.class));
                        finish();
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(MyNameRingtoneActivity.this);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(MyNameRingtoneActivity.this);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(MyNameRingtoneActivity.this, HomeActivity.class));
        finish();
    }
}
