package com.kotlinz.videoCollage.flying.poiphoto.ui;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.flying.poiphoto.Configure;
import com.kotlinz.videoCollage.flying.poiphoto.PhotoManager;
import com.kotlinz.videoCollage.flying.poiphoto.VideoManager;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Album;
import com.kotlinz.videoCollage.flying.poiphoto.ui.adapter.AlbumAdapter;
import com.kotlinz.videoCollage.flying.poiphoto.ui.custom.DividerLine;
import com.kotlinz.videoeditor.R;

import java.util.List;
import java.util.Objects;

public class AlbumFragment extends Fragment {
    ImageView back;
    private String from;
    private AlbumAdapter mAlbumAdapter;
    RecyclerView mAlbumList;
    private PhotoManager mPhotoManager;
    private VideoManager mVideoManager;

    private class AlbumTask extends AsyncTask<Void, Integer, List<Album>> {
        private AlbumTask() {
        }

        AlbumTask(AlbumFragment albumFragment) {
            this();
        }


        public List<Album> doInBackground(Void... voidArr) {
            if (AlbumFragment.this.from.equalsIgnoreCase("PickImageActivity")) {
                return AlbumFragment.this.mPhotoManager.getAlbum();
            }
            return AlbumFragment.this.mVideoManager.getAlbum();
        }


        public void onPostExecute(List<Album> list) {
            super.onPostExecute(list);
            AlbumFragment.this.refreshAlbumList(list);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ActionBar supportActionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.hide();
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.from = getArguments().getString("from");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" from  ::  ");
        stringBuilder.append(this.from);
        Log.e("replace", stringBuilder.toString());
        return layoutInflater.inflate(R.layout.poiphoto_fragment_album, viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        init(view);
        String str = "android.permission.WRITE_EXTERNAL_STORAGE";
        String str2 = "android.permission.READ_EXTERNAL_STORAGE";
        if (ContextCompat.checkSelfPermission(getContext(), str) == 0 && ContextCompat.checkSelfPermission(getContext(), str2) == 0) {
            startLoad();
        } else {
            requestPermissions(new String[]{str, str2}, 77);
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 77 && iArr[0] == 0 && iArr[1] == 0) {
            startLoad();
        }
    }

    private void startLoad() {
        new AlbumTask(this).execute(new Void[0]);
    }

    private void init(View view) {
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        if (toolbar != null) {
            initToolbar(toolbar);
        }
        this.back = (ImageView) view.findViewById(R.id.img_album_tool_back);
        this.mAlbumList = (RecyclerView) view.findViewById(R.id.album_list);
        this.mPhotoManager = new PhotoManager(getContext());
        this.mVideoManager = new VideoManager(getContext());
        this.mAlbumList.setLayoutManager(new LinearLayoutManager(getContext()));
        this.mAlbumAdapter = new AlbumAdapter();
        if (this.from.equalsIgnoreCase("PickImageActivity")) {
            this.mAlbumAdapter.setOnItemClickListener(new AlbumAdapter.OnItemClickListener() {
                public void onItemClick(View view, int i) {
                    AlbumFragment.this.getActivity().getSupportFragmentManager().beginTransaction().addToBackStack("Album").replace(R.id.container, PhotoFragment.newInstance(AlbumFragment.this.mAlbumAdapter.getBuckedId(i))).commit();
                }
            });
        } else {
            this.mAlbumAdapter.setOnItemClickListener(new AlbumAdapter.OnItemClickListener() {
                public void onItemClick(View view, int i) {
                    AlbumFragment.this.getActivity().getSupportFragmentManager().beginTransaction().addToBackStack("Album").replace(R.id.container, VideoFragment.newInstance(AlbumFragment.this.mAlbumAdapter.getBuckedId(i))).commit();
                }
            });
        }
        this.mAlbumList.setAdapter(this.mAlbumAdapter);
        this.mAlbumList.addItemDecoration(new DividerLine());
        this.back.setOnClickListener(new OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            public void onClick(View view) {
                ((FragmentActivity) Objects.requireNonNull(AlbumFragment.this.getActivity())).finish();
            }
        });
    }

    private void initToolbar(Toolbar toolbar) {
        Configure configure;
        if (this.from.equalsIgnoreCase("PickImageActivity")) {
            configure = ((PickImageActivity) getActivity()).getConfigure();
        } else {
            configure = ((PickVideoActivity) getActivity()).getConfigure();
        }
        toolbar.setTitleTextColor(configure.getToolbarTitleColor());
        toolbar.setTitle(configure.getAlbumTitle());
        toolbar.setBackgroundColor(configure.getToolbarColor());
    }

    private void refreshAlbumList(List<Album> list) {
        this.mAlbumAdapter.refreshData(list);
    }
}
