package com.vidsoft.videostatusmaker.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView.ScaleType;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.vidsoft.videostatusmaker.Activity.ActivityEditImage;
import com.vidsoft.videostatusmaker.Utils.RoundedImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;

public class EffectAdapter extends Adapter<EffectAdapter.MyViewHolder> {
  Bitmap bitmap;
  String[] strArray_effect;
  Context context;

  public static class MyViewHolder extends ViewHolder {
    public RoundedImageView roundedImageView;
    public RoundedImageView roundedImageView1;

    public MyViewHolder(View view) {
      super(view);
      this.roundedImageView = (RoundedImageView) view.findViewById(R.id.img);
      this.roundedImageView1 = (RoundedImageView) view.findViewById(R.id.selimg);
    }
  }

  public EffectAdapter(Context context, String[] strArr, Bitmap bitmap) {
    this.context = context;
    this.strArray_effect = strArr;
    this.bitmap = ResizeBitmap(bitmap);
  }

  public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
    return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter, viewGroup, false));
  }

  public void onBindViewHolder(MyViewHolder myViewHolder, final int i) {
    RequestManager with = Glide.with(this.context);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("file:///android_asset/strArray_effect/");
    stringBuilder.append(this.strArray_effect[i]);
    with.load(Uri.parse(stringBuilder.toString())).into(myViewHolder.roundedImageView);
    if (i == 0) {
      myViewHolder.roundedImageView1.setImageDrawable(null);
    } else {
      myViewHolder.roundedImageView1.setImageBitmap(this.bitmap);
      myViewHolder.roundedImageView1.setScaleType(ScaleType.CENTER_CROP);
    }
    float f = (float) ((this.context.getResources().getDisplayMetrics().widthPixels * 10) / 1080);
    myViewHolder.roundedImageView1.setCornerRadius(f);
    myViewHolder.roundedImageView.setCornerRadius(f);
    myViewHolder.itemView.setOnClickListener(new OnClickListener() {
      public void onClick(View view) {
        ((ActivityEditImage) EffectAdapter.this.context).setEffect(i);
      }
    });
  }

  public int getItemCount() {
    return this.strArray_effect.length;
  }

  public Bitmap ResizeBitmap(final Bitmap bitmap) {
    final int width = bitmap.getWidth();
    final int height = bitmap.getHeight();
    int n = 200;
    int n3;
    if (width >= height) {
      final int n2 = height * 200 / width;
      if ((n3 = n2) > 200) {
        final int n4 = 40000 / n2;
        return Bitmap.createScaledBitmap(bitmap, n4, n, true);
      }
    }
    else {
      final int n5 = width * 200 / height;
      final int n4;
      if ((n4 = n5) <= 200) {
        return Bitmap.createScaledBitmap(bitmap, n4, n, true);
      }
      n3 = 40000 / n5;
    }
    n = n3;
    int n4 = 200;
    return Bitmap.createScaledBitmap(bitmap, n4, n, true);
  }
}
