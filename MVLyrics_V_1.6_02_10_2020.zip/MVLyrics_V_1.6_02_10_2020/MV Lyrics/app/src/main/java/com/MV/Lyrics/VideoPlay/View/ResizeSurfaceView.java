package com.MV.Lyrics.VideoPlay.View;

import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;


public class ResizeSurfaceView extends SurfaceView {
    private static final int MARGIN_DP = 0;
    public ResizeSurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ResizeSurfaceView(Context context) {
        super(context);
    }


    public void adjustSize(int surfaceViewWidth, int surfaceViewHeight, int videoWidth, int videoHeight) {
        if (videoWidth > 0 && videoHeight > 0) {
            ViewGroup.LayoutParams lp = getLayoutParams();
            DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
            int windowWidth = displayMetrics.widthPixels;
            int windowHeight = displayMetrics.heightPixels;
            int margin = (int) (getContext().getResources().getDisplayMetrics().density* MARGIN_DP);
            float videoRatio = 0;
            if (windowWidth < windowHeight) {
                videoRatio = ((float) (videoWidth)) / videoHeight;
            } else {
                videoRatio = ((float) (videoHeight)) / videoWidth;
            }
            if (windowWidth < windowHeight) {
                if (videoWidth > videoHeight) {
                    if (surfaceViewWidth / videoRatio > surfaceViewHeight) {
                        lp.height = surfaceViewHeight;
                        lp.width = (int) (surfaceViewHeight * videoRatio);
                    } else {
                        lp.height = (int) (surfaceViewWidth / videoRatio);
                        lp.width = surfaceViewWidth;
                    }
                } else if (videoWidth <= videoHeight) {
                    if (surfaceViewHeight * videoRatio > surfaceViewWidth) {
                        lp.height = (int) (surfaceViewWidth / videoRatio);
                        lp.width = surfaceViewWidth;
                    } else {
                        lp.height = surfaceViewHeight;
                        lp.width = (int) (surfaceViewHeight * videoRatio);
                    }
                }
            } else if (windowWidth > windowHeight) {
                if (videoWidth > videoHeight) {
                    if (windowWidth * videoRatio > videoHeight) {
                        lp.height = windowHeight - margin;
                        lp.width = (int) ((windowHeight - margin) / videoRatio);
                    } else {
                        lp.height = (int) (windowWidth * videoRatio);
                        lp.width = windowWidth;
                    }
                } else if (videoWidth < videoHeight) {
                    lp.width = (int) ((windowHeight - margin) / videoRatio);
                    lp.height = windowHeight - margin;
                } else {
                    lp.height = windowHeight- margin;
                    lp.width = lp.height;
                }
            }
            setLayoutParams(lp);
            getHolder().setFixedSize(videoWidth, videoHeight);
            setVisibility(View.VISIBLE);
        }
    }
}