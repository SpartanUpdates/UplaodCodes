package com.videozoneinc.musicvideoeditor.util;

import android.app.Activity;
import android.graphics.BitmapFactory;

import com.videozoneinc.musicvideoeditor.R;

import org.insta.IF1977Filter;
import org.insta.IFBrannanFilter;
import org.insta.IFEarlybirdFilter;
import org.insta.IFInkwellFilter;
import org.insta.IFSierraFilter;
import org.insta.IFToasterFilter;
import org.insta.IFXprollFilter;
import org.insta.InstaFilter;

import jp.co.cyberagent.android.gpuimage.GPUImageContrastFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageLookupFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageScreenBlendFilter;

public class FilterHelper extends GPUImageFilter {
    private static final int FILTER_NUM = 12;
    private static InstaFilter[] filters;

    public static void destroyFilters() {
        if (filters != null) {
            for (int i = 0; i < filters.length; i++) {
                try {
                    if (filters[i] != null) {
                        filters[i].destroy();
                        filters[i] = null;
                    }
                } catch (Throwable th) {
                }
            }
        }
    }

    public static GPUImageFilter applyFilter(int position, Activity activity) {
        GPUImageLookupFilter gpuImageLookupFilter = new GPUImageLookupFilter();
        switch (position) {
            case 0 /*0*/:
                return new GPUImageFilter();
            case 1/*1*/:
                return new IF1977Filter(activity);
            case 2 /*2*/:
                return new IFBrannanFilter(activity);
            case 3/*3*/:
                return new IFEarlybirdFilter(activity);
            case 4/*4*/:
                return new IFInkwellFilter(activity);
            case 5 /*5*/:
                return new IFSierraFilter(activity);
            case 6/*6*/:
                return new IFToasterFilter(activity);
            case 7 /*7*/:
                return new IFXprollFilter(activity);
            case 8/*8*/:
                return new GPUImageContrastFilter();
            case 9/*9*/:
                return new GPUImageScreenBlendFilter();
            case 10 /*10*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf6));
                return gpuImageLookupFilter;
            case 11/*11*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf8));
                return gpuImageLookupFilter;
            case 12 /*12*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf10));
                return gpuImageLookupFilter;
            case 13/*13*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf11));
                return gpuImageLookupFilter;
            case 14/*14*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf12));
                return gpuImageLookupFilter;
            case 15/*15*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf14));
                return gpuImageLookupFilter;
            case 16/*16*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf17));
                return gpuImageLookupFilter;
            case 17 /*17*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf18));
                return gpuImageLookupFilter;
            case 18 /*18*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf24));
                return gpuImageLookupFilter;
            case 19 /*19*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf28));
                return gpuImageLookupFilter;
            case 20 /*20*/:
                gpuImageLookupFilter.setBitmap(BitmapFactory.decodeResource(activity.getResources(), R.drawable.pf32));
                return gpuImageLookupFilter;

            default:
                return null;
        }
    }
}
