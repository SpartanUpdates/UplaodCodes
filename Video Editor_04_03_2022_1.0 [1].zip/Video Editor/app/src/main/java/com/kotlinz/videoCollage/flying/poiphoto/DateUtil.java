package com.kotlinz.videoCollage.flying.poiphoto;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateUtil {
    public static String formatDate(long j) {
        return new SimpleDateFormat("yyyy年MM月dd日", Locale.CHINA).format(new Date(j));
    }
}
