package com.kotlinz.videoCollage.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.internal.view.SupportMenu;

import com.kotlinz.videoCollage.other.Util;


public class GuidelineImageView extends AppCompatImageView {
    boolean isInCenterX = false;
    boolean isInCenterY = false;
    private Context mContext;
    private Paint paint;

    public GuidelineImageView(Context context) {
        super(context);
        intiView(context);
    }

    public GuidelineImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        intiView(context);
    }

    public GuidelineImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        intiView(context);
    }

    private void intiView(Context context) {
        this.mContext = context;
        Paint paint = new Paint();
        this.paint = paint;
        paint.setColor(-1);
        this.paint.setStrokeWidth((float) Util.dpToPx(context, 2));
        this.paint.setPathEffect(new DashPathEffect(new float[]{5.0f, 5.0f}, 1.0f));
        this.paint.setStyle(Style.STROKE);
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = canvas.getWidth();
        int height = canvas.getHeight();
        this.paint.setColor(-1);
        int i = width / 4;
        Canvas canvas2 = canvas;
        int i2 = height;
        drawLine(canvas2, i, 0, i, i2, this.paint);
        int i3 = width / 2;
        drawLine(canvas2, i3, 0, i3, i2, this.paint);
        int i4 = (width * 3) / 4;
        drawLine(canvas2, i4, 0, i4, i2, this.paint);
        int i5 = height / 4;
        int i6 = width;
        drawLine(canvas2, 0, i5, i6, i5, this.paint);
        int i7 = height / 2;
        drawLine(canvas2, 0, i7, i6, i7, this.paint);
        int i8 = (height * 3) / 4;
        drawLine(canvas2, 0, i8, i6, i8, this.paint);
        this.paint.setColor(-16777216);
        i6 = i + 2;
        int i9 = i8;
        drawLine(canvas2, i6, 0, i6, height, this.paint);
        if (this.isInCenterX) {
            this.paint.setColor(SupportMenu.CATEGORY_MASK);
            this.isInCenterX = false;
        }
        i6 = i3 + 2;
        canvas2 = canvas;
        i2 = height;
        drawLine(canvas2, i6, 0, i6, i2, this.paint);
        this.paint.setColor(-16777216);
        i6 = i4 + 2;
        drawLine(canvas2, i6, 0, i6, i2, this.paint);
        i2 = i5 + 2;
        drawLine(canvas2, 0, i2, width, i2, this.paint);
        if (this.isInCenterY) {
            this.paint.setColor(SupportMenu.CATEGORY_MASK);
            this.isInCenterY = false;
        }
        i2 = i7 + 2;
        canvas2 = canvas;
        i6 = width;
        drawLine(canvas2, 0, i2, i6, i2, this.paint);
        this.paint.setColor(-16777216);
        i2 = i9 + 2;
        drawLine(canvas2, 0, i2, i6, i2, this.paint);
    }

    public void setCenterValues(boolean z, boolean z2) {
        this.isInCenterX = z;
        this.isInCenterY = z2;
        invalidate();
    }

    private void drawLine(Canvas canvas, int i, int i2, int i3, int i4, Paint paint) {
        Path path = new Path();
        path.moveTo((float) i, (float) i2);
        path.lineTo((float) i3, (float) i4);
        canvas.drawPath(path, paint);
    }
}
