package com.unitedvideos.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.unitedvideos.AVLoadingView.AVLoadingIndicatorView;
import com.unitedvideos.Download.ThemeDownload;
import com.unitedvideos.Model.ThemeHorizontalModel;
import com.unitedvideos.R;
import com.unitedvideos.Retrofit.APIClient;
import com.unitedvideos.Retrofit.APIInterface;
import com.unitedvideos.Retrofit.AppConstant;
import com.unitedvideos.Utils.Utils;
import com.unitedvideos.activity.HomeActivity;
import com.google.gson.JsonObject;
import com.root.unity.AndroidUnityCall;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThemeCategoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int ITEM_TYPE_DATA = 0;
    public static final int ITEM_TYPE_AD = 1;
    public int e = -1;
    public int f = -1;
    protected int ScalPosition = -1;
    private Context mContext;
    private ArrayList<ThemeHorizontalModel> themeCategoryList;
    private HomeActivity ActivityOfTheme;
    private ColorDrawable[] bgThumb = new ColorDrawable[]{new ColorDrawable(Color.parseColor("#9ACCCD")), new ColorDrawable(Color.parseColor("#8FD8A0")), new ColorDrawable(Color.parseColor("#CBD890")), new ColorDrawable(Color.parseColor("#DACC8F")), new ColorDrawable(Color.parseColor("#D9A790")), new ColorDrawable(Color.parseColor("#D18FD9")), new ColorDrawable(Color.parseColor("#FF6772")), new ColorDrawable(Color.parseColor("#4A5F07"))};

    public ThemeCategoryAdapter(Context mContext, ArrayList<ThemeHorizontalModel> themeCategoryList) {
        this.mContext = mContext;
        this.ActivityOfTheme = (HomeActivity) mContext;
        this.themeCategoryList = themeCategoryList;
    }


    private ColorDrawable getRandomDrawbleColor() {
        int idx = new Random().nextInt(bgThumb.length);
        return bgThumb[idx];
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {

        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_theme_item, viewGroup, false);
        return new ThemeViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof ThemeViewHolder) {
            final ThemeViewHolder viewHolder = (ThemeViewHolder) holder;
            final ThemeHorizontalModel themelModel = themeCategoryList.get(position);

            if (position > ScalPosition) {
                Animation scaleAnimation = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, 1, 0.5f, 1, 0.5f);
                scaleAnimation.setDuration(400);
                viewHolder.itemView.startAnimation(scaleAnimation);
                ScalPosition = position;
            }
            Glide.with(mContext).load(themelModel.getImage()).placeholder(getRandomDrawbleColor()).diskCacheStrategy(DiskCacheStrategy.ALL).into(viewHolder.iv_thumb);
            if (!themelModel.isAvailableOffline) {
                if (themelModel.isDownloading) {
                    viewHolder.ivDownload.setVisibility(View.GONE);
//                    viewHolder.ivUseTheme.setVisibility(View.GONE);
                    viewHolder.ThemeDownProgress.setVisibility(View.VISIBLE);
                } else {
                    viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                    viewHolder.ivDownload.setVisibility(View.VISIBLE);
//                    viewHolder.ivUseTheme.setVisibility(View.GONE);
                }
            } else {
                viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                viewHolder.ivDownload.setVisibility(View.GONE);
//                viewHolder.ivUseTheme.setVisibility(View.VISIBLE);
            }
            if (themelModel.getIsNewRealise().equals("1")){
                int UnityBundeldSize = Integer.parseInt(themelModel.getBundelSize());
                String BundelName = themelModel.getBundelName();
                File BundelPath = new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + BundelName);
                int BundelFileSize = Integer.parseInt(String.valueOf(BundelPath.length()));
                if (BundelFileSize == UnityBundeldSize) {
                    viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                    viewHolder.ivDownload.setVisibility(View.GONE);
                    Log.e("TAG","What's New "+themelModel.getBundelName());
                }
            }

            viewHolder.layoutBottomPanel.setBackground(getRandomDrawbleColor());
            viewHolder.tvThemeName.setText(themelModel.getThemeName());
            viewHolder.tvThemeName.setSelected(true);
//            viewHolder.tvInfo.setText("Image: " + String.valueOf(themelModel.getImg_no_of()));

            viewHolder.cvthemeSelect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DownloadThemeFiles(position, viewHolder.ivDownload, viewHolder.layoutInfo, viewHolder.ThemeDownProgress, viewHolder.indicatorThemeProgress, viewHolder.tvThemeDownProgress, themelModel);
                }
            });

        }
    }


    @Override
    public int getItemCount() {
        return themeCategoryList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return ITEM_TYPE_DATA;
    }


    private void DownloadThemeFiles(int position, ImageView ivDownload, RelativeLayout layoutInfo, LinearLayout themeDownProgress, AVLoadingIndicatorView avLoadingIndicatorView, TextView tvThemeDownprogress, ThemeHorizontalModel themelModel) {
        int UnityBundeldSize = Integer.parseInt(themelModel.getBundelSize());
        String BundelName = themelModel.getBundelName();
        File BundelPath = new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + BundelName);
        int BundelFileSize = Integer.parseInt(String.valueOf(BundelPath.length()));

//        Log.e("TAG","Unity Bundel Size..."+UnityBundeldSize);
//        Log.e("TAG","Bundel Size..."+BundelFileSize);
        AndroidUnityCall.BundelPath = themelModel.getBundelPath();
        AndroidUnityCall.PrefebName = themelModel.getPrefebName();
        AndroidUnityCall.AudioPath = themelModel.getAnimSoundPath();

        AndroidUnityCall.VideoType = themelModel.getVideoType();
        AndroidUnityCall.ImageWidth = themelModel.getImageWidht();
        AndroidUnityCall.ImageHeight = themelModel.getImageHeight();
        AndroidUnityCall.NoofImage = themelModel.getImg_no_of();
//        Log.e("TAG","Downloading..."+themelModel.isDownloading);
//        Log.e("TAG","isAvailableOffline"+themelModel.isAvailableOffline);
        if (new File(Utils.INSTANCE.getThemeFolderPath() + BundelName).exists()) {
            if (BundelFileSize == UnityBundeldSize) {
                if (!themelModel.isDownloading) {
                    if (ActivityOfTheme.mInterstitialAd != null && ActivityOfTheme.mInterstitialAd.isLoaded()) {
                        ActivityOfTheme.id = 100;
                        ActivityOfTheme.mInterstitialAd.show();
                    } else {
                        ActivityOfTheme.ShowBannerAds();
                        AndroidUnityCall.ImageSelection(ActivityOfTheme, themelModel.getImageWidht(), themelModel.getImageHeight(), themelModel.getImg_no_of(), themelModel.getVideoType(), false, "android");
                        ActivityOfTheme.finish();
                    }
                } else {
                    Toast.makeText(mContext, "Please Wait Theme Download Process Running", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    ivDownload.setVisibility(View.GONE);
                    themeDownProgress.setVisibility(View.VISIBLE);
                    avLoadingIndicatorView.smoothToShow();
                    DownloadIncrement(themelModel.getCategoryid(), themelModel.getThemeid());
                    new ThemeDownload(mContext, themelModel.getBundelUrl(), themelModel.getBundelName(), themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), ivDownload, layoutInfo, themeDownProgress, avLoadingIndicatorView, tvThemeDownprogress, themelModel);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                ivDownload.setVisibility(View.GONE);
                themeDownProgress.setVisibility(View.VISIBLE);
                avLoadingIndicatorView.smoothToShow();
                DownloadIncrement(themelModel.getCategoryid(), themelModel.getThemeid());
                new ThemeDownload(mContext, themelModel.getBundelUrl(), themelModel.getBundelName(), themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), ivDownload, layoutInfo, themeDownProgress, avLoadingIndicatorView, tvThemeDownprogress, themelModel);
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void DownloadIncrement(String CatId, String ThemeId) {
        APIInterface apiInterface = APIClient.getClient().create(APIInterface.class);
        Call<JsonObject> call = apiInterface.DownloadIncrement(AppConstant.Token, AppConstant.ApplicationId, CatId, ThemeId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {

                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }


    public class ThemeViewHolder extends RecyclerView.ViewHolder {
        CardView cvthemeSelect;
        ImageView iv_thumb, ivDownload;
        TextView tvThemeName, tvThemeDownProgress;
        //        ImageView ivUseTheme;
        AVLoadingIndicatorView indicatorThemeProgress;
        LinearLayout ThemeDownProgress;
        LinearLayout layoutDownloadMask;
        LinearLayout layoutBottomPanel;
        RelativeLayout layoutInfo;
        TextView tvInfo;

        ThemeViewHolder(View itemView) {
            super(itemView);
            cvthemeSelect = itemView.findViewById(R.id.cv_root_card);
            iv_thumb = itemView.findViewById(R.id.ivThumb);
            ivDownload = itemView.findViewById(R.id.ivThumbDownload);
            tvThemeName = itemView.findViewById(R.id.tvVideoName);
            tvThemeDownProgress = itemView.findViewById(R.id.tvCounter);
            ThemeDownProgress = itemView.findViewById(R.id.ll_theme_down_progress);
            indicatorThemeProgress = itemView.findViewById(R.id.indicator);
//            ivUseTheme = itemView.findViewById(R.id.tvUseTheme);
            layoutDownloadMask = itemView.findViewById(R.id.downloadMask);
            layoutBottomPanel = itemView.findViewById(R.id.ll_bootom_panel);
            layoutInfo = itemView.findViewById(R.id.layout_info);
            tvInfo = itemView.findViewById(R.id.tvInfo);
        }
    }

}
