package com.wavymusic.notification.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.os.Build;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.R;
import com.wavymusic.UnityPlayerActivity;
import com.wavymusic.notification.Model.NotificcationModel;
import com.wavymusic.notification.utils.NotificationConfig;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.io.IOException;
import java.net.URL;

public class MyFirebaseMessagingService extends FirebaseMessagingService {


//    private NotificationUtils notificationUtils;

    @Override
    public void onNewToken(@NonNull String s) {
        super.onNewToken(s);
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        storeRegIdInPref(refreshedToken);
        sendRegistrationToServer(refreshedToken);
        Intent registrationComplete = new Intent(NotificationConfig.REGISTRATION_COMPLETE);
        registrationComplete.putExtra("token", refreshedToken);
        LocalBroadcastManager.getInstance(this).sendBroadcast(registrationComplete);

    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Log.e("TAG", "onMessageReceived" + remoteMessage.getData().toString());
       /* if (remoteMessage.getNotification() != null) {
            handleNotification(remoteMessage.getNotification().getBody());
        }*/
        if (remoteMessage.getData().size() > 0) {
            try {
                JSONObject json = new JSONObject(remoteMessage.getData().toString());
                SetNotificationData(json);
            } catch (Exception NativAdData) {
                NativAdData.printStackTrace();
            }
        }


    }

    private void SetNotificationData(JSONObject json) {
        try {
            JSONObject data = json.getJSONObject("data");
            String title = data.getString("title");
            String message = data.getString("message");
            String imageUrl = data.getString("image");
            String timestamp = data.getString("timestamp");
            JSONObject jsonObject = data.getJSONObject("payload");


            NotificcationModel notificcationModel = new NotificcationModel();
            notificcationModel.setThemeName(jsonObject.getString("themename"));
            notificcationModel.setThemeThumbnail(jsonObject.getString("themethumbnail"));
            notificcationModel.setSongUrl(jsonObject.getString("soundfile"));
            notificcationModel.setSongFileName(jsonObject.getString("soundfilename") + ".mp3");
            notificcationModel.setSoundPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + notificcationModel.getSongFileName());
            notificcationModel.setSongSize(jsonObject.getInt("soundfilesize"));
            notificcationModel.setParticalName(jsonObject.getString("particalname"));
            notificcationModel.setParticalBundelName(jsonObject.getString("particalname") + ".zip");
            notificcationModel.setParticalThumbnail(jsonObject.getString("particalthumbnail"));
            notificcationModel.setParticalBundel(jsonObject.getString("particalbundle"));
            notificcationModel.setBundelPath(new File(Utils.PathOfAssetFolder).getAbsolutePath() + File.separator + notificcationModel.getParticalName() + File.separator + notificcationModel.getParticalName() + ".unity3d");
            notificcationModel.setParticalSize(jsonObject.getInt("particalbundlesize"));
            notificcationModel.setGameobjectName(jsonObject.getString("gameobjectname"));
            notificcationModel.setFromAsset(jsonObject.getBoolean("from_asset"));
            MyApplication.notificcationModels.add(0, notificcationModel);
            int verCode = 1;
            String version = "1.0";
            try {
                PackageInfo pInfo = getApplicationContext().getPackageManager().getPackageInfo(getPackageName(), 0);
                version = pInfo.versionName;
                verCode = pInfo.versionCode;
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }


         /*   if (Float.parseFloat(version) >= Float.parseFloat(jsonObject.getString("minimumversion"))) {
                if (!NotificationUtils.isAppIsInBackground(getApplicationContext())) {
                    Intent pushNotification = new Intent(NotificationConfig.PUSH_NOTIFICATION);
                    pushNotification.putExtra("message", message);
                    Log.e("TAG", "isAppIsInBackground" + imageUrl);
                    LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);
                    NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
                    notificationUtils.playNotificationSound();
                } else {
                    Intent resultIntent = new Intent(getApplicationContext(), NotificationActivity.class);
                    resultIntent.putExtra("message", message);
                    if (TextUtils.isEmpty(imageUrl)) {
                        showNotificationMessage(getApplicationContext(), title, message, timestamp, resultIntent);
                    } else {
                        showNotificationMessageWithBigImage(getApplicationContext(), title, message, timestamp, resultIntent, imageUrl);
                    }
                }
            }*/

            if (Float.parseFloat(version) >= Float.parseFloat(jsonObject.getString("minimumversion"))) {
                sendNotification(title, message,imageUrl);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void sendNotification(String title, String message,String imageUrl) {
        Intent intent = new Intent(this, UnityPlayerActivity.class);
        intent.putExtra("IsFromNotification",true);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, getString(R.string.notification_channel_id))
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setContentIntent(pendingIntent)
                .setContentInfo(title)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_app_lunch))
                .setLights(Color.RED, 1000, 300)
                .setDefaults(Notification.DEFAULT_VIBRATE)
                .setSmallIcon(R.mipmap.ic_app_lunch);

        try {
//            String picture = data.get(NotificationConfig.FCM_PARAM);
            if (imageUrl != null && !"".equals(imageUrl)) {
                URL url = new URL(imageUrl);
                Bitmap bigPicture = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                notificationBuilder.setStyle(
                        new NotificationCompat.BigPictureStyle().bigPicture(bigPicture).setSummaryText(message)
                );
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    getString(R.string.notification_channel_id), NotificationConfig.CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription(NotificationConfig.CHANNEL_DESC);
            channel.setShowBadge(true);
            channel.canShowBadge();
            channel.enableLights(true);
            channel.setLightColor(Color.RED);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{100, 200, 300, 400, 500});

            assert notificationManager != null;
            notificationManager.createNotificationChannel(channel);
        }

        assert notificationManager != null;
        notificationManager.notify(0, notificationBuilder.build());
    }


    private void sendRegistrationToServer(final String token) {
        Log.e("TAG", "sendRegistrationToServer: " + token);
    }

    private void storeRegIdInPref(String token) {
        SharedPreferences pref = getApplicationContext().getSharedPreferences(NotificationConfig.SHARED_PREF, 0);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("regId", token);
        editor.apply();
    }


     /* private void showNotificationMessage(Context context, String title, String message, String timeStamp, Intent intent) {
         notificationUtils = new NotificationUtils(context);
         intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
         notificationUtils.showNotificationMessage(title, message, timeStamp, intent);
     }


     private void showNotificationMessageWithBigImage(Context context, String title, String message, String timeStamp, Intent intent, String imageUrl) {
         notificationUtils = new NotificationUtils(context);
         intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
         notificationUtils.showNotificationMessage(title, message, timeStamp, intent, imageUrl);
     }
 */

    /*  private void handleNotification(String message) {
        if (!NotificationUtils.isAppIsInBackground(getApplicationContext())) {
            Intent pushNotification = new Intent(NotificationConfig.PUSH_NOTIFICATION);
            pushNotification.putExtra("message", message);
            LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);
            NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
            notificationUtils.playNotificationSound();
        }
    }*/

    /*private void SetNotificationData(String result) {
        try {
            JSONObject jsonObj = new JSONObject(result);
            JSONArray jsonArray = jsonObj.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); ++i) {
                final JSONObject jsonObject = jsonArray.getJSONObject(i);
                NotificcationModel notificcationModel = new NotificcationModel();
                notificcationModel.setThemeName(jsonObject.getString("theme_name"));
                notificcationModel.setThemeThumbnail(jsonObject.getString("theme_thumbnail"));
                notificcationModel.setSongUrl(jsonObject.getString("sound_file"));
                notificcationModel.setSongFileName(jsonObject.getString("sound_filename") + ".mp3");
                notificcationModel.setSoundPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + notificcationModel.getSongFileName());
                notificcationModel.setSongSize(jsonObject.getInt("sound_size"));
                notificcationModel.setParticalName(jsonObject.getString("partical_name"));
                notificcationModel.setParticalBundelName(jsonObject.getString("partical_name") + ".zip");
                notificcationModel.setParticalThumbnail(jsonObject.getString("partical_thumbnail"));
                notificcationModel.setParticalBundel(jsonObject.getString("partical_bundle"));
                notificcationModel.setBundelPath(new File(Utils.PathOfAssetFolder).getAbsolutePath() + File.separator + notificcationModel.getParticalName() + File.separator + notificcationModel.getParticalName() + ".unity3d");
                notificcationModel.setParticalSize(jsonObject.getInt("partical_size"));
                notificcationModel.setGameobjectName(jsonObject.getString("game_object_name"));
                MyApplication.notificcationModels.add(notificcationModel);
                if (!NotificationUtils.isAppIsInBackground(getApplicationContext())) {
                    Intent pushNotification = new Intent(Config.PUSH_NOTIFICATION);
                    pushNotification.putExtra("message", notificcationModel.getThemeName());
                    LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);
                    NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
                    notificationUtils.playNotificationSound();
                } else {
                    Intent resultIntent = new Intent(getApplicationContext(), NotificationActivity.class);
                    resultIntent.putExtra("message", notificcationModel.getThemeName());
                    if (TextUtils.isEmpty(notificcationModel.getThemeThumbnail())) {
                        showNotificationMessage(getApplicationContext(), notificcationModel.getThemeName(), notificcationModel.getThemeName(), "timestamp", resultIntent);
                    } else {
                        showNotificationMessageWithBigImage(getApplicationContext(), notificcationModel.getThemeName(), notificcationModel.getThemeName(), "timestamp", resultIntent, notificcationModel.getThemeThumbnail());
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }*/
}