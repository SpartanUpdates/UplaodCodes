package com.kotlinz.festivalstorymaker.App;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.kotlinz.festivalstorymaker.OpenAppAds.AppOpenAdManager;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.activity.CollageMakerActivity;
import com.kotlinz.festivalstorymaker.activity.DashBordActivity;
import com.kotlinz.festivalstorymaker.activity.ExitActivity;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailActivity;
import com.kotlinz.festivalstorymaker.activity.MyPostActivity;
import com.kotlinz.festivalstorymaker.activity.PosterMakerActivity;
import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;
import com.kotlinz.festivalstorymaker.activity.StoryMakerActivity;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;

import java.net.URLConnection;

public class MyApplication extends Application implements Application.ActivityLifecycleCallbacks, LifecycleObserver {

    private static MyApplication instance;
    public static Context mContext;

    public int CatItemPosition;

    private AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;

    public MyApplication() {

    }

    public static Activity activity;
    public static InterstitialAd mInterstitialAd;
    public static int AdsId;
    public static int isShowAd = 0;
    public static int ModuleId;

    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        MyApplication.mContext = this.getApplicationContext();
        this.registerActivityLifecycleCallbacks(this);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        appOpenAdManager = new AppOpenAdManager();
        interstitialAd();
    }

    public static boolean isImageFile(String str) {
        str = URLConnection.guessContentTypeFromName(str);
        return str != null && str.startsWith("image");
    }

    private void interstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, getResources().getString(R.string.InterstitialAd_id), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        requestNewInterstitial();
                                        Intent intent;
                                        switch (AdsId) {
                                            case 1:
                                                intent = new Intent(activity, PosterMakerActivity.class);
                                                intent.putExtra("moduleid", ModuleId);
                                                activity.startActivity(intent);
                                                break;
                                            case 2:
                                                intent = new Intent(activity, StoryMakerActivity.class);
                                                intent.putExtra("IsForm", "Story Maker");
                                                intent.putExtra("moduleid", ModuleId);
                                                activity.startActivity(intent);
                                                break;
                                            case 3:
                                                intent = new Intent(activity, CollageMakerActivity.class);
                                                intent.putExtra("moduleid", ModuleId);
                                                activity.startActivity(intent);
                                                break;
                                            case 6:
                                                intent = new Intent(activity, QuoteMakerDetailActivity.class);
                                                intent.putExtra("moduleid", ModuleId);
                                                activity.startActivity(intent);
                                                break;
                                            case 7:
                                                intent = new Intent(activity, StoryMakerActivity.class);
                                                intent.putExtra("IsForm", "PreDesign ArtBord");
                                                intent.putExtra("moduleid", ModuleId);
                                                activity.startActivity(intent);
                                                break;
                                            case 8:
                                                intent = new Intent(activity, HighlightDetailActivity.class);
                                                intent.putExtra("moduleid", ModuleId);
                                                activity.startActivity(intent);
                                                break;
                                            case 9:
                                                intent = new Intent(activity, StoryMakerActivity.class);
                                                intent.putExtra("IsForm", "Thematic Template");
                                                intent.putExtra("moduleid", ModuleId);
                                                activity.startActivity(intent);
                                                break;
                                            case 10:
                                                intent = new Intent(activity, StoryMakerActivity.class);
                                                intent.putExtra("IsForm", "Wish Maker");
                                                intent.putExtra("moduleid", ModuleId);
                                                activity.startActivity(intent);
                                                break;
                                            case 11:
                                                intent = new Intent(activity, StoryMakerActivity.class);
                                                intent.putExtra("IsForm", "Offer Poster");
                                                intent.putExtra("moduleid", ModuleId);
                                                activity.startActivity(intent);
                                                break;
                                            case 12:
                                                intent = new Intent(activity, StoryMakerActivity.class);
                                                intent.putExtra("IsForm", "Festival");
                                                intent.putExtra("moduleid", ModuleId);
                                                activity.startActivity(intent);
                                                break;
                                            case 13:
                                                GoToExit();
                                                break;
                                            case 14:
                                                GoToBackFromMyPost();
                                                break;
                                            case 15:
                                                activity.finish();
                                                break;
                                            case 16:
                                                GoToHomeFromExit();
                                                break;
                                            case 17:
                                                activity.startActivity(new Intent(activity, DashBordActivity.class));
                                                activity.finish();
                                                break;
                                            case 18:
                                                activity.startActivity(new Intent(activity, MyPostActivity.class));
                                                activity.finish();
                                                break;
                                            case 19:
                                                activity.startActivity(new Intent(activity, DashBordActivity.class));
                                                activity.finish();
                                                break;
                                            case 20:
                                                activity.startActivity(new Intent(activity, MyPostActivity.class));
                                                activity.finish();
                                                break;
                                            case 21:
                                                activity.startActivity(new Intent(activity, DashBordActivity.class));
                                                activity.finish();
                                                break;
                                            case 22:
                                                activity.startActivity(new Intent(activity, MyPostActivity.class));
                                                activity.finish();
                                                break;
                                            case 23:
                                                activity.startActivity(new Intent(activity, DashBordActivity.class));
                                                activity.finish();
                                                break;
                                            case 24:
                                                activity.startActivity(new Intent(activity, MyPostActivity.class));
                                                activity.finish();
                                                break;
                                            case 25:
                                                activity.startActivity(new Intent(activity, DashBordActivity.class));
                                                activity.finish();
                                                break;
                                            case 26:
                                                activity.startActivity(new Intent(activity, MyPostActivity.class));
                                                activity.finish();
                                                break;
                                            case 27:
                                                ShowImageDialog("ImageSelect");
                                                break;
                                        }
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    }
                });

    }

    public void ShowImageDialog(String IsFrom) {
        Dialog dialog = new Dialog(activity, R.style.AppImageAlertDialog);
        dialog.setContentView(R.layout.dialog_select_imagevideo);
        LinearLayout llCamera = dialog.findViewById(R.id.llCamera);
        LinearLayout llGallery = dialog.findViewById(R.id.llGallery);
        llCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenCamera();
                dialog.dismiss();
            }
        });
        llGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenGallery();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void OpenGallery() {
        final ImagePicker.ImagePickerWithActivity a = new ImagePicker.ImagePickerWithActivity(activity);
        final ImagePickerConfig a2 = a.config;
        a2.folderMode = true;
        a2.theme = 10;
        a2.showCamera = false;
        a2.limit = Constant.NoofImage;
        a.start(0);
    }

    private void OpenCamera() {
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        activity.startActivityForResult(intent, Constant.Camera);
    }

    private void requestNewInterstitial() {
        interstitialAd();
    }

    private void GoToExit() {
        activity.startActivity(new Intent(activity, ExitActivity.class));
        activity.finish();
    }

    public void GoToBackFromMyPost() {
        activity.startActivity(new Intent(activity, MyPostActivity.class));
        activity.finish();
    }

    private void GoToHomeFromExit() {
        activity.startActivity(new Intent(activity, DashBordActivity.class));
        activity.finish();
    }

    /*AppOpenAds Start*/
    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    protected void onMoveToForeground() {
        appOpenAdManager.showAdIfAvailable(currentActivity);
    }


    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {

        if (!appOpenAdManager.isShowingAd) {
            currentActivity = activity;
        }
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {
    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
    }

    /**
     * Shows an app open ad.
     *
     * @param activity                 the activity that shows the app open ad
     * @param onShowAdCompleteListener the listener to be notified when an app open ad is complete
     */
    public void showAdIfAvailable(
            @NonNull Activity activity,
            @NonNull OnShowAdCompleteListener onShowAdCompleteListener) {
        // We wrap the showAdIfAvailable to enforce that other classes only interact with MyApplication
        // class.
        appOpenAdManager.showAdIfAvailable(activity, onShowAdCompleteListener);
    }

    /**
     * Interface definition for a callback to be invoked when an app open ad is complete
     * (i.e. dismissed or fails to show).
     */
    public interface OnShowAdCompleteListener {
        void onShowAdComplete();
    }

    /*AppOpenAds End*/

}
