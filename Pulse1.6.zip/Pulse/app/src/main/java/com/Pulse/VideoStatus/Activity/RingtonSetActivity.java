package com.Pulse.VideoStatus.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.Pulse.VideoStatus.Extra.Utils;
import com.Pulse.VideoStatus.Extra.d;
import com.Pulse.VideoStatus.Extra.kprogresshud.KProgressHUD;
import com.Pulse.VideoStatus.Fragment.OnlineCategoryWiseSongFragment;
import com.Pulse.VideoStatus.Fragment.RingtoneSetCatFragment;
import com.Pulse.VideoStatus.Model.SongCatModel;
import com.Pulse.VideoStatus.R;
import com.Pulse.VideoStatus.retrofit.APIClient;
import com.Pulse.VideoStatus.retrofit.ApiInterface;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.unity3d.player.UnityPlayer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RingtonSetActivity extends AppCompatActivity {

    public static d sharedpreferences;
    public int id;
    public String FinalSongPath;
    public InterstitialAd mInterstitialAd;
    public KProgressHUD hud;
    Activity activity = RingtonSetActivity.this;
    ViewPagerAdapter adp;
    ArrayList<SongCatModel> SongList = new ArrayList<>();
    Long timestamps;
    String offlienResopnseData;
    RelativeLayout rlLoadingTheme;
    Button btnRetry;
    ImageView ivBack;
    AdRequest adRequest;
    AdView adView;
    LinearLayout llRetry;
    String[] split_AllLan;
    String[] split_selctedLan;
    SharedPreferences pref;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rington_set);
        sharedpreferences = d.a(this);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        split_AllLan = ("63,55,62,61,57,60,58,59,56,52,50,53,64").split(",");
        split_selctedLan = d.a(activity).a("pref_key_language_list", "22").split(",");
        ivBack = findViewById(R.id.ivBack);
        tabLayout = findViewById(R.id.tab_layout_song_online);
        viewPager = findViewById(R.id.vp_song_online);
        rlLoadingTheme = findViewById(R.id.rl_load_song_online);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "RingtonSetActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        loadAd();
        InterstitialAd();
        adListener();
        getOfflineCategory(activity, "ThemeCategory");
        if (offlienResopnseData != null && timestamps != null) {
            new LoadOfflineData().execute();
        }
        else {
            rlLoadingTheme.setVisibility(View.GONE);
            llRetry.setVisibility(View.VISIBLE);
        }
    }

    private void loadAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 203:
                        UnityPlayer.UnitySendMessage("StackManager", "ReturnAudio", FinalSongPath);
                        finish();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    @Override
    protected void onDestroy() {
        this.adView.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        super.onDestroy();
    }

    private void adListener() {
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(activity, false)) {
                    llRetry.setVisibility(View.GONE);
                    GetSongCategory();
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
            View customView = tab.getCustomView();
            if (tab.getPosition() == 0) {
                ((TextView) customView.findViewById(R.id.custom_text)).setTextColor(getResources().getColor(R.color.white));
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_selected));
            }
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.custom_text)).setTextColor(getResources().getColor(R.color.white));
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_selected));
                StopSong();
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.custom_text)).setTextColor(getResources().getColor(R.color.white));
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_normal));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    ((TextView) customView.findViewById(R.id.custom_text)).setTextColor(getResources().getColor(R.color.white));
                    LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                    linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_selected));
                }
            }
        });


    }

    private void StopSong() {
        try {
            if (OnlineCategoryWiseSongFragment.mediaPlayer != null) {
                OnlineCategoryWiseSongFragment.mediaPlayer.stop();
                OnlineCategoryWiseSongFragment.mediaPlayer.release();
                OnlineCategoryWiseSongFragment.mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setUpPagerNew() {
        adp = new ViewPagerAdapter(getSupportFragmentManager());
        viewPager.setOffscreenPageLimit(0);
        viewPager.setAdapter(adp);
        tabLayout.setupWithViewPager(viewPager);
    }

    public void SetOfflineCategory(Context c, String userObject, String key) {
        SharedPreferences pref = PreferenceManager
                .getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    private void getOfflineCategory(Context ctx, String key) {
        offlienResopnseData = pref.getString(key, null);
        timestamps = pref.getLong(key + "_value", 0);
    }

 /*   private void LoadOfflineSongCat(String Response){
        try {
            JSONObject jsonObj = new JSONObject(Response);
            JSONArray jsonArray = jsonObj.getJSONArray("category");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject songJSONObject = jsonArray.getJSONObject(i);
                SongCatModel songCatModel = new SongCatModel();
                songCatModel.setSongCatId(songJSONObject.getString("id"));
                if (!Arrays.asList(split_AllLan).contains(songCatModel.getSongCatId())) {
                    songCatModel.setSongCatName(songJSONObject.getString("name"));
                    SongList.add(songCatModel);
                } else if (Arrays.asList(split_selctedLan).contains(songCatModel.getSongCatId())) {
                    songCatModel.setSongCatName(songJSONObject.getString("name"));
                    SongList.add(songCatModel);
                }

            }
            setUpPagerNew();
            SetTabLayout();
            rlLoadingTheme.setVisibility(View.GONE);
        } catch (final JSONException e) {
            e.printStackTrace();
        }
    }*/

    private void GetSongCategory() {
        rlLoadingTheme.setVisibility(View.VISIBLE);
        APIClient.getRetrofit().create(ApiInterface.class).GetAllTheme("aciativtyksdfhal5215ajal", "9").enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject songJSONObject = jsonArray.getJSONObject(i);
                            SongCatModel songCatModel = new SongCatModel();
                            songCatModel.setSongCatId(songJSONObject.getString("id"));
                            if (!Arrays.asList(split_AllLan).contains(songCatModel.getSongCatId())) {
                                songCatModel.setSongCatName(songJSONObject.getString("name"));
                                SongList.add(songCatModel);
                            } else if (Arrays.asList(split_selctedLan).contains(songCatModel.getSongCatId())) {
                                songCatModel.setSongCatName(songJSONObject.getString("name"));
                                SongList.add(songCatModel);
                            }

                        }
                        setUpPagerNew();
                        SetTabLayout();
                        rlLoadingTheme.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    private class LoadOfflineData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlienResopnseData);
                JSONArray jsonArray = jsonObj.getJSONArray("category");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject songJSONObject = jsonArray.getJSONObject(i);
                    SongCatModel songCatModel = new SongCatModel();
                    songCatModel.setSongCatId(songJSONObject.getString("id"));
                    if (!Arrays.asList(split_AllLan).contains(songCatModel.getSongCatId())) {
                        songCatModel.setSongCatName(songJSONObject.getString("name"));
                        SongList.add(songCatModel);
                    } else if (Arrays.asList(split_selctedLan).contains(songCatModel.getSongCatId())) {
                        songCatModel.setSongCatName(songJSONObject.getString("name"));
                        SongList.add(songCatModel);
                    }
                }
            } catch (final JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            setUpPagerNew();
            SetTabLayout();
            rlLoadingTheme.setVisibility(View.GONE);
        }
    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return (RingtoneSetCatFragment.getInstance(Integer.parseInt(SongList.get(position).getSongCatId())));
        }

        @Override
        public int getCount() {
            return SongList.size();
        }

        public View getTabView(int position) {
            View tab = LayoutInflater.from(activity).inflate(
                    R.layout.row_song_cat, null);
            TextView tv = tab.findViewById(R.id.custom_text);
            tv.setText(SongList.get(position).getSongCatName());
            return tab;
        }
    }
}
