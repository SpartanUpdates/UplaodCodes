import 'dart:convert';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:rto_app/Fuel%20Screen/model/fuel_response_model.dart';
import 'package:rto_app/History%20Screen/controller/history_controller.dart';
import 'package:rto_app/Owner%20Info%20Screen/services/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../main.dart';
import '../view/owner_info.dart';
import '../../Utils/comman_dailog.dart';

class MainControllers extends GetxController {
  var ownerInfoData;
  var fuelData;
  double height = 180;
  bool internetConnection = false;
  String? itemError = null;
  HistoryController historyController = Get.put(HistoryController());

  @override
  void onReady() {
    historyController.getAllData();
    super.onReady();
  }

  checkConnection() async {
    var connection = await Connectivity().checkConnectivity();
    if (connection == ConnectivityResult.none) {
      internetConnection = false;
    } else {
      internetConnection = true;
    }
  }

  Future<void> itemValidation(bool empty) async {
    print("validation called");
    if (empty) {
      itemError = "Enter Valid number like MH10AB5521";
    } else {
      itemError = null;
    }
    update();
  }

  Future<void> changeHeight() async {
    height = 0;
    update();
  }

  Future<void> clearAll() async {
    DisplayData.isResponseAvailable = false;
    update();
  }

  Future<void> fetchOwnerData(BuildContext context, String number) async {
    bool exist = false;
    CommanDialog.showLoading(context);
    for (var list in historyController.ownerInfoList) {
      if (list.licensePlate == number) {
        exist = true;
        break;
      }
    }
    if (exist) {
      for (int i = 0; i < historyController.ownerInfoList.length; i++) {
        if (historyController.ownerInfoList[i].licensePlate ==
            number.toUpperCase()) {
          DisplayData.isResponseAvailable = true;
          ownerInfoData = historyController.ownerInfoList[i];
          CommanDialog.hideLoading();
          break;
        }
      }
    } else {
      try {
        final response = await ApiCall().getRequest(context, number);
        CommanDialog.hideLoading();
        if (response.code == 200) {
          ownerInfoData = response.response;
          DisplayData.isResponseAvailable = true;
        } else if (response.code == 400) {
          CommanDialog.showErrorDialog(context, "No Data Found");
        }
      } catch (error) {
        CommanDialog.hideLoading();
        CommanDialog.showErrorDialog(context, "No Data Found");
      }
    }
    historyController.getAllData();
    update();
  }

  Future<void> getPrefData() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    Map<String, dynamic> jsondatais = jsonDecode(prefs.getString('fuelData')!);

    FuelResponseModel fuelResponseModel =
        FuelResponseModel.fromJson(jsondatais);

    fuelData = fuelResponseModel;
    MyFuel.isResponseAvailable = true;
    update();
  }

  Future<void> setPrefData(FuelResponseModel fuelResponseModel) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    FuelResponseModel model = FuelResponseModel(
        code: fuelResponseModel.code,
        status: fuelResponseModel.status,
        response: fuelResponseModel.response);
    String strModel = jsonEncode(model);
    prefs.setString('fuelData', strModel);
  }

  Future<void> fetchFuelData(BuildContext context, city, String prev) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final date = new DateTime.now().day;
    String? getStoredDate = (prefs.getString("currentDate"));
    if (prev == "default") {
      if (getStoredDate == date.toString()) {
        getPrefData();
      } else {
        await prefs.setString("currentDate", date.toString());
        try {
          final response = await ApiCall().getFuelData(context, city);
          CommanDialog.hideLoading();
          if (response.code == 200) {
            MyFuel.isResponseAvailable = true;
            fuelData = FuelResponseModel(
                code: response.code,
                status: response.status,
                response: response.response);
          } else if (response.code == 400) {
            CommanDialog.showErrorDialog(context, "No Data Found");
          }
          setPrefData(fuelData);
          update();
        } catch (error) {
          CommanDialog.showErrorDialog(
              context, "Data not available for this city !");
        }
      }
    } else {
      await prefs.setString("currentDate", date.toString());
      try {
        final response = await ApiCall().getFuelData(context, city);
        CommanDialog.hideLoading();
        if (response.code == 200) {
          MyFuel.isResponseAvailable = true;
          fuelData = FuelResponseModel(
              code: response.code,
              status: response.status,
              response: response.response);
        } else if (response.code == 400) {
          CommanDialog.showErrorDialog(context, "No Data Found");
        }
        setPrefData(fuelData);
        update();
      } catch (error) {
        CommanDialog.showErrorDialog(
            context, "Data not available for this city !");
      }
    }
  }
}
