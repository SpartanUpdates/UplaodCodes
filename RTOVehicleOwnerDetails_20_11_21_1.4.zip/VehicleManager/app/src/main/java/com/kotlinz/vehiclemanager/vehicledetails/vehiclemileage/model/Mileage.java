package com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.model;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "Mileage",indices = @Index(value = {"id"},unique = true))
public class Mileage {
    @PrimaryKey(autoGenerate = true)
    int id;
    String lastReserve;
    String currentReserve;
    String fuel;
    String price;
    String date;
    String mileageKm;
    String mileageInrLtr;
    String mileageInrKm;

    public Mileage() {
    }

    public Mileage(String lastReserve, String currentReserve, String fuel, String price, String date, String mileageKm, String mileageInrLtr, String mileageInrKm) {
        this.lastReserve = lastReserve;
        this.currentReserve = currentReserve;
        this.fuel = fuel;
        this.price = price;
        this.date = date;
        this.mileageKm = mileageKm;
        this.mileageInrLtr = mileageInrLtr;
        this.mileageInrKm = mileageInrKm;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLastReserve() {
        return lastReserve;
    }

    public void setLastReserve(String lastReserve) {
        this.lastReserve = lastReserve;
    }

    public String getCurrentReserve() {
        return currentReserve;
    }

    public void setCurrentReserve(String currentReserve) {
        this.currentReserve = currentReserve;
    }

    public String getFuel() {
        return fuel;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMileageKm() {
        return mileageKm;
    }

    public void setMileageKm(String mileageKm) {
        this.mileageKm = mileageKm;
    }

    public String getMileageInrLtr() {
        return mileageInrLtr;
    }

    public void setMileageInrLtr(String mileageInrLtr) {
        this.mileageInrLtr = mileageInrLtr;
    }

    public String getMileageInrKm() {
        return mileageInrKm;
    }

    public void setMileageInrKm(String mileageInrKm) {
        this.mileageInrKm = mileageInrKm;
    }
}
