package com.libffmpeg;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Formatter;
import java.util.Iterator;
import java.util.Map;

public class FileUtils {
    public static File APP_DIRECTORY;
    private static final int DEFAULT_BUFFER_SIZE = 4096;
    private static final int EOF = -1;
    public static final File TEMP_DIRECTORY;
    public static final File TEMP_DIRECTORY_AUDIO;
    public static final File TEMP_IMG_DIRECTORY;
    public static final File TEMP_VID_DIRECTORY;
    static final String ffmpegFileName = "ffmpeg";
    public static final File frameFile;
    public static final String hiddenDirectoryName = ".MyGalaryLock/";
    public static final String hiddenDirectoryNameImage = "Image/";
    public static String hiddenDirectoryNameThumb = ".MyGalaryLock/.thumbnail/";
    public static final String hiddenDirectoryNameThumbImage = ".thumb/Image/";
    public static final String hiddenDirectoryNameThumbVideo = ".thumb/Video/";
    public static final String hiddenDirectoryNameVideo = "Video/";
    public static long mDeleteFileCount = 0L;
    public static File mDownloadDir;
    public static File mSdCard;
    private static File[] mStorageList;
    public static final String rawExternalStorage;
    public static String rawSecondaryStoragesStr;
    public static String unlockDirectoryNameImage = "GalaryLock/Image/";
    public static String unlockDirectoryNameVideo = "GalaryLock/Video/";

    static {
        rawExternalStorage = System.getenv("EXTERNAL_STORAGE");
        FileUtils.rawSecondaryStoragesStr = System.getenv("SECONDARY_STORAGE");
        FileUtils.mSdCard = new File(Environment.getExternalStorageDirectory().getAbsolutePath());
        FileUtils.mDownloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        FileUtils.APP_DIRECTORY = new File(FileUtils.mSdCard, "Pic2Video");
        TEMP_DIRECTORY = new File(FileUtils.APP_DIRECTORY, ".temp");
        TEMP_VID_DIRECTORY = new File(FileUtils.TEMP_DIRECTORY, ".temp_vid");
        TEMP_DIRECTORY_AUDIO = new File(FileUtils.APP_DIRECTORY, ".temp_audio");
        TEMP_IMG_DIRECTORY = new File(FileUtils.APP_DIRECTORY, ".temp_image");
        frameFile = new File(FileUtils.APP_DIRECTORY, ".frame.png");
        if (!FileUtils.TEMP_IMG_DIRECTORY.exists()) {
            FileUtils.TEMP_IMG_DIRECTORY.mkdirs();
        }
        if (!FileUtils.TEMP_DIRECTORY.exists()) {
            FileUtils.TEMP_DIRECTORY.mkdirs();
        }
        if (!FileUtils.TEMP_VID_DIRECTORY.exists()) {
            FileUtils.TEMP_VID_DIRECTORY.mkdirs();
        }
    }

    public FileUtils() {
        FileUtils.mDeleteFileCount = 0L;
    }

    static String SHA1(InputStream is) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA1");
            final byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
            for (int read; (read = is.read(buffer)) != -1;) {
                messageDigest.update(buffer, 0, read);
            }

            Formatter formatter = new Formatter();
            for (final byte b : messageDigest.digest()) {
                formatter.format("%02x", b);
            }
            return formatter.toString();
        } catch (NoSuchAlgorithmException e) {
        } catch (IOException e) {
        } finally {
            Util.close(is);
        }
        return null;
    }

    static String SHA1(String file) {
        InputStream is = null;
        try {
            is = new BufferedInputStream(new FileInputStream(file));
            return SHA1(is);
        } catch (IOException e) {
        } finally {
            Util.close(is);
        }
        return null;
    }

    public static void addImageTovideo(final File file) {
        appendLog(getVideoDirectory(), String.format("file '%s'", file.getAbsolutePath()));
    }

    public static void addVideoToConcat(final int n) {
        appendLog(new File(getVideoDirectory(), "video.txt"), String.format("file '%s'", getVideoFile(n).getAbsolutePath()));
    }

    public static void appendLog(final File file, final String s) {
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        try {
            final BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
            bufferedWriter.append((CharSequence) s);
            bufferedWriter.newLine();
            bufferedWriter.close();
        } catch (IOException ex2) {
            ex2.printStackTrace();
        }
    }

    static boolean copyBinaryFromAssetsToData(final Context context, final String s, final String s2) {
        final File filesDirectory = getFilesDirectory(context);
        try {
            final InputStream open = context.getAssets().open(s);
            final FileOutputStream fileOutputStream = new FileOutputStream(new File(filesDirectory, s2));
            final byte[] array = new byte[4096];
            while (true) {
                final int read = open.read(array);
                if (-1 == read) {
                    break;
                }
                fileOutputStream.write(array, 0, read);
            }
            Util.close((OutputStream) fileOutputStream);
            Util.close(open);
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    public static void copyFile(final File file, final File file2) throws IOException {
        final FileInputStream fileInputStream = new FileInputStream(file);
        final FileOutputStream fileOutputStream = new FileOutputStream(file2);
        final byte[] array = new byte[1024];
        while (true) {
            final int read = fileInputStream.read(array);
            if (read <= 0) {
                break;
            }
            fileOutputStream.write(array, 0, read);
        }
        fileInputStream.close();
        fileOutputStream.close();
    }

    public static boolean deleteFile(final File file) {
        boolean delete = false;
        int i = 0;
        if (file == null) {
            return false;
        }
        if (file.exists()) {
            if (file.isDirectory()) {
                final File[] listFiles = file.listFiles();
                if (listFiles != null && listFiles.length > 0) {
                    while (i < listFiles.length) {
                        final File file2 = listFiles[i];
                        FileUtils.mDeleteFileCount += file2.length();
                        deleteFile(file2);
                        ++i;
                    }
                }
                FileUtils.mDeleteFileCount += file.length();
                return file.delete();
            }
            FileUtils.mDeleteFileCount += file.length();
            delete = file.delete();
        }
        return delete;
    }

    public static boolean deleteFile(final String s) {
        return deleteFile(new File(s));
    }

    public static void deleteTempDir() {
        final File[] listFiles = FileUtils.TEMP_DIRECTORY.listFiles();
        for (int length = listFiles.length, i = 0; i < length; ++i) {
//            new FileUtils$1(listFiles[i]).start();
            final int finalI = i;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    FileUtils.deleteFile(listFiles[finalI]);
                }
            }).start();
        }
    }

    public static boolean deleteThemeDir(final String s) {
        return deleteFile(getImageDirectory(s));
    }

    public static String genrateFileId(final String s) {
        try {
            Thread.sleep(10L);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(System.currentTimeMillis());
        final String string = sb.toString();
        if (s.endsWith(".jpg")) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(string);
            sb2.append("_1");
            return sb2.toString();
        }
        if (s.endsWith(".JPG")) {
            final StringBuilder sb3 = new StringBuilder();
            sb3.append(string);
            sb3.append("_2");
            return sb3.toString();
        }
        if (s.endsWith(".png")) {
            final StringBuilder sb4 = new StringBuilder();
            sb4.append(string);
            sb4.append("_3");
            return sb4.toString();
        }
        if (s.endsWith(".PNG")) {
            final StringBuilder sb5 = new StringBuilder();
            sb5.append(string);
            sb5.append("_4");
            return sb5.toString();
        }
        if (s.endsWith(".jpeg")) {
            final StringBuilder sb6 = new StringBuilder();
            sb6.append(string);
            sb6.append("_5");
            return sb6.toString();
        }
        if (s.endsWith(".JPEG")) {
            final StringBuilder sb7 = new StringBuilder();
            sb7.append(string);
            sb7.append("_6");
            return sb7.toString();
        }
        if (s.endsWith(".mp4")) {
            final StringBuilder sb8 = new StringBuilder();
            sb8.append(string);
            sb8.append("_7");
            return sb8.toString();
        }
        if (s.endsWith(".3gp")) {
            final StringBuilder sb9 = new StringBuilder();
            sb9.append(string);
            sb9.append("_8");
            return sb9.toString();
        }
        if (s.endsWith(".flv")) {
            final StringBuilder sb10 = new StringBuilder();
            sb10.append(string);
            sb10.append("_9");
            return sb10.toString();
        }
        if (s.endsWith(".m4v")) {
            final StringBuilder sb11 = new StringBuilder();
            sb11.append(string);
            sb11.append("_10");
            return sb11.toString();
        }
        if (s.endsWith(".avi")) {
            final StringBuilder sb12 = new StringBuilder();
            sb12.append(string);
            sb12.append("_11");
            return sb12.toString();
        }
        if (s.endsWith(".wmv")) {
            final StringBuilder sb13 = new StringBuilder();
            sb13.append(string);
            sb13.append("_12");
            return sb13.toString();
        }
        if (s.endsWith(".mpeg")) {
            final StringBuilder sb14 = new StringBuilder();
            sb14.append(string);
            sb14.append("_13");
            return sb14.toString();
        }
        if (s.endsWith(".VOB")) {
            final StringBuilder sb15 = new StringBuilder();
            sb15.append(string);
            sb15.append("_14");
            return sb15.toString();
        }
        if (s.endsWith(".MOV")) {
            final StringBuilder sb16 = new StringBuilder();
            sb16.append(string);
            sb16.append("_15");
            return sb16.toString();
        }
        if (s.endsWith(".MPEG4")) {
            final StringBuilder sb17 = new StringBuilder();
            sb17.append(string);
            sb17.append("_16");
            return sb17.toString();
        }
        if (s.endsWith(".DivX")) {
            final StringBuilder sb18 = new StringBuilder();
            sb18.append(string);
            sb18.append("_17");
            return sb18.toString();
        }
        if (s.endsWith(".mkv")) {
            final StringBuilder sb19 = new StringBuilder();
            sb19.append(string);
            sb19.append("_18");
            return sb19.toString();
        }
        return string;
    }

    public static ArrayList<File> getCacheDirectory(final String s) {
        final ArrayList<File> list = new ArrayList<File>();
        final File[] storages = getStorages();
        for (int length = storages.length, i = 0; i < length; ++i) {
            final File file = storages[i];
            final StringBuilder sb = new StringBuilder();
            sb.append("Android/data/");
            sb.append(s);
            sb.append("/cache");
            final File file2 = new File(file, sb.toString());
            if (file2.exists()) {
                list.add(file2);
            }
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("Android/data/");
            sb2.append(s);
            sb2.append("/Cache");
            final File file3 = new File(file, sb2.toString());
            if (file3.exists()) {
                list.add(file3);
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("Android/data/");
            sb3.append(s);
            sb3.append("/.cache");
            final File file4 = new File(file, sb3.toString());
            if (file4.exists()) {
                list.add(file4);
            }
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("Android/data/");
            sb4.append(s);
            sb4.append("/.Cache");
            final File file5 = new File(file, sb4.toString());
            if (file5.exists()) {
                list.add(file5);
            }
        }
        return list;
    }

    public static long getDirectorySize(File file) {
        long j = 0;
        if (file != null) {
            final File[] listFiles = file.listFiles();
            if (listFiles != null && listFiles.length > 0) {
                for (File file2 : listFiles) {
                    long directorySize;
                    if (file2.isDirectory()) {
                        directorySize = j + getDirectorySize(file2);
                    } else {
                        directorySize = j + file2.length();
                    }
                    j = directorySize;
                }
            }
        }
        return j;
    }

    @SuppressLint({"DefaultLocale"})
    public static String getDuration(long n) {
        if (n < 1000L) {
            return String.format("%02d:%02d", 0, 0);
        }
        final long n2 = n / 1000L;
        n = n2 / 3600L;
        final long n3 = 3600L * n;
        final long n4 = (n2 - n3) / 60L;
        final long n5 = n2 - (n3 + 60L * n4);
        if (n == 0L) {
            return String.format("%02d:%02d", n4, n5);
        }
        return String.format("%02d:%02d:%02d", n, n4, n5);
    }

    public static String getFFmpeg(final Context context) {
        final StringBuilder sb = new StringBuilder();
        sb.append(getFilesDirectory(context).getAbsolutePath());
        sb.append(File.separator);
        sb.append("ffmpeg");
        return sb.toString();
    }

    static String getFFmpeg(Context context, Map<String, String> map) {
        String str = "";
        if (map != null) {
            final Iterator<Map.Entry<String, String>> iterator = map.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, String> entry = (Map.Entry<String, String>) iterator.next();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append((String) entry.getKey());
                stringBuilder.append("=");
                stringBuilder.append((String) entry.getValue());
                stringBuilder.append(" ");
                str = stringBuilder.toString();
            }
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append(getFFmpeg(context));
        return sb.toString();
    }

    public static String getFileFormat(final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append(System.currentTimeMillis());
        sb.append("_0");
        final String string = sb.toString();
        if (s.endsWith("_1")) {
            return ".jpg";
        }
        if (s.endsWith("_2")) {
            return ".JPG";
        }
        if (s.endsWith("_3")) {
            return ".png";
        }
        if (s.endsWith("_4")) {
            return ".PNG";
        }
        if (s.endsWith("_5")) {
            return ".jpeg";
        }
        if (s.endsWith("_6")) {
            return ".JPEG";
        }
        if (s.endsWith("_7")) {
            return ".mp4";
        }
        if (s.endsWith("_8")) {
            return ".3gp";
        }
        if (s.endsWith("_9")) {
            return ".flv";
        }
        if (s.endsWith("_10")) {
            return ".m4v";
        }
        if (s.endsWith("_11")) {
            return ".avi";
        }
        if (s.endsWith("_12")) {
            return ".wmv";
        }
        if (s.endsWith("_13")) {
            return ".mpeg";
        }
        if (s.endsWith("_14")) {
            return ".VOB";
        }
        if (s.endsWith("_15")) {
            return ".MOV";
        }
        if (s.endsWith("_16")) {
            return ".MPEG4";
        }
        if (s.endsWith("_17")) {
            return ".DivX";
        }
        if (s.endsWith("_18")) {
            return ".mkv";
        }
        return string;
    }

    static File getFilesDirectory(final Context context) {
        return context.getFilesDir();
    }

    public static File getHiddenAppDirectory(File file) {
        file = new File(file, ".MyGalaryLock/");
        if (file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public static File getHiddenImageAppDirectory(File file) {
        file = new File(getHiddenAppDirectory(file), "Image/");
        if (file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public static File getHiddenImageDirectory(final File file, final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append(".MyGalaryLock/Image/");
        sb.append(s);
        return new File(file, sb.toString());
    }

    public static File getHiddenVideoAppDirectory(File file) {
        file = new File(getHiddenAppDirectory(file), "Video/");
        if (file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public static File getHiddenVideoDirectory(final File file, final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append(".MyGalaryLock/Video/");
        sb.append(s);
        return new File(file, sb.toString());
    }

    public static File getImageDirectory(final int n) {
        final File file = new File(FileUtils.TEMP_DIRECTORY, String.format("IMG_%03d", n));
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public static File getImageDirectory(final String s) {
        final File file = new File(FileUtils.TEMP_DIRECTORY, s);
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public static File getImageDirectory(final String s, final int n) {
        final File file = new File(getImageDirectory(s), String.format("IMG_%03d", n));
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public static File getMoveFolderpath(final File file, final String s) {
        final File parentFile = file.getParentFile().getParentFile();
        final StringBuilder sb = new StringBuilder();
        sb.append(s);
        sb.append("/");
        sb.append(file.getName());
        return new File(parentFile, sb.toString());
    }

    @SuppressLint({"SimpleDateFormat"})
    public static File getOutputImageFile() {
        if (!FileUtils.APP_DIRECTORY.exists() && !FileUtils.APP_DIRECTORY.mkdirs()) {
            return null;
        }
        final String format = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        final File app_DIRECTORY = FileUtils.APP_DIRECTORY;
        final StringBuilder sb = new StringBuilder();
        sb.append("IMG_");
        sb.append(format);
        sb.append(".jpg");
        return new File(app_DIRECTORY, sb.toString());
    }

    public static Bitmap getPicFromBytes(final byte[] array) {
        if (array != null) {
            final BitmapFactory.Options bitmapFactory$Options = new BitmapFactory.Options();
            bitmapFactory$Options.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(array, 0, array.length, bitmapFactory$Options);
            int round;
            if ((bitmapFactory$Options.outWidth < bitmapFactory$Options.outHeight) ? (bitmapFactory$Options.outHeight >= 1024) : (bitmapFactory$Options.outWidth >= 1024)) {
                round = Math.round(bitmapFactory$Options.outWidth / 1024.0f);
            } else {
                round = 1;
            }
            final BitmapFactory.Options bitmapFactory$Options2 = new BitmapFactory.Options();
            bitmapFactory$Options2.inSampleSize = round;
            return BitmapFactory.decodeByteArray(array, 0, array.length, bitmapFactory$Options2).copy(Bitmap.Config.RGB_565, true);
        }
        return null;
    }

    public static File getRestoreImageDirectory(final File file, final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append(FileUtils.unlockDirectoryNameImage);
        sb.append(s);
        return new File(file, sb.toString());
    }

    public static File getRestoreVideoDirectory(final File file, final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append(FileUtils.unlockDirectoryNameVideo);
        sb.append(s);
        return new File(file, sb.toString());
    }

    public static File[] getStorages() {
        if (FileUtils.mStorageList != null) {
            return FileUtils.mStorageList;
        }
        return getStorge();
    }

    private static File[] getStorge() {
        final ArrayList<File> list = new ArrayList<File>();
        if (FileUtils.rawExternalStorage != null) {
            list.add(new File(FileUtils.rawExternalStorage));
        } else if (FileUtils.mSdCard != null) {
            list.add(FileUtils.mSdCard);
        }
        if (FileUtils.rawSecondaryStoragesStr != null) {
            list.add(new File(FileUtils.rawSecondaryStoragesStr));
        }
        FileUtils.mStorageList = new File[list.size()];
        for (int i = 0; i < list.size(); ++i) {
            FileUtils.mStorageList[i] = (File) list.get(i);
        }
        return FileUtils.mStorageList;
    }

    public static File getThumbnailDirectory(File file, final int n) {
        if (n == 0) {
            file = new File(getHiddenAppDirectory(file), ".thumb/Video/");
        } else {
            file = new File(getHiddenAppDirectory(file), ".thumb/Image/");
        }
        if (file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public static File getVideoDirectory() {
        if (!FileUtils.TEMP_VID_DIRECTORY.exists()) {
            FileUtils.TEMP_VID_DIRECTORY.mkdirs();
        }
        return FileUtils.TEMP_VID_DIRECTORY;
    }

    public static File getVideoFile(final int n) {
        if (!FileUtils.TEMP_VID_DIRECTORY.exists()) {
            FileUtils.TEMP_VID_DIRECTORY.mkdirs();
        }
        return new File(FileUtils.TEMP_VID_DIRECTORY, String.format("vid_%03d.mp4", n));
    }

    public static String humanReadableByteCount(final long n, final boolean b) {
        int n2;
        if (b) {
            n2 = 1000;
        } else {
            n2 = 1024;
        }
        if (n < n2) {
            final StringBuilder sb = new StringBuilder();
            sb.append(n);
            sb.append(" B");
            return sb.toString();
        }
        final double n3 = n;
        final double log = Math.log(n3);
        final double n4 = n2;
        final int n5 = (int) (log / Math.log(n4));
        final StringBuilder sb2 = new StringBuilder();
        String s;
        if (b) {
            s = "kMGTPE";
        } else {
            s = "KMGTPE";
        }
        sb2.append(s.charAt(n5 - 1));
        String s2;
        if (b) {
            s2 = "";
        } else {
            s2 = "i";
        }
        sb2.append(s2);
        return String.format("%.1f %sB", n3 / Math.pow(n4, n5), sb2.toString());
    }

    public static void moveFile(final File file, final File file2) throws IOException {
        if (!file.exists()) {
            return;
        }
        if (file.renameTo(file2)) {
            return;
        }
        if (!file2.getParentFile().exists()) {
            file2.getParentFile().mkdirs();
        }
        final FileInputStream fileInputStream = new FileInputStream(file);
        final FileOutputStream fileOutputStream = new FileOutputStream(file2);
        final byte[] array = new byte[1024];
        while (true) {
            final int read = fileInputStream.read(array);
            if (read <= 0) {
                break;
            }
            fileOutputStream.write(array, 0, read);
        }
        fileInputStream.close();
        fileOutputStream.close();
        if (file.exists()) {
            file.delete();
        }
    }

    public static void moveFile(final String s, final String s2) throws IOException {
        if (new File(s).renameTo(new File(s2))) {
            return;
        }
        final File file = new File(s);
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        final FileInputStream fileInputStream = new FileInputStream(s);
        final FileOutputStream fileOutputStream = new FileOutputStream(s2);
        final byte[] array = new byte[1024];
        while (true) {
            final int read = fileInputStream.read(array);
            if (read <= 0) {
                break;
            }
            fileOutputStream.write(array, 0, read);
        }
        fileInputStream.close();
        fileOutputStream.close();
        final File file2 = new File(s);
        if (file2.exists()) {
            file2.delete();
        }
    }

    private static String putPrefixZero(final long n) {
        final StringBuilder sb = new StringBuilder();
        sb.append(n);
        if (sb.toString().length() < 2) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("0");
            sb2.append(n);
            return sb2.toString();
        }
        final StringBuilder sb3 = new StringBuilder();
        sb3.append(n);
        return sb3.toString();
    }

    public static char[] readPatternData(final Context context) {
        try {
            final StringBuilder sb = new StringBuilder();
            sb.append(context.getFilesDir());
            sb.append("/pattern");
            if (new File(sb.toString()).exists()) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(context.getFilesDir());
                sb2.append("/pattern");
                final ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(sb2.toString()));
                final char[] array = (char[]) objectInputStream.readObject();
                objectInputStream.close();
                return array;
            }
            return null;
        } catch (Exception ex) {
            return null;
        }
    }
}
