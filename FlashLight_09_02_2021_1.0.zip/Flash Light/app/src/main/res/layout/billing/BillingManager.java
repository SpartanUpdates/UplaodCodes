package flash.light.shine.com.billing;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface.OnDismissListener;
import android.graphics.drawable.ColorDrawable;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;
import androidx.lifecycle.MutableLiveData;
import androidx.preference.PreferenceManager;
import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClient.SkuType;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingFlowParams.Builder;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchaseHistoryRecord;
import com.android.billingclient.api.PurchaseHistoryResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.google.android.material.textview.MaterialTextView;
import flash.light.shine.com.APP;
import flash.light.shine.com.R;
import flash.light.shine.com.TinyDB;
import io.branch.referral.util.BRANCH_STANDARD_EVENT;
import io.branch.referral.util.BranchEvent;
import io.branch.referral.util.CurrencyType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BillingManager {
    private static final String[] HEX_CHARACTER_TABLE;
    private static final int[] HEX_VALUE_TABLE;
    private static final int STATUS_ACCOUNT_HOLD = 7;
    private static final int STATUS_SUBSCRIBED = 1;
    private static final int STATUS_SUBSCRIPTION_RECOVERED = 2;
    private static final int STATUS_UNSUBSCRIBED = 0;
    private static final String TAG = "InAppManager";
    private final Activity mActivity;
    private BillingClient mBillingClient;
    OnPriceAvailable onPriceAvailable = null;
    public MutableLiveData<Map<String, SkuDetails>> skusWithSkuDetails = new MutableLiveData();
    List<TextView> textViews = new ArrayList();
    TinyDB tinyDB;

    interface OnPriceAvailable {
        void priceAvailable();
    }

    private String generateObfuscatedAccountId() {
        String str = APP.AAID;
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        return "A:" + Base64.encodeToString(hexString2bytes(str.replace("-", "")), 3);
    }

    private String generateObfuscatedProfileId() {
        return "C:" + Base64.encodeToString(PreferenceManager.getDefaultSharedPreferences(this.mActivity).getString("adChannel", "NULL").getBytes(), 3);
    }

    public static byte[] hexString2bytes(String str) {
        int i = 0;
        int length = str == null ? 0 : str.length();
        if (length == 0) {
            return new byte[0];
        }
        if (length % 2 != 0) {
            str = str + "0";
            length++;
        }
        byte[] bArr = new byte[(length / 2)];
        while (i < length) {
            char charAt = str.charAt(i);
            char charAt2 = str.charAt(i + 1);
            int i2 = i >> 1;
            int[] iArr = HEX_VALUE_TABLE;
            bArr[i2] = (byte) ((iArr[charAt] << 4) | iArr[charAt2]);
            i += 2;
        }
        return bArr;
    }

    static {
        String[] strArr = new String[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"};
        HEX_CHARACTER_TABLE = strArr;
        int[] iArr = new int[256];
        HEX_VALUE_TABLE = iArr;
        Arrays.fill(iArr, 0);
        int length = strArr.length;
        for (int i = 0; i < length; i++) {
            String str = HEX_CHARACTER_TABLE[i];
            int[] iArr2 = HEX_VALUE_TABLE;
            byte b = (byte) i;
            iArr2[str.charAt(0)] = b;
            iArr2[str.toLowerCase().charAt(0)] = b;
        }
    }

    public BillingManager(Activity activity, PurchasesUpdatedListener purchasesUpdatedListener) {
        this.tinyDB = new TinyDB(activity);
        this.mActivity = activity;
        this.mBillingClient = BillingClient.newBuilder(activity).enablePendingPurchases().setListener(purchasesUpdatedListener).build();
        startServiceConnectionIfNeeded(null);
    }

    private void startServiceConnectionIfNeeded(final Runnable runnable) {
        if (!this.mBillingClient.isReady()) {
            this.mBillingClient.startConnection(new BillingClientStateListener() {
                public void onBillingSetupFinished(BillingResult billingResult) {
                    int responseCode = billingResult.getResponseCode();
                    String str = BillingManager.TAG;
                    if (responseCode == 0) {
                        Log.i(str, "onBillingSetupFinished() response: " + billingResult.getResponseCode());
                        Runnable runnable = runnable;
                        if (runnable != null) {
                            runnable.run();
                        }
                        BillingManager.this.querySkuDetails();
                        return;
                    }
                    Log.w(str, "onBillingSetupFinished() error code: " + billingResult.getResponseCode());
                }

                public void onBillingServiceDisconnected() {
                    Log.w(BillingManager.TAG, "onBillingServiceDisconnected()");
                }
            });
        } else if (runnable != null) {
            runnable.run();
        }
    }

    public void querySkuDetails() {
        String str = TAG;
        Log.d(str, "querySkuDetails");
        ArrayList arrayList = new ArrayList();
        arrayList.add("flashlight.monthly.com");
        Log.i(str, "querySkuDetailsAsync");
        querySkuDetailsAsync(SkuType.SUBS, arrayList);
    }

    public void querySkuDetailsAsync(final String str, final List<String> list) {
        startServiceConnectionIfNeeded(new Runnable() {
            public void run() {
                BillingManager.this.mBillingClient.querySkuDetailsAsync(SkuDetailsParams.newBuilder().setSkusList(list).setType(str).build(), new SkuDetailsResponseListener() {
                    public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> list) {
                        int responseCode = billingResult.getResponseCode();
                        String str = " ";
                        String str2 = "onSkuDetailsResponse: ";
                        String str3 = BillingManager.TAG;
                        switch (responseCode) {
                            case -1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                                Log.i(str3, str2 + billingResult.getResponseCode() + str + billingResult.getDebugMessage());
                                return;
                            case 0:
                                Log.i(str3, str2 + billingResult.getResponseCode() + str + billingResult.getDebugMessage());
                                if (list == null) {
                                    Log.w(str3, "onSkuDetailsResponse: null SkuDetails list");
                                    BillingManager.this.skusWithSkuDetails.postValue(Collections.emptyMap());
                                    return;
                                }
                                HashMap hashMap = new HashMap();
                                for (SkuDetails skuDetails : list) {
                                    hashMap.put(skuDetails.getSku(), skuDetails);
                                }
                                BillingManager.this.skusWithSkuDetails.postValue(hashMap);
                                if (BillingManager.this.onPriceAvailable != null) {
                                    BillingManager.this.onPriceAvailable.priceAvailable();
                                }
                                Log.i(str3, "onSkuDetailsResponse: count " + hashMap.size());
                                return;
                            case 1:
                                Log.i(str3, str2 + billingResult.getResponseCode() + str + billingResult.getDebugMessage());
                                return;
                            default:
                                Log.i(str3, str2 + billingResult.getResponseCode() + str + billingResult.getDebugMessage());
                                return;
                        }
                    }
                });
            }
        });
    }

    public void startPurchaseFlow(final String str) {
        startServiceConnectionIfNeeded(new Runnable() {
            public void run() {
                String str = null;
                if ((BillingManager.this.skusWithSkuDetails.getValue() != null ? (SkuDetails) ((Map) BillingManager.this.skusWithSkuDetails.getValue()).get(str) : null) == null) {
                    Log.e("Billing", "Could not find SkuDetails to make purchase.");
                    BillingManager.this.querySkuDetails();
                    Toast.makeText(BillingManager.this.mActivity, "Something went wrong with Billing, Please Try Again.", 0).show();
                    return;
                }
                Builder obfuscatedAccountId = BillingFlowParams.newBuilder().setSkuDetails((SkuDetails) ((Map) BillingManager.this.skusWithSkuDetails.getValue()).get(str)).setObfuscatedAccountId(BillingManager.this.generateObfuscatedAccountId());
                if (BillingManager.this.generateObfuscatedAccountId() != null) {
                    str = BillingManager.this.generateObfuscatedProfileId();
                }
                BillingManager.this.mBillingClient.launchBillingFlow(BillingManager.this.mActivity, obfuscatedAccountId.setObfuscatedProfileId(str).build());
            }
        });
    }

    public void destroy() {
        BillingClient billingClient = this.mBillingClient;
        if (billingClient != null && billingClient.isReady()) {
            this.mBillingClient.endConnection();
            this.mBillingClient = null;
        }
    }

    public void acknowledgement(BillingResult billingResult, List<Purchase> list) {
        handleSubscribed();
        AcknowledgePurchaseParams build = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(((Purchase) list.get(0)).getPurchaseToken()).build();
        branchLogStartTrialEvent((Purchase) list.get(0), (SkuDetails) ((Map) this.skusWithSkuDetails.getValue()).get(((Purchase) list.get(0)).getSku()));
        this.mBillingClient.acknowledgePurchase(build, new AcknowledgePurchaseResponseListener() {
            public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
            }
        });
    }

    public void acknowledgement(PurchaseHistoryRecord purchaseHistoryRecord) {
        this.mBillingClient.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchaseHistoryRecord.getPurchaseToken()).build(), new AcknowledgePurchaseResponseListener() {
            public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
            }
        });
    }

    public void branchLogStartTrialEvent(Purchase purchase, SkuDetails skuDetails) {
        String priceCurrencyCode = skuDetails.getPriceCurrencyCode();
        if (TextUtils.isEmpty(priceCurrencyCode)) {
            priceCurrencyCode = "USD";
        }
        priceCurrencyCode = priceCurrencyCode.toUpperCase();
        new BranchEvent(BRANCH_STANDARD_EVENT.START_TRIAL).setTransactionID(purchase.getOrderId()).setCurrency(CurrencyType.getValue(priceCurrencyCode)).setDescription(skuDetails.getSku()).logEvent(this.mActivity);
        new BranchEvent(BRANCH_STANDARD_EVENT.PURCHASE).setTransactionID(purchase.getOrderId()).setCurrency(CurrencyType.getValue(priceCurrencyCode)).setDescription(skuDetails.getSku()).logEvent(this.mActivity);
    }

    public void setonhistoryfetcher(HistoryFetcher historyFetcher) {
        gethistory(historyFetcher);
    }

    public void gethistory(final HistoryFetcher historyFetcher) {
        this.mBillingClient.queryPurchaseHistoryAsync(SkuType.SUBS, new PurchaseHistoryResponseListener() {
            public void onPurchaseHistoryResponse(BillingResult billingResult, List<PurchaseHistoryRecord> list) {
                historyFetcher.ongetHistory(billingResult.getResponseCode(), list);
            }
        });
    }

    public void setprice(final String str, TextView textView) {
        this.textViews.add(textView);
        final SkuDetails[] skuDetailsArr = new SkuDetails[]{null};
        if (this.skusWithSkuDetails.getValue() != null) {
            skuDetailsArr[0] = (SkuDetails) ((Map) this.skusWithSkuDetails.getValue()).get(str);
        }
        if (skuDetailsArr[0] == null) {
            this.onPriceAvailable = new OnPriceAvailable() {
                public void priceAvailable() {
                    if (BillingManager.this.skusWithSkuDetails.getValue() != null) {
                        skuDetailsArr[0] = (SkuDetails) ((Map) BillingManager.this.skusWithSkuDetails.getValue()).get(str);
                    }
                    if (skuDetailsArr[0] == null) {
                        BillingManager.this.querySkuDetails();
                        return;
                    }
                    for (TextView textView : BillingManager.this.textViews) {
                        textView.setText(String.format(textView.getText().toString(), new Object[]{skuDetailsArr[0].getPrice()}));
                    }
                    BillingManager.this.textViews = new ArrayList();
                    BillingManager.this.onPriceAvailable = null;
                }
            };
            querySkuDetails();
            return;
        }
        textView.setText(String.format(textView.getText().toString(), new Object[]{skuDetailsArr[0].getPrice()}));
    }

    public void checkRestore(final OnDismissListener onDismissListener) {
        setonhistoryfetcher(new HistoryFetcher() {
            public void ongetHistory(int i, List<PurchaseHistoryRecord> list) {
                if (list == null || list.size() <= 0) {
                    BillingManager.this.handleUnsubscribed();
                } else {
                    BillingManager.this.handleSubscribed();
                    for (PurchaseHistoryRecord acknowledgement : list) {
                        BillingManager.this.acknowledgement(acknowledgement);
                    }
                }
                if (BillingManager.this.isAccountHold()) {
                    BillingManager.this.openGoogleDialog(false, null);
                } else if (BillingManager.this.isRecovered()) {
                    BillingManager.this.openGoogleDialog(true, onDismissListener);
                }
            }
        });
    }

    private int getLocalSubscriptionStatus() {
        return android.preference.PreferenceManager.getDefaultSharedPreferences(this.mActivity).getInt("subscription-status", 0);
    }

    private void setLocalSubscriptionStatus(int i) {
        android.preference.PreferenceManager.getDefaultSharedPreferences(this.mActivity).edit().putInt("subscription-status", i).apply();
    }

    public void handleSubscribed() {
        if (getLocalSubscriptionStatus() == 7) {
            setLocalSubscriptionStatus(2);
            return;
        }
        this.tinyDB.putBoolean("purchased", true);
        setLocalSubscriptionStatus(1);
    }

    public void handleUnsubscribed() {
        int localSubscriptionStatus = getLocalSubscriptionStatus();
        if (localSubscriptionStatus == 1 || localSubscriptionStatus == 2) {
            setLocalSubscriptionStatus(7);
            this.tinyDB.putBoolean("purchased", false);
        }
    }

    public boolean isAccountHold() {
        return getLocalSubscriptionStatus() == 7;
    }

    public boolean isRecovered() {
        return getLocalSubscriptionStatus() == 2;
    }

    public void openGoogleDialog(boolean z, OnDismissListener onDismissListener) {
        final Dialog dialog = new Dialog(this.mActivity);
        dialog.setContentView(R.layout.dialog_retention);
        TextView textView = (TextView) dialog.findViewById(R.id.title);
        TextView textView2 = (TextView) dialog.findViewById(R.id.text_view_desc);
        MaterialTextView materialTextView = (MaterialTextView) dialog.findViewById(R.id.button_confirm);
        if (z) {
            textView.setVisibility(8);
            textView2.setText("Your form of payment was updated, and your subscription has been recovered.");
        } else {
            textView.setVisibility(0);
            textView2.setText("There is a problem with your subscription. Click here to go to the Google Play subscription settings to fix your payment method.");
        }
        materialTextView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        if (z) {
            dialog.setOnDismissListener(onDismissListener);
        }
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        if (!this.mActivity.isFinishing()) {
            dialog.show();
        }
    }
}
