package com.esc.fontappstylish.activity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.RecyclerView;
import com.esc.fontappstylish.adapter.SubThemeAdapter;
import com.esc.fontappstylish.kprogresshud.KProgressHUD;
import com.esc.fontappstylish.permission.PermissionModel;
import com.esc.fontappstylish.utils.Const;
import com.esc.fontappstylish.utils.ImageUtils;
import com.esc.fontappstylish.utils.MyKeyboardInterface.subThemeSelection;
import com.esc.fontappstylish.utils.SharedPreferenceclass;
import com.esc.fontappstylish.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;

public class ChangeImageActivity extends AppCompatActivity {
    private String category;
    private ImageView imgbg;
    private RecyclerView rcvTheme;
    private SharedPreferenceclass sharedPreferenceAapnar;
    private String[] symbolList;
    private ImageView iv_back;
    private ImageView iv_uploadgallery;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int Adid;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_change_image);
        PermissionModel.checkPermission(this);
        this.sharedPreferenceAapnar = new SharedPreferenceclass(this);
        BindView();
        loadAd();
        BannerAds();
        this.category = "albums";
        try {
            this.symbolList = getAssets().list(this.category);
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.rcvTheme.setLayoutManager(new GridLayoutManager(this, 2));
        this.rcvTheme.setAdapter(new SubThemeAdapter(this, new ArrayList(Arrays.asList(this.symbolList)), new subThemeSelection() {
            public void getSubThemePosition(InputStream inputStream) {
                Bitmap decodeStream = BitmapFactory.decodeStream(inputStream);
                ChangeImageActivity.this.sharedPreferenceAapnar.setImage("imagePreferance", Const.encodeTobase64(decodeStream));
                ChangeImageActivity.this.imgbg.setImageBitmap(ChangeImageActivity.this.loadImageFromStorage(Const.saveImageToInternalStorage(ChangeImageActivity.this.getApplicationContext(), decodeStream, "img.png").toString()));
            }
        }));
    }

    private void BindView() {
        this.rcvTheme = findViewById(R.id.rcvTheme);
        this.imgbg = findViewById(R.id.imgbg);
        iv_back = findViewById(R.id.iv_back);
        iv_uploadgallery = findViewById(R.id.iv_uplodegallery);
        String image = this.sharedPreferenceAapnar.getImage("imagePreferance", getResources().getDrawable(R.mipmap.ic_launcher));
        if (image != null) {
            Bitmap decodeBase64 = Const.decodeBase64(image);
            new BitmapDrawable(getResources(), decodeBase64);
            this.imgbg.setImageBitmap(decodeBase64);
        }

        iv_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitial != null && interstitial.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(ChangeImageActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                Adid = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                } else {
                    startActivity(new Intent(ChangeImageActivity.this, FirstActivity.class));
                    finish();
                }
            }
        });

        iv_uploadgallery.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivityForResult(getPickImageChooserIntent(), Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            }
        });
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 123 && i2 == 1111) {
            Bitmap loadImageFromStorage = loadImageFromStorage(intent.getStringExtra("myResult"));
            this.imgbg.setImageBitmap(loadImageFromStorage);
            this.sharedPreferenceAapnar.setImage("imagePreferance", Const.encodeTobase64(loadImageFromStorage));
        }
        if (i2 == -1 && i == Callback.DEFAULT_DRAG_ANIMATION_DURATION) {
            String imageFilePath = getImageFilePath(intent);
            Intent intent2 = new Intent(this, CropActivity.class);
            intent2.putExtra("picturePath", imageFilePath);
            startActivityForResult(intent2, 123);
        }
    }

    private Bitmap loadImageFromStorage(String str) {
        return ImageUtils.getInstant().getCompressedBitmap22(new File(str).getAbsolutePath());
    }

    public Intent getPickImageChooserIntent() {
        Uri captureImageOutputUri = getCaptureImageOutputUri();
        ArrayList<Intent> arrayList = new ArrayList();
        PackageManager packageManager = getPackageManager();
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        for (ResolveInfo resolveInfo : packageManager.queryIntentActivities(intent, 0)) {
            Intent intent2 = new Intent(intent);
            intent2.setComponent(new ComponentName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name));
            intent2.setPackage(resolveInfo.activityInfo.packageName);
            if (captureImageOutputUri != null) {
                intent2.putExtra("output", captureImageOutputUri);
            }
            arrayList.add(intent2);
        }
        Intent intent3 = new Intent("android.intent.action.GET_CONTENT");
        intent3.setType("image/*");
        for (ResolveInfo resolveInfo2 : packageManager.queryIntentActivities(intent3, 0)) {
            Intent intent4 = new Intent(intent3);
            intent4.setComponent(new ComponentName(resolveInfo2.activityInfo.packageName, resolveInfo2.activityInfo.name));
            intent4.setPackage(resolveInfo2.activityInfo.packageName);
            arrayList.add(intent4);
        }
        Intent obj = arrayList.get(arrayList.size() - 1);
        for (Intent intent5 : arrayList) {
            if (intent5.getComponent().getClassName().equals("com.android.documentsui.DocumentsActivity")) {
                obj = intent5;
                break;
            }
        }
        arrayList.remove(obj);
        intent3 = Intent.createChooser(obj, "Select source");
        intent3.putExtra("android.intent.extra.INITIAL_INTENTS", arrayList.toArray(new Parcelable[arrayList.size()]));
        return intent3;
    }

    private Uri getCaptureImageOutputUri() {
        File externalFilesDir = getExternalFilesDir("");
        return externalFilesDir != null ? Uri.fromFile(new File(externalFilesDir.getPath(), "profile.png")) : null;
    }

    public String getImageFilePath(Intent intent) {
        return getImageFromFilePath(intent);
    }

    private String getImageFromFilePath(Intent intent) {
        Object obj = (intent == null || intent.getData() == null) ? 1 : null;
        if (obj != null) {
            return getCaptureImageOutputUri().getPath();
        }
        return getPathFromURI(intent.getData());
    }

    private String getPathFromURI(Uri uri) {
        String[] strArr = new String[1];
        String str = "_data";
        strArr[0] = str;
        Cursor query = getContentResolver().query(uri, strArr, null, null, null);
        int columnIndexOrThrow = query.getColumnIndexOrThrow(str);
        query.moveToFirst();
        return query.getString(columnIndexOrThrow);
    }

    private void loadAd() {
        //InterstitialAd

        interstitial = new InterstitialAd(ChangeImageActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        startActivity(new Intent(ChangeImageActivity.this, FirstActivity.class));
                        finish();
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(ChangeImageActivity.this);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(ChangeImageActivity.this);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onBackPressed() {
        startActivity(new Intent(ChangeImageActivity.this, FirstActivity.class));
        finish();
    }
}
