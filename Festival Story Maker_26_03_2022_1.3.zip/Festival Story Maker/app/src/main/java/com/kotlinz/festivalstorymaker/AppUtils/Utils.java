package com.kotlinz.festivalstorymaker.AppUtils;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;

import java.io.File;
import java.io.FileOutputStream;

public class  Utils {
    public static final Utils INSTANCE;
    public static long mDeleteFileCount;

    static {
        INSTANCE = new Utils();
        Utils.mDeleteFileCount = 0L;
    }

    public static void CreateDirectory() {
      /*  try {
            String rootPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + "/Festival Story Maker /";
            File root = new File(rootPath);
            if (!root.exists()) {
                root.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }*/
    }

    public final String getAPPFOLDER() {
        return "Festival Story Maker";
    }

    public final String getOutputPathExternalStorage() {
        final String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + File.separator + this.getAPPFOLDER() + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getOutputPath(Context context) {
        final String path = context.getFilesDir() + File.separator + this.getAPPFOLDER() + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getThemeFolderPath(Context context) {
        final String path = this.getOutputPath(context) + "ThemeDownload" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getBusinessTemplateFolderPath(Context context) {
        final String path = this.getOutputPath(context) + "BusinessTemplateDownload" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getTemplateImage() {
        final String path = this.getOutputPathExternalStorage() + "Share Image" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }
    public static boolean isNetworkConnected(final Context lCon) {
        final ConnectivityManager cm = (ConnectivityManager) lCon.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }


    public static boolean checkConnectivity(Context lCon, final boolean show) {
        if (isNetworkConnected(lCon)) {
            return true;
        }
        if (show) {
            Toast.makeText(lCon, "Data/Wifi Not Available", Toast.LENGTH_LONG).show();
        }
        return false;
    }

    public static boolean deleteFile(final File mFile) {
        boolean idDelete = false;
        if (mFile == null) {
            return idDelete;
        }
        if (mFile.exists()) {
            if (mFile.isDirectory()) {
                final File[] children = mFile.listFiles();
                if (children != null && children.length > 0) {
                    File[] array;
                    for (int length = (array = children).length, i = 0; i < length; ++i) {
                        final File child = array[i];
                        Utils.mDeleteFileCount += child.length();
                        idDelete = deleteFile(child);
                    }
                }
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            } else {
                Log.e("TAG", "Delete Successfully");
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            }
        }
        Log.e("TAG", " idDelete" + idDelete);
        return idDelete;
    }

    public void CameraImageSave(Bitmap imageToSave, String fileName) {
        File direct = new File(AppConstant.CameraImageFilePath);
        if (!direct.exists()) {
            File wallpaperDirectory = new File(AppConstant.CameraImageFilePath);
            wallpaperDirectory.mkdirs();
        }
        File file = new File(AppConstant.CameraImageFilePath, fileName);
        if (file.exists()) {
            file.delete();
        }
        try {
            FileOutputStream out = new FileOutputStream(file);
            imageToSave.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
