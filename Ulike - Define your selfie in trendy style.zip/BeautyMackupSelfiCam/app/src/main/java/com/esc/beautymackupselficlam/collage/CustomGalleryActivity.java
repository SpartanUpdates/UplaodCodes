package com.esc.beautymackupselficlam.collage;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.Toast;

import com.esc.beautymackupselficlam.R;
import com.esc.beautymackupselficlam.adapter.CustomGalleryAdapter;
import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiskCache;
import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.listener.PauseOnScrollListener;
import com.nostra13.universalimageloader.utils.StorageUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

public class CustomGalleryActivity extends Activity {
    private String action;
    private CustomGalleryAdapter CustomGalleryadapter;
    private Button btnGalleryOk;
    private GridView gridGallery;
    private Handler handler;
    private ImageLoader imageLoader;
    private ImageView imgNoMedia;
    AdapterView.OnItemClickListener itemMulClickListener;
    AdapterView.OnItemClickListener itemSingleClickListener;
    View.OnClickListener mOkClickListener;

    public CustomGalleryActivity() {
        this.mOkClickListener = (View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                final ArrayList<CustomGallery> selected = CustomGalleryActivity.this.CustomGalleryadapter.getSelected();
                if (selected.size() >= 3) {
                    final String[] array = new String[selected.size()];
                    for (int i = 0; i < array.length; ++i) {
                        array[i] = selected.get(i).sdcardPath;
                    }
                    CustomGalleryActivity.this.setResult(-1, new Intent().putExtra("all_path", array));
                    CustomGalleryActivity.this.finish();
                    return;
                }
                Toast.makeText((Context) CustomGalleryActivity.this, (CharSequence) "PLease select minimum 3 and maximum 6 images.", Toast.LENGTH_SHORT).show();
            }
        };
        this.itemMulClickListener = (AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                System.out.println("pressed");
                CustomGalleryActivity.this.CustomGalleryadapter.changeSelection(view, n);
            }
        };
        this.itemSingleClickListener = (AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                CustomGalleryActivity.this.setResult(-1, new Intent().putExtra("single_path", CustomGalleryActivity.this.CustomGalleryadapter.getItem(n).sdcardPath));
                CustomGalleryActivity.this.finish();
            }
        };
    }

    private void checkImageStatus() {
        if (this.CustomGalleryadapter.isEmpty()) {
            this.imgNoMedia.setVisibility(View.GONE);
            return;
        }
        this.imgNoMedia.setVisibility(View.GONE);
    }

    private ArrayList<CustomGallery> getGalleryPhotos() {
        final ArrayList<CustomGallery> list = new ArrayList<CustomGallery>();
        try {
            final Cursor managedQuery = this.managedQuery(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{"_data", "_id"}, (String) null, (String[]) null, "_id");
            if (managedQuery != null && managedQuery.getCount() > 0) {
                while (managedQuery.moveToNext()) {
                    final CustomGallery customGallery = new CustomGallery();
                    customGallery.sdcardPath = managedQuery.getString(managedQuery.getColumnIndex("_data"));
                    list.add(customGallery);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Collections.reverse(list);
        return list;
    }

    private void init() {
        this.handler = new Handler();
        (this.gridGallery = (GridView) this.findViewById(R.id.gridGallery)).setFastScrollEnabled(true);
        this.CustomGalleryadapter = new CustomGalleryAdapter(this.getApplicationContext(), this.imageLoader);
        this.gridGallery.setOnScrollListener((AbsListView.OnScrollListener) new PauseOnScrollListener(this.imageLoader, true, true));
        if (this.action.equalsIgnoreCase("com.esc.beautymackupselficlam.ACTION_MULTIPLE_PICK")) {
            this.findViewById(R.id.llBottomContainer).setVisibility(View.VISIBLE);
            this.gridGallery.setOnItemClickListener(this.itemMulClickListener);
            this.CustomGalleryadapter.setMultiplePick(true);
        } else if (this.action.equalsIgnoreCase("com.esc.beautymackupselficlam.ACTION_PICK")) {
            this.findViewById(R.id.llBottomContainer).setVisibility(View.GONE);
        }
        this.gridGallery.setAdapter((ListAdapter) this.CustomGalleryadapter);
        this.imgNoMedia = (ImageView) this.findViewById(R.id.imgNoMedia);
        this.btnGalleryOk = (Button) this.findViewById(R.id.btnGalleryOk);
        this.btnGalleryOk.setOnClickListener(this.mOkClickListener);
        new Thread() {
            @Override
            public void run() {
                Looper.prepare();
                CustomGalleryActivity.this.handler.post((Runnable) new Runnable() {
                    @Override
                    public void run() {
                        CustomGalleryActivity.this.CustomGalleryadapter.addAll(CustomGalleryActivity.this.getGalleryPhotos());
                        CustomGalleryActivity.this.checkImageStatus();
                    }
                });
                Looper.loop();
            }
        }.start();
    }

    private void initImageLoader() {
        try {
            final String string = Environment.getExternalStorageDirectory().getAbsolutePath() + "/.temp_tmp";
            new File(string).mkdirs();
            (this.imageLoader = ImageLoader.getInstance()).init(new ImageLoaderConfiguration.Builder(this.getBaseContext()).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheOnDisc(true).imageScaleType(ImageScaleType.EXACTLY).bitmapConfig(Bitmap.Config.RGB_565).build()).discCache(new UnlimitedDiskCache(StorageUtils.getOwnCacheDirectory(this.getBaseContext(), string))).memoryCache(new WeakMemoryCache()).build());
        } catch (Exception ex) {
        }
    }

    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.requestWindowFeature(1);
        this.setContentView(R.layout.gallery_grid);
        this.action = this.getIntent().getAction();
        if (this.action == null) {
            this.finish();
        }
        this.initImageLoader();
        this.init();
    }
}
