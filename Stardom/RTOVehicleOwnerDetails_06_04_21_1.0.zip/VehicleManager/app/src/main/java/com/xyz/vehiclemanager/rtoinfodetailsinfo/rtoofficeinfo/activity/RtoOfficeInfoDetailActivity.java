package com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.utils.Utils;

import androidx.appcompat.app.AppCompatActivity;

public class RtoOfficeInfoDetailActivity extends AppCompatActivity {

    private Activity activity = RtoOfficeInfoDetailActivity.this;
    private String cityCode, cityName, StateName, address, contact, website;
    private TextView tv_district;
    private TextView tv_rtoCode;
    private TextView tv_address;
    private TextView tv_phone;
    private TextView tv_website;
    private TextView tv_state;
    private ImageView iv_back;
    private LinearLayout ll_address;
    private LinearLayout ll_contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rtoofficeinfo_detail);
        cityCode = getIntent().getStringExtra("cityCode");
        cityName = getIntent().getStringExtra("cityName");
        StateName = getIntent().getStringExtra("StateName");
        address = getIntent().getStringExtra("address");
        contact = getIntent().getStringExtra("contact");
        website = getIntent().getStringExtra("website");
        BindView();
        PutAnalyticsEvent();
        if (Utils.isOnline(activity)) {
            setCityData();
        } else {
            Toast.makeText(activity, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    private void BindView() {
        tv_district = findViewById(R.id.tv_district);
        tv_rtoCode = findViewById(R.id.tv_rtoCode);
        tv_state = findViewById(R.id.tv_state);
        tv_address = findViewById(R.id.tv_address);
        tv_phone = findViewById(R.id.tv_contact);
        tv_website = findViewById(R.id.tv_website);
        iv_back = findViewById(R.id.iv_back);
        ll_address = findViewById(R.id.ll_address);
        ll_contact = findViewById(R.id.ll_contact);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "RtoOfficeInfoDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void setCityData() {
        tv_district.setText(cityName);
        tv_rtoCode.setText(cityCode);
        tv_address.setText(address);
        tv_state.setText(StateName);
        tv_website.setText(website);
        if (contact == null) {
            ll_contact.setVisibility(View.GONE);
        } else {
            tv_phone.setText(contact);
        }

        if (address == null) {
            ll_address.setVisibility(View.GONE);
        } else {
            tv_address.setText(address);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}