package com.vidsoft.videostatusmaker.App;

import android.app.Application;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;

public class MyApplication extends Application {

    private static MyApplication instance;



    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        AudienceNetworkAds.initialize(this);
        AdSettings.addTestDevice("c5d8395e-df5f-443a-873e-17c03f610a54");

    }
}
