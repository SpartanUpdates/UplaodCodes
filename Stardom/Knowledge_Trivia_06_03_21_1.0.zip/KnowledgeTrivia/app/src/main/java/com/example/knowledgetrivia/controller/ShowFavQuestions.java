package com.example.knowledgetrivia.controller;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.knowledgetrivia.R;


public class ShowFavQuestions extends AppCompatActivity {
    private MediaPlayer tick;


    public void onCreate(Bundle bundle) {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_show_fav_questions);
        this.tick = MediaPlayer.create(this, R.raw.tick);
        Intent intent = getIntent();
        ((TextView) findViewById(R.id.showfav_question)).setText(intent.getStringExtra("question"));
        ((TextView) findViewById(R.id.showfav_answer)).setText(intent.getStringExtra("answer"));
        findViewById(R.id.dismiss).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ShowFavQuestions.this.tick.start();
                ShowFavQuestions.this.finish();
            }
        });
    }

    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}
