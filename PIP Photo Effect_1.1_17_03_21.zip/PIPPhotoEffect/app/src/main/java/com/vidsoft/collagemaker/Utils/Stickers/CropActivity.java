package com.vidsoft.collagemaker.Utils.Stickers;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.naver.android.helloyako.imagecrop.view.ImageCropView;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Utils;

public class CropActivity extends Activity {
    public static final String TAG = "CropActivity";
    private ImageCropView imageCropView;
    private float intRotateLeft;
    private AdView adView;
    public CropActivity() {
        super();
        this.intRotateLeft = 0.0f;
    }

    static/* synthetic */void access$3(final CropActivity cropActivity,
                                       final float int_rotate_left) {
        cropActivity.intRotateLeft = int_rotate_left;
    }

    private void startEffect() {
        this.setResult(-1, this.getIntent());
        this.finish();
    }

    public void onBackPressed() {
    }

    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.crop_imgactivity);
        (this.imageCropView = (ImageCropView) this.findViewById(R.id.imageMain))
                .setImageBitmap(Utility.CropBitmap);
        this.imageCropView.setAspectRatio(1, 1);
        this.findViewById(R.id.next_btn).setOnClickListener(
                (View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view) {
                        if (!CropActivity.this.imageCropView.isChangingScale()) {
                            Utility.CropBitmap = CameraUtils.getResizedBitmap(
                                    CameraUtils.rotate(
                                            CropActivity.this.imageCropView
                                                    .getCroppedImage(),
                                            CropActivity.this.intRotateLeft),
                                    400, 400);
                            CropActivity.this.startEffect();
                        }
                    }
                });
        this.findViewById(R.id.back_btn).setOnClickListener(
                (View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view) {
                        CropActivity.this.finish();
                    }
                });
        this.findViewById(R.id.rotate_left).setOnClickListener(
                (View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view) {
                        final CropActivity this$0 = CropActivity.this;
                        CropActivity.access$3(this$0,
                                this$0.intRotateLeft + 90.0f);
                        CropActivity.this.imageCropView
                                .setRotation(CropActivity.this.intRotateLeft);
                    }
                });
        this.findViewById(R.id.rotate_right).setOnClickListener(
                (View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view) {
                        final CropActivity this$0 = CropActivity.this;
                        CropActivity.access$3(this$0,
                                this$0.intRotateLeft - 90.0f);
                        CropActivity.this.imageCropView
                                .setRotation(CropActivity.this.intRotateLeft);
                    }
                });
        if (Utils.isNetworkAvailable(CropActivity.this)) {
            adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
            LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);
            adContainer.addView(adView);
            adView.loadAd();
        }
    }
}
