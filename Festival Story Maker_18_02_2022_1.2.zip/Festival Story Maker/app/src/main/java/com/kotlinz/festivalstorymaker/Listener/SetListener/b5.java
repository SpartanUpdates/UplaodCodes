package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class b5 implements View.OnClickListener {
    public final int e;
    public final ImageView f;
    public final com.kotlinz.festivalstorymaker.Models.g g;
    public final CardView h;
    public final CardView i;
    public final RecyclerView j;
    public final RecyclerView k;
    public final FrameEditorNewDesign l;

    public b5(final FrameEditorNewDesign l, final int e, final ImageView f, final com.kotlinz.festivalstorymaker.Models.g g, final CardView h, final CardView i, final RecyclerView j, final RecyclerView k) {
        this.l = l;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
        this.k = k;
    }

    public void onClick(final View view) {
        final FrameEditorNewDesign l = this.l;
        if (!l.W0 && !l.t1) {
            l.u0();
            this.l.d0 = this.e;
            final ImageView v1 = FrameEditorNewDesign.v1;
            if (v1 != null) {
                v1.setOnTouchListener((View.OnTouchListener) null);
                FrameEditorNewDesign.v1.setBackground((Drawable) null);
            }
            final TextView w1 = FrameEditorNewDesign.w1;
            if (w1 != null) {
                w1.setBackground((Drawable) null);
            }
            FrameEditorNewDesign.F1 = (FrameEditorNewDesign.v1 = this.f);
            FrameEditorNewDesign.R1 = false;
            FrameEditorNewDesign.S1 = false;
            FrameEditorNewDesign.T1 = false;
            FrameEditorNewDesign.M1 = false;
            FrameEditorNewDesign frameEditorNewDesign;
            Object o;
            if (!this.g.F.equals("1") && !this.g.E.equals("1")) {
                frameEditorNewDesign = this.l;
                if (this.g.G.equals("1")) {
                    o = this.j;
                } else {
                    o = this.k;
                }
            } else {
                frameEditorNewDesign = this.l;
                if (this.g.F.equals("1")) {
                    o = this.h;
                } else {
                    o = this.i;
                }
            }
            FrameEditorNewDesign.k0(frameEditorNewDesign, (View) o);
            return;
        }
        final FrameEditorNewDesign i = this.l;
        i.t1 = false;
        i.W0 = false;
    }
}
