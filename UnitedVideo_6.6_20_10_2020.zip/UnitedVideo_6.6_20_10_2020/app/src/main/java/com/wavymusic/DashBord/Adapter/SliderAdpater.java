/*
package com.wavymusic.DashBord.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.smarteist.autoimageslider .SliderViewAdapter;
import com.wavymusic.DashBord.Model.SliderModel;
import com.wavymusic.R;
import java.util.ArrayList;

public class SliderAdpater extends SliderViewAdapter<SliderAdpater.SlideAdapterHolder> {

    private Context context;
    private ArrayList<SliderModel> sliderList = new ArrayList<>();

    public SliderAdpater(Context context, ArrayList<SliderModel> sliderList) {
        this.context = context;
        this.sliderList = sliderList;
    }

    @Override
    public SlideAdapterHolder onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_slider_item, null, false);
        return new SlideAdapterHolder(inflate);
    }

    @Override
    public void onBindViewHolder(SlideAdapterHolder viewHolder, final int position) {
        SliderModel sliderItem = sliderList.get(position);
//        Glide.with(context).load(sliderItem.getImagePath()).into(viewHolder.ivBanner);
        viewHolder.layoutSldierMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    @Override
    public int getCount() {
//        return sliderList.size();
        return 6;
    }

    class SlideAdapterHolder extends SliderViewAdapter.ViewHolder {

        FrameLayout layoutSldierMain;
        ImageView ivBanner;

        public SlideAdapterHolder(View itemView) {
            super(itemView);
            layoutSldierMain = itemView.findViewById(R.id.fl_slider_main);
            ivBanner = itemView.findViewById(R.id.iv_banner);
        }

    }
}
*/
