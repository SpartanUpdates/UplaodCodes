package com.unikapp.faceappeditor.Utils;

import android.util.Log;

import java.io.File;
import java.util.ArrayList;


public class Utils {


    public static class Constant {
        public static final float HUE_CYAN = 180.0f;
        public static ArrayList<String> IMAGEALLARY;

        static {
            Constant.IMAGEALLARY = new ArrayList<String>();
        }
        public static void listAllImages(final File file) {
            final File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (int i = listFiles.length - 1; i >= 0; --i) {
                    final String string = listFiles[i].toString();
                    final File file2 = new File(string);
                    Log.d("" + file2.length(), "" + file2.length());
                    if (file2.length() > 1024L) {
                        if (file2.toString().contains(".jpg")
                                || file2.toString().contains(".png")
                                || file2.toString().contains(".jpeg")) {
                            Constant.IMAGEALLARY.add(string);
                        }
                    } else {
                        Log.i("Invalid Image", "Delete Image");
                    }
                    System.out.println(string);
                }
            } else {
                System.out.println("Empty Folder");
            }
        }
    }
}
