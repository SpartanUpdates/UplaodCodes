package com.esc.gesturelockscreen.Other;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.opengl.GLES10;
import android.util.DisplayMetrics;
import com.esc.gesturelockscreen.R;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class BitmapUtils {
    public static int sInputImageHeight = 0;
    public static int sInputImageWidth = 0;

    Context mContext;

    public BitmapUtils(Context context) {
        this.mContext = context;
    }


    public static Bitmap decodeSampledBitmapFromUri(Context context, Uri sourceUri, int requestSize) {
        InputStream is = null;
        try {
            is = context.getContentResolver().openInputStream(sourceUri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Options options = new Options();
        options.inSampleSize = calculateInSampleSize(context, sourceUri, requestSize);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeStream(is, null, options);
    }

    public static int calculateInSampleSize(Context context, Uri sourceUri, int requestSize) {
        InputStream is = null;
        Options options = new Options();
        options.inJustDecodeBounds = true;
        try {
            is = context.getContentResolver().openInputStream(sourceUri);
            BitmapFactory.decodeStream(is, null, options);
        } catch (FileNotFoundException e) {
        } finally {
            closeQuietly(is);
        }
        int inSampleSize = 1;
        sInputImageWidth = options.outWidth;
        sInputImageHeight = options.outHeight;
        while (true) {
            if (options.outWidth / inSampleSize <= requestSize && options.outHeight / inSampleSize <= requestSize) {
                return inSampleSize;
            }
            inSampleSize *= 2;
        }
    }

    public static int getMaxSize() {
        int[] arr = new int[1];
        GLES10.glGetIntegerv(3379, arr, 0);
        if (arr[0] > 0) {
            return Math.min(arr[0], 4096);
        }
        return 2048;
    }

    public static void closeQuietly(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (Throwable th) {
            }
        }
    }

    public Bitmap getBackgroundBitmap() {
        DisplayMetrics displayMetrics = this.mContext.getResources().getDisplayMetrics();
        int i = displayMetrics.widthPixels;
        int i2 = displayMetrics.heightPixels;
        boolean booleanPref = PrefUtils.getBooleanPref(this.mContext, PrefUtils.PRF_IS_SET_GALLERY, false);
        PrefUtils.getBooleanPref(this.mContext, PrefUtils.PRF_IS_SET_BGCOLOR, false);
        boolean booleanPref2 = PrefUtils.getBooleanPref(this.mContext, PrefUtils.PRF_IS_SET_BACKGROUND, false);
        int intPref = PrefUtils.getIntPref(this.mContext, PrefUtils.PRF_SET_FRAME_BLUR_RADIUS, 0);
        Context context;
        if (booleanPref) {
            context = this.mContext;
            return BlurBitmap.getBlurBitmap(context, StaticBitmapUtils.decodeFileFromUriToBitmap(Uri.parse(PrefUtils.getStringPref(context, PrefUtils.PRF_SELECTED_GALLERY_IMG_URI, ""))), intPref);
        } else if (booleanPref2) {
            context = this.mContext;
            return BlurBitmap.getBlurBitmap(context, BitmapFactory.decodeResource(context.getResources(), Constant.arrBG[PrefUtils.getIntPref(this.mContext, PrefUtils.PRF_BACKGROUND_IMG_POSITION, 0)].intValue()), intPref);
        } else {
            Options options = new Options();
            options.inSampleSize = 8;
            Context context2 = this.mContext;
            return BlurBitmap.getBlurBitmap(context2, BitmapFactory.decodeResource(context2.getResources(), R.drawable.music_bg1, options), 12);
        }
    }
}
