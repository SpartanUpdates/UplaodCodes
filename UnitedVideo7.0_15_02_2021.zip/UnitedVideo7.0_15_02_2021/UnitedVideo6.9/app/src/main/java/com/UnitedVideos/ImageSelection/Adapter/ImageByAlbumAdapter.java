package com.UnitedVideos.ImageSelection.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.UnitedVideos.ImageSelection.activity.SelectImageActivityUv;
import com.bumptech.glide.RequestManager;
import com.wavymusic.App.MyApplication;
import com.wavymusic.ImageSelection.Interface.OnItemClickListner;
import com.wavymusic.ImageSelection.Model.ImageModel;
import com.wavymusic.R;

public class ImageByAlbumAdapter extends RecyclerView.Adapter<ImageByAlbumAdapter.Holder> {
    private MyApplication application;
    private LayoutInflater inflater;
    private OnItemClickListner<Object> clickListner;
    private RequestManager glide;
    private SelectImageActivityUv activity;

    public ImageByAlbumAdapter(Context context) {
        application = MyApplication.getInstance();
        inflater = LayoutInflater.from(context);
        glide = com.bumptech.glide.Glide.with(context);
        activity = ((SelectImageActivityUv) context);
    }

    public void setOnItemClickListner(OnItemClickListner<Object> clickListner) {
        this.clickListner = clickListner;
    }



    public int getItemCount() {
        return application.getImageByAlbum(application.getSelectedFolderId()).size();
    }

    public ImageModel getItem(int pos) {
        return application.getImageByAlbum(application.getSelectedFolderId()).get(pos);
    }


    public void onBindViewHolder(final Holder holder, final int pos) {
        final ImageModel data = this.getItem(pos);
        holder.textView.setSelected(true);
        holder.textView.setText((data.imageCount == 0) ? "" : String.format("%02d", data.imageCount));
        this.glide.load(data.imagePath).into(holder.imageView);
        holder.textView.setBackgroundColor((data.imageCount == 0) ? 0 : this.activity.getResources().getColor(R.color.image_counter_color));

        holder.clickableView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (holder.imageView.getDrawable() == null) {

                    Toast.makeText(application, "Image currpted or not support.", Toast.LENGTH_LONG).show();
                    return;
                }
                if (application.getSelectedImages().size() < MyApplication.TotalSelectedImage) {
                    application.addSelectedImage(data);
                    notifyItemChanged(pos);

                } else {
                    Toast.makeText(application, "Please Select only " + MyApplication.TotalSelectedImage + " Image", Toast.LENGTH_SHORT).show();
                }
                if (clickListner != null) {
                    clickListner.onItemClick(v, data);
                }
            }
        });
    }
    public class Holder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;
        View parent;
        View clickableView;

        public Holder(View v) {
            super(v);
            parent = v;
            imageView = v.findViewById(R.id.imageView1);
            textView = v.findViewById(R.id.textView1);
            clickableView = v.findViewById(R.id.clickableView);
        }

        public void onItemClick(View view, Object item) {
            if (clickListner != null) {
                clickListner.onItemClick(view, item);
            }
        }
    }

    @NonNull
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int pos) {
        return new Holder(inflater.inflate(R.layout.row_image_by_folder, parent,
                false));
    }
}
