package com.kotlinz.vehiclemanager.famousperson.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class famousListAdapter extends RecyclerView.Adapter<famousListAdapter.ViewHolder> {
    Context context;
    LayoutInflater inflater;
    String[] name;
    String[] number;
    OnItemClickListener onItemClickListener;
    DarkTheame darkTheame;

    public famousListAdapter(Context context, String[] strArr, String[] strArr2, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.name = strArr;
        this.number = strArr2;
        this.onItemClickListener = onItemClickListener;
        this.inflater = LayoutInflater.from(context);
        this.darkTheame=new DarkTheame(context);
    }

    public interface OnItemClickListener {
        void onItemClick(View view, int i);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements AdapterView.OnItemClickListener {
        TextView tvcelebName;
        TextView tvcelebNumber;
        ImageView iv_celeb_icon;
        LinearLayout layout_trendingi_item;
        LinearLayout ll_celebrity_layout;
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        }

        public ViewHolder(@NonNull final View view) {
            super(view);
            this.iv_celeb_icon = view.findViewById(R.id.celeb_icon);
            this.tvcelebName = view.findViewById(R.id.celebName);
            this.tvcelebNumber = view.findViewById(R.id.celebNumber);
            this.ll_celebrity_layout=view.findViewById(R.id.ll_celebrity_layout);
            this.layout_trendingi_item = view.findViewById(R.id.trendingi_item_layout);
            view.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    famousListAdapter.this.onItemClickListener.onItemClick(view, ViewHolder.this.getAdapterPosition());
                }
            });
        }
    }

    @NonNull
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ViewHolder(this.inflater.inflate(R.layout.layout_celebrity, viewGroup, false));
    }

    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        if(darkTheame.modeData().equals("nightMode"))
        {
            viewHolder.ll_celebrity_layout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        }
        viewHolder.tvcelebName.setText(this.number[i]);
        viewHolder.tvcelebNumber.setText(this.name[i]);
    }

    public int getItemCount() {
        return this.name.length;
    }
}
