package com.esc.flashlight.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;

import com.esc.flashlight.App.APP;


public class ScreenReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        String str = "ScreenReceiver";
        if ("android.intent.action.SCREEN_OFF".equals(action)) {
            APP.getPrefManager().setScreenOnTime(-1);
            Log.d(str, "screen off");
        } else if ("android.intent.action.SCREEN_ON".equals(action)) {
            APP.getPrefManager().setScreenOnTime(SystemClock.elapsedRealtime());
            Log.d(str, "screen on");
        }
    }
}
