package com.example.postermaker.textitems;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import com.example.postermaker.eaz_EditActivity;
import com.xiaopo.flying.sticker.TextSticker;

public class eaz_TextEditor implements OnClickListener {
    Context context;

    public eaz_TextEditor(Context context) {
        this.context = context;
    }

    public void loadTextItemsLayout() {
        addnewText();
        eaz_EditActivity.textItemlayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.addtextlogo.setOnClickListener(this);
        eaz_EditActivity.textbgcolor.setOnClickListener(this);
        eaz_EditActivity.textcolor.setOnClickListener(this);
        eaz_EditActivity.textborder.setOnClickListener(this);
        eaz_EditActivity.textsize.setOnClickListener(this);
        eaz_EditActivity.gradient.setOnClickListener(this);
        eaz_EditActivity.texture.setOnClickListener(this);
        eaz_EditActivity.font.setOnClickListener(this);
        eaz_EditActivity.arctext.setOnClickListener(this);
        eaz_EditActivity.donetext.setOnClickListener(this);
    }

    public void addnewText() {
        eaz_EditActivity.logoText = new TextView(this.context);
        eaz_EditActivity.logoText.setLayoutParams(new LayoutParams(-2, -2));
        eaz_EditActivity.logoText.setText("Company Name");
        eaz_EditActivity.logoText.setTextSize(40.0f);
        eaz_EditActivity.logoText.setGravity(17);
        eaz_EditActivity.textdrawLayout.addView(eaz_EditActivity.logoText);
    }

    public void onClick(View view) {
        String str = "No Text Found";
        if (view.equals(eaz_EditActivity.addtextlogo)) {
            new eaz_AddTextLayout().showTextLayout();
        } else if (view.equals(eaz_EditActivity.textbgcolor)) {
            new eaz_TextBGColor(0, this.context).applyTextBGColor();
        } else if (view.equals(eaz_EditActivity.textcolor)) {
            new eaz_TextBGColor(1, this.context).applyTextBGColor();
        } else if (view.equals(eaz_EditActivity.textborder)) {
            new eaz_TextBorderItem(this.context).showTextBorderItem();
        } else if (view.equals(eaz_EditActivity.textsize)) {
            new eaz_TextSizeLayout().showTextsizeLayout();
        } else if (view.equals(eaz_EditActivity.gradient)) {
            new eaz_TextGradient(view.getContext(), 0, 'G').showGradientLayout();
        } else if (view.equals(eaz_EditActivity.texture)) {
            new eaz_TextGradient(view.getContext(), 1, 'G').showGradientLayout();
        } else if (view.equals(eaz_EditActivity.font)) {
            new eaz_TextGradient(view.getContext(), 1, 'F').showGradientLayout();
        } else if (view.equals(eaz_EditActivity.arctext)) {
            new eaz_TextShadow().showShadowItems();
        } else if (view.equals(eaz_EditActivity.donetext)) {
            try {
                if (eaz_EditActivity.logoText.getText().length() > 0) {
                    eaz_EditActivity.textdrawLayout.removeAllViews();
                    eaz_EditActivity.logoText.buildDrawingCache();
                    Drawable bitmapDrawable = new BitmapDrawable(view.getContext().getResources(), eaz_EditActivity.logoText.getDrawingCache());
                    TextSticker textSticker = new TextSticker(view.getContext());
                    textSticker.setText("  ");
                    textSticker.setDrawable(bitmapDrawable);
                    textSticker.resizeText();
                    eaz_EditActivity.stickerView.addSticker(textSticker);
                    eaz_EditActivity.stickerView.invalidate();
                    eaz_EditActivity.textItemlayout.setVisibility(View.GONE);
                    eaz_EditActivity.textdrawLayout.removeAllViews();
                    return;
                }
                eaz_EditActivity.textItemlayout.setVisibility(View.GONE);
                Toast.makeText(view.getContext(), str, Toast.LENGTH_SHORT).show();
                eaz_EditActivity.textdrawLayout.removeAllViews();
            } catch (Exception unused) {
                eaz_EditActivity.textItemlayout.setVisibility(View.GONE);
                Toast.makeText(view.getContext(), str, Toast.LENGTH_SHORT).show();
                eaz_EditActivity.textdrawLayout.removeAllViews();
            }
        }
    }
}
