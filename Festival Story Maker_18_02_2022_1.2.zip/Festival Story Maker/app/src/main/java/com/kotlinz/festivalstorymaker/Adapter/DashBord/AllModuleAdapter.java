package com.kotlinz.festivalstorymaker.Adapter.DashBord;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Model.DashBord.AllModule;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Utils;
import com.kotlinz.festivalstorymaker.activity.DashBordActivity;

import java.util.ArrayList;

public class AllModuleAdapter extends RecyclerView.Adapter<AllModuleAdapter.MyViewHolder> {

    DashBordActivity activity;
    ArrayList<AllModule> allModuleList;

    public AllModuleAdapter(Context context, ArrayList<AllModule> allModuleList) {
        this.activity = (DashBordActivity) context;
        this.allModuleList = allModuleList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_all_module, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(activity).load(Utils.ModuleImage(allModuleList.get(position).getModuleName())).into(holder.ivModule);
        holder.llMainModule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Glide.with(activity).load(Utils.ModuleImagePress(allModuleList.get(position).getModuleName())).into(holder.ivModule);
                if (allModuleList.get(position).getModuleName().equals("Poster Maker")) {
                    activity.ModuleId = allModuleList.get(position).getModuleId();
                    activity.PosterMaker();
                } else if (allModuleList.get(position).getModuleName().equals("Story Maker")) {
                    activity.ModuleId = allModuleList.get(position).getModuleId();
                    activity.StoryMaker();
                } else if (allModuleList.get(position).getModuleName().equals("PreDesign ArtBord")) {
                    activity.ModuleId = allModuleList.get(position).getModuleId();
                    activity.PreDesignArtbord();
                } else if (allModuleList.get(position).getModuleName().equals("Thematic Template")) {
                    activity.ModuleId = 33;
                    activity.ThematicTemplate();
                } else if (allModuleList.get(position).getModuleName().equals("Wish Maker")) {
                    activity.ModuleId = allModuleList.get(position).getModuleId();
                    activity.WishMaker();
                } else if (allModuleList.get(position).getModuleName().equals("Offer Poster")) {
                    activity.ModuleId = allModuleList.get(position).getModuleId();
                    activity.OfferPoster();
                } else if (allModuleList.get(position).getModuleName().equals("Festival")) {
                    activity.ModuleId = allModuleList.get(position).getModuleId();
                    activity.FestivalPoster();
                } else if (allModuleList.get(position).getModuleName().equals("Collage Maker")) {
                    activity.ModuleId = allModuleList.get(position).getModuleId();
                    activity.CollageMaker();
                } else if (allModuleList.get(position).getModuleName().equals("Zoom Collage")) {
                    activity.ModuleId = allModuleList.get(position).getModuleId();
                    activity.ZoomCollage();
                } else if (allModuleList.get(position).getModuleName().equals("Quote Maker")) {
                    activity.ModuleId = allModuleList.get(position).getModuleId();
                    activity.QuoteMaker();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return allModuleList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        LinearLayout llMainModule;
        ImageView ivModule;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            llMainModule = itemView.findViewById(R.id.ll_main_module);
            ivModule = itemView.findViewById(R.id.iv_module);
        }
    }
}
