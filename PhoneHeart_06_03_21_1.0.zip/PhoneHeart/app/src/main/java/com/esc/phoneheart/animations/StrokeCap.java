package com.esc.phoneheart.animations;

import android.graphics.Paint.Cap;

public enum StrokeCap {
    BUTT(Cap.BUTT),
    ROUND(Cap.ROUND),
    SQUARE(Cap.SQUARE);
    
    public final Cap a;

    StrokeCap(Cap cap) {
        this.a = cap;
    }
}
