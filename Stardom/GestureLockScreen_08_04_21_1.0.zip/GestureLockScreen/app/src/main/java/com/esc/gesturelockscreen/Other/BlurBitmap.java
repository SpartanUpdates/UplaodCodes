package com.esc.gesturelockscreen.Other;

import android.content.Context;
import android.graphics.Bitmap;

public class BlurBitmap {
    public static Bitmap getBlurBitmap(Context context, Bitmap bitmap, int i) {
        return i > 0 ? GaussianBlur.with(context).size(200.0f).radius(i).render(bitmap) : bitmap;
    }
}
