package com.esc.phoneheart.cooler;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.esc.phoneheart.activity.BaseActivity;
import com.esc.phoneheart.activity.FinalScreen;
import com.esc.phoneheart.R;
import com.esc.phoneheart.promo.ParentScreen;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.pref.SharedPrefUtil;
import com.esc.phoneheart.wrappers.ProcessWrapper;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class CoolerScanScreen extends ParentScreen {
    private Activity activity = CoolerScanScreen.this;
    public boolean backPressed = false;
    public boolean isPause = false;
    public Button btn_cooldowm;
    public Context context;
    public int deviceHeight;
    public int devicewidth;
    public Dialog dialog;
    public ImageView imgRotate;
    public int l = 0;
    public LinearLayout layoutupper;
    public int maxcooled;
    public float mmmmmm;
    public boolean noti_result_back;
    public ArrayList<ProcessWrapper> processList;
    public SharedPrefUtil savedPref;
    public boolean scanCompeted = false;
    public boolean z = false;
    public TextView t_cpuuses;
    public StringBuilder text;
    public TextView tv_processing;
    public TextView tv_temp;
    public TextView tviewSymbol;
    public ArrayList<String> values = new ArrayList<>();
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private void animate() {
        this.imgRotate = findViewById(R.id.img_rotate);
        ImageView imageView = findViewById(R.id.img_still);
        RelativeLayout relativeLayout = findViewById(R.id.layoutimg_media);
        setDeviceDimensio();
        LayoutParams layoutParams = (LayoutParams) this.imgRotate.getLayoutParams();
        layoutParams.width = (getWidth() * 65) / 100;
        layoutParams.height = (getWidth() * 65) / 100;
        this.imgRotate.setLayoutParams(layoutParams);
        LayoutParams layoutParams2 = (LayoutParams) imageView.getLayoutParams();
        layoutParams2.width = (getWidth() * 60) / 100;
        layoutParams2.height = (getWidth() * 60) / 100;
        imageView.setLayoutParams(layoutParams2);
        startAnim();
    }

    public final void animateViews(ImageView imageView, long j, long j2) {
        imageView.animate().translationY((float) this.deviceHeight).setInterpolator(new AccelerateInterpolator()).setDuration(j2);
    }

    public static long checkTimeDifference(String str, String str2) {
        if (str == null || str2 == null) {
            return 90000000L;
        }
        long parseLong = Long.parseLong(str);
        long parseLong2 = Long.parseLong(str2);
        if (parseLong < 0L || parseLong2 < 0L) {
            return 900000000L;
        }
        Date date = new Date(parseLong);
        Date date2 = new Date(parseLong2);
        if (parseLong > parseLong2) {
            parseLong2 = date.getTime();
            parseLong = date2.getTime();
        } else {
            parseLong2 = date2.getTime();
            parseLong = date2.getTime();
        }
        return TimeUnit.SECONDS.toSeconds(parseLong2 - parseLong);
    }

    public void cputemp() {
        this.values.clear();
        String string = savedPref.getString(SharedPrefUtil.LASTCOOLTIME);
        StringBuilder sb = new StringBuilder();
        String str = "";
        sb.append(str);
        sb.append(System.currentTimeMillis());
        if (checkTimeDifference(sb.toString(), string) < GlobalData.coolPause) {
            finish();
            Intent intent = new Intent(CoolerScanScreen.this, FinalScreen.class);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(maxcooled);
            intent.putExtra("DATA", stringBuilder.toString());
            intent.putExtra("TYPE", "COOLER");
            startActivity(intent);
//            overridePendingTransition(R.anim.enter_from_right, R.anim.exit_out_left);
            return;
        }
        int i;
        for (i = 0; i < 30; i++) {
            this.text = new StringBuilder();
            StringBuilder sb1 = new StringBuilder();
            sb1.append("sys/devices/virtual/thermal/thermal_zone");
            sb1.append(i);
            sb1.append("/");
            File file = new File(sb1.toString(), "temp");
            if (!file.exists()) {
            }

            try {
                BufferedReader bufferedReader = new BufferedReader(new FileReader(file));

                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                }
                this.text.append(readLine);
                ArrayList arrayList;
                if (Integer.parseInt(this.text.toString()) > 1000) {
                    arrayList = this.values;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str);
                    stringBuilder2.append(Integer.parseInt(this.text.toString()) / 1000);
                    arrayList.add(stringBuilder2.toString());
                } else {
                    arrayList = this.values;
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(str);
                    stringBuilder3.append(this.text.toString());
                    arrayList.add(stringBuilder3.toString());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        i = check_max();
        maxcooled = i;
        this.tv_temp.setText(String.valueOf(i));
        this.tviewSymbol.setText("Temperature");
    }

    private void ifnoProcessFound() {
        if (this.processList.size() == 0) {
            new Handler().postDelayed(new Runnable() {
                public void run() {
                }
            }, 6000);
        }
    }

    private void init() {
        this.tviewSymbol = findViewById(R.id.symbol);
        this.layoutupper = findViewById(R.id.cpucollerfirst_toplayout);
        this.tv_temp = findViewById(R.id.cpucollerfirst_temp);
        this.t_cpuuses = findViewById(R.id.cpucoolerfirst_usage);
        this.tv_processing = findViewById(R.id.tv_text);
        this.btn_cooldowm = findViewById(R.id.btn_cpu_cooler_first);
    }

    public void kill_servieses() {
        List<ApplicationInfo> installedApplications = getPackageManager().getInstalledApplications(0);
        @SuppressLint("WrongConstant") ActivityManager activityManager = (ActivityManager) getSystemService("activity");
        ArrayList ignoredData = getIgnoredData();
        for (ApplicationInfo applicationInfo : installedApplications) {
            if ((applicationInfo.flags & 1) != 1) {
                if (!applicationInfo.packageName.equals("com.esc.phoneheart")) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(applicationInfo.packageName);
                    if (!ignoredData.contains(stringBuilder.toString())) {
                        if (activityManager != null) {
                            activityManager.killBackgroundProcesses(applicationInfo.packageName);
                        }
                    }
                }
            }
        }
    }

    private boolean notExists(String str) {
        int i = 0;
        while (i < this.processList.size()) {
            try {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(((ProcessWrapper) this.processList.get(i)).appname);
                if (str.equalsIgnoreCase(stringBuilder.toString())) {
                    return false;
                }
                i++;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    public void readUsage() {
        String str = " +";
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("/proc/stat", "r");
            String[] split = randomAccessFile.readLine().split(str);
            long parseLong = Long.parseLong(split[4]);
            long parseLong2 = ((((Long.parseLong(split[2]) + Long.parseLong(split[3])) + Long.parseLong(split[5])) + Long.parseLong(split[6])) + Long.parseLong(split[7])) + Long.parseLong(split[8]);
            try {
                Thread.sleep(360);
            } catch (Exception unused) {
            }
            randomAccessFile.seek(0);
            String readLine = randomAccessFile.readLine();
            randomAccessFile.close();
            String[] split2 = readLine.split(str);
            long parseLong3 = ((((Long.parseLong(split2[2]) + Long.parseLong(split2[3])) + Long.parseLong(split2[5])) + Long.parseLong(split2[6])) + Long.parseLong(split2[7])) + Long.parseLong(split2[8]);
            this.mmmmmm = ((float) (parseLong3 - parseLong2)) / ((float) ((parseLong3 + Long.parseLong(split2[4])) - (parseLong2 + parseLong)));

        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    private void redirectToNoti() {
        this.noti_result_back = getIntent().getBooleanExtra(GlobalData.NOTI_RESULT_BACK, false);
    }

    private void setDeviceDimensions() {
        BaseActivity.displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(BaseActivity.displaymetrics);
        DisplayMetrics displayMetrics = BaseActivity.displaymetrics;
        this.deviceHeight = displayMetrics.heightPixels;
        this.devicewidth = displayMetrics.widthPixels;
    }

    private void setDimensions() {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.layoutupper.getLayoutParams();
        layoutParams.height = (this.deviceHeight * 16) / 100;
        this.layoutupper.setLayoutParams(layoutParams);
    }


    private boolean showSavedTemp(String str) {
        boolean z = false;
        if (str == null) {
            return false;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(System.currentTimeMillis());
        if (checkTimeDifference(sb.toString(), str) <= GlobalData.coolPause) {
            z = true;
        }
        return z;
    }

    public void startAnim() {
        this.imgRotate.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotation));
    }

    public void startFallAnimation() {
        ImageView imageView = findViewById(R.id.img_two);
        ImageView imageView2 = findViewById(R.id.img_three);
        ImageView imageView3 = findViewById(R.id.img_four);
        ImageView imageView4 = findViewById(R.id.img_five);
        ImageView imageView5 = findViewById(R.id.img_six);
        ImageView imageView6 = findViewById(R.id.img_sev);
        ImageView imageView7 = findViewById(R.id.img_eight);
        ImageView imageView8 = findViewById(R.id.img_nine);
        ImageView imageView9 = findViewById(R.id.img_ten);
        ImageView imageView10 = findViewById(R.id.img_eleven);
        ImageView imageView11 = findViewById(R.id.img_twelve);
        animateViews(findViewById(R.id.img_one), 0, 7000);
        animateViews(imageView, 0, 5000);
        animateViews(imageView2, 0, 9000);
        animateViews(imageView3, 100, 8000);
        animateViews(imageView4, 0, 11000);
        animateViews(imageView5, 500, 12000);
        animateViews(imageView6, 200, 6000);
        animateViews(imageView7, 300, 12800);
        animateViews(imageView8, 300, 5000);
        animateViews(imageView9, 300, 8000);
        animateViews(imageView10, 300, 12800);
        animateViews(imageView11, 300, 6000);
    }

    public final int check_max() {
        int i = 0;
        for (int i2 = 0; i2 < values.size(); i2++) {
            try {
                if (Integer.parseInt(((String) values.get(i2)).trim()) > i) {
                    i = Integer.parseInt(((String) values.get(i2)).trim());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return (i > 45 || i < 10) ? RandomValue() : i;

    }

    public final int RandomValue() {
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Random value in double from ");
        stringBuilder.append(41);
        String str = " to ";
        stringBuilder.append(str);
        stringBuilder.append(45);
        String str2 = ":";
        stringBuilder.append(str2);
        printStream.println(stringBuilder.toString());
        double d = (double) 5;
        double d2 = (double) 41;
        System.out.println((Math.random() * d) + d2);
        printStream = System.out;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Random value in int from ");
        stringBuilder.append(41);
        stringBuilder.append(str);
        stringBuilder.append(45);
        stringBuilder.append(str2);
        printStream.println(stringBuilder.toString());
        int random = (int) ((Math.random() * d) + d2);
        System.out.println(random);
        return random;
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        GlobalData.SETAPPLAnguage(this);
        setContentView(R.layout.activity_cpu_cooler);
        setSupportActionBar(findViewById(R.id.toolbar));
        Drawable backArrow = getResources().getDrawable(R.drawable.ic_back_selector);
        getSupportActionBar().setHomeAsUpIndicator(backArrow);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("");

        this.processList = new ArrayList<>();
        for (int i = 0; i < GlobalData.processDataList.size(); i++) {
            if (notExists(GlobalData.processDataList.get(i).appname)) {
                this.processList.add(GlobalData.processDataList.get(i));
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("here ");
        sb.append(GlobalData.processDataList.size());
        sb.append("  ");
        sb.append(this.processList.size());
        Log.d("CALLED", sb.toString());
        this.context = this;
        this.savedPref = new SharedPrefUtil(this.context);
        setDeviceDimensions();
        init();
        animate();
        redirectToNoti();
        setDimensions();
        BannerAds();

        this.btn_cooldowm.setEnabled(false);
        this.btn_cooldowm.setVisibility(View.INVISIBLE);

        new Handler().postDelayed(new Runnable() {
            public void run() {
                try {
                    imgRotate.clearAnimation();
                    imgRotate.setVisibility(View.INVISIBLE);
                    findViewById(R.id.img_still).clearAnimation();
                    findViewById(R.id.img_still).setVisibility(View.INVISIBLE);
//                    tviewSymbol.setText(CoolerScanScreen.this.getString(R.string.cpu_high));
                    btn_cooldowm.setVisibility(View.VISIBLE);
                    tv_processing.setText("");
                    scanCompeted = true;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                CoolerScanScreen.this.cputemp();
                CoolerScanScreen.this.btn_cooldowm.setEnabled(true);
            }
        }, 4000);
        this.btn_cooldowm.setOnClickListener(new OnClickListener() {
            @SuppressLint("StaticFieldLeak")
            public void onClick(View view) {
                if (!CoolerScanScreen.this.doubleClicked()) {
                    CoolerScanScreen.this.imgRotate.setVisibility(View.VISIBLE);
                    CoolerScanScreen.this.layoutupper.setVisibility(View.INVISIBLE);
                    CoolerScanScreen.this.startAnim();
                    CoolerScanScreen.this.startFallAnimation();
                    CoolerScanScreen.this.tv_processing.setText(CoolerScanScreen.this.getString(R.string.pcl_coolingdown));
                    CoolerScanScreen.this.btn_cooldowm.setVisibility(View.INVISIBLE);
                    new AsyncTask<String, String, String>() {
                        public void onPreExecute() {
                            super.onPreExecute();
                        }

                        @SuppressLint("WrongConstant")
                        public String doInBackground(String... strArr) {
                            try {
                                if (CoolerScanScreen.this.processList.size() == 1) {
                                    CoolerScanScreen.this.kill_servieses();
                                } else {
                                    for (int i = 0; i < CoolerScanScreen.this.processList.size(); i++) {
                                        ((ActivityManager) CoolerScanScreen.this.context.getSystemService("activity")).killBackgroundProcesses(CoolerScanScreen.this.processList.get(i).name);
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            return null;
                        }

                        public void onPostExecute(String str) {
                            SharedPrefUtil e = CoolerScanScreen.this.savedPref;
                            String str2 = SharedPrefUtil.LASTBOOSTTIME;
                            StringBuilder sb = new StringBuilder();
                            String str3 = "";
                            sb.append(str3);
                            sb.append(System.currentTimeMillis());
                            e.saveString(str2, sb.toString());
                            e = CoolerScanScreen.this.savedPref;
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append(str3);
                            sb2.append(CoolerScanScreen.this.maxcooled);
                            sb2.append(176);
                            sb2.append("C");
                            e.saveString(SharedPrefUtil.AFTERCOOLTEMP, sb2.toString());
                            e = CoolerScanScreen.this.savedPref;
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append(str3);
                            sb3.append(System.currentTimeMillis());
                            e.saveString(SharedPrefUtil.LASTCOOLTIME, sb3.toString());
                            new Handler().postDelayed(new Runnable() {
                                public void run() {
                                    if (!CoolerScanScreen.this.backPressed) {
                                        CoolerScanScreen.this.finish();
                                        Intent intent = new Intent(CoolerScanScreen.this.context, FinalScreen.class);
                                        StringBuilder sb = new StringBuilder();
                                        sb.append("");
                                        sb.append(CoolerScanScreen.this.maxcooled);
                                        intent.putExtra("DATA", sb.toString());
                                        intent.putExtra("TYPE", "COOLER");
                                        startActivity(intent);
                                    }
                                }
                            }, 7000);
                            super.onPostExecute(str);
                        }
                    }.execute(new String[0]);
                }
            }
        });
        new Timer().schedule(new TimerTask() {
            public void run() {
                CoolerScanScreen.this.readUsage();
                CoolerScanScreen.this.runOnUiThread(new Runnable() {
                    public void run() {
                        String str = "";
                        try {
                            String replace = new DecimalFormat(".0#").format(CoolerScanScreen.this.mmmmmm).replace(",", str).replace(".", str);
                            if (replace.startsWith("-")) {
                                CoolerScanScreen.this.t_cpuuses.setText("0");
                                return;
                            }
                            TextView j = CoolerScanScreen.this.t_cpuuses;
                            StringBuilder sb = new StringBuilder();
                            sb.append(str);
                            sb.append(replace);
                            j.setText(sb.toString());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        }, 3000, 5000);
        ifnoProcessFound();
        new Handler().postDelayed(new Runnable() {
            public void run() {
                try {
                    StringBuilder sb = new StringBuilder();
                    sb.append(CoolerScanScreen.this.tv_temp.getText().toString());
                    sb.append("℃");
                    GlobalData.cpu_temperature = sb.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 2000);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        this.isPause = true;
        Dialog dialog2 = new Dialog(this);
        this.dialog = dialog2;
        dialog2.requestWindowFeature(1);
        if (this.dialog.getWindow() != null) {
            this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            this.dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
        }
        this.dialog.setContentView(R.layout.new_dialog_junk_cancel);
        this.dialog.setCancelable(false);
        this.dialog.setCanceledOnTouchOutside(false);
        this.dialog.getWindow().setLayout(-1, -1);
        this.dialog.getWindow().setGravity(17);
        ((TextView) this.dialog.findViewById(R.id.dialog_title)).setText(getResources().getString(R.string.cpu_title));
        if (this.scanCompeted) {
            ((TextView) this.dialog.findViewById(R.id.dialog_msg)).setText(getResources().getString(R.string.dialouge_result_back));
        } else {
            ((TextView) this.dialog.findViewById(R.id.dialog_msg)).setText(getResources().getString(R.string.dialouge_scan_back));
        }
        this.dialog.findViewById(R.id.ll_no).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!CoolerScanScreen.this.doubleClicked()) {
                    CoolerScanScreen.this.isPause = false;
                    Log.e("=========", "onBackPressed free update_progress() cancle button click");
                    CoolerScanScreen.this.dialog.dismiss();
                }
            }
        });
        this.dialog.findViewById(R.id.ll_yes).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!CoolerScanScreen.this.doubleClicked()) {
                    CoolerScanScreen.this.isPause = false;
                    CoolerScanScreen.this.dialog.dismiss();
                    CoolerScanScreen.this.backPressed = true;
                    CoolerScanScreen.this.finish();
                }
            }
        });
        this.dialog.show();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != android.R.id.home) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }
}
