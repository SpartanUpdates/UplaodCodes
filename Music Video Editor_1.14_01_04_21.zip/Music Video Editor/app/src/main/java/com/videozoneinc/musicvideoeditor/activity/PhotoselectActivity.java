package com.videozoneinc.musicvideoeditor.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.videozoneinc.musicvideoeditor.MyApplication;
import com.videozoneinc.musicvideoeditor.R;
import com.videozoneinc.musicvideoeditor.adapters.AlbumAdapterById;
import com.videozoneinc.musicvideoeditor.adapters.ImageByAlbumAdapter;
import com.videozoneinc.musicvideoeditor.adapters.OnItemClickListner;
import com.videozoneinc.musicvideoeditor.adapters.SelectedImageAdapter;
import com.videozoneinc.musicvideoeditor.modelclass.ImageData;
import com.videozoneinc.musicvideoeditor.util.ActivityAnimUtil;
import com.videozoneinc.musicvideoeditor.util.Utils;
import com.videozoneinc.musicvideoeditor.view.EmptyRecyclerView;
import com.videozoneinc.musicvideoeditor.view.ExpandIconView;
import com.videozoneinc.musicvideoeditor.view.VerticalSlidingPanel;
import com.videozoneinc.musicvideoeditor.view.VerticalSlidingPanel.PanelSlideListener;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import java.io.File;
import java.util.ArrayList;
import static com.videozoneinc.musicvideoeditor.util.NativeAdsMethod.populateUnifiedNativeAdView;

public class PhotoselectActivity extends AppCompatActivity implements PanelSlideListener {
    private EmptyRecyclerView rvSelectedImage;
    public static boolean isForFirst = false;
    public static ArrayList<ImageData> tempImage = new ArrayList();
    private View parent;
    private RecyclerView rvAlbum;
    private SelectedImageAdapter selectedImageAdapter;
    private Toolbar toolbar;
    public static TextView tvImageCount;
    private AlbumAdapterById albumAdapter;
    private ImageByAlbumAdapter albumImagesAdapter;
    private MyApplication application;
    private TextView btnClear;
    private ExpandIconView expandIcon;
    public boolean isFromCameraNotification = false;
    public boolean isFromPreview = false;
    boolean isPause = false;
    private VerticalSlidingPanel verticalSlidingPanel;
    TextView tvDone;
    public static LinearLayout fregmentLayouts;
    public static ArrayList<String> arrayListID;
    public final ArrayList<ImageData> selectedImages = new ArrayList<ImageData>();

    public void onPanelAnchored(View view) {

    }

    public void onPanelShown(View view) {
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.image_select_activity);
        this.application = MyApplication.getInstance();
        this.isFromPreview = getIntent().hasExtra("extra_from_preview");
        this.isFromCameraNotification = getIntent().hasExtra("isFromCameraNotification");
        bindView();
        init();
        PutAnalyticsEvent();
        loadAd();
        loadAdmobAd();
        arrayListID = new ArrayList<>();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "PhotoselectActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void init() {
        setSupportActionBar(this.toolbar);
        TextView textView = (TextView) this.toolbar.findViewById(R.id.toolbar_title);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        textView.setText(getString(R.string.select_images));
        Utils.setFont(this, textView);
        if (this.isFromCameraNotification) {
            AsyncTaskRunner runner = new AsyncTaskRunner();
            runner.execute("");

        }
        this.albumAdapter = new AlbumAdapterById(this);
        this.albumImagesAdapter = new ImageByAlbumAdapter(this);
        this.selectedImageAdapter = new SelectedImageAdapter(this);
        this.rvAlbum.setHasFixedSize(true);
        this.rvAlbum.setLayoutManager(new GridLayoutManager(getApplicationContext(), 3));
        this.rvAlbum.setItemAnimator(new DefaultItemAnimator());
        this.rvAlbum.setAdapter(this.albumAdapter);
        this.rvSelectedImage.setLayoutManager(new GridLayoutManager(getApplicationContext(), 4));
        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
        this.rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
        this.btnClear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                PhotoselectActivity.this.clearData();
            }
        });
        this.albumAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object o) {
                PhotoselectActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
        this.albumImagesAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                PhotoselectActivity.this.tvImageCount.setText(String.valueOf(PhotoselectActivity.this.application.getSelectedImages().size()));
                PhotoselectActivity.this.selectedImageAdapter.notifyDataSetChanged();
            }
        });
        this.selectedImageAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                PhotoselectActivity.this.tvImageCount.setText(String.valueOf(PhotoselectActivity.this.application.getSelectedImages().size()));
                PhotoselectActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
    }

    private class AsyncTaskRunner extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            application.getFolderList();
            return "";
        }

        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
        }


        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(PhotoselectActivity.this,
                    "ProgressDialog",
                    "Please Wait...");
        }


        @Override
        protected void onProgressUpdate(String... text) {

        }
    }

    private void bindView() {
        this.tvImageCount = (TextView) findViewById(R.id.tvImageCount);
        this.tvDone = (TextView) findViewById(R.id.tvDone);
        this.expandIcon = (ExpandIconView) findViewById(R.id.settings_drag_arrow);
        this.rvAlbum = (RecyclerView) findViewById(R.id.rvAlbum);
        this.rvSelectedImage = (EmptyRecyclerView) findViewById(R.id.rvSelectedImagesList);
        this.verticalSlidingPanel = (VerticalSlidingPanel) findViewById(R.id.overview_panel);
        this.verticalSlidingPanel.setEnableDragViewTouchEvents(true);
        this.verticalSlidingPanel.setDragView(findViewById(R.id.settings_pane_header));
        this.verticalSlidingPanel.setPanelSlideListener(this);
        this.parent = findViewById(R.id.default_home_screen_panel);
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.btnClear = (TextView) findViewById(R.id.btnClear);
        tvDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (application.getSelectedImages().size() > 2) {
                    loadDone();
                    return;
                }
                Toast.makeText(PhotoselectActivity.this, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();
            }
        });
        fregmentLayouts = (LinearLayout) findViewById(R.id.fregmentspace);
        if (this.isFromPreview) {
            btnClear.setVisibility(View.GONE);

        }
    }
    public int getItemCount() {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).size();
    }

    public ImageData getItem(final int n) {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).get(n);
    }


    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 999 && i2 == -1) {
            this.application.selectedImages.remove(MyApplication.TEMP_POSITION);
            ImageData imgData = new ImageData();
            imgData.setImagePath(intent.getExtras().getString("ImgPath"));
            this.application.selectedImages.add(MyApplication.TEMP_POSITION, imgData);
            setupAdapter();
        }
    }

    private void setupAdapter() {
        this.selectedImageAdapter = new SelectedImageAdapter(this);
        this.rvSelectedImage.setLayoutManager(new GridLayoutManager(getApplicationContext(), 4));
        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
        this.rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
    }

    protected void onResume() {
        super.onResume();
        if (this.isPause) {
            this.isPause = false;
            this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
            this.albumImagesAdapter.notifyDataSetChanged();
            this.selectedImageAdapter.notifyDataSetChanged();
        }
    }

    protected void onPause() {
        super.onPause();
        this.isPause = true;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_selection, menu);
        if (this.isFromPreview) {
            menu.removeItem(R.id.menu_clear);
        }
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            SubMenu subMenu = item.getSubMenu();
            if (subMenu != null && subMenu.size() > 0) {
                for (int i2 = 0; i2 < subMenu.size(); i2++) {
                    Utils.applyFontToMenuItem(getApplicationContext(), subMenu.getItem(i2));
                }
            }
            Utils.applyFontToMenuItem(getApplicationContext(), item);
        }
        return true;
    }

    private boolean isEndFrameExist() {
        if (Fragment_EndFrame.lastsaveTempPath == null) {
            return false;
        }
        return new File(Fragment_EndFrame.lastsaveTempPath).exists();
    }

    public boolean onOptionsItemSelected(final MenuItem menuItem) {
        final int itemId = menuItem.getItemId();
        if (itemId != android.R.id.home) {
            switch (itemId) {
                case R.id.menu_done: {
                    if (this.application.getSelectedImages().size() > 2) {
                        this.loadDone();
                        break;
                    }
                    Toast.makeText(this, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();
                    break;
                }
                case R.id.menu_clear: {
                    this.clearData();
                    break;
                }
            }
        } else {
            this.onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private boolean loadDone() {
        final boolean isFromPreview = this.isFromPreview;
        int i = 0;
        if (isFromPreview) {
            if (this.isEndFrameExist()) {
                ImageData imageData = null;
                final ArrayList<ImageData> list = new ArrayList<ImageData>();
                list.addAll(this.application.selectedImages);
                this.application.selectedImages.clear();
                while (i < list.size()) {
                    if (list.get(i).imagePath.equals(Fragment_EndFrame.lastsaveTempPath)) {
                        imageData = list.get(i);
                    } else {
                        this.application.selectedImages.add(list.get(i));
                    }
                    ++i;
                }
                if (imageData != null) {
                    this.application.selectedImages.add(imageData);
                }
            }
            this.setResult(-1);
            this.finish();
            return true;
        } else {
            nextDialog();
        }
        return false;
    }

    private UnifiedNativeAd nativeAd;

    private void nextDialog() {
        final Dialog dialog = new Dialog(PhotoselectActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.imageselection_done_dialog);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.Admob_Native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                LinearLayout frameLayout = dialog.findViewById(R.id.banner_container);
                dialog.findViewById(R.id.tvLoadingads).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());

        Button btnLatter = (Button) dialog.findViewById(R.id.btnLater);
        Button btnSubmit = (Button) dialog.findViewById(R.id.btnSubmit);
        btnLatter.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                id = 100;
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    final Intent intent = new Intent(PhotoselectActivity.this, (Class) Activity_ArrangeImage.class);
                    intent.putExtra("isFromCameraNotification", false);
                    intent.putExtra("KEY", "FromImageSelection");
                    startActivity(intent);

                }
                dialog.dismiss();
            }
        });
        btnSubmit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                id = 101;
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    Intent intent = new Intent(PhotoselectActivity.this, AddTitleActivity.class);
                    intent.putExtra("ISFROMPREVIEW", isFromPreview);
                    ActivityAnimUtil.startActivitySafely(toolbar, intent);
                    if (isFromPreview) {
                        finish();
                    }
                }
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void onBackPressed() {
        if (findViewById(R.id.fregmentspace).getVisibility() == View.VISIBLE) {
            findViewById(R.id.fregmentspace).setVisibility(View.GONE);
            return;
        }
        if (this.verticalSlidingPanel.isExpanded()) {
            this.verticalSlidingPanel.collapsePane();
        } else if (this.isFromCameraNotification) {
            startActivity(new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            this.application.clearAllSelection();
            finish();
        } else if (this.isFromPreview) {
            if (application.getSelectedImages().size() > 2) {
                loadDone();
                return;
            }
            Toast.makeText(PhotoselectActivity.this, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();
        } else {
            this.application.videoImages.clear();
            this.application.clearAllSelection();

            startActivity(new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            finish();
            super.onBackPressed();
        }
    }

    public void onPanelSlide(final View view, final float n) {
        if (this.expandIcon != null) {
            this.expandIcon.setFraction(n, false);
        }
        if (n >= 0.005f) {
            if (this.parent != null && this.parent.getVisibility() != View.VISIBLE) {
                this.parent.setVisibility(View.VISIBLE);
            }
        } else if (this.parent != null && this.parent.getVisibility() == View.VISIBLE) {
            this.parent.setVisibility(View.GONE);
        }
    }

    public void onPanelCollapsed(View view) {
        if (this.parent != null) {
            this.parent.setVisibility(View.VISIBLE);
        }
        this.selectedImageAdapter.isExpanded = false;
        this.selectedImageAdapter.notifyDataSetChanged();
    }

    public void onPanelExpanded(View view) {
        if (this.parent != null) {
            this.parent.setVisibility(View.GONE);
        }
        this.selectedImageAdapter.isExpanded = true;
        this.selectedImageAdapter.notifyDataSetChanged();
    }

    private void clearData() {
        for (int size = this.application.getSelectedImages().size() - 1; size >= 0; size--) {
            this.application.removeSelectedImage(size);
        }
        this.tvImageCount.setText("0");
        this.selectedImageAdapter.notifyDataSetChanged();
        this.albumImagesAdapter.notifyDataSetChanged();
    }

    private int id;

    private void loadAd() {
        if (Utils.Utility.isNetworkAvailable(this)) {
            AdLoader adLoader = new AdLoader.Builder(this, getResources().getString(R.string.Admob_Native))
                    .forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                        @Override
                        public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                            NativeTemplateStyle styles = new
                                    NativeTemplateStyle.Builder().build();
                            TemplateView template = findViewById(R.id.my_template);
                            template.setStyles(styles);
                            template.setNativeAd(unifiedNativeAd);
                        }
                    })
                    .build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            findViewById(R.id.nativeAdLayout).setVisibility(View.GONE);
        }
    }

    private InterstitialAd mInterstitialAd;

    private void loadAdmobAd() {
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.Admob_Inter));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
            }

            @Override
            public void onAdOpened() {
            }

            @Override
            public void onAdClicked() {
            }

            @Override
            public void onAdLeftApplication() {
            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        final Intent intent = new Intent(PhotoselectActivity.this, (Class) Activity_ArrangeImage.class);
                        intent.putExtra("isFromCameraNotification", false);
                        intent.putExtra("KEY", "FromImageSelection");
                        startActivity(intent);

                        break;
                    case 101:
                        Intent intent1 = new Intent(PhotoselectActivity.this, AddTitleActivity.class);
                        intent1.putExtra("ISFROMPREVIEW", isFromPreview);
                        ActivityAnimUtil.startActivitySafely(toolbar, intent1);
                        if (isFromPreview) {
                            finish();
                        }
                        break;
                }
                requestNewInterstitialAdmob();
            }
        });

    }

    private void requestNewInterstitialAdmob() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }
}
