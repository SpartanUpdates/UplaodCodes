package com.vidsoft.videostatusmaker.adapter;

import com.vidsoft.videostatusmaker.Activity.MainActivity;
import com.vidsoft.videostatusmaker.Utils.gridview.*;

import android.content.*;

import java.util.*;

import android.widget.*;
import android.view.*;

import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.nostra13.universalimageloader.core.*;

public class GalleryAdapter extends BaseDynamicGridAdapter {
    public static String st = "r";
    int height;
    Context context;
    int width;

    public GalleryAdapter(final Context context, final List<?> list, final int n) {
        super(context, list, n);
        this.context = context;
        this.width = this.context.getResources().getDisplayMetrics().widthPixels;
        this.height = this.context.getResources().getDisplayMetrics().heightPixels;
    }

    public View getView(final int n, View inflate, final ViewGroup viewGroup) {
        GalleryviewHolder tag;
        if (inflate == null) {
            inflate = LayoutInflater.from(this.getContext()).inflate(R.layout.gallery_adapter, (ViewGroup) null);
            tag = new GalleryviewHolder(inflate);
            inflate.setTag((Object) tag);
        } else {
            tag = (GalleryviewHolder) inflate.getTag();
        }
        if (GalleryAdapter.st.equals("c")) {
            tag.image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            tag.image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        }
        if (MainActivity.anInt == 1) {
            tag.bg_img.setScaleType(ImageView.ScaleType.FIT_XY);
        }
        tag.bg_imageView.setBackgroundColor(-16777216);
        tag.build(this.getItem(n).toString());
        return inflate;
    }

    private class GalleryviewHolder {
        private ImageView bg_imageView;
        private ImageView bg_img;
        private ImageView image;
        RelativeLayout mainlay;

        private GalleryviewHolder(final View view) {
            this.image = (ImageView) view.findViewById(R.id.image);
            this.bg_img = (ImageView) view.findViewById(R.id.bg_img);
            this.bg_imageView = (ImageView) view.findViewById(R.id.bg_imageView);
            this.mainlay = (RelativeLayout) view.findViewById(R.id.mainlay);

            this.bg_img.setVisibility(View.VISIBLE);
            if (MainActivity.anInt == 1) {
                this.mainlay.setLayoutParams((ViewGroup.LayoutParams) new RelativeLayout.LayoutParams(GalleryAdapter.this.width / 2, GalleryAdapter.this.height * 700 / 1920));
                final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams(GalleryAdapter.this.width * 493 / 1080, GalleryAdapter.this.height * 643 / 1920);
                relativeLayout$LayoutParams.addRule(13);
                this.image.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams);
                this.bg_imageView.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams);
                final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(GalleryAdapter.this.width * 509 / 1080, GalleryAdapter.this.height * 660 / 1920);
                layoutParams.addRule(13);
                this.bg_img.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
                this.bg_img.setImageResource(R.drawable.full_arrange_bg);
                return;
            }
            this.mainlay.setLayoutParams((ViewGroup.LayoutParams) new RelativeLayout.LayoutParams(GalleryAdapter.this.width / 2, GalleryAdapter.this.width / 2));
            final RelativeLayout.LayoutParams relativeLayout$LayoutParams2 = new RelativeLayout.LayoutParams(GalleryAdapter.this.width * 480 / 1080, GalleryAdapter.this.width * 480 / 1080);
            relativeLayout$LayoutParams2.addRule(13);
            this.image.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams2);
            this.bg_imageView.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams2);
            final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(GalleryAdapter.this.width * 502 / 1080, GalleryAdapter.this.width * 502 / 1080);
            layoutParams2.addRule(13);
            this.bg_img.setLayoutParams((ViewGroup.LayoutParams) layoutParams2);
        }

        void build(final String s) {
            final DisplayImageOptions build = new DisplayImageOptions.Builder().build();
            final ImageLoader instance = ImageLoader.getInstance();
            final StringBuilder sb = new StringBuilder();
            sb.append("file:///");
            sb.append(s);
            instance.displayImage(sb.toString(), this.image, build);
        }
    }
}
