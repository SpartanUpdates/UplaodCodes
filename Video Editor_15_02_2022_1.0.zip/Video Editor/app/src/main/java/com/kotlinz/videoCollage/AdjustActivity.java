package com.kotlinz.videoCollage;

import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff.Mode;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.kotlinz.videoCollage.views.ColorFilterGenerator;
import com.kotlinz.videoeditor.R;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Random;


public class AdjustActivity extends AppCompatActivity {
    private String adjustPath;
    private int brightnessProgress = 0;
    private Context context;
    private int contrastProgress = 0;
    private FrameLayout frameBrightness;
    private FrameLayout frameContrast;
    private FrameLayout frameHue;
    private FrameLayout frameSaturation;
    private int hueProgress = 0;
    private ImageView imgAdjust;
    private ImageView imgBack;
    private ImageView imgBrightness;
    private ImageView imgContrast;
    private ImageView imgDone;
    private ImageView imgHue;
    private ImageView imgResetBrightness;
    private ImageView imgSaturation;
    private String path;
    private int saturationProgress = 0;
    private SeekBar seekBarBrightness;
    private SeekBar seekBarContrast;
    private SeekBar seekBarHue;
    private SeekBar seekBarSaturation;
    private TextView tempTextForAdjust;
    private View viewBrightness;
    private View viewContrast;
    private View viewHue;
    private View viewSaturation;

    private class ImageSaveAsyncTask extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressDialog;

        private ImageSaveAsyncTask() {

        }

        ImageSaveAsyncTask(AdjustActivity adjustActivity) {
            this();
        }


        public void onPreExecute() {
            super.onPreExecute();
            ProgressDialog progressDialog = new ProgressDialog(AdjustActivity.this.context);
            this.progressDialog = progressDialog;
            progressDialog.setMessage("Please wait...It is applying filter");
            this.progressDialog.setIndeterminate(false);
            this.progressDialog.setCancelable(false);
            this.progressDialog.setCanceledOnTouchOutside(false);
            this.progressDialog.show();
        }


        public String doInBackground(Void... voidArr) {
            int nextInt = new Random().nextInt(10000);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Image-");
            stringBuilder.append(nextInt);
            stringBuilder.append(".jpg");
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(AdjustActivity.this.context.getCacheDir());
            stringBuilder3.append("/adjusttemp");
            File file = new File(stringBuilder3.toString());
            if (!file.exists()) {
                file.mkdirs();
            }
            File file2 = new File(file, stringBuilder2);
            if (file2.exists()) {
                file2.delete();
            }
            AdjustActivity.this.imgAdjust.buildDrawingCache();
            Bitmap copy = AdjustActivity.this.imgAdjust.getDrawingCache().copy(Config.ARGB_8888, false);
            AdjustActivity.this.imgAdjust.destroyDrawingCache();
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                copy.compress(CompressFormat.JPEG, 100, fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return file2.getAbsolutePath();
        }


        public void onPostExecute(String str) {
            super.onPostExecute(str);
            AdjustActivity.this.adjustPath = str;
            this.progressDialog.dismiss();
            Intent intent = new Intent();
            intent.putExtra("adjust_path", AdjustActivity.this.adjustPath);
            AdjustActivity.this.setResult(-1, intent);
            AdjustActivity.this.finish();
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_adjust);
        this.context = this;
        PutAnalyticsEvent();
        inIt();
        String string = getIntent().getExtras().getString("path");
        this.path = string;
        this.imgAdjust.setImageBitmap(BitmapFactory.decodeFile(string));
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "AdjustActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    public void onBackPressed() {
        String str = "Cancel";
        new Builder(this).setMessage("All changes will be discarded.").setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                AdjustActivity.this.setResult(0, new Intent());
                AdjustActivity.this.finish();
            }
        }).setNegativeButton(str, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }

    private void inIt() {
        setSupportActionBar((Toolbar) findViewById(R.id.adjust_toolbar));
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(false);
        this.imgAdjust = (ImageView) findViewById(R.id.img_adjust);
        this.imgBack = (ImageView) findViewById(R.id.img_adjust_tool_back);
        this.imgDone = (ImageView) findViewById(R.id.img_adjust_tool_done);
        this.frameBrightness = (FrameLayout) findViewById(R.id.frame_brightness);
        this.imgBrightness = (ImageView) findViewById(R.id.img_brightness);
        this.viewBrightness = findViewById(R.id.view_brightness);
        this.frameContrast = (FrameLayout) findViewById(R.id.frame_contrast);
        this.imgContrast = (ImageView) findViewById(R.id.img_contrast);
        this.viewContrast = findViewById(R.id.view_contrast);
        this.frameSaturation = (FrameLayout) findViewById(R.id.frame_saturation);
        this.imgSaturation = (ImageView) findViewById(R.id.img_saturation);
        this.viewSaturation = findViewById(R.id.view_saturation);
        this.frameHue = (FrameLayout) findViewById(R.id.frame_hue);
        this.imgHue = (ImageView) findViewById(R.id.img_hue);
        this.viewHue = findViewById(R.id.view_hue);
        this.tempTextForAdjust = (TextView) findViewById(R.id.temp_text_view_for_adjust);
        this.seekBarBrightness = (SeekBar) findViewById(R.id.seek_brightness);
        this.seekBarContrast = (SeekBar) findViewById(R.id.seek_contrast);
        this.seekBarSaturation = (SeekBar) findViewById(R.id.seek_saturation);
        this.seekBarHue = (SeekBar) findViewById(R.id.seek_hue);
        this.imgResetBrightness = (ImageView) findViewById(R.id.img_reset_all);
        SeekBar seekBar = this.seekBarBrightness;
        seekBar.setProgress(seekBar.getProgress());
        this.seekBarBrightness.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                AdjustActivity adjustActivity = AdjustActivity.this;
                adjustActivity.brightnessProgress = i - (adjustActivity.seekBarBrightness.getMax() / 2);
                AdjustActivity.this.tempTextForAdjust.setText(String.valueOf(AdjustActivity.this.brightnessProgress));
                AdjustActivity.this.imgAdjust.setColorFilter(ColorFilterGenerator.adjustColor(AdjustActivity.this.brightnessProgress, 0, 0, 0));
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                AdjustActivity.this.tempTextForAdjust.setVisibility(View.VISIBLE);
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                AdjustActivity.this.tempTextForAdjust.setVisibility(View.GONE);
            }
        });
        seekBar = this.seekBarContrast;
        seekBar.setProgress(seekBar.getProgress());
        this.seekBarContrast.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                AdjustActivity adjustActivity = AdjustActivity.this;
                adjustActivity.contrastProgress = i - (adjustActivity.seekBarContrast.getMax() / 2);
                AdjustActivity.this.tempTextForAdjust.setText(String.valueOf(AdjustActivity.this.contrastProgress));
                AdjustActivity.this.imgAdjust.setColorFilter(ColorFilterGenerator.adjustColor(0, AdjustActivity.this.contrastProgress, 0, 0));
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                AdjustActivity.this.tempTextForAdjust.setVisibility(View.VISIBLE);
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                AdjustActivity.this.tempTextForAdjust.setVisibility(View.GONE);
            }
        });
        seekBar = this.seekBarSaturation;
        seekBar.setProgress(seekBar.getProgress());
        this.seekBarSaturation.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                AdjustActivity adjustActivity = AdjustActivity.this;
                adjustActivity.saturationProgress = i - (adjustActivity.seekBarSaturation.getMax() / 2);
                AdjustActivity.this.tempTextForAdjust.setText(String.valueOf(AdjustActivity.this.saturationProgress));
                AdjustActivity.this.imgAdjust.setColorFilter(ColorFilterGenerator.adjustColor(0, 0, AdjustActivity.this.saturationProgress, 0));
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                AdjustActivity.this.tempTextForAdjust.setVisibility(View.VISIBLE);
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                AdjustActivity.this.tempTextForAdjust.setVisibility(View.GONE);
            }
        });
        seekBar = this.seekBarHue;
        seekBar.setProgress(seekBar.getProgress());
        this.seekBarHue.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                AdjustActivity.this.hueProgress = i;
                AdjustActivity.this.tempTextForAdjust.setText(String.valueOf(AdjustActivity.this.hueProgress));
                AdjustActivity.this.imgAdjust.setColorFilter(ColorFilterGenerator.adjustColor(0, 0, 0, AdjustActivity.this.hueProgress));
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                AdjustActivity.this.tempTextForAdjust.setVisibility(View.VISIBLE);
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                AdjustActivity.this.tempTextForAdjust.setVisibility(View.GONE);
            }
        });
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AdjustActivity.this.onBackPressed();
            }
        });
        this.imgDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                new ImageSaveAsyncTask(AdjustActivity.this).execute(new Void[0]);
            }
        });
        this.frameBrightness.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AdjustActivity.this.hideOrShowBrightness();
            }
        });
        this.frameContrast.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AdjustActivity.this.hideOrShowContrast();
            }
        });
        this.frameSaturation.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AdjustActivity.this.hideOrShowSaturation();
            }
        });
        this.frameHue.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AdjustActivity.this.hideOrShowHue();
            }
        });
        this.imgResetBrightness.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AdjustActivity.this.seekBarBrightness.setProgress(AdjustActivity.this.seekBarBrightness.getMax() / 2);
                AdjustActivity.this.brightnessProgress = 0;
                AdjustActivity.this.seekBarContrast.setProgress(AdjustActivity.this.seekBarContrast.getMax() / 2);
                AdjustActivity.this.contrastProgress = 0;
                AdjustActivity.this.seekBarSaturation.setProgress(AdjustActivity.this.seekBarSaturation.getMax() / 2);
                AdjustActivity.this.saturationProgress = 0;
                AdjustActivity.this.seekBarHue.setProgress(0);
                AdjustActivity.this.hueProgress = 0;
                AdjustActivity.this.imgAdjust.setImageBitmap(BitmapFactory.decodeFile(AdjustActivity.this.path));
            }
        });
    }

    private void hideOrShowBrightness() {
        this.viewBrightness.setVisibility(View.VISIBLE);
        this.viewContrast.setVisibility(View.GONE);
        this.viewSaturation.setVisibility(View.GONE);
        this.viewHue.setVisibility(View.GONE);
        this.seekBarBrightness.setVisibility(View.VISIBLE);
        this.seekBarContrast.setVisibility(View.GONE);
        this.seekBarSaturation.setVisibility(View.GONE);
        this.seekBarHue.setVisibility(View.GONE);
        this.imgBrightness.setColorFilter(getResources().getColor(R.color.colorAccent), Mode.SRC_IN);
        this.imgContrast.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgSaturation.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
    }

    private void hideOrShowContrast() {
        this.viewBrightness.setVisibility(View.GONE);
        this.viewContrast.setVisibility(View.VISIBLE);
        this.viewSaturation.setVisibility(View.GONE);
        this.viewHue.setVisibility(View.GONE);
        this.seekBarBrightness.setVisibility(View.GONE);
        this.seekBarContrast.setVisibility(View.VISIBLE);
        this.seekBarSaturation.setVisibility(View.GONE);
        this.seekBarHue.setVisibility(View.GONE);
        this.imgBrightness.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgContrast.setColorFilter(getResources().getColor(R.color.colorAccent), Mode.SRC_IN);
        this.imgSaturation.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
    }

    private void hideOrShowSaturation() {
        this.viewBrightness.setVisibility(View.GONE);
        this.viewContrast.setVisibility(View.GONE);
        this.viewSaturation.setVisibility(View.VISIBLE);
        this.viewHue.setVisibility(View.GONE);
        this.seekBarBrightness.setVisibility(View.GONE);
        this.seekBarContrast.setVisibility(View.GONE);
        this.seekBarSaturation.setVisibility(View.VISIBLE);
        this.seekBarHue.setVisibility(View.GONE);
        this.imgBrightness.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgContrast.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgSaturation.setColorFilter(getResources().getColor(R.color.colorAccent), Mode.SRC_IN);
    }

    private void hideOrShowHue() {
        this.viewBrightness.setVisibility(View.GONE);
        this.viewContrast.setVisibility(View.GONE);
        this.viewSaturation.setVisibility(View.GONE);
        this.viewHue.setVisibility(View.VISIBLE);
        this.seekBarBrightness.setVisibility(View.GONE);
        this.seekBarContrast.setVisibility(View.GONE);
        this.seekBarSaturation.setVisibility(View.GONE);
        this.seekBarHue.setVisibility(View.VISIBLE);
        this.imgBrightness.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgContrast.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
        this.imgSaturation.setColorFilter(getResources().getColor(R.color.colorWhite), Mode.SRC_IN);
    }
}
