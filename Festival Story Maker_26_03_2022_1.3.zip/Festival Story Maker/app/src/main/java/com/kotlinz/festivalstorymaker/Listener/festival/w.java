package com.kotlinz.festivalstorymaker.Listener.festival;

import android.graphics.Typeface;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;
import com.kotlinz.festivalstorymaker.texteditor.FontListAdapter;

public class w implements FontListAdapter.a {
    public final  FestivalDetailActivity_New n;

    public  w(FestivalDetailActivity_New festivalDetailActivity_New) {
        this.n = festivalDetailActivity_New;
    }

    @Override
    public void B(Typeface typeface, int i) {
        this.n.K(typeface, i);
    }
}
