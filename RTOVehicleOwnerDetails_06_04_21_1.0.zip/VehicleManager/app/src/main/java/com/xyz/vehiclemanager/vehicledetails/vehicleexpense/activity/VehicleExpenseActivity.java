package com.xyz.vehiclemanager.vehicledetails.vehicleexpense.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.vehicledetails.vehicleexpense.adapter.VehicleExpenseList;
import com.xyz.vehiclemanager.vehicledetails.vehicleexpense.database.ExpenseSqlite;
import com.xyz.vehiclemanager.vehicledetails.vehicleexpense.model.VehicleExpense;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

public class VehicleExpenseActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = VehicleExpenseActivity.this;
    ImageView iv_addexpense;
    LinearLayout ll_empty;
    ExpandableListView listView;
    TextView tvTotal;
    ImageView iv_back;
    ExpenseSqlite sqlite;
    VehicleExpenseList expenseListAdapter;
    ArrayList<VehicleExpense> expenseModels = new ArrayList();

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_expense);
        sqlite = new ExpenseSqlite(getApplicationContext());
        BindView();
        PutAnalyticsEvent();
        BannerAds();
        TotalAmount();
        SetListener();
    }

    public void BindView() {
        iv_addexpense = findViewById(R.id.iv_addexpense);
        ll_empty = findViewById(R.id.ll_emplty);
        listView = findViewById(R.id.listview);
        tvTotal = findViewById(R.id.tv_total);
        iv_back = findViewById(R.id.iv_back);

        iv_addexpense.setOnClickListener(this);
        iv_back.setOnClickListener(this);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VehicleExpenseActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SetListener() {
        listView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                listView.setIndicatorBounds(listView.getMeasuredWidth() - 80, listView.getMeasuredWidth());
            }
        });

        listView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            public boolean onGroupClick(ExpandableListView expandableListView, View view, int i, long j) {
                return false;
            }
        });

        this.listView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i2, long j) {
                try {
                    final VehicleExpense vehicleExpenseModel = VehicleExpenseActivity.this.expenseModels.get(i).getExpenseModels().get(i2);
                    view = ((LayoutInflater) VehicleExpenseActivity.this.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.vehicleexpanse_dialog, null);
                    AlertDialog.Builder builder = new AlertDialog.Builder(VehicleExpenseActivity.this);
                    builder.setView(view);
                    builder.setCancelable(true);
                    final AlertDialog create = builder.create();
                    create.show();
                    Button button = view.findViewById(R.id.btnDeleteBill);
                    view.findViewById(R.id.btnEditBill).setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {
                            create.dismiss();
                            Intent intent = new Intent(VehicleExpenseActivity.this, VehicleExpenseDetailAtivity.class);
                            intent.putExtra("BID", vehicleExpenseModel.getBid());
                            intent.putExtra("BPAYEE", vehicleExpenseModel.getPayee());
                            intent.putExtra("BAMOUNT", vehicleExpenseModel.getAmount());
                            intent.putExtra("BCATNAME", vehicleExpenseModel.getCatname());
                            intent.putExtra("BCATICON", vehicleExpenseModel.getCaticon());
                            intent.putExtra("BNOTE", vehicleExpenseModel.getNotes());
                            intent.putExtra("BDUEDATE", vehicleExpenseModel.getDuedate());
                            intent.putExtra("btn", "UPDATE");
                            VehicleExpenseActivity.this.startActivity(intent);
                        }
                    });
                    button.setOnClickListener(new View.OnClickListener() {

                        public void onClick(View view) {
                            create.dismiss();
                            view = ((LayoutInflater) VehicleExpenseActivity.this.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.vehicleexpanse_delete_itemdialog, null);
                            AlertDialog.Builder builder = new AlertDialog.Builder(VehicleExpenseActivity.this);
                            builder.setView(view);
                            builder.setCancelable(true);
                            final AlertDialog dialog = builder.create();
                            dialog.show();

                            TextView tv_delete = view.findViewById(R.id.tv_delete);
                            TextView tv_cancel = view.findViewById(R.id.tv_cancel);

                            tv_delete.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (sqlite.dlt(vehicleExpenseModel.getBid()) > 0) {
                                        TotalAmount();
                                    }
                                    dialog.dismiss();
                                }
                            });

                            tv_cancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });
                        }
                    });
                } catch (Exception unused) {
                    unused.printStackTrace();
                }
                return false;
            }
        });
    }

    public void TotalAmount() {
        String rawQuery = this.sqlite.rawQuery();
        int i = 0;
        if (rawQuery != null) {
            this.ll_empty.setVisibility(View.GONE);
            this.tvTotal.setVisibility(View.VISIBLE);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Total Amount: ");
            stringBuilder.append(getString(R.string.rs));
            stringBuilder.append(" ");
            stringBuilder.append(rawQuery);
            tvTotal.setText(stringBuilder.toString());
        } else {
            this.tvTotal.setVisibility(View.GONE);
            this.ll_empty.setVisibility(View.VISIBLE);
        }
        this.expenseModels = this.sqlite.list();
        this.expenseListAdapter = new VehicleExpenseList(this, this.expenseModels);
        this.listView.setAdapter(this.expenseListAdapter);
        while (i < this.expenseListAdapter.getGroupCount()) {
            try {
                this.listView.expandGroup(i);
                i++;
            } catch (Exception unused) {
                return;
            }
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.iv_addexpense:
                startActivity(new Intent(VehicleExpenseActivity.this, VehicleExpenseCategory.class));
                break;

            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }

    public void onResume() {
        super.onResume();
        TotalAmount();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}