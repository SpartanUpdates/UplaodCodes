package com.example.lyricsvideo.activity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.danikula.videocache.CacheListener;
import com.danikula.videocache.HttpProxyCacheServer;
import com.example.lyricsvideo.FullScreenVideoview.UniversalMediaController;
import com.example.lyricsvideo.FullScreenVideoview.UniversalVideoView;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.Utils.Utils;
import com.example.lyricsvideo.application.App;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.squareup.picasso.Picasso;

import java.io.File;

public class FullVideoPlayActivity extends AppCompatActivity implements UniversalVideoView.VideoViewCallback, CacheListener {

    private static final String TAG = "FullScreenVideoPlay";
    private static final String SEEK_POSITION_KEY = "SEEK_POSITION_KEY";
    public boolean IsPlayVidoeFromHome, IsVideoFromList;
    FullVideoPlayActivity activity = FullVideoPlayActivity.this;
    UniversalVideoView mVideoView;
    UniversalMediaController mMediaController;
    View mVideoLayout;
    ImageView ivBack, ivShare;
    String VideoUrl, VideoName, videoThumbImage;
    int StopVideoPosition;
    LinearLayout loadingLayout;
    ImageView ivVideoThumb;
    InterstitialAd mInterstitialAd;
    private int mSeekPosition;
    private boolean isFullscreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_video);
        VideoUrl = getIntent().getStringExtra("Url");
        VideoName = getIntent().getStringExtra("Name");
        videoThumbImage = getIntent().getStringExtra("videoThumbImage");
        IsPlayVidoeFromHome = getIntent().getBooleanExtra("IsPlayVidoeFromHome", false);
        IsVideoFromList = getIntent().getBooleanExtra("IsVideoFromList", false);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "FullVideoPlayActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
        InterstitialAd();
        mVideoLayout = findViewById(R.id.video_layout);
        mVideoView = findViewById(R.id.videoView);
        loadingLayout = findViewById(R.id.loading_layout);
        mMediaController = findViewById(R.id.media_controller);
        ivBack = findViewById(R.id.iv_back);
//        ivShare = findViewById(R.id.iv_share);
        ivVideoThumb = findViewById(R.id.iv_video_thumb);
        mVideoView.setMediaController(mMediaController);
        setVideoAreaSize();
        mVideoView.setVideoViewCallback(this);
        if (mSeekPosition > 0) {
            mVideoView.seekTo(mSeekPosition);
        }
        if (IsPlayVidoeFromHome) {
            SelectedItem();
        } else {
            mVideoView.setVideoPath(VideoUrl);
            mVideoView.start();
        }

        mMediaController.setTitle(VideoName);
        mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
            }
        });
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
//        ivShare.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                ShareVideo();
//            }
//        });
    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(this, getString(R.string.FB_inter));
        mInterstitialAd.setAdListener(new InterstitialAdListener() {

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }

            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                onBackPressed();

            }
        });
        mInterstitialAd.loadAd();
    }
//    private void ShareVideo() {
//        String path = VideoUrl;
//        final File file = new File(path);
//        final Intent shareIntent = new Intent("android.intent.action.SEND");
//        shareIntent.setType("video/*");
//        shareIntent.putExtra("android.intent.extra.SUBJECT", activity.getString(R.string.app_name));
//        shareIntent.putExtra("android.intent.extra.TEXT", String.valueOf(activity.getString(R.string.get_free_)) + activity.getString(R.string.app_name) + " at here : " + "https://play.google.com/store/apps/details?id=" + activity.getPackageName());
//        final Uri ShareUri = FileProvider.getUriForFile(activity, String.valueOf(activity.getPackageName()) + ".provider", file);
//        shareIntent.putExtra("android.intent.extra.STREAM", ShareUri);
//        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//        activity.startActivity(Intent.createChooser(shareIntent, "Share Video"));
//
//    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause ");
        if (mVideoView != null && mVideoView.isPlaying()) {
            mSeekPosition = mVideoView.getCurrentPosition();
            Log.d(TAG, "onPause mSeekPosition=" + mSeekPosition);
            mVideoView.pause();
        }
    }

    private void setVideoAreaSize() {
        mVideoLayout.post(new Runnable() {
            @Override
            public void run() {
                ViewGroup.LayoutParams videoLayoutParams = mVideoLayout.getLayoutParams();
                videoLayoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
                videoLayoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
                mVideoLayout.setLayoutParams(videoLayoutParams);
                mVideoView.requestFocus();
            }
        });
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(SEEK_POSITION_KEY, mSeekPosition);
    }

    @Override
    protected void onRestoreInstanceState(Bundle outState) {
        super.onRestoreInstanceState(outState);
        mSeekPosition = outState.getInt(SEEK_POSITION_KEY);
    }


    @Override
    public void onScaleChange(boolean isFullscreen) {
        this.isFullscreen = isFullscreen;
        if (isFullscreen) {
            ViewGroup.LayoutParams layoutParams = mVideoLayout.getLayoutParams();
            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
            layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
            mVideoLayout.setLayoutParams(layoutParams);

        } else {
            ViewGroup.LayoutParams layoutParams = mVideoLayout.getLayoutParams();
            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
            layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
            mVideoLayout.setLayoutParams(layoutParams);
        }

        switchTitleBar(!isFullscreen);
    }

    private void switchTitleBar(boolean show) {
        android.support.v7.app.ActionBar supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            if (show) {
                supportActionBar.show();
            } else {
                supportActionBar.hide();
            }
        }
    }

    @Override
    public void onPause(MediaPlayer mediaPlayer) {
    }

    @Override
    public void onStart(MediaPlayer mediaPlayer) {
    }

    @Override
    public void onBufferingStart(MediaPlayer mediaPlayer) {
    }

    @Override
    public void onBufferingEnd(MediaPlayer mediaPlayer) {
    }

    public void SelectedItem() {
        if (Utils.CheckIntrenetConnectivity(activity, false)) {
            checkCachedState();
            startVideo();
        } else {
            HttpProxyCacheServer proxy = App.getProxy(activity);
            boolean fullyCached = proxy.isCached(VideoUrl);
            if (fullyCached) {
                String proxyUrl = proxy.getProxyUrl(VideoUrl);
                mVideoView.setVideoPath(proxyUrl);
                mVideoView.start();
                loadingLayout.setVisibility(View.INVISIBLE);
                ivVideoThumb.setVisibility(View.GONE);
            } else {
                StopVideoPosition = mVideoView.getCurrentPosition();
                mVideoView.pause();
                loadingLayout.setVisibility(View.VISIBLE);
                ivVideoThumb.setVisibility(View.VISIBLE);
            }
        }
    }

    private void checkCachedState() {
        HttpProxyCacheServer proxy = App.getProxy(activity);
        boolean fullyCached = proxy.isCached(VideoUrl);
        if (fullyCached) {
            ivVideoThumb.setVisibility(View.GONE);
        } else {
            Picasso.with(activity).load(videoThumbImage).into(ivVideoThumb);
            ivVideoThumb.setVisibility(View.VISIBLE);
            loadingLayout.setVisibility(View.VISIBLE);
        }
    }

    private void startVideo() {
        HttpProxyCacheServer proxy = App.getProxy(activity);
        proxy.registerCacheListener(this, VideoUrl);
        String proxyUrl = proxy.getProxyUrl(VideoUrl);
        mVideoView.setVideoPath(proxyUrl);
        mVideoView.start();
    }

    @Override
    public void onCacheAvailable(File cacheFile, String url, int percentsAvailable) {
        if (mVideoView.isPlaying()) {
            ivVideoThumb.setVisibility(View.GONE);
            loadingLayout.setVisibility(View.GONE);
        }
    }


    @Override
    public void onBackPressed() {
        if (this.isFullscreen) {
            mVideoView.setFullscreen(false);
        } else {
            if (mInterstitialAd != null && mInterstitialAd.isAdLoaded()) {
                App.ShowDialog(activity);
                mInterstitialAd.show();
            } else {
                if (IsVideoFromList) {
                    finish();
                } else {
                    startActivity(new Intent(activity, MainActivity.class));
                    finish();
                }
            }
        }
    }

}
