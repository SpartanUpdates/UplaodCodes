package com.esc.storymaker.interfaces;

public interface HorizontallyScrollable {
    boolean interceptMoveLeft(float f, float f2);

    boolean interceptMoveRight(float f, float f2);
}
