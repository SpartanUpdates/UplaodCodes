import 'dart:math';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:date_picker_timeline/date_picker_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:rto_app/Utils/utils.dart';
import 'package:rto_app/VehicleMileage/controller/vehicle_mileage_controller.dart';
import 'package:rto_app/VehicleMileage/model/vehicle_mileage_model.dart';
import 'package:velocity_x/src/flutter/center.dart';
import 'package:velocity_x/src/flutter/padding.dart';
import 'package:velocity_x/src/flutter/widgets.dart';

class VehicleMileageCalculation extends StatefulWidget {
  @override
  _VehicleMileageCalculationState createState() =>
      _VehicleMileageCalculationState();
}

class _VehicleMileageCalculationState extends State<VehicleMileageCalculation> {
  VehicleMileageController controller = Get.put(VehicleMileageController());
  String? lastReserve = null;
  String? currentReserve = null;
  String? totalPrice = null;
  String? totalFuel = null;
  TextEditingController lastReserveController = TextEditingController();
  TextEditingController currentReserveController = TextEditingController();
  TextEditingController totalPriceController = TextEditingController();
  TextEditingController totalFuelController = TextEditingController();
  bool isCalculatedData = false;
  String selectedDate = DateTime.now().toString();
  DateTime preDate = DateTime.now().subtract(Duration(days: 2));

  @override
  Widget build(BuildContext context) {
    controller.getAllData();
    return WillPopScope(
      onWillPop: () {
        Future.delayed(const Duration(milliseconds: 350), () {
          Navigator.pop(context);
        });
        return Future.value(false);
      },
      child: Material(
        child: SafeArea(
          child: Scaffold(
            body: NestedScrollView(
              physics: BouncingScrollPhysics(),
              floatHeaderSlivers: true,
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return <Widget>[
                  SliverAppBar(
                    backgroundColor: Theme.of(context).primaryColor,
                    title: Text(
                      "Mileage Calculator",
                      style: TextStyle(
                          fontSize: 16.5,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Bold"),
                    ).centered(),
                    leading: Container(
                      padding: EdgeInsets.all(10),
                      child: Material(
                        color: Colors.transparent,
                        shape: CircleBorder(),
                        clipBehavior: Clip.hardEdge,
                        child: IconButton(
                            padding: EdgeInsets.zero,
                            onPressed: () {
                              Future.delayed(const Duration(milliseconds: 350),
                                  () {
                                Navigator.pop(context);
                              });
                            },
                            icon: Hero(
                              tag: "vehicleexpense",
                              transitionOnUserGestures: true,
                              child: Icon(
                                Icons.arrow_back_ios_rounded,
                                color: Theme.of(context).accentColor,
                                size: 20,
                              ).pOnly(left: 5),
                            )),
                      ),
                    ),
                    actions: [
                      IconButton(
                        onPressed: () {
                          Future.delayed(const Duration(milliseconds: 350), () {
                            Navigator.pop(context);
                            Navigator.pop(context);
                          });
                        },
                        icon: Hero(
                            tag: "rtooffice",
                            transitionOnUserGestures: true,
                            child: (Icon(
                              CupertinoIcons.home,
                              color: Theme.of(context).dividerColor,
                              size: 24,
                            ))),
                        iconSize: 30,
                      ).pOnly(right: 8),
                    ],
                  )
                ];
              },
              body: Column(
                children: [
                  Expanded(
                    child: Container(
                      color: Theme.of(context).primaryColor,
                      child: Container(
                          child: SingleChildScrollView(
                        physics: BouncingScrollPhysics(),
                        child: GetBuilder<VehicleMileageController>(
                          builder: (controller) {
                            return Column(
                              children: [
                                SizedBox(
                                  child: Card(
                                    color: Theme.of(context).canvasColor,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: SizedBox(
                                      height: 80,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                              child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Expanded(
                                                child: Padding(
                                                  padding: EdgeInsets.all(10),
                                                  child: Column(
                                                    children: [
                                                      SizedBox(
                                                        child: Text(
                                                          controller.kmPerLtr!
                                                              .toStringAsFixed(
                                                                  2),
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              fontSize: 25,
                                                              color: Theme.of(
                                                                      context)
                                                                  .hintColor,
                                                              fontFamily:
                                                                  "Circular Medium"),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        child: Text(
                                                          "Km / Ltr",
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              fontSize: 13,
                                                              color: Color(
                                                                  0xff757381),
                                                              fontFamily:
                                                                  "Circular Medium"),
                                                        ),
                                                      ).pOnly(top: 5)
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.center,
                                                child: Container(
                                                  color: Colors.blueGrey,
                                                  height: 50,
                                                  width: 0.2,
                                                ),
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding: EdgeInsets.all(10),
                                                  child: Column(
                                                    children: [
                                                      SizedBox(
                                                        child: Text(
                                                          controller.rsPerLtr!
                                                              .toStringAsFixed(
                                                                  2),
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              fontSize: 25,
                                                              color: Theme.of(
                                                                      context)
                                                                  .hintColor,
                                                              fontFamily:
                                                                  "Circular Medium"),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        child: Text(
                                                          "Rs / Ltr",
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              fontSize: 13,
                                                              color: Color(
                                                                  0xff757381),
                                                              fontFamily:
                                                                  "Circular Medium"),
                                                        ),
                                                      ).pOnly(top: 5)
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.center,
                                                child: Container(
                                                  color: Colors.blueGrey,
                                                  height: 50,
                                                  width: 0.2,
                                                ),
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding: EdgeInsets.all(10),
                                                  child: Column(
                                                    children: [
                                                      SizedBox(
                                                        child: Text(
                                                          controller.rsPerKm!
                                                              .toStringAsFixed(
                                                                  2),
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              fontSize: 25,
                                                              color: Theme.of(
                                                                      context)
                                                                  .hintColor,
                                                              fontFamily:
                                                                  "Circular Medium"),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        child: Text(
                                                          "Rs / Km",
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              fontSize: 13,
                                                              color: Color(
                                                                  0xff757381),
                                                              fontFamily:
                                                                  "Circular Medium"),
                                                        ),
                                                      ).pOnly(top: 5)
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          )),
                                        ],
                                      ),
                                    ),
                                  ),
                                ).pOnly(bottom: 15),
                                TextField(
                                  cursorColor: Theme.of(context).accentColor,
                                  style: TextStyle(
                                      fontFamily: "Circular Medium",
                                      fontSize: 20,
                                      color: Theme.of(context).accentColor),
                                  autofocus: false,
                                  controller: lastReserveController,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    WhitelistingTextInputFormatter.digitsOnly
                                  ],
                                  onChanged: (value) {
                                    setState(() {
                                      if (value.isEmpty) {
                                        lastReserve =
                                            'This should not be empty';
                                      } else {
                                        lastReserve = null;
                                      }
                                    });
                                  },
                                  decoration: InputDecoration(
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Color(0xff6C629F),
                                            width: 0.3),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Color(0xff6C629F),
                                            width: 0.3),
                                      ),
                                      border: const OutlineInputBorder(),
                                      labelText: " Last Reading ( km ) ",
                                      labelStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 17,
                                          color:
                                              Theme.of(context).indicatorColor),
                                      hintStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 20,
                                          color:
                                              Theme.of(context).indicatorColor),
                                      hintText: "ex : 1250",
                                      errorStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 10,
                                          color: Colors.redAccent),
                                      errorText:
                                          lastReserve /*controllers.lastReserve*/),
                                  //controller: controller,
                                ).px(5).pOnly(top: 5),
                                TextField(
                                  cursorColor: Theme.of(context).accentColor,
                                  style: TextStyle(
                                      fontFamily: "Circular Medium",
                                      fontSize: 20,
                                      color: Theme.of(context).accentColor),
                                  autofocus: false,
                                  controller: currentReserveController,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    WhitelistingTextInputFormatter.digitsOnly
                                  ],
                                  onChanged: (value) {
                                    setState(() {
                                      if (value.isEmpty) {
                                        currentReserve =
                                            'This should not be empty';
                                      } else if (int.parse(value) <
                                          int.parse(
                                              lastReserveController.text)) {
                                        currentReserve =
                                            'Current Reading Km is never less than Last Reading Km';
                                      } else {
                                        currentReserve = null;
                                      }
                                    });
                                  },
                                  decoration: InputDecoration(
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Color(0xff6C629F),
                                            width: 0.3),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Color(0xff6C629F),
                                            width: 0.3),
                                      ),
                                      border: OutlineInputBorder(),
                                      labelText: " Current Reading ( km ) ",
                                      labelStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 17,
                                          color:
                                              Theme.of(context).indicatorColor),
                                      hintStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 20,
                                          color:
                                              Theme.of(context).indicatorColor),
                                      hintText: "ex : 1800",
                                      errorStyle: TextStyle(
                                          fontFamily: "Circular Medium",
                                          fontSize: 10,
                                          color: Colors.redAccent),
                                      errorText:
                                          currentReserve /*controllers.currentReserve*/),
                                  //controller: controller,
                                ).px(5).py(15),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      child: Padding(
                                        padding: EdgeInsets.all(5),
                                        child: TextField(
                                          cursorColor:
                                              Theme.of(context).accentColor,
                                          style: TextStyle(
                                              fontFamily: "Circular Medium",
                                              fontSize: 20,
                                              color: Theme.of(context)
                                                  .accentColor),
                                          autofocus: false,
                                          controller: totalPriceController,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: [
                                            WhitelistingTextInputFormatter
                                                .digitsOnly
                                          ],
                                          onChanged: (value) {
                                            setState(() {
                                              if (value.isEmpty) {
                                                totalPrice =
                                                    'This should not be empty';
                                              } else {
                                                totalPrice = null;
                                              }
                                            });
                                          },
                                          decoration: InputDecoration(
                                              focusedBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Color(0xff6C629F),
                                                    width: 0.3),
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Color(0xff6C629F),
                                                    width: 0.3),
                                              ),
                                              border:
                                                  const OutlineInputBorder(),
                                              labelText: " Total Price ( Rs ) ",
                                              labelStyle: TextStyle(
                                                  fontFamily: "Circular Medium",
                                                  fontSize: 17,
                                                  color: Theme.of(context)
                                                      .indicatorColor),
                                              hintStyle: TextStyle(
                                                  fontFamily: "Circular Medium",
                                                  fontSize: 20,
                                                  color: Theme.of(context)
                                                      .indicatorColor),
                                              hintText: "ex : 900",
                                              errorStyle: TextStyle(
                                                  fontFamily: "Circular Medium",
                                                  fontSize: 10,
                                                  color: Colors.redAccent),
                                              errorText:
                                                  totalPrice /*controllers.totalPrice*/),
                                          //controller: controller,
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: Padding(
                                        padding: EdgeInsets.all(5),
                                        child: TextField(
                                          cursorColor:
                                              Theme.of(context).accentColor,
                                          style: TextStyle(
                                              fontFamily: "Circular Medium",
                                              fontSize: 20,
                                              color: Theme.of(context)
                                                  .accentColor),
                                          controller: totalFuelController,
                                          onChanged: (value) {
                                            setState(() {
                                              if (value.isEmpty) {
                                                totalFuel =
                                                    'This should not be empty';
                                              } else {
                                                totalFuel = null;
                                              }
                                            });
                                          },
                                          keyboardType: TextInputType.number,
                                          inputFormatters: [
                                            WhitelistingTextInputFormatter
                                                .digitsOnly
                                          ],
                                          decoration: InputDecoration(
                                              focusedBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Color(0xff6C629F),
                                                    width: 0.3),
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Color(0xff6C629F),
                                                    width: 0.3),
                                              ),
                                              border:
                                                  const OutlineInputBorder(),
                                              labelText: " Total Fuel ( Ltr ) ",
                                              labelStyle: TextStyle(
                                                  fontFamily: "Circular Medium",
                                                  fontSize: 17,
                                                  color: Theme.of(context)
                                                      .indicatorColor),
                                              hintStyle: TextStyle(
                                                  fontFamily: "Circular Medium",
                                                  fontSize: 20,
                                                  color: Theme.of(context)
                                                      .indicatorColor),
                                              hintText: "ex : 7",
                                              errorStyle: TextStyle(
                                                  fontFamily: "Circular Medium",
                                                  fontSize: 10,
                                                  color: Colors.redAccent),
                                              errorText:
                                                  totalFuel /*controllers.totalFuel*/),
                                          //controller: controller,
                                        ),
                                      ),
                                    ),
                                  ],
                                ).pOnly(bottom: 5),
                                Container(
                                  height: 100,
                                  child: DatePicker(
                                    preDate,
                                    initialSelectedDate: DateTime.now(),
                                    selectionColor:
                                        Theme.of(context).canvasColor,
                                    selectedTextColor: Colors.blueGrey,
                                    dayTextStyle: TextStyle(
                                        color: Colors.grey,
                                        fontFamily: "Circular Medium"),
                                    dateTextStyle: TextStyle(
                                        color: Colors.grey,
                                        fontFamily: "Circular Medium"),
                                    monthTextStyle: TextStyle(
                                        color: Colors.grey,
                                        fontFamily: "Circular Medium"),
                                    onDateChange: (date) {
                                      selectedDate = date.toString();
                                    },
                                  ),
                                ).px(2).py(10),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 45,
                                      width: 130,
                                      child: Material(
                                        color: Theme.of(context).canvasColor,
                                        child: Ink(
                                          decoration: BoxDecoration(),
                                          child: InkWell(
                                            customBorder:
                                                RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.only(
                                                            topRight: Radius
                                                                .circular(8),
                                                            bottomRight:
                                                                Radius.circular(
                                                                    8))),
                                            splashColor: Colors.black,
                                            onTap: () {
                                              if (Links.rateDialog) {
                                                Links.rateDialog = false;
                                                CommanDialog.showRatingDialog(
                                                    context);
                                              }

                                              Random random = new Random();
                                              int randomNumber =
                                                  random.nextInt(1000);
                                              if (isCalculatedData) {
                                                String day = selectedDate
                                                    .substring(8, 10);
                                                String month = selectedDate
                                                    .substring(5, 7);
                                                String year = selectedDate
                                                    .substring(0, 4);
                                                controller
                                                    .insert(VehicleMileageModel(
                                                        randomId: randomNumber
                                                            .toString(),
                                                        date:
                                                            "${day} - ${month} - ${year}",
                                                        lastreserve:
                                                            lastReserveController
                                                                .text,
                                                        currentreserve:
                                                            currentReserveController
                                                                .text,
                                                        totalprice:
                                                            totalPriceController
                                                                .text,
                                                        totalfuel:
                                                            totalFuelController
                                                                .text,
                                                        kmperltr: controller
                                                            .kmPerLtr!
                                                            .toStringAsFixed(2),
                                                        rsperltr: controller
                                                            .rsPerLtr!
                                                            .toStringAsFixed(2),
                                                        rsperkm: controller
                                                            .rsPerKm!
                                                            .toStringAsFixed(
                                                                2)))
                                                    .then((value) {})
                                                    .onError(
                                                        (error, stackTrace) {});
                                                controller.getAllData();
                                                Navigator.pop(context);
                                              } else {
                                                SnackBar(
                                                  content: Row(
                                                    children: <Widget>[
                                                      Text(
                                                        "Please calculate first !",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                    ],
                                                  ),
                                                  duration:
                                                      Duration(seconds: 3),
                                                  backgroundColor: Colors.black,
                                                );
                                              }
                                            },
                                            child: Center(
                                              child: Text(
                                                "Save",
                                                style: TextStyle(
                                                    color: Theme.of(context)
                                                        .accentColor,
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                        .cornerRadius(8)
                                        .pOnly(left: 10, right: 10)
                                        .py(15),
                                    Container(
                                      height: 45,
                                      width: 130,
                                      child: Material(
                                        color: Theme.of(context).canvasColor,
                                        child: Ink(
                                          decoration: BoxDecoration(),
                                          child: InkWell(
                                            customBorder:
                                                RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.only(
                                                            topRight: Radius
                                                                .circular(8),
                                                            bottomRight:
                                                                Radius.circular(
                                                                    8))),
                                            splashColor: Colors.black,
                                            onTap: () {
                                              if (lastReserveController
                                                  .text.isEmpty) {
                                                setState(() {
                                                  lastReserve =
                                                      "This should not be empty";
                                                });
                                              }
                                              if (currentReserveController
                                                  .text.isEmpty) {
                                                setState(() {
                                                  currentReserve =
                                                      "This should not be empty";
                                                });
                                              }
                                              if (totalPriceController
                                                  .text.isEmpty) {
                                                setState(() {
                                                  totalPrice =
                                                      "This should not be empty";
                                                });
                                              }
                                              if (totalFuelController
                                                  .text.isEmpty) {
                                                setState(() {
                                                  totalFuel =
                                                      "This should not be empty";
                                                });
                                              }
                                              if (lastReserveController
                                                      .text.isNotEmpty &&
                                                  currentReserveController
                                                      .text.isNotEmpty &&
                                                  totalPriceController
                                                      .text.isNotEmpty &&
                                                  totalFuelController
                                                      .text.isNotEmpty) {
                                                FocusScope.of(context)
                                                    .unfocus();
                                                controller.calculation(
                                                    context,
                                                    lastReserveController.text,
                                                    currentReserveController
                                                        .text,
                                                    totalPriceController.text,
                                                    totalFuelController.text);
                                                isCalculatedData = true;
                                              }
                                            },
                                            child: Center(
                                              child: Text(
                                                "Calculate",
                                                style: TextStyle(
                                                    color: Theme.of(context)
                                                        .accentColor,
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                        .cornerRadius(8)
                                        .pOnly(left: 10, right: 10)
                                        .py(15)
                                  ],
                                ),
                              ],
                            );
                          },
                        ),
                      )).px(20).py(20),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
