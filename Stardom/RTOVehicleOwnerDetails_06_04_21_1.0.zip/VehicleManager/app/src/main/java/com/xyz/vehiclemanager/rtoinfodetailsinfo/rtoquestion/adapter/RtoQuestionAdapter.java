package com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.model.RtoQuestion;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RtoQuestionAdapter extends RecyclerView.Adapter<RtoQuestionAdapter.ViewHolder> {
    Context context;
    ArrayList<RtoQuestion> rtoQuestionArray;

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_question;
        TextView tv_answer;
        TextView tv_questionNo;
        TextView tv_answerNo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_question = itemView.findViewById(R.id.tv_question);
            tv_answer = itemView.findViewById(R.id.tv_answer);
            tv_questionNo = itemView.findViewById(R.id.tv_questionNo);
            tv_answerNo = itemView.findViewById(R.id.tv_answerNo);
        }
    }

    public RtoQuestionAdapter(Context context, ArrayList<RtoQuestion> rtoQuestionArray) {
        this.context = context;
        this.rtoQuestionArray = rtoQuestionArray;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_rto_questions,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.tv_question.setText(rtoQuestionArray.get(position).getQuestion());
        holder.tv_answer.setText(rtoQuestionArray.get(position).getAnswer());
        holder.tv_questionNo.setText("Q "+rtoQuestionArray.get(position).getId()+":");
        holder.tv_answerNo.setText("A "+rtoQuestionArray.get(position).getId()+":");
    }

    @Override
    public int getItemCount() {
        return rtoQuestionArray.size();
    }

}
