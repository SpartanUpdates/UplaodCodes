package com.wavymusic.DashBord.activity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.DashBord.Fragment.ThemeViewAllFragmentWavy;
import com.wavymusic.DashBord.Model.CategoryModel;
import com.wavymusic.DashBord.Model.ThemeHomeModel;
import com.wavymusic.DashBord.View.ViewPager.CustomViewPager;
import com.wavymusic.MoreApp.MoreAppActivity;
import com.wavymusic.MyCreationVideo.activity.YourVideoActivity;
import com.wavymusic.Preferance.LanguagePref;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.APIClient;
import com.wavymusic.RetrofitApiCall.APIInterface;
import com.wavymusic.RetrofitApiCall.AppConstant;
import com.wavymusic.Setting.SettingActivity;
import com.wavymusic.UnityPlayerActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThemeAllActivityWavy extends AppCompatActivity implements View.OnClickListener {

    Activity activity = ThemeAllActivityWavy.this;
    public int id;
    ArrayList<CategoryModel> tabcategorylistWavy = new ArrayList<>();
    private ArrayList<ThemeHomeModel> WhatsNewListWavy = new ArrayList<>();
    RelativeLayout rlLoading;
    LinearLayout llRetry;
    Button btnRetry;
    TextView tvtitle;
    Toolbar toolbar;
    TextView tv_prg_msg;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ImageView ivBack, ivMoreApp;
    private ImageView ivSetting, ivMyCreation, ivRate;
    APIInterface apiInterface;
    ViewPagerAdapter adp;
    public SharedPreferences pref;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public boolean IsFromLanguage;

    boolean isSetupReadyWavy = false;
    public static boolean isApiRunningWavy = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme_all_wavy);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        IsFromLanguage = getIntent().getBooleanExtra("IsFromLanguage", false);
        CategoryModel categoryModel = new CategoryModel();
        categoryModel.setCategoryId("111");
        categoryModel.setName("New");
        tabcategorylistWavy.add(categoryModel);
        PutAnalyticsEvent();
        BindView();
        SetWavyThemJsonData();
        VerifyToSetOfflineThemeDataWavy();
        BannerAds();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ThemeAllActivityWavy");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BindView() {
        toolbar = findViewById(R.id.toolbar);
        tvtitle = findViewById(R.id.tv_app_name);
        rlLoading = findViewById(R.id.rl_loading);
        tabLayout = findViewById(R.id.tab_viewall_wavy);
        viewPager = findViewById(R.id.mViewPager);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);
        tv_prg_msg = findViewById(R.id.tv_prg_msg);
        tv_prg_msg.setText("Please wait…");
        ivBack = findViewById(R.id.iv_back);
        ivMoreApp = findViewById(R.id.iv_more_app);
        ivSetting = findViewById(R.id.iv_setting);
        ivMyCreation = findViewById(R.id.iv_my_creation);
        ivRate = findViewById(R.id.iv_rate);
        ivBack.setOnClickListener(this);
        ivMoreApp.setOnClickListener(this);
        ivSetting.setOnClickListener(this);
        ivMyCreation.setOnClickListener(this);
        ivRate.setOnClickListener(this);

    }

    private void GoToMoreApp() {
        startActivity(new Intent(activity, MoreAppActivity.class));
        finish();
    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void ShowBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void SetWavyThemJsonData() {
        if (Utils.checkConnectivity(activity, false)) {
            if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
                if (!isApiRunningWavy) {
                    isApiRunningWavy = true;
                    GetCategoryWavy();
                } else if (IsFromLanguage && MyApplication.TempcallWavy != null) {
                    MyApplication.TempcallWavy.cancel();
                    isApiRunningWavy = true;
                    GetCategoryWavy();
                }
            } else if (((new Date().getTime() - pref.getLong("offlineResponseTime", 1588598205L)) >= AppConstant.ApiUpdateTime)) {
                if (!isApiRunningWavy) {
                    isApiRunningWavy = true;
                    GetCategoryWavy();
                }
            } else if (IsFromLanguage) {
                if (!isApiRunningWavy) {
                    isApiRunningWavy = true;
                    GetCategoryWavy();
                } else if (MyApplication.TempcallWavy != null) {
                    MyApplication.TempcallWavy.cancel();
                    isApiRunningWavy = true;
                    GetCategoryWavy();
                }
            }
        } else if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
            Log.e("HomeActivity", "No Internet");
        }
    }

    private void VerifyToSetOfflineThemeDataWavy() {
        if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
            isSetupReadyWavy = true;
        } else if (!IsFromLanguage) {
            SetupDataInLayoutWavy(pref.getString("offlineResponse", ""));
        } else {
            isSetupReadyWavy = true;
        }
    }

    private void GetCategoryWavy() {
        final Handler handler = new Handler();
        if (pref.getString("offlineResponse", "").equalsIgnoreCase("") || IsFromLanguage) {
            handler.postDelayed(new Runnable() {
                public void run() {
                    tv_prg_msg.setText("Slow Internet Connection");
                }
            }, 10000);
        }
        llRetry.setVisibility(View.GONE);
        rlLoading.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.GetAllTheme(AppConstant.Token, AppConstant.ApplicationId);
        MyApplication.TempcallWavy = call;
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        if (handler != null) {
                            handler.removeCallbacksAndMessages(null);
                        }
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        //Set Response In Offline
                        SetOfflineCategory(activity, jsonObj.toString(), "offlineResponse");
                        //Set Response Time
                        SetOfflineResponseTime(activity, new Date(), "offlineResponseTime");
                        isApiRunningWavy = false;
                        if (isSetupReadyWavy) {
                            isSetupReadyWavy = false;
                            SetupDataInLayoutWavy(jsonObj.toString());
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                isApiRunningWavy = false;
                rlLoading.setVisibility(View.GONE);
                if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetupDataInLayoutWavy(String response) {
        try {
            JSONObject jsonObj = new JSONObject(response);
            JSONArray tabcategory = jsonObj.getJSONArray("category");
            for (int i = 0; i < tabcategory.length(); i++) {
                JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                String CategoryId = tabcategoryJSONObject.getString("id");
                SetOfflineCategory(activity, tabcategoryJSONObject.toString(), "Wavy" + CategoryId);
                CategoryModel categoryModel = new CategoryModel();
                categoryModel.setCategoryId(tabcategoryJSONObject.getString("id"));
                categoryModel.setName(tabcategoryJSONObject.getString("name"));
                tabcategorylistWavy.add(categoryModel);
                //What'sNewData
                JSONArray jSONArray4 = tabcategoryJSONObject.getJSONArray("themes");
                for (int j = 0; j < jSONArray4.length(); j++) {
                    ThemeHomeModel themeModel = new ThemeHomeModel();
                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                    if (jsonobjecttheme.getString("is_release").equalsIgnoreCase("1")) {
                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                        themeModel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                        themeModel.setSmall_Thumbnail(jsonobjecttheme.getString("small_thumbnail"));
                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                        themeModel.setAnimSoundPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                        themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                        themeModel.setThemeCounter(jsonobjecttheme.getString("downloads"));
                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                        if (themeModel.isNewRealise().equals("1")) {
                            WhatsNewListWavy.add(themeModel);
                        }
                    }
                }
            }
            SetOfflineCategory(activity, Utils.WhatsNewJsonWavy(WhatsNewListWavy), "NewThemeWavy");
            setUpPagerWavy();
            SetTabLayoutWavy();
            rlLoading.setVisibility(View.GONE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

    private void setUpPagerWavy() {
        adp = new ViewPagerAdapter(getSupportFragmentManager());
        int i;
        viewPager.setAdapter(adp);
        if (MyApplication.CatSelectedPositionWavy != -1) {
            i = MyApplication.CatSelectedPositionWavy;
        } else {
            i = 0;
        }
        viewPager.setCurrentItem(i);
        tabLayout.setupWithViewPager(viewPager);
    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayoutWavy() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
        }

        ImageView ivCat = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getCustomView().findViewById(R.id.iv_cat);
        ivCat.setImageResource(Utils.INSTANCE.ThemHomeCatThumSelected(tabcategorylistWavy.get(tabLayout.getSelectedTabPosition()).getName()));
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                LinearLayout llIndictor = customView.findViewById(R.id.ll_indictor);
                llIndictor.setVisibility(View.VISIBLE);
                ImageView ivCat = customView.findViewById(R.id.iv_cat);
                ivCat.setImageResource(Utils.INSTANCE.ThemHomeCatThumSelected(tabcategorylistWavy.get(tab.getPosition()).getName()));
                MyApplication.ThemePositionWavy = 0;
                MyApplication.CatSelectedPositionWavy = tab.getPosition();

            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                LinearLayout llIndictor = customView.findViewById(R.id.ll_indictor);
                llIndictor.setVisibility(View.GONE);
                ImageView ivCat = customView.findViewById(R.id.iv_cat);
                ivCat.setImageResource(Utils.INSTANCE.ThemHomeCatThum(tabcategorylistWavy.get(tab.getPosition()).getName()));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    ImageView ivCat = customView.findViewById(R.id.iv_cat);
                    ivCat.setImageResource(Utils.INSTANCE.ThemHomeCatThumSelected(tabcategorylistWavy.get(tab.getPosition()).getName()));
                }
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_setting:
                GoToSetting();
                break;
            case R.id.iv_my_creation:
                GoToMyCreation();
                break;
            case R.id.iv_rate:
                RateApp();
                break;
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.iv_more_app:
                GoToMoreApp();
                break;
        }
    }

    private void GoToSetting() {
        startActivity(new Intent(activity, SettingActivity.class));
        finish();
    }

    private void GoToMyCreation() {
        startActivity(new Intent(activity, YourVideoActivity.class));
        finish();
    }

    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    private void ShareAPP() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "United Videos");
            String shareMessage = "\nGet free United Videos at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return ThemeViewAllFragmentWavy.newInstance(Integer.parseInt(tabcategorylistWavy.get(position).getCategoryId()));
        }


        @Override
        public int getCount() {
            return tabcategorylistWavy.size();
        }


        public View getTabView(int position) {
            View tabCatView = LayoutInflater.from(activity).inflate(R.layout.row_category_item, null);
            TextView tv = tabCatView.findViewById(R.id.tvCategoryName);
            ImageView ivCat = tabCatView.findViewById(R.id.iv_cat);
            tv.setText(tabcategorylistWavy.get(position).getName());
            ivCat.setImageResource(Utils.INSTANCE.ThemHomeCatThum(tabcategorylistWavy.get(position).getName()));
            return tabCatView;
        }
    }

    private void SetOfflineCategory(Context c, String userObject, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    private void SetOfflineResponseTime(Context c, final Date date, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putLong(key, date.getTime());
        editor.apply();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(activity, DashbordActivity.class));
        finish();

       /*Intent intent=new Intent(activity,DashbordActivity.class);
        overridePendingTransition(R.anim.left_right, R.anim.right_left);
        startActivity(intent);
        finish();*/
    }
}