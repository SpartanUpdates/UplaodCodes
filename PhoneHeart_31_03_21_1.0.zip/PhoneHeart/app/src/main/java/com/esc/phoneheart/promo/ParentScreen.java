package com.esc.phoneheart.promo;

import android.os.Bundle;
import android.util.DisplayMetrics;

import com.esc.phoneheart.activity.BaseActivity;
import com.google.android.gms.ads.AdView;

public class ParentScreen extends BaseActivity {
    public AdView adView;
    public int height;
    public int width;

    public int getHeight() {
        return this.height;
    }

    public int getWidth() {
        return this.width;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public void onDestroy() {
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
        }
        super.onDestroy();
    }

    public void setDeviceDimensio() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.width = displayMetrics.widthPixels;
        this.height = displayMetrics.heightPixels;
    }
}
