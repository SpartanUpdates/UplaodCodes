package flash.light.shine.com.util;

import android.os.Build.VERSION;
import android.util.Base64;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

public class Crypto {
    private static final String HEX = "0123456789ABCDEF";
    private static final int JELLY_BEAN_4_2 = 17;
    private static final byte[] key = new byte[16];

    public static String encrypt(String str, String str2) throws Exception {
        return (str2 == null || str2 == "") ? null : new String(Base64.encodeToString(toHex(encrypt(getRawKey(str.getBytes()), str2.getBytes())).getBytes(), 0));
    }

    public static String decrypt(String str, String str2) throws Exception {
        if (str2 == null || str2 == "") {
            return null;
        }
        byte[] bytes = str.getBytes();
        byte[] bArr = key;
        int i = 16;
        if (bytes.length < 16) {
            i = bytes.length;
        }
        System.arraycopy(bytes, 0, bArr, 0, i);
        return new String(decrypt(getRawKey(bytes), toByte(new String(Base64.decode(str2, 0)))));
    }

    public static byte[] encryptBytes(String str, byte[] bArr) throws Exception {
        return encrypt(getRawKey(str.getBytes()), bArr);
    }

    public static byte[] decryptBytes(String str, byte[] bArr) throws Exception {
        return decrypt(getRawKey(str.getBytes()), bArr);
    }

    private static byte[] getRawKey(byte[] bArr) throws Exception {
        SecureRandom instance;
        KeyGenerator instance2 = KeyGenerator.getInstance("AES");
        String str = "SHA1PRNG";
        if (VERSION.SDK_INT >= 17) {
            instance = SecureRandom.getInstance(str, "Crypto");
        } else {
            instance = SecureRandom.getInstance(str);
        }
        instance.setSeed(bArr);
        try {
            instance2.init(256, instance);
        } catch (Exception unused) {
            try {
                instance2.init(192, instance);
            } catch (Exception unused2) {
                instance2.init(128, instance);
            }
        }
        return instance2.generateKey().getEncoded();
    }

    private static byte[] encrypt(byte[] bArr, byte[] bArr2) throws Exception {
        String str = "AES";
        SecretKeySpec secretKeySpec = new SecretKeySpec(bArr, str);
        Cipher instance = Cipher.getInstance(str);
        instance.init(1, secretKeySpec);
        return instance.doFinal(bArr2);
    }

    private static byte[] decrypt(byte[] bArr, byte[] bArr2) throws Exception {
        String str = "AES";
        SecretKeySpec secretKeySpec = new SecretKeySpec(bArr, str);
        Cipher instance = Cipher.getInstance(str);
        instance.init(2, secretKeySpec);
        return instance.doFinal(bArr2);
    }

    public static String toHex(String str) {
        return toHex(str.getBytes());
    }

    public static String fromHex(String str) {
        return new String(toByte(str));
    }

    public static byte[] toByte(String str) {
        int length = str.length() / 2;
        byte[] bArr = new byte[length];
        for (int i = 0; i < length; i++) {
            int i2 = i * 2;
            bArr[i] = Integer.valueOf(str.substring(i2, i2 + 2), 16).byteValue();
        }
        return bArr;
    }

    public static String toHex(byte[] bArr) {
        if (bArr == null) {
            return "";
        }
        StringBuffer stringBuffer = new StringBuffer(bArr.length * 2);
        for (byte appendHex : bArr) {
            appendHex(stringBuffer, appendHex);
        }
        return stringBuffer.toString();
    }

    private static void appendHex(StringBuffer stringBuffer, byte b) {
        int i = (b >> 4) & 15;
        String str = HEX;
        stringBuffer.append(str.charAt(i)).append(str.charAt(b & 15));
    }
}
