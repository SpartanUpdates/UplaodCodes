package com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.activity;

import static com.kotlinz.vehiclemanager.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.Room.MileageDatabase;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.adapter.VehicleMileageAdapter;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.model.Mileage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

public class VehicleMileageActivity extends AppCompatActivity implements View.OnClickListener {
    private Activity activity = VehicleMileageActivity.this;
    private ImageView iv_addmileage;
    private LinearLayout ll_empty;
    private RecyclerView rvmileage;
    private ImageView iv_back;
    private VehicleMileageAdapter vehicleMileageAdapter;
    private List<Mileage> mileagelist = new ArrayList<>();
    private TextView title_tv;
    private MileageDatabase mileageDatabase;
    private Boolean darkMode = false;

    private NativeAd nativeAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_mileage);
        mileagelist = new ArrayList<>();
        mileageDatabase = Room.databaseBuilder(VehicleMileageActivity.this, MileageDatabase.class, "MileageDatabase").allowMainThreadQueries().build();
        BindView();
        SetData();
        LoadNativeAds();
        PutAnalyticsEvent();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            darkMode = true;
            setupDarkMode();
        }
        DarkTheame darkTheame = new DarkTheame(VehicleMileageActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            darkMode = true;
            setupDarkMode();
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VehicleMileageActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (VehicleMileageActivity.this.nativeAd != null) {
                            VehicleMileageActivity.this.nativeAd.destroy();
                        }
                        VehicleMileageActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    private void setupDarkMode() {
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        ll_empty.setBackgroundResource(R.drawable.ic_vehicle_mileage_bg_dark);
    }

    private void SetData() {
        mileagelist = mileageDatabase.mileageDao().getMileageData();
        Collections.reverse(mileagelist);
        vehicleMileageAdapter = new VehicleMileageAdapter(VehicleMileageActivity.this, darkMode, mileagelist);
        rvmileage.setLayoutManager(new GridLayoutManager(this, 1));
        rvmileage.setAdapter(vehicleMileageAdapter);
        if (mileagelist != null && !mileagelist.isEmpty()) {
            ll_empty.setVisibility(View.GONE);
            rvmileage.setVisibility(View.VISIBLE);
        } else {
            rvmileage.setVisibility(View.GONE);
            ll_empty.setVisibility(View.VISIBLE);
        }
    }

    private void BindView() {
        iv_addmileage = findViewById(R.id.iv_addmileage);
        ll_empty = findViewById(R.id.ll_emptyLayout);
        rvmileage = findViewById(R.id.recyclerview_mileage);
        iv_back = findViewById(R.id.iv_back);
        title_tv = findViewById(R.id.title_tv);

        iv_addmileage.setOnClickListener(this);
        iv_back.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_addmileage:
                if (MyApplication.isShowAd == 1) {
                    startActivity(new Intent(VehicleMileageActivity.this, VehicleMilageDetailActivity.class));
                    finish();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 38;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        startActivity(new Intent(VehicleMileageActivity.this, VehicleMilageDetailActivity.class));
                        finish();
                    }
                }
                break;

            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(VehicleMileageActivity.this, MainActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 20;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(VehicleMileageActivity.this, MainActivity.class));
                finish();
            }
        }
    }
}