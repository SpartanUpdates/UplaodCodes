package com.Pulse.VideoStatus.SongCrop.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.Pulse.VideoStatus.R;
import com.Pulse.VideoStatus.SongCrop.media.mediacontext;


public class PlayMusicControllerView extends View {
    private float A;
    private Drawable B;
    private boolean C;
    private boolean a;
    private int b;
    private float c;
    private int d;
    private float e;
    private Drawable drawable;
    private playmusicControllerinterface f4953g;
    private Paint h;
    private Paint i;
    private Paint j;
    private int k;
    private int l;
    private float m;
    private float n;
    private Paint o;
    private float p;
    private float q;
    private float r;
    private float s;
    private float t;
    private float u;
    private float v;
    private int w;
    private int x;
    private long y;
    private float z;


    public PlayMusicControllerView(Context context) {
        this(context, null);
    }

    public PlayMusicControllerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PlayMusicControllerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.k = -1;
        this.d = getResources().getColor(R.color.bgBarColor);
        this.b = getResources().getColor(R.color.barColor);
        this.c = 2.0f;
        this.A = 16.0f;
        this.z = 20.0f;
        this.C = true;
        this.x = 10;
        this.c = (float) mediacontext.context(context, this.c);
        this.A = (float) mediacontext.context(context, this.A);
        this.z = (float) mediacontext.context(context, this.z);
        this.x = mediacontext.context(context, (float) this.x);
        this.drawable = getResources().getDrawable(R.drawable.icon_player_seekbar);
        this.B = getResources().getDrawable(R.drawable.icon_player_seekbar);
        this.o = new Paint(1);
        this.o.setColor(getResources().getColor(R.color.barColorBlack));
        this.o.setStyle(Style.STROKE);
        this.o.setStrokeWidth(this.c);
        this.i = new Paint(1);
        this.h = new Paint(1);
        this.j = new Paint(1);
        this.j.setColor(-1);
        this.i.setStrokeWidth(this.c);
        this.i.setStyle(Style.STROKE);
        this.h.setStyle(Style.STROKE);
        this.h.setStrokeWidth(this.c);
        this.m = this.z / 1.07374182E9f;
        this.t = this.m + (this.z / 1.07374182E9f);

    }

    private void a(Canvas canvas) {
        canvas.drawLine(this.z / 2.0f, (float) (this.l / 2), ((float) this.w) - (this.z / 2.0f), (float) (this.l / 2), this.i);
    }

    private boolean a(MotionEvent motionEvent) {
        return !this.C && new RectF(this.m - this.z, this.n - this.z, this.m + this.z, this.n + this.z).contains(motionEvent.getX(), motionEvent.getY());
    }

    private void b(Canvas canvas) {
        canvas.drawLine(this.m, this.n, this.t, this.u, this.h);
    }

    private boolean b(MotionEvent motionEvent) {
        return !this.C && new RectF(this.t - this.z, this.u - this.z, this.t + this.z, this.u + this.z).contains(motionEvent.getX(), motionEvent.getY());
    }

    private void c(Canvas canvas) {
        this.q = this.p;
        canvas.drawLine(this.m, this.n, this.q, this.r, this.o);
    }

    private void d(Canvas canvas) {
        if (this.drawable != null) {
            this.drawable.setBounds((int) (this.m - (this.z / 2.0f)), (int) (this.n - (this.z / 2.0f)), (int) (this.m + (this.z / 2.0f)), (int) (this.n + (this.z / 2.0f)));
            this.drawable.draw(canvas);
        }
    }

    private void e(Canvas canvas) {
        if (this.B != null) {
            this.B.setBounds((int) (this.t - (this.z / 2.0f)), (int) (this.u - (this.z / 2.0f)), (int) (this.t + (this.z / 2.0f)), (int) (this.u + (this.z / 2.0f)));
            this.B.draw(canvas);
        }
    }

    public void a() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            invalidate();
        } else {
            postInvalidate();
        }
    }

    public void a(long j, long j2) {
        float f;
        this.y = j;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("j : ");
        stringBuilder.append(j);
        stringBuilder.append("j2 : ");
        stringBuilder.append(j2);
        MusicTag.a("TAG", stringBuilder.toString());
        this.C = false;
        this.m = this.z / 2.0f;
        this.p = this.m;
        if (30000 >= this.y) {
            f = this.e;
        } else {
            float f2 = 0.0f;
            if (j != 0) {
                f2 = ((float) 30000.0f) / ((float) j);
            }
            f = this.e * f2;
        }
        this.v = f;
        this.t = this.m + this.v;
        if (this.f4953g != null) {
            this.f4953g.a(0);
            this.f4953g.b((long) (((this.t - (this.z / 2.0f)) / this.e) * ((float) j)));
        }
        a();
    }

    public int getBarColor() {
        return this.b;
    }

    public void setBarColor(int i) {
        this.b = i;
    }

    public float getBarHeight() {
        return this.c;
    }

    public void setBarHeight(float f) {
        this.c = f;
    }

    public int getBgBarColor() {
        return this.d;
    }

    public void setBgBarColor(int i) {
        this.d = i;
    }

    protected void onDraw(Canvas canvas) {
        this.i.setColor(this.d);
        this.h.setShader(new LinearGradient(0.0f, 0.0f, 30.0f, -110.0f, new int[]{getResources().getColor(R.color.colorAccent), getResources().getColor(R.color.colorAccent)}, null, TileMode.MIRROR));
        a(canvas);
        b(canvas);
        c(canvas);
        if (!this.C) {
            if (this.a) {
                d(canvas);
                e(canvas);
                return;
            }
            e(canvas);
            d(canvas);
        }
    }

    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        this.w = (MeasureSpec.getSize(i) - getPaddingLeft()) - getPaddingRight();
        this.l = (MeasureSpec.getSize(i2) - getPaddingTop()) - getPaddingBottom();
        this.e = ((float) this.w) - this.z;
        this.n = (float) (this.l / 2);
        this.u = this.n;
        this.s = this.n;
        this.r = this.n;
    }

    @SuppressLint("ClickableViewAccessibility")
    public boolean onTouchEvent(final MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            default: {
                return false;
            }
            case 2: {
                if (k == 1) {
                    Label_0166:
                    {
                        float x;
                        if (motionEvent.getX() <= this.z / 2.0f) {
                            x = this.z / 2.0f;
                        } else {
                            if (t - motionEvent.getX() >= this.v && motionEvent.getX() >= this.z / 2.0f) {
                                this.m = motionEvent.getX();
                                this.t = this.m + this.v;
                                break Label_0166;
                            }
                            if (motionEvent.getX() >= this.t - this.x) {
                                x = this.t - this.x;
                            } else {
                                x = motionEvent.getX();
                            }
                        }
                        this.m = x;
                    }
                    this.p = this.m;
                    if (this.f4953g != null) {
                        this.f4953g.a((long) ((this.m - this.z / 2.0f) / this.e * this.y));
                        this.f4953g.b((long) ((this.t - this.z / 2.0f) / this.e * this.y));
                    }

                    this.a();

                    return true;
                }
                if (this.k == 2) {
                    if (motionEvent.getX() <= this.m + this.x) {
                        this.t = this.m + this.x;
                        this.a = true;
                    } else {
                        Label_0335:
                        {
                            float x2;
                            if (motionEvent.getX() >= this.e + this.z / 2.0f) {
                                x2 = this.e + this.z / 2.0f;
                            } else {
                                if (motionEvent.getX() - this.m >= this.v && motionEvent.getX() <= this.e + this.z / 2.0f) {
                                    this.t = motionEvent.getX();
                                    this.m = this.t - this.v;
                                    break Label_0335;
                                }
                                x2 = motionEvent.getX();
                            }
                            this.t = x2;
                        }
                        this.a = false;
                    }
                    this.p = this.m;
                    if (this.f4953g != null) {
                        this.f4953g.a((long) ((this.m - this.z / 2.0f) / this.e * this.y));
                        this.f4953g.b((long) ((this.t - this.z / 2.0f) / this.e * this.y));
                    }
                    this.a();

                }
                return true;
            }
            case 1: {
                if ((this.k == 1 || this.k == 2) && this.f4953g != null) {
                    this.f4953g.b();
                }
                this.a();
                return false;
            }
            case 0: {
                if (this.a(motionEvent)) {
                    if (!this.a) {
                        this.k = 1;
                    }
                    if (this.f4953g == null) {
                        return true;
                    }
                } else {
                    if (!this.b(motionEvent)) {
                        return false;
                    }
                    this.p = this.m;
                    this.k = 2;
                    if (this.f4953g == null) {
                        return true;
                    }
                }
                f4953g.a();
                return true;
            }

        }


    }

    public void setOnMusicPlayControllerListener(playmusicControllerinterface playmusicControllerinterface) {
        this.f4953g = playmusicControllerinterface;
    }

    public void setPlayProgress(int i) {
        this.p = ((((float) i) / ((float) this.y)) * this.e) + (this.z / 2.0f);
        a();
    }

    public interface playmusicControllerinterface {
        void a();

        void a(long j);

        void b();

        void b(long j);
    }
}
