package com.esc.photoslideshow.libffmpeg;

interface ResponseHandler {
    void onFinish();

    void onStart();
}
