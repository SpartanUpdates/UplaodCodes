package com.kotlinz.puzzlecreator.activity;

import android.os.Bundle;

import com.kotlinz.puzzlecreator.R;

public class AboutUsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        setToolbar("About Us");

    }
}