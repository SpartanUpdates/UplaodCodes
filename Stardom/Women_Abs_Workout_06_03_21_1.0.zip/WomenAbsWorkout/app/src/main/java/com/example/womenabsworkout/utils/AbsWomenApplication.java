package com.example.womenabsworkout.utils;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.StrictMode;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;

import com.example.womenabsworkout.OpenAds.AppOpenManager;
import com.example.womenabsworkout.R;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class AbsWomenApplication extends Application {
    public static AbsWomenApplication absWomenApplication;
    public TextToSpeech textToSpeech;

    AppOpenManager appOpenManager;

    private static Context context;
    private ExecutorService executorService = Executors.newCachedThreadPool();

    public static AbsWomenApplication getInstance() {
        return absWomenApplication;
    }

    public void addEarCorn(int i) {
        try {
            if (this.textToSpeech != null)
            {
                if (i == 1)
                {
                    this.textToSpeech.addEarcon("tick", getApplicationContext().getPackageName(), R.raw.clocktick_trim);
                } else
               {
                    this.textToSpeech.addEarcon("", getApplicationContext().getPackageName());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Boolean isSpeaking() {
        return Boolean.valueOf(this.textToSpeech.isSpeaking());
    }

    public void onCreate() {
        super.onCreate();

        context = getApplicationContext();

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        appOpenManager = new AppOpenManager(AbsWomenApplication.this);
        if (Build.VERSION.SDK_INT >= 24) {
            final StrictMode.VmPolicy.Builder strictModeVmPolicyBuilder = new StrictMode.VmPolicy.Builder();
            strictModeVmPolicyBuilder.detectFileUriExposure();
            StrictMode.setVmPolicy(strictModeVmPolicyBuilder.build());
        }

        absWomenApplication = this;
        new Thread(new Runnable() {
            public void run() {
                AbsWomenApplication absWomenApplication = AbsWomenApplication.this;
                if (absWomenApplication.textToSpeech == null) {
                    absWomenApplication.textToSpeech = new TextToSpeech(AbsWomenApplication.getInstance().getApplicationContext(), new OnInitListener() {
                        public void onInit(int i) {
                            if (i == 0) {
                                try {
                                    if (AbsWomenApplication.this.textToSpeech != null) {
                                        AbsWomenApplication.this.textToSpeech.setLanguage(Locale.US);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    });
                }
            }
        }).start();
    }

    public void playEarCorn(int i) {
        try {
            if (this.textToSpeech != null) {
                String str = "tick";
                String str2 = "";
                if (VERSION.SDK_INT >= 21) {
                    if (i == 1) {
                        this.textToSpeech.playEarcon(str, 0, (Bundle) null, getApplicationContext().getPackageName());
                    } else {
                        this.textToSpeech.playEarcon(str2, 0, (Bundle) null, getApplicationContext().getPackageName());
                    }
                } else if (i == 0) {
                    this.textToSpeech.playEarcon(str, 0, (HashMap) null);
                } else {
                    this.textToSpeech.playEarcon(str2, 0, (HashMap) null);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static final String TAG = AbsWomenApplication.class.getSimpleName();

    public void speak(String str) {
        try {
            if (this.textToSpeech != null) {
                this.textToSpeech.setSpeechRate(1.0f);
                this.textToSpeech.speak(str, 1, (HashMap) null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stop() {
        try {
            if (this.textToSpeech != null) {
                this.textToSpeech.stop();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ExecutorService getExecutorService() {
        return this.executorService;
    }

    public static AbsWomenApplication getApplication() {
        return absWomenApplication;
    }

    public static Context getContext() {
        return context;
    }

}
