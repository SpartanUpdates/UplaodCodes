package com.kotlinz.videoCollage.sticker;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Environment;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;

import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.Transformation;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.kotlinz.videoCollage.GridActivity;
import com.kotlinz.videoCollage.sticker.listener.MultiTouchListener;
import com.kotlinz.videoeditor.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

public class ResizableStickerView extends RelativeLayout implements MultiTouchListener.TouchCallbackListener {
    private static final int SELF_SIZE_DP = 30;
    public static final String TAG = "ResizableStickerView";
    private int alphaProg = 0;
    double angle = 0.0d;
    int baseh;
    int basew;
    int basex;
    int basey;
    private ImageView border_iv;
    private Bitmap btmp = null;
    float cX = 0.0f;
    float cY = 0.0f;
    private double centerX;
    private double centerY;
    private String colorType = "colored";
    private Context context;
    double dAngle = 0.0d;
    private ImageView delete_iv;
    private String drawableId;
    private String field_four;
    private int field_one;
    private String field_two;
    private ImageView flip_iv;
    private String from;
    boolean ft;
    private int he;
    float heightMain;
    private int hueProg;
    private int imgAlpha;
    private int imgColor;
    private boolean isBorderVisible;
    private boolean isColorFilterEnable;
    public boolean isHandleTransparency;
    public boolean isMultiTouchEnabled;
    private boolean isSticker;
    private boolean isWatermark;
    private boolean isdeleteEnable;
    private int leftMargin;
    private TouchEventListener listener;
    String lockStatus;
    private OnTouchListener mTouchListener;
    private OnTouchListener mTouchListener1;
    public ImageView main_iv;
    private int margin;
    int margl;
    int margt;
    double onTouchAngle;
    private OnTouchListener rTouchListener;
    private Uri resUri;
    private ImageView rotate_iv;
    private float rotation;
    private int s;
    private int s2;
    Animation scale;
    private int scaleRotateProg;
    private ImageView scale_iv;
    private double scale_orgHeight;
    private double scale_orgWidth;
    private float scale_orgX;
    private float scale_orgY;
    int screenHeight;
    int screenWidth;
    private String stkr_path;
    double tAngle;
    private float this_orgX;
    private float this_orgY;
    private int topMargin;
    double vAngle;
    private int wi;
    float widthMain;
    private int xRotateProg;
    private int yRotateProg;
    private float yRotation;
    private int zRotateProg;
    Animation zoomInScale;
    Animation zoomOutScale;

    public interface TouchEventListener {
        byte[] getResBytes(Context context, String str);

        void onCenterX(View view);

        void onCenterXY(View view);

        void onCenterY(View view);

        void onDelete();

        void onEdit(View view, Uri uri);

        void onOtherXY(View view);

        void onRotateDown(View view);

        void onRotateMove(View view);

        void onRotateUp(View view);

        void onScaleDown(View view);

        void onScaleMove(View view);

        void onScaleUp(View view);

        void onTouchDown(View view);

        void onTouchMove(View view);

        void onTouchUp(View view);
    }

    public void optimize(float f, float f2) {
    }

    public ResizableStickerView setOnTouchCallbackListener(GridActivity gridActivity) {
        this.listener = gridActivity;
        return this;
    }

    public ResizableStickerView(Context context, String str) {
        super(context);
        String str2 = "";
        this.field_four = str2;
        this.field_one = 0;
        this.field_two = "0,0";
        this.ft = true;
        this.heightMain = 0.0f;
        this.hueProg = 2;
        this.imgAlpha = 100;
        this.imgColor = 0;
        this.isBorderVisible = false;
        this.isColorFilterEnable = false;
        this.isHandleTransparency = true;
        this.isMultiTouchEnabled = true;
        this.isSticker = true;
        this.isdeleteEnable = true;
        this.leftMargin = 0;
        this.listener = null;
        this.lockStatus = "UNLOCKED";
        this.isWatermark = true;
        this.from = "sticker";
        this.mTouchListener = new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                int action = motionEvent.getAction();
                ResizableStickerView resizableStickerView;
                double d;
                ResizableStickerView resizableStickerView2;
                if (action == 0) {
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.this_orgX = resizableStickerView.getX();
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.this_orgY = resizableStickerView.getY();
                    ResizableStickerView.this.scale_orgX = motionEvent.getRawX();
                    ResizableStickerView.this.scale_orgY = motionEvent.getRawY();
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.scale_orgWidth = (double) resizableStickerView.getLayoutParams().width;
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.scale_orgHeight = (double) resizableStickerView.getLayoutParams().height;
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.centerX = (double) ((((View) resizableStickerView.getParent()).getX() + ResizableStickerView.this.getX()) + (((float) ResizableStickerView.this.getWidth()) / 2.0f));
                    action = 0;
                    int identifier = ResizableStickerView.this.getResources().getIdentifier("status_bar_height", "dimen", "android");
                    if (identifier > 0) {
                        action = ResizableStickerView.this.getResources().getDimensionPixelSize(identifier);
                    }
                    d = (double) action;
                    resizableStickerView2 = ResizableStickerView.this;
                    resizableStickerView2.centerY = (((double) (((View) resizableStickerView2.getParent()).getY() + ResizableStickerView.this.getY())) + d) + ((double) (((float) ResizableStickerView.this.getHeight()) / 2.0f));
                } else if (action == 1) {
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.wi = resizableStickerView.getLayoutParams().width;
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.he = resizableStickerView.getLayoutParams().height;
                } else if (action == 2) {
                    double abs = (Math.abs(Math.atan2((double) (motionEvent.getRawY() - ResizableStickerView.this.scale_orgY), (double) (motionEvent.getRawX() - ResizableStickerView.this.scale_orgX)) - Math.atan2(((double) ResizableStickerView.this.scale_orgY) - ResizableStickerView.this.centerY, ((double) ResizableStickerView.this.scale_orgX) - ResizableStickerView.this.centerX)) * 180.0d) / 3.141592653589793d;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("angle_diff: ");
                    stringBuilder.append(abs);
                    Log.v(ResizableStickerView.TAG, stringBuilder.toString());
                    ResizableStickerView resizableStickerView3 = ResizableStickerView.this;
                    d = resizableStickerView3.getLength(resizableStickerView3.centerX, ResizableStickerView.this.centerY, (double) ResizableStickerView.this.scale_orgX, (double) ResizableStickerView.this.scale_orgY);
                    resizableStickerView3 = ResizableStickerView.this;
                    double access$1000 = resizableStickerView3.getLength(resizableStickerView3.centerX, ResizableStickerView.this.centerY, (double) motionEvent.getRawX(), (double) motionEvent.getRawY());
                    resizableStickerView2 = ResizableStickerView.this;
                    int dpToPx = resizableStickerView2.dpToPx(resizableStickerView2.getContext(), 30);
                    LayoutParams layoutParams;
                    if (access$1000 > d && (abs < 25.0d || Math.abs(abs - 180.0d) < 25.0d)) {
                        d = (double) Math.round(Math.max((double) Math.abs(motionEvent.getRawX() - ResizableStickerView.this.scale_orgX), (double) Math.abs(motionEvent.getRawY() - ResizableStickerView.this.scale_orgY)));
                        layoutParams = (LayoutParams) ResizableStickerView.this.getLayoutParams();
                        layoutParams.width = (int) (((double) layoutParams.width) + d);
                        layoutParams = (LayoutParams) ResizableStickerView.this.getLayoutParams();
                        layoutParams.height = (int) (((double) layoutParams.height) + d);
                    } else if (access$1000 < d && (abs < 25.0d || Math.abs(abs - 180.0d) < 25.0d)) {
                        dpToPx /= 2;
                        if (ResizableStickerView.this.getLayoutParams().width > dpToPx && ResizableStickerView.this.getLayoutParams().height > dpToPx) {
                            d = (double) Math.round(Math.max((double) Math.abs(motionEvent.getRawX() - ResizableStickerView.this.scale_orgX), (double) Math.abs(motionEvent.getRawY() - ResizableStickerView.this.scale_orgY)));
                            layoutParams = (LayoutParams) ResizableStickerView.this.getLayoutParams();
                            layoutParams.width = (int) (((double) layoutParams.width) - d);
                            layoutParams = (LayoutParams) ResizableStickerView.this.getLayoutParams();
                            layoutParams.height = (int) (((double) layoutParams.height) - d);
                        }
                    }
                    ResizableStickerView.this.scale_orgX = motionEvent.getRawX();
                    ResizableStickerView.this.scale_orgY = motionEvent.getRawY();
                    ResizableStickerView.this.postInvalidate();
                    ResizableStickerView.this.requestLayout();
                }
                return true;
            }
        };
        this.mTouchListener1 = new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                ResizableStickerView resizableStickerView = (ResizableStickerView) view.getParent();
                ResizableStickerView.this.setBorderVisibility(true);
                int rawX = (int) motionEvent.getRawX();
                int rawY = (int) motionEvent.getRawY();
                LayoutParams layoutParams = (LayoutParams) ResizableStickerView.this.getLayoutParams();
                int action = motionEvent.getAction();
                if (action == 0) {
                    if (resizableStickerView != null) {
                        resizableStickerView.requestDisallowInterceptTouchEvent(true);
                    }
                    if (ResizableStickerView.this.listener != null) {
                        ResizableStickerView.this.listener.onScaleDown(ResizableStickerView.this);
                    }
                    ResizableStickerView.this.invalidate();
                    ResizableStickerView.this.basex = rawX;
                    ResizableStickerView.this.basey = rawY;
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.basew = resizableStickerView.getWidth();
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.baseh = resizableStickerView.getHeight();
                    ResizableStickerView.this.getLocationOnScreen(new int[2]);
                    ResizableStickerView.this.margl = layoutParams.leftMargin;
                    ResizableStickerView.this.margt = layoutParams.topMargin;
                } else if (action == 1) {
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.wi = resizableStickerView.getLayoutParams().width;
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.he = resizableStickerView.getLayoutParams().height;
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.leftMargin = ((LayoutParams) resizableStickerView.getLayoutParams()).leftMargin;
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.topMargin = ((LayoutParams) resizableStickerView.getLayoutParams()).topMargin;
                    resizableStickerView = ResizableStickerView.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(String.valueOf(ResizableStickerView.this.leftMargin));
                    stringBuilder.append(",");
                    stringBuilder.append(String.valueOf(ResizableStickerView.this.topMargin));
                    resizableStickerView.field_two = stringBuilder.toString();
                    if (ResizableStickerView.this.listener != null) {
                        ResizableStickerView.this.listener.onScaleUp(ResizableStickerView.this);
                    }
                } else if (action == 2) {
                    if (resizableStickerView != null) {
                        resizableStickerView.requestDisallowInterceptTouchEvent(true);
                    }
                    if (ResizableStickerView.this.listener != null) {
                        ResizableStickerView.this.listener.onScaleMove(ResizableStickerView.this);
                    }
                    float toDegrees = (float) Math.toDegrees(Math.atan2((double) (rawY - ResizableStickerView.this.basey), (double) (rawX - ResizableStickerView.this.basex)));
                    if (toDegrees < 0.0f) {
                        toDegrees += 360.0f;
                    }
                    rawX -= ResizableStickerView.this.basex;
                    rawY -= ResizableStickerView.this.basey;
                    rawY *= rawY;
                    action = (int) (Math.sqrt((double) ((rawX * rawX) + rawY)) * Math.cos(Math.toRadians((double) (toDegrees - ResizableStickerView.this.getRotation()))));
                    int sqrt = (int) (Math.sqrt((double) ((action * action) + rawY)) * Math.sin(Math.toRadians((double) (toDegrees - ResizableStickerView.this.getRotation()))));
                    rawX = (action * 2) + ResizableStickerView.this.basew;
                    rawY = (sqrt * 2) + ResizableStickerView.this.baseh;
                    if (rawX > ResizableStickerView.this.s2) {
                        layoutParams.width = rawX;
                        layoutParams.leftMargin = ResizableStickerView.this.margl - action;
                    }
                    if (rawY > ResizableStickerView.this.s2) {
                        layoutParams.height = rawY;
                        layoutParams.topMargin = ResizableStickerView.this.margt - sqrt;
                    }
                    ResizableStickerView.this.setLayoutParams(layoutParams);
                    ResizableStickerView.this.performLongClick();
                }
                return true;
            }
        };
        this.onTouchAngle = 0.0d;
        this.rTouchListener = new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                ResizableStickerView resizableStickerView = (ResizableStickerView) view.getParent();
                ResizableStickerView.this.setBorderVisibility(true);
                int action = motionEvent.getAction();
                if (action == 0) {
                    if (resizableStickerView != null) {
                        resizableStickerView.requestDisallowInterceptTouchEvent(true);
                    }
                    if (ResizableStickerView.this.listener != null) {
                        ResizableStickerView.this.listener.onRotateDown(ResizableStickerView.this);
                    }
                    Rect rect = new Rect();
                    ((View) view.getParent()).getGlobalVisibleRect(rect);
                    ResizableStickerView.this.cX = rect.exactCenterX();
                    ResizableStickerView.this.cY = rect.exactCenterY();
                    ResizableStickerView.this.vAngle = (double) ((View) view.getParent()).getRotation();
                    ResizableStickerView resizableStickerView2 = ResizableStickerView.this;
                    resizableStickerView2.tAngle = (Math.atan2((double) (resizableStickerView2.cY - motionEvent.getRawY()), (double) (ResizableStickerView.this.cX - motionEvent.getRawX())) * 180.0d) / 3.141592653589793d;
                    resizableStickerView2 = ResizableStickerView.this;
                    resizableStickerView2.dAngle = resizableStickerView2.vAngle - ResizableStickerView.this.tAngle;
                } else if (action != 1) {
                    if (action == 2) {
                        if (resizableStickerView != null) {
                            resizableStickerView.requestDisallowInterceptTouchEvent(true);
                        }
                        if (ResizableStickerView.this.listener != null) {
                            ResizableStickerView.this.listener.onRotateMove(ResizableStickerView.this);
                        }
                        resizableStickerView = ResizableStickerView.this;
                        resizableStickerView.angle = (Math.atan2((double) (resizableStickerView.cY - motionEvent.getRawY()), (double) (ResizableStickerView.this.cX - motionEvent.getRawX())) * 180.0d) / 3.141592653589793d;
                        float f = (float) (ResizableStickerView.this.angle + ResizableStickerView.this.dAngle);
                        ((View) view.getParent()).setRotation(f);
                        ((View) view.getParent()).invalidate();
                        ((View) view.getParent()).requestLayout();
                        if (Math.abs(90.0f - Math.abs(f)) <= 5.0f) {
                            f = f > 0.0f ? 90.0f : -90.0f;
                        }
                        if (Math.abs(0.0f - Math.abs(f)) <= 5.0f) {
                            f = f > 0.0f ? 0.0f : -0.0f;
                        }
                        if (Math.abs(180.0f - Math.abs(f)) <= 5.0f) {
                            f = f > 0.0f ? 180.0f : -180.0f;
                        }
                        ((View) view.getParent()).setRotation(f);
                    }
                } else if (ResizableStickerView.this.listener != null) {
                    ResizableStickerView.this.listener.onRotateUp(ResizableStickerView.this);
                }
                return true;
            }
        };
        this.resUri = null;
        this.scaleRotateProg = 0;
        this.scale_orgHeight = -1.0d;
        this.scale_orgWidth = -1.0d;
        this.scale_orgX = -1.0f;
        this.scale_orgY = -1.0f;
        this.screenHeight = 300;
        this.screenWidth = 300;
        this.stkr_path = str2;
        this.tAngle = 0.0d;
        this.this_orgX = -1.0f;
        this.this_orgY = -1.0f;
        this.topMargin = 0;
        this.vAngle = 0.0d;
        this.widthMain = 0.0f;
        this.xRotateProg = 0;
        this.yRotateProg = 0;
        this.yRotation = 0.0f;
        this.zRotateProg = 0;
        this.from = str;
        init(context);
    }

    public ResizableStickerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        String str = "";
        this.field_four = str;
        this.field_one = 0;
        this.field_two = "0,0";
        this.ft = true;
        this.heightMain = 0.0f;
        this.hueProg = 2;
        this.imgAlpha = 100;
        this.imgColor = 0;
        this.isBorderVisible = false;
        this.isColorFilterEnable = false;
        this.isHandleTransparency = true;
        this.isMultiTouchEnabled = true;
        this.isSticker = true;
        this.isdeleteEnable = true;
        this.leftMargin = 0;
        this.listener = null;
        this.lockStatus = "UNLOCKED";
        this.isWatermark = true;
        this.from = "sticker";
        this.onTouchAngle = 0.0d;
        this.resUri = null;
        this.scaleRotateProg = 0;
        this.scale_orgHeight = -1.0d;
        this.scale_orgWidth = -1.0d;
        this.scale_orgX = -1.0f;
        this.scale_orgY = -1.0f;
        this.screenHeight = 300;
        this.screenWidth = 300;
        this.stkr_path = str;
        this.tAngle = 0.0d;
        this.this_orgX = -1.0f;
        this.this_orgY = -1.0f;
        this.topMargin = 0;
        this.vAngle = 0.0d;
        this.widthMain = 0.0f;
        this.xRotateProg = 0;
        this.yRotateProg = 0;
        this.yRotation = 0.0f;
        this.zRotateProg = 0;
        init(context);
    }

    public ResizableStickerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        String str = "";
        this.field_four = str;
        this.field_one = 0;
        this.field_two = "0,0";
        this.ft = true;
        this.heightMain = 0.0f;
        this.hueProg = 2;
        this.imgAlpha = 100;
        this.imgColor = 0;
        this.isBorderVisible = false;
        this.isColorFilterEnable = false;
        this.isHandleTransparency = true;
        this.isMultiTouchEnabled = true;
        this.isSticker = true;
        this.isdeleteEnable = true;
        this.leftMargin = 0;
        this.listener = null;
        this.lockStatus = "UNLOCKED";
        this.isWatermark = true;
        this.from = "sticker";
        this.onTouchAngle = 0.0d;
        this.resUri = null;
        this.scaleRotateProg = 0;
        this.scale_orgHeight = -1.0d;
        this.scale_orgWidth = -1.0d;
        this.scale_orgX = -1.0f;
        this.scale_orgY = -1.0f;
        this.screenHeight = 300;
        this.screenWidth = 300;
        this.stkr_path = str;
        this.tAngle = 0.0d;
        this.this_orgX = -1.0f;
        this.this_orgY = -1.0f;
        this.topMargin = 0;
        this.vAngle = 0.0d;
        this.widthMain = 0.0f;
        this.xRotateProg = 0;
        this.yRotateProg = 0;
        this.yRotation = 0.0f;
        this.zRotateProg = 0;
        init(context);
    }

    public void init(Context context) {
        this.context = context;
        this.main_iv = new ImageView(this.context);
        this.scale_iv = new ImageView(this.context);
        this.border_iv = new ImageView(this.context);
        this.flip_iv = new ImageView(this.context);
        this.rotate_iv = new ImageView(this.context);
        this.delete_iv = new ImageView(this.context);
        this.margin = dpToPx(this.context, 5);
        this.s = dpToPx(this.context, 25);
        this.s2 = dpToPx(this.context, 55);
        this.wi = dpToPx(this.context, Callback.DEFAULT_DRAG_ANIMATION_DURATION);
        this.he = dpToPx(this.context, Callback.DEFAULT_DRAG_ANIMATION_DURATION);
        this.border_iv.setImageResource(R.drawable.sticker_border_gray_bg);
        this.scale_iv.setImageDrawable(DrawableCompat.wrap(AppCompatResources.getDrawable(this.context, R.drawable.ic_sticker_resize_selector)));
        this.flip_iv.setImageDrawable(DrawableCompat.wrap(AppCompatResources.getDrawable(this.context, R.drawable.ic_sticker_flip_selector)));
        this.rotate_iv.setImageDrawable(DrawableCompat.wrap(AppCompatResources.getDrawable(this.context, R.drawable.ic_sticker_rotate_selector)));
        this.delete_iv.setImageDrawable(DrawableCompat.wrap(AppCompatResources.getDrawable(this.context, R.drawable.ic_sticker_delete_selector)));
        if (this.from.equalsIgnoreCase("watermark")) {
            this.flip_iv.setVisibility(GONE);
            this.rotate_iv.setVisibility(GONE);
        } else {
            this.flip_iv.setVisibility(VISIBLE);
            this.rotate_iv.setVisibility(VISIBLE);
        }
        LayoutParams layoutParams = new LayoutParams(this.wi, this.he);
        LayoutParams layoutParams2 = new LayoutParams(-1, -1);
        int i = this.s;
        layoutParams2.setMargins(i, i, i, i);
        layoutParams2.addRule(17);
        int i2 = this.s;
        LayoutParams layoutParams3 = new LayoutParams(i2, i2);
        layoutParams3.addRule(12);
        layoutParams3.addRule(11);
        int i3 = this.margin;
        layoutParams3.setMargins(i3, i3, i3, i3);
        int i4 = this.s;
        LayoutParams layoutParams4 = new LayoutParams(i4, i4);
        layoutParams4.addRule(10);
        layoutParams4.addRule(11);
        int i5 = this.margin;
        layoutParams4.setMargins(i5, i5, i5, i5);
        int i6 = this.s;
        LayoutParams layoutParams5 = new LayoutParams(i6, i6);
        layoutParams5.addRule(12);
        layoutParams5.addRule(9);
        i6 = this.margin;
        layoutParams5.setMargins(i6, i6, i6, i6);
        int i7 = this.s;
        LayoutParams layoutParams6 = new LayoutParams(i7, i7);
        layoutParams6.addRule(10);
        layoutParams6.addRule(9);
        i2 = this.margin;
        layoutParams6.setMargins(i2, i2, i2, i2);
        LayoutParams layoutParams7 = new LayoutParams(-1, -1);
        setLayoutParams(layoutParams);
        setBackgroundResource(R.drawable.sticker_border_gray_bg);
        addView(this.border_iv);
        this.border_iv.setLayoutParams(layoutParams7);
        this.border_iv.setScaleType(ScaleType.FIT_XY);
        this.border_iv.setTag("border_iv");
        addView(this.main_iv);
        this.main_iv.setLayoutParams(layoutParams2);
        addView(this.flip_iv);
        this.flip_iv.setLayoutParams(layoutParams4);
        this.flip_iv.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (((double) ResizableStickerView.this.yRotation) == 0.0d) {
                    ResizableStickerView.this.yRotation = 1.0f;
                } else {
                    ResizableStickerView.this.yRotation = 0.0f;
                }
                ResizableStickerView resizableStickerView;
                if (!ResizableStickerView.this.stkr_path.equals("")) {
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.setStrPath(resizableStickerView.stkr_path, false);
                } else if (ResizableStickerView.this.drawableId.equals("0")) {
                    ResizableStickerView.this.addStkrBitmap(false);
                } else {
                    resizableStickerView = ResizableStickerView.this;
                    resizableStickerView.setBgDrawable(resizableStickerView.drawableId, false);
                }
            }
        });
        addView(this.rotate_iv);
        this.rotate_iv.setLayoutParams(layoutParams5);
        this.rotate_iv.setOnTouchListener(this.rTouchListener);
        addView(this.delete_iv);
        this.delete_iv.setLayoutParams(layoutParams6);
        this.delete_iv.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                final ViewGroup viewGroup = (ViewGroup) ResizableStickerView.this.getParent();
                ResizableStickerView.this.zoomInScale.setAnimationListener(new AnimationListener() {
                    public void onAnimationRepeat(Animation animation) {
                    }

                    public void onAnimationStart(Animation animation) {
                    }

                    public void onAnimationEnd(Animation animation) {
                        viewGroup.removeView(ResizableStickerView.this);
                    }
                });
                ResizableStickerView.this.main_iv.startAnimation(ResizableStickerView.this.zoomInScale);
                ResizableStickerView.this.setBorderVisibility(false);
                if (ResizableStickerView.this.listener != null) {
                    ResizableStickerView.this.listener.onDelete();
                }
            }
        });
        addView(this.scale_iv);
        this.scale_iv.setLayoutParams(layoutParams3);
        this.scale_iv.setOnTouchListener(this.mTouchListener1);
        this.scale_iv.setTag("scale_iv");
        this.rotation = getRotation();
        this.scale = AnimationUtils.loadAnimation(getContext(), R.anim.sticker_scale_anim);
        this.zoomOutScale = AnimationUtils.loadAnimation(getContext(), R.anim.sticker_scale_zoom_out);
        this.zoomInScale = AnimationUtils.loadAnimation(getContext(), R.anim.sticker_scale_zoom_in);
        this.isMultiTouchEnabled = setDefaultTouchListener(true);
    }

    public boolean setDefaultTouchListener(boolean z) {
        if (z) {
            this.lockStatus = "UNLOCKED";
            setOnTouchListener(new MultiTouchListener(this.context).enableRotation(true).enableTransparencyCheck(this.isHandleTransparency).setOnTouchCallbackListener(this));
            return true;
        }
        this.lockStatus = "LOCKED";
        setOnTouchListener(null);
        return false;
    }

    public void setWatermarkVisibility(boolean z) {
        this.isWatermark = z;
    }

    public boolean getWatermarkVisibility() {
        return this.isWatermark;
    }

    public void setBorderVisibility(boolean z) {
        this.isBorderVisible = z;
        if (!z) {
            this.border_iv.setVisibility(GONE);
            this.scale_iv.setVisibility(GONE);
            this.flip_iv.setVisibility(GONE);
            this.rotate_iv.setVisibility(GONE);
            this.delete_iv.setVisibility(GONE);
            setBackgroundResource(0);
            if (this.isColorFilterEnable) {
                this.main_iv.setColorFilter(Color.parseColor("#303828"));
            }
        } else if (this.border_iv.getVisibility() != VISIBLE) {
            this.border_iv.setVisibility(VISIBLE);
            this.scale_iv.setVisibility(VISIBLE);
            if (this.isWatermark) {
                this.flip_iv.setVisibility(GONE);
                this.rotate_iv.setVisibility(GONE);
            } else {
                this.flip_iv.setVisibility(VISIBLE);
                this.rotate_iv.setVisibility(VISIBLE);
            }
            if (this.isdeleteEnable) {
                this.delete_iv.setVisibility(VISIBLE);
            }
            setBackgroundResource(R.drawable.textlib_border_gray);
            this.main_iv.startAnimation(this.scale);
        }
    }

    public boolean getBorderVisbilty() {
        return this.isBorderVisible;
    }

    public void opecitySticker(int i) {
        try {
            this.main_iv.setAlpha(((float) i) / 100.0f);
            this.imgAlpha = i;
        } catch (Exception unused) {
        }
    }

    public int getHueProg() {
        return this.hueProg;
    }

    public void setHueProg(int i) {
        this.hueProg = i;
        if (i < 1 || i > 5) {
            this.main_iv.setColorFilter(ColorFilterGenerator.adjustHue((float) i, "watermark"));
        } else {
            this.main_iv.setColorFilter(0);
        }
    }

    public void setHueProgW(int i) {
        this.hueProg = i;
        this.main_iv.setColorFilter(ColorFilterGenerator.adjustHue((float) i, "watermark"));
    }

    public int getXRotateProg() {
        return this.xRotateProg;
    }

    public int getYRotateProg() {
        return this.yRotateProg;
    }

    public int getZRotateProg() {
        return this.zRotateProg;
    }

    public int geScaleProg() {
        return this.scaleRotateProg;
    }

    public void setStickerRotateProg(int i, int i2, int i3, int i4, int i5, int i6) {
        this.xRotateProg = i4;
        this.yRotateProg = i5;
        this.zRotateProg = i6;
        applyTransformation(i, i2, i3);
    }

    public void setScaleViewProg(int i) {
        this.scaleRotateProg = i;
        float f = ((float) i) / 10.0f;
        this.main_iv.setScaleX(f);
        this.main_iv.setScaleY(f);
    }

    public String getColorType() {
        return this.colorType;
    }

    public void setColorType(String str) {
        this.colorType = str;
    }

    public int getAlphaProg() {
        return this.alphaProg;
    }

    public void setAlphaProg(int i) {
        this.alphaProg = i;
        this.main_iv.setAlpha(((float) i) / 100.0f);
    }

    public int getColor() {
        return this.imgColor;
    }

    public void setColor(int i) {
        try {
            this.main_iv.setColorFilter(i);
            this.imgColor = i;
        } catch (Exception unused) {
        }
    }

    public void setBgDrawable(String str, boolean z) {
        this.drawableId = str;
        addStkrBitmap(z);
    }

    public void setStrPath(String str, boolean z) {
        Uri parse = Uri.parse(str);
        if (this.yRotation != 0.0f) {
            ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load(parse.toString()).diskCacheStrategy(DiskCacheStrategy.NONE)).dontAnimate()).override(dpToPx(this.context, 300), dpToPx(this.context, 300))).transform((Transformation) new MyTransformation(this.context, true))).into(this.main_iv);
        } else {
            ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load(parse.toString()).diskCacheStrategy(DiskCacheStrategy.NONE)).dontAnimate()).override(dpToPx(this.context, 300), dpToPx(this.context, 300))).into(this.main_iv);
        }
        this.stkr_path = str;
        if (z) {
            this.main_iv.startAnimation(this.zoomOutScale);
        }
    }

    public void applyTransformation(int i, int i2, int i3) {
        this.main_iv.setRotationX((float) i);
        this.main_iv.setRotationY((float) i2);
        this.main_iv.setRotation((float) i3);
        setVisibility(VISIBLE);
        this.main_iv.setVisibility(VISIBLE);
        this.main_iv.requestLayout();
        this.main_iv.postInvalidate();
        requestLayout();
        postInvalidate();
    }

    public void setComponentInfo(ComponentInfo componentInfo) {
        this.wi = componentInfo.getWIDTH();
        this.he = componentInfo.getHEIGHT();
        this.drawableId = componentInfo.getRES_ID();
        this.resUri = componentInfo.getRES_URI();
        this.btmp = componentInfo.getBITMAP();
        this.rotation = componentInfo.getROTATION();
        this.imgColor = componentInfo.getSTC_COLOR();
        this.yRotation = componentInfo.getY_ROTATION();
        this.alphaProg = componentInfo.getSTC_OPACITY();
        this.stkr_path = componentInfo.getSTKR_PATH();
        this.colorType = componentInfo.getCOLORTYPE();
        this.hueProg = componentInfo.getSTC_HUE();
        this.lockStatus = componentInfo.getFIELD_THREE();
        this.field_two = componentInfo.getFIELD_TWO();
        this.xRotateProg = componentInfo.getXRotateProg();
        this.yRotateProg = componentInfo.getYRotateProg();
        this.zRotateProg = componentInfo.getZRotateProg();
        this.scaleRotateProg = componentInfo.getScaleProg();
        applyTransformation(45 - this.xRotateProg, 45 - this.yRotateProg, 180 - this.zRotateProg);
        String str = "";
        if (!this.stkr_path.equals(str)) {
            setStrPath(this.stkr_path, true);
        } else if (this.drawableId.equals("0")) {
            addStkrBitmap(true);
        } else {
            setBgDrawable(this.drawableId, true);
        }
        if (this.colorType.equals("white")) {
            setColor(this.imgColor);
        } else {
            setHueProg(this.hueProg);
        }
        setRotation(this.rotation);
        setScaleViewProg(this.scaleRotateProg);
        setAlphaProg(this.alphaProg);
        if (this.field_two.equals(str)) {
            getLayoutParams().width = this.wi;
            getLayoutParams().height = this.he;
            setX(componentInfo.getPOS_X());
            setY(componentInfo.getPOS_Y());
        } else {
            String[] split = this.field_two.split(",");
            int parseInt = Integer.parseInt(split[0]);
            int parseInt2 = Integer.parseInt(split[1]);
            ((LayoutParams) getLayoutParams()).leftMargin = parseInt;
            ((LayoutParams) getLayoutParams()).topMargin = parseInt2;
            getLayoutParams().width = this.wi;
            getLayoutParams().height = this.he;
            setX(componentInfo.getPOS_X() + ((float) (parseInt * -1)));
            setY(componentInfo.getPOS_Y() + ((float) (parseInt2 * -1)));
        }
        if (componentInfo.getTYPE() == "SHAPE") {
            this.flip_iv.setVisibility(GONE);
            this.isSticker = false;
        }
        if (componentInfo.getTYPE() == "STICKER") {
            this.flip_iv.setVisibility(VISIBLE);
            this.isSticker = true;
        }
        if (componentInfo.getTYPE() == "WATERMARK") {
            this.flip_iv.setVisibility(VISIBLE);
            this.delete_iv.setVisibility(GONE);
            this.isSticker = true;
            this.isdeleteEnable = false;
            this.isHandleTransparency = false;
        }
        if (this.lockStatus.equals("LOCKED")) {
            this.isMultiTouchEnabled = setDefaultTouchListener(false);
        } else {
            this.isMultiTouchEnabled = setDefaultTouchListener(true);
        }
    }

    public void addStkrBitmap(boolean z) {
        if (this.drawableId.equals("0")) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            this.btmp.compress(CompressFormat.PNG, 100, byteArrayOutputStream);
            if (this.yRotation != 0.0f) {
                ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).asBitmap().load(byteArrayOutputStream.toByteArray()).override(dpToPx(this.context, 300), dpToPx(this.context, 300))).transform((Transformation) new MyTransformation(this.context, true))).into(this.main_iv);
            } else {
                ((RequestBuilder) Glide.with(this.context).asBitmap().load(byteArrayOutputStream.toByteArray()).override(dpToPx(this.context, 300), dpToPx(this.context, 300))).into(this.main_iv);
            }
        } else {
            getResources().getIdentifier(this.drawableId, "drawable", this.context.getPackageName());
            TouchEventListener touchEventListener = this.listener;
            if (touchEventListener != null) {
                byte[] resBytes = touchEventListener.getResBytes(this.context, this.drawableId);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("yRotation ");
                stringBuilder.append(this.yRotation);
                String str = "in_resizeable_value";
                Log.e(str, stringBuilder.toString());
                if (this.yRotation != 0.0f) {
                    ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load(resBytes).dontAnimate()).override(dpToPx(this.context, 300), dpToPx(this.context, 300))).transform((Transformation) new MyTransformation(this.context, true))).into(this.main_iv);
                } else {
                    Log.e(str, "else");
                    ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load(resBytes).dontAnimate()).override(dpToPx(this.context, 300), dpToPx(this.context, 300))).into(this.main_iv);
                }
            }
        }
        if (z) {
            this.main_iv.startAnimation(this.zoomOutScale);
        }
    }

    public void optimizeScreen(float f, float f2) {
        this.screenHeight = (int) f2;
        this.screenWidth = (int) f;
    }

    public void setMainLayoutWH(float f, float f2) {
        this.widthMain = f;
        this.heightMain = f2;
    }

    public float getMainWidth() {
        return this.widthMain;
    }

    public float getMainHeight() {
        return this.heightMain;
    }

    public void incrX() {
        setX(getX() + 1.0f);
    }

    public void decX() {
        setX(getX() - 1.0f);
    }

    public void incrY() {
        setY(getY() + 1.0f);
    }

    public void decY() {
        setY(getY() - 1.0f);
    }

    public ComponentInfo getComponentInfo() {
        Bitmap bitmap = this.btmp;
        if (bitmap != null) {
            this.stkr_path = saveBitmapObject1(bitmap);
        }
        ComponentInfo componentInfo = new ComponentInfo();
        componentInfo.setPOS_X(getX());
        componentInfo.setPOS_Y(getY());
        componentInfo.setWIDTH(this.wi);
        componentInfo.setHEIGHT(this.he);
        componentInfo.setRES_ID(this.drawableId);
        componentInfo.setSTC_COLOR(this.imgColor);
        componentInfo.setRES_URI(this.resUri);
        componentInfo.setSTC_OPACITY(this.alphaProg);
        componentInfo.setCOLORTYPE(this.colorType);
        componentInfo.setBITMAP(this.btmp);
        componentInfo.setROTATION(getRotation());
        componentInfo.setY_ROTATION(this.yRotation);
        componentInfo.setXRotateProg(this.xRotateProg);
        componentInfo.setYRotateProg(this.yRotateProg);
        componentInfo.setZRotateProg(this.zRotateProg);
        componentInfo.setScaleProg(this.scaleRotateProg);
        componentInfo.setSTKR_PATH(this.stkr_path);
        componentInfo.setSTC_HUE(this.hueProg);
        componentInfo.setFIELD_ONE(this.field_one);
        componentInfo.setFIELD_TWO(this.field_two);
        componentInfo.setFIELD_THREE(this.lockStatus);
        componentInfo.setFIELD_FOUR(this.field_four);
        return componentInfo;
    }

    private String saveBitmapObject1(Bitmap bitmap) {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), ".Dynamo Stickers/category1");
        file.mkdirs();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("raw1-");
        stringBuilder.append(System.currentTimeMillis());
        stringBuilder.append(".png");
        File file2 = new File(file, stringBuilder.toString());
        String absolutePath = file2.getAbsolutePath();
        if (file2.exists()) {
            file2.delete();
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            bitmap.compress(CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.close();
            return absolutePath;
        } catch (Exception e) {
            e.printStackTrace();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Exception");
            stringBuilder2.append(e.getMessage());
            Log.i("testing", stringBuilder2.toString());
            return "";
        }
    }

    public int dpToPx(Context context, int i) {
        float f = (float) i;
        context.getResources();
        return (int) (f * Resources.getSystem().getDisplayMetrics().density);
    }

    private double getLength(double d, double d2, double d3, double d4) {
        return Math.sqrt(Math.pow(d4 - d2, 2.0d) + Math.pow(d3 - d, 2.0d));
    }

    public void enableColorFilter(boolean z) {
        this.isColorFilterEnable = z;
    }

    public void onTouchCallback(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchDown(view);
        }
    }

    public void onTouchUpCallback(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchUp(view);
        }
    }

    public void onTouchMoveCallback(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchMove(view);
        }
    }

    public void onCenterPosX(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onCenterX(view);
        }
    }

    public void onCenterPosY(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onCenterY(view);
        }
    }

    public void onCenterPosXY(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onCenterXY(view);
        }
    }

    public void onOtherPos(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onOtherXY(view);
        }
    }
}
