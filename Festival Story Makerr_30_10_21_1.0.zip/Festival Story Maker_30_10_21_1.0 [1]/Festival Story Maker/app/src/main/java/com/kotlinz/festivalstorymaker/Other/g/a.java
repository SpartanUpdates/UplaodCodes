package com.kotlinz.festivalstorymaker.Other.g;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Other.Utils;

import java.util.Map;

public class a {
    public c a;
    public Activity b;
    public Utils c;

    private RequestQueue mRequestQueue;
    private StringRequest mStringRequest;

    public a(final Activity b, final c a) {
        this.a = a;
        this.b = b;
        (this.c = new Utils(b)).c(b.getResources().getString(R.string.loading));
    }

    public void a(final int n, final String s, final Map<String, String> map, final int n2) {
        mRequestQueue = Volley.newRequestQueue((Context)this.b);
        mStringRequest = new StringRequest(n, s, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                final String s = (String)response;
                com.kotlinz.festivalstorymaker.Other.g.a.this.a.z(n2, s);
                final a b = com.kotlinz.festivalstorymaker.Other.g.a.this;
                b.c.v(b.b);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                final a b = com.kotlinz.festivalstorymaker.Other.g.a.this;
                b.c.v(b.b);
                final boolean b2 = error instanceof VolleyError;
                final String s = "Cannot connect to Internet...Please check your connection!";
                String s2;
                if (b2) {
                    s2 = s;
                }
                else if (error instanceof VolleyError) {
                    s2 = "The server could not be found. Please try again after some time!!";
                }
                else if (error instanceof VolleyError) {
                    s2 = s;
                }
                else if (error instanceof VolleyError) {
                    s2 = s;
                }
                else if (error instanceof VolleyError) {
                    s2 = "Connection TimeOut! Please check your internet connection.";
                }
                else {
                    s2 = "";
                }
                com.kotlinz.festivalstorymaker.Other.g.a.this.a.L(n2, s2);
            }

        });

        mRequestQueue.add(mStringRequest);
    }

    public void b(final int n, final String s, final Map<String, String> map, final int n2) {

        mRequestQueue = Volley.newRequestQueue((Context)this.b);
        mStringRequest = new StringRequest(n, s, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                final String s = (String)response;
                Log.d("------ response: ", s);
                com.kotlinz.festivalstorymaker.Other.g.a.this.a.z(n2, s);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                final a b = com.kotlinz.festivalstorymaker.Other.g.a.this;
                b.c.v(b.b);
                final boolean b2 = error instanceof VolleyError;
                final String s = "Cannot connect to Internet...Please check your connection!";
                String s2;
                if (b2) {
                    s2 = s;
                }
                else if (error instanceof VolleyError) {
                    s2 = "The server could not be found. Please try again after some time!!";
                }
                else if (error instanceof VolleyError) {
                    s2 = s;
                }
                else if (error instanceof VolleyError) {
                    s2 = s;
                }
                else if (error instanceof VolleyError) {
                    s2 = "Connection TimeOut! Please check your internet connection.";
                }
                else {
                    s2 = "";
                }
                com.kotlinz.festivalstorymaker.Other.g.a.this.a.L(n2, s2);
            }

        });

        mRequestQueue.add(mStringRequest);
    }
}
