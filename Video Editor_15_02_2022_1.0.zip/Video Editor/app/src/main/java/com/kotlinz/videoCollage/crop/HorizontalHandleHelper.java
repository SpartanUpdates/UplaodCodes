package com.kotlinz.videoCollage.crop;

import android.graphics.Rect;

public class HorizontalHandleHelper extends HandleHelper {
    private Edge mEdge;

    HorizontalHandleHelper(Edge edge) {
        super(edge, null);
        this.mEdge = edge;
    }

    public void updateCropWindow(float f, float f2, float f3, Rect rect, float f4) {
        this.mEdge.adjustCoordinate(f, f2, rect, f4, f3);
        f = Edge.LEFT.getCoordinate();
        f2 = Edge.TOP.getCoordinate();
        float coordinate = Edge.RIGHT.getCoordinate();
        f2 = (AspectRatioUtil.calculateWidth(f2, Edge.BOTTOM.getCoordinate(), f3) - (coordinate - f)) / 2.0f;
        coordinate += f2;
        Edge.LEFT.setCoordinate(f - f2);
        Edge.RIGHT.setCoordinate(coordinate);
        if (Edge.LEFT.isOutsideMargin(rect, f4) && !this.mEdge.isNewRectangleOutOfBounds(Edge.LEFT, rect, f3)) {
            Edge.RIGHT.offset(-Edge.LEFT.snapToRect(rect));
            this.mEdge.adjustCoordinate(f3);
        }
        if (Edge.RIGHT.isOutsideMargin(rect, f4) && !this.mEdge.isNewRectangleOutOfBounds(Edge.RIGHT, rect, f3)) {
            Edge.LEFT.offset(-Edge.RIGHT.snapToRect(rect));
            this.mEdge.adjustCoordinate(f3);
        }
    }
}
