package com.unitedvideosapp.photovideomaker.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.Toolbar.OnMenuItemClickListener;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.unitedvideosapp.photovideomaker.activity.ActivityVideoAlbum;
import com.unitedvideosapp.photovideomaker.activity.videoPlay;
import com.unitedvideosapp.photovideomaker.kprogresshud.KProgressHUD;
import com.unitedvideosapp.photovideomaker.modelclass.VideoData;
import com.unitedvideosapp.photovideomaker.util.ActivityAnimUtil;
import com.unitedvideosapp.photovideomaker.video.FileUtils;
import com.uvvideos.photo.video.slideshow.maker.R;

import java.io.File;
import java.util.ArrayList;

public class AllVideoAlbumAdapter extends Adapter<AllVideoAlbumAdapter.Holder> {
    public static ArrayList<VideoData> mVideoDatas;
    ActivityVideoAlbum activity;
    private Context mContext;

    public class Holder extends ViewHolder {
        private View clickable;
        private ImageView ivPreview;
        private Toolbar toolbar;
        private TextView tvDuration;
        private TextView tvFileName;


        public Holder(View view) {
            super(view);
            this.clickable = view.findViewById(R.id.list_item_video_clicker);
            this.ivPreview = view.findViewById(R.id.list_item_video_thumb);
            this.tvDuration = view.findViewById(R.id.list_item_video_duration);
            this.tvFileName = view.findViewById(R.id.list_item_video_title);
            this.toolbar = view.findViewById(R.id.list_item_video_toolbar);
        }
    }

    private class MenuItemClickListener implements OnMenuItemClickListener {
        VideoData videoData;

        public MenuItemClickListener(VideoData videoData) {
            this.videoData = videoData;
        }


        public boolean onMenuItemClick(final MenuItem menuItem) {
            final int index = AllVideoAlbumAdapter.mVideoDatas.indexOf(this.videoData);
            final int itemId = menuItem.getItemId();
            if (itemId != R.id.action_delete) {
                if (itemId == R.id.action_share_native) {
                    final File file = new File(AllVideoAlbumAdapter.mVideoDatas.get(index).videoFullPath);
                    final Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("video/*");
                    intent.putExtra("android.intent.extra.SUBJECT", AllVideoAlbumAdapter.mVideoDatas.get(index).videoName);
                    intent.putExtra("android.intent.extra.TITLE", AllVideoAlbumAdapter.mVideoDatas.get(index).videoName);
                    intent.putExtra("android.intent.extra.STREAM", Uri.fromFile(file));
                    AllVideoAlbumAdapter.this.mContext.startActivity(Intent.createChooser(intent, "Share Video"));
                }
            } else {
                final AlertDialog.Builder alertDialog$Builder = new AlertDialog.Builder(AllVideoAlbumAdapter.this.mContext, R.style.Theme_MovieMaker_AlertDialog);
                alertDialog$Builder.setTitle(R.string.delete_video_);
                final StringBuilder sb = new StringBuilder();
                sb.append(AllVideoAlbumAdapter.this.mContext.getResources().getString(R.string.are_you_sure_to_delete_));
                sb.append(AllVideoAlbumAdapter.mVideoDatas.get(index).videoName);
                sb.append(".mp4 ?");
                alertDialog$Builder.setMessage(sb.toString());
                alertDialog$Builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialogInterface, final int n) {
                        FileUtils.deleteFile(new File(AllVideoAlbumAdapter.mVideoDatas.remove(index).videoFullPath));
                        AllVideoAlbumAdapter.this.notifyDataSetChanged();
                    }
                });
                alertDialog$Builder.setNegativeButton("Cancel", null);
                alertDialog$Builder.show();
            }
            return false;
        }
    }

    public AllVideoAlbumAdapter(Context context, ArrayList<VideoData> arrayList) {
        mVideoDatas = arrayList;
        this.mContext = context;
        this.activity = (ActivityVideoAlbum) context;
    }


    public int getItemCount() {
        return mVideoDatas.size();
    }

    public void onBindViewHolder(Holder holder, final int i) {
        holder.tvDuration.setText(FileUtils.getDuration(mVideoDatas.get(i).videoDuration));
        Glide.with(this.mContext).load(mVideoDatas.get(i).videoFullPath).into(holder.ivPreview);
        TextView access$200 = holder.tvFileName;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(mVideoDatas.get(i).videoName);
        stringBuilder.append(".mp4");
        access$200.setText(stringBuilder.toString());
//        holder.tvFileName.setVisibility(View.VISIBLE);
//        holder.tvDuration.setVisibility(View.VISIBLE);
        holder.clickable.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                activity.id = i;
                activity.view = view;
                if (activity.mInterstitialAd != null && activity.mInterstitialAd.isLoaded()) {
                    try {
                        activity.hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        activity.hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                activity.hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (activity.mInterstitialAd != null && activity.mInterstitialAd.isLoaded()) {
                                activity.mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    AllVideoAlbumAdapter.this.loadVideoPlayer(view);
                }
            }
        });
        menu(holder.toolbar, R.menu.home_item_exported_video_local_menu, new MenuItemClickListener(mVideoDatas.get(i)));
    }

    private void loadVideoPlayer(View view) {
        Intent intent = new Intent(this.mContext, videoPlay.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("KEY", "FromVideoAlbum");
        intent.putExtra("android.intent.extra.TEXT", mVideoDatas.get(activity.id).videoFullPath);
        intent.putExtra(this.mContext.getResources().getString(R.string.video_position_key), activity.id);
        ActivityAnimUtil.startActivitySafely(view, intent);
    }

    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(this.mContext).inflate(R.layout.list_item_published_video, viewGroup, false));
    }

    public static void menu(Toolbar toolbar, int i, OnMenuItemClickListener onMenuItemClickListener) {
        toolbar.getMenu().clear();
        toolbar.inflateMenu(i);
        toolbar.setOnMenuItemClickListener(onMenuItemClickListener);
    }
}
