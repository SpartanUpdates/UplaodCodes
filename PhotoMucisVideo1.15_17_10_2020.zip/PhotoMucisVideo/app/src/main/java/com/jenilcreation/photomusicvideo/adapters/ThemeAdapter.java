package com.jenilcreation.photomusicvideo.adapters;

import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.jenilcreation.photomusicvideo.MyApplication;
import com.jenilcreation.photomusicvideo.R;
import com.jenilcreation.photomusicvideo.activity.PreviewActivity;
import com.jenilcreation.photomusicvideo.mask.Themes1;
import com.jenilcreation.photomusicvideo.util.service.ImageCreatorService;
import com.videolib.libffmpeg.FileUtils;
import java.util.ArrayList;
import java.util.Arrays;

public class ThemeAdapter extends Adapter<ThemeAdapter.Holder> {
    private MyApplication application;
    private LayoutInflater inflater;
    private ArrayList<Themes1> theame_List;
    private PreviewActivity previewActivity;

    class clickableView implements OnClickListener {
        private final int val$pos;

        clickableView(int i) {
            this.val$pos = i;
        }

        public void onClick(View v) {
            application.check = 1;

            if (ThemeAdapter.this.theame_List.get(this.val$pos) != ThemeAdapter.this.application.selected_theme) {
                ThemeAdapter.this.deleteThemeDir(ThemeAdapter.this.application.selected_theme.toString());
                ThemeAdapter.this.application.videoImages.clear();
                ThemeAdapter.this.application.selected_theme = (Themes1) ThemeAdapter.this.theame_List.get(this.val$pos);
                ThemeAdapter.this.application.setCurrentTheme(ThemeAdapter.this.application.selected_theme.toString());
                ThemeAdapter.this.previewActivity.reset();
                Intent intent = new Intent(ThemeAdapter.this.application, ImageCreatorService.class);
                intent.putExtra(ImageCreatorService.EXTRA_SELECTED_THEME, ThemeAdapter.this.application.getCurrentTheme());
                ThemeAdapter.this.application.startService(intent);
                ThemeAdapter.this.notifyDataSetChanged();
            }
        }
    }

    class deleteTheme extends Thread {
        private final String val$dir;

        deleteTheme(String str) {
            this.val$dir = str;
        }

        public void run() {
            FileUtils.deleteThemeDir(this.val$dir);
        }
    }

    public class Holder extends ViewHolder {
        CheckBox checkbox_select;
        private View clickableView;
        private ImageView ivThumb;
        private View mainView;
        private TextView tvThemeName;

        public Holder(View v) {
            super(v);
            this.checkbox_select = (CheckBox) v
                    .findViewById(R.id.checkbox_select);
            this.ivThumb = (ImageView) v.findViewById(R.id.imgV_thumb);
            this.tvThemeName = (TextView) v
                    .findViewById(R.id.txtView_themeName);
            this.clickableView = v.findViewById(R.id.clickable_view);
            this.mainView = v;
        }
    }

    public ThemeAdapter(PreviewActivity previewActivity) {
        this.application = MyApplication.getInstance();
        this.previewActivity = previewActivity;
        this.theame_List = new ArrayList(Arrays.asList(Themes1.values()));
        this.inflater = LayoutInflater.from(previewActivity);
    }

    public Holder onCreateViewHolder(ViewGroup paramViewGroup, int paramInt) {
        return new Holder(this.inflater.inflate(R.layout.movietheme, paramViewGroup, false));
    }

    public void onBindViewHolder(Holder holder, int pos) {
        Themes1 themes = (Themes1) this.theame_List.get(pos);
        Glide.with(this.application).load(Integer.valueOf(themes.getThemeDrawable())).into(holder.ivThumb);
        holder.tvThemeName.setText(themes.getName());
        holder.tvThemeName.setSelected(true);
        holder.checkbox_select.setChecked(themes == this.application.selected_theme);
        holder.clickableView.setOnClickListener(new clickableView(pos));
    }

    private void deleteThemeDir(String dir) {
        new deleteTheme(dir).start();
    }

    public ArrayList<Themes1> getList() {
        return this.theame_List;
    }

    public int getItemCount() {
        return this.theame_List.size();
    }
}
