package com.kotlinz.festivalstorymaker.Model.Story;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class StoryMain {

	@SerializedName("success")
	private String success;

	@SerializedName("response")
	private ArrayList<StoryCategory> response;

	public String getSuccess(){
		return success;
	}

	public ArrayList<StoryCategory> getResponse(){
		return response;
	}
}