package com.example.postermaker.editorsclasses.designitems;

import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout.LayoutParams;
import com.example.postermaker.eaz_ConstantValues;
import com.example.postermaker.eaz_EditActivity;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar.OnProgressChangeListener;

public class eaz_BackgroundSize implements OnClickListener, OnProgressChangeListener {
    public void onStartTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public void onStopTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public void loadBackgroundSizeItems()
    {
        eaz_EditActivity.backgroundsizelayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.oksize.setOnClickListener(this);
        eaz_EditActivity.cancelsize.setOnClickListener(this);
        eaz_EditActivity.backwidth.setOnProgressChangeListener(this);
        eaz_EditActivity.backhight.setOnProgressChangeListener(this);
        eaz_EditActivity.imagewidth.setOnProgressChangeListener(this);
        eaz_EditActivity.imagehight.setOnProgressChangeListener(this);
    }

    public void onClick(View view) {
        if (view.equals(eaz_EditActivity.oksize)) {
            eaz_EditActivity.backgroundsizelayout.setVisibility(View.GONE);
        } else if (view.equals(eaz_EditActivity.cancelsize)) {
            if (eaz_ConstantValues.bgchoice == 1) {
                eaz_EditActivity.backgroundlayout.setLayoutParams(new LayoutParams(-1, -1));
                eaz_EditActivity.foregroundlayout.setLayoutParams(new LayoutParams(-1, -1));
            } else if (eaz_ConstantValues.bgchoice == 2) {
                eaz_EditActivity.backgroundlayout.setLayoutParams(new LayoutParams(-1, -1));
                eaz_EditActivity.foregroundlayout.setLayoutParams(new LayoutParams(-1, -1));
            }
            eaz_EditActivity.backgroundsizelayout.setVisibility(View.GONE);
        }
    }

    public void onProgressChanged(DiscreteSeekBar discreteSeekBar, int i, boolean z) {
        ViewGroup.LayoutParams layoutParams;
        if (discreteSeekBar.equals(eaz_EditActivity.backwidth)) {
            if (eaz_ConstantValues.bgchoice == 1) {
                layoutParams = eaz_EditActivity.backgroundlayout.getLayoutParams();
                layoutParams.width = i;
                eaz_EditActivity.backgroundlayout.setLayoutParams(layoutParams);
                eaz_EditActivity.backgroundlayout.invalidate();
            } else if (eaz_ConstantValues.bgchoice == 2) {
                layoutParams = eaz_EditActivity.foregroundlayout.getLayoutParams();
                layoutParams.width = i;
                eaz_EditActivity.foregroundlayout.setLayoutParams(layoutParams);
                eaz_EditActivity.foregroundlayout.invalidate();
            }
        } else if (discreteSeekBar.equals(eaz_EditActivity.backhight)) {
            if (eaz_ConstantValues.bgchoice == 1) {
                layoutParams = eaz_EditActivity.backgroundlayout.getLayoutParams();
                layoutParams.height = i;
                eaz_EditActivity.backgroundlayout.setLayoutParams(layoutParams);
                eaz_EditActivity.backgroundlayout.invalidate();
            } else if (eaz_ConstantValues.bgchoice == 2) {
                layoutParams = eaz_EditActivity.foregroundlayout.getLayoutParams();
                layoutParams.height = i;
                eaz_EditActivity.foregroundlayout.setLayoutParams(layoutParams);
                eaz_EditActivity.foregroundlayout.invalidate();
            }
        } else if (discreteSeekBar.equals(eaz_EditActivity.imagewidth)) {
            if (eaz_ConstantValues.bgchoice == 1) {
                layoutParams = eaz_EditActivity.backgroundimage.getLayoutParams();
                layoutParams.width = i;
                eaz_EditActivity.backgroundimage.setLayoutParams(layoutParams);
                eaz_EditActivity.backgroundimage.invalidate();
            } else if (eaz_ConstantValues.bgchoice == 2) {
                layoutParams = eaz_EditActivity.forgroundimage.getLayoutParams();
                layoutParams.width = i;
                eaz_EditActivity.forgroundimage.setLayoutParams(layoutParams);
                eaz_EditActivity.forgroundimage.invalidate();
            }
        } else if (!discreteSeekBar.equals(eaz_EditActivity.imagehight)) {
        } else {
            if (eaz_ConstantValues.bgchoice == 1) {
                layoutParams = eaz_EditActivity.backgroundimage.getLayoutParams();
                layoutParams.height = i;
                eaz_EditActivity.backgroundimage.setLayoutParams(layoutParams);
                eaz_EditActivity.backgroundimage.invalidate();
            } else if (eaz_ConstantValues.bgchoice == 2) {
                layoutParams = eaz_EditActivity.forgroundimage.getLayoutParams();
                layoutParams.height = i;
                eaz_EditActivity.forgroundimage.setLayoutParams(layoutParams);
                eaz_EditActivity.forgroundimage.invalidate();
            }
        }
    }
}
