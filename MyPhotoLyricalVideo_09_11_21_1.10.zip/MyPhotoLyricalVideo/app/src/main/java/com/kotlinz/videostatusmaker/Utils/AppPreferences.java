package com.kotlinz.videostatusmaker.Utils;

import android.content.*;

import com.kotlinz.videostatusmaker.R;

public class AppPreferences
{
  private static final String ALL_CAPS = "ALL_CAPS";
  private static String PREFS_NAME;
  private final SharedPreferences.Editor editor;
  private final SharedPreferences preferences;

  public AppPreferences(final Context context) {
    AppPreferences.PREFS_NAME = context.getResources().getString(R.string.app_name);
    this.preferences = context.getSharedPreferences(AppPreferences.PREFS_NAME, 0);
    this.editor = this.preferences.edit();
  }

  public boolean get_ALL_CAPS() {
    return this.preferences.getBoolean("ALL_CAPS", false);
  }

  public void set_ALL_CAPS(final boolean b) {
    this.editor.putBoolean("ALL_CAPS", b);
    this.editor.commit();
  }
}
