package com.kotlinz.festivalstorymaker.roomdatabase;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.kotlinz.festivalstorymaker.Model.customer.AddCustomer;

@Database(entities = {AddCustomer.class}, version = 1)
public abstract class BusinessDatabase extends RoomDatabase
{
    public abstract AddBusinessDeo addBusinessDeo();
    public static BusinessDatabase businessDatabase;

    public static BusinessDatabase getBusinessDetailsDatabase(final Context context) {
        if (businessDatabase == null) {
            synchronized (BusinessDatabase.class) {
                if (businessDatabase == null) {
                    businessDatabase = Room.databaseBuilder(context,
                            BusinessDatabase.class, "Business")
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return businessDatabase;
    }
}
