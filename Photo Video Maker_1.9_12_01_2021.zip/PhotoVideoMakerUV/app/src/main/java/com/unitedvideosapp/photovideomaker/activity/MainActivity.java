package com.unitedvideosapp.photovideomaker.activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;
import com.unitedvideosapp.photovideomaker.MyApplication;
import com.unitedvideosapp.photovideomaker.adapters.SliderAdpater;
import com.unitedvideosapp.photovideomaker.modelclass.SliderModel;
import com.unitedvideosapp.photovideomaker.util.ActivityAnimUtil;
import com.unitedvideosapp.photovideomaker.util.EPreferences;
import com.unitedvideosapp.photovideomaker.util.PermissionModelUtil;
import com.unitedvideosapp.photovideomaker.util.Utils;
import com.unitedvideosapp.photovideomaker.utility.service.CreateVideoService;
import com.unitedvideosapp.photovideomaker.utility.service.CreateVideoServicenew;
import com.unitedvideosapp.photovideomaker.utility.service.ImageCreatorService;
import com.unitedvideosapp.photovideomaker.utility.service.ImageCreatorServicenew;
import com.uvvideos.photo.video.slideshow.maker.R;

import java.util.ArrayList;

import static com.unitedvideosapp.photovideomaker.view.CustomNativeAd.populateUnifiedNativeAdView;

public class MainActivity extends AppCompatActivity implements OnClickListener {
    Activity activity = MainActivity.this;
    static int anInt;
    View view;
    EPreferences ePreferences;
    EPreferences ePreferences1;
    ComponentName SecurityComponentName = null;
    PermissionModelUtil permissionModelUtil;


    SliderView sliderHome;
    ArrayList<SliderModel> sliderList = new ArrayList<>();
    SliderAdpater sliderAdpater;

    public MainActivity() {

    }

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        if (this.isVideoInprocess()) {
            this.startActivity(new Intent(this, ProgressActivity.class));
            this.overridePendingTransition(0, 0);
            this.finish();
            return;
        } else if (this.isVideoInprocessnew()) {
            this.startActivity(new Intent(this, ProgressActivity.class));
            this.overridePendingTransition(0, 0);
            this.finish();
            return;
        }
        this.setContentView(R.layout.activity_main);
        this.ePreferences = EPreferences.getInstance(this);
        this.ePreferences1 = EPreferences.getInstance1(this);
        if (!this.ePreferences1.getBoolean("privacy_policy", false)) {
            PrivacyPolicyDialog();
        }
        this.setActionBar();
        LoadnativeAd();
        this.init();
        this.addListener();
        SetSliderAdapter();
//        if (Utils.checkAds) {
//            loadAd();
//        } else {
//            Utils.checkAds = true;
//        }
        MyApplication.getInstance().setAutostartAppName();
        if (MyApplication.getInstance().runApp(Utils.autostart_app_name, 0) && !this.check_permission()) {
            this.permissionDialog();
        }
        PutAnalyticsEvent();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MainActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private UnifiedNativeAd nativeAd;

    private void LoadnativeAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    private void PrivacyPolicyDialog() {
        final Dialog dialog = new Dialog(com.unitedvideosapp.photovideomaker.activity.MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_policy);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ePreferences1.putBoolean("privacy_policy", true);
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    private void SetSliderAdapter() {
        sliderList.add(0, new SliderModel(getResources().getDrawable(R.drawable.slider_one)));
        sliderList.add(1, new SliderModel(getResources().getDrawable(R.drawable.slide_two)));
        sliderList.add(2, new SliderModel(getResources().getDrawable(R.drawable.slider_three)));
        sliderList.add(3, new SliderModel(getResources().getDrawable(R.drawable.slider_four)));
        sliderList.add(4, new SliderModel(getResources().getDrawable(R.drawable.slider_five)));
        sliderList.add(5, new SliderModel(getResources().getDrawable(R.drawable.slider_six)));
        sliderAdpater = new SliderAdpater(activity, sliderList);
        sliderHome.setSliderAdapter(sliderAdpater);
        sliderHome.setIndicatorAnimation(IndicatorAnimationType.WORM);
        sliderHome.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderHome.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
        sliderHome.setIndicatorSelectedColor(getResources().getColor(R.color.white));
        sliderHome.setIndicatorUnselectedColor(getResources().getColor(R.color.slide_unselected));
        sliderHome.setScrollTimeInSec(3);
        sliderHome.setAutoCycle(true);
        sliderHome.startAutoCycle();
    }

    public boolean check_permission() {
        return this.ePreferences.getBoolean("HasAutoStartPermission", false);
    }


    private void permissionDialog() {
        String str = Build.MANUFACTURER;
        if (str.equals("Xiaomi")) {

            this.SecurityComponentName = new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity");
            Utils.autostart_app_name = "Security";

        } else if (str.equals("asus")) {

            this.SecurityComponentName = new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity");
            Utils.autostart_app_name = "Auto-start Manager";

        }
        Intent intent = new Intent(this, ActivityPermission.class);
        intent.putExtra("PACKAGE", this.SecurityComponentName);
        intent.putExtra("APPNAME", Utils.autostart_app_name);
        startActivity(intent);
    }


    private boolean isVideoInprocess() {

        return MyApplication.isMyServiceRunning(this, CreateVideoService.class) || MyApplication.isMyServiceRunning(this, ImageCreatorService.class);

    }

    private boolean isVideoInprocessnew() {
        return MyApplication.isMyServiceRunning(this, CreateVideoServicenew.class) || MyApplication.isMyServiceRunning(this, ImageCreatorServicenew.class);
    }

    private void init() {
        sliderHome = findViewById(R.id.slider_home);
        Utils.isVideoCreationRunning = true;
        if (Utils.checkPermission(this)) {
            MyApplication.getInstance().getFolderList();
        } else {
            Utils.requestPermission(this);
        }
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(307);
    }

    protected void onResume() {
        super.onResume();
        if (anInt == 1) {
            anInt = 0;
            if (Utils.checkPermission(this)) {
                onStart();
            } else {
                Utils.requestPermission(this);
            }
        }
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int n, @NonNull final String[] array, @NonNull final int[] array2) {
        if (n != 222) {
            return;
        }
        if (array2.length > 0) {
            boolean b = false;
            if (array2[0] == 0) {
                n = 1;
            } else {
                n = 0;
            }
            if (array2[1] == 0) {
                b = true;
            }
            if (n != 0 && b) {
                MyApplication.getInstance().getFolderList();
                return;
            }
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.READ_EXTERNAL_STORAGE") && !ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
                Utils.permissionDailog(this);
                return;
            }
            Utils.requestPermission(this);
        }
    }

    private void addListener() {
        findViewById(R.id.btnCreateVideo).setOnClickListener(this);
        findViewById(R.id.btnViewVideo).setOnClickListener(this);
        findViewById(R.id.lyRateus).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                } catch (ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                }
            }
        });
        findViewById(R.id.lyPolicy).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                loadPrivacy();
            }
        });

        findViewById(R.id.lyshare).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                loadShare();
            }
        });
    }


    public void onClick(View view) {
        this.view = view;
        int id = view.getId();
        if (id != R.id.btnChangeLang) {
            if (id != R.id.btnCreateVideo) {
                if (id == R.id.btnViewVideo) {
                    if (Utils.checkPermission(this)) {
                        loadVideoList(view);
                    }
                    Utils.requestPermission(this);
                }
            } else if (Utils.checkPermission(this)) {
                AsyncTaskRunner1 runner1 = new AsyncTaskRunner1();
                runner1.execute("");
            } else {
                Utils.requestPermission(this);
            }
        } else {
            this.permissionModelUtil.showPermissionExplanationThenAuthorization();
        }
    }

    private void loadVideoList(View view) {
        ActivityAnimUtil.startActivitySafely(view, new Intent(this, ActivityVideoAlbum.class));
    }

    private class AsyncTaskRunner1 extends AsyncTask<String, String, String> {

        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            MyApplication.getInstance().getFolderList();
            if (MyApplication.getInstance().getAllFolder().size() > 0) {
                MyApplication.isStoryAdded = false;
                MyApplication.isBreak = false;
                MyApplication.getInstance().setMusicData(null);
                return "";
            }
            return "Null";
        }


        @Override
        protected void onPostExecute(String result) {
            if (!result.equalsIgnoreCase("Null")) {
                ActivityAnimUtil.startActivitySafely(view, new Intent(MainActivity.this, PhotoselectActivity.class));
            } else {
                Toast.makeText(getApplicationContext(), R.string.no_images_found_in_device_please_add_images_in_sdcard, Toast.LENGTH_SHORT).show();
            }
            progressDialog.dismiss();
        }


        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(MainActivity.this,
                    "Loading Images",
                    "Please Wait...");
        }


        @Override
        protected void onProgressUpdate(String... text) {

        }
    }

    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(MainActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                dialog.findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout =
                        dialog.findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    ePreferences.putBoolean("pref_key_rate", true);
                    dialog.dismiss();
                    if (isRate[0]) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(com.unitedvideosapp.photovideomaker.activity.MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                dialog.findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout =
                        dialog.findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        dialog.show();
    }

    private void setActionBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        TextView textView = toolbar.findViewById(R.id.toolbar_title);
        textView.setText(getString(R.string.app_name));
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        Utils.setFont(this, textView);
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }


    public boolean onOptionsItemSelected(MenuItem menuItem) {
        return true;
    }

    private void loadShare() {
        Intent intent = new Intent("android.intent.action.SEND");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Create amazing and stunning  ");
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" : https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        intent.setType("text/plain");
        startActivity(intent);
    }

    private void loadPrivacy() {
        Intent intent1 = new Intent(Intent.ACTION_VIEW);
        intent1.setData(Uri.parse("https://sites.google.com/site/unitedvideosprivacy/"));
        startActivity(intent1);
    }

}
