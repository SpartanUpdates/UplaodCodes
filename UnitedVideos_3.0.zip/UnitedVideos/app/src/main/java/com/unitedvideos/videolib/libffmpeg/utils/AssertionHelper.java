package com.unitedvideos.videolib.libffmpeg.utils;


public class AssertionHelper {
  public AssertionHelper() {}
  
  /*public static void assertError(String message) { Assert.assertTrue(message, false); }
  
  public static void assertError()
  {
    assertError("");
  }
  
  public static void assertOK(String message) {
    Assert.assertTrue(message, true);
  }
  
  public static void assertOK() {
    assertOK("");
  }*/
}
