package com.wavymusic.bottomSheet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.root.UnitySendValue.AndroidUnityCall;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.R;

public class BottomSheetFragment extends BottomSheetDialogFragment {
    Button btnLatter, btnStayHere;
    String IsFromModule;
    String IsFrom;


    public static BottomSheetFragment newInstance(String IsFromModule, String IsFrom) {
        BottomSheetFragment fragment = new BottomSheetFragment();
        Bundle bundle = new Bundle();
        bundle.putString("IsFromModule", IsFromModule);
        bundle.putString("isFrom", IsFrom);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            IsFromModule = getArguments().getString("IsFromModule");
            IsFrom = getArguments().getString("isFrom");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_back_preview, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        BindView(view);
    }

    private void BindView(View view) {
        btnLatter = view.findViewById(R.id.btn_latter);
        btnStayHere = view.findViewById(R.id.btn_stayhere);
        btnLatter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (IsFromModule.equals("Wavy")) {
                    UnityPlayer.UnitySendMessage("ThemeManager", "DOLater", "");
                    if (IsFrom.equals("0")) {
                        AndroidUnityCall.BackToMain(MyApplication.PreviewContext);
                    } else {
                        AndroidUnityCall.BackToMainWavyViewAll(MyApplication.PreviewContext);
                    }
                } else if (IsFromModule.equals("UV")) {
                    UnityPlayer.UnitySendMessage("UVThemeData", "DOLater", "");
                    if (IsFrom.equals("0")) {
                        AndroidUnityCall.BackToMainUv(MyApplication.PreviewContext);
                    } else {
                        AndroidUnityCall.BackToMainUvViewAll(MyApplication.PreviewContext);
                    }
                }
                dismiss();
            }
        });
        btnStayHere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (IsFromModule.equals("Wavy")) {
                    UnityPlayer.UnitySendMessage("ThemeManager", "BackRestart", "");
                } else if (IsFromModule.equals("UV")) {
                    UnityPlayer.UnitySendMessage("UVThemeData", "BackRestart", "");
                }
                dismiss();
            }
        });
    }
}
