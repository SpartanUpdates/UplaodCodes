package com.kotlinz.festivalstorymaker.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.CollageMakeFrameListAdapter;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.CategoryWiseData.CollageCategoryWiseData;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.CategoryWiseData.CollageCategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.CollageMainCategory;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.CollageResponse;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CollageMakerActivity extends BaseActivity {

    Activity activity = CollageMakerActivity.this;


    @BindView(R.id.imgSquareSize)
    public ImageView ivSquare;
    @BindView(R.id.imgVerticalSize)
    public ImageView ivVertical;
    @BindView(R.id.imgStorySize)
    public ImageView ivStory;
    @BindView(R.id.rv_collage_maker)
    public RecyclerView rvCollageMaker;

    @BindView(R.id.rl_main_Data)
    RelativeLayout rlMainData;

    @BindView(R.id.llRetry)
    LinearLayout llRetry;

    private ProgressDialog progressDialog;

    APIInterface apiInterface;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.h> Q = new ArrayList();

    public int Position;
    private int ModuleId;
    public ArrayList<CollageMainCategory> collageCategoryList;
    public ArrayList<CollageCategoryWiseData> categoryWiseCollageList;
    public CollageMakeFrameListAdapter collageMakeFrameListAdapter;


    ImagePickerConfig a2;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    Gson gson = new Gson();


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.kotlinz.festivalstorymaker.R.layout.activity_collage_maker);
        ButterKnife.bind(this);
        BannerAds();
        PutAnalyticsEvent();
        apiInterface = APIClient.getClient().create(APIInterface.class);
        ModuleId = getIntent().getIntExtra("moduleid", 0);
        ivSquare.setImageResource(R.drawable.ic_square_press);
        InitProgressDialog();
        SetCollageMakerMainCategoryData();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CollageMakerActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(com.kotlinz.festivalstorymaker.R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(com.kotlinz.festivalstorymaker.R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    @OnClick(R.id.llRetry)
    public void RetryData() {
        if (Utils.checkConnectivity(activity, false)) {
            rlMainData.setVisibility(View.VISIBLE);
            llRetry.setVisibility(View.GONE);
            GetCollageCategory(ModuleId);
        } else {
            Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
        }
    }


    private void SetCollageMakerMainCategoryData() {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMaker).equalsIgnoreCase("")) {
                GetCollageCategory(ModuleId);

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.CollageMakerResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetCollageCategory(ModuleId);

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMaker).equalsIgnoreCase("")) {

                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMaker));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMaker).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);
            } else {
                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMaker));
            }
        }
    }

    private void GetCollageCategory(int ModuleId) {
        progressDialog.show();
        Call<CollageResponse> call = apiInterface.getCollageModuleWiseCategory(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<CollageResponse>() {
            @Override
            public void onResponse(Call<CollageResponse> call, Response<CollageResponse> response) {
                if (response.isSuccessful()) {
                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.CollageMaker);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.CollageMakerResponseTime);
                    SetOfflineDataMainCategory(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<CollageResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMaker).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineDataMainCategory(String response) {
        CollageResponse collageResponse = gson.fromJson(response, CollageResponse.class);
        collageCategoryList = collageResponse.getData();
        SetCollageThemeData(0, collageCategoryList);
        progressDialog.dismiss();
    }

    public void SetCollageThemeData(int Position, ArrayList<CollageMainCategory> collageCategoryList) {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + collageCategoryList.get(Position).getCatId() + collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                GetCollageCategoryDataByID(String.valueOf(collageCategoryList.get(Position).getCatId()), String.valueOf(collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.CollageMakerThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetCollageCategoryDataByID(String.valueOf(collageCategoryList.get(Position).getCatId()), String.valueOf(collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + collageCategoryList.get(Position).getCatId() + collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {

                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + collageCategoryList.get(Position).getCatId() + collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + collageCategoryList.get(Position).getCatId() + collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + collageCategoryList.get(Position).getCatId() + collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));
            }
        }
    }

    public void GetCollageCategoryDataByID(String ParentCatId, String ChildCatId) {
        progressDialog.show();
        Call<CollageCategoryWiseResponse> call = apiInterface.getCollageCategoryWiseData(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId), "0", ParentCatId, ChildCatId);
        call.enqueue(new Callback<CollageCategoryWiseResponse>() {
            @Override
            public void onResponse(Call<CollageCategoryWiseResponse> call, Response<CollageCategoryWiseResponse> response) {
                if (response.isSuccessful()) {
                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.CollageMakerTheme + ParentCatId + ChildCatId);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.CollageMakerThemeResponseTime);
                    SetOfflineThemeData(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<CollageCategoryWiseResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + ParentCatId + ChildCatId).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineThemeData(String response) {
        CollageCategoryWiseResponse categoryWiseResponse = gson.fromJson(response, CollageCategoryWiseResponse.class);
        categoryWiseCollageList = categoryWiseResponse.getData();
        collageMakeFrameListAdapter = new CollageMakeFrameListAdapter(activity, categoryWiseCollageList);
        rvCollageMaker.setLayoutManager(new GridLayoutManager(activity, 3));
        rvCollageMaker.setAdapter(collageMakeFrameListAdapter);
        progressDialog.dismiss();
    }

    private void SetCollageMethod(String ParentCatId, String ChildCatId) {
        if (com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + ParentCatId + ChildCatId).equalsIgnoreCase("")) {
                GetCollageCategoryDataByID(ParentCatId, ChildCatId);

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.CollageMakerThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetCollageCategoryDataByID(ParentCatId, ChildCatId);

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + ParentCatId + ChildCatId).equalsIgnoreCase("")) {

                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + ParentCatId + ChildCatId));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + ParentCatId + ChildCatId).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.CollageMakerTheme + ParentCatId + ChildCatId));
            }
        }
    }

    public void ShowImageDialog(String IsFrom) {
        Dialog dialog = new Dialog(activity, R.style.AppImageAlertDialog);
        dialog.setContentView(R.layout.dialog_select_imagevideo);
        LinearLayout llCamera = dialog.findViewById(R.id.llCamera);
        LinearLayout llGallery = dialog.findViewById(R.id.llGallery);
        llCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenCamera();
                dialog.dismiss();
            }
        });
        llGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenGallery();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void OpenGallery() {
        final ImagePicker.ImagePickerWithActivity a = new ImagePicker.ImagePickerWithActivity(this);
        a2 = a.config;
        a2.folderMode = true;
        a2.theme = 10;
        a2.limit = Constant.NoofImage;
        a2.showCamera = false;
        a.start(0);
    }

    private void OpenCamera() {
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        startActivityForResult(intent, Constant.Camera);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == 0 && resultCode == -1) {
            ArrayList arrayList = new ArrayList();
            List c = ImagePicker.getImages(intent);
            if (c.size() == Constant.NoofImage) {
                for (int i3 = 0; i3 < c.size(); i3++) {
                    arrayList.add(((Image) c.get(i3)).getPath());
                }
                Intent intent1 = new Intent(activity, CollageMakerDetailActivity.class);
                intent1.putStringArrayListExtra("list", arrayList);
                intent1.putExtra("moduleid", ModuleId);
                intent1.putExtra("FilePath", Constant.TextFilePath);
                startActivity(intent1);
                return;
            }
            Toast.makeText(activity, "Please select " + Constant.NoofImage + "Images", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llSquareSize:
                ivSquare.setImageResource(R.drawable.ic_square_press);
                ivVertical.setImageResource(R.drawable.ic_vertical_unpress);
                ivStory.setImageResource(R.drawable.ic_story_unpress);
                /*GetCollageCategoryDataByID(String.valueOf(collageCategoryList.get(0).getCatId()), String.valueOf(collageCategoryList.get(0).getChildCategory().get(0).getChildCatId()));*/
                SetCollageMethod(String.valueOf(collageCategoryList.get(0).getCatId()), String.valueOf(collageCategoryList.get(0).getChildCategory().get(0).getChildCatId()));
                break;
            case R.id.llVerticalSize:
                ivVertical.setImageResource(R.drawable.ic_vertical_press);
                ivSquare.setImageResource(R.drawable.ic_square_unpress);
                ivStory.setImageResource(R.drawable.ic_story_unpress);
                /*GetCollageCategoryDataByID(String.valueOf(collageCategoryList.get(2).getCatId()), String.valueOf(collageCategoryList.get(1).getChildCategory().get(0).getChildCatId()));*/
                SetCollageMethod(String.valueOf(collageCategoryList.get(2).getCatId()), String.valueOf(collageCategoryList.get(1).getChildCategory().get(0).getChildCatId()));
                break;
            case R.id.llStorySize:
                ivStory.setImageResource(R.drawable.ic_story_press);
                ivSquare.setImageResource(R.drawable.ic_square_unpress);
                ivVertical.setImageResource(R.drawable.ic_vertical_unpress);
                /*GetCollageCategoryDataByID(String.valueOf(collageCategoryList.get(1).getCatId()), String.valueOf(collageCategoryList.get(2).getChildCategory().get(0).getChildCatId()));*/
                SetCollageMethod(String.valueOf(collageCategoryList.get(1).getCatId()), String.valueOf(collageCategoryList.get(2).getChildCategory().get(0).getChildCatId()));
                break;
            case R.id.iv_my_creation:
                Intent intent = new Intent(this, MyPostActivity.class);
                startActivityForResult(intent, 724);
                return;
            default:
                return;
        }
    }


    @OnClick(R.id.iv_my_creation)
    public void MyCreation() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, MyPostActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 24;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(activity, MyPostActivity.class));
                finish();
            }
        }
    }

    @OnClick(R.id.iv_back)
    public void Back(View view) {
        onBackPressed();
    }


    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, DashBordActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 23;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(activity, DashBordActivity.class));
                finish();
            }
        }
    }
}