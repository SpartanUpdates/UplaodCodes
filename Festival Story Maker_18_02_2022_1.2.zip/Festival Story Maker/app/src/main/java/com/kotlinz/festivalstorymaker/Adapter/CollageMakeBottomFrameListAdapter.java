package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.CategoryWiseData.CollageCategoryWiseData;
import com.kotlinz.festivalstorymaker.R;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CollageMakeBottomFrameListAdapter extends RecyclerView.Adapter<CollageMakeBottomFrameListAdapter.ViewHolder> {

    public Activity activity;
    public ArrayList<CollageCategoryWiseData> collageFrameList;
    public a i;


    public interface a {
        void a(int i);
    }

    public CollageMakeBottomFrameListAdapter(Activity activity, ArrayList<CollageCategoryWiseData> arrayList, a aVar) {
        this.activity = activity;
        this.collageFrameList = arrayList;
        this.i = aVar;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_collage_maker_bottom_frame_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(activity).load(collageFrameList.get(position).getThemeThumbnail()).placeholder(R.drawable.ic_placehoder).into(holder.img);
        holder.img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i.a(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return collageFrameList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.imgBg)
        public ImageView img;

        @BindView(R.id.imgLock)
        public ImageView imgLock;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this,itemView);
        }
    }
}
