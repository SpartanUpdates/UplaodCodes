package com.esc.phoneheart.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import com.esc.phoneheart.R;
import com.esc.phoneheart.interfaceclass.DialogListners;
import com.esc.phoneheart.utility.Util;

import androidx.appcompat.app.AppCompatActivity;

public class SplashScreen extends AppCompatActivity {

    public static final String TAG = "Splash";

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashScreen.this, HomeActivity.class));
                finish();
            }
        },3000);
    }

    public static void showdialog_sdcard(Context context, final DialogListners dialogListners) {
        Util.appendLogphonecleanerbug(TAG, "in sd card dialog method");
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(1);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
        }
        dialog.setContentView(R.layout.dialog_sdcard);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.getWindow().setGravity(17);
        ((TextView) dialog.findViewById(R.id.ll_no_txt)).setText(context.getString(R.string.dialouge_notnow));
        ((TextView) dialog.findViewById(R.id.ll_yes_txt)).setText(context.getString(R.string.pcl_continues));
        dialog.findViewById(R.id.ll_no).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Util.appendLogphonecleanerbug(SplashScreen.TAG, "sd card dialog dismiss");
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.ll_yes).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
                Util.appendLogphonecleanerbug(SplashScreen.TAG, "sd card ok click");
                dialogListners.clickOK();
            }
        });
        dialog.show();
    }
}
