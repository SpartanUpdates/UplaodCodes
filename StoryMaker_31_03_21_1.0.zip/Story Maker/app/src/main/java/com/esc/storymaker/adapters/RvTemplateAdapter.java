package com.esc.storymaker.adapters;

import android.graphics.Color;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.bumptech.glide.Glide;
import com.esc.storymaker.MainActivity;
import com.esc.storymaker.R;
import com.esc.storymaker.interfaces.ItemClickListener;
import com.esc.storymaker.mediapicker.utils.DensityUtil;
import com.esc.storymaker.utils.AppUtil;
import com.esc.storymaker.utils.ContractsUtil;

import java.util.ArrayList;
import java.util.List;

public class RvTemplateAdapter extends RecyclerView.Adapter<RvTemplateAdapter.ViewHolderCollagePattern> {
    private ArrayList<String> categories;
    private String category;
    private boolean isFirstClick;
    private long mLastClickTime = System.currentTimeMillis();
    private MainActivity mainActivity;
    private List<String> newCategories = new ArrayList();
    private int screenWidth;
    private ArrayList<String> thumbnails;

    static class ViewHolderCollagePattern extends ViewHolder implements OnClickListener {
        ItemClickListener itemClickListener;
        ImageView ivNew;
        ImageView ivThumb;
        RelativeLayout llWrapper;
        TextView tvName;

        public ViewHolderCollagePattern(View view) {
            super(view);
            this.ivThumb = view.findViewById(R.id.iv_thumb);
            this.tvName = view.findViewById(R.id.tv_name);
            this.llWrapper = view.findViewById(R.id.ll_wrapper);
            this.ivNew = view.findViewById(R.id.iv_new);
            view.setOnClickListener(this);
        }

        public void setItemClickListener(ItemClickListener itemClickListener) {
            this.itemClickListener = itemClickListener;
        }

        public void onClick(View view) {
            this.itemClickListener.onItemClick(view, getLayoutPosition());
        }
    }

    public RvTemplateAdapter(MainActivity mainActivity, ArrayList<String> arrayList, ArrayList<String> arrayList2, int i) {
        this.mainActivity = mainActivity;
        this.categories = arrayList;
        this.thumbnails = arrayList2;
        this.screenWidth = i;
        this.newCategories.add("Pinpur");
        this.isFirstClick = true;
    }

    public RvTemplateAdapter(MainActivity mainActivity, String str, ArrayList<String> arrayList, int i) {
        this.mainActivity = mainActivity;
        this.thumbnails = arrayList;
        this.category = str;
        this.screenWidth = i;
        this.isFirstClick = true;
    }

    public ViewHolderCollagePattern onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolderCollagePattern(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_templates, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolderCollagePattern viewHolderCollagePattern, int i) {
        String stringBuilder;
        int dp2px = (this.screenWidth / 2) - DensityUtil.dp2px(this.mainActivity, 12.0f);
        viewHolderCollagePattern.ivThumb.getLayoutParams().width = dp2px;
        LayoutParams layoutParams = viewHolderCollagePattern.ivThumb.getLayoutParams();
        double d = dp2px;
        Double.isNaN(d);
        Double.isNaN(d);
        layoutParams.height = (int) (d * 1.7777777777777777d);
        String str = "/";
        String str2 = "file:///android_asset/Thumbnails/";
        StringBuilder stringBuilder2;
        if (this.categories != null) {
            viewHolderCollagePattern.ivThumb.setPadding(10, 10, 10, 0);
            viewHolderCollagePattern.llWrapper.setBackgroundColor(Color.parseColor(ContractsUtil.templateCategories.get(this.categories.get(i))));
            viewHolderCollagePattern.tvName.setText(this.categories.get(i));
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str2);
            stringBuilder2.append(this.categories.get(i));
            stringBuilder2.append(str);
            stringBuilder2.append(this.thumbnails.get(i));
            stringBuilder = stringBuilder2.toString();
            if (this.newCategories.contains(this.categories.get(i))) {
                viewHolderCollagePattern.ivNew.setVisibility(View.VISIBLE);
            } else {
                viewHolderCollagePattern.ivNew.setVisibility(View.GONE);
            }
        } else {
            viewHolderCollagePattern.tvName.setVisibility(View.GONE);
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str2);
            stringBuilder2.append(this.category);
            stringBuilder2.append(str);
            stringBuilder2.append(this.thumbnails.get(i));
            stringBuilder = stringBuilder2.toString();
        }
        Glide.with(this.mainActivity).load(Uri.parse(stringBuilder)).into(viewHolderCollagePattern.ivThumb);

        viewHolderCollagePattern.setItemClickListener(new ItemClickListener() {
            public void onItemClick(View view, int i) {
                long currentTimeMillis = System.currentTimeMillis();
                if (RvTemplateAdapter.this.isFirstClick || currentTimeMillis - RvTemplateAdapter.this.mLastClickTime >= 3000) {
                    RvTemplateAdapter.this.mLastClickTime = currentTimeMillis;
                    RvTemplateAdapter.this.isFirstClick = false;
                    if (RvTemplateAdapter.this.categories != null) {
                        RvTemplateAdapter.this.mainActivity.selectTempCategory(RvTemplateAdapter.this.categories.get(i));
                        return;
                    }
                    AppUtil.mainPermissionGranted(RvTemplateAdapter.this.mainActivity, "android.permission.WRITE_EXTERNAL_STORAGE", RvTemplateAdapter.this.category, RvTemplateAdapter.this.thumbnails.get(i).replace(".jpg", ""), null);
                }
            }
        });
    }

    public int getItemCount() {
        ArrayList arrayList = this.thumbnails;
        return arrayList != null ? arrayList.size() : 0;
    }
}
