package com.xyz.vehiclemanager.favourite.Room;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.xyz.vehiclemanager.favourite.model.FavoriteCarModel;

import java.util.List;

@Dao
public interface FavoriteCarDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertCarFavorite(FavoriteCarModel favoriteCarModel);

    @Query("select * from FavoriteCar")
    List<FavoriteCarModel> getFavoriteCarList();

    @Query(" Delete from FavoriteCar where modelId=:modelId")
    void deleteCarFavorite(String modelId);
}
