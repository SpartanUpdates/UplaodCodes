package com.unitedvideos.Adapter;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import com.unitedvideos.R;
import com.unitedvideos.activity.DynamicTextFieldActivity;

import java.util.ArrayList;

import androidx.recyclerview.widget.RecyclerView;

public class DynamicTextAdapter extends RecyclerView.Adapter<DynamicTextHOlder> {
    private static Context context;
    private ArrayList<String> listtext;

    public DynamicTextAdapter(ArrayList<String> arrayList, Context context) {
        this.listtext = arrayList;
        DynamicTextAdapter.context = context;
    }

    public DynamicTextHOlder a(ViewGroup viewGroup, int i) {
        return new DynamicTextHOlder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_dyanmic_text_item, null));
    }

    public void a() {
        ((DynamicTextFieldActivity) context).f();
    }

    public void a(int i) {
        ((DynamicTextFieldActivity) context).a(i);
    }

    public void a(final DynamicTextHOlder dynamicTextHOlderVar, final int is) {
        EditText editText;
        int i2;
        dynamicTextHOlderVar.a.setHint((CharSequence) this.listtext.get(is));
        Log.e("TAG", "context: " + dynamicTextHOlderVar.a.getText().toString());
        if (is == this.listtext.size() - 1) {
            editText = dynamicTextHOlderVar.a;
            i2 = 268435462;
        } else {
            editText = dynamicTextHOlderVar.a;
            i2 = 5;
        }
        editText.setImeOptions(i2);
        dynamicTextHOlderVar.a.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                listtext.set(is, dynamicTextHOlderVar.a.getText().toString());
                Log.e("TAG", "onTextChanged: " + i + dynamicTextHOlderVar.a.getText().toString());
            }
        });
        dynamicTextHOlderVar.a.setOnEditorActionListener(new OnEditorActionListener() {

            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i == 5) {
                    a(i);
                    return true;
                } else if (i != 6) {
                    return false;
                } else {
                    a();
                    return true;
                }
            }
        });
        dynamicTextHOlderVar.a.setOnTouchListener(new OnTouchListener() {

            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (!dynamicTextHOlderVar.a.hasFocus()) {
                    return false;
                }
                view.getParent().requestDisallowInterceptTouchEvent(true);
                if ((motionEvent.getAction() & 255) != 8) {
                    return false;
                }
                view.getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            }
        });
    }

    public int getItemCount() {
        Log.e("TAG", "getItemCount: " + listtext.size());
        return this.listtext.size();

    }

    public int getItemViewType(int i) {
        return i;
    }


    public void onBindViewHolder(DynamicTextHOlder viewHolder, int i) {
        a(viewHolder, i);
    }

    public DynamicTextHOlder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return a(viewGroup, i);
    }
}