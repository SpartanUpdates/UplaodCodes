package com.wavymusic.Fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.wavymusic.Adapter.ThemeCategoryAdapter;
import com.wavymusic.Model.ThemeHorizontalModel;
import com.wavymusic.Preferences.LanguagePref;
import com.wavymusic.ProgressBar.kprogresshud.KProgressHUD;
import com.wavymusic.R;
import com.wavymusic.Retrofit.APIClient;
import com.wavymusic.Retrofit.APIInterface;
import com.wavymusic.Retrofit.AppConstant;
import com.wavymusic.UnityPlayerActivity;
import com.wavymusic.Utils.Utils;
import com.wavymusic.activity.HomeActivity;
import com.wavymusic.application.MyApplication;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ThemeFragmentByCategory extends Fragment {

    public static LanguagePref sharedpreferences;
    public int id;
    public Handler i;
    LinearLayout llInternetCheck;
    Button btnRetry;
    RelativeLayout rlLoadingTheme;
    RecyclerView rvVideos;
    String offlineThemeData;
    int CategoryId = -1;
    String CatId;
    SharedPreferences pref;
    GridLayoutManager gridLayoutManager;
    KProgressHUD hud;
    Long timestamps;

    private String WhsThemeItem;
    Date date = new Date();
    //    SwipeRefreshLayout mSwipeRefreshLayout;
    private ArrayList<ThemeHorizontalModel> ThemeListCategoryWise = new ArrayList<>();
    private ThemeCategoryAdapter themeAdapter;
    APIInterface apiInterface;

    public static ThemeFragmentByCategory newInstance(int catid) {
        ThemeFragmentByCategory fragment = new ThemeFragmentByCategory();
        Bundle bundle = new Bundle();
        bundle.putInt("CategoryId", catid);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            CategoryId = getArguments().getInt("CategoryId");
            CatId = String.valueOf(CategoryId);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_theme, container, false);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        sharedpreferences = LanguagePref.a(getActivity());
        apiInterface = APIClient.getClient().create(APIInterface.class);
        BindView(view);
        SetListener();
        if (ThemeListCategoryWise != null && ThemeListCategoryWise.size() == 0) {
            if (CategoryId == 111) {
                WhatsNewData();
            } else {
                SetThemeData();
            }
        } else {
            SetUpAdapter();
        }
        return view;
    }

    private void WhatsNewData() {
        /*Old Code*/
        getNewgetOfflineCategory(getActivity(), "NewTheme_v3");
        if (WhsThemeItem != null) {
            new WhatsNewData().execute(WhsThemeItem);
        }
    }

    private void SetThemeData() {
        String id = pref.getString(CatId, null);
        if (id != null && !id.equals("")) {
            getOfflineCategory(getActivity(), CatId);
            if (offlineThemeData != null) {
                new GetofflineThemeData().execute();
            } else {
                llInternetCheck.setVisibility(View.VISIBLE);
                rlLoadingTheme.setVisibility(View.GONE);
                Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void BindView(View view) {
//        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
        rvVideos = view.findViewById(R.id.rvVideos);
        llInternetCheck = view.findViewById(R.id.llRetry);
        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
        rlLoadingTheme = view.findViewById(R.id.rl_loading_pager);
        rvVideos.setNestedScrollingEnabled(false);
        rvVideos.setHasFixedSize(true);
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    startActivity(new Intent(getActivity(), HomeActivity.class));
                    getActivity().finish();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
        /*mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    ThemeListCategoryWise.clear();
                    GetCategoryOfTheme();
                    mSwipeRefreshLayout.setRefreshing(false);
                } else {
                    mSwipeRefreshLayout.setRefreshing(false);
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_SHORT).show();
                }
            }
        });*/

    }

    private void getNewgetOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        WhsThemeItem = pref.getString(key, null);
//        timestamps = pref.getLong(key + "_value", 0);
    }


    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlineThemeData = pref.getString(key, null);
//        timestamps = pref.getLong(key + "_value", 0);
    }


    private void SetUpAdapter() {
        RecyclerView recyclerView;
        int i2 = 0;
        gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        themeAdapter = new ThemeCategoryAdapter(getActivity(), ThemeListCategoryWise);
        rvVideos.setLayoutManager(gridLayoutManager);
        rvVideos.setItemAnimator(new DefaultItemAnimator());
        rvVideos.setAdapter(themeAdapter);
        if (MyApplication.ThemePosition == -1) {
            recyclerView = this.rvVideos;
        } else {
            recyclerView = this.rvVideos;
            i2 = MyApplication.ThemePosition;
        }
        recyclerView.scrollToPosition(i2);
        rvVideos.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(gridLayoutManager.findFirstVisibleItemPosition());
                stringBuilder.append("");
                MyApplication.ThemePosition = gridLayoutManager.findFirstVisibleItemPosition();
            }
        });
        themeAdapter.notifyDataSetChanged();
//        Log.e("TAG", "IsHomeAds" + MyApplication.IsHomeAdsDisplay);
        if (!MyApplication.IsHomeAdsDisplay && MyApplication.fbinterstitialAd != null && MyApplication.fbinterstitialAd.isAdLoaded()) {
            MyApplication.IsHomeAdsDisplay = true;
            MyApplication.AdsId = 8;
//            Log.e("TAG", "IsHomeDisplay" + MyApplication.IsHomeAdsDisplay);
            MyApplication.fbinterstitialAd.show();
            /*try {
                hud = KProgressHUD.create(getActivity())
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Showing Ads")
                        .setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (UnityPlayerActivity.mInterstitialAd != null && UnityPlayerActivity.mInterstitialAd.isLoaded()) {
                        MyApplication.IsHomeAdsDisplay = true;
                        UnityPlayerActivity.mInterstitialAd.show();
                    }
                }
            }, 2000);*/
        }
    }


    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }


    @SuppressLint("StaticFieldLeak")
    public class GetofflineThemeData extends AsyncTask<Void, Void, Void> {

        protected void onPreExecute() {
            Log.e("TAG", "Fragment->Getoffline Data Called...");
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlineThemeData);
                JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
                for (int j = 0; j < jSONArray4.length(); j++) {
                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                    themeModel.setThemeid(jsonobjecttheme.getString("id"));
                    themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                    themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                    themeModel.setImage(AppConstant.ThemeThumburl + jsonobjecttheme.getString("theme_thumbnail"));
                    themeModel.setSmall_Thumbnail(AppConstant.SmallThemeThumbrl + jsonobjecttheme.getString("small_thumbnail"));
                    themeModel.setAnimsoundurl(AppConstant.SoundUrl + jsonobjecttheme.getString("sound_file"));
                    themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                    themeModel.setAnimSoundPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                    themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                    themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                    themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                    themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                    ThemeListCategoryWise.add(themeModel);

                    if (isAdded()) {
                        if (Utils.checkConnectivity(getActivity(), false)) {
                            if (MyApplication.getInstance().IsNativeAdsLoaded) {
                                if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                    themeModel.setNativeAds(true);
                                    ThemeListCategoryWise.add(j, themeModel);
                                }
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(Void result) {
            rlLoadingTheme.setVisibility(View.GONE);
            SetUpAdapter();
        }
    }


    @SuppressLint("StaticFieldLeak")
    public class WhatsNewData extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected String doInBackground(String... arg0) {
            Log.e("TAG", "WhatsNewData Called..." + arg0[0]);
            try {
                JSONObject jsonObj = new JSONObject(arg0[0]);
                JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
                for (int j = 0; j < jSONArray4.length(); j++) {
                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                    themeModel.setThemeid(jsonobjecttheme.getString("id"));
                    themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                    themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                    themeModel.setImage(AppConstant.ThemeThumburl + jsonobjecttheme.getString("theme_thumbnail"));
                    themeModel.setSmall_Thumbnail(AppConstant.SmallThemeThumbrl + jsonobjecttheme.getString("small_thumbnail"));
                    themeModel.setAnimsoundurl(AppConstant.SoundUrl + jsonobjecttheme.getString("sound_file"));
                    themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                    themeModel.setAnimSoundPath(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                    themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                    themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                    themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                    themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                    if (themeModel.isNewRealise().equals("1")) {
                        ThemeListCategoryWise.add(themeModel);
                    }
                    if (isAdded()) {
                        if (Utils.checkConnectivity(getActivity(), false)) {
                            if (MyApplication.getInstance().IsNativeAdsLoaded) {
                                if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                    themeModel.setNativeAds(true);
                                    ThemeListCategoryWise.add(j, themeModel);
                                }
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(String result) {
            rlLoadingTheme.setVisibility(View.GONE);
            SetUpAdapter();
        }
    }

//    @Override
//    public void onDestroy() {
//        if (MyApplication.fbinterstitialAd != null) {
//            MyApplication.fbinterstitialAd.destroy();
//        }
//        super.onDestroy();
//    }
}
