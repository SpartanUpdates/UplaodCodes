package com.esc.tarotcardreading;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class NewListAdapter extends BaseAdapter {
    Activity activity;
    Context context;
    ArrayList<String> listitem;
    TextView txtview;

    public Object getItem(int i) {
        return null;
    }

    public long getItemId(int i) {
        return 0;
    }

    NewListAdapter(Context context, Activity activity, ArrayList<String> arrayList) {
        this.context = context;
        this.activity = activity;
        this.listitem = arrayList;
    }

    public int getCount() {
        return this.listitem.size();
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = ((LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.newlistitem, viewGroup, false);
        }
        TextView textView = (TextView) view.findViewById(R.id.txtview);
        this.txtview = textView;
        textView.setText((CharSequence) this.listitem.get(i));
        this.txtview.setTypeface(TaroQuestionsActivity.face3);
        return view;
    }
}
