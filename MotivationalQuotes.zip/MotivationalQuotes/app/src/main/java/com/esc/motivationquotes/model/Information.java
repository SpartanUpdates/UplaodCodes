package com.esc.motivationquotes.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.ArrayList;

public class Information implements Serializable {
    @SerializedName("categories")
    private ArrayList<Category> categories;
    @SerializedName("sections")
    private ArrayList<Section> sections;

    public ArrayList<Section> getSections() {
        return this.sections;
    }

    public ArrayList<Category> getCategories() {
        return this.categories;
    }
}
