package com.kotlinz.festivalstorymaker.Models;

import java.io.Serializable;

public class h implements Serializable {
    public String e;
    public String f;
    public String g;
    public String h;
    public String i;
    public String j;
    public String k;
    public String l;
    public String m;
    public String n;
    public String o;
    public String p;
    public String q;
    public String r;
    public String s;
    public String t;

    public h() {
        String str = "";
        this.e = str;
        this.f = str;
        this.g = str;
        this.i = str;
        this.j = str;
        this.k = str;
        this.m = str;
        this.n = str;
        this.o = str;
        this.p = str;
        this.q = str;
        this.r = str;
        this.s = str;
        this.t = str;
    }
}
