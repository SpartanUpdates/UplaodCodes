import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:rto_app/Owner%20Info%20Screen/controllers/controllers.dart';
import 'package:rto_app/Owner%20Info%20Screen/view/owner_info.dart';
import 'package:rto_app/Utils/utils.dart';
import 'package:velocity_x/src/extensions/context_ext.dart';
import 'package:velocity_x/src/flutter/padding.dart';
import 'package:velocity_x/src/flutter/text.dart';

class FamousPersonScreen extends StatelessWidget {
  MainControllers controller = Get.put(MainControllers());

  String type;
  FamousPersonScreen(this.type);

  List<String> nameList = [];
  List<String> numList = [];

  matchString() {
    if (type == "Actresses") {
      nameList = FamousPersonList.actressesname;
      numList = FamousPersonList.actressesnum;
    }
    if (type == "Dancer") {
      nameList = FamousPersonList.dancersname;
      numList = FamousPersonList.dancersnum;
    }
    if (type == "Singer") {
      nameList = FamousPersonList.singersname;
      numList = FamousPersonList.singersnum;
    }
    if (type == "Actor") {
      nameList = FamousPersonList.actorsname;
      numList = FamousPersonList.actorsnum;
    }
    if (type == "Politician") {
      nameList = FamousPersonList.politiciansname;
      numList = FamousPersonList.politiciansnum;
    }
    if (type == "Sports Man") {
      nameList = FamousPersonList.sportspersonsname;
      numList = FamousPersonList.sportspersonsnum;
    }
    if (type == "Business Man") {
      nameList = FamousPersonList.bussinessmanname;
      numList = FamousPersonList.bussinessmannum;
    }
  }

  @override
  Widget build(BuildContext context) {
    matchString();
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Colors.transparent));
    return Material(
      child: SafeArea(
        child: Scaffold(
          backgroundColor: context.primaryColor,
          body: NestedScrollView(
            physics: BouncingScrollPhysics(),
            floatHeaderSlivers: true,
            headerSliverBuilder:
                (BuildContext context, bool innerBoxIsScrolled) {
              return <Widget>[
                SliverAppBar(
                  backgroundColor: context.primaryColor,
                  title: Text(
                    type,
                    style: TextStyle(
                        fontSize: 16.5,
                        color: context.accentColor,
                        fontFamily: "Circular Bold"),
                  ),
                  leading: Card(
                    color: context.primaryColor,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                        side: BorderSide(
                            width: 0.3, color: context.primaryColor)),
                    child: InkWell(
                      customBorder: new CircleBorder(),
                      onTap: () {
                        Future.delayed(const Duration(milliseconds: 350), () {
                          Navigator.pop(context);
                        });
                      },
                      splashColor: Colors.black54,
                      child: Padding(
                        padding: EdgeInsets.all(10),
                        child: new Icon(
                          Icons.arrow_back_ios,
                          size: 20,
                        ),
                      ),
                    ),
                  ).pOnly(left: 10),
                )
              ];
            },
            body: Column(
              children: [
                Expanded(
                  child: Container(
                    color: context.primaryColor,
                    child: ListView.builder(
                        physics: BouncingScrollPhysics(),
                        itemCount: nameList.length,
                        itemBuilder: (context, index) {
                          return Container(
                            child: Card(
                              elevation: 0,
                              color: context.cardColor,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              child: ListTile(
                                leading: type == "Actresses"
                                    ? Opacity(
                                        opacity: 0.7,
                                        child: Image.asset(
                                          "assets/images/casting.png",
                                          height: 35,
                                          width: 35,
                                        ),
                                      )
                                    : type == "Dancer"
                                        ? Opacity(
                                            opacity: 0.7,
                                            child: Image.asset(
                                              "assets/images/dancing.png",
                                              height: 35,
                                              width: 35,
                                            ),
                                          )
                                        : type == "Singer"
                                            ? Opacity(
                                                opacity: 0.7,
                                                child: Image.asset(
                                                  "assets/images/singer.png",
                                                  height: 35,
                                                  width: 35,
                                                ),
                                              )
                                            : type == "Actor"
                                                ? Opacity(
                                                    opacity: 0.7,
                                                    child: Image.asset(
                                                      "assets/images/actor.png",
                                                      height: 35,
                                                      width: 35,
                                                    ),
                                                  )
                                                : type == "Sports Man"
                                                    ? Opacity(
                                                        opacity: 0.7,
                                                        child: Image.asset(
                                                          "assets/images/running.png",
                                                          height: 35,
                                                          width: 35,
                                                        ),
                                                      )
                                                    : Opacity(
                                                        opacity: 0.7,
                                                        child: Image.asset(
                                                          "assets/images/businessman.png",
                                                          height: 35,
                                                          width: 35,
                                                        ),
                                                      ),
                                title: Text(nameList[index],
                                        style: TextStyle(
                                            fontFamily: "Circular Medium",
                                            color: Theme.of(context).hintColor))
                                    .text
                                    .size(16)
                                    .make()
                                    .pOnly(bottom: 3.2),
                                subtitle: Text(numList[index],
                                        style: TextStyle(
                                            fontFamily: "Circular Medium",
                                            color: Colors.grey))
                                    .text
                                    .size(13)
                                    .make()
                                    .pOnly(top: 3.2),
                                trailing: Card(
                                  color: Theme.of(context).backgroundColor,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(25),
                                      side: BorderSide(
                                          width: 0.3,
                                          color: context.primaryColor)),
                                  child: InkWell(
                                    customBorder: new CircleBorder(),
                                    onTap: () {
                                      Get.to(OwnerInfo(false, numList[index]));
                                      controller.fetchOwnerData(
                                          context, numList[index]);
                                    },
                                    splashColor: Colors.red,
                                    child: Padding(
                                      padding: EdgeInsets.all(5),
                                      child: new Icon(
                                        Icons.navigate_next_rounded,
                                        size: 35,
                                        color: Colors.blueGrey,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ).px(10).py(2),
                          );
                        }).pOnly(top: 5),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
