package com.unitedvideos.Adapter;

import android.view.View;
import android.widget.EditText;

import com.unitedvideos.R;

import androidx.recyclerview.widget.RecyclerView;


public class DynamicTextHOlder extends RecyclerView.ViewHolder {
    public EditText a;

    public DynamicTextHOlder(View view) {
        super(view);
        this.a = (EditText) view.findViewById(R.id.et_row_single);
    }

}