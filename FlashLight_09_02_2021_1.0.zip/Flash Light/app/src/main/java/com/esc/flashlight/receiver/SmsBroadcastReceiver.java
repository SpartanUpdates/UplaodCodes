package com.esc.flashlight.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.esc.flashlight.flashlight.FlashService;
import com.esc.flashlight.util.FlashAlertUtil;

public class SmsBroadcastReceiver extends BroadcastReceiver {
    private static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
    private static final String TAG = "SmsBroadcastReceiver";

    public void onReceive(Context context, Intent intent) {
        if (SMS_RECEIVED.equals(intent.getAction())) {
            Bundle extras = intent.getExtras();
            if (extras != null && ((Object[]) extras.get("pdus")).length > 0) {
                Log.d(TAG, "RECEIVE MSG");
                handleReceiveMsg(context, intent);
            }
        }
    }

    private void handleReceiveMsg(Context context, Intent intent) {
        if (FlashAlertUtil.checkedReceiveMsg(context, intent)) {
            FlashService.runIntentInService(context, intent);
            setResult(-1, null, null);
        }
    }
}
