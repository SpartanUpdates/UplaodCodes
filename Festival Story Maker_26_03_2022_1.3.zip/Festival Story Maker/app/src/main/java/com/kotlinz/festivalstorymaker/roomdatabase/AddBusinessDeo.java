package com.kotlinz.festivalstorymaker.roomdatabase;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.kotlinz.festivalstorymaker.Model.customer.AddCustomer;

import java.util.List;

@Dao
public interface AddBusinessDeo {
    @Insert
    void insertBusinessDetails(AddCustomer addBusiness);

    @Query("select * from AddCustomer")
    List<AddCustomer> getBusinessList();


    @Query("UPDATE AddCustomer SET Name=:Name,MobileNo=:MobileNo, Email=:Email, Occupation=:Occupation, City=:City, DeviceId=:DeviceId, DeviceType=:DeviceType WHERE id=:id")
    void UpdateColumnById(String Name, String MobileNo, String Email, String Occupation, String City, String DeviceId, String DeviceType, int id);

    @Query(" Delete from AddCustomer where id=:id")
    void deleteBusinessData(int id);
}
