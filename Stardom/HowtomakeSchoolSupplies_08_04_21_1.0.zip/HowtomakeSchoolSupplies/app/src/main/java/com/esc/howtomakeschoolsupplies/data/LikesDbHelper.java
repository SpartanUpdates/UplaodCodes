package com.esc.howtomakeschoolsupplies.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LikesDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "likes.db";

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    public LikesDbHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE likes (_id INTEGER PRIMARY KEY AUTOINCREMENT, article_id INTEGER DEFAULT -1);");
        sQLiteDatabase.execSQL("CREATE TABLE favorites (_id INTEGER PRIMARY KEY AUTOINCREMENT, article_id INTEGER DEFAULT -1);");
    }
}
