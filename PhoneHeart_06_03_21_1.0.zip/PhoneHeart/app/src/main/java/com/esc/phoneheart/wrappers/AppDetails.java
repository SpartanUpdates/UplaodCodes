package com.esc.phoneheart.wrappers;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.pm.ResolveInfo.DisplayNameComparator;
import android.os.Build;
import android.util.Log;
import android.widget.ListView;
import com.esc.phoneheart.utility.GlobalData;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AppDetails {
    public Context a;
    public ListView list;
    public ArrayList<PackageData> res = new ArrayList();

    public AppDetails(Context context) {
        this.a = context;
    }

    public ArrayList<String> getAllInstalledPkgList() {
        ArrayList arrayList = new ArrayList();
        Context context = this.a;
        if (context == null) {
            return arrayList;
        }
        try {
            int i = 0;
            List installedPackages = context.getPackageManager().getInstalledPackages(0);
            while (i < installedPackages.size()) {
                PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
                if (packageInfo.versionName != null) {
                    arrayList.add(packageInfo.packageName);
                }
                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    public ArrayList<PackageData> getAllInstalledPkgListDetail(Context context) {
        ArrayList arrayList = new ArrayList();
        Context context2 = this.a;
        if (context2 == null) {
            return arrayList;
        }
        try {
            int i = 0;
            List installedPackages = context2.getPackageManager().getInstalledPackages(0);
            while (i < installedPackages.size()) {
                PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
                PackageData packageData = new PackageData();
                if (packageInfo.versionName != null) {
                    String str = packageInfo.packageName;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(context.getPackageName());
                    if (!str.equalsIgnoreCase(stringBuilder.toString())) {
                        str = packageInfo.applicationInfo.loadLabel(this.a.getPackageManager()).toString();
                        packageData.appname = str;
                        if (!str.contains(".")) {
                            packageData.pname = packageInfo.packageName;
                            packageData.datadir = packageInfo.applicationInfo.dataDir;
                            packageData.saurcedir = packageInfo.applicationInfo.sourceDir;
                            packageData.apkPath = packageInfo.applicationInfo.publicSourceDir;
                            packageData.versionName = packageInfo.versionName;
                            packageData.versionCode = packageInfo.versionCode;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                packageData.installLocation = packageInfo.installLocation;
                            }
                            arrayList.add(packageData);
                        }
                    }
                }
                i++;
            }
            try {
                Collections.sort(arrayList, new Comparator<PackageData>() {
                    public int compare(PackageData packageData, PackageData packageData2) {
                        return packageData.appname.compareToIgnoreCase(packageData2.appname);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return arrayList;
    }

    public ArrayList<PackageData> getApplicationsInfo(Context context) {
        Intent intent = new Intent("android.intent.action.MAIN", null);
        intent.addCategory("android.intent.category.LAUNCHER");
        PackageManager packageManager = context.getPackageManager();
        List<ResolveInfo> queryIntentActivities = packageManager.queryIntentActivities(intent, 0);
        try {
            Collections.sort(queryIntentActivities, new DisplayNameComparator(packageManager));
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (ResolveInfo resolveInfo : queryIntentActivities) {
            PackageData packageData = new PackageData();
            packageData.appname = resolveInfo.activityInfo.applicationInfo.loadLabel(packageManager).toString();
            try {
                packageManager.getApplicationIcon(resolveInfo.activityInfo.packageName);
                String str = resolveInfo.activityInfo.packageName;
                packageData.pname = str;
                try {
                    if (!str.equalsIgnoreCase("")) {
                        if (!(packageData.appname.equalsIgnoreCase("Google play services") || packageData.appname.equalsIgnoreCase("Google play store"))) {
                            if (packageData.appname.equalsIgnoreCase("Google play music")) {
                            }
                            ApplicationInfo applicationInfo = resolveInfo.activityInfo.applicationInfo;
                            packageData.datadir = applicationInfo.dataDir;
                            packageData.saurcedir = applicationInfo.sourceDir;
                            packageData.apkPath = applicationInfo.publicSourceDir;
                            packageData.ischecked = true;
                            this.res.add(packageData);
                        }
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            } catch (NameNotFoundException e3) {
                e3.printStackTrace();
            }
        }
        return this.res;
    }

    public ArrayList<PackageData> getIgnoredApps(Context context) {
        ArrayList allInstalledPkgListDetail = getAllInstalledPkgListDetail(context);
        try {
            ArrayList arrayList = (ArrayList) GlobalData.getObj(context, "ignored_apps");
            if (arrayList != null) {
                for (int i = 0; i < arrayList.size(); i++) {
                    String str = (String) arrayList.get(i);
                    for (int i2 = 0; i2 < allInstalledPkgListDetail.size(); i2++) {
                        String str2 = ((PackageData) allInstalledPkgListDetail.get(i2)).pname;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("");
                        stringBuilder.append(str);
                        if (str2.equalsIgnoreCase(stringBuilder.toString())) {
                            ((PackageData) allInstalledPkgListDetail.get(i2)).ignored = true;
                        }
                    }
                }
            }
        } catch (Exception unused) {
        }
        return allInstalledPkgListDetail;
    }

    public ArrayList<PackageData> getInstalledApps() {
        int i = 0;
        List installedPackages = this.a.getPackageManager().getInstalledPackages(0);
        while (i < installedPackages.size()) {
            PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
            if (packageInfo.versionName != null) {
                PackageData packageData = new PackageData();
                String charSequence = packageInfo.applicationInfo.loadLabel(this.a.getPackageManager()).toString();
                packageData.appname = charSequence;
                try {
                    if (!charSequence.equalsIgnoreCase("Google play services")) {
                        if (!packageData.appname.equalsIgnoreCase("Google play store")) {
                            if (packageData.appname.equalsIgnoreCase("PCleaner")) {
                            }
                            packageData.pname = packageInfo.packageName;
                            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
                            packageData.datadir = applicationInfo.dataDir;
                            packageData.saurcedir = applicationInfo.sourceDir;
                            packageData.apkPath = applicationInfo.publicSourceDir;
                            packageData.versionName = packageInfo.versionName;
                            packageData.versionCode = packageInfo.versionCode;
                            this.res.add(packageData);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            i++;
        }
        return this.res;
    }

    public ArrayList<PackageData> getInstalledAppsWithNames() {
        PackageManager packageManager = this.a.getPackageManager();
        int i = 0;
        List installedPackages = packageManager.getInstalledPackages(0);
        while (i < installedPackages.size()) {
            PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
            if (packageInfo.versionName != null) {
                PackageData packageData = new PackageData();
                packageData.appname = packageInfo.applicationInfo.loadLabel(packageManager).toString();
                try {
                    packageManager.getApplicationIcon(packageInfo.packageName);
                    try {
                        if (!packageData.appname.equalsIgnoreCase("Google play services")) {
                            if (packageData.appname.equalsIgnoreCase("Google play store")) {
                            }
                            packageData.pname = packageInfo.packageName;
                            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
                            packageData.datadir = applicationInfo.dataDir;
                            packageData.saurcedir = applicationInfo.sourceDir;
                            packageData.apkPath = applicationInfo.publicSourceDir;
                            packageData.versionName = packageInfo.versionName;
                            packageData.versionCode = packageInfo.versionCode;
                            this.res.add(packageData);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } catch (NameNotFoundException e2) {
                    e2.printStackTrace();
                }
            }
            i++;
        }
        return this.res;
    }

    public ArrayList<PackageData> getInstalledGameUserApps() {
        String str = "PCleaner";
        try {
            List installedPackages = this.a.getPackageManager().getInstalledPackages(0);
            for (int i = 0; i < installedPackages.size(); i++) {
                PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
                PackageData packageData = new PackageData();
                String str2 = "Systemmm ";
                if (packageInfo.applicationInfo.sourceDir.startsWith("/data/app/")) {
                    Log.d(str2, "no system");
                    if (packageInfo.versionName != null) {
                        String charSequence = packageInfo.applicationInfo.loadLabel(this.a.getPackageManager()).toString();
                        packageData.appname = charSequence;
                        try {
                            if (!charSequence.equalsIgnoreCase("Google play services")) {
                                if (!packageData.appname.equalsIgnoreCase("Google play store")) {
                                    if (!packageData.appname.equalsIgnoreCase(str)) {
                                        if (packageData.appname.equals(str)) {
                                        }
                                        packageData.pname = packageInfo.packageName;
                                        try {
                                            packageData.appsize = (long) this.a.getPackageManager().getApplicationInfo(packageData.pname, 0).publicSourceDir.length();
                                        } catch (NameNotFoundException e) {
                                            e.printStackTrace();
                                        }
                                        packageData.datadir = packageInfo.applicationInfo.dataDir;
                                        packageData.saurcedir = packageInfo.applicationInfo.sourceDir;
                                        packageData.apkPath = packageInfo.applicationInfo.publicSourceDir;
                                        packageData.versionName = packageInfo.versionName;
                                        packageData.versionCode = packageInfo.versionCode;
                                        packageData.ischecked = true;
                                        this.res.add(packageData);
                                    }
                                }
                            }
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    }
                } else {
                    Log.d(str2, "Systemm");
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SIZE OF RES ");
            stringBuilder.append(this.res.size());
            Log.d("------ ", stringBuilder.toString());
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        return this.res;
    }

    public ArrayList<String> getInstalledPackeageNames() {
        int i = 0;
        List installedPackages = this.a.getPackageManager().getInstalledPackages(0);
        ArrayList arrayList = new ArrayList();
        while (i < installedPackages.size()) {
            PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
            if (packageInfo.versionName != null) {
                arrayList.add(packageInfo.packageName);
            }
            i++;
        }
        return arrayList;
    }

    public ArrayList<PackageData> getInstalledSystemApps() {
        try {
            int i = 0;
            List installedPackages = this.a.getPackageManager().getInstalledPackages(0);
            while (i < installedPackages.size()) {
                PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
                if (packageInfo.versionName != null) {
                    PackageData packageData = new PackageData();
                    if ((packageInfo.applicationInfo.flags & 1) != 0) {
                        packageData.appname = packageInfo.applicationInfo.loadLabel(this.a.getPackageManager()).toString();
                        String str = packageInfo.packageName;
                        packageData.pname = str;
                        packageData.datadir = packageInfo.applicationInfo.dataDir;
                        packageData.saurcedir = packageInfo.applicationInfo.sourceDir;
                        packageData.apkPath = packageInfo.applicationInfo.publicSourceDir;
                        packageData.versionName = packageInfo.versionName;
                        packageData.versionCode = packageInfo.versionCode;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            packageData.installLocation = packageInfo.installLocation;
                        }
                        if (!str.equalsIgnoreCase("")) {
                            this.res.add(packageData);
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(packageData.appname);
                            stringBuilder.append("  ");
                            stringBuilder.append(packageData.pname);
                            Log.d("PackageInfoStruct", stringBuilder.toString());
                        }
                    }
                }
                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this.res;
    }

    public ArrayList<PackageData> getInstalledUserApps() {
        try {
            int i = 0;
            List installedPackages = this.a.getPackageManager().getInstalledPackages(0);
            while (i < installedPackages.size()) {
                PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
                if (packageInfo.versionName != null) {
                    PackageData packageData = new PackageData();
                    if ((packageInfo.applicationInfo.flags & 1) == 0) {
                        String charSequence = packageInfo.applicationInfo.loadLabel(this.a.getPackageManager()).toString();
                        packageData.appname = charSequence;
                        try {
                            if (!charSequence.equalsIgnoreCase("Google play services")) {
                                if (packageData.appname.equalsIgnoreCase("Google play store")) {
                                }
                                charSequence = packageInfo.packageName;
                                packageData.pname = charSequence;
                                packageData.datadir = packageInfo.applicationInfo.dataDir;
                                packageData.saurcedir = packageInfo.applicationInfo.sourceDir;
                                packageData.apkPath = packageInfo.applicationInfo.publicSourceDir;
                                packageData.versionName = packageInfo.versionName;
                                packageData.versionCode = packageInfo.versionCode;
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    packageData.installLocation = packageInfo.installLocation;
                                }
                                if (!charSequence.equalsIgnoreCase("")) {
                                    if (!packageData.pname.equalsIgnoreCase("com.domobile.applock")) {
                                        this.res.add(packageData);
                                    }
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                i++;
            }
            try {
                Collections.sort(this.res, new Comparator<PackageData>() {
                    public int compare(PackageData packageData, PackageData packageData2) {
                        return packageData.appname.compareToIgnoreCase(packageData2.appname);
                    }
                });
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        } catch (Exception e22) {
            e22.printStackTrace();
        }
        return this.res;
    }

    public ArrayList<String> getInstalledUserAppsPkgs() {
        ArrayList arrayList = new ArrayList();
        try {
            int i = 0;
            List installedPackages = this.a.getPackageManager().getInstalledPackages(0);
            while (i < installedPackages.size()) {
                PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
                if (packageInfo.versionName != null) {
                    if ((packageInfo.applicationInfo.flags & 1) == 0) {
                        String charSequence = packageInfo.applicationInfo.loadLabel(this.a.getPackageManager()).toString();
                        try {
                            if (!charSequence.equalsIgnoreCase("Google play services")) {
                                if (charSequence.equalsIgnoreCase("Google play store")) {
                                }
                                String str = packageInfo.packageName;
                                if (!str.equalsIgnoreCase("")) {
                                    arrayList.add(str);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                i++;
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return arrayList;
    }
}
