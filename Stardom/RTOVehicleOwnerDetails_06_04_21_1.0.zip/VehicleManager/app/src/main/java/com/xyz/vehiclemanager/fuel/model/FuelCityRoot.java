package com.xyz.vehiclemanager.fuel.model;

import com.google.gson.annotations.SerializedName;

public class FuelCityRoot
{
    @SerializedName("statusCode")
    public String statusCode;
    @SerializedName("statusMessage")
    public String statusMessage;
    @SerializedName("data")
    public FuelCity data;

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public FuelCity getData() {
        return data;
    }

    public void setData(FuelCity data) {
        this.data = data;
    }
}
