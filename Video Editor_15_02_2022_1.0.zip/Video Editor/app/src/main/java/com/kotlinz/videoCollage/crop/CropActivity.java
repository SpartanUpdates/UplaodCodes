package com.kotlinz.videoCollage.crop;

import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.GridActivity;
import com.kotlinz.videoCollage.interfaces.OnSetImageStickerInterface;
import com.kotlinz.videoeditor.R;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.measurement.api.AppMeasurementSdk.ConditionalUserProperty;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class CropActivity extends AppCompatActivity {
    Bitmap bitmap;
    CropAdapter cropAdapter;
    CropImageView cropImageView;
    OnSetImageStickerInterface getSticker;
    ImageView imgBack;
    ImageView imgDone;
    ArrayList<String> list;
    RecyclerView recyclerviewCrop;


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_crop);
        inIt();
        bundle = (Bundle) Objects.requireNonNull(getIntent().getExtras());
        String str = ConditionalUserProperty.VALUE;
        String str2 = "path";
        if (Objects.equals(bundle.getString(str), "image")) {
            this.bitmap = BitmapFactory.decodeFile(getIntent().getExtras().getString(str2), new Options());
            cropSize(true, 1, 1);
        } else if (Objects.equals(getIntent().getExtras().getString(str), "sticker")) {
            this.bitmap = BitmapFactory.decodeFile(getIntent().getExtras().getString(str2), new Options());
            cropSize(true, 1, 1);
        }
        this.cropImageView.setImageBitmap(this.bitmap);
        this.list.addAll(Arrays.asList(getResources().getStringArray(R.array.cropName)));
        this.cropAdapter = new CropAdapter(this, this.list);
        this.recyclerviewCrop.setHasFixedSize(true);
        this.recyclerviewCrop.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        this.recyclerviewCrop.setAdapter(this.cropAdapter);
        this.recyclerviewCrop.addOnItemTouchListener(new RecyclerItemClickListener(this, new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int i) {
                String str = (String) CropActivity.this.list.get(i);
                if (str.equals("Custom")) {
                    CropActivity.this.cropImageView.setFixedAspectRatio(false);
                } else if (str.equals("Square")) {
                    CropActivity.this.cropSize(true, 1, 1);
                } else if (str.equals("1:2")) {
                    CropActivity.this.cropSize(true, 1, 2);
                } else if (str.equals("2:1")) {
                    CropActivity.this.cropSize(true, 2, 1);
                } else if (str.equals("2:3")) {
                    CropActivity.this.cropSize(true, 2, 3);
                } else if (str.equals("3:2")) {
                    CropActivity.this.cropSize(true, 3, 2);
                } else if (str.equals("3:4")) {
                    CropActivity.this.cropSize(true, 3, 4);
                } else if (str.equals("3:5")) {
                    CropActivity.this.cropSize(true, 3, 5);
                } else if (str.equals("4:3")) {
                    CropActivity.this.cropSize(true, 4, 3);
                } else if (str.equals("4:5")) {
                    CropActivity.this.cropSize(true, 4, 5);
                } else if (str.equals("4:7")) {
                    CropActivity.this.cropSize(true, 4, 7);
                } else if (str.equals("5:3")) {
                    CropActivity.this.cropSize(true, 5, 3);
                } else if (str.equals("5:4")) {
                    CropActivity.this.cropSize(true, 5, 4);
                } else if (str.equals("5:6")) {
                    CropActivity.this.cropSize(true, 5, 6);
                } else if (str.equals("5:7")) {
                    CropActivity.this.cropSize(true, 5, 7);
                } else if (str.equals("9:16")) {
                    CropActivity.this.cropSize(true, 9, 16);
                } else if (str.equals("16:9")) {
                    CropActivity.this.cropSize(true, 16, 9);
                }
            }
        }));
    }

    private void cropSize(boolean z, int i, int i2) {
        this.cropImageView.setFixedAspectRatio(z);
        this.cropImageView.setAspectRatio(i, i2);
    }

    public void onBackPressed() {
        String str = "Cancel";
        new Builder(this).setMessage("All changes will be discarded.").setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                CropActivity.this.finish();
            }
        }).setNegativeButton(str, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }

    private void inIt() {
        setSupportActionBar((Toolbar) findViewById(R.id.crop_toolbar));
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(false);
        this.cropImageView = (CropImageView) findViewById(R.id.cropimage);
        this.recyclerviewCrop = (RecyclerView) findViewById(R.id.crop_recycler);
        this.imgBack = (ImageView) findViewById(R.id.img_crop_tool_back);
        this.imgDone = (ImageView) findViewById(R.id.img_crop_tool_done);
        this.list = new ArrayList();
        this.getSticker = GridActivity.gridActivity;
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                CropActivity.this.onBackPressed();
            }
        });
        this.imgDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                CropActivity cropActivity = CropActivity.this;
                cropActivity.bitmap = cropActivity.cropImageView.getCroppedImage();
                if (CropActivity.this.bitmap == null) {
                    Toast.makeText(CropActivity.this, "Error while retrieving picture. Please try again.", Toast.LENGTH_SHORT).show();
                    CropActivity.this.finish();
                } else if (CropActivity.this.getIntent().getExtras().getString(ConditionalUserProperty.VALUE).equals("image")) {
                    Bundle bundle = new Bundle();
                    bundle.putString(Scopes.PROFILE, "no");
                    Intent intent = new Intent();
                    intent.putExtras(bundle);
                    CropActivity.this.setResult(-1, intent);
                    CropActivity.this.finish();
                } else {
                    CropActivity.this.getSticker.onGetSticker(CropActivity.this.bitmap);
                    CropActivity.this.finish();
                }
            }
        });
    }
}
