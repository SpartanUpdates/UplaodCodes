package com.mbit.VideoMaker.Interface;

import android.view.View;

public abstract interface OnItemClickListner<T>
{
  public abstract void onItemClick(View paramView, T paramT);
}
