package com.esc.fontappstylish.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;

public class RequestPermissionsActivity extends Activity {
    public static final String PREVIOUS_ACTIVITY_INTENT = "previous_intent";
    private static String[] permissions = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA};
    private Intent mPreviousActivityIntent;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mPreviousActivityIntent = (Intent) getIntent().getExtras().get(PREVIOUS_ACTIVITY_INTENT);
        requestPermissions();
    }

    public static boolean startPermissionActivity(Activity activity) {
        if (hasPermissions(activity)) {
            return false;
        }
        Intent intent = new Intent(activity, RequestPermissionsActivity.class);
        intent.putExtra(PREVIOUS_ACTIVITY_INTENT, activity.getIntent());
        activity.startActivity(intent);
        activity.finish();
        return true;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (isAllGranted(iArr)) {
            this.mPreviousActivityIntent.setFlags(65536);
            startActivity(this.mPreviousActivityIntent);
            finish();
            overridePendingTransition(0, 0);
            return;
        }
        requestPermissions();
    }

    private boolean isAllGranted(int[] iArr) {
        for (int i : iArr) {
            if (i != 0) {
                return false;
            }
        }
        return true;
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            Trace.beginSection("requestPermissions");
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(permissions, 1);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            Trace.endSection();
        }
    }

    public static boolean hasPermissions(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            Trace.beginSection("hasPermission");
        }
        try {
            for (String checkSelfPermission : permissions) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (context.checkSelfPermission(checkSelfPermission) != PackageManager.PERMISSION_GRANTED) {
                        return false;
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                Trace.endSection();
            }
            return true;
        } finally {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                Trace.endSection();
            }
        }
    }
}
