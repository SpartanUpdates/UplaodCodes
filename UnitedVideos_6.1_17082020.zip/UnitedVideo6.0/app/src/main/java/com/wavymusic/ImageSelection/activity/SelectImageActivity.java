package com.wavymusic.ImageSelection.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.wavymusic.App.MyApplication;
import com.wavymusic.CropImage.activity.CropImageActivity;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.ImageSelection.Adapter.AlbumAdapterById;
import com.wavymusic.ImageSelection.Adapter.ImageByAlbumAdapter;
import com.wavymusic.ImageSelection.Adapter.SelectedImageAdapter;
import com.wavymusic.ImageSelection.Interface.OnItemClickListner;
import com.wavymusic.ImageSelection.Model.ImageModel;
import com.wavymusic.ImageSelection.View.EmptyRecyclerView;
import com.wavymusic.ImageSelection.View.ExpandIconView;
import com.wavymusic.ImageSelection.View.VerticalSlidingPanel;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.R;
import java.io.File;
import java.util.ArrayList;

public class SelectImageActivity extends AppCompatActivity implements VerticalSlidingPanel.PanelSlideListener {
    Activity activity = SelectImageActivity.this;
    public static ArrayList<ImageModel> tempImage = new ArrayList();
    public static boolean isForFirst = false;
    public boolean isFromPreview = false;
    public String PathOfImage;
    Button btnDone;
    ArrayList<String> arrayList;
    String imageOrientation;
    boolean isPause = false;
    int ImageCount;
    private RecyclerView rvAlbum;
    private RecyclerView rvAlbumImages;
    private AlbumAdapterById albumAdapter;
    private ImageByAlbumAdapter albumImagesAdapter;
    private SelectedImageAdapter selectedImageAdapter;
    private VerticalSlidingPanel panel;
    private View parent;
    private ExpandIconView expandIcon;
    private Button btnClear;
    private TextView tvImageCount;
    private MyApplication application;
    private EmptyRecyclerView rvSelectedImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_image);
        application = MyApplication.getInstance();
        isFromPreview = getIntent().hasExtra("extra_from_preview");
        ImageCount = getIntent().getIntExtra("NoofImage", 0);
        MyApplication.TotalSelectedImage = ImageCount;
        PutAnalyticsEvent();
        application.init();
        init();
        CallListener();
    }

    @SuppressLint({"NewApi"})
    private void init() {
        btnDone = findViewById(R.id.btnDone);
        tvImageCount = findViewById(R.id.tvCounter);
        expandIcon = findViewById(R.id.settings_drag_arrow);
        rvAlbum = findViewById(R.id.rvAlbum);
        rvAlbumImages = findViewById(R.id.rvImageAlbum);
        rvSelectedImage = findViewById(R.id.rvSelectedImagesList);
        panel = findViewById(R.id.overview_panel);
        panel.setEnableDragViewTouchEvents(true);
        panel.setDragView(findViewById(R.id.settings_pane_header));
        panel.setPanelSlideListener(this);
        parent = findViewById(R.id.default_home_screen_panel);
        btnClear = findViewById(R.id.btnClear);

        albumAdapter = new AlbumAdapterById(this);
        albumImagesAdapter = new ImageByAlbumAdapter(this);
        selectedImageAdapter = new SelectedImageAdapter(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(
                getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        rvAlbum.setLayoutManager(mLayoutManager);
        rvAlbum.setItemAnimator(new DefaultItemAnimator());
        rvAlbum.setAdapter(albumAdapter);

        RecyclerView.LayoutManager gridLayputManager = new GridLayoutManager(getApplicationContext(), 3);
        rvAlbumImages.setLayoutManager(gridLayputManager);
        rvAlbumImages.setItemAnimator(new DefaultItemAnimator());
        rvAlbumImages.setAdapter(albumImagesAdapter);

        RecyclerView.LayoutManager gridLayputManager1 = new GridLayoutManager(
                getApplicationContext(), 4);
        rvSelectedImage.setLayoutManager(gridLayputManager1);
        rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        rvSelectedImage.setAdapter(selectedImageAdapter);
        rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
        if (MyApplication.TotalSelectedImage >= 50) {
            tvImageCount.setText(String.valueOf(application.getSelectedImages().size()));
        } else {
            tvImageCount.setText(application.getSelectedImages().size() + "/" + MyApplication.TotalSelectedImage);
        }
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SelectImageActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private String getDropboxIMGSize(final String uri) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(new File(uri).getAbsolutePath(), options);
        final int imageHeight = options.outHeight;
        final int imageWidth = options.outWidth;
        if (imageHeight > imageWidth) {
            return "P";
        }
        return "L";
    }

    private void CallListener() {
        arrayList = new ArrayList<String>();
        btnDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (application.getSelectedImages().size() != 0) {
                    if (application.getSelectedImages().size() <= MyApplication.TotalSelectedImage) {
                        int i = 0;
                        for (final ImageModel d : application.getSelectedImages()) {
                            final String isLandOrPort = getDropboxIMGSize(d.getImagePath());
                            if (i == 0) {
                                PathOfImage = d.getImagePath();
                                imageOrientation = isLandOrPort;
                            } else {
                                PathOfImage = PathOfImage + MyApplication.SPLIT_PATTERN + d.getImagePath();
                                imageOrientation = imageOrientation + "$" + isLandOrPort;
                            }
                            ++i;
                        }
                        Intent intent = new Intent(activity, CropImageActivity.class);
                        intent.putExtra("path", PathOfImage);
                        intent.putExtra("NoofImage", ImageCount);
                        startActivity(intent);
                        finish();
                    } else if (application.getSelectedImages().size() > MyApplication.TotalSelectedImage) {
                        new StringBuilder("Please Remove ").append(application.getSelectedImages().size() - MyApplication.TotalSelectedImage).append(" Images").toString();
                    } else {
                        Toast.makeText(activity, "Selected : " + MyApplication.TotalSelectedImage + " Image", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(activity, "Please Select Image!", Toast.LENGTH_SHORT).show();
                }
            }

        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (application.getSelectedImages().size() != 0) {
                    clearData();
                } else {
                    Toast.makeText(activity, "Please Select Image!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        albumAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                albumImagesAdapter.notifyDataSetChanged();
            }
        });
        albumImagesAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                if (MyApplication.TotalSelectedImage >= 50) {
                    tvImageCount.setText(String.valueOf(application.getSelectedImages().size()));
                } else {
                    tvImageCount.setText(application.getSelectedImages().size() + "/" + MyApplication.TotalSelectedImage);
                }
                selectedImageAdapter.notifyDataSetChanged();
            }
        });
        selectedImageAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                if (MyApplication.TotalSelectedImage >= 50) {
                    tvImageCount.setText(String.valueOf(application.getSelectedImages().size()));
                } else {
                    tvImageCount.setText(application.getSelectedImages().size() + "/" + MyApplication.TotalSelectedImage);
                }
                albumImagesAdapter.notifyDataSetChanged();
            }
        });
    }


    protected void onResume() {
        super.onResume();
        if (isPause) {
            isPause = false;
            if (MyApplication.TotalSelectedImage >= 50) {
                tvImageCount.setText(String.valueOf(application
                        .getSelectedImages().size()));
            } else {
                tvImageCount.setText(application.getSelectedImages().size() + "/" + MyApplication.TotalSelectedImage);
            }

            albumImagesAdapter.notifyDataSetChanged();
            selectedImageAdapter.notifyDataSetChanged();
        }
    }

    protected void onPause() {
        super.onPause();
        isPause = true;
    }

    public void onBackPressed() {
        if (this.panel.isExpanded()) {
            this.panel.collapsePane();
        } else if (MyApplication.IsSelectImageFrom) {
            startActivity(new Intent(this, DashbordActivity.class));
            finish();
        } else {
            UnityPlayer.UnitySendMessage("WavyThemeData", "PlayMainMusic", "");
            finish();
        }
    }

    public void onPanelSlide(View panel, final float slideOffset) {
        if (expandIcon != null)
            expandIcon.setFraction(slideOffset, false);
        if (slideOffset >= 0.005f) {
            if ((parent != null) && (parent.getVisibility() != View.VISIBLE)) {
                parent.setVisibility(View.VISIBLE);
            }
        } else if ((parent != null) && (parent.getVisibility() == View.VISIBLE)) {
            parent.setVisibility(View.GONE);
        }
    }


    public void onPanelCollapsed(View panel) {
        if (parent != null) {
            parent.setVisibility(View.VISIBLE);
        }
        selectedImageAdapter.isExpanded = false;
        selectedImageAdapter.notifyDataSetChanged();
    }

    public void onPanelExpanded(View panel) {
        if (parent != null) {
            parent.setVisibility(View.GONE);
        }
        selectedImageAdapter.isExpanded = true;
        selectedImageAdapter.notifyDataSetChanged();
    }


    public void onPanelAnchored(View panel) {
    }


    public void onPanelShown(View panel) {
    }


    private void clearData() {
        ArrayList<ImageModel> selectedImages = application.getSelectedImages();
        for (int i = selectedImages.size() - 1; i >= 0; i--) {
            application.removeSelectedImage(i);
        }
        if (MyApplication.TotalSelectedImage >= 50) {
            tvImageCount.setText("0");
        } else {
            tvImageCount.setText("0/" + MyApplication.TotalSelectedImage);
        }
        selectedImageAdapter.notifyDataSetChanged();
        albumImagesAdapter.notifyDataSetChanged();
    }
}