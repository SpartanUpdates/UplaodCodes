package com.kotlinz.festivalstorymaker.Models.festival;

import android.graphics.Color;
import android.view.View;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

public class y5 implements View.OnClickListener {
    FestivalDetailActivity_New festivalDetailActivity_new;
    public final int n;
    public final FestivalDetailActivity_New.ColorListAdapter o;

    public y5(FestivalDetailActivity_New festivalDetailActivity_new,FestivalDetailActivity_New.ColorListAdapter colorListAdapter, int i) {
        this.festivalDetailActivity_new=festivalDetailActivity_new;
        this.o = colorListAdapter;
        this.n = i;
    }

    public void onClick(View view) {
        FestivalDetailActivity_New.ColorListAdapter colorListAdapter = this.o;
        festivalDetailActivity_new.G0(Color.parseColor(colorListAdapter.q[this.n]));
    }

}
