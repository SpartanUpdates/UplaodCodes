package com.esc.howtomakeschoolsupplies.activity;

import android.media.MediaPlayer;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

import com.esc.howtomakeschoolsupplies.R;
import com.esc.howtomakeschoolsupplies.data.LikesContract;
import com.esc.howtomakeschoolsupplies.fragment.ContentFragment;
import com.esc.howtomakeschoolsupplies.network.ConnectToServer;

import androidx.core.content.ContextCompat;
import kotlin.jvm.internal.Intrinsics;

public class ContentFragmentOnCreateView1 implements OnClickListener {
    final MediaPlayer mpClick;
    final MediaPlayer mpLike;
    final int numberArticle;
    final View rootView;
    final ContentFragment contentfragment;

    static final class ClickLike_favourite1 implements Runnable {
        final ContentFragmentOnCreateView1 contentfragmentonCreateView;

        ClickLike_favourite1(ContentFragmentOnCreateView1 contentFragment$onCreateView$2) {
            this.contentfragmentonCreateView = contentFragment$onCreateView$2;
        }

        public final void run() {
            try {
                ConnectToServer.Companion.postOnServer("http://167.172.217.101:8080/chancellery/like/?id=" + this.contentfragmentonCreateView.numberArticle + "&onLike=" + false);
                this.contentfragmentonCreateView.contentfragment.removeLine(LikesContract.DBEntry.TABLE_NAME_LIKES, this.contentfragmentonCreateView.numberArticle);
                this.contentfragmentonCreateView.contentfragment.updateListsDB();
                this.contentfragmentonCreateView.contentfragment.isLike = this.contentfragmentonCreateView.contentfragment.checkLikeAndFavorite(this.contentfragmentonCreateView.contentfragment.mListDBLikes, this.contentfragmentonCreateView.numberArticle);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    static final class ClickLike_favourite2 implements Runnable {
        final ContentFragmentOnCreateView1 conentfragmentOnCreateView1;

        ClickLike_favourite2(ContentFragmentOnCreateView1 contentFragment$onCreateView$2) {
            this.conentfragmentOnCreateView1 = contentFragment$onCreateView$2;
        }

        public final void run() {
            try {
                ConnectToServer.Companion.postOnServer("http://167.172.217.101:8080/chancellery/like/?id=" + this.conentfragmentOnCreateView1.numberArticle + "&onLike=" + true);
                this.conentfragmentOnCreateView1.contentfragment.insertLine(LikesContract.DBEntry.TABLE_NAME_LIKES, this.conentfragmentOnCreateView1.numberArticle);
                this.conentfragmentOnCreateView1.contentfragment.updateListsDB();
                this.conentfragmentOnCreateView1.contentfragment.isLike = this.conentfragmentOnCreateView1.contentfragment.checkLikeAndFavorite(this.conentfragmentOnCreateView1.contentfragment.mListDBLikes, this.conentfragmentOnCreateView1.numberArticle);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public ContentFragmentOnCreateView1(ContentFragment contentFragment, MediaPlayer mediaPlayer, View view, int i, MediaPlayer mediaPlayer2) {
        this.contentfragment = contentFragment;
        this.mpClick = mediaPlayer;
        this.rootView = view;
        this.numberArticle = i;
        this.mpLike = mediaPlayer2;
    }

    public final void onClick(View view) {
        if (this.contentfragment.isLike) {
            this.mpClick.start();
            view = this.rootView;
            Intrinsics.checkExpressionValueIsNotNull(view, "rootView");
            ((ImageButton) view.findViewById(R.id.btnLike)).setImageDrawable(ContextCompat.getDrawable(this.contentfragment.requireActivity(), R.drawable.ic_like_unfill_white));
            new Thread(new ClickLike_favourite1(this)).start();
            return;
        }
        this.mpLike.start();
        this.contentfragment.animationLike();
        new Thread(new ClickLike_favourite2(this)).start();
    }
}
