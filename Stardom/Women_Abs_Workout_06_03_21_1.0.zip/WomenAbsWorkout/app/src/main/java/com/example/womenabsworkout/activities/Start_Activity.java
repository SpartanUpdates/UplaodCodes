package com.example.womenabsworkout.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.fcm.AppInstalledReciever;
import com.example.womenabsworkout.kprogresshud.KProgressHUD;
import com.example.womenabsworkout.newscreen.Library;
import com.example.womenabsworkout.receiver.NotificationReceiver;
import com.example.womenabsworkout.utils.Constants;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.analytics.FirebaseAnalytics.Event;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;
import com.thekhaeng.pushdownanim.PushDownAnim;
import java.util.Calendar;


public class Start_Activity extends AppCompatActivity {

    Activity activity=Start_Activity.this;

    public String TAG = "com.outthinking.abc";
    public FrameLayout adLoadingLayout;
    public Context context;
    public int height;
    public String k = null;
    public String l = null;
    public LayoutManager layoutManager;
    public AppInstalledReciever m;
    public FirebaseAnalytics mFirebaseAnalytics;
    public RecyclerView n;
    public LinearLayoutManager o;
    public SharedPreferences q;
    public TextView r;
    public RecyclerView recycler_view_crosspromtionl;
    public View t;
    public AppBarLayout u;
    public RelativeLayout v;
    public TextView w;
    public int width;
    public Library x;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    private OnClickListener getClickListener()
    {
        return new OnClickListener() {
            public void onClick(View view) {
                if (view == Start_Activity.this.r) {
                    new Handler().postDelayed(new Runnable()
                    {
                        public void run() {

                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                try {
                                    hud = KProgressHUD.create(activity)
                                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                            .setLabel("Showing Ads")
                                            .setDetailsLabel("Please Wait...");
                                    hud.show();
                                } catch (IllegalArgumentException e) {
                                    e.printStackTrace();
                                } catch (NullPointerException e2) {
                                    e2.printStackTrace();
                                } catch (Exception e3) {
                                    e3.printStackTrace();
                                }

                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            hud.dismiss();
                                        } catch (IllegalArgumentException e) {
                                            e.printStackTrace();

                                        } catch (NullPointerException e2) {
                                            e2.printStackTrace();
                                        } catch (Exception e3) {
                                            e3.printStackTrace();
                                        }
                                        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                            id = 100;
                                            mInterstitialAd.show();
                                        }
                                    }
                                }, 2000);
                            } else {
                                Start_Activity.this.startActivity(new Intent(Start_Activity.this, After_Main_Activity.class));
                                Start_Activity.this.finish();
                            }
                        }
                    }, 100);
                }
            }
        };
    }

    public void b() {
        Intent intent = getIntent();
        if (intent != null) {
            this.k = intent.getStringExtra(Constants.APP_PACKAGE_NAME);
            String stringExtra = intent.getStringExtra(Constants.APP_BANNER_URL);
            this.l = stringExtra;
            if (!(this.k == null || stringExtra == null)) {
                c();
                Editor edit = getApplicationContext().getSharedPreferences(Constants.FCM_CROSS_PROMO_PREF, 0).edit();
                edit.putString("appPackageNameFromFCM", this.k);
                edit.apply();
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("appPackageUrlFromFCM: ");
        stringBuilder.append(this.k);
        Log.d("onCreate", stringBuilder.toString());
    }

    public void c()
    {
        @SuppressLint("ResourceType") final Dialog dialog = new Dialog(this, 16974122);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.getWindow().getAttributes().windowAnimations = R.style.FCMDialogAnimation;
        dialog.setContentView(R.layout.launch_fcm_dialog);
        dialog.setCancelable(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.setCancelable(true);
        ((ImageView) dialog.findViewById(R.id.ad_close)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        FrameLayout frameLayout = (FrameLayout) dialog.findViewById(R.id.layoutContainer_dialog);
        frameLayout.setVisibility(View.VISIBLE);
        ImageView imageView = (ImageView) frameLayout.findViewById(R.id.image);
        LayoutParams layoutParams = imageView.getLayoutParams();
        int i = this.width;
        layoutParams.width = i - (i / 10);
        imageView.getLayoutParams().height = this.width;
        try {
            if (this.l != null) {
                Picasso.get().load(this.l).resize(this.width - (this.width / 10), this.width).placeholder((int) R.drawable.progress_animation).error((int) R.drawable.error).memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE);
            }
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("market://details?id=");
                    stringBuilder.append(Start_Activity.this.k);
                    Start_Activity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(stringBuilder.toString())));
                    dialog.dismiss();
                    try {
                        Bundle bundle = new Bundle();
                        bundle.putString(Param.ITEM_ID, Start_Activity.this.k);
                        bundle.putString(Param.ITEM_NAME, "clicked");
                        bundle.putString(Param.CONTENT_TYPE, "image");
                        Start_Activity.this.mFirebaseAnalytics.logEvent(Event.SELECT_CONTENT, bundle);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        dialog.show();
    }

    @SuppressLint("MissingPermission")
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        getWindow();
        if (isTaskRoot()) {
            this.context = this;
            this.x = new Library(this.context);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            this.width = displayMetrics.widthPixels;
            this.height = displayMetrics.heightPixels;
            if (this.x.isConnectedToInternet()) {
                setContentView(R.layout.start_activity);

                interstitialAd();

            }

            this.mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
            this.t = ((Start_Activity) this.context).findViewById(R.id.toolbar);
            this.u = (AppBarLayout) ((Start_Activity) this.context).findViewById(R.id.appBarLayout);
            this.q = PreferenceManager.getDefaultSharedPreferences(this);
            TextView textView = (TextView) findViewById(R.id.start);
            this.r = textView;
            PushDownAnim.setPushDownAnimTo(textView).setScale(1.0f).setDurationPush(50).setDurationRelease(50).setInterpolatorPush(PushDownAnim.DEFAULT_INTERPOLATOR).setInterpolatorRelease(PushDownAnim.DEFAULT_INTERPOLATOR).setOnClickListener(getClickListener());
            this.m = new AppInstalledReciever();
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(Intent.ACTION_PACKAGE_ADDED);
            intentFilter.addAction(Intent.ACTION_PACKAGE_INSTALL);
            intentFilter.addDataScheme("package");
            registerReceiver(this.m, intentFilter);
            return;
        }
        finish();
    }

    public void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(this.m);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Bundle extras = intent.getExtras();
        if (extras != null) {
            String str = "type";
            if (extras.containsKey(str) && extras.getString(str).equals("test type")) {
                Toast.makeText(this, extras.getString("message"), Toast.LENGTH_SHORT).show();
            }
            this.k = intent.getStringExtra(Constants.APP_PACKAGE_NAME);
            this.l = intent.getStringExtra(Constants.APP_BANNER_URL);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("appPackageNameFromFCM: ");
            stringBuilder.append(this.k);
            Log.d("onNewIntent", stringBuilder.toString());
            if (this.k != null && this.l != null) {
                Editor edit = getApplicationContext().getSharedPreferences(Constants.FCM_CROSS_PROMO_PREF, 0).edit();
                edit.putString("appPackageNameFromFCM", this.k);
                edit.apply();
                c();
            }
        }
    }

    public void onResume() {
        Log.d("TAG", "onResume");
        PushDownAnim.setPushDownAnimTo(this.r).setScale(1.0f).setDurationPush(50).setDurationRelease(50).setInterpolatorPush(PushDownAnim.DEFAULT_INTERPOLATOR).setInterpolatorRelease(PushDownAnim.DEFAULT_INTERPOLATOR).setOnClickListener(getClickListener());
        super.onResume();
    }

    public void onStop() {
        super.onStop();
    }

    @SuppressLint("WrongConstant")
    public void setAlarm() {
        Calendar instance = Calendar.getInstance();
        instance.set(11, 7);
        instance.set(12, 30);
        instance.set(13, 0);
        ((AlarmManager) getSystemService(NotificationCompat.CATEGORY_ALARM)).setRepeating(0, instance.getTimeInMillis(), 86400000, PendingIntent.getBroadcast(getApplicationContext(), 100, new Intent(getApplicationContext(), NotificationReceiver.class), 134217728));
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        Start_Activity.this.startActivity(new Intent(Start_Activity.this, After_Main_Activity.class));
                        Start_Activity.this.finish();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
