package com.kotlinz.photoslideshow.util;

public interface GloblePrgListener {
    void notifyAdaptor(String str, String str2);

    void updateProgress(String str, float f);
}
