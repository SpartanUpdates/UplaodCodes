package com.MV.Lyrics.notification.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.MV.Lyrics.AppUtils.AVLoadingView.AVLoadingIndicatorView;
import com.MV.Lyrics.Home.activity.HomeActivity;
import com.MV.Lyrics.R;
import com.google.firebase.analytics.FirebaseAnalytics;

public class NotificationActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = NotificationActivity.this;
    ImageView ivBack;
    public LinearLayout layoutDownload;
    public Button btnCreate;
    public ImageView ivThumb;
    public ImageView ivThumbDownload;
    public ImageView tvUseTheme;
    public TextView tvVideoName;
    public AVLoadingIndicatorView indicatorView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        BindView();
        PutAnalyticsEvent();
    }

    private void BindView() {
        ivBack = findViewById(R.id.ivBack);
        ivBack.setOnClickListener(this);
        ivThumb = findViewById(R.id.ivThumb);
        tvVideoName = findViewById(R.id.tvVideoName);
        ivThumbDownload = findViewById(R.id.ivThumbDownload);
        indicatorView = findViewById(R.id.indicator);
        layoutDownload = findViewById(R.id.ll_download);
        btnCreate = findViewById(R.id.btnCreate);
        tvUseTheme = findViewById(R.id.tvUseTheme);

    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "NotificationActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public final String V(String str) {
        str = str.substring(str.lastIndexOf("/") + 1);
        return str.substring(0, str.lastIndexOf("."));
    }

   /* public final void W() {
       indicatorView.setIndicator(new LineScalePulseOutRapidIndicator());
        try {
            g p = e.p(MyApplication.e0);
            this.C = p;
            if (p == null) {
                this.C = new g();
            }
            Z();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public final void X(g gVar) {
        File file = new File(gVar.g());
        if (!file.exists()) {
            a.a(this, new File(gVar.h()), file);
            try {
                a.l(new File(gVar.g()), new File(gVar.f()));
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (!new File(gVar.f()).exists()) {
            a.l(new File(gVar.g()), new File(gVar.f()));
        }
        file = new File(gVar.a());
        if (!file.exists()) {
            a.a(this, new File(gVar.b()), file);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(gVar.f());
        stringBuilder.append(File.separator);
        stringBuilder.append("ibig.jpg");
        String stringBuilder2 = stringBuilder.toString();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(gVar.f());
        stringBuilder3.append(File.separator);
        stringBuilder3.append("song.mp3");
        String stringBuilder4 = stringBuilder3.toString();
        StringBuilder stringBuilder5 = new StringBuilder();
        stringBuilder5.append(gVar.f());
        stringBuilder5.append(File.separator);
        stringBuilder5.append("json.json");
        String stringBuilder6 = stringBuilder5.toString();
        String a = gVar.a();
        String V = V(gVar.a());
        StringBuilder stringBuilder7 = new StringBuilder();
        stringBuilder7.append(stringBuilder2);
        stringBuilder2 = "?";
        stringBuilder7.append(stringBuilder2);
        stringBuilder7.append(stringBuilder4);
        stringBuilder7.append(stringBuilder2);
        stringBuilder7.append(stringBuilder6);
        stringBuilder7.append(stringBuilder2);
        stringBuilder7.append(a);
        stringBuilder7.append(stringBuilder2);
        stringBuilder7.append(V);
        stringBuilder4 = stringBuilder7.toString();
        UnityPlayerActivity unityPlayerActivity = MyApplication.p0;
        stringBuilder7 = new StringBuilder();
        stringBuilder7.append(a);
        stringBuilder7.append(stringBuilder2);
        stringBuilder7.append(V);
        unityPlayerActivity.K = stringBuilder7.toString();
        MyApplication.p0.L = -1;
        b.b("finalString", stringBuilder4);
        MyApplication.p0.i0();
        MyApplication.p0.B0();
        UnityPlayer.UnitySendMessage("LoadTemplate", "LoadAssetBundleWithSingleImageSongBundleLyricAndTemplate", stringBuilder4);
        finish();
    }

    public final void Y() {
        File file = new File(this.C.g());
        File file2 = new File(this.C.a());
        if (!(file.exists() && file2.exists())) {
            File file3 = new File(this.C.h());
            File file4 = new File(this.C.b());
            if (file3.exists() && file4.exists()) {
                if (!file.exists()) {
                    a.a(this, file3, file);
                }
                if (!file2.exists()) {
                    a.a(this, file4, file2);
                }
            } else {
                this.C.j(false);
                return;
            }
        }
        this.C.j(true);
    }

    public final void Z() {
        if (this.C != null) {
            ImageView imageView;
            c.b.a.c.w(this).s(this.C.e()).a(new f().h0(new ColorDrawable(Color.parseColor("#9ACCCD")))).I0(this.ivThumb);
            this.tvVideoName.setText(this.C.d());
            this.y.setText("0");
            Y();
            if (this.C.i()) {
                MyApplication.b0 = false;
                this.ivThumbDownload.setVisibility(View.GONE);
                this.z.setVisibility(View.GONE);
                this.y.setVisibility(View.GONE);
                this.A.setVisibility(View.GONE);
                imageView = this.tvUseTheme;
            } else {
                this.z.setVisibility(View.GONE);
                this.y.setVisibility(View.GONE);
                this.A.setVisibility(View.GONE);
                this.tvUseTheme.setVisibility(View.GONE);
                imageView = this.ivThumbDownload;
            }
            imageView.setVisibility(View.VISIBLE);
        }
    }
*/

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:{

            }
        }
    }
}