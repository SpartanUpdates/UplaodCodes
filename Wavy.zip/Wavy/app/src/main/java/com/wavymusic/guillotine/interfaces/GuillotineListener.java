package com.wavymusic.guillotine.interfaces;


public interface GuillotineListener {
    void onGuillotineOpened();
    void onGuillotineClosed();
}
