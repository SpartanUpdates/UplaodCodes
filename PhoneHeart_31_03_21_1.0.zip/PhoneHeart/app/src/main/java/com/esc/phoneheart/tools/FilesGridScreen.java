package com.esc.phoneheart.tools;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.OnScanCompletedListener;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore.Files;
import android.text.TextUtils.TruncateAt;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.esc.phoneheart.interfaceclass.DialogListners;
import com.esc.phoneheart.activity.FinalScreen;
import com.esc.phoneheart.activity.PhoneCleaner;
import com.esc.phoneheart.R;
import com.esc.phoneheart.activity.SplashScreen;
import com.esc.phoneheart.promo.ParentScreen;
import com.esc.phoneheart.model.FileManagerModule;
import com.esc.phoneheart.model.MediaList;
import com.esc.phoneheart.utility.FileUtil;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.MountPoints;
import com.esc.phoneheart.utility.Util;
import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;
import com.esc.phoneheart.model.FileType.FileTypes;

import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class FilesGridScreen extends ParentScreen implements OnClickListener, DialogListners {
    public static final int REQUEST_CODE_STORAGE_ACCESS_INPUT = 2415;
    public static String TAG = "FilesGridScreen";
    public TextView ads_message;
    public TextView ads_title;
    public Button btn_deleteBtn;
    public AsyncTask<String, Integer, DELETION> deleteTask;
    public int deviceHeight;
    public int deviceWidth;
    public ProgressDialog displayProgress;
    public boolean fromToolBox;
    public RelativeLayout l;
    public ListView listview;
    public RecyclerView listviewImages;
    public RelativeLayout m;
    public MediaList mediaList;
    public ImageAdapter imageadapter;
    public int notDeleted = 0;
    public FilesAdapter fileadpater;
    public boolean redirectToNoti;
    public boolean removeMenu = false;
    public static boolean resumedFromClick;
    public TextView tvview;

    public static class AnonymousClass11 {
        public static final int[] f2828a;
        public static final int[] b;

        static {
            int[] iArr = new int[DELETION.values().length];
            b = iArr;
            try {
                iArr[DELETION.ERROR.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                b[DELETION.PERMISSION.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                b[DELETION.SUCCESS.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            int[] iArr2 = new int[FileTypes.values().length];
            f2828a = iArr2;
            iArr2[FileTypes.Image.ordinal()] = 1;
            f2828a[FileTypes.Video.ordinal()] = 2;
            f2828a[FileTypes.Audio.ordinal()] = 3;
            f2828a[FileTypes.Document.ordinal()] = 4;
            f2828a[FileTypes.Others.ordinal()] = 5;
            f2828a[FileTypes.APK.ordinal()] = 6;
            try {
                f2828a[FileTypes.ALL.ordinal()] = 7;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    public enum DELETION {
        SUCCESS,
        ERROR,
        PERMISSION,
        SELECTION,
        FINISH,
        NOTDELETION
    }

    public class FilesAdapter extends BaseAdapter {
        public LayoutInflater mInflater;

        public FilesAdapter(Context context) {
            this.mInflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
        }

        private Bitmap getBitmapFromExt(String str) {
            String str2 = str;
            if (str2 == null) {
                return BitmapFactory.decodeResource(FilesGridScreen.this.getResources(), R.mipmap.ic_launcher);
            }
            if (Arrays.asList(new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"}).contains(str2)) {
                return BitmapFactory.decodeResource(FilesGridScreen.this.getResources(), R.drawable.ic_documents);
            }
            if (Arrays.asList(new String[]{"mp3", "aac", "m4a", "wav"}).contains(str2)) {
                return BitmapFactory.decodeResource(FilesGridScreen.this.getResources(), R.drawable.ic_audio);
            }
            return str2.equalsIgnoreCase("apk") ? BitmapFactory.decodeResource(FilesGridScreen.this.getResources(), R.drawable.ic_apk) : null;
        }

        public int getCount() {
            return FilesGridScreen.this.mediaList.filesList.size();
        }

        public Object getItem(int i) {
            return null;
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(final int i, View view, ViewGroup viewGroup) {
            String str = "";
            if (view == null) {
                view = this.mInflater.inflate(R.layout.fileslistitemaudio, viewGroup, false);
            }
            ImageView imageView = (ImageView) ViewHolder.get(view, R.id.junklistitemimage);
            TextView textView = (TextView) ViewHolder.get(view, R.id.junklistitemapp);
            TextView textView2 = (TextView) ViewHolder.get(view, R.id.junklistitemsize);
            AppCompatCheckBox checkBox = (AppCompatCheckBox) ViewHolder.get(view, R.id.junklistitemcheck);
            ImageView imageView2 = (ImageView) ViewHolder.get(view, R.id.listiteminfo);
            LinearLayout linearLayout = (LinearLayout) ViewHolder.get(view, R.id.checkcontainer);
            checkBox.setFocusable(false);
            checkBox.setClickable(false);
            final BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) FilesGridScreen.this.mediaList.filesList.get(i);
            try {
                if (FilesGridScreen.this.mediaList.mediaType == FileTypes.Audio) {
                    imageView.setImageBitmap(BitmapFactory.decodeResource(FilesGridScreen.this.getResources(), R.drawable.ic_audio));
                } else if (FilesGridScreen.this.mediaList.mediaType == FileTypes.Others) {
                    imageView.setImageBitmap(BitmapFactory.decodeResource(FilesGridScreen.this.getResources(), R.mipmap.ic_launcher));
                } else if (FilesGridScreen.this.mediaList.mediaType == FileTypes.Document) {
                    imageView.setImageBitmap(BitmapFactory.decodeResource(FilesGridScreen.this.getResources(), R.drawable.ic_documents));
                } else if (FilesGridScreen.this.mediaList.mediaType == FileTypes.APK) {
                    imageView.setImageBitmap(BitmapFactory.decodeResource(FilesGridScreen.this.getResources(), R.drawable.ic_apk_press));
                } else {
                    Bitmap bitmapFromExt = getBitmapFromExt(FilenameUtils.getExtension(bigSizeFilesWrapper.path));
                    if (bitmapFromExt == null) {
                        Glide.with(FilesGridScreen.this)
                                .load(new File(bigSizeFilesWrapper.path))
                                .placeholder(R.mipmap.ic_launcher)
                                .error(R.mipmap.ic_launcher)
                                .centerCrop()
                                .into(imageView);
                    } else {
                        imageView.setImageBitmap(bitmapFromExt);
                    }
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(bigSizeFilesWrapper.name);
                textView.setText(stringBuilder.toString());
                stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(Util.convertBytes(bigSizeFilesWrapper.size));
                textView2.setText(stringBuilder.toString());
                textView.setSelected(true);
                textView.setEllipsize(TruncateAt.MARQUEE);
                imageView2.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        if (!FilesGridScreen.this.doubleClicked()) {
                            Util.appendLogphonecleaner(FilesGridScreen.TAG, "imageInfo View.OnClickListener", GlobalData.FILE_NAME);
                            final Dialog dialog = new Dialog(FilesGridScreen.this);
                            if (dialog.getWindow() != null) {
                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                                dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
                            }
                            dialog.setContentView(R.layout.new_dialog_junk_cancel);
                            dialog.setCancelable(true);
                            dialog.setCanceledOnTouchOutside(true);
                            dialog.getWindow().setLayout(-1, -1);
                            dialog.getWindow().setGravity(17);
                            dialog.findViewById(R.id.dialog_img).setVisibility(View.GONE);
                            dialog.findViewById(R.id.dialog_title).setVisibility(View.GONE);
                            String a = FilesGridScreen.this.getmDate(bigSizeFilesWrapper.dateTaken);
                            TextView textView = (TextView) dialog.findViewById(R.id.dialog_msg);
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(FilesGridScreen.this.getResources().getString(R.string.pcl_name));
                            String str = " ";
                            stringBuilder.append(str);
                            stringBuilder.append(bigSizeFilesWrapper.name);
                            String str2 = "\n\n";
                            stringBuilder.append(str2);
                            stringBuilder.append(FilesGridScreen.this.getResources().getString(R.string.pcl_path));
                            stringBuilder.append(str);
                            stringBuilder.append(bigSizeFilesWrapper.path);
                            stringBuilder.append(str2);
                            stringBuilder.append(FilesGridScreen.this.getResources().getString(R.string.pcl_size));
                            stringBuilder.append(str);
                            stringBuilder.append(Util.convertBytes(bigSizeFilesWrapper.size));
                            stringBuilder.append(str2);
                            stringBuilder.append(FilesGridScreen.this.getResources().getString(R.string.pcl_time));
                            stringBuilder.append(str);
                            stringBuilder.append(a);
                            textView.setText(stringBuilder.toString());
                            dialog.findViewById(R.id.ll_yes_no).setVisibility(View.GONE);
                            dialog.findViewById(R.id.ll_ok).setVisibility(View.VISIBLE);
                            dialog.findViewById(R.id.ll_ok).setOnClickListener(new OnClickListener() {
                                public void onClick(View view) {
                                    if (!FilesGridScreen.this.doubleClicked()) {
                                        dialog.dismiss();
                                    }
                                }
                            });
                            dialog.show();
                        }
                    }
                });
                view.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        if (!FilesGridScreen.this.doubleClicked()) {
                            Util.appendLogphonecleaner(FilesGridScreen.TAG, "convertView .OnClickListener", GlobalData.FILE_NAME);
                            if (FilesGridScreen.this.mediaList.mediaType == FileTypes.Audio) {
                                Util.appendLogphonecleaner(FilesGridScreen.TAG, "convertView.setOnClickListener type.equalsIgnoreCase(audios)", GlobalData.FILE_NAME);
                                try {
                                    FilesGridScreen.this.openFile(FilesGridScreen.this, new File(bigSizeFilesWrapper.path));
                                    Toast.makeText(FilesGridScreen.this, FilesGridScreen.this.getString(R.string.unableToOpenFile), Toast.LENGTH_LONG).show();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else {
                                Util.appendLogphonecleaner(FilesGridScreen.TAG, "convertView.setOnClickListener type.equalsIgnoreCase(files)", GlobalData.FILE_NAME);
                                try {
                                    FilesGridScreen.this.openFile(FilesGridScreen.this, new File(bigSizeFilesWrapper.path));
                                } catch (Exception e2) {
                                    FilesGridScreen filesGridScreen = FilesGridScreen.this;
                                    Toast.makeText(filesGridScreen, filesGridScreen.getString(R.string.unableToOpenFile), Toast.LENGTH_LONG).show();
                                    e2.printStackTrace();
                                }
                            }
                        }
                    }
                });
                linearLayout.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        if (!FilesGridScreen.this.doubleClicked()) {
                            Util.appendLogphonecleaner(FilesGridScreen.TAG, "checkcontainer LinearLayout click Listener", GlobalData.FILE_NAME);
                            if (bigSizeFilesWrapper.ischecked) {
                                FilesGridScreen.this.mediaList.unSelectNodeAtIndex(i);
                                checkBox.setChecked(false);
                                for (int i = 0; i < FilesGridScreen.this.mediaList.arrContents.size(); i++) {
                                    if (((BigSizeFilesWrapper) FilesGridScreen.this.mediaList.arrContents.get(i)).id == bigSizeFilesWrapper.id) {
                                        ((BigSizeFilesWrapper) FilesGridScreen.this.mediaList.arrContents.get(i)).ischecked = false;
                                    }
                                }
                            } else {
                                for (int i2 = 0; i2 < FilesGridScreen.this.mediaList.arrContents.size(); i2++) {
                                    if (((BigSizeFilesWrapper) FilesGridScreen.this.mediaList.arrContents.get(i2)).id == bigSizeFilesWrapper.id) {
                                        ((BigSizeFilesWrapper) FilesGridScreen.this.mediaList.arrContents.get(i2)).ischecked = true;
                                    }
                                }
                                FilesGridScreen.this.mediaList.selectNodeAtIndex(i);
                                checkBox.setChecked(true);
                            }
                            FilesGridScreen.this.updateDeleteButtonTitle();
                            FilesGridScreen.this.updateSelectedCount();
                        }
                    }
                });
                if (bigSizeFilesWrapper.ischecked) {
                    checkBox.setChecked(true);
                } else {
                    checkBox.setChecked(false);
                }
            } catch (Exception e) {
                String a = FilesGridScreen.TAG;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("FilesAdapter exception !!!!!!!!!!");
                stringBuilder2.append(e.getMessage());
                Util.appendLogphonecleaner(a, stringBuilder2.toString(), GlobalData.FILE_NAME);
                e.printStackTrace();
            }
            return view;
        }
    }

    public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.MyViewHolder> {
        public LayoutInflater mInflater;

        public ImageAdapter(Context context) {
            this.mInflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {

            ImageView iv_junklistitemimage;
            ImageView iv_listiteminfo;
            TextView txt_junklistitemapp;
            TextView txt_junklistitemsize;
            LinearLayout ll_checkcontainer;
            LinearLayout ll_main;
            CheckBox chk_junklistitemcheck;

            public MyViewHolder(View view) {
                super(view);
                iv_junklistitemimage = (ImageView) view.findViewById(R.id.junklistitemimage);
                iv_listiteminfo = (ImageView) view.findViewById(R.id.listiteminfo);
                txt_junklistitemapp = (TextView) view.findViewById(R.id.junklistitemapp);
                txt_junklistitemsize = (TextView) view.findViewById(R.id.junklistitemsize);
                ll_checkcontainer = (LinearLayout) view.findViewById(R.id.checkcontainer);
                chk_junklistitemcheck = (CheckBox) view.findViewById(R.id.junklistitemcheck);
                ll_main = (LinearLayout) view.findViewById(R.id.ll_main);
            }
        }

        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new MyViewHolder(mInflater.inflate(R.layout.fileslistitem, parent, false));
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            String str = "";
            final BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) FilesGridScreen.this.mediaList.filesList.get(position);
            holder.chk_junklistitemcheck.setFocusable(false);
            holder.chk_junklistitemcheck.setClickable(false);

            Glide.with(FilesGridScreen.this)
                    .load(bigSizeFilesWrapper.path)
                    .placeholder(R.drawable.ic_photo)
                    .error(R.drawable.ic_photo)
                    .into(holder.iv_junklistitemimage);

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(bigSizeFilesWrapper.name);
            holder.txt_junklistitemapp.setText(stringBuilder.toString());
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(Util.convertBytes(bigSizeFilesWrapper.size));
            holder.txt_junklistitemsize.setText(stringBuilder.toString());
            holder.txt_junklistitemapp.setSelected(true);
            holder.txt_junklistitemapp.setEllipsize(TruncateAt.MARQUEE);

            holder.iv_listiteminfo.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (!FilesGridScreen.this.doubleClicked()) {
                        Util.appendLogphonecleaner(FilesGridScreen.TAG, "imageinfo click Listener", GlobalData.FILE_NAME);
                        final Dialog dialog = new Dialog(FilesGridScreen.this);
                        if (dialog.getWindow() != null) {
                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                            dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
                        }
                        dialog.setContentView(R.layout.new_dialog_junk_cancel);
                        dialog.setCancelable(true);
                        dialog.setCanceledOnTouchOutside(true);
                        dialog.getWindow().setLayout(-1, -1);
                        dialog.getWindow().setGravity(17);
                        dialog.findViewById(R.id.dialog_img).setVisibility(View.GONE);
                        dialog.findViewById(R.id.dialog_title).setVisibility(View.GONE);
                        String format = new SimpleDateFormat("MMM dd,yyyy, hh:mm aaa").format(new Date(bigSizeFilesWrapper.dateTaken));
                        TextView textView = (TextView) dialog.findViewById(R.id.dialog_msg);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(FilesGridScreen.this.getResources().getString(R.string.pcl_name));
                        String str = " ";
                        stringBuilder.append(str);
                        stringBuilder.append(bigSizeFilesWrapper.name);
                        String str2 = "\n\n";
                        stringBuilder.append(str2);
                        stringBuilder.append(FilesGridScreen.this.getResources().getString(R.string.pcl_path));
                        stringBuilder.append(str);
                        stringBuilder.append(bigSizeFilesWrapper.path);
                        stringBuilder.append(str2);
                        stringBuilder.append(FilesGridScreen.this.getResources().getString(R.string.pcl_size));
                        stringBuilder.append(str);
                        stringBuilder.append(Util.convertBytes(bigSizeFilesWrapper.size));
                        stringBuilder.append(str2);
                        stringBuilder.append(FilesGridScreen.this.getResources().getString(R.string.pcl_time));
                        stringBuilder.append(str);
                        stringBuilder.append(format);
                        textView.setText(stringBuilder.toString());
                        dialog.findViewById(R.id.ll_yes_no).setVisibility(View.GONE);
                        dialog.findViewById(R.id.ll_ok).setVisibility(View.VISIBLE);
                        dialog.findViewById(R.id.ll_ok).setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                if (!FilesGridScreen.this.doubleClicked()) {
                                    dialog.dismiss();
                                }
                            }
                        });
                        dialog.show();
                    }
                }
            });

            holder.ll_checkcontainer.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (!FilesGridScreen.this.doubleClicked()) {
                        Util.appendLogphonecleaner(FilesGridScreen.TAG, "checkcontainer LinearLayout click Listener", GlobalData.FILE_NAME);
                        if (bigSizeFilesWrapper.ischecked) {
                            FilesGridScreen.this.mediaList.unSelectNodeAtIndex(position);
                            holder.chk_junklistitemcheck.setChecked(false);
                            for (int i = 0; i < FilesGridScreen.this.mediaList.arrContents.size(); i++) {
                                if (((BigSizeFilesWrapper) FilesGridScreen.this.mediaList.arrContents.get(i)).id == bigSizeFilesWrapper.id) {
                                    ((BigSizeFilesWrapper) FilesGridScreen.this.mediaList.arrContents.get(i)).ischecked = false;
                                }
                            }
                        } else {
                            for (int i2 = 0; i2 < FilesGridScreen.this.mediaList.arrContents.size(); i2++) {
                                if (((BigSizeFilesWrapper) FilesGridScreen.this.mediaList.arrContents.get(i2)).id == bigSizeFilesWrapper.id) {
                                    ((BigSizeFilesWrapper) FilesGridScreen.this.mediaList.arrContents.get(i2)).ischecked = true;
                                }
                            }
                            FilesGridScreen.this.mediaList.selectNodeAtIndex(position);
                            holder.chk_junklistitemcheck.setChecked(true);
                        }
                        FilesGridScreen.this.updateDeleteButtonTitle();
                        FilesGridScreen.this.updateSelectedCount();
                    }
                }
            });

            holder.ll_main.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    FilesGridScreen filesGridScreen;
                    if (!FilesGridScreen.this.doubleClicked()) {
                        Util.appendLogphonecleaner(FilesGridScreen.TAG, "convertView VIEW click Listener", GlobalData.FILE_NAME);
                        if (FilesGridScreen.this.mediaList.mediaType == FileTypes.Image) {
                            Util.appendLogphonecleaner(FilesGridScreen.TAG, "type.equalsIgnoreCase images", GlobalData.FILE_NAME);
                            try {
                                FilesGridScreen.this.openFile(FilesGridScreen.this, new File(bigSizeFilesWrapper.path));
                            } catch (Exception e) {
                                filesGridScreen = FilesGridScreen.this;
                                Toast.makeText(filesGridScreen, filesGridScreen.getString(R.string.unableToOpenFile), Toast.LENGTH_LONG).show();
                                e.printStackTrace();
                            }
                            FilesGridScreen.this.resumedFromClick = true;
                        } else {
                            Util.appendLogphonecleaner(FilesGridScreen.TAG, "type.equalsIgnoreCase Video", GlobalData.FILE_NAME);
                            try {
                                FilesGridScreen.this.openFile(FilesGridScreen.this, new File(bigSizeFilesWrapper.path));
                            } catch (Exception e2) {
                                filesGridScreen = FilesGridScreen.this;
                                Toast.makeText(filesGridScreen, filesGridScreen.getString(R.string.unableToOpenFile), Toast.LENGTH_LONG).show();
                                e2.printStackTrace();
                            }
                            FilesGridScreen.this.resumedFromClick = true;
                        }
                    }
                }
            });
            if (bigSizeFilesWrapper.ischecked) {
                holder.chk_junklistitemcheck.setChecked(true);
            } else {
                holder.chk_junklistitemcheck.setChecked(false);
            }
        }

        @Override
        public int getItemCount() {
            return FilesGridScreen.this.mediaList.filesList.size();
        }
    }

    public static class ViewHolder {
        public static <T extends View> T get(View view, int i) {
            SparseArray tag;
            if ((tag = (SparseArray) view.getTag()) == null) {
                tag = new SparseArray();
                view.setTag((Object) tag);
            }
            View viewById;
            if ((viewById = (View) tag.get(i)) == null) {
                viewById = view.findViewById(i);
                tag.put(i, (Object) viewById);
            }
            return (T) viewById;
        }
    }

    public FilesGridScreen() {
    }

    private void GetDeviceDimensions() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        }
        this.deviceHeight = displayMetrics.heightPixels;
        this.deviceWidth = displayMetrics.widthPixels;
    }

    private boolean deleteImageFile(BigSizeFilesWrapper bigSizeFilesWrapper) {
        boolean exists;
        File file = new File(bigSizeFilesWrapper.path);
        if (file.exists()) {
            delete(file);
            exists = file.exists() ^ true;
            if (exists) {
                updateMediaScannerPath(file);
            } else {
                boolean isKitKat = FileUtil.isKitKat();
            }
        } else {
            updateMediaScannerPath(file);
            exists = true;
        }
        if (VERSION.SDK_INT == 21) {
            return true;
        }
        return exists;
    }

    private void deletion(final int i, final int i2, final Intent intent) {
        try {
            new AsyncTask<Void, Integer, DELETION>() {
                public void onPreExecute() {
                    FilesGridScreen.this.mediaList.initRecoveredBeforeDelete();
                    FilesGridScreen.this.displayProgress = new ProgressDialog(FilesGridScreen.this);
                    FilesGridScreen.this.getWindow().addFlags(2097280);
                    ProgressDialog f = FilesGridScreen.this.displayProgress;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(FilesGridScreen.this.getResources().getString(R.string.cleaning));
                    f.setTitle(stringBuilder.toString());
                    FilesGridScreen.this.displayProgress.setCanceledOnTouchOutside(false);
                    FilesGridScreen.this.displayProgress.setProgressStyle(1);
                    FilesGridScreen.this.displayProgress.setCancelable(false);
                    FilesGridScreen.this.displayProgress.setMax(FilesGridScreen.this.mediaList.selectedCount);
                    FilesGridScreen.this.displayProgress.show();
                }

                public DELETION doInBackground(Void... voidArr) {
                    if (FileUtil.isSystemAndroid5()) {
                        FilesGridScreen.onActivityResultLollipop(FilesGridScreen.this, i, i2, intent);
                    }
                    return FilesGridScreen.this.permissionBasedDeletion();
                }

                public void onPostExecute(DELETION deletion) {
                    if (FilesGridScreen.this.displayProgress != null) {
                        FilesGridScreen.this.displayProgress.dismiss();
                    }
                    try {
                        FilesGridScreen.this.getWindow().clearFlags(2097280);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    int i = AnonymousClass11.b[deletion.ordinal()];
                    if (i == 1) {
                        Toast.makeText(FilesGridScreen.this, "", Toast.LENGTH_LONG).show();
                    } else if (i == 2) {
                        FilesGridScreen.this.permissionAlert();
                    } else if (i == 3) {
                        FilesGridScreen.this.successDeletion();
                    }
                }

                public void onProgressUpdate(Integer... numArr) {
                    super.onProgressUpdate(numArr);
                    FilesGridScreen.this.displayProgress.setProgress(numArr[0].intValue());
                }
            }.execute(new Void[0]);
        } catch (Exception e) {
            String str = TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Permission deletion exception====");
            stringBuilder.append(e.getMessage());
            Util.appendLogphonecleaner(str, stringBuilder.toString(), GlobalData.FILE_NAME);
        }
    }

    private void deletionTask() {
        Util.appendLogphonecleaner(TAG, "method deletionTask calling", GlobalData.FILE_NAME);
        this.deleteTask = new AsyncTask<String, Integer, DELETION>() {
            private boolean isBothStorageCanDelete(ArrayList<String> arrayList) {
                for (int i = 0; i < arrayList.size(); i++) {
                    if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        if (!FileUtil.isWritableNormalOrSaf(FilesGridScreen.this, new File((String) arrayList.get(i)))) {
                            return false;
                        }
                    }
                }
                return true;
            }

            public void onPreExecute() {
                Util.appendLogphonecleaner(FilesGridScreen.TAG, "method deletionTask pre execute calling", GlobalData.FILE_NAME);
                FilesGridScreen.this.mediaList.initRecoveredBeforeDelete();
                FilesGridScreen.this.displayProgress = new ProgressDialog(FilesGridScreen.this);
                FilesGridScreen.this.getWindow().addFlags(2097280);
                FilesGridScreen.this.displayProgress.setTitle(R.string.cleaning);
                FilesGridScreen.this.displayProgress.setCanceledOnTouchOutside(false);
                FilesGridScreen.this.displayProgress.setProgressStyle(1);
                FilesGridScreen.this.displayProgress.setCancelable(false);
                FilesGridScreen.this.displayProgress.setMax(FilesGridScreen.this.mediaList.selectedCount);
                FilesGridScreen.this.displayProgress.show();
                super.onPreExecute();
            }

            public DELETION doInBackground(String... strArr) {
                if (strArr != null) {
                    return FilesGridScreen.this.permissionBasedDeletion();
                }
                Util.appendLogphonecleaner(FilesGridScreen.TAG, "method deletionTask doinbackground calling", GlobalData.FILE_NAME);
                if (FileUtil.IsDeletionBelow6()) {
                    Util.appendLogphonecleaner(FilesGridScreen.TAG, "method deletionTask os below 5.0", GlobalData.FILE_NAME);
                    return FilesGridScreen.this.normalDeletion();
                }
                ArrayList returnMountPOints = MountPoints.returnMountPOints(FilesGridScreen.this);
                if (returnMountPOints == null) {
                    Util.appendLogphonecleaner(FilesGridScreen.TAG, "mount points arr is null", GlobalData.FILE_NAME);
                    return FilesGridScreen.this.normalDeletion();
                } else if (returnMountPOints.size() == 1) {
                    Util.appendLogphonecleaner(FilesGridScreen.TAG, "mount points arr size is 1", GlobalData.FILE_NAME);
                    return FilesGridScreen.this.    normalDeletion();
                } else {
                    String a2 = FilesGridScreen.TAG;
                    StringBuilder sb = new StringBuilder();
                    sb.append("mount points arr size is ");
                    sb.append(returnMountPOints.size());
                    Util.appendLogphonecleaner(a2, sb.toString(), GlobalData.FILE_NAME);
                    File file = new File((String) returnMountPOints.get(1));
                    if (file.listFiles() == null || file.listFiles().length == 0) {
                        return FilesGridScreen.this.normalDeletion();
                    }
                    if (VERSION.SDK_INT <= 21) {
                        return DELETION.SUCCESS;
                    }
                    if (!isBothStorageCanDelete(returnMountPOints)) {
                        Util.appendLogphonecleaner(FilesGridScreen.TAG, "file is not able to write on external.Taking Permission", GlobalData.FILE_NAME);
                        return DELETION.PERMISSION;
                    }
                    Util.appendLogphonecleaner(FilesGridScreen.TAG, "file is able to write on external", GlobalData.FILE_NAME);
                    return FilesGridScreen.this.permissionBasedDeletion();
                }
            }

            public void onPostExecute(DELETION deletion) {
                String a2 = FilesGridScreen.TAG;
                StringBuilder sb = new StringBuilder();
                sb.append("method deletionTask onPostExecute() calling with status====");
                sb.append(deletion.name());
                Util.appendLogphonecleaner(a2, sb.toString(), GlobalData.FILE_NAME);
                FilesGridScreen.this.btn_deleteBtn.setEnabled(true);
                if (FilesGridScreen.this.displayProgress != null && FilesGridScreen.this.displayProgress.isShowing()) {
                    FilesGridScreen.this.displayProgress.dismiss();
                }
                try {
                    FilesGridScreen.this.getWindow().clearFlags(2097280);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                int i = AnonymousClass11.b[deletion.ordinal()];
                if (i == 1) {
                    Toast.makeText(FilesGridScreen.this, "Error", Toast.LENGTH_LONG).show();
                } else if (i == 2) {
                    FilesGridScreen.this.permissionAlert();
                } else if (i == 3) {
                    FilesGridScreen.this.successDeletion();
                }
                super.onPostExecute(deletion);
            }

            public void onProgressUpdate(Integer... numArr) {
                super.onProgressUpdate(numArr);
                FilesGridScreen.this.displayProgress.setProgress(numArr[0].intValue());
            }
        };
        ArrayList<String> list = new ArrayList();
        boolean z = true;
        for (int i = 0; i < list.size(); i++) {
            if (list != null && list.size() >1){
                File file = new File((String) list.get(1));
                if (file.listFiles() != null) {
                }
            }
        }
        if (!z) {
            this.deleteTask.execute(new String[0]);
        } else if (!isBothStorageCanDelete(list)) {
            permissionAlert();
        } else {
            this.deleteTask.execute(new String[]{"permissiondeletion"});
        }
    }

    public static Uri getSharedPreferenceUri(int i, Context context) {
        String string = getSharedPreferences(context).getString(context.getString(i), null);
        if (string == null) {
            return null;
        }
        return Uri.parse(string);
    }

    public static SharedPreferences getSharedPreferences(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    private String getmDate(long j) {
        String charSequence = DateFormat.format("dd-MMM-yyyy' at 'HH:mm a", new Date(j * 1000)).toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(charSequence);
        stringBuilder.append("");
        return stringBuilder.toString();
    }

    private void initControls() {
        this.l = (RelativeLayout) findViewById(R.id.layout_one);
        this.m = (RelativeLayout) findViewById(R.id.layout_two);
        this.ads_title = (TextView) findViewById(R.id.dialog_title);
        this.ads_message = (TextView) findViewById(R.id.dialog_msg);
        this.listviewImages = (RecyclerView) findViewById(R.id.grid);
        btn_deleteBtn = (Button) findViewById(R.id.btnfiledelete);
        btn_deleteBtn.setOnClickListener(this);
        this.listview = (ListView) findViewById(R.id.listview);
        this.tvview = (TextView) findViewById(R.id.tv_gird);
    }

    private boolean isBothStorageCanDelete(ArrayList<String> arrayList) {
        for (int i = 0; i < arrayList.size(); i++) {
            if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (!FileUtil.isWritableNormalOrSaf(this, new File((String) arrayList.get(i)))) {
                    return false;
                }
            }
        }
        return true;
    }

    private DELETION normalDeletion() {
        int i = 0;
        this.notDeleted = 0;
        Util.appendLogphonecleaner(TAG, "method normaldeletion calling ", GlobalData.FILE_NAME);
        try {
            int size = this.mediaList.filesList.size();
            int i2 = 0;
            for (i = 0; i < size; i++) {
                BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) this.mediaList.filesList.get(i);
                if (bigSizeFilesWrapper.ischecked) {
                    String str;
                    StringBuilder stringBuilder;
                    if (deleteImageFile(bigSizeFilesWrapper)) {
                        str = TAG;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("normal delete success with path===");
                        stringBuilder.append(bigSizeFilesWrapper.path);
                        Util.appendLogphonecleaner(str, stringBuilder.toString(), GlobalData.FILE_NAME);
                        this.mediaList.deleteNode(bigSizeFilesWrapper);
                        this.mediaList.filesList.remove(i);
                        i2++;
                        this.displayProgress.setProgress(i2);
                        size--;
                    } else {
                        this.notDeleted++;
                        str = TAG;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("normal delete failed with path===");
                        stringBuilder.append(bigSizeFilesWrapper.path);
                        Util.appendLogphonecleaner(str, stringBuilder.toString(), GlobalData.FILE_NAME);

                    }
                    FileManagerModule fileManagerModule = PhoneCleaner.getInstance().spaceManagerModule;
                    fileManagerModule.recoveredSize += bigSizeFilesWrapper.size;
                }
            }
            return DELETION.SUCCESS;
        } catch (Exception e) {
            String str2 = TAG;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("normal delete exception====");
            stringBuilder2.append(e.getMessage());
            Util.appendLogphonecleaner(str2, stringBuilder2.toString(), GlobalData.FILE_NAME);
            DELETION deletion = DELETION.ERROR;
            return DELETION.SUCCESS;
        } catch (Throwable unused) {
            return DELETION.SUCCESS;
        }
    }

    public static void onActivityResultLollipop(Context context, int i, int i2, @NonNull Intent intent) {
        if (i == REQUEST_CODE_STORAGE_ACCESS_INPUT) {
            if (getSharedPreferenceUri(R.string.pcl_key_internal_uri_extsdcard_input, context) == null) {
                getSharedPreferenceUri(R.string.pcl_key_internal_uri_extsdcard_photos, context);
            }
            Uri uri = null;
            if (i2 == -1) {
                uri = intent.getData();
                setSharedPreferenceUri(R.string.pcl_key_internal_uri_extsdcard_input, uri, context);
            }
            if (i2 != -1) {
                System.out.println("File is not writable");
                return;
            }
            i = intent.getFlags() & 3;
            if (uri != null) {
                if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    context.getContentResolver().takePersistableUriPermission(uri, i);
                }
            }
        }
    }

    private void openFile(Context context, File file) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setFlags(268435456);
        intent.addFlags(3);
        Uri uriForFile = FileProvider.getUriForFile(context, "com.esc.phoneheart.fileprovider", file);
        String mimeType = Util.getMimeType(file.getAbsolutePath());
        if (mimeType != null) {
            intent.setDataAndType(uriForFile, mimeType);
        } else if (file.toString().contains(".doc") || file.toString().contains(".docx")) {
            intent.setDataAndType(uriForFile, "application/msword");
        } else if (file.toString().contains(".pdf")) {
            intent.setDataAndType(uriForFile, "application/pdf");
        } else if (file.toString().contains(".ppt") || file.toString().contains(".pptx")) {
            intent.setDataAndType(uriForFile, "application/vnd.ms-powerpoint");
        } else if (file.toString().contains(".xls") || file.toString().contains(".xlsx")) {
            intent.setDataAndType(uriForFile, "application/vnd.ms-excel");
        } else if (file.toString().contains(".zip") || file.toString().contains(".rar")) {
            intent.setDataAndType(uriForFile, "application/x-wav");
        } else if (file.toString().contains(".rtf")) {
            intent.setDataAndType(uriForFile, "application/rtf");
        } else if (file.toString().contains(".wav") || file.toString().contains(".mp3") || file.toString().contains(".wma") || file.toString().contains(".ogg") || file.toString().contains(".flac") || file.toString().contains(".aac")) {
            intent.setDataAndType(uriForFile, "audio/*");
        } else if (file.toString().contains(".gif")) {
            intent.setDataAndType(uriForFile, "image/gif");
        } else if (file.toString().contains(".jpg") || file.toString().contains(".jpeg") || file.toString().contains(".png")) {
            intent.setDataAndType(uriForFile, "image/*");
        } else if (file.toString().contains(".txt")) {
            intent.setDataAndType(uriForFile, "text/plain");
        } else if (file.toString().contains(".3gp") || file.toString().contains(".mpg") || file.toString().contains(".mpeg") || file.toString().contains(".mpe") || file.toString().contains(".mp4") || file.toString().contains(".avi")) {
            intent.setDataAndType(uriForFile, "video/*");
        } else if (file.toString().contains(".apk")) {
            intent.setDataAndType(uriForFile, "application/vnd.android.package-archive");
        } else {
            intent.setDataAndType(uriForFile, "*/*");
        }
        context.startActivity(intent);
    }

    private void permissionAlert() {
        final Dialog dialog = new Dialog(this);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
        }
        dialog.setContentView(R.layout.new_dialog_junk_cancel);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.getWindow().setGravity(17);
        dialog.findViewById(R.id.dialog_img).setVisibility(View.GONE);
        dialog.findViewById(R.id.dialog_title).setVisibility(View.GONE);
        ((TextView) dialog.findViewById(R.id.dialog_msg)).setText(getString(R.string.pcl_sdcard_permission_delete));
        ((TextView) dialog.findViewById(R.id.ll_no_txt)).setText(getString(R.string.pcl_deny));
        ((TextView) dialog.findViewById(R.id.ll_yes_txt)).setText(getString(R.string.pcl_grant));
        dialog.findViewById(R.id.ll_no).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!FilesGridScreen.this.doubleClicked()) {
                    FilesGridScreen.this.deleteTask.execute(new String[0]);
                }
            }
        });
        dialog.findViewById(R.id.ll_yes).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!FilesGridScreen.this.doubleClicked()) {
                    dialog.dismiss();
                    FilesGridScreen filesGridScreen = FilesGridScreen.this;
                    SplashScreen.showdialog_sdcard(filesGridScreen, filesGridScreen);
                }
            }
        });
        dialog.show();
    }

    private DELETION permissionBasedDeletion() {
        int i = 0;
        this.notDeleted = 0;
        Util.appendLogphonecleaner(TAG, "method permissionBasedDeletion()", GlobalData.FILE_NAME);
        try {
            int size = this.mediaList.filesList.size();
            int i2 = 0;
            while (i < size) {
                BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) this.mediaList.filesList.get(i);
                if (bigSizeFilesWrapper.ischecked) {
                    boolean exists;
                    File file = new File(bigSizeFilesWrapper.path);
                    if (file.delete()) {
                        exists = file.exists();
                    } else {
                        exists = FileUtil.deleteFile(this, file);
                    }
                    if (exists) {
                        exists = FileUtil.deleteFile(this, file);
                    }
                    String str;
                    StringBuilder stringBuilder;
                    if (!exists) {
                        i2++;
                        this.displayProgress.setProgress(i2);
                        str = TAG;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("permission deletion success with path===");
                        stringBuilder.append(file.getAbsolutePath());
                        Util.appendLogphonecleaner(str, stringBuilder.toString(), GlobalData.FILE_NAME);
                        updateMediaScannerPath(file);
                        this.mediaList.deleteNode(bigSizeFilesWrapper);
                        this.mediaList.filesList.remove(i);
                        size--;
                    } else {
                        str = TAG;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("permission deletion failed with path===");
                        stringBuilder.append(file.getAbsolutePath());
                        Util.appendLogphonecleaner(str, stringBuilder.toString(), GlobalData.FILE_NAME);
                        this.notDeleted++;
                        i++;
                    }
                    FileManagerModule fileManagerModule = PhoneCleaner.getInstance().spaceManagerModule;
                    fileManagerModule.recoveredSize += bigSizeFilesWrapper.size;
                } else {
                    i++;
                }
            }
            return DELETION.SUCCESS;
        } catch (Exception e) {
            try {
                String str2 = TAG;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Permission deletion exception====");
                stringBuilder2.append(e.getMessage());
                Util.appendLogphonecleaner(str2, stringBuilder2.toString(), GlobalData.FILE_NAME);
                DELETION deletion = DELETION.ERROR;
                return DELETION.SUCCESS;
            } catch (Throwable unused) {
                return DELETION.SUCCESS;
            }
        }
    }

    private void redirectToNoti() {
        this.redirectToNoti = getIntent().getBooleanExtra(GlobalData.REDIRECTNOTI, false);
    }

    private void setAdapters() {
        Util.appendLogphonecleaner(TAG, " method setAdapters Calling ", GlobalData.FILE_NAME);
        switch (AnonymousClass11.f2828a[this.mediaList.mediaType.ordinal()]) {
            case 1:
            case 2:
                imageadapter = new ImageAdapter(this);
                listviewImages.setLayoutManager(new LinearLayoutManager(this));
                this.listviewImages.setAdapter(imageadapter);

                break;
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
                this.listviewImages.setVisibility(View.GONE);
                FilesAdapter filesAdapter = new FilesAdapter(this);
                this.fileadpater = filesAdapter;
                this.listview.setAdapter(filesAdapter);
                break;
        }
        updateSelectedCount();
    }

    private void setArrays() {
        int[] iArr = new int[this.mediaList.filesList.size()];
        for (int i = 0; i < this.mediaList.filesList.size(); i++) {
            iArr[i] = ((BigSizeFilesWrapper) this.mediaList.filesList.get(i)).id;
        }
    }

    private void setListners() {
    }

    public static void setSharedPreferenceUri(int i, @Nullable Uri uri, Context context) {
        Editor edit = getSharedPreferences(context).edit();
        if (uri == null) {
            edit.putString(context.getString(i), null);
        } else {
            edit.putString(context.getString(i), uri.toString());
        }
        edit.apply();
    }

    private void setTitle() {
        Util.appendLogphonecleaner(TAG, " method setTitle Calling ", GlobalData.FILE_NAME);
        switch (AnonymousClass11.f2828a[this.mediaList.mediaType.ordinal()]) {
            case 1:
                this.tvview.setText(R.string.file_manage_category_no_item);
                return;
            case 2:
                this.tvview.setText(R.string.file_manage_category_no_item);
                return;
            case 3:
                this.tvview.setText(R.string.file_manage_category_no_item);
                return;
            case 4:
                this.tvview.setText(R.string.file_manage_category_no_item);
                return;
            case 5:
                this.tvview.setText(R.string.file_manage_category_no_item);
                return;
            case 6:
                this.tvview.setText(R.string.file_manage_category_no_item);
                return;
            case 7:
                this.tvview.setText(R.string.file_manage_category_no_item);
                return;
            default:
                return;
        }
    }

    private void showCustomDialog() {
        Util.appendLogphonecleaner(TAG, "method showCustomDialog calling ", GlobalData.FILE_NAME);
        if (!Util.isConnectingToInternet(this) || Util.isAdsFree(this)) {
            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(1);
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
            }
            dialog.setContentView(R.layout.new_dialog_junk_cancel);
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);
            dialog.getWindow().setLayout(-1, -1);
            dialog.getWindow().setGravity(17);
            if (this.fromToolBox) {
                ((TextView) dialog.findViewById(R.id.dialog_title)).setText(getResources().getString(R.string.module_file_manager));
            } else {
                ((TextView) dialog.findViewById(R.id.dialog_title)).setText(getResources().getString(R.string.module_file_manager));
            }
            ((TextView) dialog.findViewById(R.id.dialog_msg)).setText(getResources().getString(R.string.dup_photo_cleanconfirm_message));
            dialog.findViewById(R.id.ll_no).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (!FilesGridScreen.this.doubleClicked()) {
                        Util.appendLogphonecleaner(FilesGridScreen.TAG, "method showCustomDialog calling cancel press", GlobalData.FILE_NAME);
                        dialog.dismiss();
                        FilesGridScreen.this.btn_deleteBtn.setEnabled(true);
                    }
                }
            });
            dialog.findViewById(R.id.ll_yes).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                        FilesGridScreen.this.btn_deleteBtn.setEnabled(false);
                        Util.appendLogphonecleaner(FilesGridScreen.TAG, "method showCustomDialog calling continue press", GlobalData.FILE_NAME);
                        FilesGridScreen.this.deletionTask();
                        dialog.dismiss();
                }
            });
            dialog.show();
            return;
        }
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        this.l.setVisibility(View.GONE);
        this.m.setVisibility(View.VISIBLE);
        if (this.fromToolBox) {
            this.ads_title.setText(getResources().getString(R.string.module_file_manager));
        } else {
            this.ads_title.setText(getResources().getString(R.string.module_file_manager));
        }
        this.ads_message.setText(getResources().getString(R.string.dup_photo_cleanconfirm_message));
    }

    private void sortListByDate() {
        try {
            Collections.sort(this.mediaList.filesList, new Comparator<BigSizeFilesWrapper>() {
                public int compare(BigSizeFilesWrapper bigSizeFilesWrapper, BigSizeFilesWrapper bigSizeFilesWrapper2) {
                    return Long.compare(bigSizeFilesWrapper2.dateTaken, bigSizeFilesWrapper.dateTaken);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        ImageAdapter imageAdapter = this.imageadapter;
        if (imageAdapter != null) {
            imageAdapter.notifyDataSetChanged();
        }
        FilesAdapter filesAdapter = this.fileadpater;
        if (filesAdapter != null) {
            filesAdapter.notifyDataSetChanged();
        }
    }

    private void sortListByName() {
        try {
            Collections.sort(this.mediaList.filesList, new Comparator<BigSizeFilesWrapper>() {
                public int compare(BigSizeFilesWrapper bigSizeFilesWrapper, BigSizeFilesWrapper bigSizeFilesWrapper2) {
                    return bigSizeFilesWrapper.name.trim().compareToIgnoreCase(bigSizeFilesWrapper2.name.trim());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        ImageAdapter imageAdapter = this.imageadapter;
        if (imageAdapter != null) {
            imageAdapter.notifyDataSetChanged();
        }
        FilesAdapter filesAdapter = this.fileadpater;
        if (filesAdapter != null) {
            filesAdapter.notifyDataSetChanged();
        }
    }

    private void sortListBySize() {
        try {
            Collections.sort(this.mediaList.filesList, new Comparator<BigSizeFilesWrapper>() {
                public int compare(BigSizeFilesWrapper bigSizeFilesWrapper, BigSizeFilesWrapper bigSizeFilesWrapper2) {
                    return Long.compare(bigSizeFilesWrapper2.size, bigSizeFilesWrapper.size);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        ImageAdapter imageAdapter = this.imageadapter;
        if (imageAdapter != null) {
            imageAdapter.notifyDataSetChanged();
        }
        FilesAdapter filesAdapter = this.fileadpater;
        if (filesAdapter != null) {
            filesAdapter.notifyDataSetChanged();
        }
    }

    private void successDeletion() {
        Intent intent = new Intent(this, FinalScreen.class);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(Util.convertBytes(this.mediaList.recoveredSize));
        intent.putExtra("DATA", stringBuilder.toString());
        intent.putExtra("TYPE", "Recovered");
        intent.putExtra("FROMLARGE", true);
        intent.putExtra("not_deleted", this.notDeleted);
        if (this.redirectToNoti) {
            intent.putExtra(GlobalData.REDIRECTNOTI, false);
        }
        this.resumedFromClick = true;
        GlobalData.afterDelete = true;
        startActivity(intent);
    }

    public void updateDeleteButtonTitle() {
        try {
            if (this.mediaList == null || this.mediaList.selectedSize != 0) {
                Button button = this.btn_deleteBtn;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(getResources().getString(R.string.clean));
                stringBuilder.append(" ");
                stringBuilder.append(Util.convertBytes(this.mediaList.selectedSize));
                button.setText(String.format(stringBuilder.toString(), new Object[0]));
                return;
            }
            this.btn_deleteBtn.setText(R.string.clean);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateMediaScannerPath(File file) {
        MediaScannerConnection.scanFile(this, new String[]{file.getAbsolutePath()}, null, new OnScanCompletedListener() {
            public void onScanCompleted(String str, Uri uri) {
            }
        });
    }

    public void updateSelectedCount() {
        CharSequence stringBuilder;
        int i = AnonymousClass11.f2828a[this.mediaList.mediaType.ordinal()];
        String str = " ";
        String str2 = "/";
        StringBuilder stringBuilder2;
        switch (i) {
            case 1:
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(this.mediaList.selectedCount);
                stringBuilder2.append(str2);
                stringBuilder2.append(this.mediaList.filesList.size());
                stringBuilder2.append(str);
                stringBuilder2.append(getResources().getString(R.string.images));
                stringBuilder = stringBuilder2.toString();
                break;
            case 2:
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(this.mediaList.selectedCount);
                stringBuilder2.append(str2);
                stringBuilder2.append(this.mediaList.filesList.size());
                stringBuilder2.append(str);
                stringBuilder2.append(getResources().getString(R.string.videos));
                stringBuilder = stringBuilder2.toString();
                break;
            case 3:
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(this.mediaList.selectedCount);
                stringBuilder2.append(str2);
                stringBuilder2.append(this.mediaList.filesList.size());
                stringBuilder2.append(str);
                stringBuilder2.append(getResources().getString(R.string.audios));
                stringBuilder = stringBuilder2.toString();
                break;
            case 4:
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(this.mediaList.selectedCount);
                stringBuilder2.append(str2);
                stringBuilder2.append(this.mediaList.filesList.size());
                stringBuilder2.append(str);
                stringBuilder2.append(getResources().getString(R.string.documents));
                stringBuilder = stringBuilder2.toString();
                break;
            case 5:
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(this.mediaList.selectedCount);
                stringBuilder2.append(str2);
                stringBuilder2.append(this.mediaList.filesList.size());
                stringBuilder2.append(str);
                stringBuilder2.append(getResources().getString(R.string.file_manage_others));
                stringBuilder = stringBuilder2.toString();
                break;
            case 6:
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(this.mediaList.selectedCount);
                stringBuilder2.append(str2);
                stringBuilder2.append(this.mediaList.filesList.size());
                stringBuilder2.append(str);
                stringBuilder2.append(getResources().getString(R.string.junk_scan_APKs));
                stringBuilder = stringBuilder2.toString();
                break;
            case 7:
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(this.mediaList.selectedCount);
                stringBuilder2.append(str2);
                stringBuilder2.append(this.mediaList.filesList.size());
                stringBuilder2.append(str);
                stringBuilder2.append(getResources().getString(R.string.file_manage_items));
                stringBuilder = stringBuilder2.toString();
                break;
            default:
                stringBuilder = "";
                break;
        }
        ((TextView) findViewById(R.id.toolbar_title)).setText(stringBuilder);
    }

    public void clickOK() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(64);
        intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
        intent.addFlags(1);
        startActivityForResult(intent, REQUEST_CODE_STORAGE_ACCESS_INPUT);
    }

    public boolean delete(File file) {
        file.delete();
        if (file.exists()) {
            String[] strArr = new String[]{file.getAbsolutePath()};
            ContentResolver contentResolver = getContentResolver();
            Uri contentUri = Files.getContentUri("external");
            String str = "_data=?";
            contentResolver.delete(contentUri, str, strArr);
            if (file.exists()) {
                contentResolver.delete(contentUri, str, strArr);
            }
        }
        return true;
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == REQUEST_CODE_STORAGE_ACCESS_INPUT && i2 == -1) {
            deletion(i, i2, intent);
        }
    }

    public void onBackPressed() {
        Util.appendLogphonecleaner(TAG, "ON BACK PRESS", GlobalData.FILE_NAME);
        super.onBackPressed();
    }

    public void onClick(View view) {
        if (!doubleClicked() && view.getId() == R.id.btnfiledelete) {
            Util.appendLogphonecleaner(TAG, " btnfiledelete Button Calling Before for Loop", GlobalData.FILE_NAME);
            if (this.mediaList.selectedCount == 0) {
                Util.appendLogphonecleaner(TAG, "Please select at least one item to delete.", GlobalData.FILE_NAME);
                Toast.makeText(this, getResources().getString(R.string.junk_atlest_one), Toast.LENGTH_LONG).show();
            } else {
                showCustomDialog();
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        GlobalData.SETAPPLAnguage(this);
        setContentView(R.layout.activity_grid);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            Drawable backArrow = getResources().getDrawable(R.drawable.ic_back_selector);
            getSupportActionBar().setHomeAsUpIndicator(backArrow);
            getSupportActionBar().setTitle((CharSequence) "");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        try {
            redirectToNoti();
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.resumedFromClick = false;
        try {
            MediaList mediaList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
            this.mediaList = mediaList;
            mediaList.filesList = new ArrayList();
            this.mediaList.refresh();
            this.mediaList.filesList.addAll(this.mediaList.arrContents);
            if (this.mediaList == null) {
                return;
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        this.fromToolBox = getIntent().getBooleanExtra("fromToolBox", false);
        Util.appendLogphonecleaner(TAG, " onCreate() Calling ", GlobalData.FILE_NAME);
        GlobalData.afterDelete = false;
        try {
            setArrays();
        } catch (Exception e22) {
            e22.printStackTrace();
        }
        initControls();
        GetDeviceDimensions();
        updateDeleteButtonTitle();
        switch (AnonymousClass11.f2828a[this.mediaList.mediaType.ordinal()]) {
            case 1:
            case 2:
                this.listview.setVisibility(View.GONE);
                break;
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
                this.listview.setVisibility(View.VISIBLE);
                break;
        }
        if (this.mediaList.filesList.size() == 0) {
            this.removeMenu = true;
            invalidateOptionsMenu();
            ((View) this.tvview.getParent()).setVisibility(View.VISIBLE);
            this.listview.setVisibility(View.GONE);
            this.listviewImages.setVisibility(View.GONE);
            this.btn_deleteBtn.setVisibility(View.GONE);
        }
        setTitle();
        setListners();
        setAdapters();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        if (this.removeMenu) {
            return true;
        }
        getMenuInflater().inflate(R.menu.large_files_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.action_markall) {
            MediaList mediaList = this.mediaList;
            mediaList.selectAll(mediaList.filesList);
            updateDeleteButtonTitle();
            updateSelectedCount();
            setAdapters();
            return true;
        } else if (itemId != R.id.action_unmarkall) {
            switch (itemId) {
                case R.id.action_settings:
                    break;
                case R.id.action_sortByDate:
                    sortListByDate();
                    break;
                case R.id.action_sortByName:
                    sortListByName();
                    return true;
                case R.id.action_sortBySize:
                    sortListBySize();
                    return true;
                default:
                    onBackPressed();
                    return super.onOptionsItemSelected(menuItem);
            }
            return true;
        } else {
            this.mediaList.unSelectAll();
            updateDeleteButtonTitle();
            updateSelectedCount();
            setAdapters();
            return true;
        }
    }

    public void onResume() {
        ImageAdapter imageAdapter = this.imageadapter;
        if (imageAdapter != null) {
            imageAdapter.notifyDataSetChanged();
            updateDeleteButtonTitle();
            updateSelectedCount();
        }
        FilesAdapter filesAdapter = this.fileadpater;
        if (filesAdapter != null) {
            filesAdapter.notifyDataSetChanged();
            updateDeleteButtonTitle();
            updateSelectedCount();
        }
        if (btn_deleteBtn != null) {
            btn_deleteBtn.setEnabled(true);
        }
        MediaList mediaList = this.mediaList;
        if (mediaList != null && mediaList.filesList.size() == 0) {
            ((View) this.tvview.getParent()).setVisibility(View.VISIBLE);
            this.listview.setVisibility(View.GONE);
            this.listviewImages.setVisibility(View.GONE);
            this.btn_deleteBtn.setVisibility(View.GONE);
            this.removeMenu = true;
            invalidateOptionsMenu();
        }
        super.onResume();
    }
}
