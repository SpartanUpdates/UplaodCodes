package com.kotlinz.videoCollage.interfaces;

public interface BGImageAdapterCallBackInterface {
    void itemClick(int i);
}
