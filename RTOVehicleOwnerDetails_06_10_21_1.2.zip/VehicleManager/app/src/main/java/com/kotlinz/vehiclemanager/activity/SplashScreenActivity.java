package com.kotlinz.vehiclemanager.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.LinearLayout;

import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.AppOpenAdsEventsListener;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.utils.DarkTheame;

public class SplashScreenActivity extends AppCompatActivity {
    private LinearLayout splashScreen;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        splashScreen = findViewById(R.id.splashScreen);

        DarkTheame darkTheame = new DarkTheame(SplashScreenActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            splashScreen.setBackgroundResource(R.drawable.dark_splash);
        }
        OpenAppAds();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashScreenActivity.this, MainActivity.class));
                finish();
            }
        }, 2000);
    }

    private void OpenAppAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        GGAppOpenAds.setListener(new AppOpenAdsEventsListener() {
            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdClosed() {

            }

        });
        GGAppOpenAds.loadAd(getResources().getString(R.string.open_ads));
    }

}