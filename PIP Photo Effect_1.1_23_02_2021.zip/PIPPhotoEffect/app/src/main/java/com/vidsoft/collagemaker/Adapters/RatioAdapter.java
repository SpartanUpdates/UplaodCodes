package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;
import androidx.multidex.BuildConfig;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.vidsoft.collagemaker.Model.Ratio;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Const;

import java.util.ArrayList;

public class RatioAdapter extends Adapter<RatioAdapter.ViewHolder> {
    String Selection;
    Activity activity;
    ArrayList<Ratio> list;

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout border;
        ImageView imageView;
        TextView textRatio;

        public ViewHolder(View itemView) {
            super(itemView);
            this.textRatio = (TextView) itemView.findViewById(R.id.tvRatio);
            this.border = (LinearLayout) itemView.findViewById(R.id.rl_border);
            this.imageView = (ImageView) itemView.findViewById(R.id.imageView);
        }
    }

    public RatioAdapter(Activity activity, ArrayList<Ratio> list) {
        this.Selection = "0";
        this.list = list;
        this.activity = activity;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.ratio_adapter, parent, false));
    }

    public void onBindViewHolder(ViewHolder holder, int position) {
        if (this.Selection.equals(BuildConfig.FLAVOR)) {
            holder.imageView.setColorFilter(ContextCompat.getColor(this.activity, Const.normalColor));
            holder.textRatio.setTextColor(ContextCompat.getColor(this.activity, Const.normalColor));
        } else if (position == Integer.parseInt(this.Selection)) {
            holder.imageView.setColorFilter(ContextCompat.getColor(this.activity, Const.selectedColor));
            holder.textRatio.setTextColor(ContextCompat.getColor(this.activity, Const.selectedColor));
        } else {
            holder.imageView.setColorFilter(ContextCompat.getColor(this.activity, Const.normalColor));
            holder.textRatio.setTextColor(ContextCompat.getColor(this.activity, Const.normalColor));
        }
        holder.textRatio.setText(((Ratio) this.list.get(position)).getTitle());
        Glide.with(this.activity).load(Integer.valueOf(((Ratio) this.list.get(position)).getImage())).into(holder.imageView);
    }

    public void selection(String pos) {
        this.Selection = pos;
    }

    public int getItemCount() {
        return this.list.size();
    }
}