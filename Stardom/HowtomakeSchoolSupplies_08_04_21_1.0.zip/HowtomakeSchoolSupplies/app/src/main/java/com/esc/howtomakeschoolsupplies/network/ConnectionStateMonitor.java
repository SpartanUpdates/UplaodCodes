package com.esc.howtomakeschoolsupplies.network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.ConnectivityManager.NetworkCallback;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.NetworkRequest.Builder;
import android.os.Build;

import androidx.annotation.RequiresApi;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;

@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class ConnectionStateMonitor extends NetworkCallback {
    public ConnectionMonitor connectionMonitor;
    private final NetworkRequest networkRequest;

    public interface ConnectionMonitor {
        void disabledConnectMonitor();

        void enabledConnectMonitor();
    }

    public ConnectionStateMonitor() {
        NetworkRequest build = new Builder().addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR).addTransportType(NetworkCapabilities.TRANSPORT_WIFI).addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET).build();
        Intrinsics.checkExpressionValueIsNotNull(build, "NetworkRequest.Builder()…NET)\n            .build()");
        this.networkRequest = build;
    }

    public final void enable(Context context) {
        Intrinsics.checkParameterIsNotNull(context, "context");
        this.connectionMonitor = (ConnectionMonitor) context;
        Object systemService = context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (systemService != null) {
            ((ConnectivityManager) systemService).registerNetworkCallback(this.networkRequest, this);
            return;
        }
        throw new TypeCastException("null cannot be cast to non-null type android.net.ConnectivityManager");
    }

    public void onAvailable(Network network) {
        Intrinsics.checkParameterIsNotNull(network, "network");
        if (this.connectionMonitor != null) {
            ConnectionMonitor connectionMonitor = this.connectionMonitor;
            if (connectionMonitor == null) {
                Intrinsics.throwUninitializedPropertyAccessException("connectionMonitor");
            }
            connectionMonitor.enabledConnectMonitor();
        }
    }

    public void onLost(Network network) {
        Intrinsics.checkParameterIsNotNull(network, "network");
        if (this.connectionMonitor != null) {
            ConnectionMonitor connectionMonitor = this.connectionMonitor;
            if (connectionMonitor == null) {
                Intrinsics.throwUninitializedPropertyAccessException("connectionMonitor");
            }
            connectionMonitor.disabledConnectMonitor();
        }
    }
}
