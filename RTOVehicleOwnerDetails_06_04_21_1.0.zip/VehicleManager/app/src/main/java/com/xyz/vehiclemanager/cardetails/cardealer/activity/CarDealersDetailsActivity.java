package com.xyz.vehiclemanager.cardetails.cardealer.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.cardetails.cardealer.adapter.CarDealersDetailAdapter;
import com.xyz.vehiclemanager.cardetails.cardealer.model.CarDealers;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.utils.Utils;
import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CarDealersDetailsActivity extends AppCompatActivity implements View.OnClickListener
{
    private Activity activity = CarDealersDetailsActivity.this;
    private String cityId,brandId,cityName;
    private TextView tv_cityname;
    private ImageView iv_back;
    private CarDealersDetailAdapter carDealersDetailAdapter;
    private RecyclerView rv_dealerdetail;
    private Button btn_changecity;
    private RtoDetailsInterface rtoDetailsInterface;
    private AppCompatDialog dialog;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardealers_details);

        Intent intent = getIntent();
        brandId = intent.getStringExtra("brandId");
        cityName = intent.getStringExtra("cityname");
        cityId = intent.getStringExtra("cityid");
        if(brandId == null)
        {
            brandId = CarDealerSelectStateActivity.brandId;
        }

        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        BindView();
        PutAnalyticsEvent();
        BannerAds();
        DialogAnimation();
        if (Utils.isOnline(activity)){
            getCarDealerDetails();
        }else {
            Toast.makeText(this, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    private void BindView(){
        iv_back = findViewById(R.id.iv_back);
        tv_cityname = findViewById(R.id.tv_cityname);
        rv_dealerdetail = findViewById(R.id.rv_dealerdetail);
        btn_changecity = findViewById(R.id.btn_changecity);

        btn_changecity.setOnClickListener(this);
        iv_back.setOnClickListener(this);

        tv_cityname.setText(cityName);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CarDealersDetailsActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void  DialogAnimation()
    {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_cardialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.btn_changecity:
                onBackPressed();
                break;

            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }

    private void getCarDealerDetails()
    {
        Call<CarDealers> call = rtoDetailsInterface.getCarDelersDetail(brandId,cityId);
        call.enqueue(new Callback<CarDealers>() {
            @Override
            public void onResponse(Call<CarDealers> call, Response<CarDealers> response) {
                if (response.isSuccessful())
                {
                    if (dialog != null && dialog.isShowing())
                    {
                        dialog.dismiss();
                    }
                    ArrayList<CarDealers> cardealerlist = response.body().getData();
                    String statusMessage=response.body().getStatusMessage();
                    if(statusMessage.contains("Sorry! No matching car dealers found."))
                    {
                        Toast.makeText(CarDealersDetailsActivity.this, "No Data found", Toast.LENGTH_SHORT).show();
                    }else
                    {
                        carDealersDetailAdapter = new CarDealersDetailAdapter(activity, cardealerlist);
                        rv_dealerdetail.setLayoutManager(new LinearLayoutManager(activity));
                        rv_dealerdetail.setAdapter(carDealersDetailAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<CarDealers> call, Throwable t) {
                if (dialog != null && dialog.isShowing())
                {
                    dialog.dismiss();
                }
                 Toast.makeText(activity, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
       super.onBackPressed();
    }
}