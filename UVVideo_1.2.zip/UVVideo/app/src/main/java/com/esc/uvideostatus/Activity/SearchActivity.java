package com.esc.uvideostatus.Activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer.text.ttml.TtmlNode;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.esc.uvideostatus.Adapters.CustomAdapter;
import com.esc.uvideostatus.Adapters.SearchAdapter;
import com.esc.uvideostatus.Models.VideoData;
import com.esc.uvideostatus.R;
import com.esc.uvideostatus.Utility.FontTextView;
import com.esc.uvideostatus.Utility.Utility;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpHeaders;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SearchActivity extends AppCompatActivity {
    public static ArrayList<VideoData> videoData = new ArrayList<>();
    public RecyclerView album_recyclerview;
    RelativeLayout data_layout;
    TextView enter;
    ImageView iv_backpress;
    LinearLayout lin_list;
    public ListView listView;
    SearchAdapter mAdapter;
    LinearLayoutManager mLayoutManager;
    String main_url;
    FontTextView no_data_txt;
    public EditText searchView;
    FontTextView search_txt;
    Toolbar toolbar;
    VideoData videoDataobj = new VideoData();
    String vurl;

    class dataserachhandler extends AsyncHttpResponseHandler {
        ProgressDialog progressDialog;

        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
        }

        dataserachhandler() {
        }

        public void onStart() {
            super.onStart();
            this.progressDialog = new ProgressDialog(SearchActivity.this);
            this.progressDialog.setMessage("Please wait..");
            this.progressDialog.show();
        }

        @SuppressLint("WrongConstant")
        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            String str = "url";
            String str2 = new String(bArr);
            StringBuilder sb = new StringBuilder();
            sb.append("response12: ");
            sb.append(str2);
            Log.d("data", sb.toString());
            if (!SearchActivity.this.isFinishing()) {
                ProgressDialog progressDialog2 = this.progressDialog;
                if (progressDialog2 != null && progressDialog2.isShowing()) {
                    this.progressDialog.dismiss();
                }
            }
            try {
                SearchActivity.videoData = new ArrayList<>();
                JSONArray jSONArray = new JSONArray(str2);
                int i2 = 0;
                while (i2 < jSONArray.length()) {
                    try {
                        JSONObject jSONObject = jSONArray.getJSONObject(i2);
                        SearchActivity.this.videoDataobj = new VideoData();
                        SearchActivity.this.videoDataobj.setVideo_id(jSONObject.getLong(TtmlNode.ATTR_ID));
                        //SearchActivity.this.videoDataobj.setTitle(jSONObject.getString(NotificationTable.COLUMN_NAME_TITLE));
                        videoDataobj.setTitle(jSONObject.getString("title"));
                        SearchActivity.this.videoDataobj.setUrl(jSONObject.getString(str));
                        SearchActivity.this.videoDataobj.setReal_videopath(jSONObject.getString(str));
                        SearchActivity.this.videoDataobj.setThumbnail(jSONObject.getString(TtmlNode.TAG_IMAGE));
                        SearchActivity.this.videoDataobj.setCatagory(jSONObject.getString("cname"));
                        SearchActivity.this.videoDataobj.setViews(jSONObject.getString("downloads"));
                        SearchActivity.videoData.add(SearchActivity.this.videoDataobj);
                        i2++;
                    } catch (JSONException e) {
                        e.printStackTrace();
                        return;
                    }
                }
                album_recyclerview.setVisibility(View.VISIBLE);
                data_layout.setVisibility(View.GONE);
                no_data_txt.setVisibility(View.GONE);
                mAdapter = new SearchAdapter(SearchActivity.this.getApplicationContext(), SearchActivity.videoData, SearchActivity.this, SearchActivity.this.album_recyclerview);
                album_recyclerview.setAdapter(SearchActivity.this.mAdapter);
                mAdapter.notifyDataSetChanged();
                if (videoData == null || videoData.size() != 0) {
                    data_layout.setVisibility(View.GONE);
                    album_recyclerview.setVisibility(View.VISIBLE);
                } else {
                    data_layout.setVisibility(View.VISIBLE);
                    no_data_txt.setVisibility(View.VISIBLE);
                    search_txt.setVisibility(View.GONE);
                    album_recyclerview.setVisibility(View.GONE);
                }
                if (!(SearchActivity.videoData == null || SearchActivity.videoData.size() == 0)) {
                    ((InputMethodManager) SearchActivity.this.getSystemService("input_method")).hideSoftInputFromWindow(SearchActivity.this.album_recyclerview.getWindowToken(), 0);
                }
                SearchActivity.this.searchView.clearFocus();
            } catch (Exception unused) {
            }
        }
    }

    class datasuggestion extends AsyncHttpResponseHandler {
        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
        }

        datasuggestion() {
        }

        public void onStart() {
            super.onStart();
        }

        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            try {
                JSONObject jSONObject = new JSONObject(new String(bArr));
                SearchActivity.videoData = new ArrayList<>();
                jSONObject.getString("error");
                try {
                    JSONArray jSONArray = jSONObject.getJSONArray("data");
                    for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                        JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                        SearchActivity.this.videoDataobj = new VideoData();
                        //SearchActivity.this.videoDataobj.setTitle(jSONObject2.getString(NotificationTable.COLUMN_NAME_TITLE));
                        videoDataobj.setTitle(jSONObject.getString("title"));
                        SearchActivity.videoData.add(SearchActivity.this.videoDataobj);
                    }
                    SearchActivity.this.listView.setAdapter(new CustomAdapter(SearchActivity.videoData, SearchActivity.this, SearchActivity.this));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } catch (Exception unused) {
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_search);
        if (getIntent() != null) {
            this.main_url = getIntent().getStringExtra("url");
            this.vurl = getIntent().getStringExtra("vurl");
        }
        initview();
    }

    @SuppressLint("WrongConstant")
    private void initview() {
        this.lin_list = findViewById(R.id.lin_list);
        this.toolbar = findViewById(R.id.toolbar);
        this.listView = findViewById(R.id.listview);
        this.searchView = findViewById(R.id.editTextSearch);
        this.enter = findViewById(R.id.enter);
        this.iv_backpress = findViewById(R.id.iv_backpress);
        this.album_recyclerview = findViewById(R.id.album_recyclerview);
        this.data_layout = findViewById(R.id.data_layout);
        this.no_data_txt = findViewById(R.id.no_data_txt);
        this.search_txt = findViewById(R.id.search_txt);
        this.data_layout.setVisibility(0);
        this.mLayoutManager = new LinearLayoutManager(this);
        this.album_recyclerview.setLayoutManager(this.mLayoutManager);
        this.album_recyclerview.setItemAnimator(new DefaultItemAnimator());
        this.album_recyclerview.addItemDecoration(new DividerItemDecoration(this, 0));
        this.searchView.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @SuppressLint("WrongConstant")
            public void afterTextChanged(Editable editable) {
                SearchActivity.this.lin_list.setVisibility(8);
                SearchActivity.this.searchView.getText().toString();
            }
        });
        this.searchView.setOnEditorActionListener(new OnEditorActionListener() {
            @SuppressLint("WrongConstant")
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i != 3) {
                    return false;
                }
                SearchActivity.this.lin_list.setVisibility(8);
                SearchActivity.this.getsearchvideo(SearchActivity.this.searchView.getText().toString());
                return true;
            }
        });
        this.iv_backpress.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                SearchActivity.this.onBackPressed();
            }
        });
    }

    @SuppressLint("WrongConstant")
    public void getsearchvideo(String str) {
        JSONObject jSONObject;
        jSONObject = new JSONObject();
        try {
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("$regex", str);
            //jSONObject.put(NotificationTable.COLUMN_NAME_TITLE, jSONObject2);
            jSONObject.put("title",jSONObject2);
            StringBuilder sb = new StringBuilder();
            sb.append("");
            sb.append(jSONObject.toString());
            Log.e("=>>", sb.toString());
        } catch (JSONException e) {
            e = e;
        }
        JSONObject jSONObject32 = new JSONObject();
        try {
            jSONObject32.put("_id", -1);
        } catch (JSONException e3) {
            e3.printStackTrace();
        }
        RequestParams requestParams2 = new RequestParams();
        requestParams2.put("q", jSONObject.toString());
        requestParams2.put("sk", "0");
        requestParams2.put("l", 20);
        requestParams2.put("s", jSONObject32.toString());
        AsyncHttpClient asyncHttpClient2 = new AsyncHttpClient();
        asyncHttpClient2.setTimeout(60000);
        StringBuilder sb22 = new StringBuilder();
        sb22.append(Utility.baseUrl);
        sb22.append("collections/tbl_video?apiKey=");
        sb22.append(Utility.apiKey);
        asyncHttpClient2.get(sb22.toString(), requestParams2, new dataserachhandler());
        ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 2);
    }

    public void getsuggestion() {
        new RequestParams();
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        asyncHttpClient.addHeader("Authorization", String.valueOf(123));
        asyncHttpClient.setTimeout(60000);
        StringBuilder sb = new StringBuilder();
        sb.append(this.main_url);
        sb.append("getsearchtrending");
        asyncHttpClient.post(sb.toString(), new datasuggestion());
    }

    public void playVideo(VideoData videoData2) {
        Intent intent = new Intent(this, Video_play_Activity.class);
        intent.putExtra("VIDEO_PATH", videoData2.getReal_videopath());
        intent.putExtra("list", videoData2);
        intent.putExtra(HttpHeaders.FROM, "Searching");
        StringBuilder sb = new StringBuilder();
        sb.append("playVideo: ");
        sb.append(videoData2.getReal_videopath());
        sb.append(" ");
        sb.append(videoData2.getTitle());
        Log.d("TAG", sb.toString());
        startActivity(intent);
    }

    @SuppressLint("WrongConstant")
    public void searchitem(String str) {
        getsearchvideo(str);
        this.lin_list.setVisibility(8);
    }

    public void onBackPressed() {
        super.onBackPressed();
    }
}
