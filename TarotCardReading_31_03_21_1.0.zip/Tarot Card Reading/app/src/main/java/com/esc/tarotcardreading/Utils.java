package com.esc.tarotcardreading;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Configuration;
import android.os.Build.VERSION;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

public class Utils {

    public static void CopyStream(InputStream inputStream, OutputStream outputStream) {
        try {
            byte[] bArr = new byte[1024];
            while (true) {
                int read = inputStream.read(bArr, 0, 1024);
                if (read != -1) {
                    outputStream.write(bArr, 0, read);
                } else {
                    return;
                }
            }
        } catch (Exception unused) {
            unused.printStackTrace();
        }
    }

    public static ContextWrapper changeLang(Context context, String str) {
        Locale locale = new Locale(str);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        if (VERSION.SDK_INT >= 24) {
            configuration.setLocale(locale);
        } else {
            configuration.locale = locale;
        }
        if (VERSION.SDK_INT >= 17) {
            context = context.createConfigurationContext(configuration);
        } else {
            context.getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());
        }
        return new ContextWrapper(context);
    }
}
