package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class RtoOfficeRoot {
    @SerializedName("details")
    public ArrayList<RtoCityList> cityList;

    public ArrayList<RtoCityList> getCityList() {
        return cityList;
    }

    public void setCityList(ArrayList<RtoCityList> cityList) {
        this.cityList = cityList;
    }

    public class RtoCityList {
        @SerializedName("name")
        public String stateName;
        @SerializedName("rtoList")
        public ArrayList<RtoOfficeDetail> cityName;

        public String getStateName() {
            return stateName;
        }

        public void setStateName(String stateName) {
            this.stateName = stateName;
        }

        public ArrayList<RtoOfficeDetail> getCityName() {
            return cityName;
        }

        public void setCityName(ArrayList<RtoOfficeDetail> cityName) {
            this.cityName = cityName;
        }

        public class RtoOfficeDetail {
            @SerializedName("rto_code")
            public String rtoCode;
            @SerializedName("district")
            public String district;
            @SerializedName("state")
            public String stateName;
            @SerializedName("address")
            public String address;
            @SerializedName("phone")
            public String phone;
            @SerializedName("website")
            public String website;

            public String getRtoCode() {
                return rtoCode;
            }

            public void setRtoCode(String rtoCode) {
                this.rtoCode = rtoCode;
            }

            public String getDistrict() {
                return district;
            }

            public void setDistrict(String district) {
                this.district = district;
            }

            public String getStateName() {
                return stateName;
            }

            public void setStateName(String stateName) {
                this.stateName = stateName;
            }

            public String getAddress() {
                return address;
            }

            public void setAddress(String address) {
                this.address = address;
            }

            public String getPhone() {
                return phone;
            }

            public void setPhone(String phone) {
                this.phone = phone;
            }

            public String getWebsite() {
                return website;
            }

            public void setWebsite(String website) {
                this.website = website;
            }
        }
    }
}
