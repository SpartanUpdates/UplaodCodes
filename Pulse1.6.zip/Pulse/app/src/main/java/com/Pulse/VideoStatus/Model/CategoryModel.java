package com.Pulse.VideoStatus.Model;

public class CategoryModel {
    private String CategoryId, name, appid;
    private int CatIcon;
    private int CatSelectedIcon;
    public int getCatIcon() {
        return CatIcon;
    }

    public void setCatIcon(int catIcon) {
        CatIcon = catIcon;
    }

    public String getCategoryId() {
        return CategoryId;
    }

    public void setCategoryId(String categoryId) {
        this.CategoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public int getCatSelectedIcon() {
        return CatSelectedIcon;
    }

    public void setCatSelectedIcon(int catSelectedIcon) {
        CatSelectedIcon = catSelectedIcon;
    }
}
