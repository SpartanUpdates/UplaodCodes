package com.wavymusic.activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.wavymusic.Adapter.VideoAdapter;
import com.wavymusic.Model.VideoModel;
import com.wavymusic.R;
import com.wavymusic.Utils.Utils;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.io.File;
import java.util.ArrayList;

public class YourVideoActivity extends AppCompatActivity {

    public ArrayList<VideoModel> videoList;
    Activity activity = YourVideoActivity.this;
    LinearLayout llcreatevideo;
    ImageView ivBack;
    TextView txtMainTitle;
    String from = "";
    TextView tvcreatevideoNow;
    RecyclerView rvVideoList;
    VideoAdapter videoAdapter;

    private StaggeredGridLayoutManager gridLayoutManager;

    private NativeBannerAd mNativeBannerAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_video);
        from = getIntent().getStringExtra("from");
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "YourVideoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        bindView();
        init();
        loadNativeAds();
        setAdapṭer();
        addListener();
    }


    private void loadNativeAds(){
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(activity, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                FrameLayout nativeBannerAdContainer =findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();
    }


    private void bindView() {
        ivBack = findViewById(R.id.ivBack);
        txtMainTitle = findViewById(R.id.tv_name);
        llcreatevideo = findViewById(R.id.ll_novideo);
        tvcreatevideoNow = findViewById(R.id.tv_create_now);
        rvVideoList = findViewById(R.id.rvAlubmPhotos);
    }


    private void addListener() {
        ivBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                if (from != null && from.equalsIgnoreCase("unity")) {
                    finish();
                } else {
                    onBackPressed();
                }
            }

        });
        tvcreatevideoNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(activity, HomeActivity.class));
                finish();
            }
        });
    }

    private void init() {
        getVideoList();
        if (videoList.size() > 0) {
            llcreatevideo.setVisibility(View.GONE);
        } else {
            llcreatevideo.setVisibility(View.VISIBLE);
        }
    }

    private void getVideoList() {
        this.videoList = new ArrayList<VideoModel>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "datetaken";
        final Cursor cur = getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getStoryFolderPath() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final VideoModel videoData = new VideoModel();
                videoData.videoDuration = cur.getLong(bucketColumn);
                videoData.videoFullPath = cur.getString(data);
                videoData.videoName = cur.getString(name);
                videoData.dateTaken = cur.getLong(dateTaken);
                if (new File(videoData.videoFullPath).exists()) {
                    this.videoList.add(videoData);
                }
            } while (cur.moveToNext());
        }
    }

    private void setAdapṭer() {
        if (videoList.size() <= 0) {
            rvVideoList.setVisibility(View.GONE);
        } else {
            rvVideoList.setVisibility(View.VISIBLE);
        }
        videoAdapter = new VideoAdapter(activity, videoList);
        gridLayoutManager = new StaggeredGridLayoutManager(2, 1);
        gridLayoutManager.setAutoMeasureEnabled(true);
        rvVideoList.setLayoutManager(gridLayoutManager);
        rvVideoList.setAdapter(videoAdapter);
        videoAdapter.notifyDataSetChanged();

    }

    public void onBackPressed() {
        Intent intent = new Intent(activity, HomeActivity.class);
        startActivity(intent);
        finish();
    }

    public void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }
}
