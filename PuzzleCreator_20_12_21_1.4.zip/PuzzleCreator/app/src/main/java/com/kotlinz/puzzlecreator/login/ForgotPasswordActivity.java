package com.kotlinz.puzzlecreator.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputLayout;
import com.kotlinz.puzzlecreator.activity.BaseActivity;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.model.Credentials;
import com.kotlinz.puzzlecreator.retrofit.APIClient;
import com.kotlinz.puzzlecreator.retrofit.APIInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPasswordActivity extends BaseActivity {
    TextInputLayout tmnumber, tpass, trepass;
    EditText edtpass, edtrepass, edtmobile;
    Button btnsubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        setarrawToolbar();
        edtmobile = (EditText) findViewById(R.id.edtmobile);
        edtpass = (EditText) findViewById(R.id.edtPassword);
        edtrepass = (EditText) findViewById(R.id.edtRePassword);

        tpass = (TextInputLayout) findViewById(R.id.tpass);
        trepass = (TextInputLayout) findViewById(R.id.trepass);
        tmnumber = (TextInputLayout) findViewById(R.id.tmnumber);

        btnsubmit = (Button) findViewById(R.id.btnsubmit);
        edtrepass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edtpass.getText().toString().equalsIgnoreCase(edtrepass.getText().toString())) {
                    trepass.setErrorEnabled(true);
                    trepass.setError("Both Password Not Match");
                } else {
                    trepass.setErrorEnabled(false);
                }
            }
        });
        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtmobile.getText().toString().equalsIgnoreCase("")) {
                    tmnumber.setErrorEnabled(true);
                    tmnumber.setError("Enter Mobile");
                } else if (edtmobile.getText().toString().length() != 10) {
                    tmnumber.setErrorEnabled(true);
                    tmnumber.setError("Enter 10 Digit Mobile Number");
                } else if (edtpass.getText().toString().equalsIgnoreCase("")) {
                    tpass.setErrorEnabled(true);
                    tpass.setError("Enter Password");
                } else if (edtrepass.getText().toString().equalsIgnoreCase("")) {
                    trepass.setErrorEnabled(true);
                    trepass.setError("Enter Re-password");
                } else if (!edtpass.getText().toString().equalsIgnoreCase(edtrepass.getText().toString())) {
                    trepass.setErrorEnabled(true);
                    trepass.setError("Both password not match");
                } else {
                    Forgot_Password(edtmobile.getText().toString(), edtpass.getText().toString());
                }
            }
        });
    }
    private void Forgot_Password(String number, String password)  {

        showProgressDialog();
        Credentials forgot = new Credentials();
        forgot.mobile_number = number;
        forgot.password = password;
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).ForgotPassword(forgot);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> res) {
                if (res.code() == 200) {
                    try {
                        String result=res.body().string();
                        JSONObject obj = new JSONObject(result);
                        if (obj.getBoolean("status")) {
                            cancel_dialog();
                            Intent i = new Intent(ForgotPasswordActivity.this, LoginActivity.class);
                            startActivity(i);
                            finish();
                        } else {
                            cancel_dialog();
                            showerrorDialog("Failed", obj.getString("message"));
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                    cancel_dialog();
                } else {
                    try {
                        JSONObject obj = new JSONObject(res.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }

}