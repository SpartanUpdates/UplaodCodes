package com.root.bridge;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.mbit.VideoMaker.Activity.CustomizeTextActivity;
import com.mbit.VideoMaker.Activity.HomeActivity;
import com.mbit.VideoMaker.Activity.ImageSelectActivity;
import com.mbit.VideoMaker.Activity.OnlineSongActivity;
import com.mbit.VideoMaker.Activity.VideoPlayerActivity;
import com.mbit.VideoMaker.AllData.GetUrl;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Extra.kprogresshud.KProgressHUD;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.UnityPlayerActivity;
import com.mbit.VideoMaker.application.MyApplication;
import com.unity3d.player.UnityPlayer;

import java.io.File;

public class AndroidPluginClass {
    public static KProgressHUD hud;
    public static void InitilizeAppData(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10) {
        GetUrl.l = str;
        GetUrl.k = str2;
        GetUrl.c = str3;
        GetUrl.a = str4;
        GetUrl.b = str5;
        GetUrl.g = str6;
        GetUrl.f = str7;
        GetUrl.d = str8;
        GetUrl.e = str9;
        GetUrl.j = str10;
        checkForNewTheme();

    }

    public static void LuanchApp(Context context) {
        if (UnityPlayerActivity.alertDialog != null && UnityPlayerActivity.alertDialog.isShowing()) {
            UnityPlayerActivity.alertDialog.dismiss();
        }
        if (MyApplication.aa) {
            loadMainActivityForAds(context);
        } else {
            loadMainActivity(context);
        }
    }

    private static void loadMainActivityForAds(final Context context) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                if (MyApplication.aa && MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(context)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
                                MyApplication.mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Toast.makeText(context, "MainAct Without Ads", Toast.LENGTH_SHORT).show();
                    loadMainActivity(context);
                }
            }
        });


    }

    public static void loadMainActivity(Context context) {
        Intent intent = new Intent(context, HomeActivity.class);
        context.startActivity(intent);
    }

    public static void LuanchAppFromMainMenu(Context context) {
        Intent intent = new Intent(context, HomeActivity.class);
        context.startActivity(intent);
    }

    public static void AddSound(Context context) {
        context.startActivity(new Intent(context, OnlineSongActivity.class));
    }


    public static void CallGallery(Context context, String str) {
        MyApplication.IsSelectImageFrom = false;
        MyApplication.IS_EDITIMAGE = 0;
        MyApplication.TotalSelectedImage = 6;
//        MyApplication.getInstance().getSelectedImageslist().clear();
        MyApplication.getInstance().getCropImages().clear();
        Intent intent = new Intent(context, ImageSelectActivity.class);
        intent.putExtra("NoofImage", 6);
        context.startActivity(intent);
    }

    public static void EditInput(Context context, String str) {
        Intent intent = new Intent(context, CustomizeTextActivity.class);
        intent.putExtra("JsonStr", str);
        context.startActivity(intent);
    }


    public static void AfterAdsDoneAction(Context context) {
        Intent intent = new Intent(context, VideoPlayerActivity.class);
        intent.putExtra("VideoUrl", AppUsages.VideoOutputFullPath);
        intent.putExtra("VideoPosition", 0);
        intent.putExtra("AllVideoList", Utils.getAllCreatedVideoList(context));
        intent.putExtra("IsVideoFromAndroidList", false);
        context.startActivity(intent);
        RefereshVideoList(context, AppUsages.VideoOutputFullPath);
        AppUsages.LastTime = 0.0f;
        DeleteCropImages();
    }


    public static void LoadVideo(Context context) {
        AfterAdsDoneAction(context);
    }

    public static void DeleteCropImages() {
        Utils util = new Utils();
        String path = util.getOutputPath() + "CropTempImg" + File.separator;
        File folder = new File(path);
        util.deleteRecursive(folder);
    }

    public static void RefereshVideoList(Context cntx, String path) {
        try {
            android.media.MediaScannerConnection.scanFile(cntx,
                    new String[]{path},
                    new String[]{"video/mp4"},
                    new android.media.MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void checkForNewTheme() {
//        new a().execute(new String[0]);
    }

    public static void createVideo(Context context, String str, String str2, String str3, String str4) {
        AppUsages.AudioVideoShort(context, str2, str3);
    }


    public static void gotoUnlockPartical(Context context, final String str) {
        Log.e("VideoAds", "gotoUnlockPartical : ".concat(String.valueOf(str)));
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                StringBuilder stringBuilder;
                try {
                    UnityPlayerActivity.m = str.split(":")[0];
                    UnityPlayerActivity.n = str.split(":")[1];
                    stringBuilder = new StringBuilder("isTransition : ");
                    stringBuilder.append(UnityPlayerActivity.n);
                    Log.e("VideoAds", stringBuilder.toString());
                    Context context = UnityPlayerActivity.l;
                    try {
                        if (UnityPlayerActivity.l.mRewardedVideoAd == null) {
                            UnityPlayerActivity.l.loadRewardedVideo();
                        } else if (UnityPlayerActivity.l.mRewardedVideoAd.isLoaded()) {
                            UnityPlayerActivity.l.mRewardedVideoAd.show();
                        } else {
                            if (Utils.checkConnectivity(context, false)) {
                                String str;
                                String str2;
                                String str3;
                                if (UnityPlayerActivity.n.equalsIgnoreCase("0")) {
                                    str = "UnlockParticle";
                                    str2 = "UnloackParticalsFromAndroid";
                                    str3 = UnityPlayerActivity.m;
                                } else {
                                    if (UnityPlayerActivity.n.equalsIgnoreCase("1")) {
                                        str = "UnlockTransaction";
                                        str2 = "UnlockTransactionFromAndroid";
                                        str3 = UnityPlayerActivity.m;
                                    }
                                    UnityPlayerActivity.l.i();
                                    return;
                                }
                                UnityPlayer.UnitySendMessage(str, str2, str3);
                                UnityPlayerActivity.l.i();
                                return;
                            }
                            Toast.makeText(context, "No Internet connection!", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                    stringBuilder = new StringBuilder("Ex : ");
                    stringBuilder.append(e2.getMessage());
                    Log.e("Error", stringBuilder.toString());
                }
            }
        });
    }

    public static void prepareSongForCreateVideo(Context context, String str, String str2, String str3, String str4) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.GONE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        AppUsages.AddSongTOVideo(context, str2, str4, str, str3);
    }
}
