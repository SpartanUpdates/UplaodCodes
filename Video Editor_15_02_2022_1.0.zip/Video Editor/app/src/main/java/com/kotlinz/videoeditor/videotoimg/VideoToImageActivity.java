package com.kotlinz.videoeditor.videotoimg;

import static com.kotlinz.videoeditor.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.net.ParseException;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RemoteViews;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.bumptech.glide.Glide;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.StartActivity;
import com.kotlinz.videoeditor.activity.VideoPlayerActivity;
import com.kotlinz.videoeditor.editvideo.activity.EditActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

@SuppressLint({"WrongConstant"})
public class VideoToImageActivity extends AppCompatActivity implements OnSeekBarChangeListener {

    Activity activity = VideoToImageActivity.this;
    public static String PATH = "";
    public static ArrayList<Integer> myList = new ArrayList<>();
    static final boolean s = true;
    public static int time;
    Handler a = new Handler();
    VideoView b;
    int c = 0;
    TextView d;
    TextView e;
    ImageView g;
    SeekBar h;
    int i = 0;
    boolean j = false;
    Bitmap k;
    File l;
    String m;
    File n;
    String o;
    String p;
    private static final String CHANNEL_ID = "channel_id01";
    public static final int NOTIFICATION_ID = 1;
    ImageView ivback, ivNext;
    private ImageView ivThumbnail;
    TextView tvToolbarName;
    Uri NotificationUri;

    private NativeAd nativeAd;


    OnClickListener q = new OnClickListener() {
        @Override
        public void onClick(View view) {
            b.setVisibility(View.VISIBLE);
            ivThumbnail.setVisibility(View.INVISIBLE);
            if (j) {
                try {
                    b.pause();
                    a.removeCallbacks(r);
                    g.setBackgroundResource(R.drawable.ic_play_upress);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    b.seekTo(VideoToImageActivity.this.h.getProgress());
                    b.start();
                    a.postDelayed(VideoToImageActivity.this.r, 200);
                    b.setVisibility(0);
                    g.setBackgroundResource(R.drawable.ic_pause_unpresss);
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            j ^= VideoToImageActivity.s;
        }
    };
    Runnable r = new Runnable() {
        public void run() {
            if (VideoToImageActivity.this.b.isPlaying()) {
                int currentPosition = VideoToImageActivity.this.b.getCurrentPosition();
                VideoToImageActivity.this.h.setProgress(currentPosition);
                try {
                    VideoToImageActivity.this.d.setText(VideoPlayerActivity.formatTimeUnit(currentPosition));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (currentPosition == VideoToImageActivity.this.i) {
                    VideoToImageActivity.this.h.setProgress(0);
                    VideoToImageActivity.this.d.setText("00:00");
                    VideoToImageActivity.this.a.removeCallbacks(VideoToImageActivity.this.r);
                    return;
                }
                VideoToImageActivity.this.a.postDelayed(VideoToImageActivity.this.r, 200);
                return;
            }
            VideoToImageActivity.this.h.setProgress(VideoToImageActivity.this.i);
            try {
                VideoToImageActivity.this.d.setText(VideoPlayerActivity.formatTimeUnit(VideoToImageActivity.this.i));
            } catch (ParseException e2) {
                e2.printStackTrace();
            }
            VideoToImageActivity.this.a.removeCallbacks(VideoToImageActivity.this.r);
        }
    };
    private FileOutputStream t;


    private class DownloadImage extends AsyncTask<Void, Void, Void> {
        private ProgressDialog progressDialog;

        public void onPreExecute() {
            progressDialog = ProgressDialog.show(VideoToImageActivity.this, "Capture Image", "Please wait...", VideoToImageActivity.s);
            super.onPreExecute();
        }

        public Void doInBackground(Void... voidArr) {
            try {
                Thread.sleep(1000);
                VideoToImageActivity.this.storeImage();
                Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                intent.setData(Uri.fromFile(new File(VideoToImageActivity.this.o)));
                VideoToImageActivity.this.sendBroadcast(intent);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            } catch (NoSuchMethodError e2) {
                e2.printStackTrace();
            } catch (IllegalArgumentException e3) {
                e3.printStackTrace();
            } catch (NullPointerException e4) {
                e4.printStackTrace();
            } catch (Exception e5) {
                e5.printStackTrace();
            }
            return null;
        }

        public void onPostExecute(Void voidR) {
            progressDialog.dismiss();
            super.onPostExecute(voidR);
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.videotoimageactivity);
        PutAnalyticsEvent();
        LoadNativeAds();
        tvToolbarName = findViewById(R.id.tv_app_name);
        ivThumbnail = findViewById(R.id.iv_thumbnail);
        ivback = findViewById(R.id.iv_back);
        ivNext = findViewById(R.id.iv_done);
        myList.clear();
        this.b = findViewById(R.id.videoView_player);
        this.h = findViewById(R.id.sbVideo);
        this.h.setOnSeekBarChangeListener(this);
        this.d = findViewById(R.id.left_pointer);
        this.e = findViewById(R.id.right_pointer);
        this.g = findViewById(R.id.btnPlayVideo);
        PATH = getIntent().getStringExtra("videouri");
        Glide.with(activity).asBitmap().load((PATH)).into(ivThumbnail);
        b.setVideoURI(Uri.parse(PATH));
        this.b.seekTo(100);
        NotificationUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.notification);
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivNext.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(activity, StartActivity.class));
                finish();
            }
        });
        this.b.setOnErrorListener(new OnErrorListener() {
            public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                Toast.makeText(activity, "Video Player Not Supporting", Toast.LENGTH_SHORT).show();
                return s;
            }
        });
        b.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                i = b.getDuration();
                h.setMax(i);
                d.setText("00:00");
                try {
                    e.setText(formatTimeUnit(i));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });
        this.b.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                b.setVisibility(0);
                g.setBackgroundResource(R.drawable.ic_play_upress);
                b.seekTo(0);
                h.setProgress(0);
                d.setText("00:00");
                a.removeCallbacks(r);
                j ^= VideoToImageActivity.s;
            }
        });
        g.setOnClickListener(q);
        findViewById(R.id.imageView_capture).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                /* SimpleNotification();*/
                time = b.getCurrentPosition() * 1000;
                k = getVideoFrame(PATH);
                new DownloadImage().execute();
            }
        });
        return;
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoToImageActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (VideoToImageActivity.this.nativeAd != null) {
                            VideoToImageActivity.this.nativeAd.destroy();
                        }
                        VideoToImageActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void SimpleNotification() {
        createNotificationChannel();
        RemoteViews remoteCollapsedViews = new RemoteViews(getPackageName(), R.layout.custom_normal);
        Intent mainIntent = new Intent(activity, VideoToImageActivity.class);
        mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent mainPIntent = PendingIntent.getActivity(this, 0, mainIntent, PendingIntent.FLAG_ONE_SHOT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID);
        builder.setSmallIcon(R.drawable.ic_baseline_notifications_24);
        builder.setDefaults(Notification.DEFAULT_SOUND);
        builder.setDefaults(Notification.DEFAULT_VIBRATE);
        builder.setPriority(NotificationCompat.PRIORITY_HIGH);
        builder.setAutoCancel(true);
        builder.setContentIntent(mainPIntent);
        builder.setStyle(new NotificationCompat.DecoratedCustomViewStyle());
        builder.setCustomContentView(remoteCollapsedViews);
        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(this);
        notificationManagerCompat.notify(NOTIFICATION_ID, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            CharSequence name = "My Notification";
            String description = "My notification description";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            notificationChannel.setDescription(description);

            NotificationManager notificationManager = (NotificationManager)
                    getSystemService(NOTIFICATION_SERVICE);

            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    public void storeImage() {
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb.append("/");
        sb.append(getResources().getString(R.string.MainFolderName));
        sb.append("/");
        sb.append(getResources().getString(R.string.VideoToImage));
        this.l = new File(sb.toString());
        if (!this.l.exists()) {
            this.l.mkdirs();
        }
        Calendar instance = Calendar.getInstance();
        int i2 = instance.get(13);
        int i3 = instance.get(10);
        int i4 = instance.get(12);
        StringBuilder sb2 = new StringBuilder();
        sb2.append(i3);
        sb2.append("-");
        sb2.append(i4);
        sb2.append("-");
        sb2.append(i2);
        this.p = sb2.toString();
        StringBuilder sb3 = new StringBuilder("Image");
        sb3.append(this.p);
        sb3.append(".jpg");
        this.m = sb3.toString();
        this.n = new File(this.l, this.m);
        this.o = this.n.getAbsolutePath();
        try {
            this.t = new FileOutputStream(this.n);
            this.k.compress(CompressFormat.PNG, 90, this.t);
            Context applicationContext = getApplicationContext();
            StringBuilder sb4 = new StringBuilder("Saved\n");
            sb4.append(this.o);
            Toast.makeText(applicationContext, sb4.toString(), Toast.LENGTH_LONG).show();
            this.t.flush();
            this.t.close();
        } catch (Exception unused) {
            unused.printStackTrace();
        }
    }

    public static Bitmap getVideoFrame(String str) {
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        mediaMetadataRetriever.setDataSource(str);
        return mediaMetadataRetriever.getFrameAtTime(time);
    }

    public void onProgressChanged(SeekBar seekBar, int i2, boolean z) {
        if (z) {
            this.b.seekTo(i2);
            try {
                this.d.setText(formatTimeUnit(i2));
            } catch (ParseException e2) {
                e2.printStackTrace();
            }
        }
    }

    @SuppressLint({"NewApi"})
    public static String formatTimeUnit(long j2) throws ParseException {
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }


    @Override
    public void onBackPressed() {
        File file = new File(PATH);
        MediaScannerConnection.scanFile(this, new String[]{file.getPath()},
                null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        // now visible in gallery
                    }
                });
        Intent intent = new Intent(getApplicationContext(), EditActivity.class);
        intent.setFlags(67108864);
        intent.putExtra("videofilename", PATH);

        startActivity(intent);
        finish();
    }


    public void onPause() {
        this.c = this.b.getCurrentPosition();
        super.onPause();
    }


    @Override
    public void onResume() {
        this.b.seekTo(this.c);
        super.onResume();
    }
}
