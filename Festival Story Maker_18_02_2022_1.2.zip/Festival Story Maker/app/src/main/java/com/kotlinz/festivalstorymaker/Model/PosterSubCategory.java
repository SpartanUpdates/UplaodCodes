package com.kotlinz.festivalstorymaker.Model;

import com.google.gson.annotations.SerializedName;

public class PosterSubCategory {
    @SerializedName("response")
    private PosterCategoryResponse mResponse;
    @SerializedName("success")
    private String mSuccess;

    public PosterCategoryResponse getResponse() {
        return mResponse;
    }

    public void setResponse(PosterCategoryResponse response) {
        mResponse = response;
    }

    public String getSuccess() {
        return mSuccess;
    }

    public void setSuccess(String success) {
        mSuccess = success;
    }
}
