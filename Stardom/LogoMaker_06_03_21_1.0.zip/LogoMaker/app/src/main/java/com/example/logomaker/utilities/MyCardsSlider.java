package com.example.logomaker.utilities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import androidx.viewpager.widget.ViewPager;

import com.example.logomaker.R;

import java.io.File;

public class MyCardsSlider extends Activity implements OnClickListener {
    File[] file;
    ViewPager pager;
    ImageView img_back;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.slider_layout);

        img_back=findViewById(R.id.img_back);
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        this.pager = (ViewPager) findViewById(R.id.viewPager);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
        stringBuilder.append(File.separator);
        stringBuilder.append(Constants.D_NAME);


        this.file = new File(stringBuilder.toString()).listFiles();
        this.pager.setAdapter(new SliderPagerAdapter(this, this.file));
        this.pager.setCurrentItem(getIntent().getIntExtra(Constants.SELECTED_ITEM, 0));
        findViewById(R.id.share).setOnClickListener(this);
    }

    public void onBackPressed() {

        super.onBackPressed();
    }

    public void shareITems() {
        String path = this.file[this.pager.getCurrentItem()].getPath();
        Intent intent = new Intent(Intent.ACTION_SEND);
        Uri parse = Uri.parse(path);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_STREAM, parse);
        startActivity(Intent.createChooser(intent, "Share using"));
    }

    public void onClick(View view) {
        shareITems();
    }
}
