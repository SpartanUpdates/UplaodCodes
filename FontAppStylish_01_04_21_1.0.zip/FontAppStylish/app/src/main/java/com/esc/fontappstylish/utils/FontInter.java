package com.esc.fontappstylish.utils;

public interface FontInter {

    public static final class DefaultImpls {
        public static float getExtraPaddingDownFactor(FontInter fontInter) {
            return 0.0f;
        }

        public static float getSizeFactorButton(FontInter fontInter) {
            return 1.0f;
        }

        public static float getSizeFactorKeys(FontInter fontInter) {
            return 1.0f;
        }

        public static boolean isUpsideDown(FontInter fontInter) {
            return false;
        }

        public static CharSequence letter(FontInter fontInter, int i, boolean z) {
            i -= 97;
            if (i < 0 || i > 25) {
                return null;
            }
            if (z) {
                return fontInter.getUppercase()[i];
            }
            return fontInter.getLowercase()[i];
        }
    }

    float getExtraPaddingDownFactor();

    CharSequence[] getLowercase();

    String getName();

    float getSizeFactorButton();

    float getSizeFactorKeys();

    CharSequence[] getUppercase();

    boolean isUpsideDown();

    CharSequence letter(int i, boolean z);
}
