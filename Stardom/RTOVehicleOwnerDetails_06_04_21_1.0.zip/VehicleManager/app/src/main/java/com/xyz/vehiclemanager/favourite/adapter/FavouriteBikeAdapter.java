package com.xyz.vehiclemanager.favourite.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.activity.BikeVariantActivity;
import com.xyz.vehiclemanager.favourite.Room.FavoriteDatabase;
import com.xyz.vehiclemanager.favourite.model.FavoriteBikeModel;

import java.util.ArrayList;
import java.util.List;

public class FavouriteBikeAdapter extends RecyclerView.Adapter<FavouriteBikeAdapter.ViewHolder> {
    Context context;
    List<FavoriteBikeModel> favoriteBikeModelList;

    public FavouriteBikeAdapter(Context context, List<FavoriteBikeModel> favoriteBikeModelList) {
        this.context = context;
        this.favoriteBikeModelList = favoriteBikeModelList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_bikemodelname, tv_bikemodelprice;
        ImageView iv_bikecategory;
        LikeButton likeButton;
        LinearLayout ll_main;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_bikemodelname =itemView.findViewById(R.id.tv_carname);
            tv_bikemodelprice =itemView.findViewById(R.id.tv_modelprice);
            iv_bikecategory =itemView.findViewById(R.id.iv_category);
            likeButton=itemView.findViewById(R.id.likeButton);
            ll_main = itemView.findViewById(R.id.ll_main);
        }
    }
    private void deleteItem(int position2) {
        favoriteBikeModelList.remove(position2);
        notifyItemRemoved(position2);
        notifyItemRangeChanged(position2, favoriteBikeModelList.size());
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_favorite, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final FavoriteBikeModel favoriteBikeModel=favoriteBikeModelList.get(position);
        final String id=favoriteBikeModel.getModelId();
        holder.tv_bikemodelname.setText(favoriteBikeModel.getModelName());
        holder.tv_bikemodelprice.setText(favoriteBikeModel.getExShowroomPrice());
        Glide.with(context)
                .load(favoriteBikeModel.getImageUrl())
                .placeholder(R.drawable.ic_bike)
                .into(holder.iv_bikecategory);

        holder.likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                Thread thread=new Thread(new Runnable() {
                    @Override
                    public void run() {
                        FavoriteDatabase.getFavoriteDatabase(context).favoriteBikeDao().insertBikeFavorite(favoriteBikeModel);
                    }
                });
                thread.start();
            }
            @Override
            public void unLiked(LikeButton likeButton) {
                Thread thread=new Thread(new Runnable() {
                    @Override
                    public void run() {
                        FavoriteDatabase.getFavoriteDatabase(context).favoriteBikeDao().deleteBikeFavorite(id);
                        deleteItem(position);
                    }
                });
                thread.start();

            }
        });
        holder.ll_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, BikeVariantActivity.class);
                intent.putExtra("modelId",id);
                intent.putExtra("modelName", favoriteBikeModel.getModelName());
                intent.putExtra("imageUrl",favoriteBikeModel.getImageUrl());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }
    @Override
    public int getItemCount() {
        return favoriteBikeModelList.size();
    }
}
