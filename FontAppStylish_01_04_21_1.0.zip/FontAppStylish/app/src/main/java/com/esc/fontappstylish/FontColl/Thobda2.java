package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Thobda2 implements FontInter {
    public CharSequence[] getLowercase() {
        CharSequence[] r0 = new CharSequence[26];
        String str = "𖦹";
        r0[9] = str;
        r0[10] = "❁";
        r0[11] = "᯾";
        r0[12] = "𒊹";
        r0[13] = "✪";
        r0[14] = "⁂";
        r0[15] = "⌘";
        r0[16] = "᪥";
        r0[17] = "𖧷";
        r0[18] = str;
        r0[19] = "߷";
        r0[20] = "༄";
        r0[21] = "✰";
        r0[22] = "✯";
        r0[23] = "☆";
        r0[24] = "༆";
        r0[25] = "★";
        return r0;
    }

    public String getName() {
        return "☼᯽✫";
    }

    public float getSizeFactorKeys() {
        return 0.95f;
    }

    public CharSequence[] getUppercase() {
        CharSequence[] r0 = new CharSequence[26];
        String str = "𖦹";
        r0[9] = str;
        r0[10] = "❁";
        r0[11] = "᯾";
        r0[12] = "𒊹";
        r0[13] = "✪";
        r0[14] = "⁂";
        r0[15] = "⌘";
        r0[16] = "᪥";
        r0[17] = "𖧷";
        r0[18] = str;
        r0[19] = "߷";
        r0[20] = "༄";
        r0[21] = "✰";
        r0[22] = "✯";
        r0[23] = "☆";
        r0[24] = "༆";
        r0[25] = "★";
        return r0;
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
