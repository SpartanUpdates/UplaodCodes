﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

namespace BallCollect
{
    public class PlayerSelection : MonoBehaviour
    {
        public static PlayerSelection instance;

        public int unlockAmount=700;

        public DragRect scrollRact;

        public GameObject[] playerBtn;

        public GameObject[] ballBtn;

        public GameObject unlockLable;

        public Image showPlayer;

        public Text unlockTxt, unlockTxt2;

        public MeshRenderer playerMesh;

        public Material playerColor, playerSkin,ballMaterial;

        public Texture[] playerSkinTexture;

        public Sprite[] ballImage,playerImage;
        private void Awake()
        {
            instance = this;
            unlockLable.SetActive(false);

        }
        void Start()
        {
            unlockAmount = 700;
            ChangePlayer();
            ChangeBall();
        }
        public void ChangePlayer()
        {
            if (DataBase.GetPlayer() <= 9)
            {
                playerMesh.material = playerColor;
                playerMesh.material.color = ColorManager.PlayerColor[DataBase.GetPlayer()-1];
            }
            else
            {
                playerMesh.material = playerSkin;
                playerMesh.material.SetTexture("_MainTex",playerSkinTexture[DataBase.GetPlayer() - 1]);
            }
        }
        public void ChangeBall()
        {
               ballMaterial.color= ColorManager.ballColors[DataBase.GetBall() - 1];
        }
        public void PageChange(int index)
        {
            SoundManger.instance.PlaySound("BtnClick");

            if (GameController.instance.isVibrate)
                VibrationManager.Haptic(VibrateType.Selection, false);

            scrollRact.ChangePage(index);
        }
     
        public void SelectPlayer(int Playerno)
        {
            SoundManger.instance.PlaySound("BtnClick");

            if (GameController.instance.isVibrate)
                VibrationManager.Haptic(VibrateType.Selection, false);

            if (PlayerPrefs.GetInt("Player" + Playerno) == 0)
            {
                if (DataBase.GetCoins() >= unlockAmount)
                {
                    PlayerPrefs.SetInt("Player" + Playerno, 1);
                    DataBase.SetCoins(DataBase.GetCoins() - unlockAmount);
                    GameController.instance.coinText.text = DataBase.GetCoins().ToString();
                    unlockLable.SetActive(false);
                    showPlayer.sprite = playerImage[Playerno - 1];
                    playerBtn[Playerno - 1].GetComponent<CheckUnlock>().CheckButton();
                    DataBase.SetPlayer(Playerno);
                    for (int i = 0; i < playerBtn.Length; i++)
                    {
                        playerBtn[i].GetComponent<CheckUnlock>().UnlockImage();
                    }
                    playerBtn[Playerno - 1].GetComponent<CheckUnlock>().unlockImg.SetActive(true);
                }
                else
                {
                    unlockLable.SetActive(false);
                    StartCoroutine(playerBtn[Playerno - 1].GetComponent<CheckUnlock>().UnLockColor());
                    unlockLable.SetActive(true);
                }
            }
            else
            {
                showPlayer.sprite = playerImage[Playerno - 1];
                DataBase.SetPlayer(Playerno);
                for (int i = 0; i < playerBtn.Length; i++)
                {
                    playerBtn[i].GetComponent<CheckUnlock>().UnlockImage();
                }
                playerBtn[Playerno - 1].GetComponent<CheckUnlock>().unlockImg.SetActive(true);
            }
            ChangePlayer();
        }


        public void SelectBall(int ballNo)
        {
            SoundManger.instance.PlaySound("BtnClick");

            if (GameController.instance.isVibrate)
                VibrationManager.Haptic(VibrateType.Selection, false);

            if (PlayerPrefs.GetInt("Ball" + ballNo) == 0)
            {
                if (DataBase.GetCoins() >= unlockAmount)
                {
                    PlayerPrefs.SetInt("Ball" + ballNo, 1);
                    DataBase.SetCoins(DataBase.GetCoins() - unlockAmount);
                    GameController.instance.coinText.text = DataBase.GetCoins().ToString();
                    unlockLable.SetActive(false);
                    showPlayer.sprite = ballImage[ballNo - 1];//EventSystem.current.currentSelectedGameObject.transform.GetChild(0).GetComponent<Image>().sprite;
                    ballBtn[ballNo-1].GetComponent<CheckUnlock>().CheckButton();
                    DataBase.SetBall(ballNo);
                    for (int i = 0; i < ballBtn.Length; i++)
                    {
                        ballBtn[i].GetComponent<CheckUnlock>().UnlockImage();
                    }
                    ballBtn[ballNo - 1].GetComponent<CheckUnlock>().unlockImg.SetActive(true);
                }
                else
                {
                    unlockLable.SetActive(false);
                    StartCoroutine(ballBtn[ballNo - 1].GetComponent<CheckUnlock>().UnLockColor());
                    unlockLable.SetActive(true);
                }
            }
            else
            {
                unlockLable.SetActive(false);
                showPlayer.sprite = ballImage[ballNo - 1];
                DataBase.SetBall(ballNo);
                for (int i = 0; i < ballBtn.Length; i++)
                {
                    ballBtn[i].GetComponent<CheckUnlock>().UnlockImage();
                }
                ballBtn[ballNo - 1].GetComponent<CheckUnlock>().unlockImg.SetActive(true);
            }
            ChangeBall();
        }
        void OnApplicationQuit()
        {
            ballMaterial.color = ColorManager.ballColors[0];
        }
    }
}