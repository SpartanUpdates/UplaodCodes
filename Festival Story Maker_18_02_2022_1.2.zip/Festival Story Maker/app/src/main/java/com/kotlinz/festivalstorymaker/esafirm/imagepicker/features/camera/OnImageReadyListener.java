package com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.camera;

import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import java.util.List;

public interface OnImageReadyListener {
    void onImageReady(List<Image> image);
}
