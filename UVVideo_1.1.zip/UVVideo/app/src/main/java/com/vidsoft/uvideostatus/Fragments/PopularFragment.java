package com.vidsoft.uvideostatus.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.OnScrollListener;
import com.google.android.exoplayer.text.ttml.TtmlNode;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import com.vidsoft.uvideostatus.Activity.Video_play_Activity;
import com.vidsoft.uvideostatus.Adapters.PopularAdapter;
import com.vidsoft.uvideostatus.Models.VideoData;
import com.vidsoft.uvideostatus.R;
import com.vidsoft.uvideostatus.Utility.Utility;
import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpHeaders;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PopularFragment extends Fragment implements OnClickListener {
    RecyclerView album_recyclerview;
    int counterlimit = 0;
    public boolean isLastPage = false;
    PopularAdapter mAdapter;
    LinearLayoutManager mLayoutManager;
    public int totalCount = 1;
    public static ArrayList<VideoData> videoData = new ArrayList<>();

    class dataTrendingHandler extends AsyncHttpResponseHandler {
        dataTrendingHandler() {
        }

        public void onStart() {
            super.onStart();
        }


        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            String str = "url";
            String str2 = new String(bArr);
            StringBuilder sb = new StringBuilder();
            sb.append("getcatogoryvideo:popu ");
            sb.append(str2);
            Log.d("ContentValues", sb.toString());
            try {
                JSONArray jSONArray = new JSONArray(str2);
                PopularFragment.videoData = new ArrayList<>();
                try {
                    if (jSONArray.length() != 0) {
                        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                            JSONObject jSONObject = jSONArray.getJSONObject(i2);
                            VideoData videoDataobj = new VideoData();
                            videoDataobj.setVideo_id(jSONObject.getLong(TtmlNode.ATTR_ID));
//                            videoData.setTitle(jSONObject.getString(NotificationTable.COLUMN_NAME_TITLE));
                            videoDataobj.setTitle(jSONObject.getString("title"));
                            videoDataobj.setUrl(jSONObject.getString(str));
                            videoDataobj.setReal_videopath(jSONObject.getString(str));
                            videoDataobj.setThumbnail(jSONObject.getString(TtmlNode.TAG_IMAGE));
                            videoDataobj.setCatagory(jSONObject.getString("cname"));
                            videoDataobj.setViews(jSONObject.getString("downloads"));
                            videoData.add(videoDataobj);
                        }
                        SetAdapter();
//                        PopularFragment.this.mAdapter.addAll(PopularFragment.videoData);
                        PopularFragment.this.totalCount = PopularFragment.this.totalCount + 1;
                        if (PopularFragment.videoData.size() < 20) {
                            PopularFragment.this.isLastPage = true;
                        } else {
                            PopularFragment.this.isLastPage = false;
                        }
                    } else {
                        PopularFragment.this.isLastPage = true;
                    }
                    PopularFragment.this.mAdapter.setLoaded();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } catch (Exception unused) {
            }
        }

        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
            StringBuilder sb = new StringBuilder();
            sb.append("");
            sb.append(th.getMessage());
            Log.e("=>>", sb.toString());
        }
    }

    public void onClick(View view) {
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.trending_fragment, viewGroup, false);
        initViews(inflate);
        return inflate;
    }

    private void initViews(View view) {
        this.album_recyclerview = (RecyclerView) view.findViewById(R.id.album_recyclerview);

        this.album_recyclerview.addOnScrollListener(new OnScrollListener() {
            public void onScrollStateChanged(RecyclerView recyclerView, int i) {
                super.onScrollStateChanged(recyclerView, i);
            }

            public void onScrolled(RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                if (i2 > 0) {
                    if (PopularFragment.this.mLayoutManager.getChildCount() + PopularFragment.this.mLayoutManager.findFirstVisibleItemPosition() >= PopularFragment.this.mLayoutManager.getItemCount() && !PopularFragment.this.isLastPage) {
                        videoData.remove(videoData.size() - 1);
                        mAdapter.notifyItemRemoved(PopularFragment.videoData.size());
                        VideoData videoDataobj = new VideoData();
                        videoDataobj.setType(2);
                        videoData.add(videoDataobj);
                        mAdapter.notifyItemInserted(videoData.size() - 1);
                        PopularFragment popularFragment = PopularFragment.this;
                        popularFragment.getTrendingVideo(popularFragment.counterlimit);
                    }
                }
            }
        });
        getTrendingVideo(this.counterlimit);
    }

    public void SetAdapter(){
        this.mLayoutManager = new LinearLayoutManager(getActivity());
        this.album_recyclerview.setLayoutManager(this.mLayoutManager);
        this.album_recyclerview.setItemAnimator(new DefaultItemAnimator());
        this.album_recyclerview.addItemDecoration(new DividerItemDecoration(getActivity(), 0));
        this.mAdapter = new PopularAdapter(getActivity(), videoData, this);
        this.album_recyclerview.setAdapter(this.mAdapter);
//        mAdapter.notifyDataSetChanged();
    }

    public void getTrendingVideo(int i) {
        JSONObject jSONObject = new JSONObject();
        JSONObject jSONObject2 = new JSONObject();
        try {
            jSONObject.put("cid", 1);
            jSONObject2.put("_id", -1);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestParams requestParams = new RequestParams();
        requestParams.put("q", jSONObject.toString());
        requestParams.put("sk", i);
        requestParams.put("l", 20);
        requestParams.put("s", jSONObject2.toString());
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        asyncHttpClient.setTimeout(60000);
        StringBuilder sb = new StringBuilder();
        sb.append(Utility.baseUrl);
        sb.append("collections/tbl_video?apiKey=");
        sb.append(Utility.apiKey);
        asyncHttpClient.get(sb.toString(), requestParams, (ResponseHandlerInterface) new dataTrendingHandler());
        this.counterlimit += 3;
    }

    public void playVideo(VideoData videoData2) {
        Intent intent = new Intent(getActivity(), Video_play_Activity.class);
        intent.putExtra("VIDEO_PATH", videoData2.getReal_videopath());
        intent.putExtra("list", videoData2);
        intent.putExtra(HttpHeaders.FROM, "PopularFragment");
        StringBuilder sb = new StringBuilder();
        sb.append("playVideo: ");
        sb.append(videoData2.getReal_videopath());
        sb.append(" ");
        sb.append(videoData2.getTitle());
        Log.d("TAG", sb.toString());
        startActivity(intent);
    }
}
