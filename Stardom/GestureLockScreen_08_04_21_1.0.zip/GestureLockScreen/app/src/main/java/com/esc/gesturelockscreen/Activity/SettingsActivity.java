package com.esc.gesturelockscreen.Activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.esc.gesturelockscreen.Other.Actions;
import com.esc.gesturelockscreen.Other.SettingsKeys;
import com.esc.gesturelockscreen.Other.SettingsUtils;
import com.esc.gesturelockscreen.Service.LockStateService;
import com.esc.gesturelockscreen.Service.ScreenLockService;
import com.esc.gesturelockscreen.R;

public class SettingsActivity extends Activity {
    private Activity activity = SettingsActivity.this;
    private boolean askedForOverlayPermission;
    private TextView disText1;
    private TextView disText2;
    private ImageView imgGesture;
    private ImageView imgSec;
    private CheckBox r0;
    private TextView tvEmergency;
    private TextView tvGesture;
    private TextView tvLock;
    private TextView tvSound;
    private TextView tvVibration;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    protected void onCreate(Bundle savedInstanceState) {
        int i;
        int i2 = R.string.s_on;
        super.onCreate(savedInstanceState);
        SettingsUtils.init(getApplicationContext());
        setContentView(R.layout.activity_settings);
        BannerAds();
        this.tvLock = (TextView) findViewById(R.id.tv_lock_subtitle);
        this.tvSound = (TextView) findViewById(R.id.tv_sound_subtitle);
        this.tvEmergency = (TextView) findViewById(R.id.tv_emergency_subtitle);
        this.tvVibration = (TextView) findViewById(R.id.tv_vibration_subtitle);
        this.tvGesture = (TextView) findViewById(R.id.tv_gesture_subtitle);
        this.imgSec = (ImageView) findViewById(R.id.image_sec);
        this.imgGesture = (ImageView) findViewById(R.id.image_gesuture);
        this.disText1 = (TextView) findViewById(R.id.tv_sec_title);
        this.disText2 = (TextView) findViewById(R.id.tv_sec_subtitle);
        boolean enabled = SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_LOCKSCREEN, false);
        if (enabled) {
            startService(new Intent(this, LockStateService.class));
            sendBroadcast(new Intent(Actions.BROADCAST_LOCK_ENABLED).setPackage(getPackageName()));
        }
        ((CheckBox) findViewById(R.id.check_lock)).setChecked(enabled);
        this.tvLock.setText(enabled ? R.string.s_lockscreen_enabled : R.string.s_lockscreen_disabled);
        ((CheckBox) findViewById(R.id.check_sound)).setChecked(SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_SOUND, true));
        this.tvSound.setText(SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_SOUND, true) ? R.string.s_on : R.string.s_off);
        ((CheckBox) findViewById(R.id.check_rel_emergency)).setChecked(SettingsUtils.getBoolean(SettingsKeys.KEY_QUICK_UNLOCK, true));
        TextView textView = this.tvEmergency;
        if (SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_VIBRATION, true)) {
            i = R.string.s_enabled;
        } else {
            i = R.string.s_disabled;
        }
        textView.setText(i);
        ((CheckBox) findViewById(R.id.check_vibration)).setChecked(SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_VIBRATION, true));
        TextView textView2 = this.tvVibration;
        if (!SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_VIBRATION, true)) {
            i2 = R.string.s_off;
        }
        textView2.setText(i2);
        ((CheckBox) findViewById(R.id.check_livewallpaper)).setChecked(SettingsUtils.getBoolean(SettingsKeys.KEY_SHOW_LIVEWALLPAPER, false));
        boolean gesutre = SettingsUtils.getBoolean(SettingsKeys.ENABLE_GESTURE, false);
        ((CheckBox) findViewById(R.id.check_gesture)).setChecked(gesutre);
        enabled(gesutre);
        ((CheckBox) findViewById(R.id.check_gesture)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton arg0, boolean check) {
                SettingsActivity.this.tvGesture.setText(check ? R.string.s_gesture_lock_enabled : R.string.s_gesture_lock_disabled);
                SettingsActivity.this.imgGesture.setImageResource(check ? R.drawable.ic_gesture_enable_icon : R.drawable.ic_gesture_disable_icon);
                if (check == SettingsUtils.getBoolean(SettingsKeys.ENABLE_GESTURE, false)) {
                    SettingsActivity.this.findViewById(R.id.rel_security).setEnabled(check);
                    SettingsActivity.this.enabled(check);
                } else if (check) {
                    SettingsUtils.putBoolean(SettingsKeys.ENABLE_GESTURE, check);
                    SettingsActivity.this.enabled(check);
                } else {
                    SettingsActivity.this.startActivityForResult(new Intent(SettingsActivity.this, GestureLockActivity.class), 13);
                }
            }
        });
        ((CheckBox) findViewById(R.id.check_sound)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                SettingsUtils.putBoolean(SettingsKeys.KEY_ENABLE_SOUND, arg1);
                SettingsActivity.this.tvSound.setText(arg1 ? R.string.s_on : R.string.s_off);
            }
        });
        ((CheckBox) findViewById(R.id.check_lock)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                boolean enabled = SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_LOCKSCREEN, true);
                SettingsActivity.this.tvLock.setText(arg1 ? R.string.s_lockscreen_enabled : R.string.s_lockscreen_disabled);
                if (arg1 != enabled) {
                    ((ImageView) SettingsActivity.this.findViewById(R.id.image0)).setImageResource(arg1 ? R.drawable.ic_lockenable_icon : R.drawable.ic_lockdisable_icon);
                    if (arg1 || !SettingsUtils.getBoolean(SettingsKeys.ENABLE_GESTURE, false)) {
                        SettingsUtils.putBoolean(SettingsKeys.KEY_ENABLE_LOCKSCREEN, arg1);
                        enabled = arg1;
                    } else {
                        SettingsActivity.this.startActivityForResult(new Intent(SettingsActivity.this, GestureLockActivity.class).putExtra("verify_n_create", false), 14);
                        return;
                    }
                }
                if (enabled) {
                    SettingsActivity.this.startService(new Intent(SettingsActivity.this, LockStateService.class));
                    SettingsActivity.this.sendBroadcast(new Intent(Actions.BROADCAST_LOCK_ENABLED).setPackage(SettingsActivity.this.getPackageName()));
                    return;
                }
                SettingsActivity.this.sendBroadcast(new Intent(Actions.BROADCAST_LOCK_DISABLED).setPackage(SettingsActivity.this.getPackageName()));
            }
        });
        ((CheckBox) findViewById(R.id.check_livewallpaper)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                SettingsUtils.putBoolean(SettingsKeys.KEY_SHOW_LIVEWALLPAPER, arg1);
            }
        });
        ((CheckBox) findViewById(R.id.check_rel_emergency)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override

            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                SettingsUtils.putBoolean(SettingsKeys.KEY_QUICK_UNLOCK, arg1);
                SettingsActivity.this.tvEmergency.setText(arg1 ? R.string.s_enabled : R.string.s_disabled);
            }
        });
        ((CheckBox) findViewById(R.id.check_vibration)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                SettingsUtils.putBoolean(SettingsKeys.KEY_ENABLE_VIBRATION, arg1);
                SettingsActivity.this.tvVibration.setText(arg1 ? R.string.s_on : R.string.s_off);
            }
        });
    }

    private void enabled(boolean gesutre) {
        this.tvGesture.setText(gesutre ? R.string.s_gesture_lock_enabled : R.string.s_gesture_lock_disabled);
        this.imgGesture.setImageResource(gesutre ? R.drawable.ic_gesture_enable_icon : R.drawable.ic_gesture_disable_icon);
        findViewById(R.id.rel_security).setEnabled(gesutre);
        this.disText1.setEnabled(gesutre);
        this.disText2.setEnabled(gesutre);
        this.imgSec.setImageResource(gesutre ? R.drawable.ic_security_icon : R.drawable.ic_security_disable_icon);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        boolean z = true;
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10) {
            this.askedForOverlayPermission = false;
            if (VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    startService(new Intent(this, ScreenLockService.class).setAction(Actions.SERVICE_PREVIEW_LOCK));
                } else {
                    Toast.makeText(this, "ACTION_MANAGE_OVERLAY_PERMISSION Permission Denied", Toast.LENGTH_SHORT).show();
                }
            }
        } else if (requestCode == 12) {
            if (resultCode == -1) {
                startActivityForResult(new Intent(this, SecureActivity.class), 3);
            }
        } else if (requestCode == 14) {
            boolean z2;
            int i;
            ((ImageView) findViewById(R.id.image0)).setImageResource(resultCode != -1 ? R.drawable.ic_lockenable_icon : R.drawable.ic_lockdisable_icon);
            if (resultCode == -1) {
                SettingsUtils.putBoolean(SettingsKeys.KEY_ENABLE_LOCKSCREEN, false);
            }
            this.r0 = (CheckBox) findViewById(R.id.check_lock);
            if (resultCode != -1) {
                z2 = true;
            } else {
                z2 = false;
            }
            this.r0.setChecked(z2);
            TextView textView = this.tvLock;
            if (resultCode != -1) {
                i = R.string.s_lockscreen_enabled;
            } else {
                i = R.string.s_lockscreen_disabled;
            }
            textView.setText(i);
        } else if (requestCode == 18 && VERSION.SDK_INT >= 18) {
        } else {
            if (requestCode == 4 && resultCode == -1) {
                ((CheckBox) findViewById(R.id.check_livewallpaper)).setChecked(SettingsUtils.getBoolean(SettingsKeys.KEY_SHOW_LIVEWALLPAPER, false));
            } else if (requestCode == 13) {
                boolean z3;
                String str = SettingsKeys.ENABLE_GESTURE;
                if (resultCode != -1) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                SettingsUtils.putBoolean(str, z3);
                if (resultCode != -1) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                enabled(z3);
                this.r0 = (CheckBox) findViewById(R.id.check_gesture);
                if (resultCode == -1) {
                    z = false;
                }
                this.r0.setChecked(z);
            }
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        handlerNotificationAlert();
    }

    private void handlerNotificationAlert() {
        String str = "is_notification_alert";
        if (VERSION.SDK_INT < 18) {
        }
    }

    protected void onResume() {
        super.onResume();
    }

    public void onBackPressed(View v) {
        onBackPressed();
    }

    public void onItemClicked(View v) {
        if (v instanceof RelativeLayout) {
            RelativeLayout rel = (RelativeLayout) v;
            for (int i = 0; i < rel.getChildCount(); i++) {
                if (rel.getChildAt(i) instanceof CheckBox) {
                    ((CheckBox) rel.getChildAt(i)).toggle();
                    return;
                }
            }
        }
        switch (v.getId()) {
            case R.id.rel_previewlock:
                addOverlay();
                return;
            case R.id.rel_disablesystem:
                try {
                    startActivity(new Intent("android.settings.SECURITY_SETTINGS"));
                    Toast.makeText(this, "Set Screen Lock \"NONE\" to avoid multiple lock", Toast.LENGTH_SHORT).show();
                    return;
                } catch (Exception e) {
                    return;
                }
            case R.id.rel_security:
                startActivityForResult(new Intent(this, SecureActivity.class), 3);
                return;
            case R.id.rel_wallpaper:
                startActivityForResult(new Intent(this, SetWallpaperActivity.class), 4);
                return;
            case R.id.rel_clock:
                startActivityForResult(new Intent(this, ClockActivity.class), 123);
                return;
            case R.id.rel_rateapp:
                rateApp();
                return;
            case R.id.rel_share:
                ShareApp();
                return;

            case R.id.rel_privacy:
                try {
                    Intent intent1 = new Intent(Intent.ACTION_VIEW);
                    intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                    startActivity(intent1);
                }catch (ActivityNotFoundException e)
                {
                    e.printStackTrace();
                }
                break;
            default:
                return;
        }
    }


    public void addOverlay() {
        if (VERSION.SDK_INT < 23) {
            startService(new Intent(this, ScreenLockService.class).setAction(Actions.SERVICE_PREVIEW_LOCK));
        } else if (Settings.canDrawOverlays(this)) {
            startService(new Intent(this, ScreenLockService.class).setAction(Actions.SERVICE_PREVIEW_LOCK));
        } else {
            this.askedForOverlayPermission = true;
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), 10);
        }
    }

    public void ShareApp() {
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Try This " + getString(R.string.app_name));
            intent.putExtra(Intent.EXTRA_TEXT, "Hey Check out this awesome  " + getString(R.string.app_name) + " app \nNow available on Google play store,You can also download it from \"https://play.google.com/store/apps/details?id=" + getPackageName() + "\"");
            startActivityForResult(Intent.createChooser(intent, "Share via"), 111);
        } catch (Exception e) {
        }
    }

    public void rateApp() {
        try {
            Intent goToMarket = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName()));
            goToMarket.addFlags(1208483840);
            try {
                startActivity(goToMarket);
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
            }
        } catch (Exception e2) {
        }
    }
    public void onBackPressed() {
        startActivity(new Intent(SettingsActivity.this,MainActivity.class));
        finish();
    }
}
