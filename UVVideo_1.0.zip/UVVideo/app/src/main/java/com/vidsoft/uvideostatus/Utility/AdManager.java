package com.vidsoft.uvideostatus.Utility;

import android.content.Context;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest.Builder;
import com.google.android.gms.ads.InterstitialAd;
import com.vidsoft.uvideostatus.R;

public class AdManager {
    private static AdManager singleton;
    public InterstitialAd interstitialAd;

    public static AdManager getInstance() {
        if (singleton == null) {
            singleton = new AdManager();
        }
        return singleton;
    }

    public void createAd(Context context) {
        this.interstitialAd = new InterstitialAd(context);
        this.interstitialAd.setAdUnitId(context.getString(R.string.AdMob_InterstitialAd));
        this.interstitialAd.loadAd(new Builder().build());
        this.interstitialAd.setAdListener(new AdListener() {
            public void onAdClosed() {
                AdManager.this.interstitialAd.loadAd(new Builder().build());
            }
        });
    }

    public InterstitialAd getAd() {
        return this.interstitialAd;
    }
}
