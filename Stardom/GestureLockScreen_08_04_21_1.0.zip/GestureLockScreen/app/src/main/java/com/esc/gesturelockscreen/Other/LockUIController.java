package com.esc.gesturelockscreen.Other;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Vibrator;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.esc.gesturelockscreen.Activity.SettingsActivity;
import com.esc.gesturelockscreen.Other.PINLockLayout.IPasscodeListener;
import com.esc.gesturelockscreen.Other.PINLockLayout.MODE;
import com.esc.gesturelockscreen.Service.SignatureLock;
import com.esc.gesturelockscreen.Service.SignatureLockImpl;
import com.esc.gesturelockscreen.View.ServiceLayout;
import com.esc.gesturelockscreen.R;
import androidx.annotation.NonNull;

public class LockUIController {
  private static LockUIController instance = new LockUIController();
  private int attempt = 0;
  private ImageView imShortCutPasscode;
  private ImageView imShortCutSettings;
  private Context mContext;
  private Handler mHandler = new Handler();
  private PINLockLayout mLockLayout;
  private ServiceLayout mMainView;
  private Runnable runnable = new Runnable() {
    @Override
    public void run() {
      if (System.currentTimeMillis() - LockUIController.this.startTime >= 30000) {
        LockUIController.this.attempt = 0;
        LockUIController.this.startTime = 0;
        LockUIController.this.mLockLayout.setEnable(true);
        LockUIController.this.mLockLayout.setNewMode(PINLockLayout.MODE.MODE_VERIFY);
        return;
      }
      int second = (int) (30 - ((System.currentTimeMillis() - LockUIController.this.startTime) / 1000));
      LockUIController.this.mLockLayout.setMessage(LockUIController.this.mContext.getString(R.string.more_wait, new Object[]{Integer.valueOf(second)}));
      LockUIController.this.mHandler.postDelayed(LockUIController.this.runnable, 1000);
    }
  };
  private long startTime = 0;

  private LockUIController() {
  }

  public static LockUIController getInstance() {
    return instance;
  }

  public void doVibration(long value) {
    if (this.mContext != null && SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_VIBRATION, true)) {
      Vibrator v = (Vibrator) this.mContext.getSystemService(Context.VIBRATOR_SERVICE);
      if (v.hasVibrator()) {
        v.vibrate(value);
      }
    }
  }

  public View initView(@NonNull Context context, @NonNull final SignatureLock neonLock) {
    this.mContext = context;
    final boolean hasGesture = SettingsUtils.getBoolean(SettingsKeys.ENABLE_GESTURE, false);
    ServiceLayout mMainView = ServiceLayout.getView(context);
    this.mMainView = mMainView;
    mMainView.setClickable(true);
    this.imShortCutPasscode = (ImageView) mMainView.findViewById(R.id.im_shortcut_passcode);
    this.imShortCutSettings = (ImageView) mMainView.findViewById(R.id.im_shortcut_settings);
    if (SettingsUtils.getBoolean(SettingsKeys.KEY_SHOW_LIVEWALLPAPER, false)) {
      mMainView.setBackgroundColor(0);
      mMainView.findViewById(R.id.image_wallpaper).setVisibility(View.GONE);
    } else {
      mMainView.findViewById(R.id.image_wallpaper).setVisibility(View.VISIBLE);
      WallpaperUtils.getInstance().startLoadImage(this.mContext, (ImageView) mMainView.findViewById(R.id.image_wallpaper));
    }
    mMainView.setListener(neonLock);
    this.imShortCutSettings.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        neonLock.setPendingIntent(PendingIntent.getActivity(LockUIController.this.mContext, 2, new Intent(LockUIController.this.mContext, SettingsActivity.class).setFlags(268435456), 134217728));
        if (!hasGesture) {
          neonLock.onStop(true);
        }
      }
    });
    if (!SettingsUtils.getBoolean(SettingsKeys.SHOW_KEYBOARD_PASSCODE, true)) {
      this.imShortCutPasscode.setImageResource(0);
    }
    if (!hasGesture || SettingsUtils.getRecoveryPasscode() == null) {
      this.imShortCutPasscode.setVisibility(View.INVISIBLE);
    } else {
      this.imShortCutPasscode.setOnClickListener(new OnClickListener() {
        @Override
        public void onClick(View v) {
          if (LockUIController.this.mLockLayout.getVisibility() == View.VISIBLE) {
            LockUIController.this.show();
          } else {
            LockUIController.this.hide();
          }
        }
      });
      this.imShortCutPasscode.setVisibility(View.VISIBLE);
      this.mLockLayout = new PINLockLayout(this.mContext);
      this.mLockLayout.setClickable(true);
      this.mLockLayout.setBackgroundColor(1996488704);
      this.mLockLayout.setListener(new IPasscodeListener() {
        public void onPasscodeWrong(MODE mode) {
          LockUIController.this.checkAttempt();
        }

        public void onPasscodeSuccess(MODE mode) {
          neonLock.onStop(true);
        }

        public void onPasscodeDot(MODE mode) {
          LockUIController.this.doVibration(50);
        }

        public void onPasscodeCancel() {
          LockUIController.this.show();
        }
      });
      this.mLockLayout.init(MODE.MODE_VERIFY);
      this.mLockLayout.initUserImage();
      this.mLockLayout.setVisibility(View.GONE);
      ((FrameLayout) mMainView.findViewById(R.id.frame_lock)).addView(this.mLockLayout);
      ((FrameLayout) mMainView.findViewById(R.id.frame_lock)).setVisibility(View.VISIBLE);
    }
    ClockBatteryUtils._instance.onInit(context, mMainView);
    return mMainView;
  }

  public void unregister() {
    if (this.mContext != null) {
      WallpaperUtils.getInstance().destory();
      ClockBatteryUtils._instance.unRegister(this.mContext);
    }
  }

  public void onScreenOff() {
    ClockBatteryUtils._instance.unRegister(this.mContext);
    if (this.mMainView != null) {
      this.mMainView.onScreenOff();
    }
    show();
  }

  public void onScreenOn() {
    ClockBatteryUtils._instance.register(this.mContext);
    if (this.mMainView != null) {
      this.mMainView.onScreenOn();
    }
    show();
  }

  private void show() {
    if (this.mLockLayout != null) {
      this.mLockLayout.setVisibility(View.GONE);
      this.mMainView.findViewById(R.id.gesture_lock_title).setVisibility(View.VISIBLE);
      this.mMainView.findViewById(R.id.layout_dynamic_content).setVisibility(View.VISIBLE);
      if (SettingsUtils.getBoolean(SettingsKeys.SHOW_KEYBOARD_PASSCODE, true)) {
        this.imShortCutPasscode.setImageResource(R.drawable.shortcut_lock_passcode);
      }
      if (SignatureLockImpl._instance != null) {
        SignatureLockImpl._instance.setPendingIntent(null);
      }
    }
  }

  public void hide() {
    if (this.mLockLayout != null) {
      this.mLockLayout.setVisibility(View.VISIBLE);
      this.mMainView.findViewById(R.id.gesture_lock_title).setVisibility(View.INVISIBLE);
      this.mMainView.findViewById(R.id.layout_dynamic_content).setVisibility(View.GONE);
      if (SettingsUtils.getBoolean(SettingsKeys.SHOW_KEYBOARD_PASSCODE, true)) {
        this.imShortCutPasscode.setImageResource(R.drawable.shortcut_lock_gesture);
      }
    }
  }

  private void checkAttempt() {
    this.attempt++;
    if (this.attempt > 4) {
      this.mLockLayout.setEnable(false);
      if (this.startTime <= 0) {
        doVibration(500);
        this.startTime = System.currentTimeMillis();
        this.mHandler.postDelayed(this.runnable, 1000);
        this.mLockLayout.setNewMode(MODE.MODE_WAIT);
      }
    }
  }
}
