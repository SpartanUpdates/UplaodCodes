package com.esc.flashlight.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.provider.Settings.Secure;
import android.text.TextUtils.SimpleStringSplitter;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.esc.flashlight.App.APP;
import com.esc.flashlight.R;
import com.esc.flashlight.database.TinyDB;
import com.esc.flashlight.database.DBAdapterFilteredPackages;
import com.esc.flashlight.service.AccessibilityDetector;
import com.esc.flashlight.service.ScreenOnOffService;
import com.esc.flashlight.util.FALib;
import com.esc.flashlight.util.FlashAlertUtil;
import com.esc.flashlight.util.PrefManager;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class MainActivity extends BaseActivity {

    Activity activity = MainActivity.this;
    private static final int IAB_REQUEST_CODE = 1111;
    TextView FilteringApplication;
    SwitchCompat ModeNormal;
    SwitchCompat ModeSilent;
    SwitchCompat ModeVibrate;
    SwitchCompat ScreenOn;
    SwitchCompat allflash;
    private Bitmap bmOff;
    private Bitmap bmOn;
    SwitchCompat btnignorr;
    RelativeLayout endtime;
    private int flashModuleType;
    private int flashPosition;
    private int[] ignoreTimeBegin;
    private int[] ignoreTimeEnd;
    SwitchCompat incommingcall;
    SwitchCompat incommingmsg;
    private AlertDialog mCurrentDialog;
    private CompoundButton mNeedChangeButton;
    private PrefManager mPref;
    TextView mode_ignore_begin;
    TextView mode_ignore_begin1;
    TextView mode_ignore_end;
    TextView mode_ignore_end1;
    SharedPreferences preferences;
    RelativeLayout starttime;
    SwitchCompat statusbarchange;
    private TinyDB tinyDB;
    TextView tv;
    private boolean useCall;
    private boolean useMessage;
    private boolean useMissedCall;
    private boolean useModeIgnore;
    private boolean useModeNormal;
    private boolean useModeSilent;
    private boolean useModeVibrate;
    private boolean useScreenOn;
    private boolean useStatusBar;
    private boolean useTotally;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    ImageView ivback;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.tinyDB = new TinyDB(this);
        getWindow().setFlags(1024, 1024);
        if (isStoragePermissionGranted()) {
            setContentView(R.layout.av_main);
            this.preferences = PreferenceManager.getDefaultSharedPreferences(this);
            this.mPref = APP.getPrefManager();
            initBitmaps();
            initViews();
            if (this.mPref.getFilterModeApplication() != 2) {
                DBAdapterFilteredPackages dBAdapterFilteredPackages = new DBAdapterFilteredPackages(getApplicationContext());
                dBAdapterFilteredPackages.open();
                dBAdapterFilteredPackages.clear();
                dBAdapterFilteredPackages.close();
                this.mPref.setFilterModeApplication(2);
            }
        }
        BannerAds();
    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            finish();
        }
        return true;
    }

    public boolean isStoragePermissionGranted() {
        if (VERSION.SDK_INT < 23) {
            return true;
        }
        String str = "android.permission.CALL_PHONE";
        if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") == 0 && ContextCompat.checkSelfPermission(this, str) == 0 && ContextCompat.checkSelfPermission(this, "android.permission.READ_PHONE_STATE") == 0) {
            return true;
        }
        ActivityCompat.requestPermissions(this, new String[]{str}, 1);
        return false;
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() == 82) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }


    public void onResume() {
        super.onResume();
        if (VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") == 0 && ContextCompat.checkSelfPermission(this, "android.permission.CALL_PHONE") == 0 && ContextCompat.checkSelfPermission(this, "android.permission.READ_PHONE_STATE") == 0) {
            loadPref();
            updateUIAll();
            CompoundButton compoundButton = this.mNeedChangeButton;
            if (compoundButton != null) {
                compoundButton.setChecked(compoundButton.isChecked());
                this.mNeedChangeButton = null;
            }
        }
    }


    public void onPause() {
        super.onPause();
    }

    public void onDestroy() {
        super.onDestroy();
        Bitmap bitmap = this.bmOn;
        if (!(bitmap == null || bitmap.isRecycled())) {
            this.bmOn.recycle();
            this.bmOn = null;
        }
        bitmap = this.bmOff;
        if (bitmap != null && !bitmap.isRecycled()) {
            this.bmOff.recycle();
            this.bmOff = null;
        }
    }

    private void initBitmaps() {
        this.bmOn = BitmapFactory.decodeResource(getResources(), R.drawable.widget_on);
        this.bmOff = BitmapFactory.decodeResource(getResources(), R.drawable.widget_off);
    }

    private void initViews() {
        ivback = findViewById(R.id.iv_back);
        this.allflash = findViewById(R.id.cb_totally_use);
        this.incommingcall = findViewById(R.id.swch_incoming_call);
        this.incommingmsg = findViewById(R.id.swch_incoming_msg);
        this.statusbarchange = findViewById(R.id.swch_changed_status_bar);
        this.FilteringApplication = findViewById(R.id.swch_filtering_application);
        this.ModeNormal = findViewById(R.id.swch_mode_normal);
        this.ModeSilent = findViewById(R.id.swch_mode_silent);
        this.ModeVibrate = findViewById(R.id.swch_mode_vibrate);
        this.ScreenOn = findViewById(R.id.swch_screen_on);
        this.starttime = findViewById(R.id.btn_start_time);
        this.endtime = findViewById(R.id.btn_end_time);
        this.mode_ignore_begin = findViewById(R.id.mode_ignore_begin);
        this.mode_ignore_end = findViewById(R.id.mode_ignore_end);
        this.mode_ignore_begin1 = findViewById(R.id.mode_ignore_begin1);
        this.mode_ignore_end1 = findViewById(R.id.mode_ignore_end1);
        this.btnignorr = findViewById(R.id.swch_mode_ignore);
        updateUIAll();
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        this.allflash.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                MainActivity.this.useTotally = z;
                MainActivity.this.mPref.setUseTotally(z);
                MainActivity.this.updateUIAll();
                if (VERSION.SDK_INT >= 21) {
                    FALib.sendBroadcastChangedTotallyUseState(MainActivity.this.getApplicationContext());
                }
                if (z) {
                    MainActivity.this.allflash.setText(MainActivity.this.getString(R.string.all_on));
                } else {
                    MainActivity.this.allflash.setText(MainActivity.this.getString(R.string.all_off));
                }
            }
        });
        this.incommingcall.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, final boolean z) {
                if (!MainActivity.this.tinyDB.getBoolean("purchased")) {
                    MainActivity.this.mPref.setUseCall(z);
                    if (MainActivity.this.incommingcall.isChecked()) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), CallSettingActivity.class));
                    }
                }
                /*if (!MainActivity.this.tinyDB.getBoolean("purchased")) {
                    Fragment newInstance = StartFreeTrialDialog.newInstance(MainActivity.this, new StartFreeTrialDialog.Callback() {
                        public void OnResult() {
                            Fragment findFragmentByTag = MainActivity.this.getSupportFragmentManager().findFragmentByTag(StartFreeTrialDialog.TAG);
                            if (findFragmentByTag != null) {
                                MainActivity.this.getSupportFragmentManager().beginTransaction().remove(findFragmentByTag).commitAllowingStateLoss();
                            }
                            MainActivity.this.mPref.setUseCall(z);
                            if (MainActivity.this.incommingcall.isChecked()) {
                                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), CallSettingActivity.class));
                            }
                        }

                        public void OnSubscribed() {
                            Fragment findFragmentByTag = MainActivity.this.getSupportFragmentManager().findFragmentByTag(StartFreeTrialDialog.TAG);
                            if (findFragmentByTag != null) {
                                MainActivity.this.getSupportFragmentManager().beginTransaction().remove(findFragmentByTag).commitAllowingStateLoss();
                            }
                            MainActivity.this.mPref.setUseCall(z);
                            if (MainActivity.this.incommingcall.isChecked()) {
                                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), CallSettingActivity.class));
                            }
                        }
                    });
                    FragmentTransaction beginTransaction = MainActivity.this.getSupportFragmentManager().beginTransaction();
                    beginTransaction.replace(R.id.frame_container, newInstance, StartFreeTrialDialog.TAG);
                    beginTransaction.commitAllowingStateLoss();
                }*/
            }
        });
        this.incommingmsg.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, final boolean z) {
                if (!MainActivity.this.tinyDB.getBoolean("purchased")) {
                    MainActivity.this.mPref.setUseMessage(z);
                    if (MainActivity.this.incommingmsg.isChecked()) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), SMSSettingActivity.class));
                    }
                }

                /*if (!MainActivity.this.tinyDB.getBoolean("purchased")) {
                    Fragment newInstance = StartFreeTrialDialog.newInstance(MainActivity.this, new StartFreeTrialDialog.Callback() {
                        public void OnResult() {
                            Fragment findFragmentByTag = MainActivity.this.getSupportFragmentManager().findFragmentByTag(StartFreeTrialDialog.TAG);
                            if (findFragmentByTag != null) {
                                MainActivity.this.getSupportFragmentManager().beginTransaction().remove(findFragmentByTag).commitAllowingStateLoss();
                            }
                            MainActivity.this.mPref.setUseMessage(z);
                            if (MainActivity.this.incommingmsg.isChecked()) {
                                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), SMSSettingActivity.class));
                            }
                        }

                        public void OnSubscribed() {
                            Fragment findFragmentByTag = MainActivity.this.getSupportFragmentManager().findFragmentByTag(StartFreeTrialDialog.TAG);
                            if (findFragmentByTag != null) {
                                MainActivity.this.getSupportFragmentManager().beginTransaction().remove(findFragmentByTag).commitAllowingStateLoss();
                            }
                            MainActivity.this.mPref.setUseMessage(z);
                            if (MainActivity.this.incommingmsg.isChecked()) {
                                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), SMSSettingActivity.class));
                            }
                        }
                    });
                    FragmentTransaction beginTransaction = MainActivity.this.getSupportFragmentManager().beginTransaction();
                    beginTransaction.replace(R.id.frame_container, newInstance, StartFreeTrialDialog.TAG);
                    beginTransaction.commitAllowingStateLoss();
                }*/
            }
        });
        this.statusbarchange.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, final boolean z) {
                if (!MainActivity.this.tinyDB.getBoolean("purchased")) {
                    MainActivity.this.mPref.setUseStatusBar(z);
                }
                /*if (!MainActivity.this.tinyDB.getBoolean("purchased")) {
                    Fragment newInstance = StartFreeTrialDialog.newInstance(MainActivity.this, new StartFreeTrialDialog.Callback() {
                        public void OnResult() {
                            Fragment findFragmentByTag = MainActivity.this.getSupportFragmentManager().findFragmentByTag(StartFreeTrialDialog.TAG);
                            if (findFragmentByTag != null) {
                                MainActivity.this.getSupportFragmentManager().beginTransaction().remove(findFragmentByTag).commitAllowingStateLoss();
                            }
                            MainActivity.this.mPref.setUseStatusBar(z);
                        }

                        public void OnSubscribed() {
                            Fragment findFragmentByTag = MainActivity.this.getSupportFragmentManager().findFragmentByTag(StartFreeTrialDialog.TAG);
                            if (findFragmentByTag != null) {
                                MainActivity.this.getSupportFragmentManager().beginTransaction().remove(findFragmentByTag).commitAllowingStateLoss();
                            }
                            MainActivity.this.mPref.setUseStatusBar(z);
                        }
                    });
                    FragmentTransaction beginTransaction = MainActivity.this.getSupportFragmentManager().beginTransaction();
                    beginTransaction.replace(R.id.frame_container, newInstance, StartFreeTrialDialog.TAG);
                    beginTransaction.commitAllowingStateLoss();
                }*/
            }
        });
        this.statusbarchange.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Log.e("statusbar", "onClick: " + MainActivity.isAccessibilityServiceEnabled(MainActivity.this, AccessibilityDetector.class));
                if (MainActivity.isAccessibilityServiceEnabled(MainActivity.this, AccessibilityDetector.class) && MainActivity.this.statusbarchange.isChecked()) {
                    MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), NotificationSettingActivity.class));
                } else if (MainActivity.this.statusbarchange.isChecked()) {
                    MainActivity.this.showAccessibilityDialog();
                }
            }
        });
        this.FilteringApplication.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Log.e("filter", "onClick: " + MainActivity.isAccessibilityServiceEnabled(MainActivity.this, AccessibilityDetector.class));
                if (MainActivity.isAccessibilityServiceEnabled(MainActivity.this, AccessibilityDetector.class)) {
                    MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), AppFilterActivity.class));
                } else {
                    MainActivity.this.showAccessibilityDialog();
                }
            }
        });

        this.ModeNormal.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                MainActivity.this.mPref.setUseModeNormal(z);
            }
        });
        this.ModeSilent.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                MainActivity.this.mPref.setUseModeSilent(z);
            }
        });
        this.ModeVibrate.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                MainActivity.this.mPref.setUseModeVibrate(z);
            }
        });
        this.ScreenOn.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (MainActivity.this.mPref.setUseScreenOn(z)) {
                    MainActivity.this.setScreenOnOffServiceEnable(z);
                }
            }
        });
        this.starttime.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (MainActivity.this.mode_ignore_begin.isEnabled()) {
                    new TimePickerDialog(MainActivity.this, new OnTimeSetListener() {
                        public void onTimeSet(TimePicker timePicker, int i, int i2) {
                            MainActivity.this.mPref.setIgnoreTimeBegin(i, i2);
                            MainActivity.this.ignoreTimeBegin[0] = i;
                            MainActivity.this.ignoreTimeBegin[1] = i2;
                            MainActivity.this.invalidateTimeText(MainActivity.this.mode_ignore_begin, MainActivity.this.ignoreTimeBegin);
                        }
                    }, MainActivity.this.ignoreTimeBegin[0], MainActivity.this.ignoreTimeBegin[1], true).show();
                }
            }
        });

        this.endtime.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (MainActivity.this.mode_ignore_end.isEnabled()) {
                    new TimePickerDialog(MainActivity.this, new OnTimeSetListener() {
                        public void onTimeSet(TimePicker timePicker, int i, int i2) {
                            MainActivity.this.mPref.setIgnoreTimeEnd(i, i2);
                            MainActivity.this.ignoreTimeEnd[0] = i;
                            MainActivity.this.ignoreTimeEnd[1] = i2;
                            MainActivity.this.invalidateTimeText(MainActivity.this.mode_ignore_end, MainActivity.this.ignoreTimeEnd);
                        }
                    }, MainActivity.this.ignoreTimeEnd[0], MainActivity.this.ignoreTimeEnd[1], true).show();
                }
            }
        });
        this.btnignorr.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (MainActivity.this.mPref.setUseModeIgnore(z)) {
                    MainActivity.this.mode_ignore_begin.setEnabled(z);
                    MainActivity.this.mode_ignore_end.setEnabled(z);
                    MainActivity.this.mode_ignore_begin1.setEnabled(z);
                    MainActivity.this.mode_ignore_end1.setEnabled(z);
                }
            }
        });
    }

    public static boolean isAccessibilityServiceEnabled(Context context, Class<?> cls) {
        if (VERSION.SDK_INT <= 26) {
            return true;
        }
        ComponentName componentName = new ComponentName(context, cls);
        String string = Secure.getString(context.getContentResolver(), "enabled_accessibility_services");
        if (string == null) {
            return false;
        }
        SimpleStringSplitter simpleStringSplitter = new SimpleStringSplitter(':');
        simpleStringSplitter.setString(string);
        while (simpleStringSplitter.hasNext()) {
            ComponentName unflattenFromString = ComponentName.unflattenFromString(simpleStringSplitter.next());
            if (unflattenFromString != null && unflattenFromString.equals(componentName)) {
                return true;
            }
        }
        return false;
    }

    private void loadPref() {
        this.useTotally = this.mPref.getUseTotally();
        this.useCall = this.mPref.getUseCall();
        this.useMessage = this.mPref.getUseMessage();
        this.useStatusBar = this.mPref.getUseStatusBar();
        this.useMissedCall = this.mPref.getUseMissedCall();
        this.useModeNormal = this.mPref.getUseModeNormal();
        this.useModeVibrate = this.mPref.getUseModeVibrate();
        this.useModeSilent = this.mPref.getUseModeSilent();
        this.useModeIgnore = this.mPref.getUseModeIgnore();
        boolean useScreenOn = this.mPref.getUseScreenOn();
        this.useScreenOn = useScreenOn;
        useScreenOn = !useScreenOn && this.useTotally;
        setScreenOnOffServiceEnable(useScreenOn);
        this.flashModuleType = this.mPref.getFlashController();
        this.ignoreTimeBegin = this.mPref.getIgnoreTimeBegin();
        this.ignoreTimeEnd = this.mPref.getIgnoreTimeEnd();
        this.flashPosition = this.mPref.getFlashPosition();
    }

    private void updateUIAll() {
        loadPref();
        this.allflash.setChecked(this.useTotally);
        this.incommingcall.setChecked(this.useCall);
        this.incommingmsg.setChecked(this.useMessage);
        this.statusbarchange.setChecked(this.useStatusBar);
        this.ModeNormal.setChecked(this.useModeNormal);
        this.ModeSilent.setChecked(this.useModeSilent);
        this.ModeVibrate.setChecked(this.useModeVibrate);
        this.ScreenOn.setChecked(this.useScreenOn);
        this.btnignorr.setChecked(this.useModeIgnore);
        this.incommingcall.setEnabled(this.useTotally);
        this.incommingmsg.setEnabled(this.useTotally);
        this.statusbarchange.setEnabled(this.useTotally);
        this.ModeNormal.setEnabled(this.useTotally);
        this.ModeVibrate.setEnabled(this.useTotally);
        this.ModeSilent.setEnabled(this.useTotally);
        this.ScreenOn.setEnabled(this.useTotally);
        this.btnignorr.setEnabled(this.useTotally);
        this.mode_ignore_end.setEnabled(this.useTotally);
        this.mode_ignore_end1.setEnabled(this.useTotally);
        this.mode_ignore_begin.setEnabled(this.useTotally);
        this.mode_ignore_begin1.setEnabled(this.useTotally);
        this.starttime.setEnabled(this.useTotally);
        this.endtime.setEnabled(this.useTotally);
        if (this.useTotally) {
            if (this.btnignorr.isChecked()) {
                this.mode_ignore_end.setEnabled(true);
                this.mode_ignore_end1.setEnabled(true);
                this.mode_ignore_begin.setEnabled(true);
                this.mode_ignore_begin1.setEnabled(true);
            } else {
                this.mode_ignore_end.setEnabled(false);
                this.mode_ignore_end1.setEnabled(false);
                this.mode_ignore_begin.setEnabled(false);
                this.mode_ignore_begin1.setEnabled(false);
            }
        }
        this.FilteringApplication.setEnabled(this.useTotally);
        boolean z = this.useTotally;
        invalidateTimeText(this.mode_ignore_begin, this.ignoreTimeBegin);
        invalidateTimeText(this.mode_ignore_end, this.ignoreTimeEnd);
        getResources().getString(R.string.main_flash_module);
    }

    private void invalidateTimeText(TextView textView, int[] iArr) {
        int i = iArr[0];
        int i2 = iArr[1];
        String str = "0";
        String str2 = "";
        StringBuilder append = new StringBuilder(i < 10 ? str : str2).append(i).append(":");
        if (i2 >= 10) {
            str = str2;
        }
        textView.setText(append.append(str).append(i2).toString());
    }

    private void showAccessibilityDialog() {
        DialogInterface.OnClickListener anonymousClass14 = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                if (i != -1) {
                    MainActivity.this.statusbarchange.setChecked(false);
                } else {
                    MainActivity.this.performMoveAccessibility();
                }
            }
        };
        AlertDialog alertDialog = this.mCurrentDialog;
        if (alertDialog != null) {
            alertDialog.dismiss();
        }
        AlertDialog create = new Builder(this).setTitle(R.string.accessibility_title).setMessage(R.string.accessibility_message).setNegativeButton(R.string.accessibility_cancel, anonymousClass14).setPositiveButton(R.string.accessibility_setting, anonymousClass14).create();
        this.mCurrentDialog = create;
        create.setOnCancelListener(new OnCancelListener() {
            public void onCancel(DialogInterface dialogInterface) {
                MainActivity.this.statusbarchange.setChecked(false);
            }
        });
        this.mCurrentDialog.show();
    }

    private void performMoveAccessibility() {
        startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
    }

    private void setScreenOnOffServiceEnable(boolean z) {
        if (z) {
            this.mPref.setScreenOnTime(SystemClock.elapsedRealtime() - FlashAlertUtil.SCREEN_ON_SAFE_DELAY);
            startService(new Intent(this, ScreenOnOffService.class));
            return;
        }
        stopService(new Intent(this, ScreenOnOffService.class));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
