package com.wavymusic.activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.wavymusic.R;
import com.wavymusic.UnityPlayerActivity;
import com.google.firebase.analytics.FirebaseAnalytics;

public class ExitAppActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = ExitAppActivity.this;

    ImageView ivClose;
    TextView tvRateApp;
    TextView tvYes, tvNo;
    FirebaseAnalytics mFirebaseAnalytics;

    private NativeBannerAd mNativeBannerAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exit_app);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ExitAppActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        BindView();
        loadNativeAds();
    }

    private void BindView() {
        tvRateApp = findViewById(R.id.tvRaeApp);
        tvYes = findViewById(R.id.tv_yes);
        tvNo = findViewById(R.id.tv_no);
        ivClose = findViewById(R.id.iv_close);
        tvRateApp.setOnClickListener(this);
        tvYes.setOnClickListener(this);
        tvNo.setOnClickListener(this);
        ivClose.setOnClickListener(this);
    }

    private void loadNativeAds(){
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(activity, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                FrameLayout nativeBannerAdContainer =findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                startActivity(new Intent(activity, HomeActivity.class));
                finish();
                break;
            case R.id.tv_no:
                startActivity(new Intent(activity, HomeActivity.class));
                finish();
                break;
            case R.id.tv_yes:
                CloseApp();
                break;
            case R.id.tvRaeApp:
                RateApp();
                break;
        }
    }


    private void CloseApp() {
        finishAffinity();
        if (UnityPlayerActivity.mUnityPlayer != null) {
            UnityPlayerActivity.mUnityPlayer.quit();
        }
    }

    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }
}
