package com.kotlinz.festivalstorymaker.Utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;

public class BorderedTextView extends AppCompatTextView
{
    public Rect i;
    public Paint j;
    public Paint k;
    public Typeface l;
    public int m;
    public String n;
    public int o;
    public int p;
    public float q;
    public float r;
    public int s;
    public int t;
    public int u;
    public int v;
    public int w;
    public int x;

    public BorderedTextView(final Context context) {
        super(context);
        this.m = 0;
        this.n = "";
        this.o = 0;
        this.p = 16777215;
        this.r = -1.0f;
        this.v = 0;
        this.x = 0;
        this.c();
        if (!this.getText().toString().isEmpty()) {
            this.n = this.getText().toString();
        }
    }

    public BorderedTextView(final Context context, final AttributeSet set) {
        super(context, set);
        this.m = 0;
        this.n = "";
        this.o = 0;
        this.p = 16777215;
        this.r = -1.0f;
        this.v = 0;
        this.x = 0;
        this.c();
        if (!this.getText().toString().isEmpty()) {
            this.n = this.getText().toString();
        }
    }

    public BorderedTextView(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.m = 0;
        this.n = "";
        this.o = 0;
        this.p = 16777215;
        this.r = -1.0f;
        this.v = 0;
        this.x = 0;
        this.c();
        if (!this.getText().toString().isEmpty()) {
            this.n = this.getText().toString();
        }
    }

    public void c() {
        this.l = Typeface.createFromAsset(this.getContext().getAssets(), "fonts/Mont-Bold.ttf");
        this.j = new Paint();
        this.k = new Paint();
        this.j.setDither(true);
        this.k.setDither(true);
        this.j.setColor(this.o);
        this.k.setColor(this.p);
        this.j.setTextAlign(Paint.Align.CENTER);
        this.k.setTextAlign(Paint.Align.CENTER);
        this.j.setTypeface(this.l);
        this.k.setTypeface(this.l);
        this.j.setFlags(1);
        this.k.setFlags(1);
        this.k.setTextSize(this.getTextSize());
        this.j.setTextSize(this.getTextSize());
        this.j.setStyle(Paint.Style.STROKE);
        this.j.setStrokeJoin(Paint.Join.ROUND);
        this.j.setStrokeCap(Paint.Cap.ROUND);
        this.j.setStrokeWidth((float)this.m);
        this.i = new Rect();
    }

    public void onDraw(final Canvas canvas) {
        final String string = this.getText().toString();
        this.n = string;
        if (!string.isEmpty()) {
            final Paint j = this.j;
            final String n = this.n;
            j.getTextBounds(n, 0, n.length(), this.i);
            final int w = this.w;
            Label_0120: {
                int n3 = 0;
                Label_0072: {
                    int n2;
                    if (w == 0) {
                        n2 = this.getWidth();
                    }
                    else if (w == 1) {
                        n2 = this.i.width();
                    }
                    else {
                        if (w == 2) {
                            n3 = this.getWidth() - this.i.width() / 2;
                            break Label_0072;
                        }
                        break Label_0120;
                    }
                    n3 = n2 / 2;
                }
                this.q = (float)n3;
            }
            final int x = this.x;
            Label_0195: {
                float r;
                if (x == 0) {
                    r = (float)((this.getHeight() - this.i.height()) / 2 + this.i.height());
                }
                else {
                    int n4;
                    if (x == 1) {
                        n4 = this.i.height();
                    }
                    else {
                        if (x != 2) {
                            break Label_0195;
                        }
                        n4 = this.getHeight();
                    }
                    r = (float)n4;
                }
                this.r = r;
            }
            canvas.drawText(this.n, this.q, this.r, this.k);
            canvas.drawText(this.n, this.q, this.r, this.j);
        }
    }

    public void setBorderTypeface(final Typeface typeface) {
        this.j.setTypeface(typeface);
        this.k.setTypeface(typeface);
        this.invalidate();
    }

    public void setBorderWidth(final int n) {
        this.j.setStrokeWidth((float)n);
    }

    public void setBorderedColor(final int color) {
        this.j.setColor(color);
        this.invalidate();
    }

    public void setBottomMargin(final int n) {
        this.t += n;
    }

    public void setInsetColor(final int color) {
        this.k.setColor(color);
        this.invalidate();
    }

    public void setLeftMargin(final int n) {
        this.u += n;
    }

    public void setRightMargin(final int n) {
        this.v += n;
    }

    public void setTextAlign(final a a) {
        final int ordinal = a.ordinal();
        if (ordinal != 0) {
            int x;
            int w = x = 2;
            Label_0062: {
                if (ordinal != 1) {
                    if (ordinal != 2) {
                        if (ordinal != 3) {
                            x = 0;
                            w = 0;
                            if (ordinal == 4) {
                                break Label_0062;
                            }
                            if (ordinal != 5) {
                                return;
                            }
                        }
                        this.w = w;
                        return;
                    }
                    this.w = 1;
                    return;
                }
            }
            this.x = x;
            return;
        }
        this.x = 1;
    }

    public void setTextSizes(final float n) {
        this.k.setTextSize(this.getResources().getDisplayMetrics().density * n);
        this.j.setTextSize(n * this.getResources().getDisplayMetrics().density);
        this.invalidate();
    }

    public void setTopMargin(final int n) {
        this.s += n;
    }

    public enum a
    {
        e,
        f,
        g,
        h,
        i,
        j;
    }
}
