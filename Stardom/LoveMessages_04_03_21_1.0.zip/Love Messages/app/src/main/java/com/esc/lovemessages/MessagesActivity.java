package com.esc.lovemessages;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog.Builder;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd.OnUnifiedNativeAdLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.Task;
import com.ironsource.mediationsdk.IronSource;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MessagesActivity extends AppCompatActivity  {
    private static String greeting;
    public static boolean isFirst = true;
    public static int lockCounter;
    public static Boolean unlocked = Boolean.valueOf(false);
    public Adapter Radapter;
    Activity activity = this;
    String appname = "Love Messages For Wife";
    DataBaseHelper baseHelper;
    String cat;
    TextView cattext;
    ConsentInformation consentInformation;
    Context context;
    int currentVisiblePosition = 0;
    Dialog dialogR;
    public Editor editor;
    public Typeface face1;
    public Typeface face2;
    ArrayList<String> fav = new ArrayList();
    ArrayList<String> image = new ArrayList();
    ReviewManager manager;
    ArrayList<String> msg = new ArrayList();
    String msg2;
    ArrayList<String> msgid = new ArrayList();
    String pg_id;
    String pg_title;
    RecyclerView recyclerview;
    ReviewInfo reviewInfo;
    public SharedPreferences sharedPreferences;
    String url;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public class MyRecyclerAdapter extends Adapter<MyRecyclerAdapter.ViewHolder> {
        public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
        Activity activity;
        private String cat;
        Context context;
        private ArrayList<String> fav;
        private ArrayList<String> image;
        private LayoutInflater inflate = null;
        private ArrayList<String> msg;
        private ArrayList<String> msgid;
        private String pg_url;
        File shfile;
        String title;

        public class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            TextView copyTextButton;
            ImageView imgfav;
            LinearLayout linear;
            ImageView msgimg;
            Button personalized;
            RelativeLayout rel;
            RelativeLayout rel2;
            TextView saveImageButton;
            LinearLayout saveShareLinearLayout;
            TextView shareimage;
            TextView sharetxt;
            TextView txt;

            public ViewHolder(View view) {
                super(view);
                this.txt = (TextView) view.findViewById(R.id.msg);
                this.msgimg = (ImageView) view.findViewById(R.id.msgimg);
                this.rel = (RelativeLayout) view.findViewById(R.id.rel1);
                this.shareimage = (TextView) view.findViewById(R.id.shareimage);
                this.sharetxt = (TextView) view.findViewById(R.id.sharetxt);
                this.imgfav = (ImageView) view.findViewById(R.id.imgfav);
                this.rel2 = (RelativeLayout) view.findViewById(R.id.rel2);
                this.linear = (LinearLayout) view.findViewById(R.id.linear);
                this.saveShareLinearLayout = (LinearLayout) view.findViewById(R.id.save_share_linearlayout);
                this.copyTextButton = (TextView) view.findViewById(R.id.copy_text);
                this.saveImageButton = (TextView) view.findViewById(R.id.save_image);
                this.personalized = (Button) view.findViewById(R.id.personalized);
                this.txt.setTypeface(MessagesActivity.this.face2);
                this.shareimage.setTypeface(MessagesActivity.this.face1);
                this.sharetxt.setTypeface(MessagesActivity.this.face1);
                this.saveImageButton.setTypeface(MessagesActivity.this.face1);
                this.copyTextButton.setTypeface(MessagesActivity.this.face1);
                this.personalized.setTypeface(MessagesActivity.this.face1);
                LayoutParams layoutParams;
                double d;
                double d2;
                if ((MessagesActivity.this.getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
                    this.txt.setTextSize(33.0f);
                    layoutParams = this.shareimage.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.shareimage.setTextSize(30.0f);
                    layoutParams = this.sharetxt.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.sharetxt.setTextSize(30.0f);
                    layoutParams = this.saveImageButton.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.saveImageButton.setTextSize(30.0f);
                    layoutParams = this.copyTextButton.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.copyTextButton.setTextSize(30.0f);
                    layoutParams = this.msgimg.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.4d);
                    layoutParams = this.imgfav.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.06d);
                    layoutParams = this.personalized.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.personalized.setTextSize(30.0f);
                } else if ((MessagesActivity.this.getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
                    this.txt.setTextSize(24.0f);
                    layoutParams = this.shareimage.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.shareimage.setTextSize(24.0f);
                    layoutParams = this.msgimg.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.38d);
                    layoutParams = this.sharetxt.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.sharetxt.setTextSize(24.0f);
                    layoutParams = this.saveImageButton.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.saveImageButton.setTextSize(24.0f);
                    layoutParams = this.copyTextButton.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.copyTextButton.setTextSize(24.0f);
                    layoutParams = this.imgfav.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.06d);
                    layoutParams = this.personalized.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.personalized.setTextSize(24.0f);
                } else {
                    this.txt.setTextSize(20.0f);
                    layoutParams = this.shareimage.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.shareimage.setTextSize(18.0f);
                    layoutParams = this.msgimg.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.35d);
                    layoutParams = this.sharetxt.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.sharetxt.setTextSize(18.0f);
                    layoutParams = this.saveImageButton.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.saveImageButton.setTextSize(18.0f);
                    layoutParams = this.copyTextButton.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.copyTextButton.setTextSize(18.0f);
                    layoutParams = this.imgfav.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.06d);
                    layoutParams = this.personalized.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.personalized.setTextSize(18.0f);
                }
            }
        }

        public MyRecyclerAdapter(Context context, ArrayList<String> arrayList, ArrayList<String> arrayList2, ArrayList<String> arrayList3, ArrayList<String> arrayList4, String str, String str2, String str3, Activity activity) {
            this.msg = arrayList;
            this.msgid = arrayList2;
            this.image = arrayList3;
            this.fav = arrayList4;
            this.pg_url = str;
            this.cat = str2;
            this.activity = activity;
            this.context = context;
            this.title = str3;
        }

        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.messageitem1, viewGroup, false));
        }

        public int getItemViewType(int i) {
            return ((String) this.image.get(i)).contains("0") ? 0 : 1;
        }

        public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
            final String str = (String) this.msg.get(i);
            viewHolder.txt.setText(Html.fromHtml(str));
            StringBuilder stringBuilder = new StringBuilder();
            String str2 = "";
            stringBuilder.append(str2);
            stringBuilder.append((String) this.msgid.get(i));
            if (MessagesActivity.this.sharedPreferences.getBoolean("lock", true)) {
                viewHolder.personalized.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.lock, 0);
                viewHolder.personalized.setPadding(0, 0, 50, 0);
            }
            if (Integer.parseInt((String) this.fav.get(i)) == 0) {
                viewHolder.imgfav.setImageResource(R.drawable.ic_favorite_border_white_24dp);
            } else {
                viewHolder.imgfav.setImageResource(R.drawable.ic_favorite_white_24dp);
            }
            if (getItemViewType(i) == 1) {
                String stringBuilder2;
                String str3 = ".jpg";
                String str4 = "-";
                if (!MainActivity.image_url.contains(".com") || MainActivity.image_url.contains("amazonaws")) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(MainActivity.image_url);
                    stringBuilder.append(str2);
                    stringBuilder.append(this.cat);
                    stringBuilder.append("/");
                    stringBuilder.append((String) this.msgid.get(i));
                    stringBuilder.append(str4);
                    stringBuilder.append(this.pg_url);
                    stringBuilder.append(str3);
                    stringBuilder2 = stringBuilder.toString();
                } else {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(MainActivity.image_url);
                    stringBuilder.append(str2);
                    stringBuilder.append(this.cat);
                    stringBuilder.append("/uploads/");
                    stringBuilder.append((String) this.msgid.get(i));
                    stringBuilder.append(str4);
                    stringBuilder.append(this.pg_url);
                    stringBuilder.append(str3);
                    stringBuilder2 = stringBuilder.toString();
                }
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append(".......");
                stringBuilder3.append(stringBuilder2);
                Log.e("url", stringBuilder3.toString());
                ((RequestBuilder) Glide.with(this.context).load(stringBuilder2).placeholder((int) R.drawable.loading)).into(viewHolder.msgimg);
            } else if (getItemViewType(i) == 0) {
                viewHolder.msgimg.setImageDrawable(null);
                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) viewHolder.msgimg.getLayoutParams();
                viewHolder.msgimg.getLayoutParams().height = 0;
                viewHolder.msgimg.getLayoutParams().width = 0;
            }
            viewHolder.imgfav.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ImageView imageView = (ImageView) view.findViewById(R.id.imgfav);
                    imageView.setTag(viewHolder.imgfav.getTag());
                    try {
                        MessagesActivity.this.baseHelper.createDataBase();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    int parseInt = Integer.parseInt((String) MyRecyclerAdapter.this.fav.get(i));
                    if (parseInt == 0) {
                        imageView.setImageResource(R.drawable.ic_favorite_white_24dp);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("");
                        stringBuilder.append(imageView);
                        MessagesActivity.this.baseHelper.updateFavorite(1, Integer.parseInt((String) MyRecyclerAdapter.this.msgid.get(i)));
                        Toast.makeText(MessagesActivity.this.getApplicationContext(), MessagesActivity.this.getApplicationContext().getResources().getString(R.string.marked), Toast.LENGTH_LONG).show();
                        imageView.invalidate();
                        MyRecyclerAdapter.this.fav.set(i, "1");
                    } else if (parseInt == 1) {
                        imageView.setImageResource(R.drawable.ic_favorite_border_white_24dp);
                        MessagesActivity.this.baseHelper.updateFavorite(0, Integer.parseInt((String) MyRecyclerAdapter.this.msgid.get(i)));
                        Toast.makeText(MessagesActivity.this.getApplicationContext(), MessagesActivity.this.getApplicationContext().getResources().getString(R.string.Unmarked), Toast.LENGTH_LONG).show();
                        imageView.invalidate();
                        MyRecyclerAdapter.this.fav.set(i, "0");
                    }
                }
            });
            viewHolder.sharetxt.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    String obj = Html.fromHtml((String) MyRecyclerAdapter.this.msg.get(i)).toString();
                    MessagesActivity messagesActivity = MessagesActivity.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(obj);
                    stringBuilder.append("\n");
                    StringBuilder stringBuilder2 = new StringBuilder();
                    String str = "<br>";
                    stringBuilder2.append(str);
                    stringBuilder2.append(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.fromshare));
                    stringBuilder2.append(str);
                    stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                    stringBuilder.append(Html.fromHtml(stringBuilder2.toString()));
                    messagesActivity.msg2 = stringBuilder.toString();
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.SUBJECT", "Love Messages For Wife");
                    intent.putExtra("android.intent.extra.TEXT", MessagesActivity.this.msg2);
                    MessagesActivity.this.startActivity(Intent.createChooser(intent, MessagesActivity.this.getApplicationContext().getResources().getString(R.string.sharevia)));
                    Map hashMap = new HashMap();
                    hashMap.put(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.sharetext), MessagesActivity.this.pg_title);
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("");
                    stringBuilder2.append(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.sharetext));
                    stringBuilder2.append("  ");
                    stringBuilder2.append(MessagesActivity.this.pg_title);
                    MessagesActivity.this.AddRateClicks();
                }
            });
            viewHolder.saveImageButton.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (ContextCompat.checkSelfPermission(MyRecyclerAdapter.this.context, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                        Toast.makeText(MyRecyclerAdapter.this.context, "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
                        MyRecyclerAdapter.this.checkAndRequestPermissions();
                        return;
                    }
                    String str = ".jpg";
                    String str2 = "-";
                    String str3 = "";
                    MessagesActivity messagesActivity;
                    StringBuilder stringBuilder;
                    if (!MainActivity.image_url.contains(".com") || MainActivity.image_url.contains("amazonaws")) {
                        messagesActivity = MessagesActivity.this;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(MainActivity.image_url);
                        stringBuilder.append(str3);
                        stringBuilder.append(MyRecyclerAdapter.this.cat);
                        stringBuilder.append("/");
                        stringBuilder.append((String) MyRecyclerAdapter.this.msgid.get(i));
                        stringBuilder.append(str2);
                        stringBuilder.append(MyRecyclerAdapter.this.pg_url);
                        stringBuilder.append(str);
                        messagesActivity.url = stringBuilder.toString();
                    } else {
                        messagesActivity = MessagesActivity.this;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(MainActivity.image_url);
                        stringBuilder.append(str3);
                        stringBuilder.append(MyRecyclerAdapter.this.cat);
                        stringBuilder.append("/uploads/");
                        stringBuilder.append((String) MyRecyclerAdapter.this.msgid.get(i));
                        stringBuilder.append(str2);
                        stringBuilder.append(MyRecyclerAdapter.this.pg_url);
                        stringBuilder.append(str);
                        messagesActivity.url = stringBuilder.toString();
                    }
                    try {
                        if (MessagesActivity.this.isNetworkAvailable()) {
                            Glide.with(MessagesActivity.this.getApplicationContext()).asBitmap().load(MessagesActivity.this.url).into(new SimpleTarget<Bitmap>() {
                                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                    MessagesActivity.this.saveImage(bitmap, Integer.parseInt((String) MyRecyclerAdapter.this.msgid.get(i)));
                                }
                            });
                        } else {
                            Builder builder = new Builder(MessagesActivity.this);
                            builder.setTitle(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.errror));
                            builder.setMessage(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.error));
                            builder.setCancelable(false).setPositiveButton(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.retry), new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, final int i) {
                                    if (MessagesActivity.this.isNetworkAvailable()) {
                                        Glide.with(MessagesActivity.this.getApplicationContext()).asBitmap().load(MessagesActivity.this.url).into(new SimpleTarget<Bitmap>() {
                                            public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                                MessagesActivity.this.saveImage(bitmap, Integer.parseInt((String) MyRecyclerAdapter.this.msgid.get(i)));
                                            }
                                        });
                                    } else {
                                        Toast.makeText(MessagesActivity.this, MessagesActivity.this.getApplicationContext().getResources().getString(R.string.error), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }).setNegativeButton(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.cancel();
                                }
                            });
                            builder.create().show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    MessagesActivity.this.AddRateClicks();
                }
            });
            viewHolder.copyTextButton.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ClipboardManager clipboardManager = (ClipboardManager) MyRecyclerAdapter.this.context.getSystemService(CLIPBOARD_SERVICE);
                    String string = MessagesActivity.this.getApplicationContext().getResources().getString(R.string.label);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append((String) MyRecyclerAdapter.this.msg.get(i));
                    String str = "<br>";
                    stringBuilder.append(str);
                    stringBuilder.append(MessagesActivity.this.getResources().getString(R.string.fromshare));
                    stringBuilder.append(str);
                    stringBuilder.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                    clipboardManager.setPrimaryClip(ClipData.newPlainText(string, Html.fromHtml(stringBuilder.toString())));
                    Toast.makeText(MessagesActivity.this.getApplicationContext().getApplicationContext(), MessagesActivity.this.getApplicationContext().getResources().getString(R.string.ClipboardCopied), Toast.LENGTH_LONG).show();
                    Map hashMap = new HashMap();
                    hashMap.put(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.copytext), String.valueOf(MessagesActivity.this.baseHelper.getPg_Title()));
                    hashMap.put(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.copytext), MessagesActivity.this.pg_title);
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("");
                    stringBuilder2.append(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.copytext));
                    stringBuilder2.append("  ");
                    stringBuilder2.append(MessagesActivity.this.pg_title);
                }
            });
            viewHolder.shareimage.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (ContextCompat.checkSelfPermission(MyRecyclerAdapter.this.context, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                        Toast.makeText(MyRecyclerAdapter.this.context, "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
                        MyRecyclerAdapter.this.checkAndRequestPermissions();
                        return;
                    }
                    final String stringBuilder;
                    MessagesActivity.this.AddRateClicks();
                    String str = ".jpg";
                    String str2 = "-";
                    String str3 = "";
                    StringBuilder stringBuilder2;
                    if (!MainActivity.image_url.contains(".com") || MainActivity.image_url.contains("amazonaws")) {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(MainActivity.image_url);
                        stringBuilder2.append(str3);
                        stringBuilder2.append(MyRecyclerAdapter.this.cat);
                        stringBuilder2.append("/");
                        stringBuilder2.append((String) MyRecyclerAdapter.this.msgid.get(i));
                        stringBuilder2.append(str2);
                        stringBuilder2.append(MyRecyclerAdapter.this.pg_url);
                        stringBuilder2.append(str);
                        stringBuilder = stringBuilder2.toString();
                    } else {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(MainActivity.image_url);
                        stringBuilder2.append(str3);
                        stringBuilder2.append(MyRecyclerAdapter.this.cat);
                        stringBuilder2.append("/uploads/");
                        stringBuilder2.append((String) MyRecyclerAdapter.this.msgid.get(i));
                        stringBuilder2.append(str2);
                        stringBuilder2.append(MyRecyclerAdapter.this.pg_url);
                        stringBuilder2.append(str);
                        stringBuilder = stringBuilder2.toString();
                    }
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(" ");
                    stringBuilder3.append(stringBuilder);
                    if (MessagesActivity.this.isNetworkAvailable()) {
                        try {
                            Glide.with(MessagesActivity.this.getApplicationContext()).asBitmap().load(stringBuilder).into(new SimpleTarget<Bitmap>() {
                                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                    File externalStorageDirectory = Environment.getExternalStorageDirectory();
                                    MyRecyclerAdapter myRecyclerAdapter = MyRecyclerAdapter.this;
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append((String) MyRecyclerAdapter.this.msgid.get(i));
                                    stringBuilder.append(".jpg");
                                    myRecyclerAdapter.shfile = new File(externalStorageDirectory, stringBuilder.toString());
                                    try {
                                        FileOutputStream fileOutputStream = new FileOutputStream(MyRecyclerAdapter.this.shfile);
                                        bitmap.compress(CompressFormat.JPEG, 100, fileOutputStream);
                                        try {
                                            fileOutputStream.flush();
                                            fileOutputStream.close();
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                    } catch (FileNotFoundException e2) {
                                        e2.printStackTrace();
                                        Toast.makeText(MyRecyclerAdapter.this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
                                    }
                                    MessagesActivity messagesActivity = MessagesActivity.this;
                                    StringBuilder stringBuilder2 = new StringBuilder();
                                    String str = "\n";
                                    stringBuilder2.append(str);
                                    stringBuilder2.append(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.fromshare));
                                    stringBuilder2.append(str);
                                    stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                                    messagesActivity.msg2 = stringBuilder2.toString();
                                    Uri uriForFile = FileProvider.getUriForFile(MessagesActivity.this, String.valueOf(activity.getPackageName()) + ".provider", MyRecyclerAdapter.this.shfile);
                                    Intent intent = new Intent();
                                    intent.setAction("android.intent.action.SEND");
                                    intent.setType("image/*");
                                    intent.putExtra("android.intent.extra.SUBJECT", MessagesActivity.this.appname);
                                    intent.putExtra("android.intent.extra.TEXT", MessagesActivity.this.msg2);
                                    intent.putExtra("android.intent.extra.STREAM", uriForFile);
                                    MessagesActivity.this.startActivity(Intent.createChooser(intent, MessagesActivity.this.getApplicationContext().getResources().getString(R.string.sharevia)));
                                    Map hashMap = new HashMap();
                                    hashMap.put(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.shareimage), MessagesActivity.this.pg_title);
                                    StringBuilder stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("");
                                    stringBuilder3.append(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.shareimage));
                                    stringBuilder3.append("  ");
                                    stringBuilder3.append(MessagesActivity.this.pg_title);
                                }
                            });
                            return;
                        } catch (Exception e) {
                            e.printStackTrace();
                            return;
                        }
                    }
                    Builder builder = new Builder(MessagesActivity.this);
                    builder.setTitle(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.errror));
                    builder.setMessage(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.error));
                    builder.setCancelable(false).setPositiveButton(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.retry), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, final int i) {
                            if (MessagesActivity.this.isNetworkAvailable()) {
                                try {
                                    Glide.with(MessagesActivity.this.getApplicationContext()).asBitmap().load(stringBuilder).into(new SimpleTarget<Bitmap>() {
                                        public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                            File externalStorageDirectory = Environment.getExternalStorageDirectory();
                                            MyRecyclerAdapter myRecyclerAdapter = MyRecyclerAdapter.this;
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append((String) MyRecyclerAdapter.this.msgid.get(i));
                                            stringBuilder.append(".jpg");
                                            myRecyclerAdapter.shfile = new File(externalStorageDirectory, stringBuilder.toString());
                                            try {
                                                FileOutputStream fileOutputStream = new FileOutputStream(MyRecyclerAdapter.this.shfile);
                                                bitmap.compress(CompressFormat.JPEG, 100, fileOutputStream);
                                                try {
                                                    fileOutputStream.flush();
                                                    fileOutputStream.close();
                                                } catch (IOException e) {
                                                    e.printStackTrace();
                                                }
                                            } catch (FileNotFoundException e2) {
                                                e2.printStackTrace();
                                                Toast.makeText(MyRecyclerAdapter.this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
                                            }
                                            MessagesActivity messagesActivity = MessagesActivity.this;
                                            StringBuilder stringBuilder2 = new StringBuilder();
                                            String str = "\n";
                                            stringBuilder2.append(str);
                                            stringBuilder2.append(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.fromshare));
                                            stringBuilder2.append(str);
                                            stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                                            messagesActivity.msg2 = stringBuilder2.toString();
                                            Uri uriForFile = FileProvider.getUriForFile(MessagesActivity.this, String.valueOf(activity.getPackageName()) + ".provider", MyRecyclerAdapter.this.shfile);
                                            Intent intent = new Intent();
                                            intent.setAction("android.intent.action.SEND");
                                            intent.setType("image/*");
                                            intent.putExtra("android.intent.extra.SUBJECT", MessagesActivity.this.appname);
                                            intent.putExtra("android.intent.extra.TEXT", MessagesActivity.this.msg2);
                                            intent.putExtra("android.intent.extra.STREAM", uriForFile);
                                            MessagesActivity.this.startActivity(Intent.createChooser(intent, MessagesActivity.this.getApplicationContext().getResources().getString(R.string.sharevia)));
                                        }
                                    });
                                    return;
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    return;
                                }
                            }
                            Toast.makeText(MessagesActivity.this, MessagesActivity.this.getApplicationContext().getResources().getString(R.string.error), Toast.LENGTH_SHORT).show();
                        }
                    }).setNegativeButton(MessagesActivity.this.getApplicationContext().getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });
                    builder.create().show();
                }
            });
            if (getItemViewType(i) == 1) {
                viewHolder.rel2.setVisibility(View.VISIBLE);
                viewHolder.shareimage.setVisibility(View.VISIBLE);
                viewHolder.saveShareLinearLayout.setVisibility(View.VISIBLE);
            } else {
                viewHolder.rel2.setVisibility(View.GONE);
                viewHolder.msgimg.setImageDrawable(null);
                viewHolder.shareimage.setVisibility(View.INVISIBLE);
                viewHolder.saveShareLinearLayout.setVisibility(View.GONE);
            }
            viewHolder.personalized.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    String str = "date";
                    String str2 = "dd/M/yyyy hh:mm:ss";
                    MessagesActivity.greeting = str;
                    try {
                        String string = MessagesActivity.this.sharedPreferences.getString(str, new SimpleDateFormat(str2, Locale.ENGLISH).format(Calendar.getInstance().getTime()));
                        Date time = Calendar.getInstance().getTime();
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str2, Locale.ENGLISH);
                        int difference = MessagesActivity.getDifference(simpleDateFormat.parse(string), simpleDateFormat.parse(simpleDateFormat.format(time)));
                        String str3 = "unlocked";
                        if (MessagesActivity.this.sharedPreferences.getBoolean("lock", true)) {
                            if (!MessagesActivity.this.isNetworkAvailable()) {
                                Toast.makeText(MessagesActivity.this.getApplicationContext(), "Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                            } else if (MessagesActivity.lockCounter >= 7) {
                                MessagesActivity.unlocked = Boolean.valueOf(true);
                                str2 = new SimpleDateFormat(str2, Locale.ENGLISH).format(Calendar.getInstance().getTime());
                                MessagesActivity.this.editor.putBoolean(str3, true);
                                MessagesActivity.this.editor.putString(str, str2);
                                MessagesActivity.this.editor.commit();
                                MessagesActivity.this.checkRewardAds();
                            } else {
                                MessagesActivity.lockCounter++;
                                Toast.makeText(MessagesActivity.this.getApplicationContext(), "Try Again", Toast.LENGTH_SHORT).show();
                            }
                        } else if (difference < 5) {
                            MessagesActivity.this.editor.putBoolean(str3, false);
                            if (MessagesActivity.isFirst) {
                                MessagesActivity.isFirst = false;
                            }
                            MessagesActivity.this.editor.commit();
                            Intent intent = new Intent(MyRecyclerAdapter.this.context, GreetingActivity.class);
                            intent.putExtra("source", "MainActivity");
                            intent.putExtra(NotificationCompat.CATEGORY_MESSAGE, MessagesActivity.greeting);
                            MessagesActivity.this.startActivity(intent);
                        }
                    } catch (ParseException unused) {
                        unused.printStackTrace();
                    }
                }
            });
        }

        private boolean checkAndRequestPermissions() {
            String str = "android.permission.WRITE_EXTERNAL_STORAGE";
            int checkSelfPermission = ContextCompat.checkSelfPermission(this.context, str);
            ArrayList arrayList = new ArrayList();
            if (checkSelfPermission != 0) {
                arrayList.add(str);
            }
            if (arrayList.isEmpty()) {
                return true;
            }
            ActivityCompat.requestPermissions(this.activity, (String[]) arrayList.toArray(new String[arrayList.size()]), 1);
            return false;
        }

        public int getItemCount() {
            return this.msgid.size();
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_messages);
        this.context = this;
        this.sharedPreferences = this.context.getSharedPreferences("MYPREFERENCE", 0);
        this.editor = this.sharedPreferences.edit();
        lockCounter = this.sharedPreferences.getInt("lockcounter", 0);
        this.baseHelper = new DataBaseHelper(getApplicationContext());
        try {
            this.baseHelper.createDataBase();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String str = "inappreview";
        this.editor.putInt(str, this.sharedPreferences.getInt(str, 0) + 1).apply();
        if (this.sharedPreferences.getInt(str, 0) > 6 || this.sharedPreferences.getInt(str, 0) == 1) {
            RateAndReview1(getApplicationContext());
        }
        this.face1 = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Bold.ttf");
        this.face2 = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Regular.ttf");
        this.cattext = (TextView) findViewById(R.id.categorytext);
        this.cattext.setTypeface(this.face1);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle((CharSequence) "");
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.action_bar_title, null);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        TextView textView = (TextView) inflate.findViewById(R.id.action_bar_title);
        textView.setText(getResources().getString(R.string.appname));
        textView.setTypeface(this.face1);
        if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(30.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        this.recyclerview = (RecyclerView) findViewById(R.id.recylerview);
        this.recyclerview.setHasFixedSize(true);
        Bundle extras = getIntent().getExtras();
        this.pg_id = (String) extras.get("pg_id");
        this.pg_title = (String) extras.get("pg_title");
        this.msgid = this.baseHelper.getMsgId(this.pg_id);
        this.msg = this.baseHelper.getMsg(this.pg_id);
        this.image = this.baseHelper.getImage(this.pg_id);
        this.fav = this.baseHelper.getFav(this.pg_id);
        this.url = this.baseHelper.getUrl(this.pg_id);
        this.cat = this.baseHelper.getCat(this.pg_id);
        this.cattext.setText(this.pg_title);
        BannerAds();
        this.Radapter = new MyRecyclerAdapter(getApplicationContext(), this.msg, this.msgid, this.image, this.fav, this.url, this.cat, this.pg_title, this.activity);
        this.recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        this.recyclerview.setAdapter(this.Radapter);
    }


    public void RateAndReview1(Context context) {
        this.manager = ReviewManagerFactory.create(context);
        this.manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener<ReviewInfo>() {
            public void onComplete(Task<ReviewInfo> task) {
                String str = "inapp reivew";
                if (task.isSuccessful()) {
                    MessagesActivity.this.reviewInfo = (ReviewInfo) task.getResult();
                    Log.e(str, "In-app REVIEW SUCCESSFUL");
                    return;
                }
            }
        });
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void RateAndReview() {
        String str = "inapp reivew";
        String str2 = "inappreview";
        if (this.sharedPreferences.getInt(str2, 0) > 6) {
            this.editor.putInt(str2, 1).apply();
        }
        try {
            if (this.manager != null) {
                if (this.reviewInfo != null) {
                    this.manager.launchReviewFlow(this, this.reviewInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        public void onComplete(Task<Void> task) {
                            Log.e("inapp reivew", "In-app REVIEW SUCCESSFUL");
                            MessagesActivity.this.finish();
                        }
                    });
                    return;
                }
            }
            RATE_DIALOG();
        } catch (Exception unused) {
            unused.printStackTrace();
            RATE_DIALOG();
        }
    }

    public void onBackPressed() {
        String str = "inappreview";
        if (this.sharedPreferences.getInt(str, 0) > 6 || this.sharedPreferences.getInt(str, 0) == 1) {
            RateAndReview();
            return;
        }
        String str2 = "rateagain";
        if (this.sharedPreferences.getInt(str2, 0) > 12 || this.sharedPreferences.getInt("applaunched", 0) == 0) {
            this.editor.putInt(str2, 0);
            this.editor.commit();
            RATE_DIALOG();
            return;
        }
        MainActivity.check_paused = true;
        super.onBackPressed();
    }

    public void onResume() {
        super.onResume();
        IronSource.onResume(this);
        if (FavoriteActivity.backpressed) {
            this.msgid = this.baseHelper.getMsgId(this.pg_id);
            this.msg = this.baseHelper.getMsg(this.pg_id);
            this.image = this.baseHelper.getImage(this.pg_id);
            this.fav = this.baseHelper.getFav(this.pg_id);
            this.url = this.baseHelper.getUrl(this.pg_id);
            this.cat = this.baseHelper.getCat(this.pg_id);
            this.Radapter = new MyRecyclerAdapter(getApplicationContext(), this.msg, this.msgid, this.image, this.fav, this.url, this.cat, this.pg_title, this.activity);
            this.recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            this.recyclerview.getLayoutManager().scrollToPosition(this.currentVisiblePosition);
            this.recyclerview.setAdapter(this.Radapter);
            this.currentVisiblePosition = 0;
        }
        checkRewardAds();
    }


    public void onPause() {
        this.currentVisiblePosition = ((LinearLayoutManager) this.recyclerview.getLayoutManager()).findFirstCompletelyVisibleItemPosition();
        super.onPause();

    }



    public void onRestart() {
        super.onRestart();
    }



    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.favorite, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
        } else if (itemId == R.id.favmenu) {
            Intent intent = new Intent(this, FavoriteActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }


    public void checkRewardAds() {
        String str = "lock";
        String str2 = "dd/M/yyyy hh:mm:ss";
        String str3 = "unlocked";
        try {
            String string = this.sharedPreferences.getString("date", new SimpleDateFormat(str2, Locale.ENGLISH).format(Calendar.getInstance().getTime()));
            Date time = Calendar.getInstance().getTime();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str2, Locale.ENGLISH);
            if (getDifference(simpleDateFormat.parse(string), simpleDateFormat.parse(simpleDateFormat.format(time))) >= 5) {
                isFirst = true;
                this.editor.putBoolean(str3, false);
                this.editor.putBoolean(str, true);
                this.editor.commit();
                MyRecyclerAdapter myRecyclerAdapter = new MyRecyclerAdapter(getApplicationContext(), this.msg, this.msgid, this.image, this.fav, this.url, this.cat, this.pg_title, this.activity);
                this.recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                this.recyclerview.setAdapter(myRecyclerAdapter);
            }
        } catch (ParseException unused) {
            unused.printStackTrace();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("unlocked ");
        stringBuilder.append(unlocked);
        stringBuilder.append(" sP unlocked ");
        stringBuilder.append(this.sharedPreferences.getBoolean(str3, false));
        stringBuilder.append(" sP unlocked2 ");
        stringBuilder.append(this.sharedPreferences.getBoolean("unlocked2", false));
        Log.e("jjjj", stringBuilder.toString());
        if (unlocked.booleanValue() && this.sharedPreferences.getBoolean(str3, false)) {
            Intent intent = new Intent(this, GreetingActivity.class);
            intent.putExtra("source", "MainActivity");
            intent.putExtra(NotificationCompat.CATEGORY_MESSAGE, greeting);
            startActivity(intent);
            unlocked = Boolean.valueOf(false);
            lockCounter = 0;
            this.Radapter = new MyRecyclerAdapter(getApplicationContext(), this.msg, this.msgid, this.image, this.fav, this.url, this.cat, this.pg_title, this.activity);
            this.recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            this.recyclerview.setAdapter(this.Radapter);
            this.editor.putBoolean(str, false);
            this.editor.commit();
            Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.unlocked), Toast.LENGTH_LONG).show();
        }
    }



    public static int getDifference(Date date, Date date2) {
        return (int) ((date2.getTime() - date.getTime()) / 86400000);
    }


    public void saveImage(Bitmap bitmap, int i) {
        try {
            File externalStorageDirectory = Environment.getExternalStorageDirectory();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(i);
            stringBuilder.append(".jpg");
            File file = new File(externalStorageDirectory, stringBuilder.toString());
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                bitmap.compress(CompressFormat.JPEG, 100, fileOutputStream);
                try {
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.ImageSave), Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (FileNotFoundException e2) {
                e2.printStackTrace();
                Toast.makeText(this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
            }
            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
            intent.setData(Uri.fromFile(file));
            sendBroadcast(intent);
            Map hashMap = new HashMap();
            hashMap.put(getApplicationContext().getResources().getString(R.string.saveimage), this.pg_title);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("");
            stringBuilder2.append(getApplicationContext().getResources().getString(R.string.saveimage));
            stringBuilder2.append("  ");
            stringBuilder2.append(this.pg_title);
            Log.e("Flurry", stringBuilder2.toString());
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    private boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    public void AddRateClicks() {
        String str = "rateagain";
        if (this.sharedPreferences.getInt(str, 0) < 13) {
            int i = this.sharedPreferences.getInt(str, 0) + 1;
            this.editor.putInt(str, i);
            this.editor.commit();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(i);
            Log.e("clicks ", stringBuilder.toString());
        }
    }

    private void RATE_DIALOG() {
        View inflate = View.inflate(this, R.layout.rateus_dialog, null);
        this.dialogR = new Dialog(this);
        Dialog dialog = this.dialogR;
        dialog.getWindow();
        dialog.requestWindowFeature(1);
        this.dialogR.setContentView(inflate);
        this.dialogR.setCancelable(false);
        TextView textView = (TextView) this.dialogR.findViewById(R.id.ratedailog_text);
        textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textView.setText(getResources().getString(R.string.rate_us));
        Button button = (Button) this.dialogR.findViewById(R.id.btn_yes);
        Button button2 = (Button) this.dialogR.findViewById(R.id.btn_later);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Yes I will Clicked");
                MessagesActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                MessagesActivity.this.finish();
                MessagesActivity.this.dialogR.cancel();
            }
        });
        button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Rate Later Clicked");
                MainActivity.check_paused = true;
                MessagesActivity.this.dialogR.cancel();
                MessagesActivity.this.finish();
            }
        });
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
            button.setTextSize(30.0f);
            button2.setTextSize(30.0f);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(28.0f);
            button.setTextSize(26.0f);
            button2.setTextSize(26.0f);
        } else {
            textView.setTextSize(20.0f);
            button.setTextSize(18.0f);
            button2.setTextSize(18.0f);
        }
        if (!isFinishing()) {
            this.dialogR.show();
        }
    }
}
