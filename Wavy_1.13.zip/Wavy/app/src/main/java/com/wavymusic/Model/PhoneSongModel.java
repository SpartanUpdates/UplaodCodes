package com.wavymusic.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class PhoneSongModel {

    public static final Parcelable.Creator<PhoneSongModel> CREATOR = new MusicCreater();
    private long A;
    private float B;
    private String C;
    private String D;
    private String E;
    private String F;
    private long G;
    private float H;
    private long I;
    private int J;

    private boolean l;

    PhoneSongModel() {

    }

    public PhoneSongModel(int id, String title, String artist, String album, String path, long duration) {
        J = id;
        E = title;
        D = artist;
        F = path;
        G = duration;
    }

    public int a() {
        return this.J;
    }

    public void a(int i) {
        this.J = i;
    }

    public void a(long j) {
        this.I = j;
    }

    public void a(String str) {
        this.F = str;
    }

    public long b() {
        return this.I;
    }

    public void b(long j) {
        this.A = j;
    }

    public void b(String str) {
        this.E = str;
    }

    public String c() {
        return this.F;
    }

    public void c(long j) {
        this.G = j;
    }

    public void c(String str) {
        this.D = str;
    }

    public Object clone() {
        return musicresult();
    }

    public String m5778d() {
        return this.E;
    }

    public int describeContents() {
        return 0;
    }

    public long e() {
        return this.G;
    }

    public long f() {
        return this.A - this.I;
    }

    public void l(boolean z) {
        this.l = z;
    }

    public boolean l() {
        return this.l;
    }

    public PhoneSongModel musicresult() {
        PhoneSongModel musicRes = new PhoneSongModel();
        musicRes.J = this.J;
        musicRes.E = this.E;
        musicRes.D = this.D;
        musicRes.G = this.G;
        musicRes.F = this.F;
        musicRes.I = this.I;
        musicRes.A = this.A;
        musicRes.C = this.C;
        return musicRes;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.J);
        parcel.writeString(this.E);
        parcel.writeString(this.D);
        parcel.writeLong(this.G);
        parcel.writeString(this.F);
        parcel.writeLong(this.I);
        parcel.writeLong(this.A);
        parcel.writeFloat(this.H);
        parcel.writeString(this.C);
        parcel.writeFloat(this.B);
    }

    static class MusicCreater implements Parcelable.Creator<PhoneSongModel> {
        MusicCreater() {
        }

        public PhoneSongModel m5756a(Parcel parcel) {
            PhoneSongModel musicRes = new PhoneSongModel();
            musicRes.J = parcel.readInt();
            musicRes.E = parcel.readString();
            musicRes.D = parcel.readString();
            musicRes.G = parcel.readLong();
            musicRes.F = parcel.readString();
            musicRes.I = parcel.readLong();
            musicRes.A = parcel.readLong();
            musicRes.H = parcel.readFloat();
            musicRes.C = parcel.readString();
            musicRes.B = parcel.readFloat();
            return musicRes;
        }

        public PhoneSongModel[] m5757a(int i) {
            return new PhoneSongModel[i];
        }


        public PhoneSongModel createFromParcel(Parcel parcel) {
            return m5756a(parcel);

        }


        public PhoneSongModel[] newArray(int i) {
            return m5757a(i);
        }
    }

}
