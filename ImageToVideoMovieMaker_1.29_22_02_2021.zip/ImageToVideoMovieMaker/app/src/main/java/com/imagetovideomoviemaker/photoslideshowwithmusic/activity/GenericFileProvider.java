package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
