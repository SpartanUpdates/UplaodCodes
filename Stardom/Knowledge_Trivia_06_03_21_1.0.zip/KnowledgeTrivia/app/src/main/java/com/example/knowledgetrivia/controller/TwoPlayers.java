package com.example.knowledgetrivia.controller;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.content.ContextCompat;

import com.example.knowledgetrivia.R;
import com.example.knowledgetrivia.database.DatabaseHelper;
import com.example.knowledgetrivia.kprogresshud.KProgressHUD;
import com.example.knowledgetrivia.models.LevelScore;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.muddzdev.styleabletoast.StyleableToast.Builder;

import java.util.ArrayList;

public class TwoPlayers extends AppCompatActivity {
    Activity activity=TwoPlayers.this;
    private ConstraintLayout alert_msg_layout;
    private LinearLayout alpha_layout;
    private Button okButton;
    private Button playButton;
    private EditText player1;
    private EditText player2;
    private MediaPlayer tick;


    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public void onCreate(Bundle bundle)
    {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_two_players);

        BannerAds();
        interstitialAd();

        this.player1 = (EditText) findViewById(R.id.player1NameField);
        this.player2 = (EditText) findViewById(R.id.player2NameField);
        this.playButton = (Button) findViewById(R.id.playButton);
        this.okButton = (Button) findViewById(R.id.alert_button);
        this.alert_msg_layout = (ConstraintLayout) findViewById(R.id.alert_msg_layout);
        this.alpha_layout = (LinearLayout) findViewById(R.id.alpha_layout);
        this.tick = MediaPlayer.create(this, R.raw.tick);

        this.playButton.setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                   PlayStart();
                }

            }
        });

        this.okButton.setOnClickListener(new OnClickListener()
        {
            public void onClick(View view) {
                TwoPlayers.this.alpha_layout.setVisibility(View.GONE);
                TwoPlayers.this.alert_msg_layout.setVisibility(View.GONE);
            }
        });
    }

    private void PlayStart()
    {
        TwoPlayers.this.tick.start();
        String obj = TwoPlayers.this.player1.getText().toString();
        String obj2 = TwoPlayers.this.player2.getText().toString();
        if (obj.isEmpty() || obj2.isEmpty()) {
            new Builder(TwoPlayers.this.getApplicationContext()).text("Names should not be empty.").backgroundColor(ContextCompat.getColor(TwoPlayers.this.getApplicationContext(), R.color.happy_color)).textColor(-1).length(0).iconStart(R.drawable.happy).solidBackground().show();
            return;
        }
        Intent intent = new Intent(TwoPlayers.this, TwoPlayerShowingQuestion.class);
        intent.putExtra("name1", obj);
        intent.putExtra("name2", obj2);
        TwoPlayers.this.startActivity(intent);
        TwoPlayers.this.finish();
    }
    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdmobBannerId));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdmobInterstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        PlayStart();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdmobInterstitial));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
