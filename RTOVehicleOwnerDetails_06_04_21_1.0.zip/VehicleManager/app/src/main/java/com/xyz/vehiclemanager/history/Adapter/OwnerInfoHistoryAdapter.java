package com.xyz.vehiclemanager.history.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.history.Model.OwnerHistory;
import com.xyz.vehiclemanager.history.Room.HistoryDatabase;
import com.xyz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity;
import java.util.List;

public class OwnerInfoHistoryAdapter extends RecyclerView.Adapter<OwnerInfoHistoryAdapter.ViewHolder> {
    Context mcontext;
    List<OwnerHistory> ownerHistoryArrayList;
    public OwnerInfoHistoryAdapter(Context mcontext, List<OwnerHistory> ownerHistoryArrayList) {
        this.mcontext = mcontext;
        this.ownerHistoryArrayList = ownerHistoryArrayList;
    }
    public class ViewHolder extends RecyclerView.ViewHolder
    {
        LinearLayout ll_main;
        TextView tv_ownerName, tv_ownerVehicleNumber;
        ImageView iv_delete;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ll_main = itemView.findViewById(R.id.ll_main);
            tv_ownerName = itemView.findViewById(R.id.tv_OwnerName);
            tv_ownerVehicleNumber = itemView.findViewById(R.id.tv_OwnerVehicleNumber);
            iv_delete = itemView.findViewById(R.id.iv_delete);
        }
    }
    private void deleteItem(int position2) {
        ownerHistoryArrayList.remove(position2);
        notifyItemRemoved(position2);
        notifyItemRangeChanged(position2, ownerHistoryArrayList.size());
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_history,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final OwnerHistory ownerHistory=ownerHistoryArrayList.get(position);
        holder.tv_ownerName.setText(ownerHistory.getOwnerName());
        holder.tv_ownerVehicleNumber.setText(ownerHistory.getRegistrationNo());
        holder.iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem(position);
                HistoryDatabase.getDatabase(mcontext).ownerHistoryDao().deleteOwnerDetails(ownerHistory.getRegistrationNo());
            }
        });
        holder.ll_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(mcontext, RtoOwnerDetailActivity.class);
                intent.putExtra("imageUri",ownerHistory.getImageUrl());
                intent.putExtra("ownerName", ownerHistory.getOwnerName());
                intent.putExtra("registrationNumber",ownerHistory.getRegistrationNo());
                intent.putExtra("registrationDate",ownerHistory.getRegistrationDate());
                intent.putExtra("fuelType", ownerHistory.getFuelType());
                intent.putExtra("chassisNumber", ownerHistory.getChasisNumber());
                intent.putExtra("fuelNorms",ownerHistory.getFuelNorms());
                intent.putExtra("engineNumber", ownerHistory.getEngineNumber());
                intent.putExtra("insuranceUpto",ownerHistory.getInsuranceUpto());
                intent.putExtra("fitnessUpto",ownerHistory.getFitnessUpto());
                intent.putExtra("vehicleClass",ownerHistory.getVehicleClass());
                intent.putExtra("city",ownerHistory.getCity());
                intent.putExtra("markerModel",ownerHistory.getMarkerModel());
                intent.putExtra("brandName",ownerHistory.getBrandName());
                intent.putExtra("modelName",ownerHistory.getModelName());
                intent.putExtra("showRoomPrice", ownerHistory.getShowRoomPrice());
                intent.putExtra("vehicleType",ownerHistory.getVehicleType());
                intent.putExtra("vehicleColor",ownerHistory.getVehicleColor());
                intent.putExtra("seatCapacity",ownerHistory.getSeatCapacity());
                intent.putExtra("ownerShip",ownerHistory.getOwnership());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mcontext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return ownerHistoryArrayList.size();
    }
}
