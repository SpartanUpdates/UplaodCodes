package com.xyz.vehiclemanager.cardetails.cardealer.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.cardetails.cardealer.activity.CarDealerSelectStateActivity;
import com.xyz.vehiclemanager.model.CarBrands;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CarBrandDealerAdapter extends RecyclerView.Adapter<CarBrandDealerAdapter.ViewHolder> {

    Context context;
    ArrayList<CarBrands> carBrandlist;

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_carbrandsname;
        ImageView iv_carbrands;
        LinearLayout ll_carbrand;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_carbrandsname = itemView.findViewById(R.id.tv_carbrandsname);
            iv_carbrands = itemView.findViewById(R.id.iv_carbrands);
            ll_carbrand = itemView.findViewById(R.id.ll_carbrand);
        }
    }

    public CarBrandDealerAdapter(Context context, ArrayList<CarBrands> carBrandsList) {
        this.context = context;
        this.carBrandlist = carBrandsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_carbrads,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        final CarBrands carDealerBrands = carBrandlist.get(position);

        holder.tv_carbrandsname.setText(carDealerBrands.getBrandName());
        Glide.with(context)
                .load(carDealerBrands.getImageUrl())
                .placeholder(R.drawable.ic_car)
                .into(holder.iv_carbrands);

        final String brandId = carDealerBrands.getId();

        holder.ll_carbrand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CarDealerSelectStateActivity.class);
                intent.putExtra("brandId",brandId);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return carBrandlist.size();
    }

}
