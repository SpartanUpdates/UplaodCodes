package com.videozoneinc.musicvideoeditor;

import android.graphics.Typeface;

public interface OnStickerSelected {
    void onStickerTouch(int i);

    void onTextStyleChange(Typeface typeface);
}
