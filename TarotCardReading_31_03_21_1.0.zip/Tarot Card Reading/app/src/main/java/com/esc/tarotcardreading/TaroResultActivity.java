package com.esc.tarotcardreading;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;

import com.google.ads.consent.ConsentInformation;
import com.google.android.gms.ads.AdRequest;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Random;

public class TaroResultActivity extends AppCompatActivity {
    Activity activity = TaroResultActivity.this;
    public static Editor editor = null;
    public static String head = "";
    public static SharedPreferences sharedpreferences = null;
    public static String type;
    int arrlen;
    Bitmap bm;
    ImageView card;
    ImageView card1;
    ImageView card10;
    ImageView card2;
    ImageView card3;
    ImageView card4;
    ImageView card5;
    ImageView card6;
    ImageView card7;
    ImageView card8;
    ImageView card9;
    public String cc2;
    public String ccb;
    private Runnable changeAdBoolMoreapps;
    BitmapDrawable d1;
    BitmapDrawable d2;
    BitmapDrawable d3;
    BitmapDrawable d4;
    BitmapDrawable d5;
    public String dcn1;
    public String dcn2;
    public String dcn3;
    public String dcn4;
    public String dcn5;
    int dia;
    BitmapDrawable draw;
    ImageButton email;
    ImageButton facebook;
    OnClickListener faceshare;
    Boolean fbsharerateusclicked;
    ArrayList<Uri> files;
    public String line;
    OnClickListener listenemail;
    String locale;
    private Handler mHandlerMoreapps;
    RelativeLayout moreapps;
    TextView moreappstxt;
    String msg2;
    String name;
    public String name2;
    String[] names;
    String[] names2;
    ImageView next;
    String nine;
    int nooftimes_resultviewd;
    String one;
    String output;
    String page;
    Uri pngUri;
    ImageView prev;
    String queen;
    int resid;
    int[] resids;
    public String result;
    int resultindex;
    String[] results;
    String savedemail;
    String savedpass;
    HorizontalScrollView sc;
    View sendmail;
    String seven;
    int sh;
    Boolean sharerateusclicked;
    String six;
    private String source;
    private boolean startboolMoreapps;
    String[] status;
    String subtype;
    String subtype_eng;
    int sw;
    TextView tcardname;
    TextView tcardname1;
    TextView tcardname10;
    TextView tcardname2;
    TextView tcardname3;
    TextView tcardname4;
    TextView tcardname5;
    TextView tcardname6;
    TextView tcardname7;
    TextView tcardname8;
    TextView tcardname9;
    String ten;
    TextView thead;
    TextView thead0;
    String three;
    TextView titleview;
    TextView tmessage;
    TextView trestext;
    TextView trestext10;
    TextView trestext2;
    TextView trestext3;
    TextView trestext4;
    TextView trestext5;
    TextView trestext6;
    TextView trestext7;
    TextView trestext8;
    TextView trestext9;
    String two;

    public TaroResultActivity() {
        Boolean valueOf = Boolean.valueOf(false);
        this.fbsharerateusclicked = valueOf;
        this.sharerateusclicked = valueOf;
        String str = "";
        this.result = str;
        this.output = str;
        this.msg2 = str;
        this.resids = new int[10];
        this.results = new String[10];
        this.status = new String[10];
        this.resultindex = 0;
        this.names = null;
        this.names2 = null;
        this.resid = 0;
        this.name = str;
        this.dia = 0;
        this.arrlen = 0;
        this.files = new ArrayList();
        this.ccb = str;
        this.cc2 = str;
        this.name2 = str;
        this.dcn1 = str;
        this.dcn2 = str;
        this.dcn3 = str;
        this.dcn4 = str;
        this.dcn5 = str;
        this.locale = str;
        this.nooftimes_resultviewd = 0;
        this.listenemail = new OnClickListener() {
            public void onClick(View view) {
                if (TaroResultActivity.CheckPermisson(TaroResultActivity.this)) {
                    String str = "TaroResult";
                    StringBuilder stringBuilder;
                    if (TaroResultActivity.this.ccb.equals("Meanings Of All Tarot Cards")) {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("tracker - Share Button Email ccb= ");
                        stringBuilder.append(TaroResultActivity.this.ccb);
                        stringBuilder.append(" - subtype = ");
                        stringBuilder.append(TaroResultActivity.this.subtype_eng);
                        stringBuilder.append(" - name = ");
                        stringBuilder.append(TaroResultActivity.this.name);
                        Log.e(str, stringBuilder.toString());
                    } else {
                        if (TaroResultActivity.this.cc2 != null) {
                            String str2 = "";
                            if (!TaroResultActivity.this.cc2.equals(str2)) {
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(" - ");
                                stringBuilder.append(TaroResultActivity.this.cc2);
                                String stringBuilder2 = stringBuilder.toString();
                                StringBuilder stringBuilder3 = new StringBuilder();
                                stringBuilder3.append("ELSE tracker Share Button Email ccb= ");
                                stringBuilder3.append(TaroResultActivity.this.ccb);
                                stringBuilder3.append(str2);
                                stringBuilder3.append(stringBuilder2);
                                Log.e(str, stringBuilder3.toString());
                            }
                        }
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("IF tracker Share Button Email1 ccb= ");
                        stringBuilder.append(TaroResultActivity.this.ccb);
                        Log.e(str, stringBuilder.toString());
                    }
                    TaroResultActivity.this.showPopUp2("email", "Send E-Mail", "Enter Subject:", TaroResultActivity.type);
                }
            }
        };
        this.faceshare = new OnClickListener() {
            public void onClick(View view) {
                TaroResultActivity.this.fb();
            }
        };
        this.mHandlerMoreapps = new Handler();
        this.startboolMoreapps = false;
        this.source = "Tarot_Card_Reading";
        this.changeAdBoolMoreapps = new Runnable() {
            public void run() {
                TaroResultActivity.this.mHandlerMoreapps.postDelayed(TaroResultActivity.this.changeAdBoolMoreapps, 200);
            }
        };
    }

    public static boolean CheckPermisson(final Context context) {
        String str = "android.permission.WRITE_EXTERNAL_STORAGE";
        if (ContextCompat.checkSelfPermission(context, str) != 0) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle(context.getString(R.string.req_per));
            builder.setMessage(context.getString(R.string.access_photo));
            builder.setCancelable(false).setPositiveButton(context.getString(R.string.ok), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityCompat.requestPermissions((Activity) context, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 1000);
                    Toast.makeText(context, context.getResources().getString(R.string.gt_setting), Toast.LENGTH_LONG).show();
                }
            }).setNegativeButton(context.getString(R.string.can), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            builder.create().show();
        }
        return ContextCompat.checkSelfPermission(context, str) == 0;
    }

    public void showPopUp2(String str, String str2, String str3, String str4) {
        popup(str, str2, str3, str4);
    }

    public void popup(String str, String str2, String str3, String str4) {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean z6;
        boolean z7;
        String str5 = str4;
        boolean z8 = true;
        this.sharerateusclicked = Boolean.valueOf(true);
        String str6 = "\n";
        String str7 = "";
        String str8 = " ";
        String str9 = "https://play.google.com/store/apps/details?id=" + getPackageName();
        String str10 = "<br>";
        String str11 = "<br><br>";
        if (str5.equals("one")) {
            if (this.name2.isEmpty()) {
                this.name2 = str7;
                z6 = true;
            } else {
                z6 = false;
            }
            if (head.isEmpty()) {
                head = str7;
                z7 = true;
            } else {
                z7 = false;
            }
            if (this.result.isEmpty()) {
                this.result = str7;
            } else {
                z8 = false;
            }
            if (z6 || z7 || z8) {
                StringBuilder sb = new StringBuilder();
                sb.append(getResources().getString(R.string.share2));
                sb.append(str10);
                sb.append(str9);
                this.msg2 = sb.toString();
            } else {
                StringBuilder sb2 = new StringBuilder();
                sb2.append(getResources().getString(R.string.share1));
                sb2.append(str8);
                sb2.append(head);
                sb2.append(str8);
                sb2.append(getResources().getString(R.string.sharer));
                sb2.append(str11);
                sb2.append(this.name2.toUpperCase());
                sb2.append(str10);
                sb2.append(this.result.replaceAll(str6, str10));
                sb2.append(str11);
                sb2.append(getResources().getString(R.string.share2));
                sb2.append(str10);
                sb2.append(str9);
                this.msg2 = sb2.toString();
            }
            StringBuilder sb3 = new StringBuilder();
            sb3.append("*****");
            sb3.append(head);
            String str12 = "....";
            sb3.append(str12);
            sb3.append(this.name2);
            sb3.append(str12);
            sb3.append(this.result);
            Log.e("Error check", sb3.toString());
        } else {
            String str13 = ")<br>";
            String str14 = "(";
            if (str5.equals("three")) {
                String[] strArr = this.names2;
                boolean z9 = strArr.length <= 0 || strArr == null;
                if (head.length() <= 0 || head == null) {
                    head = str7;
                    z5 = true;
                } else {
                    z5 = false;
                }
                boolean z10 = this.results.length <= 0;
                if (z9 || z5 || z10) {
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append(getResources().getString(R.string.share2));
                    sb4.append(str10);
                    sb4.append(str9);
                    this.msg2 = sb4.toString();
                } else if (this.ccb.equals("Birthday Tarot Reading")) {
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append(getResources().getString(R.string.share1));
                    sb5.append(str8);
                    sb5.append(head);
                    sb5.append(str11);
                    sb5.append(this.status[0]);
                    sb5.append(str14);
                    sb5.append(this.names2[0].toUpperCase());
                    sb5.append(str13);
                    sb5.append(this.results[0]);
                    sb5.append(str11);
                    sb5.append(this.status[1]);
                    sb5.append(str14);
                    sb5.append(this.names2[1].toUpperCase());
                    sb5.append(str13);
                    sb5.append(this.results[1]);
                    sb5.append(str11);
                    sb5.append(this.status[2]);
                    sb5.append(str14);
                    sb5.append(this.names2[2].toUpperCase());
                    sb5.append(str13);
                    sb5.append(this.results[2]);
                    sb5.append(str11);
                    sb5.append(getResources().getString(R.string.share2));
                    sb5.append(str10);
                    sb5.append(str9);
                    this.msg2 = sb5.toString();
                } else {
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append(getResources().getString(R.string.share1));
                    sb6.append(str8);
                    sb6.append(head);
                    sb6.append(str8);
                    sb6.append(getResources().getString(R.string.sharer));
                    sb6.append(str11);
                    sb6.append(this.status[0]);
                    sb6.append(str14);
                    sb6.append(this.names2[0].toUpperCase());
                    sb6.append(str13);
                    sb6.append(this.results[0]);
                    sb6.append(str11);
                    sb6.append(this.status[1]);
                    sb6.append(str14);
                    sb6.append(this.names2[1].toUpperCase());
                    sb6.append(str13);
                    sb6.append(this.results[1]);
                    sb6.append(str11);
                    sb6.append(this.status[2]);
                    sb6.append(str14);
                    sb6.append(this.names2[2].toUpperCase());
                    sb6.append(str13);
                    sb6.append(this.results[2]);
                    sb6.append(str11);
                    sb6.append(getResources().getString(R.string.share2));
                    sb6.append(str10);
                    sb6.append(str9);
                    this.msg2 = sb6.toString();
                }
            } else if (str5.equals("four")) {
                String[] strArr2 = this.names2;
                boolean z11 = strArr2.length <= 0 || strArr2 == null;
                if (head.length() <= 0 || head == null) {
                    head = str7;
                    z4 = true;
                } else {
                    z4 = false;
                }
                boolean z12 = this.results.length <= 0;
                if (z11 || z4 || z12) {
                    StringBuilder sb7 = new StringBuilder();
                    sb7.append(getResources().getString(R.string.share2));
                    sb7.append(str10);
                    sb7.append(str9);
                    this.msg2 = sb7.toString();
                } else {
                    StringBuilder sb8 = new StringBuilder();
                    sb8.append(getResources().getString(R.string.share1));
                    sb8.append(str8);
                    sb8.append(head);
                    sb8.append(str8);
                    sb8.append(getResources().getString(R.string.sharer));
                    sb8.append(str11);
                    sb8.append(this.status[0]);
                    sb8.append(str14);
                    sb8.append(this.names2[0].toUpperCase());
                    sb8.append(str13);
                    sb8.append(this.results[0]);
                    sb8.append(str11);
                    sb8.append(this.status[1]);
                    sb8.append(str14);
                    sb8.append(this.names2[1].toUpperCase());
                    sb8.append(str13);
                    sb8.append(this.results[1]);
                    sb8.append(str11);
                    sb8.append(this.status[2]);
                    sb8.append(str14);
                    sb8.append(this.names2[2].toUpperCase());
                    sb8.append(str13);
                    sb8.append(this.results[2]);
                    sb8.append(str11);
                    sb8.append(this.status[3]);
                    sb8.append(str14);
                    sb8.append(this.names2[3].toUpperCase());
                    sb8.append(str13);
                    sb8.append(this.results[3]);
                    sb8.append(str11);
                    sb8.append(getResources().getString(R.string.share2));
                    sb8.append(str10);
                    sb8.append(str9);
                    this.msg2 = sb8.toString();
                }
            } else if (str5.equals("ten")) {
                String[] strArr3 = this.names2;
                boolean z13 = strArr3.length <= 0 || strArr3 == null;
                if (head.length() <= 0 || head == null) {
                    head = str7;
                    z3 = true;
                } else {
                    z3 = false;
                }
                boolean z14 = this.results.length <= 0;
                if (z13 || z3 || z14) {
                    StringBuilder sb9 = new StringBuilder();
                    sb9.append(getResources().getString(R.string.share2));
                    sb9.append(str10);
                    sb9.append(str9);
                    this.msg2 = sb9.toString();
                } else {
                    StringBuilder sb10 = new StringBuilder();
                    sb10.append(getResources().getString(R.string.share1));
                    sb10.append(str8);
                    sb10.append(head);
                    sb10.append(str8);
                    sb10.append(getResources().getString(R.string.sharer));
                    sb10.append(str11);
                    sb10.append(this.status[0]);
                    sb10.append(str14);
                    sb10.append(this.names2[0].toUpperCase());
                    sb10.append(str13);
                    sb10.append(this.results[0]);
                    sb10.append(str11);
                    sb10.append(this.status[1]);
                    sb10.append(str14);
                    sb10.append(this.names2[1].toUpperCase());
                    sb10.append(str13);
                    sb10.append(this.results[1]);
                    sb10.append(str11);
                    sb10.append(this.status[2]);
                    sb10.append(str14);
                    sb10.append(this.names2[2].toUpperCase());
                    sb10.append(str13);
                    sb10.append(this.results[2]);
                    sb10.append(str11);
                    sb10.append(this.status[3]);
                    sb10.append(str14);
                    sb10.append(this.names2[3].toUpperCase());
                    sb10.append(str13);
                    sb10.append(this.results[3]);
                    sb10.append(str11);
                    sb10.append(this.status[4]);
                    sb10.append(str14);
                    sb10.append(this.names2[4].toUpperCase());
                    sb10.append(str13);
                    sb10.append(this.results[4]);
                    sb10.append(str11);
                    sb10.append(this.status[5]);
                    sb10.append(str14);
                    sb10.append(this.names2[5].toUpperCase());
                    sb10.append(str13);
                    sb10.append(this.results[5]);
                    sb10.append(str11);
                    sb10.append(this.status[6]);
                    sb10.append(str14);
                    sb10.append(this.names2[6].toUpperCase());
                    sb10.append(str13);
                    sb10.append(this.results[6]);
                    sb10.append(str11);
                    sb10.append(this.status[7]);
                    sb10.append(str14);
                    sb10.append(this.names2[7].toUpperCase());
                    sb10.append(str13);
                    sb10.append(this.results[7]);
                    sb10.append(str11);
                    sb10.append(this.status[8]);
                    sb10.append(str14);
                    sb10.append(this.names2[8].toUpperCase());
                    sb10.append(str13);
                    sb10.append(this.results[8]);
                    sb10.append(str11);
                    sb10.append(this.status[9]);
                    sb10.append(str14);
                    sb10.append(this.names2[9].toUpperCase());
                    sb10.append(str13);
                    sb10.append(this.results[9]);
                    sb10.append(str11);
                    sb10.append(getResources().getString(R.string.share2));
                    sb10.append(str10);
                    sb10.append(str9);
                    this.msg2 = sb10.toString();
                }
            } else if (str5.equals("seven")) {
                String[] strArr4 = this.names2;
                boolean z15 = strArr4.length <= 0 || strArr4 == null;
                if (head.length() <= 0 || head == null) {
                    head = str7;
                    z2 = true;
                } else {
                    z2 = false;
                }
                boolean z16 = this.results.length <= 0;
                if (z15 || z2 || z16) {
                    StringBuilder sb11 = new StringBuilder();
                    sb11.append(getResources().getString(R.string.share2));
                    sb11.append(str10);
                    sb11.append(str9);
                    this.msg2 = sb11.toString();
                } else {
                    StringBuilder sb12 = new StringBuilder();
                    sb12.append(getResources().getString(R.string.share1));
                    sb12.append(str8);
                    sb12.append(head);
                    sb12.append(str8);
                    sb12.append(getResources().getString(R.string.sharer));
                    sb12.append(str11);
                    sb12.append(this.status[0]);
                    sb12.append(str14);
                    sb12.append(this.names2[0].toUpperCase());
                    sb12.append(str13);
                    sb12.append(this.results[0]);
                    sb12.append(str11);
                    sb12.append(this.status[1]);
                    sb12.append(str14);
                    sb12.append(this.names2[1].toUpperCase());
                    sb12.append(str13);
                    sb12.append(this.results[1]);
                    sb12.append(str11);
                    sb12.append(this.status[2]);
                    sb12.append(str14);
                    sb12.append(this.names2[2].toUpperCase());
                    sb12.append(str13);
                    sb12.append(this.results[2]);
                    sb12.append(str11);
                    sb12.append(this.status[3]);
                    sb12.append(str14);
                    sb12.append(this.names2[3].toUpperCase());
                    sb12.append(str13);
                    sb12.append(this.results[3]);
                    sb12.append(str11);
                    sb12.append(this.status[4]);
                    sb12.append(str14);
                    sb12.append(this.names2[4].toUpperCase());
                    sb12.append(str13);
                    sb12.append(this.results[4]);
                    sb12.append(str11);
                    sb12.append(this.status[5]);
                    sb12.append(str14);
                    sb12.append(this.names2[5].toUpperCase());
                    sb12.append(str13);
                    sb12.append(this.results[5]);
                    sb12.append(str11);
                    sb12.append(this.status[6]);
                    sb12.append(str14);
                    sb12.append(this.names2[6].toUpperCase());
                    sb12.append(str13);
                    sb12.append(this.results[6]);
                    sb12.append(str11);
                    sb12.append(getResources().getString(R.string.share2));
                    sb12.append(str10);
                    sb12.append(str9);
                    this.msg2 = sb12.toString();
                }
            } else {
                String[] strArr5 = this.names2;
                boolean z17 = strArr5.length <= 0 || strArr5 == null;
                if (head.length() <= 0 || head == null) {
                    head = str7;
                    z = true;
                } else {
                    z = false;
                }
                boolean z18 = this.results.length <= 0;
                if (z17 || z || z18) {
                    StringBuilder sb13 = new StringBuilder();
                    sb13.append(getResources().getString(R.string.share2));
                    sb13.append(str10);
                    sb13.append(str9);
                    this.msg2 = sb13.toString();
                } else if (this.ccb.equals("Find Love")) {
                    StringBuilder sb14 = new StringBuilder();
                    sb14.append(getResources().getString(R.string.share1));
                    sb14.append(str8);
                    sb14.append(head);
                    sb14.append(str8);
                    sb14.append(getResources().getString(R.string.sharer));
                    sb14.append(str11);
                    sb14.append(this.status[0]);
                    sb14.append(str14);
                    sb14.append(this.names2[0].toUpperCase());
                    sb14.append(str13);
                    sb14.append(this.results[0]);
                    sb14.append(str11);
                    sb14.append(this.status[1]);
                    sb14.append(str14);
                    sb14.append(this.names2[1].toUpperCase());
                    sb14.append(str13);
                    sb14.append(this.results[1]);
                    sb14.append(str11);
                    sb14.append(this.status[2]);
                    sb14.append(str14);
                    sb14.append(this.names2[2].toUpperCase());
                    sb14.append(str13);
                    sb14.append(this.results[2]);
                    sb14.append(str11);
                    sb14.append(this.status[3]);
                    sb14.append(str14);
                    sb14.append(this.names2[3].toUpperCase());
                    sb14.append(str13);
                    sb14.append(this.results[3]);
                    sb14.append(str11);
                    sb14.append(this.status[4]);
                    sb14.append(str14);
                    sb14.append(this.names2[4].toUpperCase());
                    sb14.append(str13);
                    sb14.append(this.results[4]);
                    sb14.append(str11);
                    sb14.append(getResources().getString(R.string.share2));
                    sb14.append(str10);
                    sb14.append(str9);
                    this.msg2 = sb14.toString();
                } else {
                    StringBuilder sb15 = new StringBuilder();
                    sb15.append(getResources().getString(R.string.share1));
                    sb15.append(str8);
                    sb15.append(head);
                    sb15.append(str11);
                    sb15.append(getResources().getString(R.string.sh1));
                    sb15.append(str14);
                    sb15.append(this.names2[0].toUpperCase());
                    sb15.append(str13);
                    sb15.append(this.results[0]);
                    sb15.append(str11);
                    sb15.append(getResources().getString(R.string.sh2));
                    sb15.append(str14);
                    sb15.append(this.names2[1].toUpperCase());
                    sb15.append(str13);
                    sb15.append(this.results[1]);
                    sb15.append(str11);
                    sb15.append(getResources().getString(R.string.sh3));
                    sb15.append(str14);
                    sb15.append(this.names2[2].toUpperCase());
                    sb15.append(str13);
                    sb15.append(this.results[2]);
                    sb15.append(str11);
                    sb15.append(getResources().getString(R.string.sh4));
                    sb15.append(str14);
                    sb15.append(this.names2[3].toUpperCase());
                    sb15.append(str13);
                    sb15.append(this.results[3]);
                    sb15.append(str11);
                    sb15.append(getResources().getString(R.string.sh5));
                    sb15.append(str14);
                    sb15.append(this.names2[4].toUpperCase());
                    sb15.append(str13);
                    sb15.append(this.results[4]);
                    sb15.append(str11);
                    sb15.append(getResources().getString(R.string.share2));
                    sb15.append(str10);
                    sb15.append(str9);
                    this.msg2 = sb15.toString();
                }
            }
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.SUBJECT", getResources().getString(R.string.app_name));
        this.pngUri = shareImage();
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.STREAM", this.pngUri);
        intent.putExtra("android.intent.extra.TEXT", this.msg2.replaceAll(str10, str6));
        intent.putExtra("android.intent.extra.INTENT", this.msg2.replaceAll(str10, str6));
        startActivity(Intent.createChooser(intent, getResources().getString(R.string.share3)));
        copyText();
    }

    public Uri shareImage() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getPackageName());
        stringBuilder.append(".provider");
        boolean z;
        if (!type.equals("one")) {
            this.bm = BitmapFactory.decodeResource(getApplicationContext().getResources(), R.drawable.ic_share_white_24dp);
            this.arrlen = 1;
        }
        File externalStorageDirectory = Environment.getExternalStorageDirectory();
        for (int i = 0; i < this.arrlen; i++) {
            File file = new File(externalStorageDirectory, "tarot.png");
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                this.bm.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
                z = true;
            } catch (FileNotFoundException unused) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.gt_setting), Toast.LENGTH_LONG).show();
                z = false;
                if (!z) {
                }
                this.pngUri = FileProvider.getUriForFile(this, stringBuilder.toString(), file);
            } catch (Exception e) {
                e.printStackTrace();
                z = false;
                if (!z) {
                }
                this.pngUri = FileProvider.getUriForFile(this, stringBuilder.toString(), file);
            }
            if (!z) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.savingerror), Toast.LENGTH_LONG).show();
            }
            this.pngUri = FileProvider.getUriForFile(this, stringBuilder.toString(), file);
        }
        return this.pngUri;
    }

    public void copyText() {
        if (VERSION.SDK_INT >= 11) {
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("label", Html.fromHtml(this.msg2)));
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.copytxt), Toast.LENGTH_LONG).show();
            return;
        }
        ((android.text.ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setText(Html.fromHtml(this.msg2));
        Toast.makeText(getApplicationContext(), getResources().getString(R.string.copytxt), Toast.LENGTH_LONG).show();
    }

    public void fb() {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean z6;
        boolean z7;
        boolean z8;
        boolean z9 = true;
        this.fbsharerateusclicked = Boolean.valueOf(true);
        Bundle bundle = new Bundle();
        String str = "";
        StringBuffer stringBuffer = new StringBuffer(str);
        this.tmessage = new TextView(this);
        String str2 = " ";
        String str3 = "https://play.google.com/store/apps/details?id=" + getPackageName();
        String str4 = "<br>";
        String str5 = "<br><br>";
        if (type.equals("one")) {
            if (this.name2.length() <= 0 || this.name2 == null) {
                this.name2 = str;
                z7 = true;
            } else {
                z7 = false;
            }
            if (head.length() <= 0 || head == null) {
                head = str;
                z8 = true;
            } else {
                z8 = false;
            }
            if (this.result.length() <= 0 || this.result == null) {
                this.result = str;
            } else {
                z9 = false;
            }
            if (z7 || z8 || z9) {
                StringBuilder sb = new StringBuilder();
                sb.append(getResources().getString(R.string.share2));
                sb.append(str4);
                sb.append(str3);
                this.msg2 = sb.toString();
            } else {
                TextView textView = this.tmessage;
                StringBuilder sb2 = new StringBuilder();
                sb2.append(getResources().getString(R.string.share1));
                sb2.append(str2);
                sb2.append(head);
                sb2.append(str2);
                sb2.append(getResources().getString(R.string.sharer));
                sb2.append(str5);
                sb2.append(this.name2.toUpperCase());
                sb2.append(str4);
                sb2.append(this.result.replaceAll("\n", str4));
                sb2.append(str5);
                sb2.append(getResources().getString(R.string.share2));
                sb2.append(str4);
                sb2.append(str3);
                textView.setText(Html.fromHtml(sb2.toString()));
            }
        } else {
            String str6 = ")<br>";
            String str7 = "(";
            if (type.equals("three")) {
                String[] strArr = this.names2;
                boolean z10 = strArr.length <= 0 || strArr == null;
                if (head.length() <= 0 || head == null) {
                    head = str;
                    z6 = true;
                } else {
                    z6 = false;
                }
                boolean z11 = this.results.length <= 0;
                if (z10 || z6 || z11) {
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(getResources().getString(R.string.share2));
                    sb3.append(str4);
                    sb3.append(str3);
                    this.msg2 = sb3.toString();
                } else if (this.ccb.equals("Birthday Tarot Reading")) {
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append(getResources().getString(R.string.share1));
                    sb4.append(str2);
                    sb4.append(head);
                    sb4.append(str5);
                    sb4.append(this.status[0]);
                    sb4.append(str7);
                    sb4.append(this.names2[0].toUpperCase());
                    sb4.append(str6);
                    sb4.append(this.results[0]);
                    sb4.append(str5);
                    sb4.append(this.status[1]);
                    sb4.append(str7);
                    sb4.append(this.names2[1].toUpperCase());
                    sb4.append(str6);
                    sb4.append(this.results[1]);
                    sb4.append(str5);
                    sb4.append(this.status[2]);
                    sb4.append(str7);
                    sb4.append(this.names2[2].toUpperCase());
                    sb4.append(str6);
                    sb4.append(this.results[2]);
                    sb4.append(str5);
                    sb4.append(getResources().getString(R.string.share2));
                    sb4.append(str4);
                    sb4.append(str3);
                    this.msg2 = sb4.toString();
                } else {
                    TextView textView2 = this.tmessage;
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append(getResources().getString(R.string.share1));
                    sb5.append(str2);
                    sb5.append(head);
                    sb5.append(str2);
                    sb5.append(getResources().getString(R.string.sharer));
                    sb5.append(str5);
                    sb5.append(this.status[0]);
                    sb5.append(str7);
                    sb5.append(this.names2[0].toUpperCase());
                    sb5.append(str6);
                    sb5.append(this.results[0]);
                    sb5.append(str5);
                    sb5.append(this.status[1]);
                    sb5.append(str7);
                    sb5.append(this.names2[1].toUpperCase());
                    sb5.append(str6);
                    sb5.append(this.results[1]);
                    sb5.append(str5);
                    sb5.append(this.status[2]);
                    sb5.append(str7);
                    sb5.append(this.names2[2].toUpperCase());
                    sb5.append(str6);
                    sb5.append(this.results[2]);
                    sb5.append(str5);
                    sb5.append(getResources().getString(R.string.share2));
                    sb5.append(str4);
                    sb5.append(str3);
                    textView2.setText(Html.fromHtml(sb5.toString()));
                }
            } else if (type.equals("four")) {
                String[] strArr2 = this.names2;
                boolean z12 = strArr2.length <= 0 || strArr2 == null;
                if (head.length() <= 0 || head == null) {
                    head = str;
                    z5 = true;
                } else {
                    z5 = false;
                }
                boolean z13 = this.results.length <= 0;
                if (z12 || z5 || z13) {
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append(getResources().getString(R.string.share2));
                    sb6.append(str4);
                    sb6.append(str3);
                    this.msg2 = sb6.toString();
                } else {
                    TextView textView3 = this.tmessage;
                    StringBuilder sb7 = new StringBuilder();
                    sb7.append(getResources().getString(R.string.share1));
                    sb7.append(str2);
                    sb7.append(head);
                    sb7.append(str2);
                    sb7.append(getResources().getString(R.string.sharer));
                    sb7.append(str5);
                    sb7.append(this.status[0]);
                    sb7.append(str7);
                    sb7.append(this.names2[0].toUpperCase());
                    sb7.append(str6);
                    sb7.append(this.results[0]);
                    sb7.append(str5);
                    sb7.append(this.status[1]);
                    sb7.append(str7);
                    sb7.append(this.names2[1].toUpperCase());
                    sb7.append(str6);
                    sb7.append(this.results[1]);
                    sb7.append(str5);
                    sb7.append(this.status[2]);
                    sb7.append(str7);
                    sb7.append(this.names2[2].toUpperCase());
                    sb7.append(str6);
                    sb7.append(this.results[2]);
                    sb7.append(str5);
                    sb7.append(this.status[3]);
                    sb7.append(str7);
                    sb7.append(this.names2[3].toUpperCase());
                    sb7.append(str6);
                    sb7.append(this.results[3]);
                    sb7.append(str5);
                    sb7.append(getResources().getString(R.string.share2));
                    sb7.append(str4);
                    sb7.append(str3);
                    textView3.setText(Html.fromHtml(sb7.toString()));
                }
            } else if (type.equals("ten")) {
                String[] strArr3 = this.names2;
                boolean z14 = strArr3.length <= 0 || strArr3 == null;
                if (head.length() <= 0 || head == null) {
                    head = str;
                    z4 = true;
                } else {
                    z4 = false;
                }
                boolean z15 = this.results.length <= 0;
                if (z14 || z4 || z15) {
                    StringBuilder sb8 = new StringBuilder();
                    sb8.append(getResources().getString(R.string.share2));
                    sb8.append(str4);
                    sb8.append(str3);
                    this.msg2 = sb8.toString();
                } else {
                    TextView textView4 = this.tmessage;
                    StringBuilder sb9 = new StringBuilder();
                    sb9.append(getResources().getString(R.string.share1));
                    sb9.append(str2);
                    sb9.append(head);
                    sb9.append(str2);
                    sb9.append(getResources().getString(R.string.sharer));
                    sb9.append(str5);
                    sb9.append(this.status[0]);
                    sb9.append(str7);
                    sb9.append(this.names2[0].toUpperCase());
                    sb9.append(str6);
                    sb9.append(this.results[0]);
                    sb9.append(str5);
                    sb9.append(this.status[1]);
                    sb9.append(str7);
                    sb9.append(this.names2[1].toUpperCase());
                    sb9.append(str6);
                    sb9.append(this.results[1]);
                    sb9.append(str5);
                    sb9.append(this.status[2]);
                    sb9.append(str7);
                    sb9.append(this.names2[2].toUpperCase());
                    sb9.append(str6);
                    sb9.append(this.results[2]);
                    sb9.append(str5);
                    sb9.append(this.status[3]);
                    sb9.append(str7);
                    sb9.append(this.names2[3].toUpperCase());
                    sb9.append(str6);
                    sb9.append(this.results[3]);
                    sb9.append(str5);
                    sb9.append(this.status[4]);
                    sb9.append(str7);
                    sb9.append(this.names2[4].toUpperCase());
                    sb9.append(str6);
                    sb9.append(this.results[4]);
                    sb9.append(str5);
                    sb9.append(this.status[5]);
                    sb9.append(str7);
                    sb9.append(this.names2[5].toUpperCase());
                    sb9.append(str6);
                    sb9.append(this.results[5]);
                    sb9.append(str5);
                    sb9.append(this.status[6]);
                    sb9.append(str7);
                    sb9.append(this.names2[6].toUpperCase());
                    sb9.append(str6);
                    sb9.append(this.results[6]);
                    sb9.append(str5);
                    sb9.append(this.status[7]);
                    sb9.append(str7);
                    sb9.append(this.names2[7].toUpperCase());
                    sb9.append(str6);
                    sb9.append(this.results[7]);
                    sb9.append(str5);
                    sb9.append(this.status[8]);
                    sb9.append(str7);
                    sb9.append(this.names2[8].toUpperCase());
                    sb9.append(str6);
                    sb9.append(this.results[8]);
                    sb9.append(str5);
                    sb9.append(this.status[9]);
                    sb9.append(str7);
                    sb9.append(this.names2[9].toUpperCase());
                    sb9.append(str6);
                    sb9.append(this.results[9]);
                    sb9.append(str5);
                    sb9.append(getResources().getString(R.string.share2));
                    sb9.append(str4);
                    sb9.append(str3);
                    textView4.setText(Html.fromHtml(sb9.toString()));
                }
            } else if (type.equals("seven")) {
                String[] strArr4 = this.names2;
                boolean z16 = strArr4.length <= 0 || strArr4 == null;
                if (head.length() <= 0 || head == null) {
                    head = str;
                    z3 = true;
                } else {
                    z3 = false;
                }
                boolean z17 = this.results.length <= 0;
                if (z16 || z3 || z17) {
                    StringBuilder sb10 = new StringBuilder();
                    sb10.append(getResources().getString(R.string.share2));
                    sb10.append(str4);
                    sb10.append(str3);
                    this.msg2 = sb10.toString();
                } else {
                    TextView textView5 = this.tmessage;
                    StringBuilder sb11 = new StringBuilder();
                    sb11.append(getResources().getString(R.string.share1));
                    sb11.append(str2);
                    sb11.append(head);
                    sb11.append(str2);
                    sb11.append(getResources().getString(R.string.sharer));
                    sb11.append(str5);
                    sb11.append(this.status[0]);
                    sb11.append(str7);
                    sb11.append(this.names2[0].toUpperCase());
                    sb11.append(str6);
                    sb11.append(this.results[0]);
                    sb11.append(str5);
                    sb11.append(this.status[1]);
                    sb11.append(str7);
                    sb11.append(this.names2[1].toUpperCase());
                    sb11.append(str6);
                    sb11.append(this.results[1]);
                    sb11.append(str5);
                    sb11.append(this.status[2]);
                    sb11.append(str7);
                    sb11.append(this.names2[2].toUpperCase());
                    sb11.append(str6);
                    sb11.append(this.results[2]);
                    sb11.append(str5);
                    sb11.append(this.status[3]);
                    sb11.append(str7);
                    sb11.append(this.names2[3].toUpperCase());
                    sb11.append(str6);
                    sb11.append(this.results[3]);
                    sb11.append(str5);
                    sb11.append(this.status[4]);
                    sb11.append(str7);
                    sb11.append(this.names2[4].toUpperCase());
                    sb11.append(str6);
                    sb11.append(this.results[4]);
                    sb11.append(str5);
                    sb11.append(this.status[5]);
                    sb11.append(str7);
                    sb11.append(this.names2[5].toUpperCase());
                    sb11.append(str6);
                    sb11.append(this.results[5]);
                    sb11.append(str5);
                    sb11.append(this.status[6]);
                    sb11.append(str7);
                    sb11.append(this.names2[6].toUpperCase());
                    sb11.append(str6);
                    sb11.append(this.results[6]);
                    sb11.append(str5);
                    sb11.append(getResources().getString(R.string.share2));
                    sb11.append(str4);
                    sb11.append(str3);
                    textView5.setText(Html.fromHtml(sb11.toString()));
                }
            } else if (this.ccb.equals("Find Love")) {
                String[] strArr5 = this.names2;
                boolean z18 = strArr5.length <= 0 || strArr5 == null;
                if (head.length() <= 0 || head == null) {
                    head = str;
                    z2 = true;
                } else {
                    z2 = false;
                }
                boolean z19 = this.results.length <= 0;
                if (z18 || z2 || z19) {
                    StringBuilder sb12 = new StringBuilder();
                    sb12.append(getResources().getString(R.string.share2));
                    sb12.append(str4);
                    sb12.append(str3);
                    this.msg2 = sb12.toString();
                } else {
                    TextView textView6 = this.tmessage;
                    StringBuilder sb13 = new StringBuilder();
                    sb13.append(getResources().getString(R.string.share1));
                    sb13.append(str2);
                    sb13.append(head);
                    sb13.append(str2);
                    sb13.append(getResources().getString(R.string.sharer));
                    sb13.append(str5);
                    sb13.append(this.status[0]);
                    sb13.append(str7);
                    sb13.append(this.names2[0].toUpperCase());
                    sb13.append(str6);
                    sb13.append(this.results[0]);
                    sb13.append(str5);
                    sb13.append(this.status[1]);
                    sb13.append(str7);
                    sb13.append(this.names2[1].toUpperCase());
                    sb13.append(str6);
                    sb13.append(this.results[1]);
                    sb13.append(str5);
                    sb13.append(this.status[2]);
                    sb13.append(str7);
                    sb13.append(this.names2[2].toUpperCase());
                    sb13.append(str6);
                    sb13.append(this.results[2]);
                    sb13.append(str5);
                    sb13.append(this.status[3]);
                    sb13.append(str7);
                    sb13.append(this.names2[3].toUpperCase());
                    sb13.append(str6);
                    sb13.append(this.results[3]);
                    sb13.append(str5);
                    sb13.append(this.status[4]);
                    sb13.append(str7);
                    sb13.append(this.names2[4].toUpperCase());
                    sb13.append(str6);
                    sb13.append(this.results[4]);
                    sb13.append(str5);
                    sb13.append(getResources().getString(R.string.share2));
                    sb13.append(str4);
                    sb13.append(str3);
                    textView6.setText(Html.fromHtml(sb13.toString()));
                }
            } else {
                String[] strArr6 = this.names2;
                boolean z20 = strArr6.length <= 0 || strArr6 == null;
                if (head.length() <= 0 || head == null) {
                    head = str;
                    z = true;
                } else {
                    z = false;
                }
                boolean z21 = this.results.length <= 0;
                if (z20 || z || z21) {
                    StringBuilder sb14 = new StringBuilder();
                    sb14.append(getResources().getString(R.string.share2));
                    sb14.append(str4);
                    sb14.append(str3);
                    this.msg2 = sb14.toString();
                } else {
                    TextView textView7 = this.tmessage;
                    StringBuilder sb15 = new StringBuilder();
                    sb15.append(getResources().getString(R.string.share1));
                    sb15.append(str2);
                    sb15.append(head);
                    sb15.append(str5);
                    sb15.append(getResources().getString(R.string.sh1));
                    sb15.append(str7);
                    sb15.append(this.names2[0].toUpperCase());
                    sb15.append(str6);
                    sb15.append(this.results[0]);
                    sb15.append(str5);
                    sb15.append(getResources().getString(R.string.sh2));
                    sb15.append(str7);
                    sb15.append(this.names2[1].toUpperCase());
                    sb15.append(str6);
                    sb15.append(this.results[1]);
                    sb15.append(str5);
                    sb15.append(getResources().getString(R.string.sh3));
                    sb15.append(str7);
                    sb15.append(this.names2[2].toUpperCase());
                    sb15.append(str6);
                    sb15.append(this.results[2]);
                    sb15.append(str5);
                    sb15.append(getResources().getString(R.string.sh4));
                    sb15.append(str7);
                    sb15.append(this.names2[3].toUpperCase());
                    sb15.append(str6);
                    sb15.append(this.results[3]);
                    sb15.append(str5);
                    sb15.append(getResources().getString(R.string.sh5));
                    sb15.append(str7);
                    sb15.append(this.names2[4].toUpperCase());
                    sb15.append(str6);
                    sb15.append(this.results[4]);
                    sb15.append(str5);
                    sb15.append(getResources().getString(R.string.share2));
                    sb15.append(str4);
                    sb15.append(str3);
                    textView7.setText(Html.fromHtml(sb15.toString()));
                }
            }
        }
        String str8 = "TaroResult";
        if (this.ccb.equals("Meanings Of All Tarot Cards")) {
            StringBuilder sb16 = new StringBuilder();
            sb16.append("tracker - Share Button Facebook ccb= ");
            sb16.append(this.ccb);
            sb16.append(" - subtype = ");
            sb16.append(this.subtype_eng);
            sb16.append(" - name = ");
            sb16.append(this.name);
            Log.e(str8, sb16.toString());
        } else {
            String str9 = this.cc2;
            if (str9 == null || str9.equals(str)) {
                StringBuilder sb17 = new StringBuilder();
                sb17.append("IF tracker Share Button Facebook ccb= ");
                sb17.append(this.ccb);
                Log.e(str8, sb17.toString());
            } else {
                StringBuilder sb18 = new StringBuilder();
                sb18.append(" - ");
                sb18.append(this.cc2);
                String sb19 = sb18.toString();
                StringBuilder sb20 = new StringBuilder();
                sb20.append("ELSE tracker Share Button Facebook ccb= ");
                sb20.append(this.ccb);
                sb20.append(str);
                sb20.append(sb19);
                Log.e(str8, sb20.toString());
            }
        }
        StringBuilder sb21 = new StringBuilder();
        sb21.append(str);
        sb21.append(stringBuffer.toString());
        Log.e("msg in loc", sb21.toString());
        bundle.putString("facebookMessage", this.tmessage.getText().toString());
        Intent intent = new Intent(this, PublishOnFbActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void onCreate(Bundle bundle) {
        char c;
        int i;
        boolean z;
        String str;
        super.onCreate(bundle);
        this.locale = getResources().getConfiguration().locale.getLanguage();
        Bundle extras = getIntent().getExtras();
        type = extras.getString("type");
        head = extras.getString("ques");
        this.ccb = extras.getString("ccc");
        this.cc2 = extras.getString("ccc2");
        Log.e("TAG", "type" + type);
        if (this.locale.contains("hi")) {

        } else {

        }
        SharedPreferences sharedPreferences = getSharedPreferences("MyPref", 0);
        sharedpreferences = sharedPreferences;
        editor = sharedPreferences.edit();
        if (sharedpreferences.getInt("firstvisit", 0) == 0) {
            editor.putInt("firstvisit", 0);
            editor.commit();
        }
        int i2 = sharedpreferences.getInt("count", 0);
        this.nooftimes_resultviewd = i2;
        editor.putInt("count", i2 + 1);
        editor.commit();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        View inflate = LayoutInflater.from(this).inflate(R.layout.titleview, null);
        this.titleview = inflate.findViewById(R.id.title);
        getSupportActionBar().setCustomView(inflate);
        this.titleview.setTextColor(getResources().getColor(R.color.white));
        TextView textView = this.titleview;
        StringBuilder sb = new StringBuilder();
        String str2 = "";
        sb.append(str2);
        sb.append(head);
        textView.setText(sb.toString());
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.sw = displayMetrics.widthPixels;
        this.sh = displayMetrics.heightPixels;
        String str3 = "one";
        String str4 = "boolean true";
        String str5 = "boolean false";
        String str6 = ".xml";
        String str7 = "/";
        String str8 = "-";
        String str9 = "XML";
        String str10 = " ";
        if (type.equals(str3)) {
            setContentView(R.layout.result);
            this.email = findViewById(R.id.email);
            this.facebook = findViewById(R.id.facebook);
            this.email.setOnClickListener(this.listenemail);
            this.facebook.setOnClickListener(this.faceshare);
            this.moreappstxt = findViewById(R.id.moreappstxt);
            RelativeLayout relativeLayout = findViewById(R.id.moreapps);
            this.moreapps = relativeLayout;
            relativeLayout.setVisibility(View.GONE);

            this.name = extras.getString("name");
            this.name2 = extras.getString("name2");
            StringBuilder sb2 = new StringBuilder();
            sb2.append("trac TYPE + ONE  name = ");
            sb2.append(this.name);
            sb2.append(" name2 = ");
            sb2.append(this.name2);
            Log.e("TaroResult", sb2.toString());
            if (this.name.contains("I")) {
                str = this.name.replace("I", "i");
            } else {
                str = this.name;
            }
            this.resid = getResources().getIdentifier(str.toLowerCase().replaceAll(str10, str2).replaceAll(str8, str2), "drawable", getPackageName());
            this.thead = findViewById(R.id.header);
            TextView textView2 = findViewById(R.id.cardname);
            this.tcardname = textView2;
            textView2.setText(this.name2.toUpperCase());
            this.trestext = findViewById(R.id.restext);
            this.thead0 = findViewById(R.id.header00);
            if (this.locale.contains("hi")) {
                TextView textView3 = this.thead;
                StringBuilder sb3 = new StringBuilder();
                sb3.append(head);
                sb3.append(str10);
                sb3.append(getResources().getString(R.string.f_head));
                textView3.setText(sb3.toString());
            } else {
                TextView textView4 = this.thead;
                StringBuilder sb4 = new StringBuilder();
                sb4.append(getResources().getString(R.string.f_head));
                sb4.append(str10);
                sb4.append(head);
                textView4.setText(sb4.toString());
            }
            if (!this.locale.contains("vi")) {

            }
            if (!this.locale.contains("vi")) {

            }
            ImageView imageView = findViewById(R.id.card);
            imageView.setImageResource(this.resid);
            BitmapDrawable bitmapDrawable = (BitmapDrawable) imageView.getDrawable();
            this.draw = bitmapDrawable;
            try {
                this.bm = bitmapDrawable.getBitmap();
            } catch (Exception unused) {
                unused.printStackTrace();
            }
            this.arrlen = 1;
            if (this.ccb.equals("Daily Tarot Horoscope")) {
                this.thead.setText(head);
                int nextInt = new Random().nextInt(30) + 1;
                int nextInt2 = new Random().nextInt(30) + 1;
                int nextInt3 = new Random().nextInt(30) + 1;
                int nextInt4 = new Random().nextInt(30) + 1;
                int nextInt5 = new Random().nextInt(30) + 1;
                String str11 = str5;
                String str12 = str9;
                String[] strArr = {getResources().getString(R.string.statusDTC1), getResources().getString(R.string.statusDTC2), getResources().getString(R.string.statusDTC3), getResources().getString(R.string.statusDTC4), getResources().getString(R.string.statusDTC5)};
                StringBuilder sb5 = new StringBuilder();
                sb5.append("-GENERAL");
                sb5.append(nextInt);
                this.dcn1 = sb5.toString();
                StringBuilder sb6 = new StringBuilder();
                sb6.append("-LOVE-AND-DATING");
                sb6.append(nextInt2);
                this.dcn2 = sb6.toString();
                StringBuilder sb7 = new StringBuilder();
                sb7.append("-MONEY");
                sb7.append(nextInt3);
                this.dcn3 = sb7.toString();
                StringBuilder sb8 = new StringBuilder();
                sb8.append("-WORK-AND-CAREER");
                sb8.append(nextInt4);
                this.dcn4 = sb8.toString();
                StringBuilder sb9 = new StringBuilder();
                sb9.append("-FAMILY-AND-FRIENDS");
                sb9.append(nextInt5);
                this.dcn5 = sb9.toString();
                String[] strArr2 = {this.name.toUpperCase().replace(str10, str8)};
                StringBuilder sb10 = new StringBuilder();
                sb10.append(getResources().getString(R.string.fetchingfile));
                sb10.append(this.ccb);
                sb10.append(str7);
                sb10.append(this.ccb.replace(str10, str2));
                sb10.append(str6);
                if (resultString(sb10.toString(), strArr2, str3)) {
                    StringBuilder sb11 = new StringBuilder();
                    sb11.append(strArr[0]);
                    sb11.append("\n");
                    sb11.append(this.results[0]);
                    sb11.append("\n\n");
                    sb11.append(strArr[1]);
                    sb11.append("\n");
                    sb11.append(this.results[1]);
                    sb11.append("\n\n");
                    sb11.append(strArr[2]);
                    sb11.append("\n");
                    sb11.append(this.results[2]);
                    sb11.append("\n\n");
                    sb11.append(strArr[3]);
                    sb11.append("\n");
                    sb11.append(this.results[3]);
                    sb11.append("\n\n");
                    sb11.append(strArr[4]);
                    sb11.append("\n");
                    sb11.append(this.results[4]);
                    this.result = sb11.toString();
                    Log.e(str12, str4);
                } else {
                    Log.e(str12, str11);
                }
            } else {
                String str13 = str5;
                String str14 = "-ONE";
                if (this.ccb.equals("Meanings Of All Tarot Cards")) {
                    this.subtype = extras.getString("subtype");
                    this.subtype_eng = extras.getString("subtype_eng");
                    StringBuilder sb12 = new StringBuilder();
                    sb12.append("subtype = ");
                    sb12.append(this.subtype);
                    Log.e("SUBTYPE", sb12.toString());
                    TextView textView5 = this.thead;
                    StringBuilder sb13 = new StringBuilder();
                    sb13.append(getResources().getString(R.string.tcmeaning));
                    sb13.append(str10);
                    sb13.append(this.subtype);
                    textView5.setText(sb13.toString());
                    StringBuilder sb14 = new StringBuilder();
                    sb14.append(this.name.toUpperCase().replace(str10, str8));
                    sb14.append(str14);
                    String[] strArr3 = {sb14.toString()};
                    StringBuilder sb15 = new StringBuilder();
                    sb15.append(getResources().getString(R.string.fetchingfile));
                    sb15.append(this.ccb);
                    sb15.append(str7);
                    sb15.append(this.ccb.replace(str10, str2));
                    sb15.append(str6);
                    if (resultString(sb15.toString(), strArr3, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Yes or No")) {
                    StringBuilder sb16 = new StringBuilder();
                    sb16.append(this.name.toUpperCase().replace(str10, str8));
                    sb16.append(str14);
                    String[] strArr4 = {sb16.toString()};
                    StringBuilder sb17 = new StringBuilder();
                    sb17.append(getResources().getString(R.string.fetchingfile));
                    sb17.append(this.ccb);
                    sb17.append(str7);
                    sb17.append(this.ccb.replace(str10, str2));
                    sb17.append(str6);
                    if (resultString(sb17.toString(), strArr4, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Life")) {
                    StringBuilder sb18 = new StringBuilder();
                    sb18.append(this.name.toUpperCase().replace(str10, str8));
                    sb18.append(str14);
                    String[] strArr5 = {sb18.toString()};
                    StringBuilder sb19 = new StringBuilder();
                    sb19.append(getResources().getString(R.string.fetchingfile));
                    sb19.append(this.ccb);
                    sb19.append(str7);
                    sb19.append(this.ccb.replace(str10, str2));
                    sb19.append(str6);
                    if (resultString(sb19.toString(), strArr5, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Family & Friends")) {
                    StringBuilder sb20 = new StringBuilder();
                    sb20.append(this.name.toUpperCase().replace(str10, str8));
                    sb20.append(str14);
                    String[] strArr6 = {sb20.toString()};
                    StringBuilder sb21 = new StringBuilder();
                    sb21.append(getResources().getString(R.string.fetchingfile));
                    sb21.append(this.ccb);
                    sb21.append(str7);
                    sb21.append(this.ccb.replace(str10, str2));
                    sb21.append(str6);
                    if (resultString(sb21.toString(), strArr6, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Money")) {
                    StringBuilder sb22 = new StringBuilder();
                    sb22.append(this.name.toUpperCase().replace(str10, str8));
                    sb22.append(str14);
                    String[] strArr7 = {sb22.toString()};
                    StringBuilder sb23 = new StringBuilder();
                    sb23.append(getResources().getString(R.string.fetchingfile));
                    sb23.append(this.ccb);
                    sb23.append(str7);
                    sb23.append(this.ccb.replace(str10, str2));
                    sb23.append(str6);
                    if (resultString(sb23.toString(), strArr7, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Love & Relationships")) {
                    StringBuilder sb24 = new StringBuilder();
                    sb24.append(this.name.toUpperCase().replace(str10, str8));
                    sb24.append(str14);
                    String[] strArr8 = {sb24.toString()};
                    StringBuilder sb25 = new StringBuilder();
                    sb25.append(getResources().getString(R.string.fetchingfile));
                    sb25.append(this.ccb);
                    sb25.append(str7);
                    sb25.append(this.ccb.replace(str10, str2));
                    sb25.append(str6);
                    if (resultString(sb25.toString(), strArr8, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Health")) {
                    StringBuilder sb26 = new StringBuilder();
                    sb26.append(this.name.toUpperCase().replace(str10, str8));
                    sb26.append(str14);
                    String[] strArr9 = {sb26.toString()};
                    StringBuilder sb27 = new StringBuilder();
                    sb27.append(getResources().getString(R.string.fetchingfile));
                    sb27.append(this.ccb);
                    sb27.append(str7);
                    sb27.append(this.ccb.replace(str10, str2));
                    sb27.append(str6);
                    if (resultString(sb27.toString(), strArr9, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Dreams & Ambitions")) {
                    StringBuilder sb28 = new StringBuilder();
                    sb28.append(this.name.toUpperCase().replace(str10, str8));
                    sb28.append(str14);
                    String[] strArr10 = {sb28.toString()};
                    StringBuilder sb29 = new StringBuilder();
                    sb29.append(getResources().getString(R.string.fetchingfile));
                    sb29.append(this.ccb);
                    sb29.append(str7);
                    sb29.append(this.ccb.replace(str10, str2));
                    sb29.append(str6);
                    if (resultString(sb29.toString(), strArr10, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Travel")) {
                    StringBuilder sb30 = new StringBuilder();
                    sb30.append(this.name.toUpperCase().replace(str10, str8));
                    sb30.append(str14);
                    String[] strArr11 = {sb30.toString()};
                    StringBuilder sb31 = new StringBuilder();
                    sb31.append(getResources().getString(R.string.fetchingfile));
                    sb31.append(this.ccb);
                    sb31.append(str7);
                    sb31.append(this.ccb.replace(str10, str2));
                    sb31.append(str6);
                    if (resultString(sb31.toString(), strArr11, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Work & Career")) {
                    StringBuilder sb32 = new StringBuilder();
                    sb32.append(this.name.toUpperCase().replace(str10, str8));
                    sb32.append(str14);
                    String[] strArr12 = {sb32.toString()};
                    StringBuilder sb33 = new StringBuilder();
                    sb33.append(getResources().getString(R.string.fetchingfile));
                    sb33.append(this.ccb);
                    sb33.append(str7);
                    sb33.append(this.ccb.replace(str10, str2));
                    sb33.append(str6);
                    if (resultString(sb33.toString(), strArr12, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Focus")) {
                    StringBuilder sb34 = new StringBuilder();
                    sb34.append(this.name.toUpperCase().replace(str10, str8));
                    sb34.append(str14);
                    String[] strArr13 = {sb34.toString()};
                    StringBuilder sb35 = new StringBuilder();
                    sb35.append(getResources().getString(R.string.fetchingfile));
                    sb35.append(this.ccb);
                    sb35.append(str7);
                    sb35.append(this.ccb.replace(str10, str2));
                    sb35.append(str6);
                    if (resultString(sb35.toString(), strArr13, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Success")) {
                    StringBuilder sb36 = new StringBuilder();
                    sb36.append(this.name.toUpperCase().replace(str10, str8));
                    sb36.append(str14);
                    String[] strArr14 = {sb36.toString()};
                    StringBuilder sb37 = new StringBuilder();
                    sb37.append("file = ");
                    sb37.append(getResources().getString(R.string.fetchingfile));
                    sb37.append(this.ccb);
                    sb37.append(str7);
                    sb37.append(this.ccb.replace(str10, str2));
                    sb37.append(str6);
                    Log.e(str2, sb37.toString());
                    StringBuilder sb38 = new StringBuilder();
                    sb38.append(getResources().getString(R.string.fetchingfile));
                    sb38.append(this.ccb);
                    sb38.append(str7);
                    sb38.append(this.ccb.replace(str10, str2));
                    sb38.append(str6);
                    if (resultString(sb38.toString(), strArr14, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Luck")) {
                    StringBuilder sb39 = new StringBuilder();
                    sb39.append(this.name.toUpperCase().replace(str10, str8));
                    sb39.append(str14);
                    String[] strArr15 = {sb39.toString()};
                    StringBuilder sb40 = new StringBuilder();
                    sb40.append(getResources().getString(R.string.fetchingfile));
                    sb40.append(this.ccb);
                    sb40.append(str7);
                    sb40.append(this.ccb.replace(str10, str2));
                    sb40.append(str6);
                    if (resultString(sb40.toString(), strArr15, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Marriage")) {
                    StringBuilder sb41 = new StringBuilder();
                    sb41.append(this.name.toUpperCase().replace(str10, str8));
                    sb41.append(str14);
                    String[] strArr16 = {sb41.toString()};
                    StringBuilder sb42 = new StringBuilder();
                    sb42.append(getResources().getString(R.string.fetchingfile));
                    sb42.append(this.ccb);
                    sb42.append(str7);
                    sb42.append(this.ccb.replace(str10, str2));
                    sb42.append(str6);
                    if (resultString(sb42.toString(), strArr16, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Change & Transformation")) {
                    String[] strArr17 = {this.name.toUpperCase().replace(str10, str8)};
                    StringBuilder sb43 = new StringBuilder();
                    sb43.append(getResources().getString(R.string.fetchingfile));
                    sb43.append(this.ccb);
                    sb43.append(str7);
                    sb43.append(this.ccb.replace(str10, str2));
                    sb43.append(str6);
                    if (resultString(sb43.toString(), strArr17, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Destiny & Life Purpose")) {
                    String[] strArr18 = {this.name.toUpperCase().replace(str10, str8)};
                    StringBuilder sb44 = new StringBuilder();
                    sb44.append(getResources().getString(R.string.fetchingfile));
                    sb44.append(this.ccb);
                    sb44.append(str7);
                    sb44.append(this.ccb.replace(str10, str2));
                    sb44.append(str6);
                    if (resultString(sb44.toString(), strArr18, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Opportunities & Obstacles")) {
                    String[] strArr19 = {this.name.toUpperCase().replace(str10, str8)};
                    StringBuilder sb45 = new StringBuilder();
                    sb45.append(getResources().getString(R.string.fetchingfile));
                    sb45.append(this.ccb);
                    sb45.append(str7);
                    sb45.append(this.ccb.replace(str10, str2));
                    sb45.append(str6);
                    if (resultString(sb45.toString(), strArr19, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Emotional And Mental State")) {
                    StringBuilder sb46 = new StringBuilder();
                    sb46.append(this.name.toUpperCase().replace(str10, str8));
                    sb46.append(str14);
                    String[] strArr20 = {sb46.toString()};
                    StringBuilder sb47 = new StringBuilder();
                    sb47.append(getResources().getString(R.string.fetchingfile));
                    sb47.append(this.ccb);
                    sb47.append(str7);
                    sb47.append(this.ccb.replace(str10, str2));
                    sb47.append(str6);
                    if (resultString(sb47.toString(), strArr20, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Immediate Question On your Mind")) {
                    TextView textView6 = this.thead;
                    StringBuilder sb48 = new StringBuilder();
                    sb48.append(getResources().getString(R.string.f_head2));
                    sb48.append(str10);
                    sb48.append(head);
                    textView6.setText(sb48.toString());
                    StringBuilder sb49 = new StringBuilder();
                    sb49.append(this.name.toUpperCase().replace(str10, str8));
                    sb49.append(str14);
                    String[] strArr21 = {sb49.toString()};
                    StringBuilder sb50 = new StringBuilder();
                    sb50.append(getResources().getString(R.string.fetchingfile));
                    sb50.append(this.ccb);
                    sb50.append(str7);
                    sb50.append(this.ccb.replace(str10, str2));
                    sb50.append(str6);
                    if (resultString(sb50.toString(), strArr21, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                } else if (this.ccb.equals("Will Your Wish Be Fulfilled?")) {
                    TextView textView7 = this.thead;
                    StringBuilder sb51 = new StringBuilder();
                    sb51.append(getResources().getString(R.string.f_head2));
                    sb51.append(str10);
                    sb51.append(head);
                    textView7.setText(sb51.toString());
                    StringBuilder sb52 = new StringBuilder();
                    sb52.append(this.name.toUpperCase().replace(str10, str8));
                    sb52.append(str14);
                    String[] strArr22 = {sb52.toString()};
                    StringBuilder sb53 = new StringBuilder();
                    sb53.append(getResources().getString(R.string.fetchingfile));
                    sb53.append("Will Your Wish Be Fulfilled/WillYourWishBeFulfilled.xml");
                    if (resultString(sb53.toString(), strArr22, str3)) {
                        this.result = this.results[0];
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str13);
                    }
                }
            }
            this.thead0.append(this.name2.toUpperCase());
            this.trestext.setText(this.result);
            this.trestext.setMovementMethod(new ScrollingMovementMethod());
            this.trestext.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    return false;
                }
            });
        } else {
            String str15 = str5;
            if (type.equals("three")) {
                setContentView(R.layout.three_result);
                TextView textView8 = this.titleview;
                StringBuilder sb54 = new StringBuilder();
                sb54.append(str2);
                sb54.append(head);
                textView8.setText(sb54.toString());
                this.email = findViewById(R.id.email);
                this.facebook = findViewById(R.id.facebook);
                this.moreappstxt = findViewById(R.id.moreappstxt);
                RelativeLayout relativeLayout2 = findViewById(R.id.moreapps);
                this.moreapps = relativeLayout2;
                relativeLayout2.setVisibility(View.GONE);
                this.email.setOnClickListener(this.listenemail);
                this.facebook.setOnClickListener(this.faceshare);
                this.dia = 1;
                this.names = extras.getStringArray("name");
                this.names2 = extras.getStringArray("name2");
                for (int i3 = 0; i3 < 3; i3++) {
                    this.resids[i3] = getResources().getIdentifier(this.names[i3].toLowerCase().replaceAll(str10, str2).replaceAll(str8, str2), "drawable", getPackageName());
                }
                this.thead = findViewById(R.id.header);
                this.trestext = findViewById(R.id.restext);
                this.trestext2 = findViewById(R.id.restext2);
                TextView textView9 = findViewById(R.id.restext3);
                this.trestext3 = textView9;
                TextView[] textViewArr = {this.trestext, this.trestext2, textView9};
                if (this.ccb.equals("Birthday Tarot Reading")) {
                    TextView textView10 = this.thead;
                    StringBuilder sb55 = new StringBuilder();
                    sb55.append(getResources().getString(R.string.f_head3));
                    sb55.append(str10);
                    sb55.append(head);
                    textView10.setText(sb55.toString());
                } else {
                    TextView textView11 = this.thead;
                    StringBuilder sb56 = new StringBuilder();
                    sb56.append(getResources().getString(R.string.f_head5));
                    sb56.append(str10);
                    sb56.append(head);
                    textView11.setText(sb56.toString());
                }
                ImageView imageView2 = findViewById(R.id.card1);
                this.card1 = imageView2;
                imageView2.setImageResource(this.resids[0]);
                ImageView imageView3 = findViewById(R.id.card2);
                this.card2 = imageView3;
                imageView3.setImageResource(this.resids[1]);
                ImageView imageView4 = findViewById(R.id.card3);
                this.card3 = imageView4;
                imageView4.setImageResource(this.resids[2]);
                if (this.ccb.equals("Past Life")) {
                    this.status = new String[]{getResources().getString(R.string.statusPL1), getResources().getString(R.string.statusPL2), getResources().getString(R.string.statusPL3)};
                } else if (this.ccb.equals("Birthday Tarot Reading")) {
                    this.status = new String[]{getResources().getString(R.string.statusBTR1), getResources().getString(R.string.statusBTR2), getResources().getString(R.string.statusBTR3)};
                } else {
                    this.status = new String[]{getResources().getString(R.string.statusTC1), getResources().getString(R.string.statusTC2), getResources().getString(R.string.statusTC3)};
                }
                StringBuilder sb57 = new StringBuilder();
                sb57.append(getResources().getString(R.string.fetchingfile));
                sb57.append(this.ccb);
                sb57.append(str7);
                sb57.append(this.ccb.replace(str10, str2));
                sb57.append(str6);
                if (resultString(sb57.toString(), this.names, "three")) {
                    for (int i4 = 0; i4 < 3; i4++) {
                        TextView textView12 = textViewArr[i4];
                        StringBuilder sb58 = new StringBuilder();
                        sb58.append(this.names2[i4]);
                        sb58.append("\n(");
                        sb58.append(this.status[i4]);
                        sb58.append(")\n");
                        sb58.append(this.results[i4]);
                        textView12.setText(sb58.toString());
                    }
                    Log.e(str9, str4);
                } else {
                    Log.e(str9, str15);
                }
                textViewArr[0].setOnTouchListener(new View.OnTouchListener() {
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        return false;
                    }
                });
            } else if (type.equals("four")) {
                setContentView(R.layout.five_result);
                TextView textView13 = this.titleview;
                StringBuilder sb59 = new StringBuilder();
                sb59.append(str2);
                sb59.append(head);
                textView13.setText(sb59.toString());
                this.email = findViewById(R.id.email);
                this.facebook = findViewById(R.id.facebook);
                this.moreappstxt = findViewById(R.id.moreappstxt);
                RelativeLayout relativeLayout3 = findViewById(R.id.moreapps);
                this.moreapps = relativeLayout3;
                relativeLayout3.setVisibility(View.GONE);
                this.email.setOnClickListener(this.listenemail);
                this.facebook.setOnClickListener(this.faceshare);
                this.dia = 2;
                this.names = extras.getStringArray("name");
                this.names2 = extras.getStringArray("name2");
                this.thead = findViewById(R.id.header);
                this.trestext = findViewById(R.id.restext);
                this.trestext2 = findViewById(R.id.restext2);
                this.trestext3 = findViewById(R.id.restext3);
                this.trestext4 = findViewById(R.id.restext4);
                this.trestext5 = findViewById(R.id.restext5);
                for (int i5 = 0; i5 < 4; i5++) {
                    this.resids[i5] = getResources().getIdentifier(this.names[i5].toLowerCase().replaceAll(str10, str2).replaceAll(str8, str2), "drawable", getPackageName());
                }
                if (this.ccb.equals("Decision Making")) {
                    TextView textView14 = this.thead;
                    StringBuilder sb60 = new StringBuilder();
                    sb60.append(head);
                    sb60.append(str10);
                    sb60.append(getResources().getString(R.string.sharer));
                    textView14.setText(sb60.toString());
                    StringBuilder sb61 = new StringBuilder();
                    sb61.append(getResources().getString(R.string.fetchingfile));
                    sb61.append(this.ccb);
                    sb61.append("/DecisionMaking.xml");
                    z = resultString(sb61.toString(), this.names, "four");
                    this.status = new String[]{getResources().getString(R.string.statusDM1), getResources().getString(R.string.statusDM2), getResources().getString(R.string.statusDM3), getResources().getString(R.string.statusDM4)};
                } else if (this.ccb.equals("Relationship Potential")) {
                    TextView textView15 = this.thead;
                    StringBuilder sb62 = new StringBuilder();
                    sb62.append(head);
                    sb62.append(str10);
                    sb62.append(getResources().getString(R.string.sharer));
                    textView15.setText(sb62.toString());
                    StringBuilder sb63 = new StringBuilder();
                    sb63.append(getResources().getString(R.string.fetchingfile));
                    sb63.append(this.ccb);
                    sb63.append("/RelationshipPotential.xml");
                    z = resultString(sb63.toString(), this.names, "four");
                    this.status = new String[]{getResources().getString(R.string.statusR1), getResources().getString(R.string.statusR2), getResources().getString(R.string.statusR3), getResources().getString(R.string.statusR4)};
                } else {
                    TextView textView16 = this.thead;
                    StringBuilder sb64 = new StringBuilder();
                    sb64.append(getResources().getString(R.string.f_head4));
                    sb64.append(str10);
                    sb64.append(head);
                    textView16.setText(sb64.toString());
                    StringBuilder sb65 = new StringBuilder();
                    sb65.append(getResources().getString(R.string.fetchingfile));
                    sb65.append(this.ccb);
                    sb65.append("/CompleteRelationshipAnalysis.xml");
                    z = resultString(sb65.toString(), this.names, "four");
                    c = 3;
                    this.status = new String[]{getResources().getString(R.string.statusFC1), getResources().getString(R.string.statusFC2), getResources().getString(R.string.statusFC3), getResources().getString(R.string.statusFC4)};
                    i = 4;
                    TextView[] textViewArr2 = new TextView[i];
                    TextView textView17 = this.trestext;
                    textViewArr2[0] = textView17;
                    textViewArr2[1] = this.trestext2;
                    textViewArr2[2] = this.trestext3;
                    textViewArr2[c] = this.trestext4;
                    ImageView imageView5 = findViewById(R.id.card1);
                    this.card1 = imageView5;
                    imageView5.setImageResource(this.resids[0]);
                    ImageView imageView6 = findViewById(R.id.card2);
                    this.card2 = imageView6;
                    imageView6.setImageResource(this.resids[1]);
                    ImageView imageView7 = findViewById(R.id.card3);
                    this.card3 = imageView7;
                    imageView7.setImageResource(this.resids[2]);
                    ImageView imageView8 = findViewById(R.id.card4);
                    this.card4 = imageView8;
                    imageView8.setImageResource(this.resids[3]);
                    ImageView imageView9 = findViewById(R.id.card5);
                    this.card5 = imageView9;
                    imageView9.setVisibility(View.INVISIBLE);
                    this.trestext5.setVisibility(View.INVISIBLE);
                    if (!z) {
                        int i6 = 0;
                        for (int i7 = 4; i6 < i7; i7 = 4) {
                            TextView textView18 = textViewArr2[i6];
                            StringBuilder sb66 = new StringBuilder();
                            sb66.append(this.names2[i6]);
                            sb66.append("\n(");
                            sb66.append(this.status[i6]);
                            sb66.append(")\n");
                            sb66.append(this.results[i6]);
                            textView18.setText(sb66.toString());
                            i6++;
                        }
                        Log.e(str9, str4);
                    } else {
                        Log.e(str9, str15);
                    }
                    textViewArr2[0].setOnTouchListener(new View.OnTouchListener() {
                        public boolean onTouch(View view, MotionEvent motionEvent) {
                            return false;
                        }
                    });
                }
                i = 4;
                c = 3;
                TextView[] textViewArr22 = new TextView[i];
                TextView textView172 = this.trestext;
                textViewArr22[0] = textView172;
                textViewArr22[1] = this.trestext2;
                textViewArr22[2] = this.trestext3;
                textViewArr22[c] = this.trestext4;
                ImageView imageView52 = findViewById(R.id.card1);
                this.card1 = imageView52;
                imageView52.setImageResource(this.resids[0]);
                ImageView imageView62 = findViewById(R.id.card2);
                this.card2 = imageView62;
                imageView62.setImageResource(this.resids[1]);
                ImageView imageView72 = findViewById(R.id.card3);
                this.card3 = imageView72;
                imageView72.setImageResource(this.resids[2]);
                ImageView imageView82 = findViewById(R.id.card4);
                this.card4 = imageView82;
                imageView82.setImageResource(this.resids[3]);
                ImageView imageView92 = findViewById(R.id.card5);
                this.card5 = imageView92;
                imageView92.setVisibility(View.INVISIBLE);
                this.trestext5.setVisibility(View.INVISIBLE);
                if (!z) {
                }
                textViewArr22[0].setOnTouchListener(new View.OnTouchListener() {
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        return false;
                    }
                });
            } else if (type.equals("ten")) {
                setContentView(R.layout.ten_result);
                TextView textView19 = this.titleview;
                StringBuilder sb67 = new StringBuilder();
                sb67.append(str2);
                sb67.append(head);
                textView19.setText(sb67.toString());
                this.email = findViewById(R.id.email);
                this.facebook = findViewById(R.id.facebook);
                this.moreappstxt = findViewById(R.id.moreappstxt);
                RelativeLayout relativeLayout4 = findViewById(R.id.moreapps);
                this.moreapps = relativeLayout4;
                relativeLayout4.setVisibility(View.GONE);
                this.email.setOnClickListener(this.listenemail);
                this.facebook.setOnClickListener(this.faceshare);
                this.dia = 2;
                this.names = extras.getStringArray("name");
                this.names2 = extras.getStringArray("name2");
                for (int i8 = 0; i8 < 10; i8++) {
                    StringBuilder sb68 = new StringBuilder();
                    sb68.append(str2);
                    sb68.append(this.names[i8].toLowerCase().replaceAll(str10, str2).replaceAll(str8, str2));
                    Log.e("IMAGE", sb68.toString());
                    this.resids[i8] = getResources().getIdentifier(this.names[i8].toLowerCase().replaceAll(str10, str2).replaceAll(str8, str2), "drawable", getPackageName());
                }
                this.thead = findViewById(R.id.header);
                this.trestext = findViewById(R.id.restext);
                this.trestext2 = findViewById(R.id.restext2);
                this.trestext3 = findViewById(R.id.restext3);
                this.trestext4 = findViewById(R.id.restext4);
                this.trestext5 = findViewById(R.id.restext5);
                this.trestext6 = findViewById(R.id.restext6);
                this.trestext7 = findViewById(R.id.restext7);
                this.trestext8 = findViewById(R.id.restext8);
                this.trestext9 = findViewById(R.id.restext9);
                TextView textView20 = findViewById(R.id.restext10);
                this.trestext10 = textView20;
                TextView textView21 = this.trestext;
                TextView[] textViewArr3 = {textView21, this.trestext2, this.trestext3, this.trestext4, this.trestext5, this.trestext6, this.trestext7, this.trestext8, this.trestext9, textView20};
                ImageView imageView10 = findViewById(R.id.card1);
                this.card1 = imageView10;
                imageView10.setImageResource(this.resids[0]);
                ImageView imageView11 = findViewById(R.id.card2);
                this.card2 = imageView11;
                imageView11.setImageResource(this.resids[1]);
                ImageView imageView12 = findViewById(R.id.card3);
                this.card3 = imageView12;
                imageView12.setImageResource(this.resids[2]);
                ImageView imageView13 = findViewById(R.id.card4);
                this.card4 = imageView13;
                imageView13.setImageResource(this.resids[3]);
                ImageView imageView14 = findViewById(R.id.card5);
                this.card5 = imageView14;
                imageView14.setImageResource(this.resids[4]);
                ImageView imageView15 = findViewById(R.id.card6);
                this.card6 = imageView15;
                imageView15.setImageResource(this.resids[5]);
                ImageView imageView16 = findViewById(R.id.card7);
                this.card7 = imageView16;
                imageView16.setImageResource(this.resids[6]);
                ImageView imageView17 = findViewById(R.id.card8);
                this.card8 = imageView17;
                imageView17.setImageResource(this.resids[7]);
                ImageView imageView18 = findViewById(R.id.card9);
                this.card9 = imageView18;
                imageView18.setImageResource(this.resids[8]);
                ImageView imageView19 = findViewById(R.id.card10);
                this.card10 = imageView19;
                imageView19.setImageResource(this.resids[9]);
                if (this.ccb.equals("Tree Of Life")) {
                    TextView textView22 = this.thead;
                    StringBuilder sb69 = new StringBuilder();
                    sb69.append(head);
                    sb69.append(str10);
                    sb69.append(getResources().getString(R.string.sharer));
                    textView22.setText(sb69.toString());
                    this.status = new String[]{getResources().getString(R.string.statusTOL1), getResources().getString(R.string.statusTOL2), getResources().getString(R.string.statusTOL3), getResources().getString(R.string.statusTOL4), getResources().getString(R.string.statusTOL5), getResources().getString(R.string.statusTOL6), getResources().getString(R.string.statusTOL7), getResources().getString(R.string.statusTOL8), getResources().getString(R.string.statusTOL9), getResources().getString(R.string.statusTOL10)};
                } else {
                    TextView textView23 = this.thead;
                    StringBuilder sb70 = new StringBuilder();
                    sb70.append(getResources().getString(R.string.f_head3));
                    sb70.append(str10);
                    sb70.append(head);
                    sb70.append(str10);
                    sb70.append(getResources().getString(R.string.sharer));
                    textView23.setText(sb70.toString());
                    this.status = new String[]{getResources().getString(R.string.statusCC1), getResources().getString(R.string.statusCC2), getResources().getString(R.string.statusCC3), getResources().getString(R.string.statusCC4), getResources().getString(R.string.statusCC5), getResources().getString(R.string.statusCC6), getResources().getString(R.string.statusCC7), getResources().getString(R.string.statusCC8), getResources().getString(R.string.statusCC9), getResources().getString(R.string.statusCC10)};
                }
                StringBuilder sb71 = new StringBuilder();
                sb71.append(getResources().getString(R.string.fetchingfile));
                sb71.append(this.ccb);
                sb71.append(str7);
                sb71.append(this.ccb.replace(str10, str2));
                sb71.append(str6);
                if (resultString(sb71.toString(), this.names, "ten")) {
                    for (int i9 = 0; i9 < 10; i9++) {
                        TextView textView24 = textViewArr3[i9];
                        StringBuilder sb72 = new StringBuilder();
                        sb72.append(this.names2[i9]);
                        sb72.append("\n(");
                        sb72.append(this.status[i9]);
                        sb72.append(")\n");
                        sb72.append(this.results[i9]);
                        textView24.setText(sb72.toString());
                    }
                    Log.e(str9, str4);
                } else {
                    Log.e(str9, str15);
                }
                textViewArr3[0].setOnTouchListener(new View.OnTouchListener() {
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        return false;
                    }
                });
            } else if (type.equals("seven")) {
                setContentView(R.layout.seven_result);
                this.moreappstxt = findViewById(R.id.moreappstxt);
                RelativeLayout relativeLayout5 = findViewById(R.id.moreapps);
                this.moreapps = relativeLayout5;
                relativeLayout5.setVisibility(View.GONE);
                TextView textView25 = this.titleview;
                StringBuilder sb73 = new StringBuilder();
                sb73.append(str2);
                sb73.append(head);
                textView25.setText(sb73.toString());
                this.email = findViewById(R.id.email);
                this.facebook = findViewById(R.id.facebook);
                this.email.setOnClickListener(this.listenemail);
                this.facebook.setOnClickListener(this.faceshare);
                this.dia = 2;
                this.names = extras.getStringArray("name");
                this.names2 = extras.getStringArray("name2");
                for (int i10 = 0; i10 < 7; i10++) {
                    StringBuilder sb74 = new StringBuilder();
                    sb74.append(str2);
                    sb74.append(this.names[i10].toLowerCase().replaceAll(str10, str2).replaceAll(str8, str2));
                    Log.e("IMAGE", sb74.toString());
                    this.resids[i10] = getResources().getIdentifier(this.names[i10].toLowerCase().replaceAll(str10, str2).replaceAll(str8, str2), "drawable", getPackageName());
                }
                this.thead = findViewById(R.id.header);
                this.trestext = findViewById(R.id.restext);
                this.trestext2 = findViewById(R.id.restext2);
                this.trestext3 = findViewById(R.id.restext3);
                this.trestext4 = findViewById(R.id.restext4);
                this.trestext5 = findViewById(R.id.restext5);
                this.trestext6 = findViewById(R.id.restext6);
                TextView textView26 = findViewById(R.id.restext7);
                this.trestext7 = textView26;
                TextView textView27 = this.trestext;
                TextView[] textViewArr4 = {textView27, this.trestext2, this.trestext3, this.trestext4, this.trestext5, this.trestext6, textView26};
                TextView textView28 = this.thead;
                StringBuilder sb75 = new StringBuilder();
                sb75.append(head);
                sb75.append(str10);
                sb75.append(getResources().getString(R.string.sharer));
                textView28.setText(sb75.toString());
                ImageView imageView20 = findViewById(R.id.card1);
                this.card1 = imageView20;
                imageView20.setImageResource(this.resids[0]);
                ImageView imageView21 = findViewById(R.id.card2);
                this.card2 = imageView21;
                imageView21.setImageResource(this.resids[1]);
                ImageView imageView22 = findViewById(R.id.card3);
                this.card3 = imageView22;
                imageView22.setImageResource(this.resids[2]);
                ImageView imageView23 = findViewById(R.id.card4);
                this.card4 = imageView23;
                imageView23.setImageResource(this.resids[3]);
                ImageView imageView24 = findViewById(R.id.card5);
                this.card5 = imageView24;
                imageView24.setImageResource(this.resids[4]);
                ImageView imageView25 = findViewById(R.id.card6);
                this.card6 = imageView25;
                imageView25.setImageResource(this.resids[5]);
                ImageView imageView26 = findViewById(R.id.card7);
                this.card7 = imageView26;
                imageView26.setImageResource(this.resids[6]);
                if (this.ccb.equals("Tarot Life")) {
                    this.status = new String[]{getResources().getString(R.string.statusKOL1), getResources().getString(R.string.statusKOL2), getResources().getString(R.string.statusKOL3), getResources().getString(R.string.statusKOL4), getResources().getString(R.string.statusKOL5), getResources().getString(R.string.statusKOL6), getResources().getString(R.string.statusKOL7)};
                } else if (this.ccb.equals("Relationship Purpose")) {
                    this.status = new String[]{getResources().getString(R.string.statusRP1), getResources().getString(R.string.statusRP2), getResources().getString(R.string.statusRP3), getResources().getString(R.string.statusRP4), getResources().getString(R.string.statusRP5), getResources().getString(R.string.statusRP6), getResources().getString(R.string.statusRP7)};
                }
                StringBuilder sb76 = new StringBuilder();
                sb76.append(getResources().getString(R.string.fetchingfile));
                sb76.append(this.ccb);
                sb76.append(str7);
                sb76.append(this.ccb.replace(str10, str2));
                sb76.append(str6);
                if (resultString(sb76.toString(), this.names, "seven")) {
                    for (int i11 = 0; i11 < 7; i11++) {
                        TextView textView29 = textViewArr4[i11];
                        StringBuilder sb77 = new StringBuilder();
                        sb77.append(this.names2[i11]);
                        sb77.append("\n(");
                        sb77.append(this.status[i11]);
                        sb77.append(")\n");
                        sb77.append(this.results[i11]);
                        textView29.setText(sb77.toString());
                    }
                    Log.e(str9, str4);
                } else {
                    Log.e(str9, str15);
                }
                textViewArr4[0].setOnTouchListener(new View.OnTouchListener() {
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        return false;
                    }
                });
            } else {
                setContentView(R.layout.five_result);
                this.moreappstxt = findViewById(R.id.moreappstxt);
                RelativeLayout relativeLayout6 = findViewById(R.id.moreapps);
                this.moreapps = relativeLayout6;
                relativeLayout6.setVisibility(View.GONE);
                TextView textView30 = this.titleview;
                StringBuilder sb78 = new StringBuilder();
                sb78.append(str10);
                sb78.append(head);
                textView30.setText(sb78.toString());
                this.email = findViewById(R.id.email);
                this.facebook = findViewById(R.id.facebook);
                this.email.setOnClickListener(this.listenemail);
                this.facebook.setOnClickListener(this.faceshare);
                this.dia = 2;
                this.names = extras.getStringArray("name");
                this.names2 = extras.getStringArray("name2");
                for (int i12 = 0; i12 < 5; i12++) {
                    this.resids[i12] = getResources().getIdentifier(this.names[i12].toLowerCase().replaceAll(str10, str2).replaceAll(str8, str2), "drawable", getPackageName());
                }
                this.thead = findViewById(R.id.header);
                this.trestext = findViewById(R.id.restext);
                this.trestext2 = findViewById(R.id.restext2);
                this.trestext3 = findViewById(R.id.restext3);
                this.trestext4 = findViewById(R.id.restext4);
                TextView textView31 = findViewById(R.id.restext5);
                this.trestext5 = textView31;
                TextView textView32 = this.trestext;
                TextView[] textViewArr5 = {textView32, this.trestext2, this.trestext3, this.trestext4, textView31};
                ImageView imageView27 = findViewById(R.id.card1);
                this.card1 = imageView27;
                imageView27.setImageResource(this.resids[0]);
                ImageView imageView28 = findViewById(R.id.card2);
                this.card2 = imageView28;
                imageView28.setImageResource(this.resids[1]);
                ImageView imageView29 = findViewById(R.id.card3);
                this.card3 = imageView29;
                imageView29.setImageResource(this.resids[2]);
                ImageView imageView30 = findViewById(R.id.card4);
                this.card4 = imageView30;
                imageView30.setImageResource(this.resids[3]);
                ImageView imageView31 = findViewById(R.id.card5);
                this.card5 = imageView31;
                imageView31.setImageResource(this.resids[4]);
                if (this.ccb.equals("Find Love")) {
                    this.status = new String[]{getResources().getString(R.string.statusLS1), getResources().getString(R.string.statusLS2), getResources().getString(R.string.statusLS3), getResources().getString(R.string.statusLS4), getResources().getString(R.string.statusLS5)};
                    this.thead.setText(str10);
                } else {
                    this.thead.setText(head);
                    this.status = new String[]{getResources().getString(R.string.statusFVC1), getResources().getString(R.string.statusFVC2), getResources().getString(R.string.statusFVC3), getResources().getString(R.string.statusFVC4), getResources().getString(R.string.statusFVC5)};
                }
                StringBuilder sb79 = new StringBuilder();
                sb79.append(" aa   ");
                sb79.append(this.ccb);
                sb79.append(str7);
                sb79.append(this.ccb.replace(str10, str2));
                sb79.append(str6);
                Log.e("aa", sb79.toString());
                StringBuilder sb80 = new StringBuilder();
                sb80.append(getResources().getString(R.string.fetchingfile));
                sb80.append(this.ccb);
                sb80.append(str7);
                sb80.append(this.ccb.replace(str10, str2));
                sb80.append(str6);
                if (resultString(sb80.toString(), this.names, "five")) {
                    for (int i13 = 0; i13 < 5; i13++) {
                        TextView textView33 = textViewArr5[i13];
                        StringBuilder sb81 = new StringBuilder();
                        sb81.append(this.names2[i13]);
                        sb81.append("\n(");
                        sb81.append(this.status[i13]);
                        sb81.append(")\n");
                        sb81.append(this.results[i13]);
                        textView33.setText(sb81.toString());
                    }
                    Log.e(str9, str4);
                } else {
                    Log.e(str9, str15);
                }
                textViewArr5[0].setOnTouchListener(new View.OnTouchListener() {

                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        return false;
                    }
                });
            }
        }
        if (this.ccb.equals("Meanings Of All Tarot Cards")) {
            StringBuilder sb82 = new StringBuilder();
            sb82.append("tracker - PAGE TYPE + 1 ccb= ");
            sb82.append(this.ccb);
            sb82.append(" - subtype = ");
            sb82.append(this.subtype_eng);
            sb82.append(" - name = ");
            sb82.append(this.name);
            Log.e("TaroResult", sb82.toString());
        } else {
            String str16 = this.cc2;
            if (str16 == null || str16.equals(str2)) {
                StringBuilder sb83 = new StringBuilder();
                sb83.append("IF tracker -TYPE + 1 ccb= ");
                sb83.append(this.ccb);
                Log.e("TaroResult", sb83.toString());
            } else {
                StringBuilder sb84 = new StringBuilder();
                sb84.append(" - ");
                sb84.append(this.cc2);
                String sb85 = sb84.toString();
                StringBuilder sb86 = new StringBuilder();
                sb86.append("ELSE tracker -TYPE + 1 ccb= ");
                sb86.append(this.ccb);
                sb86.append(str2);
                sb86.append(sb85);
                Log.e("TaroResult", sb86.toString());
            }
        }
        if (VERSION.SDK_INT >= 21) {
            getWindow().addFlags(Integer.MIN_VALUE);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_1));
        }
    }

    private boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @SuppressLint({"DefaultLocale"})
    public boolean resultString(String str, String[] strArr, String str2) {
        boolean z;
        boolean z2;
        XmlPullParserException xmlPullParserException;
        XmlPullParserException e;
        IOException iOException;
        IOException e2;
        String str3 = str;
        String[] strArr2 = strArr;
        String str4 = str2;
        String str5 = "";
        String[] strArr3 = new String[10];
        String[] strArr4 = new String[10];
        String[] strArr5 = new String[10];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(".............");
        stringBuilder.append(str3);
        Log.e("filename", stringBuilder.toString());
        for (int i = 0; i < strArr2.length; i++) {
            strArr4[i] = strArr2[i].toUpperCase().replace(" ", "-");
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("cname = ");
            stringBuilder2.append(strArr4[i]);
            stringBuilder2.append(" ctypw = ");
            stringBuilder2.append(str4);
            Log.e("XML 123", stringBuilder2.toString());
        }
        String str6 = "ten";
        String str7 = "four";
        String str8 = "three";
        int i2 = 2;
        int i3 = 1;
        if (str4.contains(str6)) {
            strArr5 = this.ccb.contains("Tree Of Life") ? new String[]{"-IDEALS", "-CREATIVE", "-WISDOM", "-VIRTUES", "-FORCE", "-HEALTH", "-LOVE", "-PROCREATOR", "-IMAGINATION", "-PHYSICAL"} : new String[]{"-FUTURE", "-OUTCOME", "-PRESENT", "-IMMEDIATE", "-RECENT", "-DISTANT", "-SITUATION", "-INFLUENCE", "-HOPES", "-FINAL"};
        } else if (str4.contains(str8)) {
            strArr5 = new String[]{"-PAST", "-PRESENT", "-FUTURE"};
        } else {
            String[] strArr6 = new String[0];
            if (str4.contains(str7)) {
                strArr6 = this.ccb.equals("Decision Making") ? new String[]{"-PRESENTSTATUS", "-POSITIVE", "-NEGATIVE", "-OTHER"} : this.ccb.equals("Relationship Potential") ? new String[]{"-CONTRIBUTION", "-PARTNER", "-COMPOSITE", "-INSIGHT"} : new String[]{"-PHYSICAL", "-MENTAL", "-EMOTIONAL", "-POTENTIAL"};
            } else if (str4.contains("five")) {
                strArr6 = this.ccb.equals("Find Love") ? new String[]{"-YOUANDISSUES", "-BEHAVIORAL", "-AREASFURTHERGROWTH", "-AREASNEEDTOCHANGE", "-AREASNEEDTOLIBERATE"} : new String[]{"-FAMILY", "-HEALTH", "-LOVE", "-MONEY", "-WORK"};
            } else if (str4.contains("seven")) {
                if (this.ccb.equals("Tarot Life")) {
                    strArr5 = new String[]{"-SOCIAL", "-NUTRITION", "-PLAY", "-LIFEPURPOSE", "-IMAGERY", "-EXERCISE", "-WORKOBLI"};
                } else if (this.ccb.equals("Relationship Purpose")) {
                    strArr5 = new String[]{"-YOU", "-YPARTNER", "-INTENTIONS", "-PARTNERSINTENTIONS", "-LESSON", "-PARTNERSLESSON", "-PURPOSE"};
                }
            }
            strArr5 = strArr6;
        }
        try {
            XmlPullParser newPullParser = XmlPullParserFactory.newInstance().newPullParser();
            InputStream open = getApplicationContext().getAssets().open(str3);
            newPullParser.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", false);
            newPullParser.setInput(open, null);
            int i4 = 0;
            int i5 = 10;
            z = false;
            while (i4 < i5) {
                try {
                    int eventType = newPullParser.getEventType();
                    Log.e(str5, " 111 ***************************************************************************");
                    i5 = eventType;
                    while (i5 != i3) {
                        try {
                            Log.e(str5, " 22  ***************************************************************************");
                            String name;
                            StringBuilder stringBuilder3;
                            if (i5 == 0) {
                                z2 = z;
                                name = newPullParser.getName();
                                stringBuilder3 = new StringBuilder();
                                stringBuilder3.append("************** ");
                                stringBuilder3.append(name);
                                Log.e(str5, stringBuilder3.toString());
                            } else if (i5 != i2) {
                                if (i5 == 3) {
                                    if (newPullParser.getName().contains("ROOT")) {
                                        i5 = 0;
                                        while (i5 < strArr3.length) {
                                            this.results[i5] = strArr3[i5];
                                            i5++;
                                        }
                                        z = true;
                                        i5 = newPullParser.next();
                                        i2 = 2;
                                        i3 = 1;
                                    }
                                }
                                z2 = z;
                            } else {
                                name = newPullParser.getName();
                                StringBuilder stringBuilder4 = new StringBuilder();
                                stringBuilder4.append("tag name ");
                                stringBuilder4.append(name);
                                Log.e(str5, stringBuilder4.toString());
                                if (!str4.contains("one")) {
                                    z2 = z;
                                    if (str4.contains(str8)) {
                                        stringBuilder3 = new StringBuilder();
                                        stringBuilder3.append(strArr4[0]);
                                        stringBuilder3.append(strArr5[0]);
                                        if (name.contains(stringBuilder3.toString())) {
                                            strArr3[0] = newPullParser.nextText();
                                        } else {
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append(strArr4[1]);
                                            stringBuilder3.append(strArr5[1]);
                                            if (name.contains(stringBuilder3.toString())) {
                                                strArr3[1] = newPullParser.nextText();
                                            } else {
                                                stringBuilder3 = new StringBuilder();
                                                stringBuilder3.append(strArr4[2]);
                                                stringBuilder3.append(strArr5[2]);
                                                if (name.contains(stringBuilder3.toString())) {
                                                    strArr3[2] = newPullParser.nextText();
                                                }
                                            }
                                        }
                                    } else if (str4.contains(str7)) {
                                        stringBuilder3 = new StringBuilder();
                                        stringBuilder3.append(strArr4[0]);
                                        stringBuilder3.append(strArr5[0]);
                                        if (name.contains(stringBuilder3.toString())) {
                                            strArr3[0] = newPullParser.nextText();
                                        } else {
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append(strArr4[1]);
                                            stringBuilder3.append(strArr5[1]);
                                            if (name.contains(stringBuilder3.toString())) {
                                                strArr3[1] = newPullParser.nextText();
                                            } else {
                                                stringBuilder3 = new StringBuilder();
                                                stringBuilder3.append(strArr4[2]);
                                                stringBuilder3.append(strArr5[2]);
                                                if (name.contains(stringBuilder3.toString())) {
                                                    strArr3[2] = newPullParser.nextText();
                                                } else {
                                                    stringBuilder3 = new StringBuilder();
                                                    stringBuilder3.append(strArr4[3]);
                                                    stringBuilder3.append(strArr5[3]);
                                                    if (name.contains(stringBuilder3.toString())) {
                                                        strArr3[3] = newPullParser.nextText();
                                                    }
                                                }
                                            }
                                        }
                                    } else if (str4.contains(str6)) {
                                        stringBuilder3 = new StringBuilder();
                                        stringBuilder3.append(strArr4[0]);
                                        stringBuilder3.append(strArr5[0]);
                                        if (name.contains(stringBuilder3.toString())) {
                                            strArr3[0] = newPullParser.nextText();
                                        } else {
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append(strArr4[1]);
                                            stringBuilder3.append(strArr5[1]);
                                            if (name.contains(stringBuilder3.toString())) {
                                                strArr3[1] = newPullParser.nextText();
                                            } else {
                                                stringBuilder3 = new StringBuilder();
                                                stringBuilder3.append(strArr4[2]);
                                                stringBuilder3.append(strArr5[2]);
                                                if (name.contains(stringBuilder3.toString())) {
                                                    strArr3[2] = newPullParser.nextText();
                                                } else {
                                                    stringBuilder3 = new StringBuilder();
                                                    stringBuilder3.append(strArr4[3]);
                                                    stringBuilder3.append(strArr5[3]);
                                                    if (name.contains(stringBuilder3.toString())) {
                                                        strArr3[3] = newPullParser.nextText();
                                                    } else {
                                                        stringBuilder3 = new StringBuilder();
                                                        stringBuilder3.append(strArr4[4]);
                                                        stringBuilder3.append(strArr5[4]);
                                                        if (name.contains(stringBuilder3.toString())) {
                                                            strArr3[4] = newPullParser.nextText();
                                                        } else {
                                                            stringBuilder3 = new StringBuilder();
                                                            stringBuilder3.append(strArr4[5]);
                                                            stringBuilder3.append(strArr5[5]);
                                                            if (name.contains(stringBuilder3.toString())) {
                                                                strArr3[5] = newPullParser.nextText();
                                                            } else {
                                                                stringBuilder3 = new StringBuilder();
                                                                stringBuilder3.append(strArr4[6]);
                                                                stringBuilder3.append(strArr5[6]);
                                                                if (name.contains(stringBuilder3.toString())) {
                                                                    strArr3[6] = newPullParser.nextText();
                                                                } else {
                                                                    stringBuilder3 = new StringBuilder();
                                                                    stringBuilder3.append(strArr4[7]);
                                                                    stringBuilder3.append(strArr5[7]);
                                                                    if (name.contains(stringBuilder3.toString())) {
                                                                        strArr3[7] = newPullParser.nextText();
                                                                    } else {
                                                                        stringBuilder3 = new StringBuilder();
                                                                        stringBuilder3.append(strArr4[8]);
                                                                        stringBuilder3.append(strArr5[8]);
                                                                        if (name.contains(stringBuilder3.toString())) {
                                                                            strArr3[8] = newPullParser.nextText();
                                                                        } else {
                                                                            stringBuilder3 = new StringBuilder();
                                                                            stringBuilder3.append(strArr4[9]);
                                                                            stringBuilder3.append(strArr5[9]);
                                                                            if (name.contains(stringBuilder3.toString())) {
                                                                                strArr3[9] = newPullParser.nextText();
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } else if (str4.contains("five")) {
                                        stringBuilder3 = new StringBuilder();
                                        stringBuilder3.append(strArr4[0]);
                                        stringBuilder3.append(strArr5[0]);
                                        if (name.contains(stringBuilder3.toString())) {
                                            strArr3[0] = newPullParser.nextText();
                                        } else {
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append(strArr4[1]);
                                            stringBuilder3.append(strArr5[1]);
                                            if (name.contains(stringBuilder3.toString())) {
                                                strArr3[1] = newPullParser.nextText();
                                            } else {
                                                stringBuilder3 = new StringBuilder();
                                                stringBuilder3.append(strArr4[2]);
                                                stringBuilder3.append(strArr5[2]);
                                                if (name.contains(stringBuilder3.toString())) {
                                                    strArr3[2] = newPullParser.nextText();
                                                } else {
                                                    stringBuilder3 = new StringBuilder();
                                                    stringBuilder3.append(strArr4[3]);
                                                    stringBuilder3.append(strArr5[3]);
                                                    if (name.contains(stringBuilder3.toString())) {
                                                        strArr3[3] = newPullParser.nextText();
                                                    } else {
                                                        stringBuilder3 = new StringBuilder();
                                                        stringBuilder3.append(strArr4[4]);
                                                        stringBuilder3.append(strArr5[4]);
                                                        if (name.contains(stringBuilder3.toString())) {
                                                            strArr3[4] = newPullParser.nextText();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } else if (str4.contains("seven")) {
                                        stringBuilder3 = new StringBuilder();
                                        stringBuilder3.append(strArr4[0]);
                                        stringBuilder3.append(strArr5[0]);
                                        if (name.contains(stringBuilder3.toString())) {
                                            strArr3[0] = newPullParser.nextText();
                                        } else {
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append(strArr4[1]);
                                            stringBuilder3.append(strArr5[1]);
                                            if (name.contains(stringBuilder3.toString())) {
                                                strArr3[1] = newPullParser.nextText();
                                            } else {
                                                stringBuilder3 = new StringBuilder();
                                                stringBuilder3.append(strArr4[2]);
                                                stringBuilder3.append(strArr5[2]);
                                                if (name.contains(stringBuilder3.toString())) {
                                                    strArr3[2] = newPullParser.nextText();
                                                } else {
                                                    stringBuilder3 = new StringBuilder();
                                                    stringBuilder3.append(strArr4[3]);
                                                    stringBuilder3.append(strArr5[3]);
                                                    if (name.contains(stringBuilder3.toString())) {
                                                        strArr3[3] = newPullParser.nextText();
                                                    } else {
                                                        stringBuilder3 = new StringBuilder();
                                                        stringBuilder3.append(strArr4[4]);
                                                        stringBuilder3.append(strArr5[4]);
                                                        if (name.contains(stringBuilder3.toString())) {
                                                            strArr3[4] = newPullParser.nextText();
                                                        } else {
                                                            stringBuilder3 = new StringBuilder();
                                                            stringBuilder3.append(strArr4[5]);
                                                            stringBuilder3.append(strArr5[5]);
                                                            if (name.contains(stringBuilder3.toString())) {
                                                                strArr3[5] = newPullParser.nextText();
                                                            } else {
                                                                stringBuilder3 = new StringBuilder();
                                                                stringBuilder3.append(strArr4[6]);
                                                                stringBuilder3.append(strArr5[6]);
                                                                if (name.contains(stringBuilder3.toString())) {
                                                                    strArr3[6] = newPullParser.nextText();
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else if (this.ccb.contains("Daily Tarot Horoscope")) {
                                    StringBuilder stringBuilder5 = new StringBuilder();
                                    z2 = z;
                                    try {
                                        stringBuilder5.append(strArr4[0]);
                                        stringBuilder5.append(this.dcn1);
                                        if (name.contains(stringBuilder5.toString())) {
                                            strArr3[0] = newPullParser.nextText();
                                        } else {
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append(strArr4[0]);
                                            stringBuilder3.append(this.dcn2);
                                            if (name.contains(stringBuilder3.toString())) {
                                                strArr3[1] = newPullParser.nextText();
                                            } else {
                                                stringBuilder3 = new StringBuilder();
                                                stringBuilder3.append(strArr4[0]);
                                                stringBuilder3.append(this.dcn3);
                                                if (name.contains(stringBuilder3.toString())) {
                                                    strArr3[2] = newPullParser.nextText();
                                                } else {
                                                    stringBuilder3 = new StringBuilder();
                                                    stringBuilder3.append(strArr4[0]);
                                                    stringBuilder3.append(this.dcn4);
                                                    if (name.contains(stringBuilder3.toString())) {
                                                        strArr3[3] = newPullParser.nextText();
                                                    } else {
                                                        stringBuilder3 = new StringBuilder();
                                                        stringBuilder3.append(strArr4[0]);
                                                        stringBuilder3.append(this.dcn5);
                                                        if (name.contains(stringBuilder3.toString())) {
                                                            strArr3[4] = newPullParser.nextText();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } catch (XmlPullParserException e32) {
                                        xmlPullParserException = e32;
                                        z = z2;
                                        xmlPullParserException.printStackTrace();
                                        Log.e(str5, "tag error");
                                        return z;
                                    } catch (IOException e222) {
                                        iOException = e222;
                                        z = z2;
                                        iOException.printStackTrace();
                                        Log.e(str5, "tag error");
                                        return z;
                                    }
                                } else {
                                    z2 = z;
                                    if (name.contains(strArr4[0])) {
                                        strArr3[0] = newPullParser.nextText();
                                    }
                                }
                            }
                            z = z2;
                            i5 = newPullParser.next();
                            i2 = 2;
                            i3 = 1;
                        } catch (XmlPullParserException e4) {
                            z2 = z;
                            Log.e(str5, "tag error");
                            return z;
                        } catch (IOException e5) {
                            z2 = z;
                            Log.e(str5, "tag error");
                            return z;
                        }
                    }
                    z2 = z;
                    i4++;
                    i5 = 10;
                    i2 = 2;
                    i3 = 1;
                } catch (XmlPullParserException e6) {
                    Log.e(str5, "tag error");
                    return z;
                }
            }
        } catch (XmlPullParserException e322) {
            xmlPullParserException = e322;
            z = false;
            xmlPullParserException.printStackTrace();
            Log.e(str5, "tag error");
            return z;
        } catch (IOException e2222) {
            iOException = e2222;
            z = false;
            iOException.printStackTrace();
            Log.e(str5, "tag error");
            return z;
        }
        return z;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Log.e("TAG", "Back");
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(activity, TaroQuestionsActivity.class);
        startActivity(intent);
        finish();
    }
}


