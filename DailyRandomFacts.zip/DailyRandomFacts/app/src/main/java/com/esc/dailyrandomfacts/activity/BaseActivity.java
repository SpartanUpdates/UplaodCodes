package com.esc.dailyrandomfacts.activity;

import android.content.Context;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.esc.dailyrandomfacts.util.Quotes;
import com.esc.dailyrandomfacts.R;
import com.esc.dailyrandomfacts.managers.SettingsManager;
import com.zeugmasolutions.localehelper.LocaleHelperActivityDelegateImpl;
import java.util.Locale;

public class BaseActivity extends AppCompatActivity {
    private LocaleHelperActivityDelegateImpl localeDelegate = Quotes.getLocaleDelegate();

    public void attachBaseContext(Context context) {
        super.attachBaseContext(this.localeDelegate.attachBaseContext(context));
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.localeDelegate.onCreate(this);
    }

    public void onResume() {
        super.onResume();
        this.localeDelegate.onResumed(this);
    }

    public void onPause() {
        super.onPause();
        this.localeDelegate.onPaused();
    }

    public void updateLocale(Locale locale) {
        this.localeDelegate.setLocale(this, locale);
    }
}
