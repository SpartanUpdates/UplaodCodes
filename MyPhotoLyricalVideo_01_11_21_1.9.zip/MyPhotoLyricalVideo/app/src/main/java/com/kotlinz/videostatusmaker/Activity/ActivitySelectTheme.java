package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.kotlinz.videostatusmaker.adapter.ThemeAdapter;
import static com.kotlinz.videostatusmaker.NativeAds.CustomNativeAd.populateUnifiedNativeAdView;

public class ActivitySelectTheme extends AppCompatActivity {
    Activity activity = ActivitySelectTheme.this;
    ThemeAdapter themeAdapter;
    ImageView ivBack;
    Typeface typeface;
    ImageLoader imageLoader;
    GridView stylelist;
    String[] theme;
    TextView title;

    private NativeAd nativeAd;

    private void initImageLoader() {
        (this.imageLoader = ImageLoader.getInstance()).init(new ImageLoaderConfiguration.Builder((Context) this).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).build()).build());
    }

    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.select_typface);
        this.getWindow().addFlags(1024);
        PutAnalyticsEvent();
        LoadNativeAds();
        this.initImageLoader();
        init();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivitySelectTheme");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (ActivitySelectTheme.this.nativeAd != null) {
                            ActivitySelectTheme.this.nativeAd.destroy();
                        }
                        ActivitySelectTheme.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
    }

    private void init() {
        this.ivBack = this.findViewById(R.id.back);
        this.title = this.findViewById(R.id.title);
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 19;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        onBackPressed();
                    }
                }
            }
        });
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.title.setTypeface(this.typeface);
        this.title.setText((CharSequence) "Themes");
        this.stylelist = this.findViewById(R.id.stylelist);
        try {
            this.theme = this.getResources().getAssets().list("theme");
            this.themeAdapter = new ThemeAdapter(this.getApplicationContext(), this.theme);
            this.stylelist.setAdapter((ListAdapter) this.themeAdapter);
            this.stylelist.setNumColumns(2);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.stylelist.setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int theme, final long n) {
                if (theme == 0) {
                    Log.e("LOG", "====11111====");
                    ActivityPreview.THEME = theme;
                    ActivityPreview.complete = false;
                    if (theme == 4) {
                        Log.e("LOG", "====22222====");
                        ActivityPreview.lyricTxt1.setTextColor(-16777216);
                        ActivityPreview.lyricTxt2.setTextColor(-16777216);
                    } else {
                        Log.e("LOG", "====33333====");
                        ActivityPreview.lyricTxt1.setTextColor(-1);
                        ActivityPreview.lyricTxt2.setTextColor(-1);
                    }
                    Log.e("LOG", "====44444====");
                    ActivitySelectTheme.this.setResult(-1, new Intent(ActivitySelectTheme.this.getApplicationContext(), (Class) ActivityPreview.class));
                    ActivitySelectTheme.this.finish();
                    return;
                }
                Log.e("LOG","====5555555====");
                ActivityPreview.complete = false;
                ActivityPreview.THEME = theme;
                if (n == 4) {
                    Log.e("LOG","====66666====");
                    ActivityPreview.lyricTxt1.setTextColor(-16777216);
                    ActivityPreview.lyricTxt2.setTextColor(-16777216);
                } else if (n == 5) {
                    Log.e("LOG","====777777====");
                    ActivityPreview.lyricTxt1.setTextColor(Color.parseColor("#000004"));
                    ActivityPreview.lyricTxt2.setTextColor(Color.parseColor("#000004"));
                } else {
                    Log.e("LOG","====88888====");
                    ActivityPreview.lyricTxt1.setTextColor(-1);
                    ActivityPreview.lyricTxt2.setTextColor(-1);
                }
                ActivitySelectTheme.this.setResult(-1, new Intent(ActivitySelectTheme.this.getApplicationContext(), (Class) ActivityPreview.class));
                ActivitySelectTheme.this.finish();
            }
        });
    }
}
