package com.esc.dailyrandomfacts.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.esc.dailyrandomfacts.R;
import com.esc.dailyrandomfacts.managers.SettingsManager;
import com.esc.dailyrandomfacts.model.Category;
import com.esc.dailyrandomfacts.model.Section;
import java.util.ArrayList;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class CategoriesAdapter extends RecyclerView.Adapter {
    private static RecyclerViewClickListener itemListener;
    private Context context;
    private ArrayList<Object> itemList;
    private final int mDefaultSpanCount;

    public interface RecyclerViewClickListener {
        void recyclerViewListClicked(View view, int i);
    }

    public class CategoryHeaderHolder extends RecyclerView.ViewHolder {
        private TextView txtHeader;

        public CategoryHeaderHolder(View view) {
            super(view);
            this.txtHeader = (TextView) view.findViewById(R.id.txtHeader);
        }
    }

    public class CategoryItemHolder extends RecyclerView.ViewHolder implements OnClickListener {
        private ImageView image;
        private TextView name;

        public CategoryItemHolder(View view) {
            super(view);
            this.name = (TextView) view.findViewById(R.id.txtName);
            this.image = (ImageView) view.findViewById(R.id.ivCategory);
            view.setOnClickListener(this);
        }

        public void onClick(View view) {
            CategoriesAdapter.itemListener.recyclerViewListClicked(view, getLayoutPosition());
        }
    }

    public CategoriesAdapter(ArrayList<Object> arrayList, GridLayoutManager gridLayoutManager, int i, Context context, RecyclerViewClickListener recyclerViewClickListener) {
        this.context = context;
        itemListener = recyclerViewClickListener;
        this.itemList = arrayList;
        this.mDefaultSpanCount = i;
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            public int getSpanSize(int i) {
                return CategoriesAdapter.this.getItemViewType(i) == 1 ? CategoriesAdapter.this.mDefaultSpanCount : 1;
            }
        });
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(this.context);
        if (i == 0) {
            return new CategoryItemHolder(from.inflate(R.layout.item_list_category, viewGroup, false));
        }
        if (i != 1) {
            return new CategoryItemHolder(from.inflate(R.layout.item_list_category, viewGroup, false));
        }
        return new CategoryHeaderHolder(from.inflate(R.layout.item_list_header_category, viewGroup, false));
    }

    @SuppressLint("WrongConstant")
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        int itemViewType = viewHolder.getItemViewType();
        if (itemViewType == 0) {
            CategoryItemHolder categoryItemHolder = (CategoryItemHolder) viewHolder;
            Category category = (Category) this.itemList.get(i);
            categoryItemHolder.name.setText(category.getTitle());
            categoryItemHolder.image.setImageDrawable(this.context.getResources().getDrawable(this.context.getResources().getIdentifier(category.getId(), "drawable", this.context.getPackageName())));

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.context.getString(R.string.default_category));
            stringBuilder.append(SettingsManager.getLanguageFiles());

        } else if (itemViewType == 1) {
           CategoryHeaderHolder categoryHeaderHolder = (CategoryHeaderHolder) viewHolder;
            Section section = (Section) this.itemList.get(i);
            if (section.getName().isEmpty()) {
                categoryHeaderHolder.txtHeader.setVisibility(8);
                return;
            }
            categoryHeaderHolder.txtHeader.setVisibility(0);
            categoryHeaderHolder.txtHeader.setText(section.getName());
        }
    }

    public int getItemViewType(int i) {
        return getItem(i) instanceof Category ? 0 : 1;
    }

    public Object getItem(int i) {
        return this.itemList.get(i);
    }

    public int getItemCount() {
        return this.itemList.size();
    }

    public void updateItems(ArrayList<Object> arrayList) {
        this.itemList = arrayList;
        notifyDataSetChanged();
    }
}
