package com.unitedvideos.guillotine.interfaces;


public interface GuillotineListener {
    void onGuillotineOpened();
    void onGuillotineClosed();
}
