package com.xyz.vehiclemanager.car.CarVarianDetails.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.car.CarVarianDetails.model.CarFeatures;
import com.xyz.vehiclemanager.model.Item;

import java.util.ArrayList;

public class CarFeaturesAdapter extends RecyclerView.Adapter<CarFeaturesAdapter.ViewHolder> {
    private Context context;
    private ArrayList<CarFeatures> featuresKey;
    private ArrayList<Item> safety;
    private ArrayList<Item> brakingAndTraction;
    private ArrayList<Item> locksAndSecurity;
    private ArrayList<Item> comfortAndConvenience;
    private ArrayList<Item> seatAndUpjolstery;
    private ArrayList<Item> storage;
    private ArrayList<Item> doorWindowsMirrorsWipers;
    private ArrayList<Item> exterior;
    private ArrayList<Item> lighting;
    private ArrayList<Item> instrumention;
    private ArrayList<Item> entertainmentInformationCommunication;
    private ArrayList<Item> manufacturesWarranty;
    private CarFeaturesAttrAdapter carfeaturesAttrAdapter;

    public CarFeaturesAdapter(Context context, ArrayList<CarFeatures> featuresKey, ArrayList<Item> safety, ArrayList<Item> brakingAndTraction, ArrayList<Item> locksAndSecurity, ArrayList<Item> comfortAndConvenience, ArrayList<Item> seatAndUpjolstery, ArrayList<Item> storage, ArrayList<Item> doorWindowsMirrorsWipers, ArrayList<Item> exterior, ArrayList<Item> lighting, ArrayList<Item> instrumention, ArrayList<Item> entertainmentInformationCommunication, ArrayList<Item> manufacturesWarranty) {
        this.context = context;
        this.featuresKey = featuresKey;
        this.safety = safety;
        this.brakingAndTraction = brakingAndTraction;
        this.locksAndSecurity = locksAndSecurity;
        this.comfortAndConvenience = comfortAndConvenience;
        this.seatAndUpjolstery = seatAndUpjolstery;
        this.storage = storage;
        this.doorWindowsMirrorsWipers = doorWindowsMirrorsWipers;
        this.exterior = exterior;
        this.lighting = lighting;
        this.instrumention = instrumention;
        this.entertainmentInformationCommunication = entertainmentInformationCommunication;
        this.manufacturesWarranty = manufacturesWarranty;
    }
    public class ViewHolder extends RecyclerView.ViewHolder
    {   TextView tv_variantKey;
        RecyclerView rv_varinatkey;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_variantKey =itemView.findViewById(R.id.tv_varinatKeyName);
            rv_varinatkey =itemView.findViewById(R.id.rv_variantKey);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_variantkey,parent,false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        CarFeatures features = featuresKey.get(position);
        holder.tv_variantKey.setText(features.getKey());
        String key = features.getKey();
        if(key.equals("Safety"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, safety);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Braking & Traction"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, brakingAndTraction);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Locks & Security"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, locksAndSecurity);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Comfort & Convenience"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, comfortAndConvenience);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Seats & Upholstery"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, seatAndUpjolstery);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Storage"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, storage);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Doors, Windows, Mirrors & Wipers"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, doorWindowsMirrorsWipers);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Exterior"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, exterior);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Lighting"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, lighting);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Instrumentation"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, instrumention);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Entertainment, Information & Communication"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, entertainmentInformationCommunication);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
        if(key.equals("Manufacturer Warranty"))
        {
            carfeaturesAttrAdapter = new CarFeaturesAttrAdapter(context, manufacturesWarranty);
            holder.rv_varinatkey.setAdapter(carfeaturesAttrAdapter);
            holder.rv_varinatkey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_varinatkey.setHasFixedSize(true);
        }
    }
    @Override
    public int getItemCount() {
        return featuresKey.size();
    }
}
