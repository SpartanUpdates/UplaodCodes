package com.MV.Lyrics.videolib.libffmpeg;

public abstract interface FFmpegExecuteResponseHandler
  extends ResponseHandler
{
  public abstract void onSuccess(String paramString);
  
  public abstract void onProgress(String paramString);
  
  public abstract void onFailure(String paramString);
}
