package com.esc.gesturelockscreen.Activity;

import android.app.AlertDialog.Builder;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.esc.gesturelockscreen.Other.ColorDialogFragment;
import com.esc.gesturelockscreen.Other.ColorDialogFragment.IOnColorSelectedListener;
import com.esc.gesturelockscreen.Other.SettingsKeys;
import com.esc.gesturelockscreen.Other.SettingsUtils;
import com.esc.gesturelockscreen.R;
import androidx.appcompat.app.AppCompatActivity;

public class SecureActivity extends AppCompatActivity {
    private TextView tvHideDraw;
    private TextView tvLength;
    private TextView tvPasscode;
    private TextView tvRandom;

    protected void onStart() {
        super.onStart();
        overridePendingTransition(0, 0);
    }

    protected void onCreate(Bundle savedInstanceState) {
        int i = R.string.s_visible;
        super.onCreate(savedInstanceState);
        SettingsUtils.init(getApplicationContext());
        setContentView(R.layout.activity_security);
        this.tvRandom = (TextView) findViewById(R.id.tv_passcode_random_subtitle);
        this.tvHideDraw = (TextView) findViewById(R.id.tv_hidegesture_subtitle);
        this.tvPasscode = (TextView) findViewById(R.id.tv_passcode_subtitle);
        this.tvLength = (TextView) findViewById(R.id.tv_passcode_length_subtitle);
        boolean random = SettingsUtils.getBoolean(SettingsKeys.RANDOM_KEYBOARD, false);
        ((CheckBox) findViewById(R.id.check_randompasscode)).setChecked(random);
        this.tvRandom.setText(random ? R.string.s_randomlock_enabled : R.string.s_randomlock_disabled);
        boolean hide = SettingsUtils.getBoolean(SettingsKeys.KEY_HIDE_GESTURE, false);
        ((CheckBox) findViewById(R.id.check_hidegesture)).setChecked(hide);
        this.tvHideDraw.setText(hide ? R.string.s_hidden : R.string.s_visible);
        boolean pass = SettingsUtils.getBoolean(SettingsKeys.SHOW_KEYBOARD_PASSCODE, true);
        ((CheckBox) findViewById(R.id.check_passcode)).setChecked(pass);
        TextView textView = this.tvPasscode;
        if (!pass) {
            i = R.string.s_hidden;
        }
        textView.setText(i);
        this.tvLength.setText(SettingsUtils.getPasscodeLengthValue() + " Digit");
        ((CheckBox) findViewById(R.id.check_randompasscode)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton arg0, boolean check) {
                SettingsUtils.putBoolean(SettingsKeys.RANDOM_KEYBOARD, check);
                SecureActivity.this.tvRandom.setText(check ? R.string.s_randomlock_enabled : R.string.s_randomlock_disabled);
            }
        });
        ((CheckBox) findViewById(R.id.check_hidegesture)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton arg0, boolean check) {
                TextView access$1 = SecureActivity.this.tvHideDraw;
                if (check) {
                    access$1.setText(R.string.s_hidden);
                    SettingsUtils.putBoolean(SettingsKeys.KEY_HIDE_GESTURE, check);
                    return;
                }
                access$1.setText(R.string.s_hidden);
                SettingsUtils.putBoolean(SettingsKeys.KEY_HIDE_GESTURE, check);
            }
        });
        ((CheckBox) findViewById(R.id.check_passcode)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton arg0, boolean check) {
                SecureActivity.this.tvPasscode.setText(check ? R.string.s_visible : R.string.s_hidden);
                SettingsUtils.putBoolean(SettingsKeys.SHOW_KEYBOARD_PASSCODE, check);
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        boolean z = true;
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 12) {
            SettingsUtils.putBoolean(SettingsKeys.SHOW_KEYBOARD_PASSCODE, resultCode != -1);
            CheckBox checkBox = (CheckBox) findViewById(R.id.check_passcode);
            if (resultCode == -1) {
                z = false;
            }
            checkBox.setChecked(z);
            this.tvPasscode.setText(resultCode != -1 ? R.string.s_visible : R.string.s_hidden);
        } else if (requestCode == 16 && resultCode == -1) {
            int length = data.getIntExtra("length", 4);
            SettingsUtils.savePasscodeLengthValue(length);
            this.tvLength.setText(new StringBuilder(String.valueOf(length)).append(" Digit").toString());
        }
    }

    protected void onResume() {
        super.onResume();
    }

    public void onBackPressed(View v) {
        onBackPressed();
    }

    public void onItemClicked(View v) {
        if (v instanceof RelativeLayout) {
            RelativeLayout rel = (RelativeLayout) v;
            for (int i = 0; i < rel.getChildCount(); i++) {
                if (rel.getChildAt(i) instanceof CheckBox) {
                    ((CheckBox) rel.getChildAt(i)).toggle();
                    return;
                }
            }
        }
        switch (v.getId()) {
            case R.id.rel_change_gesture:
                startActivityForResult(new Intent(this, GestureLockActivity.class).putExtra("verify_n_create", true), 14);
                return;
            case R.id.rel_change_gesture_color:
                ColorDialogFragment.showColorPicker(this, "gesture_color", SettingsUtils.getGestureColor(), new IOnColorSelectedListener() {
                    @Override
                    public void onColorSelected(DialogFragment fragment, int color) {
                        SettingsUtils.saveGestureColor(color);
                    }
                });
                return;
            case R.id.rel_change_gesturelevel:
                onDifficultyLength(v);
                return;
            case R.id.rel_change_passcode:
                startActivityForResult(new Intent(this, PINActivity.class).putExtra("verify_n_create", true), 15);
                return;
            case R.id.rel_passcode_legth:
                onPasswordLength(v);
                return;
            default:
                return;
        }
    }

    private void onPasswordLength(View v) {
        int index = SettingsUtils.getPasscodeLengthValue() - 4;
        Builder mBuilder = new Builder(this);
        mBuilder.setTitle("Passcode Digit Length");
        mBuilder.setPositiveButton("Cancel", null);
        mBuilder.setSingleChoiceItems(new String[]{"4 Digit", "5 Digit", "6 Digit"}, index, new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int newvalue = which + 4;
                if (SettingsUtils.getRecoveryPasscode(newvalue) == null) {
                    SecureActivity.this.startActivityForResult(new Intent(SecureActivity.this, PINActivity.class).putExtra("length", newvalue), 16);
                } else {
                    SettingsUtils.savePasscodeLengthValue(newvalue);
                    SecureActivity.this.tvLength.setText(new StringBuilder(String.valueOf(newvalue)).append(" Digit").toString());
                }
                dialog.dismiss();
            }
        });
        mBuilder.create().show();
    }

    private void onDifficultyLength(View v) {
        int index = SettingsUtils.getInt(SettingsKeys.KEY_GESTURE_LEVEL, 1);
        Builder mBuilder = new Builder(this);
        mBuilder.setTitle("Gesture Matching Accuracy");
        mBuilder.setPositiveButton("Cancel", null);
        mBuilder.setSingleChoiceItems(new String[]{"Easy", "Medium", "Hard"}, index, new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SettingsUtils.putInt(SettingsKeys.KEY_GESTURE_LEVEL, which);
                dialog.dismiss();
            }
        });
        mBuilder.create().show();
    }
}
