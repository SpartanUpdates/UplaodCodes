
package com.MV.Lyrics.VideoTrim.interfaces;


public interface OnProgressVideoListener {

    void updateProgress(int time, int max, float scale);
}
