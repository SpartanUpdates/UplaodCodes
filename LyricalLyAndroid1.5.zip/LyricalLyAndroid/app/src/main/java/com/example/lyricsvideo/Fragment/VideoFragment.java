package com.example.lyricsvideo.Fragment;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.lyricsvideo.Adapter.VideoInfoAdapter;
import com.example.lyricsvideo.Model.VideoInfo;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.Utils.Utils;
import com.example.lyricsvideo.activity.MainActivity;
import com.example.lyricsvideo.application.App;
import com.example.lyricsvideo.listener.HidingScrollListener;
import com.mlsdev.animatedrv.AnimatedRecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;


public class VideoFragment extends Fragment {
    public VideoInfoAdapter videoInfoAdapter;
    public ArrayList<VideoInfo> ThemeListCategoryWise = new ArrayList<>();
    AnimatedRecyclerView rvCategoryWiseTheme;
    float AppCurrentVersion;
    Integer CategoryId = -1;
    String AppId = "13";
    Integer PageId = 1;
    String ThemeCategoryDetailUrl;
    LinearLayout llProgressLoading;
    RelativeLayout rlProgressLoading;
    LinearLayout llInternetCheck;
    Button btnRefresh;
    boolean isLoading = false;
    String offlienResopnseData;
    SharedPreferences pref;
    SharedPreferences ThemeHomePreferences;
    String MY_PREF = "home_preference";
    App application;
    GridLayoutManager gridLayoutManager;
    private String CatId;
    private boolean IsLoadingoffiline = false;
    private boolean IsofflineResopnse = false;

    public static Fragment getInstance(String CategoryDetailUrl, int position) {
        Bundle bundle = new Bundle();
        bundle.putString("CategoryDetailUrl", CategoryDetailUrl);
        bundle.putInt("CategoryId", position);
        VideoFragment tabFragment = new VideoFragment();
        tabFragment.setArguments(bundle);
        return tabFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CategoryId = getArguments().getInt("CategoryId");
        ThemeCategoryDetailUrl = getArguments().getString("CategoryDetailUrl");
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_video, container, false);
        ThemeHomePreferences = getActivity().getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        application = App.getInstance();
        rvCategoryWiseTheme = rootView.findViewById(R.id.rv_videolist);
        llProgressLoading = rootView.findViewById(R.id.ll_pdialog);
        rlProgressLoading = rootView.findViewById(R.id.rl_pdialog);
        llInternetCheck = rootView.findViewById(R.id.ll_internet);
        btnRefresh = rootView.findViewById(R.id.btn_refresh);
        GetAppVersion();
        GetThemeUrl();
        if (ThemeListCategoryWise != null && ThemeListCategoryWise.size() == 0) {
            if (ThemeHomePreferences.getBoolean("ThemeFirstTime", true)) {
                if (Utils.CheckIntrenetConnectivity(getActivity(), false)) {
                    ThemeHomePreferences.edit().putBoolean("ThemeFirstTime", false).apply();
                    new GetThemeData().execute(ThemeCategoryDetailUrl, AppId, String.valueOf(PageId), String.valueOf(CategoryId));
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation !", Toast.LENGTH_LONG).show();
                }
            } else {
                if (Utils.CheckIntrenetConnectivity(getActivity(), false)) {
                    new GetThemeData().execute(ThemeCategoryDetailUrl, AppId, String.valueOf(PageId), String.valueOf(CategoryId));
                } else {
                    IsofflineResopnse = true;
                    new GetThemeData().execute(ThemeCategoryDetailUrl, AppId, String.valueOf(PageId), String.valueOf(CategoryId));
                }
            }
        } else {
            if (isAdded()) {
                SetThemeAdapter();
            }
        }

        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Utils.CheckIntrenetConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    startActivity(new Intent(getActivity(), MainActivity.class));
                    getActivity().finish();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }

            }
        });
        rvCategoryWiseTheme.addOnScrollListener(new HidingScrollListener() {
            @Override
            public void onHide() {
                MainActivity.rlBottom.animate().translationY(MainActivity.rlBottom.getHeight()).setInterpolator(new AccelerateInterpolator(2)).start();
            }

            @Override
            public void onShow() {
                MainActivity.rlBottom.animate().translationY(0).setInterpolator(new DecelerateInterpolator(2)).start();
            }
        });
        return rootView;
    }

    private void GetAppVersion() {
        PackageManager manager = getActivity().getPackageManager();
        PackageInfo info = null;
        try {
            info = manager.getPackageInfo(getActivity().getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (info != null) {
            AppCurrentVersion = Float.parseFloat(info.versionName);
        }
    }

    public void GetThemeUrl() {
        if (ThemeHomePreferences.getString("hometheme", "homefirsttime").equals("homefirsttime")) {
            SharedPreferences.Editor edit = ThemeHomePreferences.edit();
            edit.putString("hometheme", "ok");
            edit.putString("homethemeurl", ThemeCategoryDetailUrl);
            edit.apply();
        } else if (ThemeHomePreferences.getString("hometheme", null).equals("ok")) {
            ThemeCategoryDetailUrl = (ThemeHomePreferences.getString("homethemeurl", ""));
        }
    }

    public void SetThemeAdapter() {
        RecyclerView recyclerView;
        int i2 = 0;
        gridLayoutManager = new GridLayoutManager(getContext(), 1);
        videoInfoAdapter = new VideoInfoAdapter(getContext(), ThemeListCategoryWise);
        rvCategoryWiseTheme.setLayoutManager(gridLayoutManager);
        rvCategoryWiseTheme.setAdapter(videoInfoAdapter);
        if (App.ThemePosition == -1) {
            recyclerView = this.rvCategoryWiseTheme;
        } else {
            recyclerView = this.rvCategoryWiseTheme;
            i2 = App.ThemePosition;
        }
        Log.e("TAG", "VideoFrg" + i2);
        recyclerView.scrollToPosition(i2);
        rvCategoryWiseTheme.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
                if (!isLoading) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == ThemeListCategoryWise.size() - 1) {
                        loadMore();
                        isLoading = true;
                    }
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(gridLayoutManager.findFirstVisibleItemPosition());
                stringBuilder.append(" ");
                Log.e("onScrolled", stringBuilder.toString());
                App.ThemePosition = gridLayoutManager.findFirstVisibleItemPosition();

            }
        });
        videoInfoAdapter.notifyDataSetChanged();
//        rvCategoryWiseTheme.scheduleLayoutAnimation();
    }

    private void loadMore() {
        PageId++;
        IsLoadingoffiline = true;
        new GetThemeData().execute(ThemeCategoryDetailUrl, AppId, String.valueOf(PageId), String.valueOf(CategoryId));
    }

    public void SetOfflineTheme(Context c, String userObject, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    public void getOfflineTheme(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
    }

    public boolean CheckFileSize(String file, int size) {
        return new File(file).exists() && new File(file).length() >= size;
    }

    @SuppressLint("StaticFieldLeak")
    public class GetThemeData extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
            if (IsLoadingoffiline) {
                rlProgressLoading.setVisibility(View.VISIBLE);
            } else {
                llProgressLoading.setVisibility(View.VISIBLE);
            }
        }

        protected String doInBackground(String... arg0) {
            try {
                URL url = new URL(arg0[0]);
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("app_id", arg0[1]);
                postDataParams.put("page_id", arg0[2]);
                postDataParams.put("category_id", arg0[3]);
                CatId = arg0[3];
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(Utils.INSTANCE.getPostDataString(postDataParams));
                writer.flush();
                writer.close();
                os.close();
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuffer sb = new StringBuffer();
                    String line = "";
                    while ((line = in.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    in.close();
                    return sb.toString();
                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray ThemeCategory = new JSONArray();
                    if (IsofflineResopnse) {
                        String id = pref.getString(CatId, null);
                        if (id != null && !id.equals("")) {
                            getOfflineTheme(getActivity(), CatId);
                            ThemeCategory = new JSONArray(offlienResopnseData);
                        } else {
                            llInternetCheck.setVisibility(View.VISIBLE);
                        }
                    } else {
                        ThemeCategory = new JSONArray(result);
                    }
                    if (IsLoadingoffiline) {
                        Log.e("TAG", "is load more Response: " + PageId);
                    } else {
                        if (getActivity() != null) {
                            if (ThemeCategory.length() > 0) {
                                SetOfflineTheme(getActivity(), ThemeCategory.toString(), CatId);
                            }
                        }
                    }
                    for (int i = 0; i < ThemeCategory.length(); i++) {
                        JSONObject videoInfoJSONObject = ThemeCategory.getJSONObject(i);
                        VideoInfo info = new VideoInfo();
                        Float ThemeCurrentVersion = Float.valueOf(videoInfoJSONObject.getString("main_version"));
                        if (AppCurrentVersion >= ThemeCurrentVersion) {
                            info.setCategory_id(videoInfoJSONObject.getString("main_category_id"));
                            info.setVideoId(videoInfoJSONObject.getString("main_id"));
                            info.setVideoName(videoInfoJSONObject.getString("main_video_name"));
                            info.setSmallThemeImage(videoInfoJSONObject.getString("main_small_image"));
                            info.setLargeThemeImage(videoInfoJSONObject.getString("main_big_image"));
                            info.setPreviewVideoUrl(videoInfoJSONObject.getString("main_preview_video"));
                            info.setContentZipFilePath(videoInfoJSONObject.getString("main_data_file"));
                            String FolderName = videoInfoJSONObject.getString("main_data_file_name");
                            if (FolderName.indexOf(".") > 0)
                                FolderName = FolderName.substring(0, FolderName.lastIndexOf("."));
                            info.setContentZipFolderName(FolderName);
                            info.setContentZipFileName(videoInfoJSONObject.getString("main_data_file_name"));
                            info.setNoOfImages(Integer.parseInt(videoInfoJSONObject.getString("main_number_of_image")));
                            info.setWidth(720);
                            info.setHeight(1280);
                            info.setThemeVersion(videoInfoJSONObject.getString("main_version"));
                            info.setDownloadCount(videoInfoJSONObject.getString("main_download"));
                            info.setShareCount(videoInfoJSONObject.getString("main_share"));
                            info.setViewCount(videoInfoJSONObject.getString("main_view"));
                            info.setCategoryName(videoInfoJSONObject.getString("main_category_name"));
                            info.setVideoCreateDate(videoInfoJSONObject.getString("main_created_at"));
                            info.setPreviewVideoName(info.getPreviewVideoUrl().substring(info.getPreviewVideoUrl().lastIndexOf('/') + 1));
                            info.isAvailableOfflineShareVideo = CheckFileSize(new File(Utils.INSTANCE.getLyricsPreviewVideoPath()).getAbsolutePath() + File.separator + info.getPreviewVideoName(), videoInfoJSONObject.getInt("main_preview_video_size"));
                            info.isAvailableOffline = CheckFileSize(new File(Utils.INSTANCE.getLyricsFolderPath()).getAbsolutePath() + File.separator + info.getContentZipFolderName() + File.separator + info.getContentZipFileName(), videoInfoJSONObject.getInt("main_data_file_size"));
                            info.setPreviewVideoSize(videoInfoJSONObject.getInt("main_preview_video_size"));
                            info.setContentZipFileSize(videoInfoJSONObject.getInt("main_data_file_size"));
                            ThemeListCategoryWise.add(info);
                            if (application.IsNativeAdsLoaded) {
                                if ((ThemeListCategoryWise.size() + 1) % 3 == 0) {
                                    info.setNativeAds(true);
                                    ThemeListCategoryWise.add(info);
                                }
                            }

                        } else {
                            Log.e("TAG", "App Version " + AppCurrentVersion + "Is Lower Then Them Version" + ThemeCurrentVersion);
                        }
                    }
                    isLoading = false;
                    if (isAdded()) {
                        SetThemeAdapter();
                    }
                    rlProgressLoading.setVisibility(View.GONE);
                    llProgressLoading.setVisibility(View.GONE);
                } catch (final JSONException e) {
                    e.printStackTrace();

                }
            } else {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }
        }
    }

}
