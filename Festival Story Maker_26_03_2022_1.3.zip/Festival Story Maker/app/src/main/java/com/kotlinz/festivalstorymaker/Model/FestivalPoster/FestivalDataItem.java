package com.kotlinz.festivalstorymaker.Model.FestivalPoster;

import com.google.gson.annotations.SerializedName;

public class FestivalDataItem {

	@SerializedName("festival_id")
	private int festivalId;

	@SerializedName("festival_name")
	private String festivalName;

	@SerializedName("theme_thumbnail")
	private Object themeThumbnail;

	@SerializedName("updated_at")
	private String updatedAt;

	@SerializedName("festival_date")
	private String festivalDate;

	@SerializedName("created_at")
	private String createdAt;

	@SerializedName("module_name")
	private String moduleName;

	@SerializedName("application_id")
	private String applicationId;

	public void setFestivalId(int festivalId){
		this.festivalId = festivalId;
	}

	public int getFestivalId(){
		return festivalId;
	}

	public void setFestivalName(String festivalName){
		this.festivalName = festivalName;
	}

	public String getFestivalName(){
		return festivalName;
	}

	public void setThemeThumbnail(Object themeThumbnail){
		this.themeThumbnail = themeThumbnail;
	}

	public Object getThemeThumbnail(){
		return themeThumbnail;
	}

	public void setUpdatedAt(String updatedAt){
		this.updatedAt = updatedAt;
	}

	public String getUpdatedAt(){
		return updatedAt;
	}

	public void setFestivalDate(String festivalDate){
		this.festivalDate = festivalDate;
	}

	public String getFestivalDate(){
		return festivalDate;
	}

	public void setCreatedAt(String createdAt){
		this.createdAt = createdAt;
	}

	public String getCreatedAt(){
		return createdAt;
	}

	public void setModuleName(String moduleName){
		this.moduleName = moduleName;
	}

	public String getModuleName(){
		return moduleName;
	}

	public void setApplicationId(String applicationId){
		this.applicationId = applicationId;
	}

	public String getApplicationId(){
		return applicationId;
	}
}