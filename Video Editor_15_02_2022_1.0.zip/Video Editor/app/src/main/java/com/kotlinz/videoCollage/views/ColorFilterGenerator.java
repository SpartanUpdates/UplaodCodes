package com.kotlinz.videoCollage.views;

import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;

public class ColorFilterGenerator {
    private static double[] DELTA_INDEX = new double[]{0.0d, 0.01d, 0.02d, 0.04d, 0.05d, 0.06d, 0.07d, 0.08d, 0.1d, 0.11d, 0.12d, 0.14d, 0.15d, 0.16d, 0.17d, 0.18d, 0.2d, 0.21d, 0.22d, 0.24d, 0.25d, 0.27d, 0.28d, 0.3d, 0.32d, 0.34d, 0.36d, 0.38d, 0.4d, 0.42d, 0.44d, 0.46d, 0.48d, 0.5d, 0.53d, 0.56d, 0.59d, 0.62d, 0.65d, 0.68d, 0.71d, 0.74d, 0.77d, 0.8d, 0.83d, 0.86d, 0.89d, 0.92d, 0.95d, 0.98d, 1.0d, 1.06d, 1.12d, 1.18d, 1.24d, 1.3d, 1.36d, 1.42d, 1.48d, 1.54d, 1.6d, 1.66d, 1.72d, 1.78d, 1.84d, 1.9d, 1.96d, 2.0d, 2.12d, 2.25d, 2.37d, 2.5d, 2.62d, 2.75d, 2.87d, 3.0d, 3.2d, 3.4d, 3.6d, 3.8d, 4.0d, 4.3d, 4.7d, 4.9d, 5.0d, 5.5d, 6.0d, 6.5d, 6.8d, 7.0d, 7.3d, 7.5d, 7.8d, 8.0d, 8.4d, 8.7d, 9.0d, 9.4d, 9.6d, 9.8d, 10.0d};

    public static void adjustHue(ColorMatrix colorMatrix, float f) {
        f = (cleanValue(f, 180.0f) / 180.0f) * 3.1415927f;
        if (f != 0.0f) {
            double d = (double) f;
            f = (float) Math.cos(d);
            float sin = (float) Math.sin(d);
            float[] r2 = new float[25];
            float f2 = (f * -0.715f) + 0.715f;
            r2[1] = (-0.715f * sin) + f2;
            float f3 = (-0.072f * f) + 0.072f;
            r2[2] = (sin * 0.928f) + f3;
            r2[3] = 0.0f;
            r2[4] = 0.0f;
            float f4 = (-0.213f * f) + 0.213f;
            r2[5] = (0.143f * sin) + f4;
            r2[6] = ((0.28500003f * f) + 0.715f) + (0.14f * sin);
            r2[7] = f3 + (-0.283f * sin);
            r2[8] = 0.0f;
            r2[9] = 0.0f;
            r2[10] = f4 + (-0.787f * sin);
            r2[11] = f2 + (0.715f * sin);
            r2[12] = ((f * 0.928f) + 0.072f) + (sin * 0.072f);
            r2[13] = 0.0f;
            r2[14] = 0.0f;
            r2[15] = 0.0f;
            r2[16] = 0.0f;
            r2[17] = 0.0f;
            r2[18] = 1.0f;
            r2[19] = 0.0f;
            r2[20] = 0.0f;
            r2[21] = 0.0f;
            r2[22] = 0.0f;
            r2[23] = 0.0f;
            r2[24] = 1.0f;
            colorMatrix.postConcat(new ColorMatrix(r2));
        }
    }

    public static void adjustBrightness(ColorMatrix colorMatrix, float f) {
        if (cleanValue(f, 100.0f) != 0.0f) {
            colorMatrix.postConcat(new ColorMatrix(new float[]{1.0f, 0.0f, 0.0f, 0.0f, cleanValue(f, 100.0f), 0.0f, 1.0f, 0.0f, 0.0f, cleanValue(f, 100.0f), 0.0f, 0.0f, 1.0f, 0.0f, cleanValue(f, 100.0f), 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f}));
        }
    }

    public static void adjustContrast(ColorMatrix colorMatrix, int i) {
        i = (int) cleanValue((float) i, 100.0f);
        if (i != 0) {
            float f;
            if (i < 0) {
                f = ((float) i) / 100.0f;
            } else {
                float f2 = (float) (i % 1);
                if (f2 == 0.0f) {
                    f = (float) DELTA_INDEX[i];
                } else {
                    double[] dArr = DELTA_INDEX;
                    i <<= 0;
                    f = (((float) dArr[i]) * (1.0f - f2)) + (((float) dArr[i + 1]) * f2);
                }
            }
            f = (f * 127.0f) + 127.0f;
            float[] r0 = new float[25];
            float f3 = f / 127.0f;
            r0[0] = f3;
            r0[1] = 0.0f;
            r0[2] = 0.0f;
            r0[3] = 0.0f;
            float f4 = (127.0f - f) * 0.5f;
            r0[4] = f4;
            r0[5] = 0.0f;
            r0[6] = f3;
            r0[7] = 0.0f;
            r0[8] = 0.0f;
            r0[9] = f4;
            r0[10] = 0.0f;
            r0[11] = 0.0f;
            r0[12] = f3;
            r0[13] = 0.0f;
            r0[14] = f4;
            r0[15] = 0.0f;
            r0[16] = 0.0f;
            r0[17] = 0.0f;
            r0[18] = 1.0f;
            r0[19] = 0.0f;
            r0[20] = 0.0f;
            r0[21] = 0.0f;
            r0[22] = 0.0f;
            r0[23] = 0.0f;
            r0[24] = 1.0f;
            colorMatrix.postConcat(new ColorMatrix(r0));
        }
    }

    public static void adjustSaturation(ColorMatrix colorMatrix, float f) {
        f = cleanValue(f, 100.0f);
        int i = (f > 0.0f ? 1 : (f == 0.0f ? 0 : -1));
        if (i != 0) {
            if (i > 0) {
                f *= 3.0f;
            }
            f = (f / 100.0f) + 1.0f;
            float[] r2 = new float[25];
            float f2 = 1.0f - f;
            float f3 = 0.3086f * f2;
            r2[0] = f3 + f;
            float f4 = 0.6094f * f2;
            r2[1] = f4;
            f2 *= 0.082f;
            r2[2] = f2;
            r2[3] = 0.0f;
            r2[4] = 0.0f;
            r2[5] = f3;
            r2[6] = f4 + f;
            r2[7] = f2;
            r2[8] = 0.0f;
            r2[9] = 0.0f;
            r2[10] = f3;
            r2[11] = f4;
            r2[12] = f2 + f;
            r2[13] = 0.0f;
            r2[14] = 0.0f;
            r2[15] = 0.0f;
            r2[16] = 0.0f;
            r2[17] = 0.0f;
            r2[18] = 1.0f;
            r2[19] = 0.0f;
            r2[20] = 0.0f;
            r2[21] = 0.0f;
            r2[22] = 0.0f;
            r2[23] = 0.0f;
            r2[24] = 1.0f;
            colorMatrix.postConcat(new ColorMatrix(r2));
        }
    }

    protected static float cleanValue(float f, float f2) {
        return Math.min(f2, Math.max(-f2, f));
    }

    public static ColorFilter adjustColor(int i, int i2, int i3, int i4) {
        ColorMatrix colorMatrix = new ColorMatrix();
        adjustHue(colorMatrix, (float) i4);
        adjustContrast(colorMatrix, i2);
        adjustBrightness(colorMatrix, (float) i);
        adjustSaturation(colorMatrix, (float) i3);
        return new ColorMatrixColorFilter(colorMatrix);
    }

    public static ColorFilter adjustBrightnessNew(int i) {
        ColorMatrix colorMatrix = new ColorMatrix();
        adjustBrightness(colorMatrix, (float) i);
        return new ColorMatrixColorFilter(colorMatrix);
    }

    public static ColorFilter adjustContrastNew(int i) {
        ColorMatrix colorMatrix = new ColorMatrix();
        adjustContrast(colorMatrix, i);
        return new ColorMatrixColorFilter(colorMatrix);
    }

    public static ColorFilter adjustSaturationNew(int i) {
        ColorMatrix colorMatrix = new ColorMatrix();
        adjustSaturation(colorMatrix, (float) i);
        return new ColorMatrixColorFilter(colorMatrix);
    }

    public static ColorFilter adjustHueNew(int i) {
        ColorMatrix colorMatrix = new ColorMatrix();
        adjustHue(colorMatrix, (float) i);
        return new ColorMatrixColorFilter(colorMatrix);
    }
}
