package com.esc.dailyrandomfacts.helpers;

import android.content.Context;
import com.esc.dailyrandomfacts.R;
import com.esc.dailyrandomfacts.model.Language;
import java.util.ArrayList;

public class LanguageHelper {
    public static ArrayList<Language> getLanguages(Context context) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Language(context.getString(R.string.language_en), "en"));
        arrayList.add(new Language(context.getString(R.string.language_es), "es"));
        return arrayList;
    }
}
