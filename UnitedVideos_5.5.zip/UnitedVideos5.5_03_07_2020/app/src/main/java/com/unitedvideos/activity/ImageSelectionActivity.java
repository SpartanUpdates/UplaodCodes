package com.unitedvideos.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.unitedvideos.Adapter.AlbumAdapterById;
import com.unitedvideos.Adapter.ImageByAlbumAdapter;
import com.unitedvideos.Adapter.SelectedImageAdapter;
import com.unitedvideos.CropView.imagezoomcrop.demo.ImageCropActivity;
import com.unitedvideos.CropView.imagezoomcrop.demo.Utils;
import com.unitedvideos.Listener.OnItemClickListner;
import com.unitedvideos.Model.ImageModel;
import com.unitedvideos.R;
import com.unitedvideos.WidgetView.EmptyRecyclerView;
import com.unitedvideos.WidgetView.ExpandIconView;
import com.unitedvideos.WidgetView.VerticalSlidingPanel;
import com.unitedvideos.application.MyApplication;
import com.unity3d.player.UnityPlayer;

import java.io.File;
import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ImageSelectionActivity extends Activity implements VerticalSlidingPanel.PanelSlideListener {

    Activity activity = ImageSelectionActivity.this;
    private RecyclerView rvAlbum;
    private RecyclerView rvAlbumImages;
    public static ArrayList<ImageModel> tempImage = new ArrayList();
    private AlbumAdapterById albumAdapter;
    private ImageByAlbumAdapter albumImagesAdapter;
    private SelectedImageAdapter selectedImageAdapter;
    private VerticalSlidingPanel panel;
    private View parent;
    private ExpandIconView expandIcon;
    private Button btnClear;
    Button Done;
    private TextView tvImageCount;

    private MyApplication application;
    public boolean isFromPreview = false;
    public static boolean isForFirst = false;
    private EmptyRecyclerView rvSelectedImage;
    public static final String EXTRA_FROM_PREVIEW = "extra_from_preview";
    int hight;
    int width;
    String isCut;
    public boolean IsUpdateImage;
    ArrayList<String> arrayList;
    String path = "";
    String imageOrientation;
    public static String imagePath;
    ImageModel d;

    String isfrom;


    public ImageSelectionActivity() {
    }


    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_selection);
        application = MyApplication.getInstance();
        isFromPreview = getIntent().hasExtra("extra_from_preview");
        hight = getIntent().getIntExtra("hight", 640);
        width = getIntent().getIntExtra("width", 520);
        isCut = getIntent().getStringExtra("isCut");
        IsUpdateImage = getIntent().getBooleanExtra("Imageupdate", false);
        isfrom = getIntent().getStringExtra("isfrom");

        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ImageSelectionActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        if (IsUpdateImage) {
            Log.e("TAG", "onCreate update: " + IsUpdateImage);
        } else if (application.IsBack) {
            application.IsBack = false;
            application.cropimaglist.clear();
        } else {
            if (application.getSelectedImages().size() > 0) {
                IsFinish("Do you want to used previously selected images ?");
            }
        }
        application.init();
        ImageSelectionActivity.this.bindView();
        ImageSelectionActivity.this.init();
        ImageSelectionActivity.this.addListner();


    }

    public void scrollToPostion(final int pos) {
        rvAlbum.postDelayed(new Runnable() {
            public void run() {
                rvAlbum.scrollToPosition(pos);
            }
        }, 300L);
    }

    @SuppressLint({"NewApi"})
    private void init() {
        albumAdapter = new AlbumAdapterById(this);
        albumImagesAdapter = new ImageByAlbumAdapter(this);
        selectedImageAdapter = new SelectedImageAdapter(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(
                getApplicationContext(), RecyclerView.VERTICAL, false);
        rvAlbum.setLayoutManager(mLayoutManager);
        rvAlbum.setItemAnimator(new DefaultItemAnimator());
        rvAlbum.setAdapter(albumAdapter);

        RecyclerView.LayoutManager gridLayputManager = new GridLayoutManager(
                getApplicationContext(), 3);
        rvAlbumImages.setLayoutManager(gridLayputManager);
        rvAlbumImages.setItemAnimator(new DefaultItemAnimator());
        rvAlbumImages.setAdapter(albumImagesAdapter);

        RecyclerView.LayoutManager gridLayputManager1 = new GridLayoutManager(
                getApplicationContext(), 4);
        rvSelectedImage.setLayoutManager(gridLayputManager1);
        rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        rvSelectedImage.setAdapter(selectedImageAdapter);
        rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));


        if (MyApplication.TotalSelectedImage >= 50) {
            tvImageCount.setText(String.valueOf(application.getSelectedImages()
                    .size()));
        } else {
            tvImageCount.setText(String.valueOf(application.getSelectedImages().size()) + "/" + MyApplication.TotalSelectedImage);
        }
    }

    public void Toolbarfont() {

//        UtilsData.Textfont(activity, tvImageCount);

        final Typeface typeFacecategory = Typeface.createFromAsset(activity.getAssets(), "fonts/Ubuntu-R.ttf");
        btnClear.setTypeface(typeFacecategory);
        Done.setTypeface(typeFacecategory);
    }

    public void IsFinish(String alertmessage) {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        application.cropimaglist.clear();
                        dialog.dismiss();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        if (ImageSelectionActivity.this.application.getSelectedImages().size() != 0) {
                            imagePath = "";
                            application.selectedImages.clear();
                            application.cropimaglist.clear();
                            ImageSelectionActivity.this.clearData();
                        }
                        dialog.dismiss();
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(R.string.exit);
        builder.setMessage(alertmessage)
                .setCancelable(false)
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }

    private void bindView() {
        Done = findViewById(R.id.btnDone);
        tvImageCount = findViewById(R.id.tvCounter);
        expandIcon = findViewById(R.id.settings_drag_arrow);
        rvAlbum = findViewById(R.id.rvAlbum);
        rvAlbumImages = findViewById(R.id.rvImageAlbum);
        rvSelectedImage = findViewById(R.id.rvSelectedImagesList);
        panel = findViewById(R.id.overview_panel);
        panel.setEnableDragViewTouchEvents(true);
        panel.setDragView(findViewById(R.id.settings_pane_header));
        panel.setPanelSlideListener(this);
        parent = findViewById(R.id.default_home_screen_panel);
        btnClear = findViewById(R.id.btnClear);

//        Toolbarfont();
    }


    private String getDropboxIMGSize(final String uri) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(new File(uri).getAbsolutePath(), options);
        final int imageHeight = options.outHeight;
        final int imageWidth = options.outWidth;
        if (imageHeight > imageWidth) {
            return "P";
        }
        return "L";
    }

    private void addListner() {
        this.arrayList = new ArrayList<String>();
        this.Done.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (ImageSelectionActivity.this.application.getSelectedImages().size() != 0) {
                    if (ImageSelectionActivity.this.application.getSelectedImages().size() <= MyApplication.TotalSelectedImage) {
                        int i = 0;
                        for (final ImageModel d : ImageSelectionActivity.this.application.getSelectedImages()) {
                            final String isLandOrPort = ImageSelectionActivity.this.getDropboxIMGSize(d.getImagePath());
                            if (i == 0) {
                                imagePath = d.getImagePath();
                                ImageSelectionActivity.this.imageOrientation = isLandOrPort;
                            } else {
                                imagePath = String.valueOf(String.valueOf(imagePath)) + MyApplication.SPLIT_PATTERN + d.getImagePath();
                                ImageSelectionActivity.this.imageOrientation = String.valueOf(String.valueOf(ImageSelectionActivity.this.imageOrientation)) + "$" + isLandOrPort;
                            }
                            ++i;
                        }
                        if (ImageSelectionActivity.this.isCut.equals("3D")) {
                            final Intent intent_audio = new Intent(ImageSelectionActivity.this, ImageCropActivity.class);
                            intent_audio.putExtra("path", imagePath);
                            intent_audio.putExtra("hw", new int[]{ImageSelectionActivity.this.hight, ImageSelectionActivity.this.width});
                            intent_audio.putExtra("Imageupdate", IsUpdateImage);
                            intent_audio.putExtra("isCut", isCut);
                            intent_audio.putExtra("isfrom", isfrom);
                            ImageSelectionActivity.this.startActivity(intent_audio);
                            ImageSelectionActivity.this.finish();
                            Log.e("TAG", "onClickisCut: " + isCut);
                            Log.e("TAG", "onClickisfrom: " + isfrom);

                        } else {
                            new Utils().startAutoCrop(ImageSelectionActivity.this, imagePath, IsUpdateImage, isCut, isfrom);
//                            finish();
                            Log.e("TAG", "Utils startAutoCropisCut: " + isCut);
                            Log.e("TAG", "Utils startAutoCropIsUpdateImage: " + IsUpdateImage);
                        }
                    } else if (ImageSelectionActivity.this.application.getSelectedImages().size() > MyApplication.TotalSelectedImage) {
                        new StringBuilder("Please Remove ").append(ImageSelectionActivity.this.application.getSelectedImages().size() - MyApplication.TotalSelectedImage).append(" Images").toString();
                    } else {
                        Toast.makeText(ImageSelectionActivity.this, "Selected : " + MyApplication.TotalSelectedImage + " Image", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ImageSelectionActivity.this, "Please Select Image!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        this.btnClear.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (ImageSelectionActivity.this.application.getSelectedImages().size() != 0) {
                    ImageSelectionActivity.this.clearData();
                } else {
                    Toast.makeText(ImageSelectionActivity.this, "Please Select Image!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        this.albumAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                ImageSelectionActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
        this.albumImagesAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                if (MyApplication.TotalSelectedImage >= 50) {
                    ImageSelectionActivity.this.tvImageCount.setText(String.valueOf(ImageSelectionActivity.this.application.getSelectedImages().size()));
                } else {
                    ImageSelectionActivity.this.tvImageCount.setText(String.valueOf(String.valueOf(ImageSelectionActivity.this.application.getSelectedImages().size())) + "/" + MyApplication.TotalSelectedImage);
                }
                ImageSelectionActivity.this.selectedImageAdapter.notifyDataSetChanged();
            }
        });
        this.selectedImageAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                if (MyApplication.TotalSelectedImage >= 50) {
                    ImageSelectionActivity.this.tvImageCount.setText(String.valueOf(ImageSelectionActivity.this.application.getSelectedImages().size()));
                } else {
                    ImageSelectionActivity.this.tvImageCount.setText(String.valueOf(String.valueOf(ImageSelectionActivity.this.application.getSelectedImages().size())) + "/" + MyApplication.TotalSelectedImage);
                }
                ImageSelectionActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
    }


    boolean isPause = false;

    protected void onResume() {
        super.onResume();

        if (isPause) {
            isPause = false;
            if (MyApplication.TotalSelectedImage >= 50) {
                tvImageCount.setText(String.valueOf(application
                        .getSelectedImages().size()));
            } else {
                tvImageCount.setText(String.valueOf(application
                        .getSelectedImages().size()) +
                        "/" +
                        MyApplication.TotalSelectedImage);
            }

            albumImagesAdapter.notifyDataSetChanged();
            selectedImageAdapter.notifyDataSetChanged();
        }
    }

    protected void onPause() {
//        LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
        super.onPause();
        isPause = true;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_selection, menu);
        if (isFromPreview)
            menu.removeItem(R.id.menu_clear);
        return super.onCreateOptionsMenu(menu);
    }


    public void onBackPressed() {
        super.onBackPressed();
        if (panel.isExpanded()) {
            panel.collapsePane();
//            return;
        }
        if (isfrom.equalsIgnoreCase("android")) {
            Log.e("TAG", "Onbackpress Android" + isfrom);
            Intent i = new Intent(activity, HomeActivity.class);
            startActivity(i);
            finish();
        } else if (isfrom.equalsIgnoreCase("unity")) {
            Log.e("TAG", "Onbackpress unity" + isfrom);
            UnityPlayer.UnitySendMessage("UserData", "ResumeUnity", "");
            finish();
        }

    }

    public void onPanelSlide(View panel, final float slideOffset) {
        if (expandIcon != null)
            expandIcon.setFraction(slideOffset, false);
        if (slideOffset >= 0.005f) {
            if ((parent != null) && (parent.getVisibility() != View.VISIBLE)) {
                parent.setVisibility(View.VISIBLE);
            }
        } else if ((parent != null) && (parent.getVisibility() == View.VISIBLE)) {
            parent.setVisibility(View.GONE);
        }
    }


    public void onPanelCollapsed(View panel) {
        if (parent != null) {
            parent.setVisibility(View.VISIBLE);
        }
        selectedImageAdapter.isExpanded = false;
        selectedImageAdapter.notifyDataSetChanged();
    }

    public void onPanelExpanded(View panel) {
        if (parent != null) {
            parent.setVisibility(View.GONE);
        }
        selectedImageAdapter.isExpanded = true;
        selectedImageAdapter.notifyDataSetChanged();
    }


    public void onPanelAnchored(View panel) {
    }


    public void onPanelShown(View panel) {
    }


    private void clearData() {
        ArrayList<ImageModel> selectedImages = application.getSelectedImages();
        for (int i = selectedImages.size() - 1; i >= 0; i--) {
            application.removeSelectedImage(i);
        }
        if (MyApplication.TotalSelectedImage >= 50) {
            tvImageCount.setText("0");
        } else {
            tvImageCount.setText("0/" + MyApplication.TotalSelectedImage);
        }

        selectedImageAdapter.notifyDataSetChanged();
        albumImagesAdapter.notifyDataSetChanged();
    }


}
