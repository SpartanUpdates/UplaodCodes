package com.esc.storymaker.help;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.esc.storymaker.R;

import java.util.ArrayList;

public class Utils {
    public static String name = "Name";
    public static ArrayList<String> packArr = null;
    public static boolean packageisLoad = false;
    Long fixtime = Long.valueOf(86400000);
    Long intervalTIme = Long.valueOf(1200000);
    Context mcontext;
    SharedPreferences myPr;
    String pref_name = "myprefadmob";

    public Utils(Context context) {
        this.mcontext = context;
        this.myPr = context.getSharedPreferences(this.pref_name, 0);
    }



    public boolean checkTimeI() {
        String str = "last_clkTime";
        long currentTimeMillis = System.currentTimeMillis() - this.myPr.getLong(str, 0);
        if (currentTimeMillis != 0 && currentTimeMillis <= this.fixtime.longValue()) {
            return false;
        }
        Editor edit = this.myPr.edit();
        edit.putLong(str, 0);
        edit.apply();
        return true;
    }

    public void setLastTime() {
        long currentTimeMillis = System.currentTimeMillis();
        String str = "last_clkTimeFirst";
        Editor edit;
        if (this.myPr.getLong(str, 0) > 0) {
            edit = this.myPr.edit();
            String str2 = "last_clkTimeSecond";
            edit.putLong(str2, currentTimeMillis);
            edit.commit();
            if (this.myPr.getLong(str2, 0) - this.myPr.getLong(str, 0) < this.intervalTIme.longValue()) {
                currentTimeMillis = System.currentTimeMillis();
                edit = this.myPr.edit();
                edit.putLong("last_clkTime", currentTimeMillis);
                edit.putLong(str2, 0);
                edit.putLong(str, 0);
                edit.apply();
                return;
            }
            Editor edit2 = this.myPr.edit();
            edit2.putLong(str2, 0);
            edit2.putLong(str, System.currentTimeMillis());
            edit2.apply();
            return;
        }
        edit = this.myPr.edit();
        edit.putLong(str, currentTimeMillis);
        edit.apply();
    }

    public boolean checkTimeIf() {
        String str = "last_clkTimef";
        long currentTimeMillis = System.currentTimeMillis() - this.myPr.getLong(str, 0);
        if (currentTimeMillis != 0 && currentTimeMillis <= this.fixtime.longValue()) {
            return false;
        }
        Editor edit = this.myPr.edit();
        edit.putLong(str, 0);
        edit.apply();
        return true;
    }

    public void setLastTimef() {
        long currentTimeMillis = System.currentTimeMillis();
        String str = "last_clkTimefFirst";
        Editor edit;
        if (this.myPr.getLong(str, 0) > 0) {
            edit = this.myPr.edit();
            String str2 = "last_clkTimefSecond";
            edit.putLong(str2, currentTimeMillis);
            edit.commit();
            if (this.myPr.getLong(str2, 0) - this.myPr.getLong(str, 0) < this.intervalTIme.longValue()) {
                currentTimeMillis = System.currentTimeMillis();
                edit = this.myPr.edit();
                edit.putLong("last_clkTimef", currentTimeMillis);
                edit.putLong(str2, 0);
                edit.putLong(str, 0);
                edit.apply();
                return;
            }
            Editor edit2 = this.myPr.edit();
            edit2.putLong(str2, 0);
            edit2.putLong(str, System.currentTimeMillis());
            edit2.apply();
            return;
        }
        edit = this.myPr.edit();
        edit.putLong(str, currentTimeMillis);
        edit.apply();
    }

    public boolean checkTimeB() {
        String str = "last_clkTimeB";
        long currentTimeMillis = System.currentTimeMillis() - this.myPr.getLong(str, 0);
        if (currentTimeMillis != 0 && currentTimeMillis <= this.fixtime.longValue()) {
            return false;
        }
        Editor edit = this.myPr.edit();
        edit.putLong(str, 0);
        edit.apply();
        return true;
    }

    public void setLastTimeB() {
        long currentTimeMillis = System.currentTimeMillis();
        String str = "last_clkTimeBFirst";
        Editor edit;
        if (this.myPr.getLong(str, 0) > 0) {
            edit = this.myPr.edit();
            String str2 = "last_clkTimeBSecond";
            edit.putLong(str2, currentTimeMillis);
            edit.commit();
            if (this.myPr.getLong(str2, 0) - this.myPr.getLong(str, 0) < this.intervalTIme.longValue()) {
                currentTimeMillis = System.currentTimeMillis();
                edit = this.myPr.edit();
                edit.putLong("last_clkTimeB", currentTimeMillis);
                edit.putLong(str2, 0);
                edit.putLong(str, 0);
                edit.apply();
                return;
            }
            Editor edit2 = this.myPr.edit();
            edit2.putLong(str2, 0);
            edit2.putLong(str, System.currentTimeMillis());
            edit2.apply();
            return;
        }
        edit = this.myPr.edit();
        edit.putLong(str, currentTimeMillis);
        edit.apply();
    }

    public boolean checkTimeBf() {
        String str = "last_clkTimeBf";
        long currentTimeMillis = System.currentTimeMillis() - this.myPr.getLong(str, 0);
        if (currentTimeMillis != 0 && currentTimeMillis <= this.fixtime.longValue()) {
            return false;
        }
        Editor edit = this.myPr.edit();
        edit.putLong(str, 0);
        edit.apply();
        return true;
    }

    public void setLastTimeBf() {
        long currentTimeMillis = System.currentTimeMillis();
        String str = "last_clkTimeBfFirst";
        Editor edit;
        if (this.myPr.getLong(str, 0) > 0) {
            edit = this.myPr.edit();
            String str2 = "last_clkTimeBfSecond";
            edit.putLong(str2, currentTimeMillis);
            edit.commit();
            if (this.myPr.getLong(str2, 0) - this.myPr.getLong(str, 0) < this.intervalTIme.longValue()) {
                currentTimeMillis = System.currentTimeMillis();
                edit = this.myPr.edit();
                edit.putLong("last_clkTimeBf", currentTimeMillis);
                edit.putLong(str2, 0);
                edit.putLong(str, 0);
                edit.apply();
                return;
            }
            Editor edit2 = this.myPr.edit();
            edit2.putLong(str2, 0);
            edit2.putLong(str, System.currentTimeMillis());
            edit2.apply();
            return;
        }
        edit = this.myPr.edit();
        edit.putLong(str, currentTimeMillis);
        edit.apply();
    }
}
