package com.MV.Lyrics.Preferance;

import android.content.Context;
import android.content.SharedPreferences;

public class AppPreference {
    public SharedPreferences sharedPreferences;

    public AppPreference(final Context context, final String s, final int n) {
        sharedPreferences = context.getSharedPreferences(s, n);
    }

    public static AppPreference b(final Context context) {
        try {
            return new AppPreference(context, "Crop_preference", 0);
        } catch (Exception ex) {
            return null;
        }
    }

    public boolean a(final String s, final boolean b) {
        return sharedPreferences.getBoolean(s, b);
    }

    public String c(final String s, final String s2) {
        return sharedPreferences.getString(s, s2);
    }

    public int d(final String s, final boolean b) {
        final SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putBoolean(s, b);
        edit.apply();
        return 0;
    }

    public int e(final String s, final String s2) {
        final SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putString(s, s2);
        edit.apply();
        return 0;
    }

    public void f(final String s, final String s2) {
        final SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putString(s, s2);
        edit.apply();
    }

}
