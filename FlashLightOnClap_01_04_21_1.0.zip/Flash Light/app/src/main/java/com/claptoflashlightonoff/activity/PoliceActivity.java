package com.claptoflashlightonoff.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.WindowManager.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.claptoflashlightonoff.kprogresshud.KProgressHUD;
import com.claptoflashlightonoff.util.SoundLevelView;
import com.claptoflashlightonoff.model.SoundMeter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.example.speaktourchtight.R;

import androidx.core.internal.view.SupportMenu;
import androidx.core.view.ViewCompat;

public class PoliceActivity extends Activity {
    private int clrBlue;
    private int clrRed;
    private Intent in;
    private boolean isBlinkOn = false;
    private ImageView ivBlue;
    private ImageView ivRed;
    private LinearLayout llGuide;
    private SoundLevelView mDisplay;
    private Handler mHandler = new Handler();
    private Runnable mPollTask = new Runnable() {
        @Override
        public void run() {
            double amplitude = PoliceActivity.this.mSensor.getAmplitude();
            PoliceActivity.this.updateDisplay("Monitoring Voice...", amplitude);
            if (amplitude > ((double) PoliceActivity.this.mThreshold)) {
                PoliceActivity.this.llGuide.setVisibility(View.GONE);
                PoliceActivity.this.callForHelp();
            }
            PoliceActivity.this.mHandler.postDelayed(PoliceActivity.this.mPollTask, 300);
        }
    };
    private CHandler mRedrawHandler = new CHandler();
    private SoundMeter mSensor;
    private Runnable mSleepTask = new Runnable() {
        @Override
        public void run() {
            PoliceActivity.this.start();
        }
    };
    private TextView mStatusView;
    private int mThreshold;
    private WakeLock mWakeLock;
    private Resources res;
    public boolean sts_blink;
    private TextView tvGuide;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitialAd;
    private int Adid;
    private KProgressHUD hud;

    class CHandler extends Handler {
        int f5i = 1;

        CHandler() {
        }

        public void handleMessage(Message msg) {
            if (this.f5i % 4 == 0) {
                boolean z;
                PoliceActivity.this.ivRed.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
                PoliceActivity.this.ivBlue.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
                PoliceActivity policeActivity = PoliceActivity.this;
                if (PoliceActivity.this.sts_blink) {
                    z = false;
                } else {
                    z = true;
                }
                policeActivity.sts_blink = z;
            } else if (PoliceActivity.this.sts_blink) {
                if (this.f5i % 2 == 0) {
                    PoliceActivity.this.ivBlue.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
                } else {
                    PoliceActivity.this.ivBlue.setBackgroundColor(-16776961);
                }
            } else if (this.f5i % 2 == 0) {
                PoliceActivity.this.ivRed.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
            } else {
                PoliceActivity.this.ivRed.setBackgroundColor(SupportMenu.CATEGORY_MASK);
            }
            this.f5i++;
            PoliceActivity.this.mRedrawHandler.sleep(100);
        }

        public void sleep(long delayMillis) {
            removeMessages(0);
            sendMessageDelayed(obtainMessage(0), delayMillis);
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_police);
        this.in = getIntent();
        bindView();
        loadAd();
        BannerAds();
        init();
        addListner();
        maxBrightness();
    }

    private void loadAd()
    {
        //interstitial FullScreenAd
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onAdClosed()
            {
                switch (Adid)
                {
                    case 100:
                        if (in.getStringExtra("Act").equalsIgnoreCase("MainActivity")) {
                            stop();
                            startActivity(new Intent(PoliceActivity.this, MainActivity.class));
                            finish();
                        }
                        if (in.getStringExtra("Act").equalsIgnoreCase("Tourch")) {
                            stop();
                            startActivity(new Intent(PoliceActivity.this, TourchActivity.class));
                            finish();
                        }
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitialAd = new InterstitialAd(PoliceActivity.this);
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(PoliceActivity.this);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void onStop() {
        super.onStop();
        stop();
    }

    private void callForHelp() {
        if (this.isBlinkOn) {
            try {
                this.mRedrawHandler.removeCallbacksAndMessages(null);
                this.ivBlue.setBackgroundColor(-16776961);
                this.ivRed.setBackgroundColor(SupportMenu.CATEGORY_MASK);
            } catch (Exception e) {
                e.printStackTrace();
            }
            this.isBlinkOn = false;
            return;
        }
        this.mRedrawHandler.sleep(100);
        this.isBlinkOn = true;
    }

    private void bindView() {
        this.tvGuide = (TextView) findViewById(R.id.tvGuide);
        this.llGuide = (LinearLayout) findViewById(R.id.llGuide);
        this.ivRed = (ImageView) findViewById(R.id.ivRed);
        this.ivBlue = (ImageView) findViewById(R.id.ivBlue);
        this.mStatusView = (TextView) findViewById(R.id.status);
        this.mDisplay = (SoundLevelView) findViewById(R.id.volume);
    }

    private void init() {
        this.tvGuide.setTypeface(Typeface.createFromAsset(getAssets(), "majalla.ttf"));
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        if (prefs.getBoolean(getString(R.string.police), false)) {
            this.llGuide.setVisibility(View.GONE);
        } else {
            Editor edit = prefs.edit();
            edit.putBoolean(getString(R.string.police), Boolean.TRUE.booleanValue());
            edit.commit();
        }
        this.res = getResources();
        this.clrRed = this.res.getColor(R.color.red_round);
        this.clrBlue = this.res.getColor(R.color.blue);
        this.mSensor = new SoundMeter();
        this.mWakeLock = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(6, "NoiseAlert");
        start();
        initializeApplicationConstants();
        this.mDisplay.setLevel(0, this.mThreshold);
    }

    private void addListner() {
        this.llGuide.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                PoliceActivity.this.llGuide.setVisibility(View.GONE);
                return false;
            }
        });
    }

    private void initializeApplicationConstants() {
        this.mThreshold = 8;
    }

    private void start() {
        this.mSensor.start();
        if (!this.mWakeLock.isHeld()) {
            this.mWakeLock.acquire();
        }
        this.mHandler.postDelayed(this.mPollTask, 300);
    }

    private void stop() {
        if (this.mWakeLock.isHeld()) {
            this.mWakeLock.release();
        }
        this.mHandler.removeCallbacks(this.mSleepTask);
        this.mHandler.removeCallbacks(this.mPollTask);
        this.mSensor.stop();
        this.mDisplay.setLevel(0, 0);
        updateDisplay("stopped...", 0.0d);
    }

    public void onBackPressed() {
       if (interstitialAd !=null && interstitialAd.isLoaded()){
           try {
               hud = KProgressHUD.create(PoliceActivity.this)
                       .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                       .setLabel("Showing Ads")
                       .setDetailsLabel("Please Wait...");
               hud.show();
           } catch (IllegalArgumentException e) {
               e.printStackTrace();
           } catch (NullPointerException e2) {
               e2.printStackTrace();
           } catch (Exception e3) {
               e3.printStackTrace();
           }

           Handler handler = new Handler();
           handler.postDelayed(new Runnable() {
               @Override
               public void run() {
                   try {
                       hud.dismiss();
                   } catch (IllegalArgumentException e) {
                       e.printStackTrace();

                   } catch (NullPointerException e2) {
                       e2.printStackTrace();
                   } catch (Exception e3) {
                       e3.printStackTrace();
                   }
                   if (interstitialAd != null && interstitialAd.isLoaded()) {
                       Adid = 100;
                       interstitialAd.show();
                   }
               }
           }, 2000);
       }else {
           if (this.in.getStringExtra("Act").equalsIgnoreCase("MainActivity")) {
               stop();
               startActivity(new Intent(this, MainActivity.class));
               finish();
           }
           if (this.in.getStringExtra("Act").equalsIgnoreCase("Tourch")) {
               stop();
               startActivity(new Intent(this, TourchActivity.class));
               finish();
           }
       }
    }

    private void updateDisplay(String text, double n) {
        this.mStatusView.setText(text);
        this.mDisplay.setLevel((int) n, this.mThreshold);
    }

    private void maxBrightness() {
        LayoutParams layoutParams = getWindow().getAttributes();
        layoutParams.screenBrightness = 1.0f;
        getWindow().setAttributes(layoutParams);
        getWindow().addFlags(128);
    }

    protected void onPause() {
        super.onPause();
    }
}
