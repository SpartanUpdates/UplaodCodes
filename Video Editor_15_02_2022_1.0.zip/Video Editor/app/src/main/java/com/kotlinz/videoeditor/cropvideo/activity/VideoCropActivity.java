package com.kotlinz.videoeditor.cropvideo.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.StatFs;
import android.provider.MediaStore.Images;
import android.provider.MediaStore.Video.Media;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.edmodo.cropper.CropImageView;
import com.edmodo.cropper.cropwindow.edge.Edge;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.Utils.UtilCommand;
import com.kotlinz.videoeditor.activity.TrimVideoPrivewActivity;
import com.kotlinz.videoeditor.view.VideoPlayerState;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar;
import com.kotlinz.videoeditor.cropvideo.Utils.FileUtils;
import com.kotlinz.videoeditor.editvideo.activity.EditActivity;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;

@SuppressLint({"WrongConstant"})
public class VideoCropActivity extends AppCompatActivity {

    Activity activity = VideoCropActivity.this;
    TextView Rs;
    static final boolean af = true;
    int A;
    int B;
    String C;
    String D;
    String E;
    String F;
    String G = "00";
    String H;
    TextView S;
    Bitmap U;
    View V;
    VideoPlayerState videoPlayerState = new VideoPlayerState();
    VideoSliceSeekBar videoSliceSeekBar;
    a Y = new a();
    VideoView videoView;
    CropImageView cropImageView;
    float aa;
    float ab;
    float ac;
    float ad;
    long ae;
    private int ag;
    private int ah;
    String b;
    ImageButton btnFree;
    ImageButton LandScape;
    ImageButton Crop3by5;
    ImageButton Crop3By2;
    ImageButton Crop4By5;
    ImageButton Portrait;
    ImageButton Crop3By4;
    ImageButton Square;
    ImageButton Crop2By3;
    String l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;
    int s;
    int t;
    int u;
    int v;
    int w;
    int x;
    int y;
    int z;

    ImageView ivback, ivDone;
    TextView tvToolbarName;

    private class a extends Handler {
        private boolean b;
        private final Runnable c;

        private a() {
            b = false;
            c = new Runnable() {
                public void run() {
                    a.this.a();
                }
            };
        }


        public void a() {
            if (!b) {
                b = VideoCropActivity.af;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            b = false;
            videoSliceSeekBar.videoPlayingProgress(videoView.getCurrentPosition());
            if (!videoView.isPlaying() || videoView.getCurrentPosition() >= videoSliceSeekBar.getRightProgress()) {
                if (videoView.isPlaying()) {
                    videoView.pause();
                    VideoCropActivity.this.V.setBackgroundResource(R.drawable.ic_play_upress);
                    videoView.seekTo(100);
                }
                videoSliceSeekBar.setSliceBlocked(false);
                videoSliceSeekBar.removeVideoStatusThumb();
                return;
            }
            postDelayed(c, 50);
        }
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.videocropactivity);
        PutAnalyticsEvent();
        E = getIntent().getStringExtra("videofilename");
        if (E != null) {
            U = ThumbnailUtils.createVideoThumbnail(E, 1);
        }
        tvToolbarName = findViewById(R.id.tv_app_name);
        ivback = findViewById(R.id.iv_back);
        ivDone = findViewById(R.id.iv_done);
        FrameLayout frameLayout = findViewById(R.id.rl_container);
        LayoutParams layoutParams = (LayoutParams) frameLayout.getLayoutParams();
        x = FileUtils.getScreenWidth();
        layoutParams.width = x;
        layoutParams.height = x;
        frameLayout.setLayoutParams(layoutParams);
        cropImageView = findViewById(R.id.cropperView);
        d();
        e();
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                VideoCrop();
            }
        });
    }

    private void VideoCrop() {
        if (videoView != null && videoView.isPlaying()) {
            videoView.pause();
        }
        cropcommand();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoCropActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    public void c() {
        Intent intent = new Intent(activity, TrimVideoPrivewActivity.class);
        intent.putExtra("videofilename", D);
        startActivity(intent);
        finish();
    }

    public void cropcommand() {
        h();
        getpath();
    }

    @SuppressLint("InvalidWakeLockTag")
    public void getpath() {
        if (w == 90) {
            try {
                o = B;
                int i2 = z;
                u = B;
                v = A;
                m = y;
                n = z;
                s = y;
                t = A;
                ag = m - o;
                ah = v - i2;
                p = q - (ah + i2);
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        } else if (w == 270) {
            try {
                int i3 = B;
                int i4 = z;
                u = B;
                v = A;
                m = y;
                n = z;
                s = y;
                t = A;
                ag = m - i3;
                ah = v - i4;
                o = r - (ag + i3);
                p = i4;
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        } else {
            try {
                o = z;
                p = B;
                u = A;
                v = B;
                m = z;
                n = y;
                s = A;
                t = y;
                ag = u - o;
                ah = n - p;
            } catch (Exception e4) {
                e4.printStackTrace();
            }
        }
        H = String.valueOf(videoPlayerState.getStart() / 1000);
        F = String.valueOf(videoPlayerState.getDuration() / 1000);
        l = E;
        if (l.contains(".3gp") || l.contains(".3GP")) {
            try {
                C = FileUtils.getTargetFileName(this, l.replace(".3gp", ".mp4"));
            } catch (Exception e5) {
                e5.printStackTrace();
            }
        } else if (l.contains(".flv") || l.contains(".FLv")) {
            try {
                C = FileUtils.getTargetFileName(this, l.replace(".flv", ".mp4"));
            } catch (Exception e6) {
                e6.printStackTrace();
            }
        } else if (l.contains(".mov") || l.contains(".MOV")) {
            try {
                C = FileUtils.getTargetFileName(this, l.replace(".mov", ".mp4"));
            } catch (Exception e7) {
                e7.printStackTrace();
            }
        } else if (l.contains(".wmv") || l.contains(".WMV")) {
            try {
                C = FileUtils.getTargetFileName(this, l.replace(".wmv", ".mp4"));
            } catch (Exception e8) {
                e8.printStackTrace();
            }
        } else {
            try {
                C = FileUtils.getTargetFileName(this, l);
            } catch (Exception e9) {
                e9.printStackTrace();
            }
        }
        D = FileUtils.getTargetFileName(this, C);
        StatFs statFs = new StatFs(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath());
        long availableBlocks = ((long) statFs.getAvailableBlocks()) * ((long) statFs.getBlockSize());
        File file = new File(videoPlayerState.getFilename());
        ae = 0;
        ae = file.length() / 1024;
        if ((availableBlocks / 1024) / 1024 >= ae / 1024) {
            ((PowerManager) getSystemService(Context.POWER_SERVICE)).newWakeLock(1, "VK_LOCK").acquire();
            try {
                StringBuilder sb = new StringBuilder();
                sb.append("crop=w=");
                sb.append(ag);
                sb.append(":h=");
                sb.append(ah);
                sb.append(":x=");
                sb.append(o);
                sb.append(":y=");
                sb.append(p);
                a(new String[]{"-y", "-ss", H, "-t", F, "-i", l, "-strict", "experimental", "-vf", sb.toString(), "-r", "15", "-ab", "128k", "-vcodec", "mpeg4", "-acodec", "copy", "-b:v", "2500k", "-sample_fmt", "s16", "-ss", "0", "-t", F, D}, D);
            } catch (Exception unused) {
                File file2 = new File(D);
                if (file2.exists()) {
                    file2.delete();
                    finish();
                    return;
                }
                Toast.makeText(this, "please select any option!", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(getApplicationContext(), "Out of Memory!......", 0).show();
        }
    }

    private void a(String[] strArr, final String str) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();
        String ffmpegCommand = UtilCommand.main(strArr);
        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {

            @Override
            public void apply(final long executionId, final int returnCode) {
                com.arthenica.mobileffmpeg.Config.printLastCommandOutput(Log.INFO);
                progressDialog.dismiss();
                if (returnCode == RETURN_CODE_SUCCESS) {
                    progressDialog.dismiss();
                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(VideoCropActivity.this.D)));
                    sendBroadcast(intent);
                    c();
                    refreshGallery(str);

                } else if (returnCode == RETURN_CODE_CANCEL) {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Toast.makeText(VideoCropActivity.this, "Error Creating Video", Toast.LENGTH_LONG).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                } else {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Toast.makeText(VideoCropActivity.this, "Error Creating Video", Toast.LENGTH_LONG).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }


            }
        });
    }


    @Override
    public void onResume() {
        videoView.seekTo(videoPlayerState.getCurrentTime());
        super.onResume();
    }


    public void onPause() {
        super.onPause();
        videoPlayerState.setCurrentTime(videoView.getCurrentPosition());
    }

    private void d() {
        Rs = findViewById(R.id.left_pointer);
        S = findViewById(R.id.right_pointer);
        videoSliceSeekBar = findViewById(R.id.seek_bar);
        V = findViewById(R.id.buttonply);
        V.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (videoView == null || !videoView.isPlaying()) {
                    V.setBackgroundResource(R.drawable.ic_pause_unpresss);
                } else {
                    V.setBackgroundResource(R.drawable.ic_play_upress);
                }
                g();
            }
        });
        Object lastNonConfigurationInstance = getLastNonConfigurationInstance();
        if (lastNonConfigurationInstance != null) {
            videoPlayerState = (VideoPlayerState) lastNonConfigurationInstance;
        } else {
            videoPlayerState.setFilename(E);
        }
        btnFree = findViewById(R.id.imbtn_custom);
        btnFree.setOnClickListener(setRatioOriginal());
        Crop3by5 = findViewById(R.id.imgbtn_eight);
        Crop3by5.setOnClickListener(setRatioEight());
        Crop3By4 = findViewById(R.id.imgbtn_seven);
        Crop3By4.setOnClickListener(setRatioSeven());
        Crop3By2 = findViewById(R.id.imgbtn_five);
        Crop3By2.setOnClickListener(setRatioFive());
        Crop2By3 = findViewById(R.id.imgbtn_three);
        Crop2By3.setOnClickListener(setRatioThree());
        Square = findViewById(R.id.imgbtn_square);
        Square.setOnClickListener(setRatioSqaure());
        Portrait = findViewById(R.id.imgbtn_port);
        Portrait.setOnClickListener(setRatioPort());
        LandScape = findViewById(R.id.imgbtn_cland);
        LandScape.setOnClickListener(setRatioLand());
        Crop4By5 = findViewById(R.id.imgbtn_45);
        Crop4By5.setOnClickListener(setRatioNine());
    }

    @SuppressLint({"NewApi"})
    private void e() {
        videoView = findViewById(R.id.videoview);
        videoView.setVideoPath(E);
        b = getTimeForTrackFormat(videoView.getDuration(), af);
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        mediaMetadataRetriever.setDataSource(E);
        r = Integer.valueOf(mediaMetadataRetriever.extractMetadata(18)).intValue();
        q = Integer.valueOf(mediaMetadataRetriever.extractMetadata(19)).intValue();
        if (VERSION.SDK_INT > 16) {
            w = Integer.valueOf(mediaMetadataRetriever.extractMetadata(24)).intValue();
        } else {
            w = 0;
        }
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) cropImageView.getLayoutParams();
        if (w == 90 || w == 270) {
            if (r >= q) {
                if (r >= x) {
                    layoutParams.height = x;
                    layoutParams.width = (int) (((float) x) / (((float) r) / ((float) q)));
                } else {
                    layoutParams.width = this.x;
                    layoutParams.height = (int) (((float) q) * (((float) x) / ((float) r)));
                }
            } else if (q >= x) {
                layoutParams.width = x;
                layoutParams.height = (int) (((float) x) / (((float) q) / ((float) r)));
            } else {
                layoutParams.width = (int) (((float) r) * (((float) x) / ((float) q)));
                layoutParams.height = x;
            }
        } else if (r >= q) {
            if (r >= x) {
                layoutParams.width = x;
                layoutParams.height = (int) (((float) x) / (((float) r) / ((float) q)));
            } else {
                layoutParams.width = x;
                layoutParams.height = (int) (((float) q) * (((float) x) / ((float) r)));
            }
        } else if (q >= x) {
            layoutParams.width = (int) (((float) x) / (((float) q) / ((float) r)));
            layoutParams.height = x;
        } else {
            layoutParams.width = (int) (((float) r) * (((float) x) / ((float) q)));
            layoutParams.height = x;
        }
        cropImageView.setLayoutParams(layoutParams);
        cropImageView.setImageBitmap(Bitmap.createBitmap(layoutParams.width, layoutParams.height, Config.ARGB_8888));
        try {
            SearchVideo(getApplicationContext(), E, layoutParams.width, layoutParams.height);
        } catch (Exception unused) {
            unused.printStackTrace();
        }
        videoView.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                videoSliceSeekBar.setSeekBarChangeListener(new VideoSliceSeekBar.SeekBarChangeListener() {

                    public void SeekBarValueChanged(int i, int i2) {
                        if (videoSliceSeekBar.getSelectedThumb() == 1) {
                            videoView.seekTo(videoSliceSeekBar.getLeftProgress());
                        }
                        Rs.setText(getTimeForTrackFormat(i, af));
                        S.setText(getTimeForTrackFormat(i2, af));
                        G = getTimeForTrackFormat(i, af);
                        videoPlayerState.setStart(i);
                        b = getTimeForTrackFormat(i2, af);
                        videoPlayerState.setStop(i2);
                    }
                });
                b = getTimeForTrackFormat(mediaPlayer.getDuration(), af);
                videoSliceSeekBar.setMaxValue(mediaPlayer.getDuration());
                videoSliceSeekBar.setLeftProgress(0);
                videoSliceSeekBar.setRightProgress(mediaPlayer.getDuration());
                videoSliceSeekBar.setProgressMinDiff(0);
                videoView.seekTo(100);
            }
        });
    }


    public void f() {
        btnFree.setBackgroundResource(R.drawable.custom_u);
        Crop3by5.setBackgroundResource(R.drawable.crop_35_u);
        Crop3By4.setBackgroundResource(R.drawable.crop_34_u);
        Crop3By2.setBackgroundResource(R.drawable.crop_32_u);
        Crop2By3.setBackgroundResource(R.drawable.crop_23_u);
        Square.setBackgroundResource(R.drawable.square_u);
        Portrait.setBackgroundResource(R.drawable.portrait_u);
        LandScape.setBackgroundResource(R.drawable.landscape_u);
        Crop4By5.setBackgroundResource(R.drawable.crop_45_u);
    }


    public void g() {
        if (videoView.isPlaying()) {
            videoView.pause();
            videoSliceSeekBar.setSliceBlocked(false);
            videoSliceSeekBar.removeVideoStatusThumb();
            return;
        }
        videoView.seekTo(videoSliceSeekBar.getLeftProgress());
        videoView.start();
        videoSliceSeekBar.videoPlayingProgress(videoSliceSeekBar.getLeftProgress());
        Y.a();
    }

    public static String getTimeForTrackFormat(int i2, boolean z2) {
        String str;
        int i3 = i2 / 60000;
        int i4 = (i2 - ((i3 * 60) * 1000)) / 1000;
        StringBuilder sb = new StringBuilder((!z2 || i3 >= 10) ? "" : "0");
        sb.append(i3 % 60);
        sb.append(":");
        String sb2 = sb.toString();
        if (i4 < 10) {
            StringBuilder sb3 = new StringBuilder(sb2);
            sb3.append("0");
            sb3.append(i4);
            str = sb3.toString();
        } else {
            StringBuilder sb4 = new StringBuilder(sb2);
            sb4.append(i4);
            str = sb4.toString();
        }
        StringBuilder sb5 = new StringBuilder();
        sb5.append("Display Result");
        sb5.append(str);
        Log.e("", sb5.toString());
        return str;
    }

    private void h() {
        if (w == 90 || w == 270) {
            aa = (float) q;
            ab = (float) r;
            ac = (float) cropImageView.getWidth();
            ad = (float) cropImageView.getHeight();
            z = (int) ((Edge.LEFT.getCoordinate() * aa) / ac);
            A = (int) ((Edge.RIGHT.getCoordinate() * aa) / ac);
            B = (int) ((Edge.TOP.getCoordinate() * ab) / ad);
            y = (int) ((Edge.BOTTOM.getCoordinate() * ab) / ad);
            return;
        }
        aa = (float) r;
        ab = (float) q;
        ac = (float) cropImageView.getWidth();
        ad = (float) cropImageView.getHeight();
        z = (int) ((Edge.LEFT.getCoordinate() * aa) / ac);
        A = (int) ((Edge.RIGHT.getCoordinate() * aa) / ac);
        B = (int) ((Edge.TOP.getCoordinate() * ab) / ad);
        y = (int) ((Edge.BOTTOM.getCoordinate() * ab) / ad);
    }

    public OnClickListener setRatioOriginal() {
        return new OnClickListener() {
            @Override
            public void onClick(View view) {
                cropImageView.setFixedAspectRatio(false);
                f();
                btnFree.setBackgroundResource(R.drawable.custom_p);
            }
        };
    }

    public OnClickListener setRatioSqaure() {
        return new OnClickListener() {
            @Override
            public void onClick(View view) {
                cropImageView.setFixedAspectRatio(af);
                cropImageView.setAspectRatio(10, 10);
                f();
                Square.setBackgroundResource(R.drawable.square_p);
            }
        };
    }

    public OnClickListener setRatioPort() {
        return new OnClickListener() {
            @Override
            public void onClick(View view) {
                cropImageView.setFixedAspectRatio(af);
                cropImageView.setAspectRatio(8, 16);
                f();
                Portrait.setBackgroundResource(R.drawable.portrait_p);
            }
        };
    }

    public OnClickListener setRatioLand() {
        return new OnClickListener() {
            @Override
            public void onClick(View view) {
                cropImageView.setFixedAspectRatio(af);
                cropImageView.setAspectRatio(16, 8);
                f();
                LandScape.setBackgroundResource(R.drawable.landscape_p);
            }
        };
    }

    public OnClickListener setRatioThree() {
        return new OnClickListener() {
            @Override
            public void onClick(View view) {
                cropImageView.setFixedAspectRatio(af);
                cropImageView.setAspectRatio(3, 2);
                f();
                Crop2By3.setBackgroundResource(R.drawable.crop_23_p);
            }
        };
    }

    public OnClickListener setRatioFive() {
        return new OnClickListener() {
            @Override
            public void onClick(View view) {
                cropImageView.setFixedAspectRatio(af);
                cropImageView.setAspectRatio(2, 3);
                f();
                Crop3By2.setBackgroundResource(R.drawable.crop_32_p);
            }
        };
    }

    public OnClickListener setRatioSeven() {
        return new OnClickListener() {
            @Override
            public void onClick(View view) {
                cropImageView.setFixedAspectRatio(af);
                cropImageView.setAspectRatio(4, 3);
                f();
                Crop3By4.setBackgroundResource(R.drawable.crop_34_p);
            }
        };
    }

    public OnClickListener setRatioEight() {
        return new OnClickListener() {
            @Override
            public void onClick(View view) {
                cropImageView.setFixedAspectRatio(af);
                cropImageView.setAspectRatio(5, 3);
                f();
                Crop3by5.setBackgroundResource(R.drawable.crop_35_p);
            }
        };
    }

    public OnClickListener setRatioNine() {
        return new OnClickListener() {
            @Override
            public void onClick(View view) {
                cropImageView.setFixedAspectRatio(af);
                cropImageView.setAspectRatio(5, 4);
                f();
                Crop4By5.setBackgroundResource(R.drawable.crop_45_p);
            }
        };
    }

    public void SearchVideo(Context context, String str, int i2, int i3) {
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        String[] strArr = {"_data", "_id"};
        StringBuilder sb = new StringBuilder();
        sb.append("%");
        sb.append(str);
        sb.append("%");
        Cursor managedQuery = managedQuery(uri, strArr, "_data  like ?", new String[]{sb.toString()}, " _id DESC");
        int count = managedQuery.getCount();
        StringBuilder sb2 = new StringBuilder();
        sb2.append("count");
        sb2.append(count);
        Log.e("", sb2.toString());
        if (count > 0) {
            managedQuery.moveToFirst();
            Long.valueOf(managedQuery.getLong(managedQuery.getColumnIndexOrThrow("_id")));
            managedQuery.moveToNext();
        }
    }


    @SuppressLint("ResourceType")
    public void j() {
        new AlertDialog.Builder(this).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                VideoCropActivity.this.finish();
            }
        }).create().show();
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Images.Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Images.Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        File file = new File(E);
        MediaScannerConnection.scanFile(this, new String[]{file.getPath()},
                null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                    }
                });

        if (MyApplication.isShowAd == 1) {
            Intent intent = new Intent(activity, EditActivity.class);
            intent.putExtra("videofilename", E);
            startActivity(intent);
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 9;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, EditActivity.class);
                intent.putExtra("videofilename", E);
                startActivity(intent);
                finish();
            }
        }
    }
}
