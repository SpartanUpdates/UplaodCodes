package com.wavymusic.videolib.libffmpeg;



import com.wavymusic.videolib.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.wavymusic.videolib.libffmpeg.exceptions.FFmpegNotSupportedException;

import java.util.Map;

abstract interface FFmpegInterface
{
  public abstract void loadBinary(FFmpegLoadBinaryResponseHandler paramFFmpegLoadBinaryResponseHandler)
    throws FFmpegNotSupportedException;
  
  public abstract void execute(Map<String, String> paramMap, String[] paramArrayOfString, FFmpegExecuteResponseHandler paramFFmpegExecuteResponseHandler)
    throws FFmpegCommandAlreadyRunningException;
  
  public abstract void execute(String[] paramArrayOfString, FFmpegExecuteResponseHandler paramFFmpegExecuteResponseHandler)
    throws FFmpegCommandAlreadyRunningException;
  
  public abstract String getDeviceFFmpegVersion()
    throws FFmpegCommandAlreadyRunningException;
  
  public abstract String getLibraryFFmpegVersion();
  
  public abstract boolean isFFmpegCommandRunning();
  
  public abstract boolean killRunningProcesses();
  
  public abstract void setTimeout(long paramLong);
}
