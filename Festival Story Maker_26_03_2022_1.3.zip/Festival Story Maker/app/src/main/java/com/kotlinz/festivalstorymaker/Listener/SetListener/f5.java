package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;


public class f5 implements View.OnClickListener {
    public final FrameEditorNewDesign e;

    public f5(final FrameEditorNewDesign e) {
        this.e = e;
    }

    public void onClick(final View view) {
        this.e.u0();
    }
}
