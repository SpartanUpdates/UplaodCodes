package com.kotlinz.videoCollage.other;

import java.io.File;

public class FileModel {
    private File file;
    private String file_name;
    private long last_modify = this.file.lastModified();
    private String path = this.file.getPath();

    public FileModel() {
        this.file = file;
        this.file_name = file.getName();
    }

    public String getFile_name() {
        return this.file_name;
    }

    public void setFile_name(String str) {
        this.file_name = str;
    }

    public long getLast_modify() {
        return this.last_modify;
    }

    public void setLast_modify(long j) {
        this.last_modify = j;
    }

    public File getFile() {
        return this.file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getPath() {
        return this.path;
    }
}
