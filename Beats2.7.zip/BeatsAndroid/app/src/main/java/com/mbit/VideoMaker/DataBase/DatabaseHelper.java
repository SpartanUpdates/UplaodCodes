package com.mbit.VideoMaker.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Model.ThemelModel;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Table name
    private static final String TABLE_NAME = "image";
    // Drop table query
    private static final String DROP_QUERY = "DROP TABLE IF EXIST " + TABLE_NAME;
    // Select all query
    private static final String GET_IMAGE_QUERY = "SELECT * FROM " + TABLE_NAME;
    // image table column names
    private static final String PHOTO_URL = "photo_url";
    private static final String PHOTO = "photo";
    private static final String TITLE = "title";
    // Create table

    private static final String CREATE_TABLE_QUERY = "CREATE TABLE " + TABLE_NAME + "" + "(" +
            PHOTO_URL + "TEXT ," +
            PHOTO + " blob not null," +
            TITLE + " TEXT )";


    // Database Name
    private static final String DB_NAME = "images";
    // Database Version
    private static final int DB_VERSION = 1;

    public DatabaseHelper(final Context context) {
        super(context, Utils.INSTANCE.SaveDBPath() + File.separator + DB_NAME, null, DB_VERSION);
    }

    // Creating tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_QUERY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Upgrading tables
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        // Drop older table if existed
        db.execSQL(DROP_QUERY);
        // Create tables again
        this.onCreate(db);
    }

    //Insert Image
    public void addData(ThemelModel dataModel) {
        Log.e("TAG", "Insert Dtat" + dataModel.getThemeName());
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PHOTO_URL, dataModel.getImage());
        values.put(PHOTO, Utils.getPictureByteOfArray(dataModel.getPicture()));
        values.put(TITLE, dataModel.getThemeid());
        try {
            db.insert(TABLE_NAME, null, values);
        } catch (Exception e) {
            e.printStackTrace();
        }
        db.close();
    }

    public boolean IsFromDb(String model) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = null;
        String checkQuery = "SELECT " + TITLE + " FROM " + TABLE_NAME + " WHERE " + TITLE + "= '" + model + "'";
        cursor = db.rawQuery(checkQuery, null);
        boolean exists = (cursor.getCount() > 0);
        Log.e("TAG", "Record Exist" + exists);
        cursor.close();
        return exists;
    }

    //Get Single Image
    public Bitmap getImage(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cur = db.rawQuery("SELECT photo FROM image WHERE title = ?", new String[]{name});
        if (cur.moveToFirst()) {
            byte[] imgByte = cur.getBlob(cur.getColumnIndex(PHOTO));
            cur.close();
            return BitmapFactory.decodeByteArray(imgByte, 0, imgByte.length);
        }
        if (cur != null && !cur.isClosed()) {
            cur.close();
        }
        return null;
    }

    //Get All Images
    public List<ThemelModel> getAllImages() {
        List<ThemelModel> contactList = new ArrayList<ThemelModel>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(GET_IMAGE_QUERY, null);
        if (cursor.moveToFirst()) {
            do {
                ThemelModel themelModel = new ThemelModel();
                themelModel.setPicture(Utils.INSTANCE.getBitmapFromByte(cursor.getBlob(cursor.getColumnIndex(PHOTO))));
                themelModel.setThemeName(cursor.getString(cursor.getColumnIndex(TITLE)));
                contactList.add(themelModel);
            } while (cursor.moveToNext());
        }
        db.close();
        return contactList;
    }
}
