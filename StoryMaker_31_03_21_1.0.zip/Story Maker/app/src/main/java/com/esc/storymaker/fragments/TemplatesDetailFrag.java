package com.esc.storymaker.fragments;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.esc.storymaker.MainActivity;
import com.esc.storymaker.R;
import com.esc.storymaker.adapters.RvTemplateAdapter;
import com.esc.storymaker.mediapicker.utils.ScreenUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class TemplatesDetailFrag extends Fragment {
    private String category;
    public ProgressBar loader;
    private MainActivity mainActivity;
    private View rootView;
    private RvTemplateAdapter rvTemplateAdapter;
    public RecyclerView rvTemplates;
    public TextView tbTitle;
    ImageView tb_back;
    private ArrayList<String> thumbnails = new ArrayList();

    public static TemplatesDetailFrag getInstance(MainActivity mainActivity, String str) {
        TemplatesDetailFrag templatesDetailFrag = new TemplatesDetailFrag();
        templatesDetailFrag.category = str;
        templatesDetailFrag.mainActivity = mainActivity;
        return templatesDetailFrag;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rootView = layoutInflater.inflate(R.layout.fragment_templates_detail, viewGroup, false);
        this.loader = this.rootView.findViewById(R.id.loader);
        this.rvTemplates = this.rootView.findViewById(R.id.rv_templates);
        this.tbTitle = this.rootView.findViewById(R.id.tb_title);
        this.tb_back = this.rootView.findViewById(R.id.tb_back);
        this.tb_back.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                TemplatesDetailFrag.this.goBack();
            }
        });
        this.tbTitle.setText(this.category);
        setTemplateCategories();
        return this.rootView;
    }

    public void onStart() {
        super.onStart();
        if (this.category == null) {
            getActivity().onBackPressed();
        }
    }

    public void onResume() {
        super.onResume();
        this.rvTemplates.setVisibility(View.VISIBLE);
        this.loader.setVisibility(View.GONE);
    }

    private void setTemplateCategories() {
        try {
            AssetManager assets = getActivity().getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Thumbnails/");
            stringBuilder.append(this.category);
            String[] list = assets.list(stringBuilder.toString());
            list.getClass();
            this.thumbnails = new ArrayList(Arrays.asList(list));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.rvTemplateAdapter = new RvTemplateAdapter(this.mainActivity, this.category, this.thumbnails, ScreenUtil.getScreenWidth(getActivity()));
        this.rvTemplates.setLayoutManager(new GridLayoutManager(getContext(), 2));
        this.rvTemplates.setAdapter(this.rvTemplateAdapter);
    }

    public void goBack() {
        getActivity().onBackPressed();
    }

}
