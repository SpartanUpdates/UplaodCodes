package com.esc.phoneheart.interfaceclass;

import com.esc.phoneheart.animations.AnimationState;

public interface AnimationStateChangedListener {
    void onAnimationStateChanged(AnimationState animationState);
}
