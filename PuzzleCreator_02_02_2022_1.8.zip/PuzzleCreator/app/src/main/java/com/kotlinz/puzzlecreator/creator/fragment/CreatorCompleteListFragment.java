package com.kotlinz.puzzlecreator.creator.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.kotlinz.puzzlecreator.App.MyApplication;
import com.kotlinz.puzzlecreator.activity.BaseFragment;
import com.kotlinz.puzzlecreator.Database.CreatorDB;
import com.kotlinz.puzzlecreator.AppConstant.DataManager;
import com.kotlinz.puzzlecreator.activity.MainActivity;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.model.Credentials;
import com.kotlinz.puzzlecreator.model.DB_Pojo;
import com.kotlinz.puzzlecreator.model.puzzle_get_set;
import com.kotlinz.puzzlecreator.retrofit.APIClient;
import com.kotlinz.puzzlecreator.retrofit.APIInterface;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import nl.dionsegijn.konfetti.models.Shape;
import nl.dionsegijn.konfetti.models.Size;
import okhttp3.ResponseBody;
import pl.droidsonroids.gif.GifImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static com.kotlinz.puzzlecreator.NativeAds.CustomNativeAd.populateUnifiedNativeAdViewbig;
import static com.kotlinz.puzzlecreator.activity.MainActivity.konfettiView;
import static com.kotlinz.puzzlecreator.activity.MainActivity.txtwalletpoint;

public class CreatorCompleteListFragment extends BaseFragment {

    PuzzleAdapter adapter;
    RecyclerView recyclerView;
    ArrayList<puzzle_get_set> PuzzleList = new ArrayList<>();
    private ProgressBar loadingPB;
    private NestedScrollView nestedSV;
    int page = 1, lastpage = 0;
    SwipeRefreshLayout swipeRefreshLayout;
    CreatorDB db_pojo;
    int points = 0;
    LottieAnimationView anim_nodata;

    private String DeletePuzzleId;
   /* public InterstitialAd mInterstitialAd;
    private KProgressHUD hud;*/


    public CreatorCompleteListFragment() {
    }


    public static final CreatorCompleteListFragment newInstance() {
        return new CreatorCompleteListFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_creator_complete_list, container, false);
        db_pojo = new CreatorDB(getActivity());
        recyclerView = view.findViewById(R.id.recyclecomplete);
        loadingPB = view.findViewById(R.id.idPBLoading);
        nestedSV = view.findViewById(R.id.idNestedSV);
        swipeRefreshLayout = view.findViewById(R.id.swiperefresh);
        anim_nodata = view.findViewById(R.id.anim_nodata);
        /*interstitialAd();*/
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (isNetworkAvailable()) {
                    page = 1;
                    getPuzzle();
                } else {
                    noNetworkDialog();
                }
                swipeRefreshLayout.setRefreshing(false);
                swipeRefreshLayout.setEnabled(false);
            }
        });

        nestedSV.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (scrollY == v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight()) {
                    if (isNetworkAvailable()) {
                        if (page <= lastpage) {
                            page++;
                            loadingPB.setVisibility(View.VISIBLE);
                            getPuzzle();
                        } else {
                            loadingPB.setVisibility(View.GONE);
                        }
                    } else {
                        noNetworkDialog();
                        loadingPB.setVisibility(View.GONE);
                    }
                }
            }
        });
        adapter = new PuzzleAdapter(getContext(), PuzzleList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
        return view;
    }


    /*private void interstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(getActivity(), getResources().getString(R.string.InterstitialAd_id), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        requestNewInterstitial();
                                        switch (MyApplication.AdsId) {
                                            case 1:
                                                DeletePuzzleDialog(DeletePuzzleId);
                                                break;
                                        }
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    }
                });

    }

    private void requestNewInterstitial() {
        interstitialAd();
    }*/

    @Override
    public void onResume() {
        super.onResume();
        if (isNetworkAvailable()) {
            getPuzzle();
        } else {
            noNetworkDialog();
        }
    }

    public class PuzzleAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private final int ITEM_TYPE_DATA = 0;
        public final int ITEM_TYPE_AD = 1;
        private final ArrayList<puzzle_get_set> listdata;
        Context context;
        private int AdsIndex = 0;

        public PuzzleAdapter(Context context, ArrayList<puzzle_get_set> listdata) {
            this.listdata = listdata;
            this.context = context;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == ITEM_TYPE_AD) {
                return new NativeAdViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_coustomads, parent, false));
            } else {
                LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
                View listItem = layoutInflater.inflate(R.layout.creator_puzzleview_layout, parent, false);
                PuzzleAdapter.ViewHolder viewHolder = new PuzzleAdapter.ViewHolder(listItem);
                return viewHolder;
            }
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (getItemViewType(position) == ITEM_TYPE_AD) {
                NativeAdViewHolder nativeAdViewHolder = (NativeAdViewHolder) holder;
                if (MyApplication.getInstance().mNativeAds != null) {
                    if (AdsIndex < MyApplication.getInstance().mNativeAds.size()) {
                        NativeAd nativeAd = MyApplication.getInstance().mNativeAds.get(AdsIndex);

                        //Native Ads Not Loaded View Display First
                        View NativeAdsLoading = getLayoutInflater().inflate(R.layout.layout_nativeads_loding, null);
                        nativeAdViewHolder.frameLayout.addView(NativeAdsLoading);

                        //Native Ads Loaded Show Ads With Content
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.row_native_ad_item, null);
                        populateUnifiedNativeAdViewbig(nativeAd, adView);
                        nativeAdViewHolder.frameLayout.removeAllViews();
                        nativeAdViewHolder.frameLayout.addView(adView);
                        AdsIndex++;
                        if (AdsIndex >= MyApplication.getInstance().mNativeAds.size()) {
                            AdsIndex = 0;
                        }
                    }
                }
            } else {
                if (holder instanceof ViewHolder) {
                    ViewHolder PuzzleViewHolder = (ViewHolder) holder;
                    puzzle_get_set puzzle = listdata.get(position);
                    PuzzleViewHolder.ledit.setVisibility(View.GONE);
                    PuzzleViewHolder.ldelete.setVisibility(View.VISIBLE);
                    PuzzleViewHolder.lshare.setVisibility(View.VISIBLE);
                    PuzzleViewHolder.lreport.setVisibility(View.VISIBLE);

                    if (puzzle.getPuzzleimg() == null || puzzle.getPuzzleimg().equalsIgnoreCase("null") || puzzle.getPuzzleimg().equalsIgnoreCase("")) {
                        PuzzleViewHolder.puzzleimg.setVisibility(View.GONE);
                    } else {
                        PuzzleViewHolder.puzzleimg.setVisibility(View.VISIBLE);
                        Glide.with(context).load(puzzle.getPuzzleimg()).into(PuzzleViewHolder.puzzleimg);
                    }

                    PuzzleViewHolder.lans.removeAllViews();

                    for (int i = 0; i < puzzle.getOptions().size(); i++) {
                        TextView textView = new TextView(context);
                        textView.setText(puzzle.getOptions().get(i));
                        textView.setBackground(getResources().getDrawable(R.drawable.eclips));

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            textView.setTypeface(getResources().getFont(R.font.poppins_medium));
                        }

                        textView.setPadding(10, 20, 10, 20);
                        textView.setTextColor(getResources().getColor(R.color.mcq_color));
                        textView.setTextSize(15);
                        textView.setGravity(Gravity.CENTER);

                        if (puzzle.getTrueans().equalsIgnoreCase(puzzle.getOptions().get(i))) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                textView.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.green)));
                                textView.setTextColor(Color.WHITE);
                            }

                        } else {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                textView.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.red)));
                                textView.setTextColor(Color.WHITE);
                            }
                        }
                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        );

                        params.setMargins(15, 5, 15, 5);
                        textView.setLayoutParams(params);
                        PuzzleViewHolder.lans.addView(textView);
                    }

                    PuzzleViewHolder.txtquestion.setText(puzzle.getQuestion());

                    if (puzzle.getLevel().equalsIgnoreCase("high")) {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.high));
                    } else if (puzzle.getLevel().equalsIgnoreCase("medium")) {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.medium));
                    } else {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.low));
                    }

                    PuzzleViewHolder.lshare.setOnClickListener(new View.OnClickListener() {
                        @RequiresApi(api = Build.VERSION_CODES.O)
                        @Override
                        public void onClick(View view) {
                            String ans;
                            if (puzzle.getPuzzletype().equalsIgnoreCase("manual")) {
                                ans = "Type Answer manually";
                            } else {
                                ans = String.join("\n=> ", puzzle.getOptions());
                            }
                            Bundle params = new Bundle();
                            mFirebaseAnalytics.logEvent("Share_Puzzle", params);
                            String text = "Hey ! \n" +
                                    "\n" +
                                    "Solve this puzzle\n "
                                    + "----------------------------\n"
                                    + puzzle.getQuestion() + "\n"
                                    + "----------------------------\n=> "
                                    + ans
                                    + "\n----------------------------\n" +
                                    " from  https://play.google.com/store/apps/details?id=" + getActivity().getPackageName() + " and earn points";
                            Intent shareIntent = new Intent();
                            shareIntent.setAction(Intent.ACTION_SEND);
                            shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                            shareIntent.setType("text/*");
                            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(shareIntent, "Share Puzzle..."));

                        }
                    });

                    PuzzleViewHolder.txtquestion.setText(puzzle.getQuestion());

                    PuzzleViewHolder.lreport.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            showerrorDialog("Report", "Total View By :  " + puzzle.getTotal_view() + "\n" +
                                    "\n"
                                    + "Total Solve By :  " + puzzle.getSolvecount());
                            Bundle params = new Bundle();
                            params.putString("User_Type", sessionManager.getUserType());
                            params.putString("View_Report", "view");
                            mFirebaseAnalytics.logEvent("Creator_Puzzle_Report", params);
                        }
                    });

                    PuzzleViewHolder.ldelete.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            /*if (mInterstitialAd != null) {
                                try {
                                    hud = KProgressHUD.create(getActivity()).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                                    hud.show();
                                } catch (IllegalArgumentException e) {
                                    e.printStackTrace();
                                } catch (NullPointerException e2) {
                                    e2.printStackTrace();
                                } catch (Exception e3) {
                                    e3.printStackTrace();
                                }
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            hud.dismiss();
                                        } catch (IllegalArgumentException e) {
                                            e.printStackTrace();

                                        } catch (NullPointerException e2) {
                                            e2.printStackTrace();
                                        } catch (Exception e3) {
                                            e3.printStackTrace();
                                        }
                                        if (mInterstitialAd != null) {
                                            MyApplication.AdsId = 1;
                                            DeletePuzzleId = puzzle.getId();
                                            mInterstitialAd.show(getActivity());
                                        }
                                    }
                                }, 2000);
                            } else {
                                DeletePuzzleDialog(puzzle.getId());
                            }*/
                            DeletePuzzleDialog(puzzle.getId());
                        }
                    });
                }
            }
        }

        @Override
        public int getItemViewType(int position) {
            if ((position > 0) && ((position + 1) % 2 == 0) && MyApplication.getInstance().IsNativeAdsLoaded) {
                return ITEM_TYPE_AD;
            } else {
                return ITEM_TYPE_DATA;
            }
        }

        @Override
        public int getItemCount() {
            return listdata.size();
        }

        public class NativeAdViewHolder extends RecyclerView.ViewHolder {
            FrameLayout frameLayout;

            public NativeAdViewHolder(View view) {
                super(view);
                frameLayout = view.findViewById(R.id.fl_adplaceholder);
            }
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ImageView puzzleimg, imglevel;
            public TextView txtquestion;
            public LinearLayout lreport, ledit, lshare, ldelete;
            CardView cardimg;
            GridLayout lans;

            public ViewHolder(View itemView) {
                super(itemView);
                puzzleimg = itemView.findViewById(R.id.img);

                cardimg = itemView.findViewById(R.id.cardimg);
                lans = itemView.findViewById(R.id.lans);
                imglevel = itemView.findViewById(R.id.imglevel);

                txtquestion = itemView.findViewById(R.id.txtquestion);


                ledit = itemView.findViewById(R.id.ledit);
                lshare = itemView.findViewById(R.id.lshare);
                ldelete = itemView.findViewById(R.id.ldelete);
                lreport = itemView.findViewById(R.id.lreport);

            }
        }
    }

    private void DeletePuzzleDialog(String PuzzleId) {
        Dialog dialog = new Dialog(getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_layout);
        TextView txtmain = dialog.findViewById(R.id.txtmain);
        TextView txtmsg = dialog.findViewById(R.id.text_dialog);
        ImageView btnok = dialog.findViewById(R.id.btn_dialog);
        GifImageView gimg = dialog.findViewById(R.id.anim_tryagain);
        txtmain.setText("Are You Sure?");
        txtmsg.setText("Are you sure for delete this Puzzle??");
        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                DeletePuzzle(PuzzleId);
            }
        });
        dialog.show();
    }

    private void ManagePoints(String status, String point) {
        Credentials manage = new Credentials();
        manage.status = status;
        manage.points = point;
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).Manage_Points(sessionManager.getToken(), manage);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> res) {
                if (res.code() == 200) {
                    try {
                        String result = res.body().string();
                        JSONObject obj = new JSONObject(result);
                        if (obj.getBoolean("status")) {
                            cancel_dialog();
                            if (status.equalsIgnoreCase("1")) {
                                konfettiView.build()
                                        .addColors(Color.YELLOW, Color.GREEN, Color.MAGENTA)
                                        .setDirection(0.0, 359.0)
                                        .setSpeed(1f, 5f)
                                        .setFadeOutEnabled(true)
                                        .setTimeToLive(2000L)
                                        .addShapes(Shape.Circle.INSTANCE, Shape.Circle.INSTANCE)
                                        .addSizes(new Size(12, 5f))
                                        .setPosition(konfettiView.getX() + konfettiView.getWidth() / 2, konfettiView.getY() + konfettiView.getHeight() / 3)
                                        .burst(500);

                                MainActivity.coincollect.setVisibility(View.VISIBLE);
                                MainActivity.coincollect.playAnimation();
                            }
                            points = 0;
                            sessionManager.setUserPoints(obj.getJSONObject("response").getString("user_points"));
                            MainActivity.txtpoint.setText(sessionManager.getUserPoints() + " Points");
                            txtwalletpoint.setText(sessionManager.getUserPoints() + " Points");

                        } else {
                            cancel_dialog();
                            showerrorDialog("Failed", obj.getString("message"));
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                    cancel_dialog();
                } else {
                    try {
                        JSONObject obj = new JSONObject(res.errorBody().string());
                        cancel_dialog();
                        showerrorDialog("Failed", obj.getString("message"));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }

    private void getPuzzle() {
        if (page == 1) {
            PuzzleList.clear();
            showProgressDialog();
        }
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).GetCreatorPuzzle(sessionManager.getToken(), "complete", page);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        Log.e("Responce", "........" + res);
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            JSONObject resp = jsonObject.getJSONObject("response");

                            JSONArray puzzleData = resp.getJSONArray("puzzle_data");
                            if (page == 1 && puzzleData.length() == 0) {
                                cancel_dialog();
                                swipeRefreshLayout.setVisibility(View.GONE);
                                anim_nodata.setVisibility(View.VISIBLE);

                            } else {
                                anim_nodata.setVisibility(View.GONE);
                                swipeRefreshLayout.setVisibility(View.VISIBLE);

                                for (int i = 0; i < puzzleData.length(); i++) {
                                    JSONObject pzl = puzzleData.getJSONObject(i);
                                    puzzle_get_set puzzle = new puzzle_get_set();
                                    puzzle.setId(pzl.getString("puzzle_id"));
                                    puzzle.setQuestion(pzl.getString("question"));
                                    puzzle.setPuzzletype(pzl.getString("question_type"));
                                    puzzle.setPuzzleimg(pzl.getString("image"));
                                    puzzle.setTrueans(pzl.getString("true_answer"));
                                    puzzle.setHint(pzl.getString("hint"));
                                    puzzle.setLevel(pzl.getString("difficulty_level"));
                                    JSONArray option = pzl.getJSONArray("options");
                                    List<String> opt = new ArrayList<>();
                                    for (int j = 0; j < option.length(); j++) {
                                        opt.add(option.getString(j));
                                    }
                                    puzzle.setOptions(opt);
                                    puzzle.setReviewerstatus(pzl.getString("reviewer_status"));
                                    puzzle.setReason(pzl.getString("reason"));
                                    puzzle.setTotal_view(pzl.getJSONObject("puzzle_report").getString("total_view"));
                                    puzzle.setSolvecount(pzl.getJSONObject("puzzle_report").getString("solve_count"));
                                    if (!db_pojo.IfRecordExist(puzzle.getId())) {

                                        if (puzzle.getLevel().equalsIgnoreCase("high")) {
                                            points += Integer.parseInt(DataManager.high_point);
                                        } else if (puzzle.getLevel().equalsIgnoreCase("medium")) {
                                            points += Integer.parseInt(DataManager.medium_point);
                                        } else {
                                            points += Integer.parseInt(DataManager.low_point);
                                        }

                                        int viewby = Integer.parseInt(pzl.getJSONObject("puzzle_report").getString("total_view"));
                                        int solveby = Integer.parseInt(pzl.getJSONObject("puzzle_report").getString("solve_count"));
                                        int falseans = viewby - solveby;
                                        if (solveby > 0) {
                                            points += Integer.parseInt(DataManager.low_ans_point);
                                        }
                                        if (falseans > 0) {
                                            points += (Integer.parseInt(DataManager.low_ans_point) * falseans);
                                        }
                                        db_pojo.addData(new DB_Pojo(puzzle.getId(), puzzle.getTotal_view(), puzzle.getSolvecount(), "true"));
                                    } else {
                                        List<DB_Pojo> pojo = db_pojo.viewData(pzl.getString("puzzle_id"));
                                        int viewby = Integer.parseInt(pojo.get(0).getViewby()) - Integer.parseInt(pzl.getJSONObject("puzzle_report").getString("total_view"));
                                        int solveby = Integer.parseInt(pojo.get(0).getSolveby()) - Integer.parseInt(pzl.getJSONObject("puzzle_report").getString("solve_count"));
                                        int falseans = viewby - solveby;
                                        if (solveby > 0) {
                                            points += Integer.parseInt(DataManager.low_ans_point);
                                        }
                                        if (falseans > 0) {
                                            points += (Integer.parseInt(DataManager.low_ans_point) * falseans);
                                        }

                                    }
                                    PuzzleList.add(puzzle);
                                    if (isNetworkAvailable() && MyApplication.getInstance().IsNativeAdsLoaded) {
                                        if ((PuzzleList.size() + 1) % 2 == 0) {
                                            puzzle.setNativeAds(true);
                                            PuzzleList.add(null);
                                        }
                                    }
                                }
                                if (points > 0) {
                                    ManagePoints("1", String.valueOf(points));
                                }
                                cancel_dialog();
                                adapter.notifyDataSetChanged();
                                swipeRefreshLayout.setEnabled(true);

                                lastpage = resp.getInt("last_page");
                                if (page > lastpage) {
                                    Toast.makeText(getActivity(), "No more data..", Toast.LENGTH_SHORT).show();
                                    cancel_dialog();
                                    loadingPB.setVisibility(View.GONE);
                                    return;
                                }
                            }
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                    cancel_dialog();
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        swipeRefreshLayout.setEnabled(true);

                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }

    private void DeletePuzzle(String puzzleid) {
        showProgressDialog();
        Credentials delete = new Credentials();
        delete.puzzle_id = puzzleid;
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).Delete(sessionManager.getToken(), delete);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> res) {
                if (res.code() == 200) {
                    try {
                        String result = res.body().string();
                        JSONObject obj = new JSONObject(result);
                        if (obj.getBoolean("status")) {
                            Bundle params = new Bundle();
                            params.putString("Delete_Completed_Puzzle", puzzleid);
                            mFirebaseAnalytics.logEvent("Delete_Puzzle", params);
                            cancel_dialog();

                            showSuccessDialog("Success", obj.getString("message"));
                        } else {
                            cancel_dialog();
                            showerrorDialog("Failed", obj.getString("message"));
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                    cancel_dialog();
                } else {
                    try {
                        JSONObject obj = new JSONObject(res.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }

    public void showSuccessDialog(String main, String Msg) {

        Dialog dialog = new Dialog(getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_layout);
        TextView txtmain = dialog.findViewById(R.id.txtmain);
        TextView txtmsg = dialog.findViewById(R.id.text_dialog);
        ImageView btnok = dialog.findViewById(R.id.btn_dialog);
        GifImageView gimg = dialog.findViewById(R.id.anim_tryagain);
        gimg.setImageResource(R.drawable.success_anim);
        txtmain.setVisibility(View.GONE);
        txtmain.setText(main);
        txtmsg.setText(Msg);
        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                getPuzzle();
            }
        });
        dialog.show();

    }
}