package com.unikapp.faceappeditor.Splashscreen;

import android.app.Application;
import android.content.Context;
import android.text.TextUtils;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;

public class MyApplication extends Application {
    private static MyApplication instance;
    private RequestQueue mRequestQueue;
    private static Context context;


    public static final String TAG = MyApplication.class.getSimpleName();

    public static MyApplication getInstance() {
        return MyApplication.instance;
    }


    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }

        return mRequestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req, String tag) {
        req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
        getRequestQueue().add(req);
    }


    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        context = getApplicationContext();
        AudienceNetworkAds.initialize(this);
        AdSettings.addTestDevice("b4a602d2-8986-4c90-93b3-1fb9cbc2c4d3");
    }

    public static Context getContext() {
        return context;
    }


}
