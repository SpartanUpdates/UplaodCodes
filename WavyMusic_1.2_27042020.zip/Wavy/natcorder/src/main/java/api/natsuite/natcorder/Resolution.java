package api.natsuite.natcorder;

import java.io.Serializable;

public class Resolution implements Serializable {
    private final int width;
    private final int height;

    public Resolution(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public int width() {
        return this.width;
    }

    public int height() {
        return this.height;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        } else if (o != null && this.getClass() == o.getClass()) {
            Resolution that = (Resolution)o;
            if (this.height != that.height) {
                return false;
            } else {
                return this.width == that.width;
            }
        } else {
            return false;
        }
    }

    public int hashCode() {
        int result = this.width;
        result = 31 * result + this.height;
        return result;
    }
}