package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.Room;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface RtoQuestionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertQuestion(QuestionModel questionModel);

    @Query("select * from questionmodel ORDER BY RANDOM() LIMIT 1")
    List<QuestionModel> getQuestionsList();
}
