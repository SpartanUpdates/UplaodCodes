package com.esc.gesturelockscreen.Service;

import android.app.*;
import java.util.*;
import android.os.*;
import android.telephony.*;
import android.content.*;

public class LockStateService extends Service
{
  private static Object mObject;
  private boolean enabled;
  private BroadcastReceiver mBroadcastReceiver;
  private boolean mIsCallActive;
  private KeyguardManager mKeyguardManager;
  private KeyguardManager.KeyguardLock mLock;
  private PhoneListener mPhoneListener;
  private TelephonyManager mTelephoneManager;

  static {
    LockStateService.mObject = new Object();
  }

  public LockStateService() {
    this.enabled = true;
    this.mIsCallActive = false;
  }

  static boolean checkAndStartService(final Context context, final Class<?> clazz) {
    final Iterator<ActivityManager.RunningServiceInfo> iterator = ((ActivityManager)context.getSystemService(ACTIVITY_SERVICE)).getRunningServices(Integer.MAX_VALUE).iterator();
    while (iterator.hasNext()) {
      if (clazz.getName().equals(iterator.next().service.getClassName())) {
        return true;
      }
    }
    try {
      context.startService(new Intent(context, (Class)clazz));
      return false;
    }
    catch (Exception ex) {
      return false;
    }
  }

  private void onCall(final int n) {
    if (n == 0) {
      if (this.mIsCallActive) {
        this.sendBroadcast(new Intent("SHOW_LOCK").setPackage(this.getPackageName()));
      }
      this.mIsCallActive = false;
    }
    else if (n == 1) {
      this.mIsCallActive = true;
      this.sendBroadcast(new Intent("HIDE_LOCK").setPackage(this.getPackageName()));
    }
  }

  private void onScreenOff(final Context context) {
    if (!this.mIsCallActive && this.mTelephoneManager.getCallState() != 2) {
      this.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
      if (checkAndStartService((Context)this, ScreenLockService.class)) {
        this.sendBroadcast(new Intent("SCREEN_OFF").setPackage(context.getPackageName()));
      }
    }
  }

  public IBinder onBind(final Intent intent) {
    return null;
  }

  public void onCreate() {
    super.onCreate();
    this.mKeyguardManager = (KeyguardManager)this.getSystemService(KEYGUARD_SERVICE);
    (this.mLock = this.mKeyguardManager.newKeyguardLock("GESTURE_LOCK_KEYGAURD")).disableKeyguard();
    this.enabled = true;
    this.mTelephoneManager = (TelephonyManager)this.getSystemService(TELEPHONY_SERVICE);
    this.mPhoneListener = new PhoneListener();
    this.mTelephoneManager.listen((PhoneStateListener)this.mPhoneListener, 32);
    final IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.intent.action.SCREEN_OFF");
    intentFilter.addAction("DISABLED");
    intentFilter.addAction("ENABLED");
    this.registerReceiver(this.mBroadcastReceiver = new BroadcastReceiver() {
      public void onReceive(final Context context, final Intent intent) {
        final String action = intent.getAction();
        if (action.endsWith("ENABLED")) {
          LockStateService.this.enabled = true;
        }
        else {
          if (action.contains("DISABLED")) {
            LockStateService.this.enabled = false;
            LockStateService.this.stopSelf();
            return;
          }
          if (action.equals("android.intent.action.SCREEN_OFF") && LockStateService.this.enabled) {
            LockStateService.this.onScreenOff(context);
          }
        }
      }
    }, intentFilter);
  }

  public void onDestroy() {
    if (this.mBroadcastReceiver != null) {
      this.unregisterReceiver(this.mBroadcastReceiver);
      this.mBroadcastReceiver = null;
    }
    if (this.mLock != null) {
      this.mLock.reenableKeyguard();
    }
    super.onDestroy();
  }

  public int onStartCommand(final Intent intent, final int n, final int n2) {
    super.onStartCommand(intent, n, n2);
    return START_STICKY;
  }

  class PhoneListener extends PhoneStateListener
  {
    public void onCallStateChanged(final int n, final String s) {
      super.onCallStateChanged(n, s);
      synchronized (LockStateService.mObject) {
        LockStateService.this.onCall(n);
      }
    }
  }
}
