package game.kidspop.gk.quiz.info;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

public class mClassUtil {
    public static SQLiteDatabase OpenSQLiteDatabase(Activity activity) {
        SQLiteDatabase sQLiteDatabase = null;
        try {
            sQLiteDatabase = activity.openOrCreateDatabase(activity.getString(R.string.dbName), 0, null);
            return sQLiteDatabase;
        } catch (Exception e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error: \n\n");
            stringBuilder.append(e.toString());
            Toast.makeText(activity, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            return sQLiteDatabase;
        }
    }

    public static SQLiteDatabase OpenSQLiteDatabase_Old_SF(Activity activity) {
        SQLiteDatabase sQLiteDatabase = null;
        try {
            sQLiteDatabase = activity.openOrCreateDatabase(activity.getString(R.string.dbName_Old), 0, null);
            return sQLiteDatabase;
        } catch (Exception e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error: \n\n");
            stringBuilder.append(e.toString());
            Toast.makeText(activity, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            return sQLiteDatabase;
        }
    }

    public static boolean setspv_DatabseVer(Context context, String str) {
        try {
            Editor edit = context.getSharedPreferences("QuizKids", 0).edit();
            edit.putString("DatabseVer", str);
            edit.commit();
            return true;
        } catch (Exception e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error: \n\n");
            stringBuilder.append(e.toString());
            Toast.makeText(context, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public static String getspv_DatabseVer(Context context) {
        return context.getSharedPreferences("QuizKids", 0).getString("DatabseVer", "1");
    }

    public static boolean setspv_DbUpdateQSeenFlag(Context context, String str) {
        try {
            Editor edit = context.getSharedPreferences("QuizKids", 0).edit();
            edit.putString("DbUpdateQSeenFlag", str);
            edit.commit();
            return true;
        } catch (Exception e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error: \n\n");
            stringBuilder.append(e.toString());
            Toast.makeText(context, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public static String getspv_DbUpdateQSeenFlag(Context context) {
        return context.getSharedPreferences("QuizKids", 0).getString("DbUpdateQSeenFlag", "N");
    }

    public static boolean setspv_CountQuizPlay(Context context, Integer num) {
        try {
            Editor edit = context.getSharedPreferences("QuizKids", 0).edit();
            edit.putInt("CountQuizPlay", num.intValue());
            edit.commit();
            return true;
        } catch (Exception e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error: \n\n");
            stringBuilder.append(e.toString());
            Toast.makeText(context, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public static int getspv_CountQuizPlay(Context context) {
        return context.getSharedPreferences("QuizKids", 0).getInt("CountQuizPlay", 0);
    }

    public static boolean setspv_CountPageView(Context context, Integer num) {
        try {
            Editor edit = context.getSharedPreferences("QuizKids", 0).edit();
            edit.putInt("CountPageView", num.intValue());
            edit.commit();
            return true;
        } catch (Exception e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error: \n\n");
            stringBuilder.append(e.toString());
            Toast.makeText(context, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public static boolean setspv_PlayerName(Context context, String str) {
        try {
            Editor edit = context.getSharedPreferences("QuizKids", 0).edit();
            edit.putString("PlayerName", str);
            edit.commit();
            return true;
        } catch (Exception e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error: \n\n");
            stringBuilder.append(e.toString());
            Toast.makeText(context, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public static String getspv_PlayerName(Context context) {
        return context.getSharedPreferences("QuizKids", 0).getString("PlayerName", null);
    }

    public static boolean setspv_QueLang(Context context, String str) {
        try {
            Editor edit = context.getSharedPreferences("QuizKids", 0).edit();
            edit.putString("QueLang", str);
            edit.commit();
            return true;
        } catch (Exception e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error: \n\n");
            stringBuilder.append(e.toString());
            Toast.makeText(context, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public static String getspv_QueLang(Context context) {
        return context.getSharedPreferences("QuizKids", 0).getString("QueLang", null);
    }

    public static String getspv_AppVerNew(Context context) {
        return context.getSharedPreferences("QuizKids", 0).getString("AppVerNew", "");
    }
}