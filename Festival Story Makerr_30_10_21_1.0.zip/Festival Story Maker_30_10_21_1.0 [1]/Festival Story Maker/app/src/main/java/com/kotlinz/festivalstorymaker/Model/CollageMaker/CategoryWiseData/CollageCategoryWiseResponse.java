package com.kotlinz.festivalstorymaker.Model.CollageMaker.CategoryWiseData;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class CollageCategoryWiseResponse {

	@SerializedName("data")
	private ArrayList<CollageCategoryWiseData> data;

	@SerializedName("total_records")
	private int totalRecords;

	@SerializedName("status")
	private String status;

	public ArrayList<CollageCategoryWiseData> getData(){
		return data;
	}

	public int getTotalRecords(){
		return totalRecords;
	}

	public String getStatus(){
		return status;
	}
}