package com.mbit.VideoMaker.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.mbit.VideoMaker.Adapter.SongByFolderAdapter;
import com.mbit.VideoMaker.Extra.kprogresshud.KProgressHUD;
import com.mbit.VideoMaker.Fragment.LocalCategoryWiseSongFragment;
import com.mbit.VideoMaker.Model.AllMusicFolders;
import com.mbit.VideoMaker.Model.LocalTrack;
import com.mbit.VideoMaker.Model.MusicFolder;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.SongCrop.controler.Mediacontroler;
import com.mbit.VideoMaker.SongCrop.view.PlayMusicControllerView;
import com.mbit.VideoMaker.View.CustomViewPager;
import com.mbit.VideoMaker.videolib.libffmpeg.Util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class LocalSongActivity extends AppCompatActivity implements PlayMusicControllerView.playmusicControllerinterface {

    public static List<LocalTrack> localTrackList = new ArrayList<>();
    public static AllMusicFolders allMusicFolders;
    public static long h;
    public static long aLong;
    private static PlayMusicControllerView playMusicControllerView;
    private static long r;
    public Mediacontroler mediacontroler;
    public int id;
    public InterstitialAd mInterstitialAd;
    public KProgressHUD hud;
    Activity activity = LocalSongActivity.this;
    NewsPagerAdapterNew adp;
    TextView tvseekchangetime;
    String[] command;
    String FinalSongCropPath;
    TextView tvNoSong;
    RelativeLayout layoutSongCut;
    //    private LinearLayout adContainer;
//    private AdView adView;
    AdRequest adRequest;
    AdView adView;
    private SimpleDateFormat simpleDateFormat;
    private Handler handler = new Handler();
    private ImageView ivplaymusic;
    private boolean n = true;
    private TextView tvselectmusicname;
    private TextView tvplaytime;
    private TabLayout tabLayout;
    private CustomViewPager viewPager;
    private TextView tvendtime;
    private boolean m = true;
    private LocalTrack musicRes;
    private Process process;
    private String output;
    private long timeout;

    static File a(final Context context) {
        return context.getFilesDir();
    }

    public static String b(final Context context) {
        final StringBuilder sb = new StringBuilder(String.valueOf(String.valueOf(a(context).getAbsolutePath())));
        sb.append(File.separator);
        sb.append("ffmpeg");
        return sb.toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_song);
        simpleDateFormat = new SimpleDateFormat("mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "LocalSongActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        getLocalSongs();
        BindView();
        loadAd();
        InterstitialAd();
    }

    private void loadAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

//        adContainer = findViewById(R.id.templateContainer);
//        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
//        adContainer.addView(adView);
//        adView.loadAd();
    }

    public void Music(final LocalTrack musicRes) {
        this.musicRes = musicRes;
        handler.post(new Runnable() {


            public void run() {
                tvselectmusicname.setText(musicRes.m5778d());
                mediacontroler.a(musicRes.c());
                mediacontroler.b();
                if (SongByFolderAdapter.IsSongPlay) {
                    Musicpause();
                } else {
                    Musicplay();
                }
                playMusicControllerView.a(musicRes.e(), musicRes.e());
                playMusicControllerView.a();
            }
        });
        new Thread(new Play()).start();
    }

    public void Musicpause() {
        mediacontroler.f();
        mediacontroler.a(r);
        ivplaymusic.setImageResource(R.drawable.icon_player_pause);
    }

    public void Musicplay() {
        mediacontroler.d();
        r = (long) mediacontroler.c();
        ivplaymusic.setImageResource(R.drawable.icon_player_play);
    }

    public void Getcontent() {
        if (mediacontroler.e()) {
            Musicplay();
        }
        try {
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("audio/*");
            intent.addCategory("android.intent.category.OPENABLE");
            startActivityForResult(intent, 1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void onDestroy() {
        this.adView.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        n = false;
        SongByFolderAdapter.IsSongPlay = false;
        mediacontroler.g();
        super.onDestroy();
    }

    public void onStart() {
        super.onStart();
        if (this.m) {
            mediacontroler = new Mediacontroler(activity);
            this.m = false;
        }
    }

    public void onStop() {
        super.onStop();
        if (mediacontroler.e()) {
            Musicplay();
        }
    }

    public void a() {
        Musicplay();
        this.tvseekchangetime.setVisibility(View.VISIBLE);
        tvselectmusicname.setVisibility(View.GONE);
    }

    public void a(long j) {
        aLong = j;
        r = j;
        TextView textView = this.tvseekchangetime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(simpleDateFormat.format(j));
        stringBuilder.append("-");
        stringBuilder.append(simpleDateFormat.format(h));
        textView.setText(stringBuilder.toString());
    }

    public void b() {
        this.tvseekchangetime.setVisibility(View.GONE);
        tvselectmusicname.setVisibility(View.VISIBLE);
        r = aLong;
        Musicpause();
    }

    public void b(long j) {
        h = j;
        this.tvendtime.setText(simpleDateFormat.format(j));
        TextView textView = this.tvseekchangetime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(simpleDateFormat.format(aLong));
        stringBuilder.append("-");
        stringBuilder.append(simpleDateFormat.format(j));
        textView.setText(stringBuilder.toString());
    }

    private void BindView() {
        this.timeout = Long.MAX_VALUE;
        tabLayout = findViewById(R.id.tab_layout);
        viewPager = findViewById(R.id.viewpager);
        ivplaymusic = findViewById(R.id.img_play_music);
        FrameLayout frameLayout = findViewById(R.id.btn_play_music);
        playMusicControllerView = findViewById(R.id.music_controller_view);
        playMusicControllerView.setOnMusicPlayControllerListener(this);
        tvplaytime = findViewById(R.id.txt_play_time);
        this.tvendtime = findViewById(R.id.txt_end_time);
        tvselectmusicname = findViewById(R.id.music);
        tvseekchangetime = findViewById(R.id.seektime);
        tvNoSong = findViewById(R.id.tv_no_music_found);
        layoutSongCut = findViewById(R.id.rl_cuttor_main);
        frameLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediacontroler.a() != null) {
                    if (mediacontroler.e()) {
                        Musicplay();
                        return;
                    } else {
                        Musicpause();
                    }
                }
            }
        });
        if (allMusicFolders == null) {
            allMusicFolders = new AllMusicFolders();
        }
        if (allMusicFolders.getMusicFolders().size() > 0) {
            setUpPagerNew();
            SetTabLayout();
        } else {
            tvNoSong.setVisibility(View.VISIBLE);
            layoutSongCut.setVisibility(View.GONE);
        }
    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial_SongCutting));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 202:
                        Done();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });
    }

    public void Done() {
        musicRes.a(aLong);
        musicRes.b(h);
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory());
        sb.append(File.separator);
        sb.append("Beats");
        sb.append(File.separator);
        sb.append("Crop Song");
        final File file = new File(sb.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(Environment.getExternalStorageDirectory());
        sb2.append(File.separator);
        sb2.append("Beats");
        sb2.append(File.separator);
        sb2.append("Crop Song");
        sb2.append(File.separator);
        sb2.append("temp.mp3");
        FinalSongCropPath = sb2.toString();
        command = new String[]{getFFmpeg(activity), "-i", musicRes.c(), "-ss", getTimeDuration(musicRes.b()), "-t", getTimeDuration(musicRes.f()), "-acodec", "copy", "-y", FinalSongCropPath};
        final StringBuilder sb3 = new StringBuilder();
        sb3.append("Path :");
        sb3.append(FinalSongCropPath);
        new CropSongAsync().execute();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
            View customView = tab.getCustomView();
            if (tab.getPosition() == 0) {
                ((TextView) customView.findViewById(R.id.folder_name)).setTextColor(getResources().getColor(R.color.white));
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_selected));
            }
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.folder_name)).setTextColor(getResources().getColor(R.color.white));
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_selected));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.folder_name)).setTextColor(getResources().getColor(R.color.black));
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_normal));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    ((TextView) customView.findViewById(R.id.folder_name)).setTextColor(getResources().getColor(R.color.white));
                    LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                    linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_selected));
                }
            }
        });
    }

    private void setUpPagerNew() {
        adp = new NewsPagerAdapterNew(getSupportFragmentManager());
        for (int i = 0; i < allMusicFolders.getMusicFolders().size(); i++) {
            adp.addFrag(LocalCategoryWiseSongFragment.getInstance(i, i), "");
        }
        viewPager.setAdapter(adp);
        tabLayout.setupWithViewPager(viewPager);
    }

    private void getLocalSongs() {
        localTrackList.clear();
        allMusicFolders = new AllMusicFolders();
        allMusicFolders.getMusicFolders().clear();
        ContentResolver musicResolver = activity.getContentResolver();
        Uri musicUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = musicResolver.query(musicUri, null, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC");

        if (musicCursor != null && musicCursor.moveToFirst()) {
            int titleColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media._ID);
            int artistColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.ARTIST);
            int albumColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.ALBUM);
            int pathColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.DATA);
            int durationColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.DURATION);

            do {
                int thisId = musicCursor.getInt(idColumn);
                String thisTitle = musicCursor.getString(titleColumn);
                String thisArtist = musicCursor.getString(artistColumn);
                String thisAlbum = musicCursor.getString(albumColumn);
                String path = musicCursor.getString(pathColumn);
                long duration = musicCursor.getLong(durationColumn);

                LocalTrack lt = new LocalTrack(thisId, thisTitle, thisArtist, thisAlbum, path, duration);
                localTrackList.add(lt);
                File f = new File(path);
                String dirName = f.getParentFile().getName();
                if (getFolder(dirName) == null) {
                    MusicFolder mf = new MusicFolder(dirName);
                    mf.getLocalTracks().add(lt);
                    allMusicFolders.getMusicFolders().add(mf);
                } else {
                    getFolder(dirName).getLocalTracks().add(lt);
                }
            }
            while (musicCursor.moveToNext());
        }

        if (musicCursor != null)
            musicCursor.close();

    }

    public MusicFolder getFolder(String folderName) {
        MusicFolder mf = null;
        for (int i = 0; i < allMusicFolders.getMusicFolders().size(); i++) {
            MusicFolder mf1 = allMusicFolders.getMusicFolders().get(i);
            if (mf1.getFolderName().equals(folderName)) {
                mf = mf1;
                break;
            }
        }
        return mf;
    }

    private File getFileDirectory(final Context context) {
        return context.getFilesDir();
    }

    private String getFFmpeg(final Context context) {
        final StringBuilder sb = new StringBuilder(String.valueOf(String.valueOf(getFileDirectory(context).getAbsolutePath())));
        sb.append(File.separator);
        sb.append("ffmpeg");
        return sb.toString();
    }

    @SuppressLint("DefaultLocale")
    public String getTimeDuration(final long n) {
        return String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(n), TimeUnit.MILLISECONDS.toMinutes(n), TimeUnit.MILLISECONDS.toSeconds(n) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(n)));
    }

    private void checkAndUpdateProcess() throws TimeoutException {
        while (!Util.isProcessCompleted(this.process)) {
            if (Util.isProcessCompleted(this.process)) {
                return;
            }
            if (timeout != Long.MAX_VALUE && System.currentTimeMillis() > System.currentTimeMillis() + timeout) {
                throw new TimeoutException("FFmpeg timed out");
            }
            try {
                final BufferedReader reader = new BufferedReader(new InputStreamReader(this.process.getErrorStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    output = String.valueOf(String.valueOf(this.output)) + line + "\n";
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public class Play implements Runnable {

        public void run() {
            while (n) {
                playMusicControllerView.setPlayProgress(mediacontroler.c());
                if (((long) mediacontroler.c()) >= h) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("start : ");
                    stringBuilder.append(aLong);
                    mediacontroler.a(aLong);
                }
                new Play.p(this);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        class p implements Runnable {

            final Play play;

            p(Play play) {
                this.play = play;
            }

            public void run() {
                tvplaytime.setText(simpleDateFormat.format(mediacontroler.c()));
            }
        }
    }

    private class NewsPagerAdapterNew extends FragmentPagerAdapter {

        List<Fragment> fragList = new ArrayList<>();
        List<String> titleList = new ArrayList<>();

        public NewsPagerAdapterNew(FragmentManager fm) {
            super(fm);
        }

        public void addFrag(Fragment f, String title) {
            fragList.add(f);
            titleList.add(title);
        }

        @Override
        public Fragment getItem(int position) {
            return fragList.get(position);
        }

        @Override
        public int getCount() {
            return fragList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titleList.get(position);
        }

        public View getTabView(int position) {
            View tab = LayoutInflater.from(activity).inflate(
                    R.layout.coustom_song_items, null);
            TextView tv = tab.findViewById(R.id.folder_name);
            tv.setText(allMusicFolders.getMusicFolders().get(position).getFolderName());
            return tab;
        }
    }

    @SuppressLint("StaticFieldLeak")
    public class CropSongAsync extends AsyncTask<Void, Void, Void> {
        ProgressDialog a;

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (a != null && this.a.isShowing()) {
                this.a.dismiss();
            }
            Intent intent = new Intent();
            intent.putExtra("audio_path", FinalSongCropPath);
            setResult(-1, intent);
            finish();

        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                process = Runtime.getRuntime().exec(command);
                if (process != null) {
                    try {
                        checkAndUpdateProcess();
                    } catch (TimeoutException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            (this.a = new ProgressDialog(activity)).setMessage("Please Waiting...");
            this.a.setCancelable(false);
            this.a.show();
        }
    }
}
