﻿using UnityEngine;
using UnityEngine.Advertisements;
using UnityEngine.Analytics;


namespace BallCollect
{
    public class InterstitialUnityAds : MonoBehaviour, IUnityAdsListener
    {
        public static InterstitialUnityAds instance;

        bool testMode = true;

        [HideInInspector]
        public bool isInterstitialLoad = false;

        void Awake()
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        void Start()
        {
            Advertisement.AddListener(this);
            Advertisement.Initialize(Manager.instance.unityGameId, testMode);
            isInterstitialLoad = false;
        }

        public void OnUnityAdsDidFinish(string placementId, ShowResult showResult)
        {
            if (placementId == Manager.instance.unityInterstitialId)
            {
                isInterstitialLoad = false;
                if (showResult == ShowResult.Finished)
                {
                    GameController.instance.noAddInter.SetActive(true);

                    if (GameController.instance.isLCompleteClick)
                    {
                        GameController.instance.LevelCompletedAfter();
                        Analytics.CustomEvent("UnityInterstitalLevelCompletedDone");
                    }
                    if (GameController.instance.isRestartClick)
                    {
                        GameController.instance.BtnRestartAfter();
                        Analytics.CustomEvent("UnityInterstitalRestartDone");
                    }
                    if (GameController.instance.isHomeClick)
                    {
                        GameController.instance.BtnHomeAfter();
                        Analytics.CustomEvent("UnityInterstitalHomeDone");
                    }
                }
                else if (showResult == ShowResult.Skipped)
                {
                    GameController.instance.noAddInter.SetActive(true);

                    if (GameController.instance.isLCompleteClick)
                    {
                        GameController.instance.LevelCompletedAfter();
                        Analytics.CustomEvent("UnityInterstitalLevelCompletedDone");
                    }
                    if (GameController.instance.isRestartClick)
                    {
                        GameController.instance.BtnRestartAfter();
                        Analytics.CustomEvent("UnityInterstitalRestartDone");
                    }
                    if (GameController.instance.isHomeClick)
                    {
                        GameController.instance.BtnHomeAfter();
                        Analytics.CustomEvent("UnityInterstitalHomeDone");
                    }
                }
                else if (showResult == ShowResult.Failed)
                {

                }
            }
        }

        public void OnUnityAdsReady(string placementId)
        {
            if (placementId == Manager.instance.unityInterstitialId)
            {
                isInterstitialLoad = true;
            }
        }

        public void OnUnityAdsDidError(string message)
        {
        }

        public void OnUnityAdsDidStart(string placementId)
        {
        }

        public void ShowInterstitial()
        {
            Advertisement.Show(Manager.instance.unityInterstitialId);
        }

        public void OnDestroy()
        {
            Advertisement.RemoveListener(this);
        }
    }
}