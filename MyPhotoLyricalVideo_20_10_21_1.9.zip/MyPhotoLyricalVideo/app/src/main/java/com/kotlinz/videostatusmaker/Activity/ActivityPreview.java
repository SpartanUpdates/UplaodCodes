package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import androidx.annotation.Nullable;
import android.text.Layout;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import com.larswerkman.holocolorpicker.ColorPicker;
import com.larswerkman.holocolorpicker.OpacityBar;
import com.larswerkman.holocolorpicker.SVBar;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import com.kotlinz.videostatusmaker.Others.gallery.ActivityAllPhotos;
import com.kotlinz.videostatusmaker.Others.gallery.ActivityImageFolder;
import com.kotlinz.videostatusmaker.Utils.AppPreferences;
import com.kotlinz.videostatusmaker.Utils.Utils;
import com.kotlinz.videostatusmaker.Utils.async.MusicAdd;
import com.kotlinz.videostatusmaker.Utils.async.VideoCreate;
import com.kotlinz.videostatusmaker.adapter.TextAdapter;
import com.kotlinz.videostatusmaker.adapter.TextureAdapter;
import static com.kotlinz.videostatusmaker.NativeAds.CustomNativeAd.populateUnifiedNativeAdView;

public class ActivityPreview extends Activity {
    RelativeLayout relativeLayout;
    CopyBitmap copyBitmap;
    CountDownTimer countDownTimer;
    int currentLine1;
    public static TextView lyricTxt2;
    public static int w;
    TextAdapter textAdapter;
    TextureAdapter textureAdapter;
    LinearLayout addTextLay;
    LinearLayout addTextLay1;
    ImageView ivBack;
    public static int SEL_THEME = 888;
    public static int SEL_TYPEFACE = 999;
    public static int THEME;
    public static boolean cancel;
    public static boolean complete;
    public static boolean done_press;
    public static int h;
    static ArrayList<Bitmap> images_bit;
    public static TextView lyricTxt1;
    ImageView ivBottomleft;
    ImageView ivBottomright;
    int cPos;
    int currentLine2;
    TextView tvDone;
    File file;
    TextView txt_pro;
    ImageView imageview1;
    ImageView imageview11;
    ImageView imageview2;
    ImageView imageview22;
    Typeface typeface;
    LinearLayout gravityLay;
    Handler handler;
    Handler handler1;
    int i;
    ImageLoader imageLoader;
    ImageView ivPreview;
    Animation imageZoomOut1;
    Animation imageZoomOut2;
    ArrayList<String> line_textts1;
    ArrayList<String> line_texts2;
    File[] listFile;
    String[] strings11;
    String[] strings22;
    private OpacityBar opacityBar;
    ArrayList<String> photo2;
    ArrayList<String> photo3;
    private ColorPicker colorPicker;
    ImageView play_pause;
    MediaPlayer player;
    int pos;
    AppPreferences preferences;
    SeekBar pro_seek;
    ImageView random;
    RelativeLayout rel;
    SaveBitmap saveBitmap;
    RelativeLayout save_lay;
    RelativeLayout save_lay2;
    Dialog dialog_savee;
    ImageView ivSetolor;
    ImageView ivSetPos;
    ImageView ivSetStyle;
    public static Activity activity;
    public static ProgressDialog progressDialog;
    public static boolean randomB;
    public static TextView title;
    ImageView ivSetTheme;
    ImageView ivSetting;
    String[] styles;
    private SVBar svBar;
    int text_color;
    String[] textures;
    ImageView top_left;
    ImageView top_right;
    Animation centerZoomImage1;
    Animation centerZoomImage2;
    Animation centerZoomRotate1;
    Animation animation;
    Animation crossComeImage11;
    Animation crossComeImage12;
    Animation crossComeImage21;
    Animation crossComeImage22;
    Animation crossComeImage31;
    Animation crossComeImage32;
    Animation crossComeImage41;
    Animation crossComeImage42;
    Animation crossCome11;
    Animation crossCome12;
    Animation crossCome21;
    Animation crossCome22;
    Animation crossCome31;
    Animation crossCome32;
    Animation crossCome41;
    Animation crossCome42;
    String videoName;
    Animation animZoomBot1;
    Animation animZoomBot2;
    Animation animZoomInText1;
    Animation animZoomInText2;
    Animation animZoomLeft1;
    Animation animZoomLeft2;
    Animation animZoomRight1;
    Animation animZoomRight2;
    Animation animZoomUp1;
    Animation animZoomUp2;
    Animation animSlide_from_bot1;
    Animation animSlide_from_bot2;
    Animation animSlide_from_left1;
    Animation animSlide_from_left2;
    Animation animSlide_from_right1;
    Animation animSlide_from_right2;
    Animation animSlide_from_top1;
    Animation animSlide_from_top2;
    Animation animSlide_image_zoom1;
    Animation animSlide_image_zoom2;
    Animation animMoveBot1;
    Animation animMoveBot2;
    Animation animMoveLeft1;
    Animation animMoveLeft2;
    Animation animMoveRight1;
    Animation animMoveRight2;
    Animation animMoveUp1;
    Animation animMoveUp2;
    Animation animCenterZoom1;
    Animation animCenterZoom2;

    public Activity MyActivity = ActivityPreview.this;

    private NativeAd nativeAd;

    String sscopy;

    static {
        ActivityPreview.images_bit = new ArrayList<Bitmap>();
        ActivityPreview.cancel = false;
        ActivityPreview.complete = false;
        ActivityPreview.done_press = false;
        ActivityPreview.randomB = true;
    }

    public ActivityPreview() {
        this.line_textts1 = new ArrayList<String>();
        this.line_texts2 = new ArrayList<String>();
        this.listFile = null;
        this.photo2 = new ArrayList<String>();
        this.photo3 = new ArrayList<String>();
        this.handler = new Handler();
        this.text_color = -8323328;
        this.handler1 = new Handler();
    }

    private void initImageLoader() {
        (this.imageLoader = ImageLoader.getInstance()).init(new ImageLoaderConfiguration.Builder(this).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).build()).build());
    }

    public void addMusic(final String s) {
        final MediaPlayer mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(this, Uri.parse(s));
            mediaPlayer.prepare();
            final int n = mediaPlayer.getDuration() / 1000;
            final StringBuilder sb = new StringBuilder();
            sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
            sb.append("/");
            sb.append(this.getResources().getString(R.string.app_name));
            final String string = sb.toString();
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(string);
            sb2.append("/Video");
            final File absoluteFile = new File(sb2.toString()).getAbsoluteFile();
            final StringBuilder sb3 = new StringBuilder();
            sb3.append(absoluteFile);
            sb3.append(File.separator);
            sb3.append(this.videoName);
            sb3.append(".mp4");
            final String string2 = sb3.toString();
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("");
            sb4.append(n);
            final String string3 = sb4.toString();
            final String music_path = ActivitySelectLyrics.strMusicPath;
            final StringBuilder sb5 = new StringBuilder();
            sb5.append("");
            sb5.append(n);
            new MusicAdd(this, "0", string3, s, "0", music_path, sb5.toString(), string2).execute();
        } catch (Exception ex) {
            ex.printStackTrace();
            ActivityPreview.progressDialog.dismiss();
        }
    }

    void theme0(final String text) {
        final int n = ActivityPreview.w * 15 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay1.addView(textView);
        textView.setTypeface(ActivityPreview.lyricTxt2.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt2.getCurrentTextColor());
        textView.setText(text);
        textView.setBackgroundResource(R.drawable.textview_bg_red);
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
        } else {
            textView.setAllCaps(false);
        }
        int n2;
        if (MainActivity.anInt == 1) {
            textView.setTextSize(20.0f);
            n2 = ActivityPreview.w * 25 / 1080;
        } else {
            textView.setTextSize(20.0f);
            n2 = ActivityPreview.w * 15 / 1080;
        }
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        if (!ActivityPreview.randomB) {
            this.currentLine2 = this.cPos;
        }
        if (this.currentLine2 != 0 && this.currentLine2 != 4) {
            if (this.currentLine2 != 1 && this.currentLine2 != 5) {
                if (this.currentLine2 != 2 && this.currentLine2 != 6) {
                    if (this.currentLine2 == 3 || this.currentLine2 == 7) {
                        this.addTextLay1.setGravity(83);
                        layoutParams.setMargins(n, 0, 0, n2);
                    }
                } else {
                    this.addTextLay1.setGravity(85);
                    layoutParams.setMargins(0, 0, n, n2);
                }
            } else {
                this.addTextLay1.setGravity(53);
                layoutParams.setMargins(0, n2, n, 0);
            }
        } else {
            this.addTextLay1.setGravity(51);
            layoutParams.setMargins(n, n2, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setPadding(n, n, n, n);
    }

    void theme1(final String text, final int n) {
        final int n2 = ActivityPreview.w * 15 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay1.addView(textView);
        textView.setTypeface(ActivityPreview.lyricTxt2.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt2.getCurrentTextColor());
        textView.setText(text);
        textView.setBackgroundResource(R.drawable.textview_bg_yellow);
        textView.setVisibility(View.INVISIBLE);
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
        } else {
            textView.setAllCaps(false);
        }
        int n3;
        if (MainActivity.anInt == 1) {
            textView.setTextSize(20.0f);
            n3 = ActivityPreview.w * 25 / 1080;
        } else {
            textView.setTextSize(20.0f);
            n3 = ActivityPreview.w * 15 / 1080;
        }
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        if (!ActivityPreview.randomB) {
            this.currentLine2 = this.cPos;
        }
        if (this.currentLine2 != 0 && this.currentLine2 != 4) {
            if (this.currentLine2 != 1 && this.currentLine2 != 5) {
                if (this.currentLine2 != 2 && this.currentLine2 != 6) {
                    if (this.currentLine2 == 3 || this.currentLine2 == 7) {
                        this.addTextLay1.setGravity(83);
                        layoutParams.setMargins(n2, 0, 0, n3);
                    }
                } else {
                    this.addTextLay1.setGravity(85);
                    layoutParams.setMargins(0, 0, n2, n3);
                }
            } else {
                this.addTextLay1.setGravity(53);
                layoutParams.setMargins(0, n3, n2, 0);
            }
        } else {
            this.addTextLay1.setGravity(51);
            layoutParams.setMargins(n2, n3, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setPadding(n2, n2, n2, n2);
        this.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                textView.setVisibility(View.VISIBLE);
                if (ActivityPreview.this.currentLine2 != 0 && ActivityPreview.this.currentLine2 != 4) {
                    if (ActivityPreview.this.currentLine2 == 1 || ActivityPreview.this.currentLine2 == 5) {
                        ActivityPreview.this.animSlide_from_right2 = AnimationUtils.loadAnimation(ActivityPreview.this, R.anim.slide_from_right);
                        textView.startAnimation(ActivityPreview.this.animSlide_from_right2);
                        return;
                    }
                    if (ActivityPreview.this.currentLine2 == 2 || ActivityPreview.this.currentLine2 == 6) {
                        ActivityPreview.this.animSlide_from_right2 = AnimationUtils.loadAnimation(ActivityPreview.this, R.anim.slide_from_right);
                        textView.startAnimation(ActivityPreview.this.animSlide_from_right2);
                        return;
                    }
                    if (ActivityPreview.this.currentLine2 == 3 || ActivityPreview.this.currentLine2 == 7) {
                        ActivityPreview.this.animSlide_from_left2 = AnimationUtils.loadAnimation(ActivityPreview.this, R.anim.slide_from_left);
                        textView.startAnimation(ActivityPreview.this.animSlide_from_left2);
                    }
                } else {
                    ActivityPreview.this.animSlide_from_left2 = AnimationUtils.loadAnimation(ActivityPreview.this, R.anim.slide_from_left);
                    textView.startAnimation(ActivityPreview.this.animSlide_from_left2);
                }
            }
        }, n * 200);
    }

    void theme2(final String text) {
        final int n = ActivityPreview.w * 15 / 1080;
        final int n2 = ActivityPreview.w * 40 / 1080;
        final TextView textView = new TextView(this);
        LinearLayout.LayoutParams layoutParams;
        if (MainActivity.anInt == 1) {
            textView.setTextSize(17.0f);
            final double n3 = ActivityPreview.w;
            Double.isNaN(n3);
            layoutParams = new LinearLayout.LayoutParams((int) (n3 * 0.6), -2);
        } else {
            textView.setTextSize(20.0f);
            final double n4 = ActivityPreview.w;
            Double.isNaN(n4);
            layoutParams = new LinearLayout.LayoutParams((int) (n4 * 0.7), -2);
        }
        if (this.currentLine2 != 0 && this.currentLine2 != 4) {
            if (this.currentLine2 != 1 && this.currentLine2 != 5) {
                if (this.currentLine2 != 2 && this.currentLine2 != 6) {
                    if (this.currentLine2 == 3 || this.currentLine2 == 7) {
                        textView.startAnimation(this.animSlide_from_top2 = AnimationUtils.loadAnimation(this.getApplicationContext(), R.anim.slide_from_top));
                        layoutParams.setMargins(-n * 2, 0, 0, n * 2);
                    }
                } else {
                    textView.startAnimation(this.animSlide_from_top2 = AnimationUtils.loadAnimation(this.getApplicationContext(), R.anim.slide_from_top));
                    layoutParams.setMargins(0, n, -n * 2, n * 2);
                }
            } else {
                textView.startAnimation(this.animSlide_from_bot2 = AnimationUtils.loadAnimation(this.getApplicationContext(), R.anim.slide_from_bot));
                layoutParams.setMargins(0, n * 2, -n * 2, 0);
            }
        } else {
            textView.startAnimation(this.animSlide_from_bot2 = AnimationUtils.loadAnimation(this.getApplicationContext(), R.anim.slide_from_bot));
            layoutParams.setMargins(-n * 2, n * 2, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setGravity(17);
        textView.setTypeface(ActivityPreview.lyricTxt2.getTypeface());
        textView.setTextColor(getResources().getColor(R.color.black));
        textView.setText(text);
        textView.setBackgroundResource(R.drawable.textview_bg_black);
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
        } else {
            textView.setAllCaps(false);
        }
        final GradientDrawable gradientDrawable = (GradientDrawable) textView.getBackground().getCurrent();
        final float n5 = n;
        gradientDrawable.setCornerRadii(new float[]{n5, n5, n5, n5, n5, n5, n5, n5});
        textView.setPadding(n2, n2, n2, n2);
        this.addTextLay1.addView(textView);
    }

    void theme3(final String text) {
        final int n = ActivityPreview.w * 25 / 1080;
        final int n2 = ActivityPreview.w * 60 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay1.addView(textView);
        this.addTextLay1.setPadding(0, 0, 0, 0);
        LinearLayout.LayoutParams layoutParams;
        if (MainActivity.anInt == 1) {
            textView.setTextSize(17.0f);
            final double n3 = ActivityPreview.w;
            Double.isNaN(n3);
            final int n4 = (int) (n3 * 0.45);
            final double n5 = ActivityPreview.w;
            Double.isNaN(n5);
            layoutParams = new LinearLayout.LayoutParams(n4, (int) (n5 * 0.45));
        } else {
            textView.setTextSize(20.0f);
            layoutParams = new LinearLayout.LayoutParams(ActivityPreview.w / 2, ActivityPreview.w / 2);
        }
        if (!ActivityPreview.randomB) {
            this.currentLine2 = this.cPos;
        }
        if (this.currentLine2 != 0 && this.currentLine2 != 4) {
            if (this.currentLine2 != 1 && this.currentLine2 != 5) {
                if (this.currentLine2 != 2 && this.currentLine2 != 6) {
                    if (this.currentLine2 == 3 || this.currentLine2 == 7) {
                        this.addTextLay1.setGravity(83);
                        textView.setBackgroundResource(R.drawable.circle_bottom_left);
                        textView.setGravity(83);
                        textView.setPadding(n, 0, n2, n);
                        textView.startAnimation(this.crossCome32 = AnimationUtils.loadAnimation(this, R.anim.cross_come3));
                    }
                } else {
                    this.addTextLay1.setGravity(85);
                    textView.setBackgroundResource(R.drawable.circle_bottom_right);
                    textView.setGravity(85);
                    textView.setPadding(n2, 0, n, n);
                    textView.startAnimation(this.crossCome42 = AnimationUtils.loadAnimation(this, R.anim.cross_come4));
                }
            } else {
                this.addTextLay1.setGravity(53);
                textView.setBackgroundResource(R.drawable.circle_top_right);
                textView.setGravity(53);
                textView.setPadding(n2, n, n, 0);
                textView.startAnimation(this.crossCome22 = AnimationUtils.loadAnimation(this, R.anim.cross_come2));
            }
        } else {
            this.addTextLay1.setGravity(51);
            textView.setBackgroundResource(R.drawable.circle_top_left);
            textView.setGravity(51);
            textView.setPadding(n, n, n2, 0);
            textView.startAnimation(this.crossCome12 = AnimationUtils.loadAnimation(this, R.anim.cross_come1));
        }
        textView.setLayoutParams(layoutParams);
        textView.setTypeface(ActivityPreview.lyricTxt2.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt2.getCurrentTextColor());
        textView.setText(text);
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
            return;
        }
        textView.setAllCaps(false);
    }

    void theme4(final String text) {
        final int n = ActivityPreview.w * 20 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay1.addView(textView);
        this.addTextLay1.setPadding(0, 0, 0, 0);
        LinearLayout.LayoutParams layoutParams;
        if (MainActivity.anInt == 1) {
            textView.setTextSize(19.0f);
            final double n2 = ActivityPreview.w;
            Double.isNaN(n2);
            final int n3 = (int) (n2 * 0.55);
            final double n4 = ActivityPreview.w;
            Double.isNaN(n4);
            layoutParams = new LinearLayout.LayoutParams(n3, (int) (n4 * 0.37));
        } else {
            textView.setTextSize(22.0f);
            final double n5 = ActivityPreview.w;
            Double.isNaN(n5);
            final int n6 = (int) (n5 * 0.6);
            final double n7 = ActivityPreview.w;
            Double.isNaN(n7);
            layoutParams = new LinearLayout.LayoutParams(n6, (int) (n7 * 0.4));
        }
        if (!ActivityPreview.randomB) {
            this.currentLine2 = this.cPos;
        }
        if (this.currentLine2 != 0 && this.currentLine2 != 4) {
            if (this.currentLine2 != 1 && this.currentLine2 != 5) {
                if (this.currentLine2 != 2 && this.currentLine2 != 6) {
                    if (this.currentLine2 == 3 || this.currentLine2 == 7) {
                        this.addTextLay1.setGravity(83);
                        layoutParams.setMargins(n, 0, 0, n);
                    }
                } else {
                    this.addTextLay1.setGravity(85);
                    layoutParams.setMargins(0, 0, n, n);
                }
            } else {
                this.addTextLay1.setGravity(53);
                layoutParams.setMargins(0, n, n, 0);
            }
        } else {
            this.addTextLay1.setGravity(51);
            layoutParams.setMargins(n, n, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setTypeface(ActivityPreview.lyricTxt2.getTypeface());
        textView.setTextColor(getResources().getColor(R.color.white));
        textView.setBackgroundResource(R.drawable.textview_bg_theme4);
        textView.setText(text);
        textView.setGravity(17);
        textView.startAnimation(this.animCenterZoom2 = AnimationUtils.loadAnimation(this, R.anim.center_zoom));
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
            return;
        }
        textView.setAllCaps(false);
    }

    void theme5(final String text, final int n) {
        final int n2 = ActivityPreview.w * 15 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay1.addView(textView);
        textView.setTypeface(ActivityPreview.lyricTxt2.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt2.getCurrentTextColor());
        textView.setText(text);
        textView.setBackgroundResource(R.drawable.textview_bg_sky);
        textView.setVisibility(View.INVISIBLE);
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
        } else {
            textView.setAllCaps(false);
        }
        int n3;
        if (MainActivity.anInt == 1) {
            textView.setTextSize(20.0f);
            n3 = ActivityPreview.w * 25 / 1080;
        } else {
            textView.setTextSize(20.0f);
            n3 = ActivityPreview.w * 15 / 1080;
        }
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        if (!ActivityPreview.randomB) {
            this.currentLine2 = this.cPos;
        }
        if (this.currentLine2 != 0 && this.currentLine2 != 4) {
            if (this.currentLine2 != 1 && this.currentLine2 != 5) {
                if (this.currentLine2 != 2 && this.currentLine2 != 6) {
                    if (this.currentLine2 == 3 || this.currentLine2 == 7) {
                        this.addTextLay1.setGravity(83);
                        layoutParams.setMargins(n2, 0, 0, n3);
                    }
                } else {
                    this.addTextLay1.setGravity(85);
                    layoutParams.setMargins(0, 0, n2, n3);
                }
            } else {
                this.addTextLay1.setGravity(53);
                layoutParams.setMargins(0, n3, n2, 0);
            }
        } else {
            this.addTextLay1.setGravity(51);
            layoutParams.setMargins(n2, n3, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setPadding(n2, n2, n2, n2);
        this.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                textView.setVisibility(View.VISIBLE);
                ActivityPreview.this.animZoomInText2 = AnimationUtils.loadAnimation(ActivityPreview.this, R.anim.zoom_in_text);
                textView.startAnimation(ActivityPreview.this.animZoomInText2);
            }
        }, n * 300);
    }

    void theme6(final String text) {
        final int n = ActivityPreview.w * 20 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay1.addView(textView);
        this.addTextLay1.setPadding(0, 0, 0, 0);
        int n2;
        LinearLayout.LayoutParams layoutParams;
        if (MainActivity.anInt == 1) {
            n2 = ActivityPreview.w * 25 / 1080;
            textView.setTextSize(20.0f);
            final double n3 = ActivityPreview.w;
            Double.isNaN(n3);
            final int n4 = (int) (n3 * 0.5);
            final double n5 = ActivityPreview.w;
            Double.isNaN(n5);
            layoutParams = new LinearLayout.LayoutParams(n4, (int) (n5 * 0.5));
        } else {
            textView.setTextSize(20.0f);
            n2 = ActivityPreview.w * 15 / 1080;
            final double n6 = ActivityPreview.w;
            Double.isNaN(n6);
            final int n7 = (int) (n6 * 0.55);
            final double n8 = ActivityPreview.w;
            Double.isNaN(n8);
            layoutParams = new LinearLayout.LayoutParams(n7, (int) (n8 * 0.55));
        }
        if (!ActivityPreview.randomB) {
            this.currentLine2 = this.cPos;
        }
        if (this.currentLine2 != 0 && this.currentLine2 != 4) {
            if (this.currentLine2 != 1 && this.currentLine2 != 5) {
                if (this.currentLine2 != 2 && this.currentLine2 != 6) {
                    if (this.currentLine2 == 3 || this.currentLine2 == 7) {
                        this.addTextLay1.setGravity(83);
                        layoutParams.setMargins(n, 0, 0, n2);
                    }
                } else {
                    this.addTextLay1.setGravity(85);
                    layoutParams.setMargins(0, 0, n, n2);
                }
            } else {
                this.addTextLay1.setGravity(53);
                layoutParams.setMargins(0, n2, n, 0);
            }
        } else {
            this.addTextLay1.setGravity(51);
            layoutParams.setMargins(n, n2, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setTypeface(ActivityPreview.lyricTxt2.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt2.getCurrentTextColor());
        textView.setBackgroundResource(R.drawable.textview_bg_circle);
        textView.setText(text);
        textView.setGravity(17);
        textView.setPadding(n, n, n, n);
        textView.startAnimation(this.animation = AnimationUtils.loadAnimation(this, R.anim.zoom_in_text));
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
            return;
        }
        textView.setAllCaps(false);
    }

    void theme7(final String text) {
        final int n = ActivityPreview.w * 20 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay1.addView(textView);
        this.addTextLay1.setPadding(0, 0, 0, 0);
        int n2;
        LinearLayout.LayoutParams layoutParams;
        if (MainActivity.anInt == 1) {
            n2 = ActivityPreview.w * 25 / 1080;
            textView.setTextSize(18.0f);
            final double n3 = ActivityPreview.w;
            Double.isNaN(n3);
            final int n4 = (int) (n3 * 0.41);
            final double n5 = ActivityPreview.w;
            Double.isNaN(n5);
            layoutParams = new LinearLayout.LayoutParams(n4, (int) (n5 * 0.41));
        } else {
            textView.setTextSize(20.0f);
            n2 = ActivityPreview.w * 15 / 1080;
            final double n6 = ActivityPreview.w;
            Double.isNaN(n6);
            final int n7 = (int) (n6 * 0.45);
            final double n8 = ActivityPreview.w;
            Double.isNaN(n8);
            layoutParams = new LinearLayout.LayoutParams(n7, (int) (n8 * 0.45));
        }
        if (!ActivityPreview.randomB) {
            this.currentLine2 = this.cPos;
        }
        if (this.currentLine2 != 0 && this.currentLine2 != 4) {
            if (this.currentLine2 != 1 && this.currentLine2 != 5) {
                if (this.currentLine2 != 2 && this.currentLine2 != 6) {
                    if (this.currentLine2 == 3 || this.currentLine2 == 7) {
                        this.addTextLay1.setGravity(83);
                        layoutParams.setMargins(n, 0, 0, n2);
                    }
                } else {
                    this.addTextLay1.setGravity(85);
                    layoutParams.setMargins(0, 0, n, n2);
                }
            } else {
                this.addTextLay1.setGravity(53);
                layoutParams.setMargins(0, n2, n, 0);
            }
        } else {
            this.addTextLay1.setGravity(51);
            layoutParams.setMargins(n, n2, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setTypeface(ActivityPreview.lyricTxt2.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt2.getCurrentTextColor());
        textView.setBackgroundResource(R.drawable.textview_bg_red_sq);
        textView.setText(text);
        textView.setGravity(17);
        textView.setPadding(n, n, n, n);
        textView.startAnimation(this.animZoomInText2 = AnimationUtils.loadAnimation(this, R.anim.zoom_in_text));
        final GradientDrawable gradientDrawable = (GradientDrawable) textView.getBackground().getCurrent();
        final float n9 = n;
        gradientDrawable.setCornerRadii(new float[]{n9, n9, n9, n9, n9, n9, n9, n9});
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
            return;
        }
        textView.setAllCaps(false);
    }

    public Bitmap bitmapResize(final Bitmap bitmap, int n, int n2) {
        final int width = bitmap.getWidth();
        final int height = bitmap.getHeight();
        if (width >= height) {
            final int n3 = height * n2 / width;
            if (n3 > n) {
                n2 = n2 * n / n3;
            } else {
                n = n3;
            }
        } else {
            final int n4 = width * n / height;
            if (n4 > n2) {
                n = n * n2 / n4;
            } else {
                n2 = n4;
            }
        }
        return Bitmap.createScaledBitmap(bitmap, n2, n, true);
    }

    void build(final String s, final ImageView imageView) {
        final DisplayImageOptions build = new DisplayImageOptions.Builder().build();
        final ImageLoader instance = ImageLoader.getInstance();
        final StringBuilder sb = new StringBuilder();
        sb.append("file:///");
        sb.append(s);
        instance.displayImage(sb.toString(), imageView, build);
    }

    void cancelAnim1() {
        try {
            this.imageview1.clearAnimation();
            this.imageview2.clearAnimation();
            this.animZoomRight1.cancel();
            this.animZoomLeft1.cancel();
            this.animZoomUp1.cancel();
            this.animZoomBot1.cancel();
            this.animMoveRight1.cancel();
            this.animMoveLeft1.cancel();
            this.animMoveUp1.cancel();
            this.animMoveBot1.cancel();
            this.centerZoomImage1.cancel();
            if (this.animSlide_from_left1 != null) {
                this.animSlide_from_left1.cancel();
            }
            if (this.animSlide_from_right1 != null) {
                this.animSlide_from_right1.cancel();
            }
            if (this.animSlide_from_bot1 != null) {
                this.animSlide_from_bot1.cancel();
            }
            if (this.animSlide_from_top1 != null) {
                this.animSlide_from_top1.cancel();
            }
            if (this.crossCome11 != null) {
                this.crossCome11.cancel();
            }
            if (this.crossCome21 != null) {
                this.crossCome21.cancel();
            }
            if (this.crossCome31 != null) {
                this.crossCome31.cancel();
            }
            if (this.crossCome41 != null) {
                this.crossCome41.cancel();
            }
        } catch (Exception ex) {
            ex.toString();
        }
    }

    void cancelAnim2() {
        try {
            this.imageview11.clearAnimation();
            this.imageview22.clearAnimation();
            this.animZoomRight2.cancel();
            this.animZoomLeft2.cancel();
            this.animZoomUp2.cancel();
            this.animZoomBot2.cancel();
            this.animMoveRight2.cancel();
            this.animMoveLeft2.cancel();
            this.animMoveUp2.cancel();
            this.animMoveBot2.cancel();
            this.crossComeImage12.cancel();
            this.crossComeImage22.cancel();
            this.crossComeImage32.cancel();
            this.crossComeImage42.cancel();
            this.centerZoomImage2.cancel();
        } catch (Exception ex) {
            ex.toString();
        }
    }

    void dialog() {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.savevideo_dialog);
        final LinearLayout linearLayout = dialog.findViewById(R.id.mainLay);
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.getResources().getDisplayMetrics().heightPixels;
        linearLayout.setLayoutParams(new RelativeLayout.LayoutParams(widthPixels * 842 / 1080, heightPixels * 579 / 1920));
        final TextView textView = dialog.findViewById(R.id.title);
        dialog.getWindow().setSoftInputMode(5);
        final ImageView imageView = dialog.findViewById(R.id.cancel);
        final ImageView imageView2 = dialog.findViewById(R.id.submit);
        final ImageView imageView3 = dialog.findViewById(R.id.close);
        final EditText editText = dialog.findViewById(R.id.entertext);
        final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams(widthPixels * 310 / 1080, heightPixels * 100 / 1920);
        relativeLayout$LayoutParams.addRule(13);
        imageView.setLayoutParams(relativeLayout$LayoutParams);
        imageView2.setLayoutParams(relativeLayout$LayoutParams);
        textView.setTypeface(this.typeface);
        editText.setTypeface(this.typeface);
        final int n = widthPixels * 40 / 1080;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 65 / 1080, heightPixels * 65 / 1920);
        layoutParams.addRule(15);
        layoutParams.addRule(11);
        layoutParams.setMargins(0, 0, n, 0);
        imageView3.setLayoutParams(layoutParams);
        final StringBuilder sb = new StringBuilder();
        sb.append("lyricvideo_");
        sb.append(ActivityVideoSave.setDateFormat(System.currentTimeMillis()));
        editText.setText(sb.toString());
        editText.setSelection(editText.getText().length());
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                dialog.dismiss();
            }
        });
        imageView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View string) {
                String sss = editText.getText().toString();
                if (sss.equals("")) {
                    editText.setError("Enter Name");
                    return;
                }
                try {
                    ActivityImageFolder.activity.finish();
                    ActivityAllPhotos.activity.finish();
                    ActivityViewAlImages.activity.finish();
                    ActivityArrangePhoto.activity.finish();
                    ActivitySelectLyrics.activity.finish();
                    MainActivity.activity.finish();
                } catch (Exception ex) {
                    ex.toString();
                }
                Utils.photos.clear();
                Utils.complete = false;
                ActivityPreview.this.videoName = sss;
                ActivityPreview.done_press = true;
                if (ActivityPreview.complete) {
                    if (ActivityPreview.THEME == 0) {
                        new VideoCreate(ActivityPreview.this, "1").execute();
                    } else {
                        new VideoCreate(ActivityPreview.this, "9").execute();
                    }
                }
                ActivityPreview.this.backDialog();
                dialog.dismiss();
            }
        });
        imageView3.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    public Bitmap getBitmapFromView(final View view) {
        try {
            final Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
            this.runOnUiThread(new Runnable() {
                final Canvas val$canvas = new Canvas(bitmap);

                @Override
                public void run() {
                    view.draw(this.val$canvas);
                }
            });
            try {
                Thread.sleep(100L);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
            try {
                Bitmap bitmap2;
                if (MainActivity.anInt == 1) {
                    if ((ActivityPreview.h > 1280 && ActivityPreview.h < 1500) || ActivityPreview.h > 1920) {
                        bitmap2 = Bitmap.createScaledBitmap(bitmap, 720, 1440, true);
                    } else {
                        bitmap2 = Bitmap.createScaledBitmap(bitmap, 720, 1280, true);
                    }
                } else {
                    bitmap2 = Bitmap.createScaledBitmap(bitmap, 720, 720, true);
                }
                return bitmap2;
            } catch (Exception ex2) {
                ex2.toString();
                return bitmap;
            }
        } catch (Exception ex3) {
            Log.e("Memory", ex3.toString());
            System.gc();
            this.saveReset();
            this.start_saving();
            return null;
        }
    }

    public void getFromSdcard() {
        this.photo3.clear();
        this.photo2.clear();
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
        sb.append(File.separator);
        sb.append(this.getString(R.string.app_name));
        sb.append(File.separator);
        sb.append(this.getString(R.string.temp_folder));
        sb.append("/temp");
        final File file = new File(sb.toString());
        if (file.isDirectory()) {
            this.listFile = file.listFiles();
            for (int i = this.listFile.length - 1; i >= 0; --i) {
                if (this.listFile[i].getName().contains("anim")) {
                    this.photo3.add(this.listFile[i].getAbsolutePath());
                }
            }
            Collections.sort(this.photo3, new Comparator<String>() {
                @Override
                public int compare(final String s, final String s2) {
                    return s.compareToIgnoreCase(s2);
                }
            });
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
        sb2.append(File.separator);
        sb2.append(this.getString(R.string.app_name));
        sb2.append(File.separator);
        sb2.append(this.getString(R.string.temp_folder));
        final File file2 = new File(sb2.toString());
        if (file2.isDirectory()) {
            this.listFile = file2.listFiles();
            for (int j = this.listFile.length - 1; j >= 0; --j) {
                if (this.listFile[j].getName().contains("d")) {
                    this.photo2.add(this.listFile[j].getAbsolutePath());
                }
            }
            Collections.sort(this.photo2, new Comparator<String>() {
                @Override
                public int compare(final String s, final String s2) {
                    return s.compareToIgnoreCase(s2);
                }
            });
        }
    }

    void gone(final View view) {
        view.setVisibility(View.GONE);
    }

    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            resetPlayer();
            saveReset();
            super.onBackPressed();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                resetPlayer();
                saveReset();
                MyApplication.AdsId = 16;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                resetPlayer();
                saveReset();
                super.onBackPressed();
            }
        }
    }

    protected void onCreate(@Nullable Bundle string) {
        super.onCreate(string);
        this.setContentView(R.layout.preview);
        this.getWindow().addFlags(1024);
        this.preferences = new AppPreferences(this);
        ActivityPreview.w = this.getResources().getDisplayMetrics().widthPixels;
        ActivityPreview.h = this.getResources().getDisplayMetrics().heightPixels;
        ((ActivityPreview) (ActivityPreview.activity = this)).initImageLoader();
        (ActivityPreview.progressDialog = new ProgressDialog(this)).setMessage("Loading...");
        ActivityPreview.progressDialog.setCancelable(false);
        title = findViewById(R.id.title);
        PutAnalyticsEvent();
        bindView();
        this.ivBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                onBackPressed();
            }
        });
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        ActivityPreview.title.setTypeface(this.typeface);
        ActivityPreview.lyricTxt1.setTypeface(this.typeface);
        ActivityPreview.lyricTxt2.setTypeface(this.typeface);
        this.getFromSdcard();
        player = new MediaPlayer();
        animationSet();
        btnClicks();
        try {
            this.build(this.photo2.get(7), this.imageview2);
            this.build(this.photo2.get(7), this.imageview22);
        } catch (Exception ee) {
            string.toString();
        }
        this.setLayout();
        if (ActivitySelectLyrics.StrTxt_path != null) {
            this.file = new File(ActivitySelectLyrics.StrTxt_path);
        }
        if (this.file != null) {
            StringBuilder sss = new StringBuilder();
            try {
                final BufferedReader bufferedReader = new BufferedReader(new FileReader(this.file));
                while (true) {
                    final String line = bufferedReader.readLine();
                    if (line == null) {
                        break;
                    }
                    sss.append(line);
                    sss.append('\n');
                }
                bufferedReader.close();
                String ssssss = sss.toString();
                this.strings11 = ssssss.split("\n");
                this.strings22 = ssssss.split("\n");
                if (MainActivity.anInt == 1) {
                    ActivityPreview.progressDialog.show();
                    this.rel.post(new Runnable() {
                        @Override
                        public void run() {
                            final Bitmap bitmapResize = ActivityPreview.this.bitmapResize(BitmapFactory.decodeFile(ActivityPreview.this.photo2.get(0)), ActivityPreview.this.rel.getHeight(), ActivityPreview.this.rel.getWidth());
                            final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(bitmapResize.getWidth(), bitmapResize.getHeight());
                            layoutParams.addRule(13);
                            ActivityPreview.this.save_lay2.setLayoutParams(layoutParams);
                            final int n = bitmapResize.getHeight() * 125 / 1920;
                            ActivityPreview.this.addTextLay1.setPadding(0, n, 0, n);
                            ActivityPreview.this.setPlayer();
                            ActivityPreview.progressDialog.dismiss();
                        }
                    });
                } else {
                    this.setPlayer();
                }
                ActivityPreview.done_press = false;
                ActivityPreview.complete = false;
                ActivityPreview.randomB = true;
                if (ActivityPreview.THEME == 4) {
                    ActivityPreview.lyricTxt1.setTextColor(Color.parseColor("#282828"));
                    ActivityPreview.lyricTxt2.setTextColor(Color.parseColor("#282828"));
                    return;
                }
                if (ActivityPreview.THEME == 5) {
                    ActivityPreview.lyricTxt1.setTextColor(Color.parseColor("#000004"));
                    ActivityPreview.lyricTxt2.setTextColor(Color.parseColor("#000004"));
                    return;
                }

            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }

    private void btnClicks() {
        this.play_pause.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (ActivityPreview.this.player.isPlaying()) {
                    ActivityPreview.this.resetPlayer();
                    return;
                }
                ActivityPreview.this.setPlayer();
                ActivityPreview.this.play_pause.setImageResource(R.drawable.pause2);
            }
        });
        try {
            this.styles = this.getResources().getAssets().list("fonts");
            this.textAdapter = new TextAdapter(this.getApplicationContext(), this.styles);
            this.textures = this.getResources().getAssets().list("texture");
            this.textureAdapter = new TextureAdapter(this, this.textures);
        } catch (Exception ee) {
            ee.printStackTrace();
        }
        this.ivSetStyle.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_unpressed);
                ActivityPreview.this.gravityLay.setVisibility(View.GONE);
                ActivityPreview.cancel = false;
                ActivityPreview.this.saveReset();
                ActivityPreview.this.resetPlayer();
                ActivityPreview.this.startActivityForResult(new Intent(ActivityPreview.this.getApplicationContext(), ActivitySelectText.class), ActivityPreview.SEL_TYPEFACE);
            }
        });
        this.ivSetolor.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_unpressed);
                ActivityPreview.this.gravityLay.setVisibility(View.GONE);
                ActivityPreview.cancel = false;
                ActivityPreview.this.resetPlayer();
                ActivityPreview.this.dialogTextColors();
            }
        });
        this.ivSetPos.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (ActivityPreview.this.gravityLay.getVisibility() == View.GONE) {
                    ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_pressed);
                    ActivityPreview.this.gravityLay.setVisibility(View.VISIBLE);
                    return;
                }
                ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_unpressed);
                ActivityPreview.this.gravityLay.setVisibility(View.GONE);
            }
        });
        this.ivSetTheme.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_unpressed);
                ActivityPreview.this.gravityLay.setVisibility(View.GONE);
                ActivityPreview.cancel = false;
                ActivityPreview.this.saveReset();
                ActivityPreview.this.resetPlayer();
                ActivityPreview.this.startActivityForResult(new Intent(ActivityPreview.this.getApplicationContext(), ActivitySelectTheme.class), ActivityPreview.SEL_THEME);
            }
        });
        this.top_left.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityPreview.this.onPause();
                ActivityPreview.this.cPos = 0;
                ActivityPreview.randomB = false;
                ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_unpressed);
                ActivityPreview.this.gravityLay.setVisibility(View.GONE);
                ActivityPreview.this.startAgain();
            }
        });
        this.top_right.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityPreview.this.onPause();
                ActivityPreview.this.cPos = 1;
                ActivityPreview.randomB = false;
                ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_unpressed);
                ActivityPreview.this.gravityLay.setVisibility(View.GONE);
                ActivityPreview.this.startAgain();
            }
        });
        this.ivBottomleft.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityPreview.this.onPause();
                ActivityPreview.this.cPos = 3;
                ActivityPreview.randomB = false;
                ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_unpressed);
                ActivityPreview.this.gravityLay.setVisibility(View.GONE);
                ActivityPreview.this.startAgain();
            }
        });
        this.ivBottomright.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityPreview.this.onPause();
                ActivityPreview.this.cPos = 2;
                ActivityPreview.randomB = false;
                ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_unpressed);
                ActivityPreview.this.gravityLay.setVisibility(View.GONE);
                ActivityPreview.this.startAgain();
            }
        });
        this.random.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityPreview.this.onPause();
                if (!ActivityPreview.randomB) {
                    ActivityPreview.randomB = true;
                    ActivityPreview.this.startAgain();
                }
                ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_unpressed);
                ActivityPreview.this.gravityLay.setVisibility(View.GONE);
            }
        });
        this.ivSetting.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityPreview.this.ivSetPos.setImageResource(R.drawable.position_unpressed);
                ActivityPreview.this.gravityLay.setVisibility(View.GONE);
                ActivityPreview.cancel = false;
                ActivityPreview.this.saveReset();
                ActivityPreview.this.resetPlayer();
                ActivityPreview.this.startActivityForResult(new Intent(ActivityPreview.this.getApplicationContext(), ActivitySetting.class), ActivityPreview.SEL_THEME);
            }
        });
        this.tvDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityPreview.this.resetPlayer();
                ActivityPreview.this.dialog();
            }
        });
    }

    private void animationSet() {
        this.animZoomLeft1 = AnimationUtils.loadAnimation(this, R.anim.zoom_left);
        this.animZoomRight1 = AnimationUtils.loadAnimation(this, R.anim.zoom_right);
        this.animZoomUp1 = AnimationUtils.loadAnimation(this, R.anim.zoom_up);
        this.animZoomBot1 = AnimationUtils.loadAnimation(this, R.anim.zoom_bot);
        this.animMoveRight1 = AnimationUtils.loadAnimation(this, R.anim.move_right);
        this.animMoveLeft1 = AnimationUtils.loadAnimation(this, R.anim.move_left);
        this.animMoveUp1 = AnimationUtils.loadAnimation(this, R.anim.move_up);
        this.animMoveBot1 = AnimationUtils.loadAnimation(this, R.anim.move_bot);
        this.animZoomLeft2 = AnimationUtils.loadAnimation(this, R.anim.zoom_left);
        this.animZoomRight2 = AnimationUtils.loadAnimation(this, R.anim.zoom_right);
        this.animZoomUp2 = AnimationUtils.loadAnimation(this, R.anim.zoom_up);
        this.animZoomBot2 = AnimationUtils.loadAnimation(this, R.anim.zoom_bot);
        this.animMoveRight2 = AnimationUtils.loadAnimation(this, R.anim.move_right);
        this.animMoveLeft2 = AnimationUtils.loadAnimation(this, R.anim.move_left);
        this.animMoveUp2 = AnimationUtils.loadAnimation(this, R.anim.move_up);
        this.animMoveBot2 = AnimationUtils.loadAnimation(this, R.anim.move_bot);
        this.crossComeImage12 = AnimationUtils.loadAnimation(this, R.anim.cross_come_image1);
        this.crossComeImage22 = AnimationUtils.loadAnimation(this, R.anim.cross_come_image2);
        this.crossComeImage32 = AnimationUtils.loadAnimation(this, R.anim.cross_come_image3);
        this.crossComeImage42 = AnimationUtils.loadAnimation(this, R.anim.cross_come_image4);
        this.crossComeImage11 = AnimationUtils.loadAnimation(this, R.anim.cross_come_image1);
        this.crossComeImage21 = AnimationUtils.loadAnimation(this, R.anim.cross_come_image2);
        this.crossComeImage31 = AnimationUtils.loadAnimation(this, R.anim.cross_come_image3);
        this.crossComeImage41 = AnimationUtils.loadAnimation(this, R.anim.cross_come_image4);
        this.centerZoomImage2 = AnimationUtils.loadAnimation(this, R.anim.center_zoom_image);
        this.centerZoomImage1 = AnimationUtils.loadAnimation(this, R.anim.center_zoom_image);
        this.imageZoomOut1 = AnimationUtils.loadAnimation(this, R.anim.image_zoom_out);
        this.imageZoomOut2 = AnimationUtils.loadAnimation(this, R.anim.image_zoom_out);
        this.animSlide_image_zoom2 = AnimationUtils.loadAnimation(this, R.anim.slide_image_zoom);
        this.animSlide_image_zoom1 = AnimationUtils.loadAnimation(this, R.anim.slide_image_zoom);
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityPreview");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void bindView() {
        lyricTxt1 = findViewById(R.id.lyric_txt1);
        lyricTxt2 = findViewById(R.id.lyric_txt2);
        this.rel = findViewById(R.id.rel);
        this.gravityLay = findViewById(R.id.gravity_lay);
        this.addTextLay = findViewById(R.id.add_text_lay);
        this.addTextLay1 = findViewById(R.id.add_text_lay1);
        this.imageview1 = findViewById(R.id.user_image1);
        this.imageview11 = findViewById(R.id.user_image11);
        this.imageview2 = findViewById(R.id.user_image2);
        this.imageview22 = findViewById(R.id.user_image22);
        this.save_lay = findViewById(R.id.save_lay);
        this.save_lay2 = findViewById(R.id.save_lay2);
        this.relativeLayout = findViewById(R.id.contain_lay);
        this.play_pause = findViewById(R.id.play_pause);
        this.ivPreview = findViewById(R.id.image_preview);
        this.ivBack = findViewById(R.id.back);
        this.tvDone = findViewById(R.id.done);
        this.ivSetStyle = findViewById(R.id.set_style);
        this.ivSetPos = findViewById(R.id.set_pos);
        this.ivSetolor = findViewById(R.id.set_color);
        this.ivSetTheme = findViewById(R.id.set_theme);
        this.ivSetting = findViewById(R.id.setting);
        this.top_left = findViewById(R.id.top_left);
        this.top_right = findViewById(R.id.top_right);
        this.ivBottomleft = findViewById(R.id.bottom_left);
        this.ivBottomright = findViewById(R.id.bottom_right);
        this.random = findViewById(R.id.random);
    }


    protected void onPause() {
        this.visible(this.imageview1);
        this.visible(this.imageview2);
        this.visible(this.imageview11);
        this.visible(this.imageview22);
        ActivityPreview.cancel = true;
        this.saveReset();
        this.resetPlayer();
        if (!ActivityPreview.complete && ActivityPreview.done_press) {
            this.dialog_savee.dismiss();
            this.countDownTimer.cancel();
            this.dialog_savee = null;
        }
        super.onPause();
    }

    protected void onResume() {
        if (this.file != null) {
            if (this.preferences.get_ALL_CAPS()) {
                ActivityPreview.lyricTxt1.setAllCaps(true);
                ActivityPreview.lyricTxt2.setAllCaps(true);
            } else {
                ActivityPreview.lyricTxt1.setAllCaps(false);
                ActivityPreview.lyricTxt2.setAllCaps(false);
            }
            this.save_lay.post(new Runnable() {
                @Override
                public void run() {
                    if (!ActivityPreview.complete) {
                        ActivityPreview.cancel = false;
                        ActivityPreview.this.start_saving();
                    }
                }
            });
            if (!ActivityPreview.complete && ActivityPreview.done_press) {
                this.backDialog();
            }
        }
        super.onResume();
    }

    void resetPlayer() {
        this.imageview22.clearAnimation();
        this.player.reset();
        this.handler.removeCallbacksAndMessages(null);
        this.build(this.photo2.get(7), this.imageview22);
        this.imageview22.bringToFront();
        this.imageview22.setVisibility(View.VISIBLE);
        this.play_pause.setImageResource(R.drawable.play2);
    }

    void saveReset() {
        this.cancelAnim1();
        if (!ActivityPreview.complete) {
            this.handler1.removeCallbacksAndMessages(null);
            this.handler.removeCallbacksAndMessages(null);
            this.addTextLay.removeAllViews();
            this.line_texts2.clear();
            ActivityPreview.images_bit.clear();
            if (this.copyBitmap != null) {
                this.copyBitmap.cancel(true);
            }
            if (this.saveBitmap != null) {
                this.saveBitmap.cancel(true);
            }
            final StringBuilder sb = new StringBuilder();
            sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
            sb.append("/");
            sb.append(this.getResources().getString(R.string.app_name));
            final String string = sb.toString();
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(string);
            sb2.append("/");
            sb2.append(this.getString(R.string.temp_folder));
            sb2.append("/temp");
            MainActivity.deleteRecursive(new File(sb2.toString()));
        }
    }

    void saveTheme0(final String text) {
        final int n = ActivityPreview.w * 15 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay.addView(textView);
        textView.setTypeface(ActivityPreview.lyricTxt1.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt1.getCurrentTextColor());
        textView.setText(text);
        textView.setBackgroundResource(R.drawable.textview_bg_red);
        textView.setTextSize(20.0f);
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
        } else {
            textView.setAllCaps(false);
        }
        int n2;
        if (MainActivity.anInt == 1) {
            n2 = ActivityPreview.w * 25 / 1080;
            textView.setTextSize(23.0f);
        } else {
            n2 = ActivityPreview.w * 15 / 1080;
        }
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        if (!ActivityPreview.randomB) {
            this.currentLine1 = this.cPos;
        }
        if (this.currentLine1 != 0 && this.currentLine1 != 4) {
            if (this.currentLine1 != 1 && this.currentLine1 != 5) {
                if (this.currentLine1 != 2 && this.currentLine1 != 6) {
                    if (this.currentLine1 == 3 || this.currentLine1 == 7) {
                        this.addTextLay.setGravity(83);
                        layoutParams.setMargins(n, 0, 0, n2);
                    }
                } else {
                    this.addTextLay.setGravity(85);
                    layoutParams.setMargins(0, 0, n, n2);
                }
            } else {
                this.addTextLay.setGravity(53);
                layoutParams.setMargins(0, n2, n, 0);
            }
        } else {
            this.addTextLay.setGravity(51);
            layoutParams.setMargins(n, n2, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setPadding(n, n, n, n);
    }

    void saveTheme1(final String text, final int n) {
        final int n2 = ActivityPreview.w * 15 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay.addView(textView);
        textView.setTypeface(ActivityPreview.lyricTxt1.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt1.getCurrentTextColor());
        textView.setText(text);
        textView.setBackgroundResource(R.drawable.textview_bg_yellow);
        textView.setTextSize(20.0f);
        textView.setVisibility(View.INVISIBLE);
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
        } else {
            textView.setAllCaps(false);
        }
        int n3;
        if (MainActivity.anInt == 1) {
            textView.setTextSize(23.0f);
            n3 = ActivityPreview.w * 25 / 1080;
        } else {
            n3 = ActivityPreview.w * 15 / 1080;
        }
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        if (!ActivityPreview.randomB) {
            this.currentLine1 = this.cPos;
        }
        if (this.currentLine1 != 0 && this.currentLine1 != 4) {
            if (this.currentLine1 != 1 && this.currentLine1 != 5) {
                if (this.currentLine1 != 2 && this.currentLine1 != 6) {
                    if (this.currentLine1 == 3 || this.currentLine1 == 7) {
                        this.addTextLay.setGravity(83);
                        layoutParams.setMargins(n2, 0, 0, n3);
                    }
                } else {
                    this.addTextLay.setGravity(85);
                    layoutParams.setMargins(0, 0, n2, n3);
                }
            } else {
                this.addTextLay.setGravity(53);
                layoutParams.setMargins(0, n3, n2, 0);
            }
        } else {
            this.addTextLay.setGravity(51);
            layoutParams.setMargins(n2, n3, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setPadding(n2, n2, n2, n2);
        this.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                textView.setVisibility(View.VISIBLE);
                if (ActivityPreview.this.currentLine1 != 0 && ActivityPreview.this.currentLine1 != 4) {
                    if (ActivityPreview.this.currentLine1 == 1 || ActivityPreview.this.currentLine1 == 5) {
                        ActivityPreview.this.animSlide_from_right1 = AnimationUtils.loadAnimation(ActivityPreview.this, R.anim.slide_from_right);
                        textView.startAnimation(ActivityPreview.this.animSlide_from_right1);
                        return;
                    }
                    if (ActivityPreview.this.currentLine1 == 2 || ActivityPreview.this.currentLine1 == 6) {
                        ActivityPreview.this.animSlide_from_right1 = AnimationUtils.loadAnimation(ActivityPreview.this, R.anim.slide_from_right);
                        textView.startAnimation(ActivityPreview.this.animSlide_from_right1);
                        return;
                    }
                    if (ActivityPreview.this.currentLine1 == 3 || ActivityPreview.this.currentLine1 == 7) {
                        ActivityPreview.this.animSlide_from_left1 = AnimationUtils.loadAnimation(ActivityPreview.this, R.anim.slide_from_left);
                        textView.startAnimation(ActivityPreview.this.animSlide_from_left1);
                    }
                } else {
                    ActivityPreview.this.animSlide_from_left1 = AnimationUtils.loadAnimation(ActivityPreview.this, R.anim.slide_from_left);
                    textView.startAnimation(ActivityPreview.this.animSlide_from_left1);
                }
            }
        }, n * 200);
    }

    void saveTheme2(final String text) {
        final int n = ActivityPreview.w * 15 / 1080;
        final int n2 = ActivityPreview.w * 40 / 1080;
        final TextView textView = new TextView(this);
        textView.setTextSize(20.0f);
        final double n3 = ActivityPreview.w;
        Double.isNaN(n3);
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams((int) (n3 * 0.7), -2);
        if (!ActivityPreview.randomB) {
            this.currentLine1 = this.cPos;
        }
        if (this.currentLine1 != 0 && this.currentLine1 != 4) {
            if (this.currentLine1 != 1 && this.currentLine1 != 5) {
                if (this.currentLine1 != 2 && this.currentLine1 != 6) {
                    if (this.currentLine1 == 3 || this.currentLine1 == 7) {
                        this.addTextLay.setGravity(83);
                        textView.startAnimation(this.animSlide_from_top1 = AnimationUtils.loadAnimation(this.getApplicationContext(), R.anim.slide_from_top));
                        layoutParams.setMargins(-n * 2, 0, 0, n * 2);
                    }
                } else {
                    this.addTextLay.setGravity(85);
                    textView.startAnimation(this.animSlide_from_top1 = AnimationUtils.loadAnimation(this.getApplicationContext(), R.anim.slide_from_top));
                    layoutParams.setMargins(0, n, -n * 2, n * 2);
                }
            } else {
                this.addTextLay.setGravity(53);
                textView.startAnimation(this.animSlide_from_bot1 = AnimationUtils.loadAnimation(this.getApplicationContext(), R.anim.slide_from_bot));
                layoutParams.setMargins(0, n * 2, -n * 2, 0);
            }
        } else {
            this.addTextLay.setGravity(51);
            textView.startAnimation(this.animSlide_from_bot1 = AnimationUtils.loadAnimation(this.getApplicationContext(), R.anim.slide_from_bot));
            layoutParams.setMargins(-n * 2, n * 2, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setGravity(17);
        textView.setTypeface(ActivityPreview.lyricTxt1.getTypeface());
        textView.setTextColor(getResources().getColor(R.color.black));
        textView.setText(text);
        textView.setBackgroundResource(R.drawable.textview_bg_black);
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
        } else {
            textView.setAllCaps(false);
        }
        final GradientDrawable gradientDrawable = (GradientDrawable) textView.getBackground().getCurrent();
        final float n4 = n;
        gradientDrawable.setCornerRadii(new float[]{n4, n4, n4, n4, n4, n4, n4, n4});
        textView.setPadding(n2, n2, n2, n2);
        this.addTextLay.addView(textView);
    }

    void saveTheme3(final String text) {
        final int n = ActivityPreview.w * 25 / 1080;
        final int n2 = ActivityPreview.w * 60 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay.addView(textView);
        this.addTextLay.setPadding(0, 0, 0, 0);
        textView.setTextSize(20.0f);
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ActivityPreview.w / 2, ActivityPreview.w / 2);
        if (!ActivityPreview.randomB) {
            this.currentLine1 = this.cPos;
        }
        if (this.currentLine1 != 0 && this.currentLine1 != 4) {
            if (this.currentLine1 != 1 && this.currentLine1 != 5) {
                if (this.currentLine1 != 2 && this.currentLine1 != 6) {
                    if (this.currentLine1 == 3 || this.currentLine1 == 7) {
                        this.addTextLay.setGravity(83);
                        textView.setBackgroundResource(R.drawable.circle_bottom_left);
                        textView.setGravity(83);
                        textView.setPadding(n, 0, n2, n);
                        textView.startAnimation(this.crossCome31 = AnimationUtils.loadAnimation(this, R.anim.cross_come3));
                    }
                } else {
                    this.addTextLay.setGravity(85);
                    textView.setBackgroundResource(R.drawable.circle_bottom_right);
                    textView.setGravity(85);
                    textView.setPadding(n2, 0, n, n);
                    textView.startAnimation(this.crossCome41 = AnimationUtils.loadAnimation(this, R.anim.cross_come4));
                }
            } else {
                this.addTextLay.setGravity(53);
                textView.setBackgroundResource(R.drawable.circle_top_right);
                textView.setGravity(53);
                textView.setPadding(n2, n, n, 0);
                textView.startAnimation(this.crossCome21 = AnimationUtils.loadAnimation(this, R.anim.cross_come2));
            }
        } else {
            this.addTextLay.setGravity(51);
            textView.setBackgroundResource(R.drawable.circle_top_left);
            textView.setGravity(51);
            textView.setPadding(n, n, n2, 0);
            textView.startAnimation(this.crossCome11 = AnimationUtils.loadAnimation(this, R.anim.cross_come1));
        }
        textView.setLayoutParams(layoutParams);
        textView.setTypeface(ActivityPreview.lyricTxt1.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt1.getCurrentTextColor());
        textView.setText(text);
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
            return;
        }
        textView.setAllCaps(false);
    }

    void saveTheme4(final String text) {
        final int n = ActivityPreview.w * 25 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay.addView(textView);
        this.addTextLay.setPadding(0, 0, 0, 0);
        textView.setTextSize(22.0f);
        final double n2 = ActivityPreview.w;
        Double.isNaN(n2);
        final int n3 = (int) (n2 * 0.6);
        final double n4 = ActivityPreview.w;
        Double.isNaN(n4);
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(n3, (int) (n4 * 0.4));
        if (!ActivityPreview.randomB) {
            this.currentLine1 = this.cPos;
        }
        if (this.currentLine1 != 0 && this.currentLine1 != 4) {
            if (this.currentLine1 != 1 && this.currentLine1 != 5) {
                if (this.currentLine1 != 2 && this.currentLine1 != 6) {
                    if (this.currentLine1 == 3 || this.currentLine1 == 7) {
                        this.addTextLay.setGravity(83);
                        layoutParams.setMargins(n, 0, 0, n);
                    }
                } else {
                    this.addTextLay.setGravity(85);
                    layoutParams.setMargins(0, 0, n, n);
                }
            } else {
                this.addTextLay.setGravity(53);
                layoutParams.setMargins(0, n, n, 0);
            }
        } else {
            this.addTextLay.setGravity(51);
            layoutParams.setMargins(n, n, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setTypeface(ActivityPreview.lyricTxt1.getTypeface());
        textView.setTextColor(getResources().getColor(R.color.white));
        textView.setBackgroundResource(R.drawable.textview_bg_theme4);
        textView.setText(text);
        textView.setGravity(17);
        textView.startAnimation(this.animCenterZoom1 = AnimationUtils.loadAnimation(this, R.anim.center_zoom));
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
            return;
        }
        textView.setAllCaps(false);
    }

    void saveTheme5(final String text, final int n) {
        final int n2 = ActivityPreview.w * 15 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay.addView(textView);
        textView.setTypeface(ActivityPreview.lyricTxt1.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt1.getCurrentTextColor());
        textView.setText(text);
        textView.setBackgroundResource(R.drawable.textview_bg_sky);
        textView.setTextSize(20.0f);
        textView.setVisibility(View.INVISIBLE);
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
        } else {
            textView.setAllCaps(false);
        }
        int n3;
        if (MainActivity.anInt == 1) {
            textView.setTextSize(23.0f);
            n3 = ActivityPreview.w * 25 / 1080;
        } else {
            n3 = ActivityPreview.w * 15 / 1080;
        }
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        if (!ActivityPreview.randomB) {
            this.currentLine1 = this.cPos;
        }
        if (this.currentLine1 != 0 && this.currentLine1 != 4) {
            if (this.currentLine1 != 1 && this.currentLine1 != 5) {
                if (this.currentLine1 != 2 && this.currentLine1 != 6) {
                    if (this.currentLine1 == 3 || this.currentLine1 == 7) {
                        this.addTextLay.setGravity(83);
                        layoutParams.setMargins(n2, 0, 0, n3);
                    }
                } else {
                    this.addTextLay.setGravity(85);
                    layoutParams.setMargins(0, 0, n2, n3);
                }
            } else {
                this.addTextLay.setGravity(53);
                layoutParams.setMargins(0, n3, n2, 0);
            }
        } else {
            this.addTextLay.setGravity(51);
            layoutParams.setMargins(n2, n3, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setPadding(n2, n2, n2, n2);
        this.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                textView.setVisibility(View.VISIBLE);
                ActivityPreview.this.animZoomInText1 = AnimationUtils.loadAnimation(ActivityPreview.this, R.anim.zoom_in_text);
                textView.startAnimation(ActivityPreview.this.animZoomInText1);
            }
        }, n * 300);
    }

    void saveTheme6(final String text) {
        final int n = ActivityPreview.w * 15 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay.addView(textView);
        this.addTextLay.setPadding(0, 0, 0, 0);
        textView.setTextSize(22.0f);
        final double n2 = ActivityPreview.w;
        Double.isNaN(n2);
        final int n3 = (int) (n2 * 0.55);
        final double n4 = ActivityPreview.w;
        Double.isNaN(n4);
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(n3, (int) (n4 * 0.55));
        int n5;
        if (MainActivity.anInt == 1) {
            n5 = ActivityPreview.w * 25 / 1080;
        } else {
            n5 = ActivityPreview.w * 15 / 1080;
        }
        if (!ActivityPreview.randomB) {
            this.currentLine1 = this.cPos;
        }
        if (this.currentLine1 != 0 && this.currentLine1 != 4) {
            if (this.currentLine1 != 1 && this.currentLine1 != 5) {
                if (this.currentLine1 != 2 && this.currentLine1 != 6) {
                    if (this.currentLine1 == 3 || this.currentLine1 == 7) {
                        this.addTextLay.setGravity(83);
                        layoutParams.setMargins(n, 0, 0, n5);
                    }
                } else {
                    this.addTextLay.setGravity(85);
                    layoutParams.setMargins(0, 0, n, n5);
                }
            } else {
                this.addTextLay.setGravity(53);
                layoutParams.setMargins(0, n5, n, 0);
            }
        } else {
            this.addTextLay.setGravity(51);
            layoutParams.setMargins(n, n5, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setTypeface(ActivityPreview.lyricTxt1.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt1.getCurrentTextColor());
        textView.setBackgroundResource(R.drawable.textview_bg_circle);
        textView.setText(text);
        textView.setGravity(17);
        textView.setPadding(n, n, n, n);
        textView.startAnimation(this.centerZoomRotate1 = AnimationUtils.loadAnimation(this, R.anim.center_zoom_rotate));
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
            return;
        }
        textView.setAllCaps(false);
    }

    void saveTheme7(final String text) {
        final int n = ActivityPreview.w * 15 / 1080;
        final TextView textView = new TextView(this);
        this.addTextLay.addView(textView);
        this.addTextLay.setPadding(0, 0, 0, 0);
        textView.setTextSize(20.0f);
        final double n2 = ActivityPreview.w;
        Double.isNaN(n2);
        final int n3 = (int) (n2 * 0.45);
        final double n4 = ActivityPreview.w;
        Double.isNaN(n4);
        final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(n3, (int) (n4 * 0.45));
        int n5;
        if (MainActivity.anInt == 1) {
            n5 = ActivityPreview.w * 25 / 1080;
        } else {
            n5 = ActivityPreview.w * 15 / 1080;
        }
        if (!ActivityPreview.randomB) {
            this.currentLine1 = this.cPos;
        }
        if (this.currentLine1 != 0 && this.currentLine1 != 4) {
            if (this.currentLine1 != 1 && this.currentLine1 != 5) {
                if (this.currentLine1 != 2 && this.currentLine1 != 6) {
                    if (this.currentLine1 == 3 || this.currentLine1 == 7) {
                        this.addTextLay.setGravity(83);
                        layoutParams.setMargins(n, 0, 0, n5);
                    }
                } else {
                    this.addTextLay.setGravity(85);
                    layoutParams.setMargins(0, 0, n, n5);
                }
            } else {
                this.addTextLay.setGravity(53);
                layoutParams.setMargins(0, n5, n, 0);
            }
        } else {
            this.addTextLay.setGravity(51);
            layoutParams.setMargins(n, n5, 0, 0);
        }
        textView.setLayoutParams(layoutParams);
        textView.setTypeface(ActivityPreview.lyricTxt1.getTypeface());
        textView.setTextColor(ActivityPreview.lyricTxt1.getCurrentTextColor());
        textView.setBackgroundResource(R.drawable.textview_bg_red_sq);
        textView.setText(text);
        textView.setGravity(17);
        textView.setPadding(n, n, n, n);
        textView.startAnimation(this.animZoomInText1 = AnimationUtils.loadAnimation(this, R.anim.zoom_in_text));
        final GradientDrawable gradientDrawable = (GradientDrawable) textView.getBackground().getCurrent();
        final float n6 = n;
        gradientDrawable.setCornerRadii(new float[]{n6, n6, n6, n6, n6, n6, n6, n6});
        if (this.preferences.get_ALL_CAPS()) {
            textView.setAllCaps(true);
            return;
        }
        textView.setAllCaps(false);
    }

    void save_start_pos_theme0(int i) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(i);
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.i);
        if (cancel) {
            saveReset();
            return;
        }
        this.addTextLay.removeAllViews();
        this.line_texts2.clear();
        images_bit.clear();
        lyricTxt1.setText(this.strings11[i]);
        this.currentLine1 = i;
        build(this.photo2.get(this.currentLine1), this.imageview1);
        this.addTextLay.bringToFront();
        this.handler1.post(new Runnable() {
            public void run() {
                Layout layout = ActivityPreview.lyricTxt1.getLayout();
                String charSequence = ActivityPreview.lyricTxt1.getText().toString();
                int i = 0;
                int i2 = 0;
                while (i < ActivityPreview.lyricTxt1.getLineCount()) {
                    int lineEnd = layout.getLineEnd(i);
                    ActivityPreview.this.line_texts2.add(charSequence.substring(i2, lineEnd));
                    i++;
                    i2 = lineEnd;
                }
                for (int i3 = 0; i3 < ActivityPreview.this.line_texts2.size(); i3++) {
                    ActivityPreview.this.saveTheme0(ActivityPreview.this.line_texts2.get(i3));
                }
            }
        });
        new Handler().postDelayed(new Runnable() {
            public void run() {
                ActivityPreview.this.save_lay.setDrawingCacheEnabled(false);
                ActivityPreview.this.save_lay.setDrawingCacheEnabled(true);
                ActivityPreview.this.save_lay.buildDrawingCache();
                new SaveBitmap0(ActivityPreview.this.save_lay.getDrawingCache()).execute();
            }
        }, 1000);
    }

    void save_start_pos_theme1(final int current_line1) {
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(current_line1);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(this.i);
        if (ActivityPreview.cancel) {
            this.saveReset();
            return;
        }
        this.cancelAnim1();
        this.addTextLay.removeAllViews();
        this.line_texts2.clear();
        ActivityPreview.images_bit.clear();
        this.copyBitmap = null;
        (this.copyBitmap = new CopyBitmap()).execute();
        ActivityPreview.lyricTxt1.setText(this.strings11[current_line1]);
        if ((this.currentLine1 = current_line1) == 0) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.animZoomRight1);
            this.imageview2.startAnimation(this.animMoveRight1);
            this.setInvi(this.imageview2);
        } else if (current_line1 == 1) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.animZoomUp1);
            this.imageview1.startAnimation(this.animMoveUp1);
            this.imageview2.bringToFront();
            this.setInvi(this.imageview1);
        } else if (current_line1 == 2) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.animZoomLeft1);
            this.imageview2.startAnimation(this.animMoveLeft1);
            this.imageview1.bringToFront();
            this.setInvi(this.imageview2);
        } else if (current_line1 == 3) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.animZoomBot1);
            this.imageview1.startAnimation(this.animMoveBot1);
            this.imageview2.bringToFront();
            this.setInvi(this.imageview1);
        } else if (current_line1 == 4) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.animZoomRight1);
            this.imageview2.startAnimation(this.animMoveRight1);
            this.imageview1.bringToFront();
            this.setInvi(this.imageview2);
        } else if (current_line1 == 5) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.animZoomUp1);
            this.imageview1.startAnimation(this.animMoveUp1);
            this.imageview2.bringToFront();
            this.setInvi(this.imageview1);
        } else if (current_line1 == 6) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.animZoomLeft1);
            this.imageview2.startAnimation(this.animMoveLeft1);
            this.imageview1.bringToFront();
            this.setInvi(this.imageview2);
        } else if (current_line1 == 7) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.animZoomBot1);
            this.imageview1.startAnimation(this.animMoveBot1);
            this.imageview2.bringToFront();
            this.setInvi(this.imageview1);
        }
        this.animZoomRight1.setFillAfter(true);
        this.animZoomUp1.setFillAfter(true);
        this.animZoomBot1.setFillAfter(true);
        this.animZoomLeft1.setFillAfter(true);
        this.addTextLay.bringToFront();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                final Layout layout = ActivityPreview.lyricTxt1.getLayout();
                final String string = ActivityPreview.lyricTxt1.getText().toString();
                final int n = 0;
                int n2 = 0;
                int n3 = 0;
                int i;
                while (true) {
                    i = n;
                    if (n2 >= ActivityPreview.lyricTxt1.getLineCount()) {
                        break;
                    }
                    final int lineEnd = layout.getLineEnd(n2);
                    ActivityPreview.this.line_texts2.add(string.substring(n3, lineEnd));
                    ++n2;
                    n3 = lineEnd;
                }
                while (i < ActivityPreview.this.line_texts2.size()) {
                    ActivityPreview.this.saveTheme1(ActivityPreview.this.line_texts2.get(i), i);
                    ++i;
                }
            }
        }, 400L);
    }

    void save_start_pos_theme2(final int current_line1) {
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(current_line1);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(this.i);
        if (ActivityPreview.cancel) {
            this.saveReset();
            return;
        }
        this.cancelAnim1();
        this.addTextLay.removeAllViews();
        this.line_texts2.clear();
        ActivityPreview.images_bit.clear();
        this.copyBitmap = null;
        (this.copyBitmap = new CopyBitmap()).execute();
        ActivityPreview.lyricTxt1.setText(this.strings11[current_line1]);
        if ((this.currentLine1 = current_line1) == 0) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.animZoomBot1);
            this.imageview2.startAnimation(this.animMoveBot1);
            this.setInvi(this.imageview2);
        } else if (current_line1 == 1) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.animZoomBot1);
            this.imageview1.startAnimation(this.animMoveBot1);
            this.imageview2.bringToFront();
            this.setInvi(this.imageview1);
        } else if (current_line1 == 2) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.animZoomUp1);
            this.imageview2.startAnimation(this.animMoveUp1);
            this.imageview1.bringToFront();
            this.setInvi(this.imageview2);
        } else if (current_line1 == 3) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.animZoomUp1);
            this.imageview1.startAnimation(this.animMoveUp1);
            this.imageview2.bringToFront();
            this.setInvi(this.imageview1);
        } else if (current_line1 == 4) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.animZoomBot1);
            this.imageview2.startAnimation(this.animMoveBot1);
            this.imageview1.bringToFront();
            this.setInvi(this.imageview2);
        } else if (current_line1 == 5) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.animZoomBot1);
            this.imageview1.startAnimation(this.animMoveBot1);
            this.imageview2.bringToFront();
            this.setInvi(this.imageview1);
        } else if (current_line1 == 6) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.animZoomUp1);
            this.imageview2.startAnimation(this.animMoveUp1);
            this.imageview1.bringToFront();
            this.setInvi(this.imageview2);
        } else if (current_line1 == 7) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.animZoomUp1);
            this.imageview1.startAnimation(this.animMoveUp1);
            this.imageview2.bringToFront();
            this.setInvi(this.imageview1);
        }
        this.animZoomRight1.setFillAfter(true);
        this.animZoomUp1.setFillAfter(true);
        this.animZoomBot1.setFillAfter(true);
        this.animZoomLeft1.setFillAfter(true);
        this.addTextLay.bringToFront();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityPreview.this.saveTheme2(ActivityPreview.lyricTxt1.getText().toString());
            }
        }, 400L);
    }

    void save_start_pos_theme3(final int current_line1) {
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(current_line1);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(this.i);
        if (ActivityPreview.cancel) {
            this.saveReset();
            return;
        }
        this.cancelAnim1();
        this.addTextLay.removeAllViews();
        this.line_texts2.clear();
        ActivityPreview.images_bit.clear();
        this.copyBitmap = null;
        (this.copyBitmap = new CopyBitmap()).execute();
        ActivityPreview.lyricTxt1.setText(this.strings11[current_line1]);
        if ((this.currentLine1 = current_line1) == 0) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.crossComeImage41);
            this.imageview1.bringToFront();
        } else if (current_line1 == 1) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.crossComeImage31);
            this.imageview2.bringToFront();
        } else if (current_line1 == 2) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.crossComeImage11);
            this.imageview1.bringToFront();
        } else if (current_line1 == 3) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.crossComeImage21);
            this.imageview2.bringToFront();
        } else if (current_line1 == 4) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.crossComeImage41);
            this.imageview1.bringToFront();
        } else if (current_line1 == 5) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.crossComeImage31);
            this.imageview2.bringToFront();
        } else if (current_line1 == 6) {
            this.build(this.photo2.get(current_line1), this.imageview1);
            this.imageview1.startAnimation(this.crossComeImage11);
            this.imageview1.bringToFront();
        } else if (current_line1 == 7) {
            this.build(this.photo2.get(current_line1), this.imageview2);
            this.imageview2.startAnimation(this.crossComeImage21);
            this.imageview2.bringToFront();
        }
        this.crossComeImage11.setFillAfter(true);
        this.crossComeImage21.setFillAfter(true);
        this.crossComeImage31.setFillAfter(true);
        this.crossComeImage41.setFillAfter(true);
        this.addTextLay.bringToFront();
        this.saveTheme3(ActivityPreview.lyricTxt1.getText().toString());
    }

    void save_start_pos_theme4(final int current_line1) {
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(current_line1);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(this.i);
        if (ActivityPreview.cancel) {
            this.saveReset();
            return;
        }
        this.cancelAnim1();
        this.addTextLay.removeAllViews();
        this.line_texts2.clear();
        ActivityPreview.images_bit.clear();
        this.copyBitmap = null;
        (this.copyBitmap = new CopyBitmap()).execute();
        ActivityPreview.lyricTxt1.setText(this.strings11[current_line1]);
        this.currentLine1 = current_line1;
        this.gone(this.imageview1);
        this.build(this.photo2.get(current_line1), this.imageview2);
        this.imageview2.startAnimation(this.centerZoomImage1);
        this.imageview2.bringToFront();
        this.centerZoomImage1.setFillAfter(true);
        this.addTextLay.bringToFront();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityPreview.this.saveTheme4(ActivityPreview.lyricTxt1.getText().toString());
            }
        }, 400L);
    }

    void save_start_pos_theme5(final int current_line1) {
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(current_line1);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(this.i);
        if (ActivityPreview.cancel) {
            this.saveReset();
            return;
        }
        this.cancelAnim1();
        this.addTextLay.removeAllViews();
        this.line_texts2.clear();
        ActivityPreview.images_bit.clear();
        this.copyBitmap = null;
        (this.copyBitmap = new CopyBitmap()).execute();
        ActivityPreview.lyricTxt1.setText(this.strings11[current_line1]);
        this.currentLine1 = current_line1;
        this.gone(this.imageview1);
        this.build(this.photo2.get(current_line1), this.imageview2);
        this.imageview2.startAnimation(this.centerZoomImage1);
        this.imageview2.bringToFront();
        this.centerZoomImage1.setFillAfter(true);
        this.addTextLay.bringToFront();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                final Layout layout = ActivityPreview.lyricTxt1.getLayout();
                final String string = ActivityPreview.lyricTxt1.getText().toString();
                final int n = 0;
                int n2 = 0;
                int n3 = 0;
                int i;
                while (true) {
                    i = n;
                    if (n2 >= ActivityPreview.lyricTxt1.getLineCount()) {
                        break;
                    }
                    final int lineEnd = layout.getLineEnd(n2);
                    ActivityPreview.this.line_texts2.add(string.substring(n3, lineEnd));
                    ++n2;
                    n3 = lineEnd;
                }
                while (i < ActivityPreview.this.line_texts2.size()) {
                    ActivityPreview.this.saveTheme5(ActivityPreview.this.line_texts2.get(i), i);
                    ++i;
                }
            }
        }, 400L);
    }

    void save_start_pos_theme6(final int current_line1) {
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(current_line1);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(this.i);
        if (ActivityPreview.cancel) {
            this.saveReset();
            return;
        }
        this.cancelAnim1();
        this.addTextLay.removeAllViews();
        this.line_texts2.clear();
        ActivityPreview.images_bit.clear();
        this.copyBitmap = null;
        (this.copyBitmap = new CopyBitmap()).execute();
        ActivityPreview.lyricTxt1.setText(this.strings11[current_line1]);
        this.currentLine1 = current_line1;
        this.gone(this.imageview1);
        this.build(this.photo2.get(current_line1), this.imageview2);
        this.imageview2.startAnimation(this.imageZoomOut1);
        this.imageview2.bringToFront();
        this.imageZoomOut1.setFillAfter(true);
        this.addTextLay.bringToFront();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityPreview.this.saveTheme6(ActivityPreview.lyricTxt1.getText().toString());
            }
        }, 400L);
    }

    void save_start_pos_theme7(final int current_line1) {
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(current_line1);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(this.i);
        if (ActivityPreview.cancel) {
            this.saveReset();
            return;
        }
        this.cancelAnim1();
        this.addTextLay.removeAllViews();
        this.line_texts2.clear();
        ActivityPreview.images_bit.clear();
        this.copyBitmap = null;
        (this.copyBitmap = new CopyBitmap()).execute();
        ActivityPreview.lyricTxt1.setText(this.strings11[current_line1]);
        this.currentLine1 = current_line1;
        this.gone(this.imageview1);
        this.build(this.photo2.get(current_line1), this.imageview2);
        this.imageview2.startAnimation(this.animSlide_image_zoom1);
        this.imageview2.bringToFront();
        this.animSlide_image_zoom1.setFillAfter(true);
        this.addTextLay.bringToFront();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityPreview.this.saveTheme7(ActivityPreview.lyricTxt1.getText().toString());
            }
        }, 400L);
    }

    private void backDialog() {
        this.dialog_savee = new Dialog(ActivityPreview.this);
        this.dialog_savee.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.dialog_savee.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        this.dialog_savee.getWindow().setGravity(Gravity.CENTER);
        this.dialog_savee.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        this.dialog_savee.setContentView(R.layout.dialog_layout);
        dialog_savee.setCancelable(false);

        ImageView imageView = dialog_savee.findViewById(R.id.gifImageView);
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.rotate_my);
        imageView.startAnimation(animation);

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(NativeAd nativeAd) {
                boolean isDestroyed = false;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    isDestroyed = isDestroyed();
                }
                if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                    nativeAd.destroy();
                    return;
                }
                if (ActivityPreview.this.nativeAd != null) {
                    ActivityPreview.this.nativeAd.destroy();
                }
                ActivityPreview.this.nativeAd = nativeAd;
                FrameLayout frameLayout = dialog_savee.findViewById(R.id.fl_adplaceholder);
                NativeAdView adView =
                        (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(nativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        this.dialog_savee.setCanceledOnTouchOutside(false);
        final TextView textView = this.dialog_savee.findViewById(R.id.title);
        this.txt_pro = this.dialog_savee.findViewById(R.id.txt_pro);
        (this.pro_seek = this.dialog_savee.findViewById(R.id.pro_seek)).setMax(100);
        if (ActivityPreview.THEME == 0) {
            this.countDownTimer = new CountDownTimer(140000L, 400L) {
                public void onFinish() {
                    if (!Utils.complete) {
                        ActivityPreview.this.txt_pro.setText("99%");
                        ActivityPreview.this.pro_seek.setProgress(99);
                    }
                }

                public void onTick(long n) {
                    n = (140000L - n) / 400L;
                    if (n <= 99L && !Utils.complete) {
                        final TextView txt_pro = ActivityPreview.this.txt_pro;
                        final StringBuilder sb = new StringBuilder();
                        sb.append("");
                        sb.append(n);
                        txt_pro.setText(sb.toString());
                        ActivityPreview.this.pro_seek.setProgress(Integer.parseInt(ActivityPreview.this.txt_pro.getText().toString()));
                        final TextView txt_pro2 = ActivityPreview.this.txt_pro;
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append(ActivityPreview.this.pro_seek.getProgress());
                        sb2.append("%");
                        txt_pro2.setText(sb2.toString());
                    }
                }
            }.start();
        } else {
            this.countDownTimer = new CountDownTimer(140000L, 1000L) {
                public void onFinish() {
                    if (!Utils.complete) {
                        ActivityPreview.this.txt_pro.setText("99%");
                        ActivityPreview.this.pro_seek.setProgress(99);
                    }
                }

                public void onTick(long n) {
                    n = (140000L - n) / 1000L;
                    if (n <= 99L && !Utils.complete) {
                        final TextView txt_pro = ActivityPreview.this.txt_pro;
                        final StringBuilder sb = new StringBuilder();
                        sb.append("");
                        sb.append(n);
                        txt_pro.setText(sb.toString());
                        ActivityPreview.this.pro_seek.setProgress(Integer.parseInt(ActivityPreview.this.txt_pro.getText().toString()));
                        final TextView txt_pro2 = ActivityPreview.this.txt_pro;
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append(ActivityPreview.this.pro_seek.getProgress());
                        sb2.append("%");
                        txt_pro2.setText(sb2.toString());
                    }
                }
            }.start();
        }
        dialog_savee.show();
    }

    public void setComplete(final String s) {
        this.txt_pro.setText("100%");
        this.pro_seek.setProgress(100);
        if (ActivityPreview.cancel) {
            final StringBuilder sb = new StringBuilder();
            sb.append(this.videoName);
            sb.append(".mp4");
            this.showNotification(this, "Video Saved", sb.toString());
            this.finish();
            return;
        }
        this.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityPreview.this.dialog_savee.dismiss();
                sscopy = s;
                if (MyApplication.isShowAd == 1) {
                    GoToSave(sscopy);
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null ) {
                        MyApplication.OutPutPath = s;
                        MyApplication.activity = MyActivity;
                        MyApplication.AdsId = 2;
                        MyApplication.mInterstitialAd.show(MyActivity);
                        MyApplication.isShowAd = 1;
                    } else {
                        GoToSave(sscopy);
                    }
                }
            }
        }, 1000L);
    }

    private void GoToSave(String s) {
        Intent intent = new Intent(activity, ActivityVideoSave.class);
        intent.putExtra("outpath", s);
        ActivityPreview.this.startActivity(intent);
        ActivityPreview.this.finish();
    }

    void setInvi(final ImageView imageView) {
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                imageView.setVisibility(View.GONE);
            }
        }, 400L);
    }

    void setLayout() {
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(ActivityPreview.w * 70 / 1080, ActivityPreview.h * 70 / 1920);
        layoutParams.addRule(15);
        final int n = ActivityPreview.w * 40 / 1080;
        layoutParams.setMargins(n, 0, 0, 0);
        this.ivBack.setLayoutParams(layoutParams);
        final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(ActivityPreview.w * 70 / 1080, ActivityPreview.h * 70 / 1920);
        layoutParams2.addRule(15);
        layoutParams2.addRule(11);
        layoutParams2.setMargins(0, 0, n, 0);
        if (MainActivity.anInt == 1) {
            final double n2 = ActivityPreview.w;
            Double.isNaN(n2);
            final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams((int) (n2 * 0.75), ActivityPreview.h);
            ActivityPreview.lyricTxt1.setLayoutParams(relativeLayout$LayoutParams);
            ActivityPreview.lyricTxt2.setLayoutParams(relativeLayout$LayoutParams);
            this.save_lay.setLayoutParams(new RelativeLayout.LayoutParams(ActivityPreview.w, ActivityPreview.h));
            final int n3 = ActivityPreview.h * 125 / 1920;
            this.addTextLay.setPadding(0, n3, 0, n3);
        } else {
            final double n4 = ActivityPreview.w;
            Double.isNaN(n4);
            final RelativeLayout.LayoutParams relativeLayout$LayoutParams2 = new RelativeLayout.LayoutParams((int) (n4 * 0.75), ActivityPreview.w);
            ActivityPreview.lyricTxt1.setLayoutParams(relativeLayout$LayoutParams2);
            ActivityPreview.lyricTxt2.setLayoutParams(relativeLayout$LayoutParams2);
            this.save_lay.setLayoutParams(new RelativeLayout.LayoutParams(ActivityPreview.w, ActivityPreview.w));
        }
        final RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(ActivityPreview.w * 150 / 1080, ActivityPreview.h * 150 / 1920);
        layoutParams3.addRule(13);
        this.play_pause.setLayoutParams(layoutParams3);
        final RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(ActivityPreview.w * 163 / 1080, ActivityPreview.h * 167 / 1920);
        layoutParams4.addRule(13);
        this.ivSetolor.setLayoutParams(layoutParams4);
        this.ivSetStyle.setLayoutParams(layoutParams4);
        this.ivSetTheme.setLayoutParams(layoutParams4);
        this.ivSetting.setLayoutParams(layoutParams4);
        this.ivSetPos.setLayoutParams(layoutParams4);
        if (MainActivity.anInt == 1) {
            final RelativeLayout.LayoutParams relativeLayout$LayoutParams3 = new RelativeLayout.LayoutParams(ActivityPreview.w, ActivityPreview.h);
            this.ivPreview.setLayoutParams(relativeLayout$LayoutParams3);
            this.relativeLayout.setLayoutParams(relativeLayout$LayoutParams3);
        } else {
            final RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(ActivityPreview.w, ActivityPreview.w);
            layoutParams5.addRule(13);
            this.ivPreview.setLayoutParams(layoutParams5);
            this.relativeLayout.setLayoutParams(layoutParams5);
            this.save_lay2.setLayoutParams(layoutParams5);
        }
        final LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, 0);
        layoutParams6.weight = 8.0f;
        this.rel.setLayoutParams(layoutParams6);
        final RelativeLayout.LayoutParams layoutParams7 = new RelativeLayout.LayoutParams(-1, ActivityPreview.h * 130 / 1920);
        layoutParams7.addRule(12);
        this.gravityLay.setLayoutParams(layoutParams7);
        final RelativeLayout.LayoutParams layoutParams8 = new RelativeLayout.LayoutParams(ActivityPreview.w * 185 / 1080, ActivityPreview.h * 115 / 1920);
        layoutParams8.addRule(13);
        this.top_left.setLayoutParams(layoutParams8);
        this.top_right.setLayoutParams(layoutParams8);
        this.ivBottomleft.setLayoutParams(layoutParams8);
        this.ivBottomright.setLayoutParams(layoutParams8);
        this.random.setLayoutParams(layoutParams8);
    }

    void setPlayer() {
        try {
            this.player.reset();
            this.player.setDataSource(ActivitySelectLyrics.strMusicPath);
            this.player.prepare();
            this.player.start();
            this.player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(final MediaPlayer mediaPlayer) {
                    ActivityPreview.this.player.seekTo(0);
                    ActivityPreview.this.play_pause.setImageResource(R.drawable.play2);
                    resetPlayer();
                    ActivityPreview.this.build(ActivityPreview.this.photo2.get(7), ActivityPreview.this.imageview22);
                    ActivityPreview.this.imageview22.bringToFront();
                }
            });
            this.pos = 0;
            this.start();
        } catch (Exception ex) {
            ex.toString();
        }
    }

    public void showNotification(final Context context, final String s, final String s2) {
        final PendingIntent activity = PendingIntent.getActivity(context, 0, new Intent(context, ActivityVideoSave.class), 0);
        final NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder setAutoCancel2;
        if (Build.VERSION.SDK_INT >= 26) {
            final NotificationChannel notificationChannel = new NotificationChannel("notification_id", "notification", NotificationManager.IMPORTANCE_HIGH);
            final Notification.Builder setAutoCancel = new Notification.Builder(context, "notification_id").setSmallIcon(R.drawable.play).setChannelId("notification_id").setContentIntent(activity).setContentTitle(s).setContentText(s2).setAutoCancel(true);
            final Notification build = setAutoCancel.build();
            build.flags |= 0x18;
            setAutoCancel2 = setAutoCancel;
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
                setAutoCancel2 = setAutoCancel;
            }
        } else {
            setAutoCancel2 = new Notification.Builder(context).setSmallIcon(R.drawable.play).setPriority(Notification.PRIORITY_HIGH).setContentIntent(activity).setContentTitle(s).setContentText(s2).setAutoCancel(true);
            final Notification build2 = setAutoCancel2.build();
            build2.flags |= 0x18;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setAutoCancel2.setSmallIcon(R.drawable.play);
            setAutoCancel2.setColor(context.getResources().getColor(android.R.color.black));
        } else {
            setAutoCancel2.setSmallIcon(R.drawable.play);
        }
        final Notification build3 = setAutoCancel2.build();
        build3.flags |= 0x18;
        if (notificationManager != null) {
            notificationManager.notify((int) System.currentTimeMillis(), setAutoCancel2.build());
        }
    }

    void start() {
        if (ActivityPreview.THEME == 0) {
            this.start_pos_theme0(this.pos);
        } else if (ActivityPreview.THEME == 1) {
            this.startPosTheme1(this.pos);
            this.save_lay2.setBackgroundColor(Color.parseColor("#fd9627"));
        } else if (ActivityPreview.THEME == 2) {
            this.startPosTheme2(this.pos);
            this.save_lay2.setBackgroundColor(Color.parseColor("#555555"));
        } else if (ActivityPreview.THEME == 3) {
            this.startPosTheme3(this.pos);
            this.save_lay2.setBackgroundColor(Color.parseColor("#555555"));
        } else if (ActivityPreview.THEME == 4) {
            this.startPosTheme4(this.pos);
            this.save_lay2.setBackgroundColor(Color.parseColor("#282828"));
        } else if (ActivityPreview.THEME == 5) {
            this.startPosTheme5(this.pos);
            this.save_lay2.setBackgroundColor(Color.parseColor("#00ffea"));
        } else if (ActivityPreview.THEME == 6) {
            this.startPosTheme6(this.pos);
            this.save_lay2.setBackgroundColor(Color.parseColor("#0039e7"));
        } else if (ActivityPreview.THEME == 7) {
            this.startPosTheme7(this.pos);
            this.save_lay2.setBackgroundColor(Color.parseColor("#fa2732"));
        }
        this.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (ActivityPreview.this.player.isPlaying()) {
                    final ActivityPreview this$0 = ActivityPreview.this;
                    ++this$0.pos;
                    if (ActivityPreview.this.pos < ActivityPreview.this.photo2.size()) {
                        ActivityPreview.this.start();
                        return;
                    }
                    ActivityPreview.this.build(ActivityPreview.this.photo2.get(7), ActivityPreview.this.imageview22);
                    ActivityPreview.this.imageview22.bringToFront();
                    ActivityPreview.this.play_pause.setImageResource(R.drawable.play2);
                }
            }
        }, 3800L);
    }

    void startAgain() {
        this.saveReset();
        ActivityPreview.complete = false;
        ActivityPreview.cancel = false;
        this.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityPreview.this.start_saving();
            }
        }, 1000L);
    }

    void start_pos_theme0(final int current_line2) {
        ActivityPreview.lyricTxt2.setText(this.strings22[current_line2]);
        this.currentLine2 = current_line2;
        this.build(this.photo2.get(current_line2), this.imageview22);
        this.addTextLay1.bringToFront();
        this.addTextLay1.removeAllViews();
        this.line_textts1.clear();
        ActivityPreview.lyricTxt2.post(new Runnable() {
            @Override
            public void run() {
                final Layout layout = ActivityPreview.lyricTxt2.getLayout();
                final String string = ActivityPreview.lyricTxt2.getText().toString();
                final int n = 0;
                int n2 = 0;
                int n3 = 0;
                int i;
                while (true) {
                    i = n;
                    if (n2 >= ActivityPreview.lyricTxt2.getLineCount()) {
                        break;
                    }
                    final int lineEnd = layout.getLineEnd(n2);
                    ActivityPreview.this.line_textts1.add(string.substring(n3, lineEnd));
                    ++n2;
                    n3 = lineEnd;
                }
                while (i < ActivityPreview.this.line_textts1.size()) {
                    ActivityPreview.this.theme0(ActivityPreview.this.line_textts1.get(i));
                    ++i;
                }
            }
        });
    }

    void startPosTheme1(final int current_line2) {
        ActivityPreview.lyricTxt2.setText(this.strings22[current_line2]);
        this.currentLine2 = current_line2;
        this.cancelAnim2();
        if (current_line2 == 0) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.animZoomRight2);
            this.imageview22.startAnimation(this.animMoveRight2);
            this.setInvi(this.imageview22);
        } else if (current_line2 == 1) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.animZoomUp2);
            this.imageview11.startAnimation(this.animMoveUp2);
            this.imageview22.bringToFront();
            this.setInvi(this.imageview11);
        } else if (current_line2 == 2) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.animZoomLeft2);
            this.imageview22.startAnimation(this.animMoveLeft2);
            this.imageview11.bringToFront();
            this.setInvi(this.imageview2);
        } else if (current_line2 == 3) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.animZoomBot2);
            this.imageview11.startAnimation(this.animMoveBot2);
            this.imageview22.bringToFront();
            this.setInvi(this.imageview11);
        } else if (current_line2 == 4) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.animZoomRight2);
            this.imageview22.startAnimation(this.animMoveRight2);
            this.imageview11.bringToFront();
            this.setInvi(this.imageview22);
        } else if (current_line2 == 5) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.animZoomUp2);
            this.imageview11.startAnimation(this.animMoveUp2);
            this.imageview22.bringToFront();
            this.setInvi(this.imageview11);
        } else if (current_line2 == 6) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.animZoomLeft2);
            this.imageview22.startAnimation(this.animMoveLeft2);
            this.imageview11.bringToFront();
            this.setInvi(this.imageview22);
        } else if (current_line2 == 7) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.animZoomBot2);
            this.imageview11.startAnimation(this.animMoveBot2);
            this.imageview22.bringToFront();
            this.setInvi(this.imageview11);
        }
        this.animZoomRight2.setFillAfter(true);
        this.animZoomUp2.setFillAfter(true);
        this.animZoomBot2.setFillAfter(true);
        this.animZoomLeft2.setFillAfter(true);
        this.addTextLay1.bringToFront();
        this.addTextLay1.removeAllViews();
        this.line_textts1.clear();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                final Layout layout = ActivityPreview.lyricTxt2.getLayout();
                final String string = ActivityPreview.lyricTxt2.getText().toString();
                final int n = 0;
                int n2 = 0;
                int n3 = 0;
                int i;
                while (true) {
                    i = n;
                    if (n2 >= ActivityPreview.lyricTxt2.getLineCount()) {
                        break;
                    }
                    final int lineEnd = layout.getLineEnd(n2);
                    ActivityPreview.this.line_textts1.add(string.substring(n3, lineEnd));
                    ++n2;
                    n3 = lineEnd;
                }
                while (i < ActivityPreview.this.line_textts1.size()) {
                    ActivityPreview.this.theme1(ActivityPreview.this.line_textts1.get(i), i);
                    ++i;
                }
            }
        }, 400L);
    }

    void startPosTheme2(final int current_line2) {
        ActivityPreview.lyricTxt2.setText(this.strings22[current_line2]);
        this.currentLine2 = current_line2;
        this.cancelAnim2();
        if (current_line2 == 0) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.animZoomBot2);
            this.imageview22.startAnimation(this.animMoveBot2);
            this.setInvi(this.imageview22);
        } else if (current_line2 == 1) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.animZoomBot2);
            this.imageview11.startAnimation(this.animMoveBot2);
            this.imageview22.bringToFront();
            this.setInvi(this.imageview11);
        } else if (current_line2 == 2) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.animZoomUp2);
            this.imageview22.startAnimation(this.animMoveUp2);
            this.imageview11.bringToFront();
            this.setInvi(this.imageview2);
        } else if (current_line2 == 3) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.animZoomUp2);
            this.imageview11.startAnimation(this.animMoveUp2);
            this.imageview22.bringToFront();
            this.setInvi(this.imageview11);
        } else if (current_line2 == 4) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.animZoomBot2);
            this.imageview22.startAnimation(this.animMoveBot2);
            this.imageview11.bringToFront();
            this.setInvi(this.imageview22);
        } else if (current_line2 == 5) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.animZoomBot2);
            this.imageview11.startAnimation(this.animMoveBot2);
            this.imageview22.bringToFront();
            this.setInvi(this.imageview11);
        } else if (current_line2 == 6) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.animZoomUp2);
            this.imageview22.startAnimation(this.animMoveUp2);
            this.imageview11.bringToFront();
            this.setInvi(this.imageview22);
        } else if (current_line2 == 7) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.animZoomUp2);
            this.imageview11.startAnimation(this.animMoveUp2);
            this.imageview22.bringToFront();
            this.setInvi(this.imageview11);
        }
        this.animZoomRight2.setFillAfter(true);
        this.animZoomUp2.setFillAfter(true);
        this.animZoomBot2.setFillAfter(true);
        this.animZoomLeft2.setFillAfter(true);
        this.addTextLay1.bringToFront();
        this.addTextLay1.removeAllViews();
        this.line_textts1.clear();
        if (!ActivityPreview.randomB) {
            this.currentLine2 = this.cPos;
        }
        if (this.currentLine2 != 0 && this.currentLine2 != 4) {
            if (this.currentLine2 != 1 && this.currentLine2 != 5) {
                if (this.currentLine2 != 2 && this.currentLine2 != 6) {
                    if (this.currentLine2 == 3 || this.currentLine2 == 7) {
                        this.addTextLay1.setGravity(83);
                    }
                } else {
                    this.addTextLay1.setGravity(85);
                }
            } else {
                this.addTextLay1.setGravity(53);
            }
        } else {
            this.addTextLay1.setGravity(51);
        }
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityPreview.this.theme2(ActivityPreview.lyricTxt2.getText().toString());
            }
        }, 400L);
    }

    void startPosTheme3(final int current_line2) {
        ActivityPreview.lyricTxt2.setText(this.strings22[current_line2]);
        this.currentLine2 = current_line2;
        this.cancelAnim2();
        if (current_line2 == 0) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.crossComeImage42);
            this.imageview11.bringToFront();
        } else if (current_line2 == 1) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.crossComeImage32);
            this.imageview22.bringToFront();
        } else if (current_line2 == 2) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.crossComeImage12);
            this.imageview11.bringToFront();
        } else if (current_line2 == 3) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.crossComeImage22);
            this.imageview22.bringToFront();
        } else if (current_line2 == 4) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.crossComeImage42);
            this.imageview11.bringToFront();
        } else if (current_line2 == 5) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.crossComeImage32);
            this.imageview22.bringToFront();
        } else if (current_line2 == 6) {
            this.build(this.photo2.get(current_line2), this.imageview11);
            this.imageview11.startAnimation(this.crossComeImage12);
            this.imageview11.bringToFront();
        } else if (current_line2 == 7) {
            this.build(this.photo2.get(current_line2), this.imageview22);
            this.imageview22.startAnimation(this.crossComeImage22);
            this.imageview22.bringToFront();
        }
        this.crossComeImage12.setFillAfter(true);
        this.crossComeImage22.setFillAfter(true);
        this.crossComeImage32.setFillAfter(true);
        this.crossComeImage42.setFillAfter(true);
        this.addTextLay1.bringToFront();
        this.addTextLay1.removeAllViews();
        this.line_textts1.clear();
        this.theme3(ActivityPreview.lyricTxt2.getText().toString());
    }

    void startPosTheme4(final int current_line2) {
        ActivityPreview.lyricTxt2.setText(this.strings22[current_line2]);
        this.currentLine2 = current_line2;
        this.cancelAnim2();
        this.gone(this.imageview11);
        this.build(this.photo2.get(current_line2), this.imageview22);
        this.imageview22.startAnimation(this.centerZoomImage2);
        this.centerZoomImage2.setFillAfter(true);
        this.addTextLay1.bringToFront();
        this.addTextLay1.removeAllViews();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityPreview.this.theme4(ActivityPreview.lyricTxt2.getText().toString());
            }
        }, 400L);
    }

    void startPosTheme5(final int current_line2) {
        ActivityPreview.lyricTxt2.setText(this.strings22[current_line2]);
        this.currentLine2 = current_line2;
        this.cancelAnim2();
        this.gone(this.imageview11);
        this.build(this.photo2.get(current_line2), this.imageview22);
        this.imageview22.startAnimation(this.centerZoomImage2);
        this.centerZoomImage2.setFillAfter(true);
        this.addTextLay1.bringToFront();
        this.addTextLay1.removeAllViews();
        this.line_textts1.clear();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                final Layout layout = ActivityPreview.lyricTxt2.getLayout();
                final String string = ActivityPreview.lyricTxt2.getText().toString();
                final int n = 0;
                int n2 = 0;
                int n3 = 0;
                int i;
                while (true) {
                    i = n;
                    if (n2 >= ActivityPreview.lyricTxt2.getLineCount()) {
                        break;
                    }
                    final int lineEnd = layout.getLineEnd(n2);
                    ActivityPreview.this.line_textts1.add(string.substring(n3, lineEnd));
                    ++n2;
                    n3 = lineEnd;
                }
                while (i < ActivityPreview.this.line_textts1.size()) {
                    ActivityPreview.this.theme5(ActivityPreview.this.line_textts1.get(i), i);
                    ++i;
                }
            }
        }, 400L);
    }

    void startPosTheme6(final int current_line2) {
        ActivityPreview.lyricTxt2.setText(this.strings22[current_line2]);
        this.currentLine2 = current_line2;
        this.cancelAnim2();
        this.gone(this.imageview11);
        this.build(this.photo2.get(current_line2), this.imageview22);
        this.imageview22.startAnimation(this.imageZoomOut2);
        this.imageZoomOut2.setFillAfter(true);
        this.addTextLay1.bringToFront();
        this.addTextLay1.removeAllViews();
        this.line_textts1.clear();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityPreview.this.theme6(ActivityPreview.lyricTxt2.getText().toString());
            }
        }, 400L);
    }

    void startPosTheme7(final int current_line2) {
        ActivityPreview.lyricTxt2.setText(this.strings22[current_line2]);
        this.currentLine2 = current_line2;
        this.cancelAnim2();
        this.gone(this.imageview11);
        this.build(this.photo2.get(current_line2), this.imageview22);
        this.imageview22.startAnimation(this.animSlide_image_zoom2);
        this.animSlide_image_zoom2.setFillAfter(true);
        this.addTextLay1.bringToFront();
        this.addTextLay1.removeAllViews();
        this.line_textts1.clear();
        this.handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityPreview.this.theme7(ActivityPreview.lyricTxt2.getText().toString());
            }
        }, 400L);
    }

    void start_saving() {
        this.i = 0;
        if (ActivityPreview.THEME == 0) {
            this.save_start_pos_theme0(0);
            return;
        }
        if (ActivityPreview.THEME == 1) {
            this.save_start_pos_theme1(0);
            this.save_lay.setBackgroundColor(Color.parseColor("#fd9627"));
            return;
        }
        if (ActivityPreview.THEME == 2) {
            this.save_start_pos_theme2(0);
            this.save_lay.setBackgroundColor(Color.parseColor("#555555"));
            return;
        }
        if (ActivityPreview.THEME == 3) {
            this.save_start_pos_theme3(0);
            this.save_lay.setBackgroundColor(Color.parseColor("#555555"));
            return;
        }
        if (ActivityPreview.THEME == 4) {
            this.save_start_pos_theme4(0);
            this.save_lay.setBackgroundColor(Color.parseColor("#282828"));
            return;
        }
        if (ActivityPreview.THEME == 5) {
            this.save_start_pos_theme5(0);
            this.save_lay.setBackgroundColor(Color.parseColor("#00ffea"));
            return;
        }
        if (ActivityPreview.THEME == 6) {
            this.save_start_pos_theme6(0);
            this.save_lay.setBackgroundColor(Color.parseColor("#0039e7"));
            return;
        }
        if (ActivityPreview.THEME == 7) {
            this.save_start_pos_theme7(0);
            this.save_lay.setBackgroundColor(Color.parseColor("#fa2732"));
        }
    }

    void dialogTextColors() {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.pop_color);
        dialog.findViewById(R.id.mainLay).setLayoutParams(new RelativeLayout.LayoutParams((w * 900) / 1080, (h * 1310) / 1920));
        TextView textView = dialog.findViewById(R.id.title);
        ImageView imageView = dialog.findViewById(R.id.cancel);
        ImageView imageView2 = dialog.findViewById(R.id.ok);
        ImageView imageView3 = dialog.findViewById(R.id.close);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((w * 310) / 1080, (h * 100) / 1920);
        layoutParams.addRule(13);
        imageView.setLayoutParams(layoutParams);
        imageView2.setLayoutParams(layoutParams);
        textView.setTypeface(this.typeface);
        int i = (w * 40) / 1080;
        layoutParams = new RelativeLayout.LayoutParams((w * 65) / 1080, (h * 65) / 1920);
        layoutParams.addRule(15);
        layoutParams.addRule(11);
        layoutParams.setMargins(0, 0, i, 0);
        imageView3.setLayoutParams(layoutParams);
        this.colorPicker = dialog.findViewById(R.id.picker);
        this.svBar = dialog.findViewById(R.id.svbar);
        this.opacityBar = dialog.findViewById(R.id.opacitybar);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams((w * 650) / 1080, (h * 650) / 1920);
        layoutParams2.gravity = 17;
        this.colorPicker.setLayoutParams(layoutParams2);
        this.colorPicker.addSVBar(this.svBar);
        this.colorPicker.addOpacityBar(this.opacityBar);
        this.colorPicker.setOldCenterColor(this.text_color);
        this.colorPicker.setColor(this.text_color);
        this.svBar.setColor(this.text_color);
        this.opacityBar.setColor(this.text_color);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        imageView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivityPreview.this.text_color = ActivityPreview.this.colorPicker.getColor();
                ActivityPreview.lyricTxt1.setTextColor(ActivityPreview.this.text_color);
                ActivityPreview.lyricTxt2.setTextColor(ActivityPreview.this.text_color);
                ActivityPreview.this.startAgain();
                dialog.dismiss();
            }
        });
        imageView3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    void visible(final View view) {
        view.setVisibility(View.VISIBLE);
    }

    class CopyBitmap extends AsyncTask<String, String, String> {
        protected String doInBackground(final String... array) {
            ActivityPreview.images_bit.clear();
            for (int i = 0; i < 34; ++i) {
                try {
                    final Bitmap bitmapFromView = ActivityPreview.this.getBitmapFromView(ActivityPreview.this.save_lay);
                    if (bitmapFromView != null) {
                        ActivityPreview.images_bit.add(bitmapFromView);
                    }
                } catch (Exception ex) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Fail ");
                    sb.append(ex.toString());
                    Log.e("Bitmap :", sb.toString());
                }
            }
            return null;
        }

        protected void onPostExecute(final String s) {
            (ActivityPreview.this.saveBitmap = new SaveBitmap()).execute();
            super.onPostExecute(s);
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }
    }

    class SaveBitmap extends AsyncTask<String, String, String> {
        protected String doInBackground(final String... array) {
            if (ActivityPreview.images_bit.size() != 0) {
                for (int i = 0; i < ActivityPreview.images_bit.size(); ++i) {
                    if (!this.isCancelled()) {
                        final Bitmap bitmap = ActivityPreview.images_bit.get(i);
                        final StringBuilder sb = new StringBuilder();
                        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
                        sb.append("/");
                        sb.append(ActivityPreview.this.getResources().getString(R.string.app_name));
                        final String string = sb.toString();
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append("anim");
                        sb2.append(ActivityPreview.this.i);
                        sb2.append(".jpg");
                        final String string2 = sb2.toString();
                        final StringBuilder sb3 = new StringBuilder();
                        sb3.append(string);
                        sb3.append(File.separator);
                        sb3.append(ActivityPreview.this.getString(R.string.temp_folder));
                        sb3.append("/temp");
                        final File file = new File(sb3.toString());
                        file.mkdirs();
                        final File file2 = new File(file, string2);
                        if (file2.exists()) {
                            file2.delete();
                        }
                        try {
                            final FileOutputStream fileOutputStream = new FileOutputStream(file2);
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            bitmap.recycle();
                            final ActivityPreview this$0 = ActivityPreview.this;
                            ++this$0.i;
                        } catch (Exception ex) {
                            final StringBuilder sb4 = new StringBuilder();
                            sb4.append("Failed");
                            sb4.append(ex.toString());
                            Log.e("Save : ", sb4.toString());
                        }
                    }
                }
            } else {
                ActivityPreview.this.start_saving();
            }
            return null;
        }

        protected void onPostExecute(final String s) {
            if (ActivityPreview.THEME == 1) {
                if (ActivityPreview.this.i == 272) {
                    ActivityPreview.complete = true;
                    if (ActivityPreview.done_press) {
                        new VideoCreate(ActivityPreview.this, "9").execute();
                    }
                } else if (ActivityPreview.this.i == 238) {
                    ActivityPreview.this.save_start_pos_theme1(7);
                } else if (ActivityPreview.this.i == 204) {
                    ActivityPreview.this.save_start_pos_theme1(6);
                } else if (ActivityPreview.this.i == 170) {
                    ActivityPreview.this.save_start_pos_theme1(5);
                } else if (ActivityPreview.this.i == 136) {
                    ActivityPreview.this.save_start_pos_theme1(4);
                } else if (ActivityPreview.this.i == 102) {
                    ActivityPreview.this.save_start_pos_theme1(3);
                } else if (ActivityPreview.this.i == 68) {
                    ActivityPreview.this.save_start_pos_theme1(2);
                } else if (ActivityPreview.this.i == 34) {
                    ActivityPreview.this.save_start_pos_theme1(1);
                }
            } else if (ActivityPreview.THEME == 2) {
                if (ActivityPreview.this.i == 272) {
                    ActivityPreview.complete = true;
                    if (ActivityPreview.done_press) {
                        new VideoCreate(ActivityPreview.this, "9").execute();
                    }
                } else if (ActivityPreview.this.i == 238) {
                    ActivityPreview.this.save_start_pos_theme2(7);
                } else if (ActivityPreview.this.i == 204) {
                    ActivityPreview.this.save_start_pos_theme2(6);
                } else if (ActivityPreview.this.i == 170) {
                    ActivityPreview.this.save_start_pos_theme2(5);
                } else if (ActivityPreview.this.i == 136) {
                    ActivityPreview.this.save_start_pos_theme2(4);
                } else if (ActivityPreview.this.i == 102) {
                    ActivityPreview.this.save_start_pos_theme2(3);
                } else if (ActivityPreview.this.i == 68) {
                    ActivityPreview.this.save_start_pos_theme2(2);
                } else if (ActivityPreview.this.i == 34) {
                    ActivityPreview.this.save_start_pos_theme2(1);
                }
            } else if (ActivityPreview.THEME == 3) {
                if (ActivityPreview.this.i == 272) {
                    ActivityPreview.complete = true;
                    if (ActivityPreview.done_press) {
                        new VideoCreate(ActivityPreview.this, "9").execute();
                    }
                } else if (ActivityPreview.this.i == 238) {
                    ActivityPreview.this.save_start_pos_theme3(7);
                } else if (ActivityPreview.this.i == 204) {
                    ActivityPreview.this.save_start_pos_theme3(6);
                } else if (ActivityPreview.this.i == 170) {
                    ActivityPreview.this.save_start_pos_theme3(5);
                } else if (ActivityPreview.this.i == 136) {
                    ActivityPreview.this.save_start_pos_theme3(4);
                } else if (ActivityPreview.this.i == 102) {
                    ActivityPreview.this.save_start_pos_theme3(3);
                } else if (ActivityPreview.this.i == 68) {
                    ActivityPreview.this.save_start_pos_theme3(2);
                } else if (ActivityPreview.this.i == 34) {
                    ActivityPreview.this.save_start_pos_theme3(1);
                }
            } else if (ActivityPreview.THEME == 4) {
                if (ActivityPreview.this.i == 272) {
                    ActivityPreview.complete = true;
                    if (ActivityPreview.done_press) {
                        new VideoCreate(ActivityPreview.this, "9").execute();
                    }
                } else if (ActivityPreview.this.i == 238) {
                    ActivityPreview.this.save_start_pos_theme4(7);
                } else if (ActivityPreview.this.i == 204) {
                    ActivityPreview.this.save_start_pos_theme4(6);
                } else if (ActivityPreview.this.i == 170) {
                    ActivityPreview.this.save_start_pos_theme4(5);
                } else if (ActivityPreview.this.i == 136) {
                    ActivityPreview.this.save_start_pos_theme4(4);
                } else if (ActivityPreview.this.i == 102) {
                    ActivityPreview.this.save_start_pos_theme4(3);
                } else if (ActivityPreview.this.i == 68) {
                    ActivityPreview.this.save_start_pos_theme4(2);
                } else if (ActivityPreview.this.i == 34) {
                    ActivityPreview.this.save_start_pos_theme4(1);
                }
            } else if (ActivityPreview.THEME == 5) {
                if (ActivityPreview.this.i == 272) {
                    ActivityPreview.complete = true;
                    if (ActivityPreview.done_press) {
                        new VideoCreate(ActivityPreview.this, "9").execute();
                    }
                } else if (ActivityPreview.this.i == 238) {
                    ActivityPreview.this.save_start_pos_theme5(7);
                } else if (ActivityPreview.this.i == 204) {
                    ActivityPreview.this.save_start_pos_theme5(6);
                } else if (ActivityPreview.this.i == 170) {
                    ActivityPreview.this.save_start_pos_theme5(5);
                } else if (ActivityPreview.this.i == 136) {
                    ActivityPreview.this.save_start_pos_theme5(4);
                } else if (ActivityPreview.this.i == 102) {
                    ActivityPreview.this.save_start_pos_theme5(3);
                } else if (ActivityPreview.this.i == 68) {
                    ActivityPreview.this.save_start_pos_theme5(2);
                } else if (ActivityPreview.this.i == 34) {
                    ActivityPreview.this.save_start_pos_theme5(1);
                }
            } else if (ActivityPreview.THEME == 6) {
                if (ActivityPreview.this.i == 272) {
                    ActivityPreview.complete = true;
                    if (ActivityPreview.done_press) {
                        new VideoCreate(ActivityPreview.this, "9").execute();
                    }
                } else if (ActivityPreview.this.i == 238) {
                    ActivityPreview.this.save_start_pos_theme6(7);
                } else if (ActivityPreview.this.i == 204) {
                    ActivityPreview.this.save_start_pos_theme6(6);
                } else if (ActivityPreview.this.i == 170) {
                    ActivityPreview.this.save_start_pos_theme6(5);
                } else if (ActivityPreview.this.i == 136) {
                    ActivityPreview.this.save_start_pos_theme6(4);
                } else if (ActivityPreview.this.i == 102) {
                    ActivityPreview.this.save_start_pos_theme6(3);
                } else if (ActivityPreview.this.i == 68) {
                    ActivityPreview.this.save_start_pos_theme6(2);
                } else if (ActivityPreview.this.i == 34) {
                    ActivityPreview.this.save_start_pos_theme6(1);
                }
            } else if (ActivityPreview.THEME == 7) {
                if (ActivityPreview.this.i == 272) {
                    ActivityPreview.complete = true;
                    if (ActivityPreview.done_press) {
                        new VideoCreate(ActivityPreview.this, "9").execute();
                    }
                } else if (ActivityPreview.this.i == 238) {
                    ActivityPreview.this.save_start_pos_theme7(7);
                } else if (ActivityPreview.this.i == 204) {
                    ActivityPreview.this.save_start_pos_theme7(6);
                } else if (ActivityPreview.this.i == 170) {
                    ActivityPreview.this.save_start_pos_theme7(5);
                } else if (ActivityPreview.this.i == 136) {
                    ActivityPreview.this.save_start_pos_theme7(4);
                } else if (ActivityPreview.this.i == 102) {
                    ActivityPreview.this.save_start_pos_theme7(3);
                } else if (ActivityPreview.this.i == 68) {
                    ActivityPreview.this.save_start_pos_theme7(2);
                } else if (ActivityPreview.this.i == 34) {
                    ActivityPreview.this.save_start_pos_theme7(1);
                }
            }
            super.onPostExecute(s);
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }
    }

    class SaveBitmap0 extends AsyncTask<String, String, String> {
        Bitmap bit;

        SaveBitmap0(final Bitmap bit) {
            this.bit = bit;
        }

        protected String doInBackground(final String... array) {
            if (!this.isCancelled()) {
                final Bitmap bit = this.bit;
                final StringBuilder sb = new StringBuilder();
                sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
                sb.append("/");
                sb.append(ActivityPreview.this.getResources().getString(R.string.app_name));
                final String string = sb.toString();
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("anim");
                sb2.append(ActivityPreview.this.i);
                sb2.append(".jpg");
                final String string2 = sb2.toString();
                final StringBuilder sb3 = new StringBuilder();
                sb3.append(string);
                sb3.append(File.separator);
                sb3.append(ActivityPreview.this.getString(R.string.temp_folder));
                sb3.append("/temp");
                final File file = new File(sb3.toString());
                file.mkdirs();
                final File file2 = new File(file, string2);
                if (file2.exists()) {
                    file2.delete();
                }
                try {
                    final FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    bit.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    bit.recycle();
                    final ActivityPreview this$0 = ActivityPreview.this;
                    ++this$0.i;
                } catch (Exception ex) {
                    final StringBuilder sb4 = new StringBuilder();
                    sb4.append("Failed");
                    sb4.append(ex.toString());
                    Log.e("Save : ", sb4.toString());
                }
            }
            return null;
        }

        protected void onPostExecute(final String s) {
            if (ActivityPreview.THEME == 0) {
                if (ActivityPreview.this.i == 8) {
                    ActivityPreview.complete = true;
                    if (ActivityPreview.done_press) {
                        new VideoCreate(ActivityPreview.this, "0.26").execute();
                    }
                } else if (ActivityPreview.this.i == 7) {
                    ActivityPreview.this.save_start_pos_theme0(7);
                } else if (ActivityPreview.this.i == 6) {
                    ActivityPreview.this.save_start_pos_theme0(6);
                } else if (ActivityPreview.this.i == 5) {
                    ActivityPreview.this.save_start_pos_theme0(5);
                } else if (ActivityPreview.this.i == 4) {
                    ActivityPreview.this.save_start_pos_theme0(4);
                } else if (ActivityPreview.this.i == 3) {
                    ActivityPreview.this.save_start_pos_theme0(3);
                } else if (ActivityPreview.this.i == 2) {
                    ActivityPreview.this.save_start_pos_theme0(2);
                } else if (ActivityPreview.this.i == 1) {
                    ActivityPreview.this.save_start_pos_theme0(1);
                }
            }
            super.onPostExecute(s);
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }
    }
}
