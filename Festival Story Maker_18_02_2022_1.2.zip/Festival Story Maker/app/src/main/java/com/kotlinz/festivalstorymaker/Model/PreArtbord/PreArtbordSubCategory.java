package com.kotlinz.festivalstorymaker.Model.PreArtbord;

import com.google.gson.annotations.SerializedName;

public class PreArtbordSubCategory {
    @SerializedName("response")
    private PreArtbordResponse mResponse;
    @SerializedName("success")
    private String mSuccess;

    public PreArtbordResponse getResponse() {
        return mResponse;
    }

    public void setResponse(PreArtbordResponse response) {
        mResponse = response;
    }

    public String getSuccess() {
        return mSuccess;
    }

    public void setSuccess(String success) {
        mSuccess = success;
    }
}
