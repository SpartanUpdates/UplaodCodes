package com.xyz.vehiclemanager.bike.BikeVariantDetails.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.activity.BikeVariantTabActivity;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.adapter.SpecificationsAdapter;
import com.xyz.vehiclemanager.model.Item;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.model.BikeSpecification;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.model.BikeVariantRoot;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BikeSpecificationsFragment extends Fragment
{
    private View view;
    private RecyclerView rv_specification;
    private ArrayList<Item> engineAndTransmition = new ArrayList<>();
    private ArrayList<Item> breakWheelAndSuspention = new ArrayList<>();
    private ArrayList<Item> dimensionsAndChassis = new ArrayList<>();
    private ArrayList<Item> fuelEfficiencyAndPerfomance = new ArrayList<>();
    private SpecificationsAdapter specificationsAdapter;
    private RtoDetailsInterface rtoDetailsInterface;
    private Item item;

    public BikeSpecificationsFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_specifications, container, false);
        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        rv_specification = view.findViewById(R.id.rv_specification);
        getSpecificationsVariantData();
        return view;
    }

    private void getSpecificationsVariantData()
    {
        Call<BikeVariantRoot> call = rtoDetailsInterface.getBikeVariantDetails(BikeVariantTabActivity.varientId);
        call.enqueue(new Callback<BikeVariantRoot>() {
            @Override
            public void onResponse(Call<BikeVariantRoot> call, Response<BikeVariantRoot> response) {
                if (response.isSuccessful())
                {
                    if (BikeVariantTabActivity.dialog != null && BikeVariantTabActivity.dialog.isShowing())
                    {
                        BikeVariantTabActivity.dialog.dismiss();
                    }
                    ArrayList<BikeSpecification> variantlist = response.body().getDetails().getSpecifications();
                    for (int i = 0; i < variantlist.size(); i++)
                    {
                        String key = variantlist.get(i).getKey();
                        ArrayList<Item> itemlist = response.body().getDetails().getSpecifications().get(i).getItems();
                        if(key.equals("Engine & Transmission"))
                        {
                            for (int j = 0; j < itemlist.size(); j++)
                            {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                engineAndTransmition.add(item);
                            }
                        }
                        if(key.equals("Brakes, Wheels & Suspension"))
                        {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                breakWheelAndSuspention.add(item);
                            }
                        }
                        if(key.equals("Dimensions & Chassis"))
                        {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                dimensionsAndChassis.add(item);
                            }
                        }
                        if(key.equals("Fuel Efficiency & Performance"))
                        {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                fuelEfficiencyAndPerfomance.add(item);
                            }
                        }
                    }
                    specificationsAdapter = new SpecificationsAdapter(getActivity(), variantlist, engineAndTransmition, breakWheelAndSuspention, dimensionsAndChassis, fuelEfficiencyAndPerfomance);
                    rv_specification.setAdapter(specificationsAdapter);
                    rv_specification.setLayoutManager(new LinearLayoutManager(getActivity()));
                }
            }

            @Override
            public void onFailure(Call<BikeVariantRoot> call, Throwable t) {
                if (BikeVariantTabActivity.dialog != null && BikeVariantTabActivity.dialog.isShowing())
                {
                    BikeVariantTabActivity.dialog.dismiss();
                }
            }
        });
    }
}