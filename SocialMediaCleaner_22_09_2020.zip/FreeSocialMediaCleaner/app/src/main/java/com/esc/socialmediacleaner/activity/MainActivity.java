package com.esc.socialmediacleaner.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;

import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.loader.StaggeredGridView;

public class MainActivity extends Activity {
    private String[] urls = new String[]{"https://static.toiimg.com/thumb/72975551.cms?width=680&height=512&imgsize=881753", "https://image.shutterstock.com/image-photo/mountains-during-sunset-beautiful-natural-600w-407021107.jpg", "https://image.shutterstock.com/image-photo/creative-layout-made-flowers-leaves-600w-547784302.jpg", "https://static.toiimg.com/thumb/72975551.cms?width=680&height=512&imgsize=881753", "https://image.shutterstock.com/image-photo/mountains-during-sunset-beautiful-natural-600w-407021107.jpg", "https://image.shutterstock.com/image-photo/creative-layout-made-flowers-leaves-600w-547784302.jpg"};

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        StaggeredGridView staggeredGridView = (StaggeredGridView) findViewById(R.id.staggeredGridView1);
        int dimensionPixelSize = getResources().getDimensionPixelSize(R.dimen.margin);
        staggeredGridView.setItemMargin(dimensionPixelSize);
        staggeredGridView.setPadding(dimensionPixelSize, 0, dimensionPixelSize, 0);
    }
}
