package com.kotlinz.videoeditor.videoreverse;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.provider.MediaStore.Images.Media;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.TrimVideoPrivewActivity;
import com.kotlinz.videoeditor.view.RangePlaySeekBar;
import com.kotlinz.videoeditor.view.RangeSeekBar;
import com.kotlinz.videoeditor.Utils.UtilCommand;
import com.kotlinz.videoeditor.editvideo.activity.EditActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.util.concurrent.TimeUnit;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.kotlinz.videoeditor.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

@SuppressLint({"WrongConstant", "ResourceType"})
public class VideoReverseActivity extends AppCompatActivity {

    Activity activity = VideoReverseActivity.this;
    static final boolean A = true;
    public static VideoReverseActivity context;
    public static String videoPath;
    private final StateObserver B = new StateObserver();

    public VideoView videoView;
    public boolean CompleteNotificationCreated = false;

    public String D;
    private String E;
    public int MP_DURATION;
    boolean a = A;
    ViewGroup b;
    RangeSeekBar<Integer> c;
    RangePlaySeekBar<Integer> d;
    WakeLock e;
    int f = 0;
    int g = 4;
    int h;
    int i;
    public boolean isInFront = A;
    int j;
    int k;
    int l;
    int m = 0;
    int n = 1;
    RelativeLayout o;
    RelativeLayout reverse;
    public ProgressDialog prgDialog;
    RelativeLayout q;
    RelativeLayout r;
    TextView s;
    TextView t;
    TextView u;

    public ImageView videoPlayBtn;

    ImageView ivBack, ivDone;

    String VideoEditTime;
    private NativeAd nativeAd;

    @SuppressLint({"HandlerLeak"})
    public class StateObserver extends Handler {
        private boolean b = false;
        private final Runnable c = new Runnable() {
            public void run() {
                StateObserver.this.a();
            }
        };

        public StateObserver() {

        }


        public void a() {
            if (!this.b) {
                this.b = VideoReverseActivity.A;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            this.b = false;
            d.setSelectedMaxValue(Integer.valueOf(VideoReverseActivity.this.videoView.getCurrentPosition()));
            if (!videoView.isPlaying() || videoView.getCurrentPosition() >= VideoReverseActivity.this.c.getSelectedMaxValue().intValue()) {
                if (videoView.isPlaying()) {
                    videoView.pause();
                    videoPlayBtn.setBackgroundResource(R.drawable.ic_play_upress);
                    videoView.seekTo(VideoReverseActivity.this.c.getSelectedMinValue().intValue());
                    d.setSelectedMinValue(VideoReverseActivity.this.c.getSelectedMinValue());
                    d.setVisibility(4);
                }
                if (!videoView.isPlaying()) {
                    videoPlayBtn.setBackgroundResource(R.drawable.ic_play_upress);
                    d.setVisibility(4);
                    return;
                }
                return;
            }
            d.setVisibility(0);
            postDelayed(this.c, 50);
        }
    }

    public void intentToPreviewActivity() {
    }


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.videoreverseactivity);
        PutAnalyticsEvent();
        LoadNativeAds();
        this.a = A;
        FindId();
        context = this;
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoReverseActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(NativeAd nativeAd) {
                boolean isDestroyed = false;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    isDestroyed = isDestroyed();
                }
                if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                    nativeAd.destroy();
                    return;
                }
                if (VideoReverseActivity.this.nativeAd != null) {
                    VideoReverseActivity.this.nativeAd.destroy();
                }
                VideoReverseActivity.this.nativeAd = nativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(nativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void c() {
        Intent intent = new Intent(activity, TrimVideoPrivewActivity.class);
        intent.putExtra("videofilename", D);
        startActivity(intent);
        finish();
    }

    @SuppressLint("InvalidWakeLockTag")
    public void FindId() {
        this.isInFront = A;
        this.g = e() / 100;
        this.f = 0;
        this.e = ((PowerManager) getSystemService(Context.POWER_SERVICE)).newWakeLock(6, "VideoMerge");
        if (!this.e.isHeld()) {
            this.e.acquire();
        }
        this.E = getIntent().getStringExtra("videouri");
        videoPath = this.E;
        MyApplication.getInstance().VideoFileName = videoPath;
        ivBack = findViewById(R.id.iv_back);
        ivDone = findViewById(R.id.iv_done);
        this.o = findViewById(R.id.imgbtn_Original);
        this.reverse = findViewById(R.id.imgbtn_Reversed);
        this.q = findViewById(R.id.back_Original);
        this.r = findViewById(R.id.back_Reversed);
        this.videoView = findViewById(R.id.addcutsvideoview);
        this.videoPlayBtn = findViewById(R.id.videoplaybtn);
        this.s = findViewById(R.id.left_pointer);
        this.t = findViewById(R.id.mid_pointer);
        this.u = findViewById(R.id.right_pointer);
        if (this.m == 0) {
            a(7);
        }
        runOnUiThread(new Runnable() {
            public void run() {
                prgDialog = ProgressDialog.show(activity, "", "Loading...", VideoReverseActivity.A);
            }
        });
        VideoSeekBar();

        ivBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (videoView.isPlaying()) {
                        videoPlayBtn.setBackgroundResource(R.drawable.ic_play_upress);
                        videoView.pause();
                    }
                } catch (Exception unused) {
                    unused.printStackTrace();
                }
                j = c.getSelectedMinValue().intValue() / 1000;
                l = c.getSelectedMaxValue().intValue() / 1000;
                k = l - j;
                StringBuilder sb = new StringBuilder();
                sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
                sb.append("/");
                sb.append(getResources().getString(R.string.MainFolderName));
                sb.append("/");
                sb.append(getResources().getString(R.string.VideoReverse));
                D = sb.toString();
                File file = new File(D);
                if (!file.exists()) {
                    file.mkdirs();
                }
                StringBuilder sb2 = new StringBuilder();
                sb2.append(file.getAbsolutePath());
                sb2.append("/Rev_");
                sb2.append(System.currentTimeMillis());
                sb2.append(".mp4");
                D = sb2.toString();
                String[] strArr = new String[0];
                if (n == 0) {
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("");
                    sb3.append(j);
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append("");
                    sb4.append(k);
                    strArr = new String[]{"-ss", sb3.toString(), "-y", "-i", videoPath, "-t", sb4.toString(), "-vcodec", "mpeg4", "-b:v", "2097152", "-b:a", "48000", "-ac", "2", "-ar", "22050", "-vf", "reverse", D};
                } else if (n == 1) {
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append("");
                    sb5.append(j);
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append("");
                    sb6.append(k);
                    strArr = new String[]{"-ss", sb5.toString(), "-y", "-i", videoPath, "-t", sb6.toString(), "-vcodec", "mpeg4", "-b:v", "2097152", "-b:a", "48000", "-ac", "2", "-ar", "22050", "-vf", "reverse", "-af", "areverse", "-af", "volume=enable='between(t,0," + VideoEditTime + ")':volume=0':volume=0", D};
                }
                a(strArr, D);
            }

        });

        o.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                n = 0;
                a(6);
            }
        });

        reverse.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                n = 1;
                a(7);
            }
        });
    }

    public void a(int i2) {
        m = i2;
        selectedButton();
    }

    public void selectedButton() {
        if (m == 6) {
            o.setBackground(getResources().getDrawable(R.drawable.ic_original_unpress));
            reverse.setBackground(getResources().getDrawable(R.drawable.ic_reversed_press));
            q.setVisibility(View.VISIBLE);
            r.setVisibility(View.GONE);
        }
        if (m == 7) {
            reverse.setBackground(getResources().getDrawable(R.drawable.ic_reversed_unpress));
            o.setBackground(getResources().getDrawable(R.drawable.ic_original_press));
            q.setVisibility(View.GONE);
            r.setVisibility(View.VISIBLE);
        }
        if (m == 9) {
            q.setVisibility(View.GONE);
            r.setVisibility(View.GONE);
        }
        if (m == 0) {
            q.setVisibility(View.GONE);
            r.setVisibility(View.GONE);
        }
    }


    private void a(String[] strArr, final String str) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();
        String ffmpegCommand = UtilCommand.main(strArr);
        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {

            @Override
            public void apply(final long executionId, final int returnCode) {
                Config.printLastCommandOutput(Log.INFO);
                progressDialog.dismiss();
                if (returnCode == RETURN_CODE_SUCCESS) {
                    progressDialog.dismiss();
                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(VideoReverseActivity.this.D)));
                    VideoReverseActivity.this.sendBroadcast(intent);
                    c();
                    VideoReverseActivity.this.refreshGallery(str);
                } else if (returnCode == RETURN_CODE_CANCEL) {

                    try {
                        new File(str).delete();
                        VideoReverseActivity.this.deleteFromGallery(str);
                        Toast.makeText(VideoReverseActivity.this, "Error Creating Video", Toast.LENGTH_LONG).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                } else {

                    try {
                        new File(str).delete();
                        VideoReverseActivity.this.deleteFromGallery(str);
                        Toast.makeText(VideoReverseActivity.this, "Error Creating Video", Toast.LENGTH_LONG).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }
            }
        });
        getWindow().clearFlags(16);
    }

    public void VideoSeekBar() {
        videoView.setVideoURI(Uri.parse(videoPath));
        videoView.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                if (a) {
                    h = 0;
                    i = mediaPlayer.getDuration();
                    MP_DURATION = mediaPlayer.getDuration();
                    VideoEditTime = String.valueOf(mediaPlayer.getDuration());
                    seekLayout(0, MP_DURATION);
                    videoView.start();
                    videoView.pause();
                    videoView.seekTo(300);
                    return;
                }
                seekLayout(h, i);
                videoView.start();
                videoView.pause();
                videoView.seekTo(h);
            }
        });
        this.videoView.setOnErrorListener(new OnErrorListener() {
            public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                prgDialog.dismiss();
                return false;
            }
        });
        this.videoPlayBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                d();
            }
        });
    }


    public void d() {
        if (this.videoView.isPlaying()) {
            this.videoView.pause();
            this.videoView.seekTo(this.c.getSelectedMinValue().intValue());
            this.videoPlayBtn.setBackgroundResource(R.drawable.ic_play_upress);
            this.d.setVisibility(4);
            return;
        }
        this.videoView.seekTo(this.c.getSelectedMinValue().intValue());
        this.videoView.start();
        this.d.setSelectedMaxValue(Integer.valueOf(this.videoView.getCurrentPosition()));
        this.B.a();
        this.videoPlayBtn.setBackgroundResource(R.drawable.ic_pause_unpresss);
        this.d.setVisibility(0);
    }


    @Override
    public void onStop() {
        super.onStop();
    }


    @Override
    public void onDestroy() {
        this.f = 0;
        if (this.e.isHeld()) {
            this.e.release();
        }
        super.onDestroy();
    }

    public void seekLayout(int i2, int i3) {
        TextView textView = this.s;
        StringBuilder sb = new StringBuilder();
        sb.append(getTimeForTrackFormat(i2));
        sb.append("");
        textView.setText(sb.toString());
        TextView textView2 = this.u;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(getTimeForTrackFormat(i3));
        sb2.append("");
        textView2.setText(sb2.toString());
        TextView textView3 = this.t;
        StringBuilder sb3 = new StringBuilder();
        sb3.append(getTimeForTrackFormat(i3 - i2));
        sb3.append("");
        textView3.setText(sb3.toString());
        if (this.b != null) {
            this.b.removeAllViews();
            this.b = null;
            this.c = null;
            this.d = null;
        }
        this.b = findViewById(R.id.seekLayout);
        this.c = new RangeSeekBar<>(Integer.valueOf(0), Integer.valueOf(this.MP_DURATION), this);
        this.d = new RangePlaySeekBar<>(Integer.valueOf(0), Integer.valueOf(this.MP_DURATION), this);
        this.c.setOnRangeSeekBarChangeListener(new RangeSeekBar.OnRangeSeekBarChangeListener<Integer>() {

            public void onRangeSeekBarValuesChanged(RangeSeekBar<?> rangeSeekBar, Integer num, Integer num2, boolean z) {
                if (videoView.isPlaying()) {
                    videoView.pause();
                    videoPlayBtn.setBackgroundResource(R.drawable.ic_play_upress);
                }
                if (i == num2.intValue()) {
                    if (num2.intValue() - num.intValue() <= 1000) {
                        num = Integer.valueOf(num2.intValue() + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED);
                    }
                    videoView.seekTo(num.intValue());
                } else if (VideoReverseActivity.this.h == num.intValue()) {
                    if (num2.intValue() - num.intValue() <= 1000) {
                        num2 = Integer.valueOf(num.intValue() + 1000);
                    }
                    videoView.seekTo(num.intValue());
                }
                c.setSelectedMaxValue(num2);
                c.setSelectedMinValue(num);
                s.setText(getTimeForTrackFormat(num.intValue()));
                u.setText(getTimeForTrackFormat(num2.intValue()));
                t.setText(getTimeForTrackFormat(num2.intValue() - num.intValue()));
                d.setSelectedMinValue(num);
                d.setSelectedMaxValue(num2);
                h = num.intValue();
                i = num2.intValue();
            }
        });
        b.addView(c);
        b.addView(d);
        c.setSelectedMinValue(Integer.valueOf(i2));
        c.setSelectedMaxValue(Integer.valueOf(i3));
        d.setSelectedMinValue(Integer.valueOf(i2));
        d.setSelectedMaxValue(Integer.valueOf(i3));
        d.setEnabled(false);
        d.setVisibility(View.INVISIBLE);
        prgDialog.dismiss();
    }

    private int e() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int i2 = displayMetrics.heightPixels;
        int i3 = displayMetrics.widthPixels;
        return i3 <= i2 ? i3 : i2;
    }

    public static String getTimeForTrackFormat(int i2) {
        long j2 = i2;
        return String.format("%02d:%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toHours(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(j2))), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }


    @Override
    public void onStart() {
        super.onStart();
        if (CompleteNotificationCreated) {
            intentToPreviewActivity();
            ((NotificationManager) context.getSystemService("notification")).cancelAll();
        }
        CompleteNotificationCreated = false;
    }

    public void onPause() {
        super.onPause();
        a = false;
        try {
            if (videoView.isPlaying()) {
                videoPlayBtn.setBackgroundResource(R.drawable.ic_play_upress);
                videoView.pause();
            }
        } catch (Exception unused) {
            unused.printStackTrace();
        }
        isInFront = false;
        if (d != null && this.d.getVisibility() == 0) {
            d.setVisibility(4);
        }
    }


    public void onRestart() {
        super.onRestart();
    }


    public void g() {
        new AlertDialog.Builder(this).setIcon(17301543).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                VideoReverseActivity.this.finish();
            }
        }).create().show();
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }


    @Override
    public void onResume() {
        super.onResume();
        this.isInFront = A;
        this.E = getIntent().getStringExtra("videouri");
        videoPath = this.E;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        File file = new File(videoPath);
        MediaScannerConnection.scanFile(this, new String[]{file.getPath()},
                null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        // now visible in gallery
                    }
                });
        if (MyApplication.isShowAd == 1) {
            Intent intent = new Intent(activity, EditActivity.class);
            intent.putExtra("videofilename", videoPath);
            startActivity(intent);
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 9;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                Intent intent = new Intent(activity, EditActivity.class);
                intent.putExtra("videofilename", videoPath);
                startActivity(intent);
                finish();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_picker, menu);
        return A;
    }
}
