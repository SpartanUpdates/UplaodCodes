﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BallCollect
{
    public class SoundManger : MonoBehaviour
    {
        public static SoundManger instance;

        public AudioSource checkPoint, levelFinish, levelFail,btnClick,powerUp;

        public AudioSource bgMusic;

        private void Awake()
        {
            if (instance == null)
            {
                instance = this;
                DontDestroyOnLoad(this.gameObject);
            }else
            {
                Destroy(this.gameObject);
            }
            if (DataBase.GetMusicOn() == 0)
            {
                bgMusic.mute = false;
            }
            else
            {
                bgMusic.mute = true;
            }
        }

        public void PlaySound(string name)
        {
            if (!GameController.instance.isSound)
                return;
            switch (name)
            {
                case "CheckPoint":
                    checkPoint.Play();
                    break;
                case "LevelFinish":
                    levelFinish.Play();
                    break;
                case "LevelFail":
                    levelFail.Play();
                    break;
                case "BtnClick":
                    btnClick.Play();
                    break;
                case "PowerUp":
                    powerUp.Play();
                    break;
            }
        }
    }
}