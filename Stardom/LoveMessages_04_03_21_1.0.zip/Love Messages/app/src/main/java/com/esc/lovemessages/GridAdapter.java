package com.esc.lovemessages;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class GridAdapter extends BaseAdapter {
    ImageView categoryimg;
    Context context;
    Integer[] img;

    public Object getItem(int i) {
        return null;
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public GridAdapter(Context context, Integer[] numArr) {
        this.context = context;
        this.img = numArr;
    }

    public int getCount() {
        return this.img.length;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = ((LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.categorygriditem, viewGroup, false);
        }
        this.categoryimg = (ImageView) view.findViewById(R.id.categoryimg);
        this.categoryimg.setImageResource(this.img[i].intValue());
        LayoutParams layoutParams;
        double d;
        if ((this.context.getResources().getConfiguration().screenLayout & 15) == 4) {
            layoutParams = this.categoryimg.getLayoutParams();
            d = (double) MainActivity.height;
            Double.isNaN(d);
            layoutParams.height = (int) (d * 0.3d);
        } else if ((this.context.getResources().getConfiguration().screenLayout & 15) == 3) {
            layoutParams = this.categoryimg.getLayoutParams();
            d = (double) MainActivity.height;
            Double.isNaN(d);
            layoutParams.height = (int) (d * 0.25d);
        } else {
            layoutParams = this.categoryimg.getLayoutParams();
            d = (double) MainActivity.height;
            Double.isNaN(d);
            layoutParams.height = (int) (d * 0.35d);
        }
        return view;
    }
}
