package com.esc.howtomakeschoolsupplies.activity;

import android.media.MediaPlayer;

import com.esc.howtomakeschoolsupplies.fragment.ContentFragment;
import com.like.LikeButton;
import com.like.OnLikeListener;
import kotlin.jvm.internal.Intrinsics;

public class ContentFragmentOnCreateView2 implements OnLikeListener {
    final MediaPlayer $mp;
    final MediaPlayer $mpClick;
    final int $numberArticle;
    final ContentFragment this$0;

    public ContentFragmentOnCreateView2(ContentFragment contentFragment, MediaPlayer mediaPlayer, int i, MediaPlayer mediaPlayer2) {
        this.this$0 = contentFragment;
        this.$mp = mediaPlayer;
        this.$numberArticle = i;
        this.$mpClick = mediaPlayer2;
    }

    public void liked(LikeButton likeButton) {
        Intrinsics.checkParameterIsNotNull(likeButton, "likeButton");
        this.$mp.start();
        new Thread(new ContentFragmentOnCreateViewLiked(this)).start();
    }

    public void unLiked(LikeButton likeButton) {
        Intrinsics.checkParameterIsNotNull(likeButton, "likeButton");
        this.$mpClick.start();
        new Thread(new ContentFragmentOnCreateViewUnLiked(this)).start();
    }
}
