package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.View;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

public class h5 implements View.OnClickListener {
    public final FestivalDetailActivity_New n;

    public h5(FestivalDetailActivity_New festivalDetailActivity_New) {
        this.n = festivalDetailActivity_New;
    }

    public void onClick(View view) {
    }

}
