package com.name.nameart.sticker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.graphics.Bitmap.Config;
import android.view.MotionEvent;
import android.widget.ImageView;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.ViewCompat;

import com.name.nameart.R;

@SuppressLint("AppCompatCustomView")
public class StickerView extends AppCompatImageView {
    private static final float BITMAP_SCALE = 0.7f;
    private static final String TAG = "StickerView";
    private float MAX_SCALE = 1.2f;
    private float MIN_SCALE = 0.5f;
    private Bitmap deleteBitmap;
    private int deleteBitmapHeight;
    private int deleteBitmapWidth;
    private DisplayMetrics dm;
    private Rect rect_delete;
    private Rect rect_flip;
    private Rect rect_resize;
    private Rect rect_top;
    private Bitmap flipVBitmap;
    private int flipVBitmapHeight;
    private int flipVBitmapWidth;
    private double halfdiagonal_length;
    private boolean isHorizonMirror = false;
    private boolean isInEdit = true;
    private boolean Resize = false;
    private boolean Side;
    private boolean pointer_down = false;
    private float lastLength;
    private float lastRotateDegree;
    private float lastX;
    private float lastY;
    private Bitmap mBitmap;
    private int mScreenHeight;
    private int mScreenwidth;
    private Matrix matrix = new Matrix();
    private PointF id = new PointF();
    private float oldDis;
    private OperationListener operationListener;
    private float oringinWidth = 0.0f;
    private Bitmap resizeBitmap;
    private int resizeBitmapHeight;
    private int resizeBitmapWidth;
    private final long stickerId = 0;
    private Bitmap topBitmap;
    private int topBitmapHeight;
    private int topBitmapWidth;
    private Paint local_paint;
    private DisplayMetrics display_matrix;

    public interface OperationListener {
        void onDeleteClick();

        void onEdit(StickerView stickerView);

        void onTop(StickerView stickerView);
    }

    public StickerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public StickerView(Context context) {
        super(context);
        init();
    }

    public StickerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }


    private void init() {
        this.rect_delete = new Rect();
        this.rect_resize = new Rect();
        this.rect_flip = new Rect();
        this.rect_top = new Rect();
        this.local_paint = new Paint();
        this.local_paint.setColor(getResources().getColor(R.color.black));
        this.local_paint.setAntiAlias(true);
        this.local_paint.setDither(true);
        this.local_paint.setStyle(Style.STROKE);
        this.local_paint.setStrokeWidth(2.0f);
        this.display_matrix = getResources().getDisplayMetrics();
        this.mScreenwidth = this.display_matrix.widthPixels;
        this.mScreenHeight = this.display_matrix.heightPixels;
    }



    public void onDraw(Canvas canvas) {
        if (this.mBitmap != null) {
            float[] fArr = new float[9];
            this.matrix.getValues(fArr);
            float f1 = ((0.0f * fArr[0]) + (0.0f * fArr[1]))+ fArr[2];
            float f2 = ((0.0f * fArr[3]) + (0.0f * fArr[4]))+ fArr[5];
            float f3 = ((fArr[0] * ((float) this.mBitmap.getWidth())) + (0.0f * fArr[1])) + fArr[2];
            float f4 = ((fArr[3] * ((float) this.mBitmap.getWidth())) + (0.0f * fArr[4])) + fArr[5];
            float f5 = ((0.0f * fArr[0]) + (fArr[1] * ((float) this.mBitmap.getHeight()))) + fArr[2];
            float f6 = ((0.0f * fArr[3]) + (fArr[4] * ((float) this.mBitmap.getHeight()))) + fArr[5];
            float f7 = ((fArr[0] * ((float) this.mBitmap.getWidth())) + (fArr[1] * ((float) this.mBitmap.getHeight()))) + fArr[2];
            float f8 = ((fArr[3] * ((float) this.mBitmap.getWidth())) + (fArr[4] * ((float) this.mBitmap.getHeight()))) + fArr[5];
            canvas.save();
            canvas.drawBitmap(this.mBitmap, this.matrix, null);
            this.rect_delete.left = (int) (f3 - ((float) (this.deleteBitmapWidth / 2)));
            this.rect_delete.right = (int) (((float) (this.deleteBitmapWidth / 2)) + f3);
            this.rect_delete.top = (int) (f4 - ((float) (this.deleteBitmapHeight / 2)));
            this.rect_delete.bottom = (int) (((float) (this.deleteBitmapHeight / 2)) + f4);
            this.rect_resize.left = (int) (f7 - ((float) (this.resizeBitmapWidth / 2)));
            this.rect_resize.right = (int) ( + ((float) (this.resizeBitmapWidth / 2+f7)));
            this.rect_resize.top = (int) (f8 - ((float) (this.resizeBitmapHeight / 2)));
            this.rect_resize.bottom = (int) (((float) (this.resizeBitmapHeight / 2)) + f8);
            this.rect_top.left = (int) (f1 - ((float) (this.flipVBitmapWidth / 2)));
            this.rect_top.right = (int) (((float) (this.flipVBitmapWidth / 2)) + f1);
            this.rect_top.top = (int) (f2 - ((float) (this.flipVBitmapHeight / 2)));
            this.rect_top.bottom = (int) (((float) (this.flipVBitmapHeight / 2)) + f2);
            this.rect_flip.left = (int) (f5 - ((float) (this.topBitmapWidth / 2)));
            this.rect_flip.right = (int) (((float) (this.topBitmapWidth / 2)) + f5);
            this.rect_flip.top = (int) (f6 - ((float) (this.topBitmapHeight / 2)));
            this.rect_flip.bottom = (int) (((float) (this.topBitmapHeight / 2)) + f6);
            if (this.isInEdit) {
                canvas.drawLine(f1, f2, f3, f4, this.local_paint);
                canvas.drawLine(f3, f4, f7, f8, this.local_paint);
                canvas.drawLine(f5, f6, f7, f8, this.local_paint);
                canvas.drawLine(f5, f6, f1, f2, this.local_paint);
                canvas.drawBitmap(this.deleteBitmap, null, this.rect_delete,
                        null);
                canvas.drawBitmap(this.resizeBitmap, null, this.rect_resize,
                        null);
                    canvas.drawBitmap(this.flipVBitmap, null, this.rect_flip, null);
                    canvas.drawBitmap(this.topBitmap, null, this.rect_top, null);
            }
            canvas.restore();
        }
    }

    public void setImageResource(int i) {
        setBitmap(BitmapFactory.decodeResource(getResources(), i));
    }

    public void setBitmap(Bitmap bitmap) {
        this.matrix.reset();
        this.mBitmap = bitmap;
        setDiagonalLength();
        initBitmaps();
        int width = this.mBitmap.getWidth();
        int height = this.mBitmap.getHeight();
        this.oringinWidth = (float) width;
        float f = (this.MIN_SCALE + this.MAX_SCALE) / 4.0f;
        width /= 2;
        height /= 2;
        this.matrix.postScale(f, f, (float) width, (float) height);
        int i = this.mScreenwidth / 2;
        this.matrix.postTranslate((float) (i - width), (float) (i - height));
        this.mBitmap = this.mBitmap.copy(Config.ARGB_8888, true);
        invalidate();
    }

    private void setDiagonalLength() {
        this.halfdiagonal_length = Math.hypot((double) this.mBitmap.getWidth(), (double) this.mBitmap.getHeight()) / 2.0d;
    }

    private void initBitmaps() {
        if (this.mBitmap.getWidth() >= this.mBitmap.getHeight()) {
            float minWidth = (float) (this.mScreenwidth / 8);
            if (((float) this.mBitmap.getWidth()) < minWidth) {
                this.MIN_SCALE = 1.0f;
            } else {
                this.MIN_SCALE = (1.0f * minWidth)
                        / ((float) this.mBitmap.getWidth());
            }
            if (this.mBitmap.getWidth() > this.mScreenwidth) {
                this.MAX_SCALE = 1.0f;
            } else {
                this.MAX_SCALE = (((float) this.mScreenwidth) * 1.0f)
                        / ((float) this.mBitmap.getWidth());
            }
        } else {
            float minHeight = (float) (this.mScreenwidth / 8);
            if (((float) this.mBitmap.getHeight()) < minHeight) {
                this.MIN_SCALE = 1.0f;
            } else {
                this.MIN_SCALE = (1.0f * minHeight)
                        / ((float) this.mBitmap.getHeight());
            }
            if (this.mBitmap.getHeight() > this.mScreenwidth) {
                this.MAX_SCALE = 1.0f;
            } else {
                this.MAX_SCALE = (((float) this.mScreenwidth) * 1.0f)
                        / ((float) this.mBitmap.getHeight());
            }
        }
        this.topBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.icon_top_enable);
        this.deleteBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.icon_delete);
        this.flipVBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.icon_flip);
        this.resizeBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.icon_resize);
        this.deleteBitmapWidth = (int) (((float) this.deleteBitmap.getWidth()) * BITMAP_SCALE);
        this.deleteBitmapHeight = (int) (((float) this.deleteBitmap
                .getHeight()) * BITMAP_SCALE);
        this.resizeBitmapWidth = (int) (((float) this.resizeBitmap.getWidth()) * BITMAP_SCALE);
        this.resizeBitmapHeight = (int) (((float) this.resizeBitmap
                .getHeight()) * BITMAP_SCALE);
        this.flipVBitmapWidth = (int) (((float) this.flipVBitmap.getWidth()) * BITMAP_SCALE);
        this.flipVBitmapHeight = (int) (((float) this.flipVBitmap.getHeight()) * BITMAP_SCALE);
        this.topBitmapWidth = (int) (((float) this.topBitmap.getWidth()) * BITMAP_SCALE);
        this.topBitmapHeight = (int) (((float) this.topBitmap.getHeight()) * BITMAP_SCALE);
    }


    public boolean onTouchEvent(MotionEvent event) {
        boolean handled = true;
        switch (MotionEventCompat.getActionMasked(event)) {
            case 0:
                if (!isInButton(event, this.rect_delete)) {
                    if (!isInResize(event)) {
                        if (!isInButton(event, this.rect_flip)) {
                            if (!isInButton(event, this.rect_top)) {
                                if (!isInBitmap(event)) {
                                    handled = false;
                                    break;
                                }
                                this.Side = true;
                                this.lastX = event.getX(0);
                                this.lastY = event.getY(0);
                                break;
                            }
                            bringToFront();
                            if (this.operationListener != null) {
                                this.operationListener.onTop(this);
                                break;
                            }
                        }
                        PointF localPointF = new PointF();
                        midDiagonalPoint(localPointF);
                        this.matrix.postScale(-1.0f, 1.0f, localPointF.x,
                                localPointF.y);
                        this.isHorizonMirror = !this.isHorizonMirror;
                        invalidate();
                        break;
                    }
                    this.Resize = true;
                    this.lastRotateDegree = rotationToStartPoint(event);
                    midPointToStartPoint(event);
                    this.lastLength = diagonalLength(event);
                    break;
                } else if (this.operationListener != null) {
                    this.operationListener.onDeleteClick();
                    break;
                }
                break;
            case 1:
            case 3:
                this.Resize = false;
                this.Side = false;
                this.pointer_down = false;
                break;
            case 2:
                float scale;
                if (!this.pointer_down) {
                    if (!this.Resize) {
                        if (this.Side) {
                            float x = event.getX(0);
                            float y = event.getY(0);
                            this.matrix.postTranslate(x - this.lastX, y
                                    - this.lastY);
                            this.lastX = x;
                            this.lastY = y;
                            invalidate();
                            break;
                        }
                    }
                    this.matrix
                            .postRotate(
                                    (rotationToStartPoint(event) - this.lastRotateDegree) * 2.0f,
                                    this.id.x, this.id.y);
                    this.lastRotateDegree = rotationToStartPoint(event);
                    scale = diagonalLength(event) / this.lastLength;
                    if ((((double) diagonalLength(event))
                            / this.halfdiagonal_length > ((double) this.MIN_SCALE) || scale >= 1.0f)
                            && (((double) diagonalLength(event))
                            / this.halfdiagonal_length < ((double) this.MAX_SCALE) || scale <= 1.0f)) {
                        this.lastLength = diagonalLength(event);
                    } else {
                        scale = 1.0f;
                        if (!isInResize(event)) {
                            this.Resize = false;
                        }
                    }
                    this.matrix.postScale(scale, scale, this.id.x, this.id.y);
                    invalidate();
                    break;
                }
                float disNew = spacing(event);
                if (disNew == 0.0f || disNew < 20.0f) {
                    scale = 1.0f;
                } else {
                    scale = (((disNew / this.oldDis) - 1.0f) * 0.09f) + 1.0f;
                }
                float scaleTemp = (((float) Math.abs(this.rect_flip.left
                        - this.rect_resize.left)) * scale)
                        / this.oringinWidth;
                if ((scaleTemp > this.MIN_SCALE || scale >= 1.0f)
                        && (scaleTemp < this.MAX_SCALE || scale <= 1.0f)) {
                    this.lastLength = diagonalLength(event);
                } else {
                    scale = 1.0f;
                }
                this.matrix.postScale(scale, scale, this.id.x, this.id.y);
                invalidate();
                break;
            case 5:
                if (spacing(event) > 20.0f) {
                    this.oldDis = spacing(event);
                    this.pointer_down = true;
                    midPointToStartPoint(event);
                } else {
                    this.pointer_down = false;
                }
                this.Side = false;
                this.Resize = false;
                break;
        }
        if (handled && this.operationListener != null) {
            this.operationListener.onEdit(this);
        }
        return handled;
    }


    public StickerPropertyModel calculate(StickerPropertyModel model) {
        float[] v = new float[9];
        this.matrix.getValues(v);
        float tx = v[2];

        float scalex = v[0];
        float skewy = v[3];
        float rScale = (float) Math.sqrt((double) ((scalex * scalex) + (skewy * skewy)));

        float rAngle = (float) Math.round(Math.atan2((double) v[1], (double) v[0]) * 57.29577951308232d);

        PointF localPointF = new PointF();
        midDiagonalPoint(localPointF);

        float minX = localPointF.x;
        float minY = localPointF.y;
        model.setDegree((float) Math.toRadians((double) rAngle));
        model.setScaling((((float) this.mBitmap.getWidth()) * rScale) / ((float) this.mScreenwidth));
        model.setxLocation(minX / ((float) this.mScreenwidth));
        model.setyLocation(minY / ((float) this.mScreenwidth));
        model.setStickerId(this.stickerId);
        if (this.isHorizonMirror) {
            model.setHorizonMirror(1);
        } else {
            model.setHorizonMirror(2);
        }
        return model;
    }


    private boolean isInBitmap(final MotionEvent motionEvent) {
        final float[] array = new float[9];
        this.matrix.getValues(array);
        return this.pointInRect(
                new float[] {
                        0.0f * array[0] + 0.0f * array[1] + array[2],
                        array[0] * this.mBitmap.getWidth() + 0.0f * array[1]
                                + array[2],
                        array[0] * this.mBitmap.getWidth() + array[1]
                                * this.mBitmap.getHeight() + array[2],
                        0.0f * array[0] + array[1] * this.mBitmap.getHeight()
                                + array[2] }, new float[] {
                        0.0f * array[3] + 0.0f * array[4] + array[5],
                        array[3] * this.mBitmap.getWidth() + 0.0f * array[4]
                                + array[5],
                        array[3] * this.mBitmap.getWidth() + array[4]
                                * this.mBitmap.getHeight() + array[5],
                        0.0f * array[3] + array[4] * this.mBitmap.getHeight()
                                + array[5] }, motionEvent.getX(0),
                motionEvent.getY(0));
    }

    private boolean pointInRect(float[] xRange, float[] yRange, float x, float y) {
        double a1 = Math.hypot((double) (xRange[0] - xRange[1]),
                (double) (yRange[0] - yRange[1]));
        double a2 = Math.hypot((double) (xRange[1] - xRange[2]),
                (double) (yRange[1] - yRange[2]));
        double a3 = Math.hypot((double) (xRange[3] - xRange[2]),
                (double) (yRange[3] - yRange[2]));
        double a4 = Math.hypot((double) (xRange[0] - xRange[3]),
                (double) (yRange[0] - yRange[3]));
        double b1 = Math.hypot((double) (x - xRange[0]),
                (double) (y - yRange[0]));
        double b2 = Math.hypot((double) (x - xRange[1]),
                (double) (y - yRange[1]));
        double b3 = Math.hypot((double) (x - xRange[2]),
                (double) (y - yRange[2]));
        double b4 = Math.hypot((double) (x - xRange[3]),
                (double) (y - yRange[3]));
        double u1 = ((a1 + b1) + b2) / 2.0d;
        double u2 = ((a2 + b2) + b3) / 2.0d;
        double u3 = ((a3 + b3) + b4) / 2.0d;
        double u4 = ((a4 + b4) + b1) / 2.0d;
        return Math
                .abs((a1 * a2)
                        - (((Math.sqrt((((u1 - a1) * u1) * (u1 - b1))
                        * (u1 - b2)) + Math
                        .sqrt((((u2 - a2) * u2) * (u2 - b2))
                                * (u2 - b3))) + Math
                        .sqrt((((u3 - a3) * u3) * (u3 - b3))
                                * (u3 - b4))) + Math
                        .sqrt((((u4 - a4) * u4) * (u4 - b4))
                                * (u4 - b1)))) < 0.5d;
    }


    private boolean isInButton(MotionEvent event, Rect rect) {
        int left = rect.left;
        int right = rect.right;
        int top = rect.top;
        int bottom = rect.bottom;
        if (event.getX(0) < ((float) left) || event.getX(0) > ((float) right)
                || event.getY(0) < ((float) top)
                || event.getY(0) > ((float) bottom)) {
            return false;
        }
        return true;
    }

    private boolean isInResize(MotionEvent event) {
        int top = this.rect_resize.top - 20;
        int right = this.rect_resize.right + 20;
        int bottom = this.rect_resize.bottom + 20;
        if (event.getX(0) < ((float) (this.rect_resize.left - 20))
                || event.getX(0) > ((float) right)
                || event.getY(0) < ((float) top)
                || event.getY(0) > ((float) bottom)) {
            return false;
        }
        return true;
    }

 /*   private boolean isInResize(MotionEvent motionEvent) {
        int i = this.rect_resize.top - 20;
        int i2 = this.rect_resize.right + 20;
        int i3 = this.rect_resize.bottom + 20;
        if (motionEvent.getX(0) < ((float) (this.rect_resize.left - 20)) || motionEvent.getX(0) > ((float) i2) || motionEvent.getY(0) < ((float) i) || motionEvent.getY(0) > ((float) i3)) {
            return false;
        }
        return true;
    }
*/
    private void midPointToStartPoint(MotionEvent motionEvent) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        this.id.set(((((fArr[0] * 0.0f) + (fArr[1] * 0.0f)) + fArr[2]) + motionEvent.getX(0)) / 2.0f, ((((fArr[3] * 0.0f) + (fArr[4] * 0.0f)) + fArr[5]) + motionEvent.getY(0)) / 2.0f);
    }

    private void midDiagonalPoint(PointF pointF) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float width = ((fArr[0] * ((float) this.mBitmap.getWidth())) + (fArr[1] * ((float) this.mBitmap.getHeight()))) + fArr[2];
        pointF.set(((((fArr[0] * 0.0f) + (fArr[1] * 0.0f)) + fArr[2]) + width) / 2.0f, ((((fArr[3] * 0.0f) + (fArr[4] * 0.0f)) + fArr[5]) + (((fArr[3] * ((float) this.mBitmap.getWidth())) + (fArr[4] * ((float) this.mBitmap.getHeight()))) + fArr[5])) / 2.0f);
    }


    private float rotationToStartPoint(MotionEvent motionEvent) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        return (float) Math.toDegrees(Math.atan2((double) (motionEvent.getY(0) - (((fArr[3] * 0.0f) + (fArr[4] * 0.0f)) + fArr[5])), (double) (motionEvent.getX(0) - (((fArr[0] * 0.0f) + (fArr[1] * 0.0f)) + fArr[2]))));
    }



    private float diagonalLength(MotionEvent motionEvent) {
        return (float) Math.hypot((double) (motionEvent.getX(0) - this.id.x), (double) (motionEvent.getY(0) - this.id.y));
    }



    private float spacing(MotionEvent motionEvent) {
        if (motionEvent.getPointerCount() != 2) {
            return 0.0f;
        }
        float x = motionEvent.getX(0) - motionEvent.getX(1);
        float y = motionEvent.getY(0) - motionEvent.getY(1);
        return (float) Math.sqrt((double) ((x * x) + (y * y)));
    }

    public void setOperationListener(OperationListener operationListener) {
        this.operationListener = operationListener;
    }

    public boolean getEditMode() {
        return this.isInEdit;
    }

    public void replaceBitmap(Bitmap bitmap) {
        this.mBitmap = bitmap;
        this.mBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        invalidate();
    }

    public void setInEdit(boolean z) {
        this.isInEdit = z;
        invalidate();
    }

    public void recolor(int i) {
        Paint paint = new Paint();
        paint.setColorFilter(new PorterDuffColorFilter(i, PorterDuff.Mode.SRC_IN));
        new Canvas(this.mBitmap).drawBitmap(this.mBitmap, 0.0f, 0.0f, paint);
    }
}
