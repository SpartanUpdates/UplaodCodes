package com.kotlinz.festivalstorymaker.Models.festival;

import android.graphics.Shader;
import android.graphics.Typeface;

public class a {
    public int a;
    public float b;
    public Typeface c;

    public a() {
        Shader.TileMode tileMode = Shader.TileMode.MIRROR;
    }

}
