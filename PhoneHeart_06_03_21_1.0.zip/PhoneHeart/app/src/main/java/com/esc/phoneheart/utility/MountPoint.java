package com.esc.phoneheart.utility;

import android.content.Context;
import android.os.StatFs;
import android.util.Log;

import com.esc.phoneheart.R;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class MountPoint {
    public static int a = 0;
    public static MountPoint defaultStorage;
    public static MountPoint honeycombSdcard;
    public static boolean init = false;
    public static Map<String, MountPoint> mountPoints = new TreeMap();
    public static Map<String, MountPoint> rootedMountPoints = new TreeMap();
    public String fsType;
    public boolean hasApps2SD;
    public String root;
    public boolean rootRequired;
    public String title;

    public MountPoint(String str, String str2, boolean z, boolean z2, String str3) {
        this.title = str;
        this.root = str2;
        this.hasApps2SD = z;
        this.rootRequired = z2;
        this.fsType = str3;
    }

    public static MountPoint forPath(Context context, String str) {
        String str2;
        MountPoint mountPoint;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Looking for mount point for path: ");
        stringBuilder.append(str);
        String str3 = "diskusage";
        Log.d(str3, stringBuilder.toString());
        initMountPoints(context);
        String withSlash = GlobalData.withSlash(str);
        Iterator it = mountPoints.values().iterator();
        MountPoint mountPoint2 = null;
        while (true) {
            str2 = "MATCH:";
            if (!it.hasNext()) {
                break;
            }
            mountPoint = (MountPoint) it.next();
            if (withSlash.contains(GlobalData.withSlash(mountPoint.root)) && (mountPoint2 == null || mountPoint2.root.length() < mountPoint.root.length())) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(str2);
                stringBuilder.append(mountPoint.root);
                Log.d(str3, stringBuilder.toString());
                mountPoint2 = mountPoint;
            }
        }
        for (MountPoint mountPoint3 : rootedMountPoints.values()) {
            if (withSlash.contains(GlobalData.withSlash(mountPoint3.root)) && (mountPoint2 == null || mountPoint2.root.length() < mountPoint3.root.length())) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(str2);
                stringBuilder.append(mountPoint3.root);
                Log.d(str3, stringBuilder.toString());
                mountPoint2 = mountPoint3;
            }
        }
        if (mountPoint2 != null) {
            return mountPoint2;
        }
        Log.d(str3, "Use honeycomb hack for /data");
        return (MountPoint) mountPoints.get("/data");
    }

    public static MountPoint getDefaultStorage(Context context) {
        initMountPoints(context);
        return defaultStorage;
    }

    public static MountPoint getHoneycombSdcard(Context context) {
        initMountPoints(context);
        return honeycombSdcard;
    }

    public static Map<String, MountPoint> getMountPoints(Context context) {
        initMountPoints(context);
        return mountPoints;
    }

    public static MountPoint getNormal(Context context, String str) {
        initMountPoints(context);
        return (MountPoint) mountPoints.get(str);
    }

    public static MountPoint getRooted(Context context, String str) {
        initMountPoints(context);
        return (MountPoint) rootedMountPoints.get(str);
    }

    public static Map<String, MountPoint> getRootedMountPoints(Context context) {
        initMountPoints(context);
        return rootedMountPoints;
    }

    public static boolean hasMultiple(Context context) {
        initMountPoints(context);
        return mountPoints.size() != 1;
    }

    public static void initMountPoints(Context context) {
        String str = "/";
        if (!init) {
            init = true;
            String storageCardPath = GlobalData.storageCardPath();
            StringBuilder sb = new StringBuilder();
            sb.append("StoragePath: ");
            sb.append(storageCardPath);
            String str2 = "diskusage";
            Log.d(str2, sb.toString());
            ArrayList arrayList = new ArrayList();
            HashSet hashSet = new HashSet();
            if (storageCardPath != null) {
                MountPoint mountPoint = new MountPoint(titleStorageCard(context), storageCardPath, false, false, "");
                defaultStorage = mountPoint;
                arrayList.add(mountPoint);
                mountPoints.put(storageCardPath, defaultStorage);
            }
            try {
                a = 0;
                BufferedReader bufferedReader = new BufferedReader(new FileReader("/proc/mounts"));
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        break;
                    }
                    a += readLine.length();
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("line: ");
                    sb2.append(readLine);
                    Log.d(str2, sb2.toString());
                    String[] split = readLine.split(" +");
                    if (split.length >= 3) {
                        String str3 = split[1];
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("Mount point: ");
                        sb3.append(str3);
                        Log.d(str2, sb3.toString());
                        String str4 = split[2];
                        StatFs statFs = null;
                        try {
                            statFs = new StatFs(str3);
                        } catch (Exception unused) {
                        }
                        if ((str4.equals("vfat") || str4.equals("tntfs") || str4.equals("exfat") || str4.equals("texfat") || GlobalData.isEmulated(str4)) && !str3.startsWith("/mnt/asec") && !str3.startsWith("/firmware") && !str3.startsWith("/mnt/secure") && !str3.startsWith("/data/mac") && !str3.startsWith("/mnt/knox") && statFs != null) {
                            if (!str3.endsWith("/legacy") || !GlobalData.isEmulated(str4)) {
                                Log.d(str2, "Mount point is good");
                                MountPoint mountPoint2 = new MountPoint(str3, str3, false, false, str4);
                                arrayList.add(mountPoint2);
                            }
                        }
                        Log.d(str2, String.format("Excluded based on fsType=%s or black list", new Object[]{str4}));
                        hashSet.add(str3);
                        if (str3.equals(storageCardPath)) {
                            arrayList.remove(defaultStorage);
                            mountPoints.remove(str3);
                        }
                        if (!str3.startsWith("/mnt/asec/")) {
                            MountPoint mountPoint3 = new MountPoint(str3, str3, false, true, str4);
                            arrayList.add(mountPoint3);
                        }
                    }
                }
                bufferedReader.close();
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    MountPoint mountPoint4 = (MountPoint) it.next();
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append(mountPoint4.root);
                    sb4.append(str);
                    String sb5 = sb4.toString();
                    ArrayList arrayList2 = new ArrayList();
                    String name = new File(mountPoint4.root).getName();
                    Iterator it2 = arrayList.iterator();
                    while (it2.hasNext()) {
                        MountPoint mountPoint5 = (MountPoint) it2.next();
                        if (mountPoint5.root.startsWith(sb5)) {
                            StringBuilder sb6 = new StringBuilder();
                            sb6.append(name);
                            sb6.append(str);
                            sb6.append(mountPoint5.root.substring(sb5.length()));
                            arrayList2.add(sb6.toString());
                        }
                    }
                    Iterator it3 = hashSet.iterator();
                    boolean z = false;
                    while (it3.hasNext()) {
                        String str5 = (String) it3.next();
                        StringBuilder sb7 = new StringBuilder();
                        sb7.append(sb5);
                        sb7.append(".android_secure");
                        if (str5.equals(sb7.toString())) {
                            z = true;
                        }
                        if (str5.startsWith(sb5)) {
                            StringBuilder sb8 = new StringBuilder();
                            sb8.append(name);
                            sb8.append(str);
                            sb8.append(str5.substring(sb5.length()));
                            arrayList2.add(sb8.toString());
                        }
                    }
                    MountPoint mountPoint6 = new MountPoint(mountPoint4.root, mountPoint4.root, z, mountPoint4.rootRequired, mountPoint4.fsType);
                    if (mountPoint4.rootRequired) {
                        rootedMountPoints.put(mountPoint4.root, mountPoint6);
                    } else {
                        mountPoints.put(mountPoint4.root, mountPoint6);
                    }
                }
            } catch (Exception e) {
                Log.e(str2, "Failed to get mount points", e);
            }
        }
    }

    public static String titleStorageCard(Context context) {
        return context.getString(R.string.pcl_storage_card);
    }

    public String getRoot() {
        return this.root;
    }
}
