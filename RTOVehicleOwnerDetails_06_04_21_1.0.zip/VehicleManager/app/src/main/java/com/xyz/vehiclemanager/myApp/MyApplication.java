package com.xyz.vehiclemanager.myApp;

import android.app.Application;
import android.content.Context;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.xyz.vehiclemanager.OpenAds.AppOpenManager;


public class MyApplication extends Application {

    public static final String TAG = MyApplication.class.getSimpleName();

    private static MyApplication mInstance;
    private static Context context;

    AppOpenManager appOpenManager;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        context = getApplicationContext();
        appOpenManager = new AppOpenManager(this);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
    }

    public static Context getContext() {
        return context;
    }
    public static synchronized MyApplication getInstance() {
        return mInstance;
    }
}
