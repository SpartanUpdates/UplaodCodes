package com.example.womenabsworkout.fragments;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import androidx.fragment.app.Fragment;

import com.example.womenabsworkout.R;


public class TabFragmentWeek extends Fragment implements OnClickListener {
    public static final String TAG = "TabFragmentWeek";
    public Button mBtnStdDiet;
    public Button mBtnVegDiet;
    public LinearLayout mLayoutStdDiet;
    public LinearLayout mLayoutVegDiet;
    public SharedPreferences mSharedPreferences;
    public String mWeekNumber;
    public Editor prefsEditor;
    public ScrollView scrollweekstddietfood;
    public ScrollView scrollweekvegdietfood;
    public CheckBox std_check1;
    public CheckBox std_check10;
    public CheckBox std_check11;
    public CheckBox std_check12;
    public CheckBox std_check13;
    public CheckBox std_check14;
    public CheckBox std_check15;
    public CheckBox std_check16;
    public CheckBox std_check17;
    public CheckBox std_check18;
    public CheckBox std_check19;
    public CheckBox std_check2;
    public CheckBox std_check20;
    public CheckBox std_check21;
    public CheckBox std_check22;
    public CheckBox std_check3;
    public CheckBox std_check4;
    public CheckBox std_check5;
    public CheckBox std_check6;
    public CheckBox std_check7;
    public CheckBox std_check8;
    public CheckBox std_check9;
    public String stddiet;
    public String stddietcheckbox1;
    public String stddietcheckbox10;
    public String stddietcheckbox11;
    public String stddietcheckbox12;
    public String stddietcheckbox13;
    public String stddietcheckbox14;
    public String stddietcheckbox15;
    public String stddietcheckbox16;
    public String stddietcheckbox17;
    public String stddietcheckbox18;
    public String stddietcheckbox19;
    public String stddietcheckbox2;
    public String stddietcheckbox20;
    public String stddietcheckbox21;
    public String stddietcheckbox22;
    public String stddietcheckbox3;
    public String stddietcheckbox4;
    public String stddietcheckbox5;
    public String stddietcheckbox6;
    public String stddietcheckbox7;
    public String stddietcheckbox8;
    public String stddietcheckbox9;
    public CheckBox veg_check1;
    public CheckBox veg_check10;
    public CheckBox veg_check11;
    public CheckBox veg_check12;
    public CheckBox veg_check13;
    public CheckBox veg_check14;
    public CheckBox veg_check15;
    public CheckBox veg_check16;
    public CheckBox veg_check17;
    public CheckBox veg_check18;
    public CheckBox veg_check19;
    public CheckBox veg_check2;
    public CheckBox veg_check20;
    public CheckBox veg_check3;
    public CheckBox veg_check4;
    public CheckBox veg_check5;
    public CheckBox veg_check6;
    public CheckBox veg_check7;
    public CheckBox veg_check8;
    public CheckBox veg_check9;
    public String vegdiet;
    public String vegdietcheckbox1;
    public String vegdietcheckbox10;
    public String vegdietcheckbox11;
    public String vegdietcheckbox12;
    public String vegdietcheckbox13;
    public String vegdietcheckbox14;
    public String vegdietcheckbox15;
    public String vegdietcheckbox16;
    public String vegdietcheckbox17;
    public String vegdietcheckbox18;
    public String vegdietcheckbox19;
    public String vegdietcheckbox2;
    public String vegdietcheckbox20;
    public String vegdietcheckbox3;
    public String vegdietcheckbox4;
    public String vegdietcheckbox5;
    public String vegdietcheckbox6;
    public String vegdietcheckbox7;
    public String vegdietcheckbox8;
    public String vegdietcheckbox9;
    public Boolean week_stddietcheckbox1;
    public Boolean week_stddietcheckbox10;
    public Boolean week_stddietcheckbox11;
    public Boolean week_stddietcheckbox12;
    public Boolean week_stddietcheckbox13;
    public Boolean week_stddietcheckbox14;
    public Boolean week_stddietcheckbox15;
    public Boolean week_stddietcheckbox16;
    public Boolean week_stddietcheckbox17;
    public Boolean week_stddietcheckbox18;
    public Boolean week_stddietcheckbox19;
    public Boolean week_stddietcheckbox2;
    public Boolean week_stddietcheckbox20;
    public Boolean week_stddietcheckbox21;
    public Boolean week_stddietcheckbox22;
    public Boolean week_stddietcheckbox3;
    public Boolean week_stddietcheckbox4;
    public Boolean week_stddietcheckbox5;
    public Boolean week_stddietcheckbox6;
    public Boolean week_stddietcheckbox7;
    public Boolean week_stddietcheckbox8;
    public Boolean week_stddietcheckbox9;
    public Boolean week_stddietenabled;
    public Boolean week_vegdietcheckbox1;
    public Boolean week_vegdietcheckbox10;
    public Boolean week_vegdietcheckbox11;
    public Boolean week_vegdietcheckbox12;
    public Boolean week_vegdietcheckbox13;
    public Boolean week_vegdietcheckbox14;
    public Boolean week_vegdietcheckbox15;
    public Boolean week_vegdietcheckbox16;
    public Boolean week_vegdietcheckbox17;
    public Boolean week_vegdietcheckbox18;
    public Boolean week_vegdietcheckbox19;
    public Boolean week_vegdietcheckbox2;
    public Boolean week_vegdietcheckbox20;
    public Boolean week_vegdietcheckbox3;
    public Boolean week_vegdietcheckbox4;
    public Boolean week_vegdietcheckbox5;
    public Boolean week_vegdietcheckbox6;
    public Boolean week_vegdietcheckbox7;
    public Boolean week_vegdietcheckbox8;
    public Boolean week_vegdietcheckbox9;
    public Boolean week_vegdietenabled;

    private void setEventListeners() {
        this.std_check1.setOnClickListener(this);
        this.std_check2.setOnClickListener(this);
        this.std_check3.setOnClickListener(this);
        this.std_check4.setOnClickListener(this);
        this.std_check5.setOnClickListener(this);
        this.std_check6.setOnClickListener(this);
        this.std_check7.setOnClickListener(this);
        this.std_check8.setOnClickListener(this);
        this.std_check9.setOnClickListener(this);
        this.std_check10.setOnClickListener(this);
        this.std_check11.setOnClickListener(this);
        this.std_check12.setOnClickListener(this);
        this.std_check13.setOnClickListener(this);
        this.std_check14.setOnClickListener(this);
        this.std_check15.setOnClickListener(this);
        this.std_check16.setOnClickListener(this);
        this.std_check17.setOnClickListener(this);
        this.std_check18.setOnClickListener(this);
        this.std_check19.setOnClickListener(this);
        this.std_check20.setOnClickListener(this);
        this.std_check21.setOnClickListener(this);
        this.std_check22.setOnClickListener(this);
        this.veg_check1.setOnClickListener(this);
        this.veg_check2.setOnClickListener(this);
        this.veg_check3.setOnClickListener(this);
        this.veg_check4.setOnClickListener(this);
        this.veg_check5.setOnClickListener(this);
        this.veg_check6.setOnClickListener(this);
        this.veg_check7.setOnClickListener(this);
        this.veg_check8.setOnClickListener(this);
        this.veg_check9.setOnClickListener(this);
        this.veg_check10.setOnClickListener(this);
        this.veg_check11.setOnClickListener(this);
        this.veg_check12.setOnClickListener(this);
        this.veg_check13.setOnClickListener(this);
        this.veg_check14.setOnClickListener(this);
        this.veg_check15.setOnClickListener(this);
        this.veg_check16.setOnClickListener(this);
        this.veg_check17.setOnClickListener(this);
        this.veg_check18.setOnClickListener(this);
        this.veg_check19.setOnClickListener(this);
        this.veg_check20.setOnClickListener(this);
        this.std_check1.setText(getResources().getString(R.string.Skimmedmilk));
        this.std_check2.setText(getResources().getString(R.string.Eggs));
        this.std_check3.setText(getResources().getString(R.string.greekyogurt));
        this.std_check4.setText(getResources().getString(R.string.Brownbread));
        this.std_check5.setText(getResources().getString(R.string.Oatmealcookies));
        this.std_check6.setText(getResources().getString(R.string.Pineappleorgrapes));
        this.std_check7.setText(getResources().getString(R.string.Applewatermelonpapayastrawberry));
        this.std_check8.setText(getResources().getString(R.string.FishTunaorsalmon));
        this.std_check9.setText(getResources().getString(R.string.Chickenbreasts));
        this.std_check10.setText(getResources().getString(R.string.LeanBeef));
        this.std_check11.setText(getResources().getString(R.string.Carrotcucumbercabbagetomatobeansspinachlettuce));
        this.std_check12.setText(getResources().getString(R.string.Redrice));
        this.std_check13.setText(getResources().getString(R.string.Oats));
        this.std_check14.setText(getResources().getString(R.string.pasta));
        this.std_check15.setText(getResources().getString(R.string.Almonds));
        this.std_check16.setText(getResources().getString(R.string.Walnuts));
        this.std_check17.setText(getResources().getString(R.string.cornflakes));
        this.std_check18.setText(getResources().getString(R.string.Wheatforwraps));
        this.std_check19.setText(getResources().getString(R.string.greenteapowder));
        this.std_check20.setText(getResources().getString(R.string.Amlajuice));
        this.std_check21.setText(getResources().getString(R.string.Lemon));
        this.std_check22.setText(getResources().getString(R.string.honey));
        this.veg_check1.setText(getResources().getString(R.string.Skimmedmilk));
        this.veg_check2.setText(getResources().getString(R.string.Eggs));
        this.veg_check3.setText(getResources().getString(R.string.greekyogurt));
        this.veg_check4.setText(getResources().getString(R.string.Brownbread));
        this.veg_check5.setText(getResources().getString(R.string.Oatmealcookies));
        this.veg_check6.setText(getResources().getString(R.string.Pineappleorgrapes));
        this.veg_check7.setText(getResources().getString(R.string.Applewatermelonpapayastrawberry));
        this.veg_check8.setText(getResources().getString(R.string.Carrotcucumbercabbagetomatobeansspinachlettuce));
        this.veg_check9.setText(getResources().getString(R.string.Mushroom));
        this.veg_check10.setText(getResources().getString(R.string.Redrice));
        this.veg_check11.setText(getResources().getString(R.string.Oats));
        this.veg_check12.setText(getResources().getString(R.string.Pasta));
        this.veg_check13.setText(getResources().getString(R.string.Almonds));
        this.veg_check14.setText(getResources().getString(R.string.Walnuts));
        this.veg_check15.setText(getResources().getString(R.string.cornflakes));
        this.veg_check16.setText(getResources().getString(R.string.Wheatforwraps));
        this.veg_check17.setText(getResources().getString(R.string.Greentea));
        this.veg_check18.setText(getResources().getString(R.string.Amlajuice));
        this.veg_check19.setText(getResources().getString(R.string.Lemonjuice));
        this.veg_check20.setText(getResources().getString(R.string.honey));
    }

    public void onClick(View view) {
        int id = view.getId();
        Boolean valueOf;
        switch (id) {
            case R.id.stddietfoodcheckBox1 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox1, false));
                this.week_stddietcheckbox1 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check1.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox10:
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox10, false));
                this.week_stddietcheckbox10 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check10.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox11 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox11, false));
                this.week_stddietcheckbox11 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check11.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox12 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox12, false));
                this.week_stddietcheckbox12 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check12.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox13 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox13, false));
                this.week_stddietcheckbox13 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check13.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox14 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox14, false));
                this.week_stddietcheckbox14 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check14.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox15 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox15, false));
                this.week_stddietcheckbox15 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check15.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox16 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox16, false));
                this.week_stddietcheckbox16 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check16.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox17 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox17, false));
                this.week_stddietcheckbox17 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check17.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox18 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox18, false));
                this.week_stddietcheckbox18 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check18.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox19 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox19, false));
                this.week_stddietcheckbox19 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check19.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox2 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox2, false));
                this.week_stddietcheckbox2 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check2.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox20 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox20, false));
                this.week_stddietcheckbox20 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check20.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox21 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox21, false));
                this.week_stddietcheckbox21 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check21.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox22 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox22, false));
                this.week_stddietcheckbox22 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check22.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox3 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox3, false));
                this.week_stddietcheckbox3 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check3.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox4 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox4, false));
                this.week_stddietcheckbox4 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check4.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox5 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox5, false));
                this.week_stddietcheckbox5 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check5.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox6 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox6, false));
                this.week_stddietcheckbox6 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check6.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox7 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox7, false));
                this.week_stddietcheckbox7 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check7.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox8 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox8, false));
                this.week_stddietcheckbox8 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check8.setChecked(true);
                    break;
                }
                break;
            case R.id.stddietfoodcheckBox9 :
                valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox9, false));
                this.week_stddietcheckbox9 = valueOf;
                if (!valueOf.booleanValue()) {
                    this.std_check9.setChecked(true);
                    break;
                }
                break;
            default:
                switch (id) {
                    case R.id.vegdietfoodcheckBox1 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox1, false));
                        this.week_vegdietcheckbox1 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check1.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox10 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox10, false));
                        this.week_vegdietcheckbox10 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check10.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox11 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox11, false));
                        this.week_vegdietcheckbox11 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check11.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox12 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox12, false));
                        this.week_vegdietcheckbox12 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check12.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox13 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox13, false));
                        this.week_vegdietcheckbox13 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check13.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox14 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox14, false));
                        this.week_vegdietcheckbox14 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check14.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox15 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox15, false));
                        this.week_vegdietcheckbox15 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check15.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox16 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox16, false));
                        this.week_vegdietcheckbox16 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check16.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox17 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox17, false));
                        this.week_vegdietcheckbox17 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check17.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox18 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox18, false));
                        this.week_vegdietcheckbox18 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check18.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox19 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox19, false));
                        this.week_vegdietcheckbox19 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check19.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox2 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox2, false));
                        this.week_vegdietcheckbox2 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check2.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox20 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox20, false));
                        this.week_vegdietcheckbox20 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check20.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox3 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox3, false));
                        this.week_vegdietcheckbox3 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check3.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox4 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox4, false));
                        this.week_vegdietcheckbox4 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check4.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox5 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox5, false));
                        this.week_vegdietcheckbox5 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check5.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox6 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox6, false));
                        this.week_vegdietcheckbox6 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check6.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox7 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox7, false));
                        this.week_vegdietcheckbox7 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check7.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox8 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox8, false));
                        this.week_vegdietcheckbox8 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check8.setChecked(true);
                            break;
                        }
                        break;
                    case R.id.vegdietfoodcheckBox9 :
                        valueOf = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox9, false));
                        this.week_vegdietcheckbox9 = valueOf;
                        if (!valueOf.booleanValue()) {
                            this.veg_check9.setChecked(true);
                            break;
                        }
                        break;
                    default:
                        return;
                }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mWeekNumber = getArguments().getString("WEEK");
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        String str;
        View inflate = layoutInflater.inflate(R.layout.tab_fragment_week, viewGroup, false);
        inflate.setTag(TAG);
        this.scrollweekstddietfood = (ScrollView) inflate.findViewById(R.id.scrollweekstddietfood);
        this.scrollweekvegdietfood = (ScrollView) inflate.findViewById(R.id.scrollweekvegdietfood);
        this.mBtnStdDiet = (Button) inflate.findViewById(R.id.weekStddiet);
        this.mBtnVegDiet = (Button) inflate.findViewById(R.id.weekvegdiet);
        this.mLayoutStdDiet = (LinearLayout) inflate.findViewById(R.id.weekstddietfood);
        this.mLayoutVegDiet = (LinearLayout) inflate.findViewById(R.id.weekvegdietfood);
        this.std_check1 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox1);
        this.std_check2 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox2);
        this.std_check3 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox3);
        this.std_check4 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox4);
        this.std_check5 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox5);
        this.std_check6 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox6);
        this.std_check7 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox7);
        this.std_check8 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox8);
        this.std_check9 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox9);
        this.std_check10 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox10);
        this.std_check11 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox11);
        this.std_check12 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox12);
        this.std_check13 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox13);
        this.std_check14 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox14);
        this.std_check15 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox15);
        this.std_check16 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox16);
        this.std_check17 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox17);
        this.std_check18 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox18);
        this.std_check19 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox19);
        this.std_check20 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox20);
        this.std_check21 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox21);
        this.std_check22 = (CheckBox) inflate.findViewById(R.id.stddietfoodcheckBox22);
        this.veg_check1 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox1);
        this.veg_check2 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox2);
        this.veg_check3 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox3);
        this.veg_check4 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox4);
        this.veg_check5 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox5);
        this.veg_check6 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox6);
        this.veg_check7 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox7);
        this.veg_check8 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox8);
        this.veg_check9 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox9);
        this.veg_check10 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox10);
        this.veg_check11 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox11);
        this.veg_check12 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox12);
        this.veg_check13 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox13);
        this.veg_check14 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox14);
        this.veg_check15 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox15);
        this.veg_check16 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox16);
        this.veg_check17 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox17);
        this.veg_check18 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox18);
        this.veg_check19 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox19);
        this.veg_check20 = (CheckBox) inflate.findViewById(R.id.vegdietfoodcheckBox20);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity().getApplicationContext());
        this.mSharedPreferences = defaultSharedPreferences;
        this.prefsEditor = defaultSharedPreferences.edit();
        if (this.mWeekNumber.equals("WEEK1")) {
            this.stddiet = "WEEK_1_STDDIET";
            this.vegdiet = "WEEK_1_VEGDIET";
            this.stddietcheckbox1 = "WEEK1_STD_CHECKBOX1";
            this.stddietcheckbox2 = "WEEK1_STD_CHECKBOX2";
            this.stddietcheckbox3 = "WEEK1_STD_CHECKBOX3";
            this.stddietcheckbox4 = "WEEK1_STD_CHECKBOX4";
            this.stddietcheckbox5 = "WEEK1_STD_CHECKBOX5";
            this.stddietcheckbox6 = "WEEK1_STD_CHECKBOX6";
            this.stddietcheckbox7 = "WEEK1_STD_CHECKBOX7";
            this.stddietcheckbox8 = "WEEK1_STD_CHECKBOX8";
            this.stddietcheckbox9 = "WEEK1_STD_CHECKBOX9";
            this.stddietcheckbox10 = "WEEK1_STD_CHECKBOX10";
            this.stddietcheckbox11 = "WEEK1_STD_CHECKBOX11";
            this.stddietcheckbox12 = "WEEK1_STD_CHECKBOX12";
            this.stddietcheckbox13 = "WEEK1_STD_CHECKBOX13";
            this.stddietcheckbox14 = "WEEK1_STD_CHECKBOX14";
            this.stddietcheckbox15 = "WEEK1_STD_CHECKBOX15";
            this.stddietcheckbox16 = "WEEK1_STD_CHECKBOX16";
            this.stddietcheckbox17 = "WEEK1_STD_CHECKBOX17";
            this.stddietcheckbox18 = "WEEK1_STD_CHECKBOX18";
            this.stddietcheckbox19 = "WEEK1_STD_CHECKBOX19";
            this.stddietcheckbox20 = "WEEK1_STD_CHECKBOX20";
            this.stddietcheckbox21 = "WEEK1_STD_CHECKBOX21";
            this.stddietcheckbox22 = "WEEK1_STD_CHECKBOX22";
            this.vegdietcheckbox1 = "WEEK1_VEG_CHECKBOX1";
            this.vegdietcheckbox2 = "WEEK1_VEG_CHECKBOX2";
            this.vegdietcheckbox3 = "WEEK1_VEG_CHECKBOX3";
            this.vegdietcheckbox4 = "WEEK1_VEG_CHECKBOX4";
            this.vegdietcheckbox5 = "WEEK1_VEG_CHECKBOX5";
            this.vegdietcheckbox6 = "WEEK1_VEG_CHECKBOX6";
            this.vegdietcheckbox7 = "WEEK1_VEG_CHECKBOX7";
            this.vegdietcheckbox8 = "WEEK1_VEG_CHECKBOX8";
            this.vegdietcheckbox9 = "WEEK1_VEG_CHECKBOX9";
            this.vegdietcheckbox10 = "WEEK1_VEG_CHECKBOX10";
            this.vegdietcheckbox11 = "WEEK1_VEG_CHECKBOX11";
            this.vegdietcheckbox12 = "WEEK1_VEG_CHECKBOX12";
            this.vegdietcheckbox13 = "WEEK1_VEG_CHECKBOX13";
            this.vegdietcheckbox14 = "WEEK1_VEG_CHECKBOX14";
            this.vegdietcheckbox15 = "WEEK1_VEG_CHECKBOX15";
            this.vegdietcheckbox16 = "WEEK1_VEG_CHECKBOX16";
            this.vegdietcheckbox17 = "WEEK1_VEG_CHECKBOX17";
            this.vegdietcheckbox18 = "WEEK1_VEG_CHECKBOX18";
            this.vegdietcheckbox19 = "WEEK1_VEG_CHECKBOX19";
            str = "WEEK1_VEG_CHECKBOX20";
        } else if (this.mWeekNumber.equals("WEEK2")) {
            this.stddiet = "WEEK_2_STDDIET";
            this.vegdiet = "WEEK_2_VEGDIET";
            this.stddietcheckbox1 = "WEEK2_STD_CHECKBOX1";
            this.stddietcheckbox2 = "WEEK2_STD_CHECKBOX2";
            this.stddietcheckbox3 = "WEEK2_STD_CHECKBOX3";
            this.stddietcheckbox4 = "WEEK2_STD_CHECKBOX4";
            this.stddietcheckbox5 = "WEEK2_STD_CHECKBOX5";
            this.stddietcheckbox6 = "WEEK2_STD_CHECKBOX6";
            this.stddietcheckbox7 = "WEEK2_STD_CHECKBOX7";
            this.stddietcheckbox8 = "WEEK2_STD_CHECKBOX8";
            this.stddietcheckbox9 = "WEEK2_STD_CHECKBOX9";
            this.stddietcheckbox10 = "WEEK2_STD_CHECKBOX10";
            this.stddietcheckbox11 = "WEEK2_STD_CHECKBOX11";
            this.stddietcheckbox12 = "WEEK2_STD_CHECKBOX12";
            this.stddietcheckbox13 = "WEEK2_STD_CHECKBOX13";
            this.stddietcheckbox14 = "WEEK2_STD_CHECKBOX14";
            this.stddietcheckbox15 = "WEEK2_STD_CHECKBOX15";
            this.stddietcheckbox16 = "WEEK2_STD_CHECKBOX16";
            this.stddietcheckbox17 = "WEEK2_STD_CHECKBOX17";
            this.stddietcheckbox18 = "WEEK2_STD_CHECKBOX18";
            this.stddietcheckbox19 = "WEEK2_STD_CHECKBOX19";
            this.stddietcheckbox20 = "WEEK2_STD_CHECKBOX20";
            this.stddietcheckbox21 = "WEEK2_STD_CHECKBOX21";
            this.stddietcheckbox22 = "WEEK2_STD_CHECKBOX22";
            this.vegdietcheckbox1 = "WEEK2_VEG_CHECKBOX1";
            this.vegdietcheckbox2 = "WEEK2_VEG_CHECKBOX2";
            this.vegdietcheckbox3 = "WEEK2_VEG_CHECKBOX3";
            this.vegdietcheckbox4 = "WEEK2_VEG_CHECKBOX4";
            this.vegdietcheckbox5 = "WEEK2_VEG_CHECKBOX5";
            this.vegdietcheckbox6 = "WEEK2_VEG_CHECKBOX6";
            this.vegdietcheckbox7 = "WEEK2_VEG_CHECKBOX7";
            this.vegdietcheckbox8 = "WEEK2_VEG_CHECKBOX8";
            this.vegdietcheckbox9 = "WEEK2_VEG_CHECKBOX9";
            this.vegdietcheckbox10 = "WEEK2_VEG_CHECKBOX10";
            this.vegdietcheckbox11 = "WEEK2_VEG_CHECKBOX11";
            this.vegdietcheckbox12 = "WEEK2_VEG_CHECKBOX12";
            this.vegdietcheckbox13 = "WEEK2_VEG_CHECKBOX13";
            this.vegdietcheckbox14 = "WEEK2_VEG_CHECKBOX14";
            this.vegdietcheckbox5 = "WEEK2_VEG_CHECKBOX15";
            this.vegdietcheckbox16 = "WEEK2_VEG_CHECKBOX16";
            this.vegdietcheckbox17 = "WEEK2_VEG_CHECKBOX17";
            this.vegdietcheckbox18 = "WEEK2_VEG_CHECKBOX18";
            this.vegdietcheckbox19 = "WEEK2_VEG_CHECKBOX19";
            str = "WEEK2_VEG_CHECKBOX20";
        } else if (this.mWeekNumber.equals("WEEK3")) {
            this.stddiet = "WEEK_3_STDDIET";
            this.vegdiet = "WEEK_3_VEGDIET";
            this.stddietcheckbox1 = "WEEK3_STD_CHECKBOX1";
            this.stddietcheckbox2 = "WEEK3_STD_CHECKBOX2";
            this.stddietcheckbox3 = "WEEK3_STD_CHECKBOX3";
            this.stddietcheckbox4 = "WEEK3_STD_CHECKBOX4";
            this.stddietcheckbox5 = "WEEK3_STD_CHECKBOX5";
            this.stddietcheckbox6 = "WEEK3_STD_CHECKBOX6";
            this.stddietcheckbox7 = "WEEK3_STD_CHECKBOX7";
            this.stddietcheckbox8 = "WEEK3_STD_CHECKBOX8";
            this.stddietcheckbox9 = "WEEK3_STD_CHECKBOX9";
            this.stddietcheckbox10 = "WEEK3_STD_CHECKBOX10";
            this.stddietcheckbox11 = "WEEK3_STD_CHECKBOX11";
            this.stddietcheckbox12 = "WEEK3_STD_CHECKBOX12";
            this.stddietcheckbox13 = "WEEK3_STD_CHECKBOX13";
            this.stddietcheckbox14 = "WEEK3_STD_CHECKBOX14";
            this.stddietcheckbox15 = "WEEK3_STD_CHECKBOX15";
            this.stddietcheckbox16 = "WEEK3_STD_CHECKBOX16";
            this.stddietcheckbox17 = "WEEK3_STD_CHECKBOX17";
            this.stddietcheckbox18 = "WEEK3_STD_CHECKBOX18";
            this.stddietcheckbox19 = "WEEK3_STD_CHECKBOX19";
            this.stddietcheckbox20 = "WEEK3_STD_CHECKBOX20";
            this.stddietcheckbox21 = "WEEK3_STD_CHECKBOX21";
            this.stddietcheckbox22 = "WEEK3_STD_CHECKBOX22";
            this.vegdietcheckbox1 = "WEEK3_VEG_CHECKBOX1";
            this.vegdietcheckbox2 = "WEEK3_VEG_CHECKBOX2";
            this.vegdietcheckbox3 = "WEEK3_VEG_CHECKBOX3";
            this.vegdietcheckbox4 = "WEEK3_VEG_CHECKBOX4";
            this.vegdietcheckbox5 = "WEEK3_VEG_CHECKBOX5";
            this.vegdietcheckbox6 = "WEEK3_VEG_CHECKBOX6";
            this.vegdietcheckbox7 = "WEEK3_VEG_CHECKBOX7";
            this.vegdietcheckbox8 = "WEEK3_VEG_CHECKBOX8";
            this.vegdietcheckbox9 = "WEEK3_VEG_CHECKBOX9";
            this.vegdietcheckbox10 = "WEEK3_VEG_CHECKBOX10";
            this.vegdietcheckbox11 = "WEEK3_VEG_CHECKBOX11";
            this.vegdietcheckbox12 = "WEEK3_VEG_CHECKBOX12";
            this.vegdietcheckbox13 = "WEEK3_VEG_CHECKBOX13";
            this.vegdietcheckbox14 = "WEEK3_VEG_CHECKBOX14";
            this.vegdietcheckbox15 = "WEEK3_VEG_CHECKBOX15";
            this.vegdietcheckbox16 = "WEEK3_VEG_CHECKBOX16";
            this.vegdietcheckbox17 = "WEEK3_VEG_CHECKBOX17";
            this.vegdietcheckbox18 = "WEEK3_VEG_CHECKBOX18";
            this.vegdietcheckbox19 = "WEEK3_VEG_CHECKBOX19";
            str = "WEEK3_VEG_CHECKBOX20";
        } else if (this.mWeekNumber.equals("WEEK4")) {
            this.stddiet = "WEEK_4_STDDIET";
            this.vegdiet = "WEEK_4_VEGDIET";
            this.stddietcheckbox1 = "WEEK4_STD_CHECKBOX1";
            this.stddietcheckbox2 = "WEEK4_STD_CHECKBOX2";
            this.stddietcheckbox3 = "WEEK4_STD_CHECKBOX3";
            this.stddietcheckbox4 = "WEEK4_STD_CHECKBOX4";
            this.stddietcheckbox5 = "WEEK4_STD_CHECKBOX5";
            this.stddietcheckbox6 = "WEEK4_STD_CHECKBOX6";
            this.stddietcheckbox7 = "WEEK4_STD_CHECKBOX7";
            this.stddietcheckbox8 = "WEEK4_STD_CHECKBOX8";
            this.stddietcheckbox9 = "WEEK4_STD_CHECKBOX9";
            this.stddietcheckbox10 = "WEEK4_STD_CHECKBOX10";
            this.stddietcheckbox11 = "WEEK4_STD_CHECKBOX11";
            this.stddietcheckbox12 = "WEEK4_STD_CHECKBOX12";
            this.stddietcheckbox13 = "WEEK4_STD_CHECKBOX13";
            this.stddietcheckbox14 = "WEEK4_STD_CHECKBOX14";
            this.stddietcheckbox15 = "WEEK4_STD_CHECKBOX15";
            this.stddietcheckbox16 = "WEEK4_STD_CHECKBOX16";
            this.stddietcheckbox17 = "WEEK4_STD_CHECKBOX17";
            this.stddietcheckbox18 = "WEEK4_STD_CHECKBOX18";
            this.stddietcheckbox19 = "WEEK4_STD_CHECKBOX19";
            this.stddietcheckbox20 = "WEEK4_STD_CHECKBOX20";
            this.stddietcheckbox21 = "WEEK4_STD_CHECKBOX21";
            this.stddietcheckbox22 = "WEEK4_STD_CHECKBOX22";
            this.vegdietcheckbox1 = "WEEK4_VEG_CHECKBOX1";
            this.vegdietcheckbox2 = "WEEK4_VEG_CHECKBOX2";
            this.vegdietcheckbox3 = "WEEK4_VEG_CHECKBOX3";
            this.vegdietcheckbox4 = "WEEK4_VEG_CHECKBOX4";
            this.vegdietcheckbox5 = "WEEK4_VEG_CHECKBOX5";
            this.vegdietcheckbox6 = "WEEK4_VEG_CHECKBOX6";
            this.vegdietcheckbox7 = "WEEK4_VEG_CHECKBOX7";
            this.vegdietcheckbox8 = "WEEK4_VEG_CHECKBOX8";
            this.vegdietcheckbox9 = "WEEK4_VEG_CHECKBOX9";
            this.vegdietcheckbox10 = "WEEK4_VEG_CHECKBOX10";
            this.vegdietcheckbox11 = "WEEK4_VEG_CHECKBOX11";
            this.vegdietcheckbox12 = "WEEK4_VEG_CHECKBOX12";
            this.vegdietcheckbox13 = "WEEK4_VEG_CHECKBOX13";
            this.vegdietcheckbox14 = "WEEK4_VEG_CHECKBOX14";
            this.vegdietcheckbox15 = "WEEK4_VEG_CHECKBOX15";
            this.vegdietcheckbox16 = "WEEK4_VEG_CHECKBOX16";
            this.vegdietcheckbox17 = "WEEK4_VEG_CHECKBOX17";
            this.vegdietcheckbox18 = "WEEK4_VEG_CHECKBOX18";
            this.vegdietcheckbox19 = "WEEK4_VEG_CHECKBOX19";
            str = "WEEK4_VEG_CHECKBOX20";
        } else {
            if (this.mWeekNumber.equals("WEEK5")) {
                this.stddiet = "WEEK_5_STDDIET";
                this.vegdiet = "WEEK_5_VEGDIET";
                this.stddietcheckbox1 = "WEEK5_STD_CHECKBOX1";
                this.stddietcheckbox2 = "WEEK5_STD_CHECKBOX2";
                this.stddietcheckbox3 = "WEEK5_STD_CHECKBOX3";
                this.stddietcheckbox4 = "WEEK5_STD_CHECKBOX4";
                this.stddietcheckbox5 = "WEEK5_STD_CHECKBOX5";
                this.stddietcheckbox6 = "WEEK5_STD_CHECKBOX6";
                this.stddietcheckbox7 = "WEEK5_STD_CHECKBOX7";
                this.stddietcheckbox8 = "WEEK5_STD_CHECKBOX8";
                this.stddietcheckbox9 = "WEEK5_STD_CHECKBOX9";
                this.stddietcheckbox10 = "WEEK5_STD_CHECKBOX10";
                this.stddietcheckbox11 = "WEEK5_STD_CHECKBOX11";
                this.stddietcheckbox12 = "WEEK5_STD_CHECKBOX12";
                this.stddietcheckbox13 = "WEEK5_STD_CHECKBOX13";
                this.stddietcheckbox14 = "WEEK5_STD_CHECKBOX14";
                this.stddietcheckbox15 = "WEEK5_STD_CHECKBOX15";
                this.stddietcheckbox16 = "WEEK5_STD_CHECKBOX16";
                this.stddietcheckbox17 = "WEEK5_STD_CHECKBOX17";
                this.stddietcheckbox18 = "WEEK5_STD_CHECKBOX18";
                this.stddietcheckbox19 = "WEEK5_STD_CHECKBOX19";
                this.stddietcheckbox20 = "WEEK5_STD_CHECKBOX20";
                this.stddietcheckbox21 = "WEEK5_STD_CHECKBOX21";
                this.stddietcheckbox22 = "WEEK5_STD_CHECKBOX22";
                this.vegdietcheckbox1 = "WEEK5_VEG_CHECKBOX1";
                this.vegdietcheckbox2 = "WEEK5_VEG_CHECKBOX2";
                this.vegdietcheckbox3 = "WEEK5_VEG_CHECKBOX3";
                this.vegdietcheckbox4 = "WEEK5_VEG_CHECKBOX4";
                this.vegdietcheckbox5 = "WEEK5_VEG_CHECKBOX5";
                this.vegdietcheckbox6 = "WEEK5_VEG_CHECKBOX6";
                this.vegdietcheckbox7 = "WEEK5_VEG_CHECKBOX7";
                this.vegdietcheckbox8 = "WEEK5_VEG_CHECKBOX8";
                this.vegdietcheckbox9 = "WEEK5_VEG_CHECKBOX9";
                this.vegdietcheckbox10 = "WEEK5_VEG_CHECKBOX10";
                this.vegdietcheckbox11 = "WEEK5_VEG_CHECKBOX11";
                this.vegdietcheckbox12 = "WEEK5_VEG_CHECKBOX12";
                this.vegdietcheckbox13 = "WEEK5_VEG_CHECKBOX13";
                this.vegdietcheckbox14 = "WEEK5_VEG_CHECKBOX14";
                this.vegdietcheckbox15 = "WEEK5_VEG_CHECKBOX15";
                this.vegdietcheckbox16 = "WEEK5_VEG_CHECKBOX16";
                this.vegdietcheckbox17 = "WEEK5_VEG_CHECKBOX17";
                this.vegdietcheckbox18 = "WEEK5_VEG_CHECKBOX18";
                this.vegdietcheckbox19 = "WEEK5_VEG_CHECKBOX19";
            }
            this.week_stddietenabled = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddiet, false));
            this.week_vegdietenabled = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdiet, false));
            this.week_stddietcheckbox1 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox1, false));
            this.week_stddietcheckbox2 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox2, false));
            this.week_stddietcheckbox3 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox3, false));
            this.week_stddietcheckbox4 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox4, false));
            this.week_stddietcheckbox5 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox5, false));
            this.week_stddietcheckbox6 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox6, false));
            this.week_stddietcheckbox7 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox7, false));
            this.week_stddietcheckbox8 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox8, false));
            this.week_stddietcheckbox9 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox9, false));
            this.week_stddietcheckbox10 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox10, false));
            this.week_stddietcheckbox11 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox11, false));
            this.week_stddietcheckbox12 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox12, false));
            this.week_stddietcheckbox13 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox13, false));
            this.week_stddietcheckbox14 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox14, false));
            this.week_stddietcheckbox15 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox15, false));
            this.week_stddietcheckbox16 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox16, false));
            this.week_stddietcheckbox17 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox17, false));
            this.week_stddietcheckbox18 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox18, false));
            this.week_stddietcheckbox19 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox19, false));
            this.week_stddietcheckbox20 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox20, false));
            this.week_stddietcheckbox21 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox21, false));
            this.week_stddietcheckbox22 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox22, false));
            this.std_check1.setChecked(this.week_stddietcheckbox1.booleanValue());
            this.std_check2.setChecked(this.week_stddietcheckbox2.booleanValue());
            this.std_check3.setChecked(this.week_stddietcheckbox3.booleanValue());
            this.std_check4.setChecked(this.week_stddietcheckbox4.booleanValue());
            this.std_check5.setChecked(this.week_stddietcheckbox5.booleanValue());
            this.std_check6.setChecked(this.week_stddietcheckbox6.booleanValue());
            this.std_check7.setChecked(this.week_stddietcheckbox7.booleanValue());
            this.std_check8.setChecked(this.week_stddietcheckbox8.booleanValue());
            this.std_check9.setChecked(this.week_stddietcheckbox9.booleanValue());
            this.std_check10.setChecked(this.week_stddietcheckbox10.booleanValue());
            this.std_check11.setChecked(this.week_stddietcheckbox11.booleanValue());
            this.std_check12.setChecked(this.week_stddietcheckbox12.booleanValue());
            this.std_check13.setChecked(this.week_stddietcheckbox13.booleanValue());
            this.std_check14.setChecked(this.week_stddietcheckbox14.booleanValue());
            this.std_check15.setChecked(this.week_stddietcheckbox15.booleanValue());
            this.std_check16.setChecked(this.week_stddietcheckbox16.booleanValue());
            this.std_check17.setChecked(this.week_stddietcheckbox17.booleanValue());
            this.std_check18.setChecked(this.week_stddietcheckbox18.booleanValue());
            this.std_check19.setChecked(this.week_stddietcheckbox19.booleanValue());
            this.std_check20.setChecked(this.week_stddietcheckbox20.booleanValue());
            this.std_check21.setChecked(this.week_stddietcheckbox21.booleanValue());
            this.std_check22.setChecked(this.week_stddietcheckbox22.booleanValue());
            this.week_vegdietcheckbox1 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox1, false));
            this.week_vegdietcheckbox2 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox2, false));
            this.week_vegdietcheckbox3 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox3, false));
            this.week_vegdietcheckbox4 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox4, false));
            this.week_vegdietcheckbox5 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox5, false));
            this.week_vegdietcheckbox6 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox6, false));
            this.week_vegdietcheckbox7 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox7, false));
            this.week_vegdietcheckbox8 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox8, false));
            this.week_vegdietcheckbox9 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox9, false));
            this.week_vegdietcheckbox10 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox10, false));
            this.week_vegdietcheckbox11 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox11, false));
            this.week_vegdietcheckbox12 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox12, false));
            this.week_vegdietcheckbox13 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox13, false));
            this.week_vegdietcheckbox14 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox14, false));
            this.week_vegdietcheckbox15 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox15, false));
            this.week_vegdietcheckbox16 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox16, false));
            this.week_vegdietcheckbox17 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox17, false));
            this.week_vegdietcheckbox18 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox18, false));
            this.week_vegdietcheckbox19 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox19, false));
            this.week_vegdietcheckbox20 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox20, false));
            this.veg_check1.setChecked(this.week_vegdietcheckbox1.booleanValue());
            this.veg_check2.setChecked(this.week_vegdietcheckbox2.booleanValue());
            this.veg_check3.setChecked(this.week_vegdietcheckbox3.booleanValue());
            this.veg_check4.setChecked(this.week_vegdietcheckbox4.booleanValue());
            this.veg_check5.setChecked(this.week_vegdietcheckbox5.booleanValue());
            this.veg_check6.setChecked(this.week_vegdietcheckbox6.booleanValue());
            this.veg_check7.setChecked(this.week_vegdietcheckbox7.booleanValue());
            this.veg_check8.setChecked(this.week_vegdietcheckbox8.booleanValue());
            this.veg_check9.setChecked(this.week_vegdietcheckbox9.booleanValue());
            this.veg_check10.setChecked(this.week_vegdietcheckbox10.booleanValue());
            this.veg_check11.setChecked(this.week_vegdietcheckbox11.booleanValue());
            this.veg_check12.setChecked(this.week_vegdietcheckbox12.booleanValue());
            this.veg_check13.setChecked(this.week_vegdietcheckbox13.booleanValue());
            this.veg_check14.setChecked(this.week_vegdietcheckbox14.booleanValue());
            this.veg_check15.setChecked(this.week_vegdietcheckbox15.booleanValue());
            this.veg_check16.setChecked(this.week_vegdietcheckbox16.booleanValue());
            this.veg_check17.setChecked(this.week_vegdietcheckbox17.booleanValue());
            this.veg_check18.setChecked(this.week_vegdietcheckbox18.booleanValue());
            this.veg_check19.setChecked(this.week_vegdietcheckbox19.booleanValue());
            this.veg_check20.setChecked(this.week_vegdietcheckbox20.booleanValue());
            if (!this.week_stddietenabled.booleanValue() && !this.week_vegdietenabled.booleanValue()) {
                this.mBtnStdDiet.setTextColor(getResources().getColor(R.color.colorAccent));
                this.mBtnVegDiet.setTextColor(getResources().getColor(R.color.black));
                this.scrollweekstddietfood.setVisibility(View.VISIBLE);
                this.scrollweekvegdietfood.setVisibility(View.INVISIBLE);
            } else if (this.week_stddietenabled.booleanValue() && this.week_vegdietenabled.booleanValue()) {
                this.mBtnStdDiet.setTextColor(getResources().getColor(R.color.black));
                this.mBtnVegDiet.setTextColor(getResources().getColor(R.color.colorAccent));
                this.scrollweekstddietfood.setVisibility(View.INVISIBLE);
                this.scrollweekvegdietfood.setVisibility(View.VISIBLE);
            } else if (!(this.week_stddietenabled.booleanValue() || this.week_vegdietenabled.booleanValue())) {
                this.mBtnStdDiet.setTextColor(getResources().getColor(R.color.colorAccent));
                this.mBtnVegDiet.setTextColor(getResources().getColor(R.color.black));
                this.scrollweekstddietfood.setVisibility(View.VISIBLE);
                this.scrollweekvegdietfood.setVisibility(View.INVISIBLE);
                this.prefsEditor.putBoolean(this.stddiet, true);
                this.prefsEditor.putBoolean(this.vegdiet, false);
                this.prefsEditor.apply();
            }
            this.mBtnStdDiet.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    TabFragmentWeek tabFragmentWeek = TabFragmentWeek.this;
                    tabFragmentWeek.week_stddietenabled = Boolean.valueOf(tabFragmentWeek.mSharedPreferences.getBoolean(TabFragmentWeek.this.stddiet, false));
                    if (!TabFragmentWeek.this.week_stddietenabled.booleanValue()) {
                        TabFragmentWeek.this.mBtnStdDiet.setTextColor(TabFragmentWeek.this.getResources().getColor(R.color.colorAccent));
                        TabFragmentWeek.this.scrollweekstddietfood.setVisibility(View.VISIBLE);
                        TabFragmentWeek.this.mBtnVegDiet.setTextColor(TabFragmentWeek.this.getResources().getColor(R.color.black));
                        TabFragmentWeek.this.scrollweekvegdietfood.setVisibility(View.INVISIBLE);
                        TabFragmentWeek.this.prefsEditor.putBoolean(TabFragmentWeek.this.stddiet, true);
                        TabFragmentWeek.this.prefsEditor.putBoolean(TabFragmentWeek.this.vegdiet, false);
                    }
                    TabFragmentWeek.this.prefsEditor.commit();
                }
            });
            this.mBtnVegDiet.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    TabFragmentWeek tabFragmentWeek = TabFragmentWeek.this;
                    tabFragmentWeek.week_vegdietenabled = Boolean.valueOf(tabFragmentWeek.mSharedPreferences.getBoolean(TabFragmentWeek.this.vegdiet, false));
                    if (!TabFragmentWeek.this.week_vegdietenabled.booleanValue()) {
                        TabFragmentWeek.this.mBtnVegDiet.setTextColor(TabFragmentWeek.this.getResources().getColor(R.color.colorAccent));
                        TabFragmentWeek.this.scrollweekvegdietfood.setVisibility(View.VISIBLE);
                        TabFragmentWeek.this.mBtnStdDiet.setTextColor(TabFragmentWeek.this.getResources().getColor(R.color.black));
                        TabFragmentWeek.this.scrollweekstddietfood.setVisibility(View.INVISIBLE);
                        TabFragmentWeek.this.prefsEditor.putBoolean(TabFragmentWeek.this.vegdiet, true);
                        TabFragmentWeek.this.prefsEditor.putBoolean(TabFragmentWeek.this.stddiet, false);
                    }
                    TabFragmentWeek.this.prefsEditor.commit();
                }
            });
            setEventListeners();
            return inflate;
        }
        this.vegdietcheckbox20 = str;
        this.week_stddietenabled = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddiet, false));
        this.week_vegdietenabled = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdiet, false));
        this.week_stddietcheckbox1 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox1, false));
        this.week_stddietcheckbox2 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox2, false));
        this.week_stddietcheckbox3 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox3, false));
        this.week_stddietcheckbox4 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox4, false));
        this.week_stddietcheckbox5 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox5, false));
        this.week_stddietcheckbox6 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox6, false));
        this.week_stddietcheckbox7 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox7, false));
        this.week_stddietcheckbox8 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox8, false));
        this.week_stddietcheckbox9 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox9, false));
        this.week_stddietcheckbox10 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox10, false));
        this.week_stddietcheckbox11 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox11, false));
        this.week_stddietcheckbox12 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox12, false));
        this.week_stddietcheckbox13 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox13, false));
        this.week_stddietcheckbox14 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox14, false));
        this.week_stddietcheckbox15 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox15, false));
        this.week_stddietcheckbox16 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox16, false));
        this.week_stddietcheckbox17 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox17, false));
        this.week_stddietcheckbox18 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox18, false));
        this.week_stddietcheckbox19 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox19, false));
        this.week_stddietcheckbox20 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox20, false));
        this.week_stddietcheckbox21 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox21, false));
        this.week_stddietcheckbox22 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.stddietcheckbox22, false));
        this.std_check1.setChecked(this.week_stddietcheckbox1.booleanValue());
        this.std_check2.setChecked(this.week_stddietcheckbox2.booleanValue());
        this.std_check3.setChecked(this.week_stddietcheckbox3.booleanValue());
        this.std_check4.setChecked(this.week_stddietcheckbox4.booleanValue());
        this.std_check5.setChecked(this.week_stddietcheckbox5.booleanValue());
        this.std_check6.setChecked(this.week_stddietcheckbox6.booleanValue());
        this.std_check7.setChecked(this.week_stddietcheckbox7.booleanValue());
        this.std_check8.setChecked(this.week_stddietcheckbox8.booleanValue());
        this.std_check9.setChecked(this.week_stddietcheckbox9.booleanValue());
        this.std_check10.setChecked(this.week_stddietcheckbox10.booleanValue());
        this.std_check11.setChecked(this.week_stddietcheckbox11.booleanValue());
        this.std_check12.setChecked(this.week_stddietcheckbox12.booleanValue());
        this.std_check13.setChecked(this.week_stddietcheckbox13.booleanValue());
        this.std_check14.setChecked(this.week_stddietcheckbox14.booleanValue());
        this.std_check15.setChecked(this.week_stddietcheckbox15.booleanValue());
        this.std_check16.setChecked(this.week_stddietcheckbox16.booleanValue());
        this.std_check17.setChecked(this.week_stddietcheckbox17.booleanValue());
        this.std_check18.setChecked(this.week_stddietcheckbox18.booleanValue());
        this.std_check19.setChecked(this.week_stddietcheckbox19.booleanValue());
        this.std_check20.setChecked(this.week_stddietcheckbox20.booleanValue());
        this.std_check21.setChecked(this.week_stddietcheckbox21.booleanValue());
        this.std_check22.setChecked(this.week_stddietcheckbox22.booleanValue());
        this.week_vegdietcheckbox1 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox1, false));
        this.week_vegdietcheckbox2 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox2, false));
        this.week_vegdietcheckbox3 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox3, false));
        this.week_vegdietcheckbox4 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox4, false));
        this.week_vegdietcheckbox5 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox5, false));
        this.week_vegdietcheckbox6 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox6, false));
        this.week_vegdietcheckbox7 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox7, false));
        this.week_vegdietcheckbox8 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox8, false));
        this.week_vegdietcheckbox9 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox9, false));
        this.week_vegdietcheckbox10 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox10, false));
        this.week_vegdietcheckbox11 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox11, false));
        this.week_vegdietcheckbox12 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox12, false));
        this.week_vegdietcheckbox13 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox13, false));
        this.week_vegdietcheckbox14 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox14, false));
        this.week_vegdietcheckbox15 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox15, false));
        this.week_vegdietcheckbox16 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox16, false));
        this.week_vegdietcheckbox17 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox17, false));
        this.week_vegdietcheckbox18 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox18, false));
        this.week_vegdietcheckbox19 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox19, false));
        this.week_vegdietcheckbox20 = Boolean.valueOf(this.mSharedPreferences.getBoolean(this.vegdietcheckbox20, false));
        this.veg_check1.setChecked(this.week_vegdietcheckbox1.booleanValue());
        this.veg_check2.setChecked(this.week_vegdietcheckbox2.booleanValue());
        this.veg_check3.setChecked(this.week_vegdietcheckbox3.booleanValue());
        this.veg_check4.setChecked(this.week_vegdietcheckbox4.booleanValue());
        this.veg_check5.setChecked(this.week_vegdietcheckbox5.booleanValue());
        this.veg_check6.setChecked(this.week_vegdietcheckbox6.booleanValue());
        this.veg_check7.setChecked(this.week_vegdietcheckbox7.booleanValue());
        this.veg_check8.setChecked(this.week_vegdietcheckbox8.booleanValue());
        this.veg_check9.setChecked(this.week_vegdietcheckbox9.booleanValue());
        this.veg_check10.setChecked(this.week_vegdietcheckbox10.booleanValue());
        this.veg_check11.setChecked(this.week_vegdietcheckbox11.booleanValue());
        this.veg_check12.setChecked(this.week_vegdietcheckbox12.booleanValue());
        this.veg_check13.setChecked(this.week_vegdietcheckbox13.booleanValue());
        this.veg_check14.setChecked(this.week_vegdietcheckbox14.booleanValue());
        this.veg_check15.setChecked(this.week_vegdietcheckbox15.booleanValue());
        this.veg_check16.setChecked(this.week_vegdietcheckbox16.booleanValue());
        this.veg_check17.setChecked(this.week_vegdietcheckbox17.booleanValue());
        this.veg_check18.setChecked(this.week_vegdietcheckbox18.booleanValue());
        this.veg_check19.setChecked(this.week_vegdietcheckbox19.booleanValue());
        this.veg_check20.setChecked(this.week_vegdietcheckbox20.booleanValue());
        this.week_stddietenabled.booleanValue();
        this.week_stddietenabled.booleanValue();
        this.mBtnStdDiet.setTextColor(getResources().getColor(R.color.colorAccent));
        this.mBtnVegDiet.setTextColor(getResources().getColor(R.color.black));
        this.scrollweekstddietfood.setVisibility(View.VISIBLE);
        this.scrollweekvegdietfood.setVisibility(View.INVISIBLE);
        this.prefsEditor.putBoolean(this.stddiet, true);
        this.prefsEditor.putBoolean(this.vegdiet, false);
        this.prefsEditor.apply();
        this.mBtnStdDiet.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                TabFragmentWeek tabFragmentWeek = TabFragmentWeek.this;
                tabFragmentWeek.week_stddietenabled = Boolean.valueOf(tabFragmentWeek.mSharedPreferences.getBoolean(TabFragmentWeek.this.stddiet, false));
                if (!TabFragmentWeek.this.week_stddietenabled.booleanValue()) {
                    TabFragmentWeek.this.mBtnStdDiet.setTextColor(TabFragmentWeek.this.getResources().getColor(R.color.colorAccent));
                    TabFragmentWeek.this.scrollweekstddietfood.setVisibility(View.VISIBLE);
                    TabFragmentWeek.this.mBtnVegDiet.setTextColor(TabFragmentWeek.this.getResources().getColor(R.color.black));
                    TabFragmentWeek.this.scrollweekvegdietfood.setVisibility(View.INVISIBLE);
                    TabFragmentWeek.this.prefsEditor.putBoolean(TabFragmentWeek.this.stddiet, true);
                    TabFragmentWeek.this.prefsEditor.putBoolean(TabFragmentWeek.this.vegdiet, false);
                }
                TabFragmentWeek.this.prefsEditor.commit();
            }
        });
        this.mBtnVegDiet.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                TabFragmentWeek tabFragmentWeek = TabFragmentWeek.this;
                tabFragmentWeek.week_vegdietenabled = Boolean.valueOf(tabFragmentWeek.mSharedPreferences.getBoolean(TabFragmentWeek.this.vegdiet, false));
                if (!TabFragmentWeek.this.week_vegdietenabled.booleanValue()) {
                    TabFragmentWeek.this.mBtnVegDiet.setTextColor(TabFragmentWeek.this.getResources().getColor(R.color.colorAccent));
                    TabFragmentWeek.this.scrollweekvegdietfood.setVisibility(View.VISIBLE);
                    TabFragmentWeek.this.mBtnStdDiet.setTextColor(TabFragmentWeek.this.getResources().getColor(R.color.black));
                    TabFragmentWeek.this.scrollweekstddietfood.setVisibility(View.INVISIBLE);
                    TabFragmentWeek.this.prefsEditor.putBoolean(TabFragmentWeek.this.vegdiet, true);
                    TabFragmentWeek.this.prefsEditor.putBoolean(TabFragmentWeek.this.stddiet, false);
                }
                TabFragmentWeek.this.prefsEditor.commit();
            }
        });
        setEventListeners();
        return inflate;
    }
}
