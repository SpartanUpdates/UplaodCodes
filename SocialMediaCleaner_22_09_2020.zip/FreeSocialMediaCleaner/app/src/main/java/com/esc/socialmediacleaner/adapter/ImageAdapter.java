package com.esc.socialmediacleaner.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.core.app.ShareCompat.IntentBuilder;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.activity.FileTabsScreen;
import com.esc.socialmediacleaner.datastructure.AllData;
import com.esc.socialmediacleaner.datastructure.FileDataWrapper;
import com.esc.socialmediacleaner.datastructure.MediaType;
import com.esc.socialmediacleaner.util.Util;
import com.esc.socialmediacleaner.views.ScaleImageView;

import java.io.File;
import java.util.ArrayList;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ViewHolder> {
    private Button btnDelete;
    private final TextView btnSelect;
    private AppCompatCheckBox checkBoxSelectAll;
    private final Context context;
    private final ArrayList<FileDataWrapper> dataList;
    private LayoutInflater mInflater;
    private TextView tv_all_selection;

    public interface ItemClickListener {
        void onItemClick(View view, int i);
    }

    public class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        ScaleImageView imageView;
        ImageView imgSelect;
        ImageView imgShare;
        TextView tvDetail;

        ViewHolder(View view) {
            super(view);
            this.imageView = (ScaleImageView) view.findViewById(R.id.imageView1);
            this.tvDetail = (TextView) view.findViewById(R.id.tv_filedetail);
            this.imgSelect = (ImageView) view.findViewById(R.id.img_select);
//            this.imgShare = (ImageView) view.findViewById(R.id.img_share);
        }
    }

    public ImageAdapter(Context context, int i, ArrayList<FileDataWrapper> arrayList, AppCompatCheckBox appCompatCheckBox) {
        this.mInflater = LayoutInflater.from(context);
        this.dataList = arrayList;
        this.context = context;
        this.checkBoxSelectAll = appCompatCheckBox;
        FileTabsScreen fileTabsScreen = (FileTabsScreen) context;
        this.btnDelete = (Button) fileTabsScreen.findViewById(R.id.btn_delete);
        this.tv_all_selection = (TextView) fileTabsScreen.findViewById(R.id.tv_all_selection);
        this.btnSelect = (TextView) fileTabsScreen.findViewById(R.id.tv_select_toggle);
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(this.mInflater.inflate(R.layout.row_staggered_demo, viewGroup, false));
    }

    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        final String str = getItem(i).path;
        ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load(str).centerCrop()).placeholder(getIcon(getItem(i).type.ordinal()))).into(viewHolder.imageView);
        final AllData allData = MyApplication.getInstance().allData;
        final int i2 = i;
        final ViewHolder viewHolder2 = viewHolder;
        final AllData allData2 = allData;
        final String str2 = str;
        viewHolder.imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (MyApplication.getInstance().isSelecting) {
                    if (ImageAdapter.this.getItem(i2).ischecked) {
                        viewHolder2.imgSelect.setVisibility(View.INVISIBLE);
                        allData2.unCheckItem((FileDataWrapper) ImageAdapter.this.dataList.get(i2));
                        view.setAlpha(1.0f);
                    } else {
                        viewHolder2.imgSelect.setVisibility(View.VISIBLE);
                        allData2.checkItem((FileDataWrapper) ImageAdapter.this.dataList.get(i2));
                        view.setAlpha(0.5f);
                    }
                    if (allData2.totSelectedItem == 0) {
                        ImageAdapter.this.btnDelete.setText(ImageAdapter.this.context.getString(R.string.str_delete));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            ImageAdapter.this.btnDelete.setBackground(ImageAdapter.this.context.getDrawable(R.drawable.btn_gray_round));
                        }
//                        ImageAdapter.this.btnDelete.setTextColor(Color.parseColor("#9a9a9a"));
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            ImageAdapter.this.btnDelete.setBackground(ImageAdapter.this.context.getDrawable(R.drawable.btn_bg_round));
                        }
//                        ImageAdapter.this.btnDelete.setTextColor(Color.parseColor("#000000"));
                        Button access$200 = ImageAdapter.this.btnDelete;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(ImageAdapter.this.context.getString(R.string.str_delete));
                        stringBuilder.append(" ");
                        stringBuilder.append(Util.convertBytes(allData2.totSelectedSize));
                        access$200.setText(stringBuilder.toString());
                    }
                    TextView access$300 = ImageAdapter.this.tv_all_selection;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(MyApplication.getInstance().allData.totSelectedItem);
                    stringBuilder2.append("/");
                    stringBuilder2.append(MyApplication.getInstance().allData.total_filetype);
                    access$300.setText(stringBuilder2.toString());
                    ImageAdapter.this.checkBoxSelectAll.setChecked(ImageAdapter.this.getCheck());
//                    ((FileTabsScreen) ImageAdapter.this.context).loadAD();
                    return;
                }
                ImageAdapter imageAdapter = ImageAdapter.this;
                imageAdapter.openFile(imageAdapter.context, str2);
            }
        });
       /* viewHolder.imgShare.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Uri uriForFile = FileProvider.getUriForFile(ImageAdapter.this.context, "social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.fileprovider", new File(str));
                ImageAdapter.this.context.startActivity(Intent.createChooser(IntentBuilder.from((FileTabsScreen) ImageAdapter.this.context).setStream(uriForFile).setType("text/html").getIntent().setAction("android.intent.action.SEND").setDataAndType(uriForFile, "image/*").addFlags(1), ImageAdapter.this.context.getString(R.string.share)));
            }
        });*/
        viewHolder.tvDetail.setText(Util.convertBytes(getItem(i).size));
        viewHolder.imageView.setOnLongClickListener(new OnLongClickListener() {
            public boolean onLongClick(View view) {
                if (MyApplication.getInstance().isSelecting) {
                    return true;
                }
                ImageAdapter.this.btnSelect.setText(ImageAdapter.this.context.getString(R.string.str_selecton));
                if (ImageAdapter.this.getItem(i).ischecked) {
                    viewHolder.imgSelect.setVisibility(View.INVISIBLE);
                    allData.unCheckItem((FileDataWrapper) ImageAdapter.this.dataList.get(i));
                    view.setAlpha(1.0f);
                } else {
                    viewHolder.imgSelect.setVisibility(View.VISIBLE);
                    allData.checkItem((FileDataWrapper) ImageAdapter.this.dataList.get(i));
                    view.setAlpha(0.5f);
                }
                if (allData.totSelectedItem == 0) {
                    ImageAdapter.this.btnDelete.setText(ImageAdapter.this.context.getString(R.string.str_delete));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        ImageAdapter.this.btnDelete.setBackground(ImageAdapter.this.context.getDrawable(R.drawable.btn_gray_round));
                    }
//                    ImageAdapter.this.btnDelete.setTextColor(Color.parseColor("#9a9a9a"));
                } else {
                    Button access$200 = ImageAdapter.this.btnDelete;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(ImageAdapter.this.context.getString(R.string.str_delete));
                    stringBuilder.append(" ");
                    stringBuilder.append(Util.convertBytes(allData.totSelectedSize));
                    access$200.setText(stringBuilder.toString());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        ImageAdapter.this.btnDelete.setBackground(ImageAdapter.this.context.getDrawable(R.drawable.btn_bg_round));
                    }
//                    ImageAdapter.this.btnDelete.setTextColor(Color.parseColor("#000000"));
                }
//                ((FileTabsScreen) ImageAdapter.this.context).loadAD();
                TextView access$300 = ImageAdapter.this.tv_all_selection;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(MyApplication.getInstance().allData.totSelectedItem);
                stringBuilder2.append("/");
                stringBuilder2.append(MyApplication.getInstance().allData.total_filetype);
                access$300.setText(stringBuilder2.toString());
                ImageAdapter.this.checkBoxSelectAll.setChecked(ImageAdapter.this.getCheck());
                MyApplication.getInstance().isSelecting = true;
                return true;
            }
        });
        if (getItem(i).ischecked) {
            viewHolder.imgSelect.setVisibility(View.VISIBLE);
            viewHolder.imageView.setAlpha(0.5f);
            return;
        }
        viewHolder.imgSelect.setVisibility(View.INVISIBLE);
        viewHolder.imageView.setAlpha(1.0f);
    }

    private boolean getCheck() {
        ArrayList arrayList = MyApplication.getInstance().allData.appList;
        boolean z = false;
        for (int i = 0; i < arrayList.size(); i++) {
            if (!((FileDataWrapper) arrayList.get(i)).ischecked) {
                break;
            }
        }
        z = true;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(z);
        Log.e("CHEEEE", stringBuilder.toString());
        return z;
    }

    public int getItemCount() {
        return this.dataList.size();
    }

    private int getIcon(int i) {
        if (i == MediaType.IMAGES.ordinal()) {
            return R.drawable.ic_selector_gallery;
        }
        if (i == MediaType.VIDEOS.ordinal()) {
            return R.drawable.ic_selector_video;
        }
        if (i == MediaType.AUDIOS.ordinal()) {
            return R.drawable.ic_selector_audio;
        }
        if (i == MediaType.DOCUMENTS.ordinal()) {
        }
        return R.drawable.ic_selector_folder;
    }

    public FileDataWrapper getItem(int i) {
        return (FileDataWrapper) this.dataList.get(i);
    }

    private void openFile(Context context, String str) {
        File file = new File(str);
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setFlags(335544320);
        intent.addFlags(1);
        Uri uriForFile = FileProvider.getUriForFile(context, "social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.fileprovider", file);
        String mimeType = Util.getMimeType(file.getAbsolutePath());
        if (mimeType != null) {
            intent.setDataAndType(uriForFile, mimeType);
        } else if (file.toString().contains(".doc") || file.toString().contains(".docx")) {
            intent.setDataAndType(uriForFile, "application/msword");
        } else if (file.toString().contains(".pdf")) {
            intent.setDataAndType(uriForFile, "application/pdf");
        } else if (file.toString().contains(".ppt") || file.toString().contains(".pptx")) {
            intent.setDataAndType(uriForFile, "application/vnd.ms-powerpoint");
        } else if (file.toString().contains(".xls") || file.toString().contains(".xlsx")) {
            intent.setDataAndType(uriForFile, "application/vnd.ms-excel");
        } else if (file.toString().contains(".zip") || file.toString().contains(".rar")) {
            intent.setDataAndType(uriForFile, "application/x-wav");
        } else if (file.toString().contains(".rtf")) {
            intent.setDataAndType(uriForFile, "application/rtf");
        } else if (file.toString().contains(".wav") || file.toString().contains(".mp3")) {
            intent.setDataAndType(uriForFile, "audio/x-wav");
        } else if (file.toString().contains(".gif")) {
            intent.setDataAndType(uriForFile, "image/gif");
        } else if (file.toString().contains(".jpg") || file.toString().contains(".jpeg") || file.toString().contains(".png")) {
            intent.setDataAndType(uriForFile, "image/jpeg");
        } else if (file.toString().contains(".txt")) {
            intent.setDataAndType(uriForFile, "text/plain");
        } else if (file.toString().contains(".3gp") || file.toString().contains(".mpg") || file.toString().contains(".mpeg") || file.toString().contains(".mpe") || file.toString().contains(".mp4") || file.toString().contains(".avi")) {
            intent.setDataAndType(uriForFile, "video/*");
        } else if (file.toString().contains(".apk")) {
            intent.setDataAndType(uriForFile, "application/vnd.android.package-archive");
        } else {
            intent.setDataAndType(uriForFile, "*/*");
        }
        try {
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
