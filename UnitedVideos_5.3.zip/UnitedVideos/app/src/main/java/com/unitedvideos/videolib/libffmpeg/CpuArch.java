package com.unitedvideos.videolib.libffmpeg;

import android.text.TextUtils;

public enum CpuArch
{
  x86("x86", 0, "0dd4dbad305ff197a1ea9e6158bd2081d229e70e"), 
  ARMv7("ARMv7", 1, "871888959ba2f063e18f56272d0d98ae01938ceb"), 
  NONE("NONE", 2, null);
  
  private String sha1;
  
  private CpuArch(String s, int n, String sha1) {
    this.sha1 = sha1;
  }
  
  static CpuArch fromString(String sha1) {
    if (!TextUtils.isEmpty(sha1)) {
      CpuArch[] values;
      int length = (values = values()).length; for (int i = 0; i < length; i++) {
        CpuArch cpuArch = values[i];
        if (sha1.equalsIgnoreCase(sha1)) {
          return cpuArch;
        }
      }
    }
    return NONE;
  }
  
  String getSha1() {
    return sha1;
  }
}
