package com.vidsoft.videostatusmaker.Utils.async;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.vidsoft.videostatusmaker.Activity.ActivityViewAlImages;
import com.vidsoft.videostatusmaker.Activity.MainActivity;
import com.vidsoft.videostatusmaker.App.MyApplication;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

import java.io.File;
import java.io.IOException;

import com.vidsoft.videostatusmaker.Activity.ActivityPreview;
import com.vidsoft.videostatusmaker.Utils.Utils;

public class MusicAdd extends AsyncTask<Void, Void, Boolean> {
    String strStartVideo;
    String strInputFile;
    Context context;
    String strOutputPath;
    String strDuration;
    String strVideoEnd;
    String strAudioPathName;
    String strAuduiStart;
    String strFolder_path;


    public MusicAdd(Context context, String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.context = context;
        this.strStartVideo = str;
        this.strDuration = str2;
        this.strInputFile = str3;
        this.strAuduiStart = str4;
        this.strAudioPathName = str5;
        this.strVideoEnd = str6;
        this.strOutputPath = str7;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStorageDirectory());
        stringBuilder.append("/");
        stringBuilder.append(context.getResources().getString(R.string.app_name));
        this.strFolder_path = stringBuilder.toString();
    }


    protected void onPreExecute() {
        super.onPreExecute();
    }

    protected Boolean doInBackground(Void... voidArr) {
        File file = new File(this.strOutputPath);
        if (file.exists()) {
            file.delete();
        }
        final String inputFile = this.strInputFile;
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(this.strAuduiStart);
        final String string = sb.toString();
        final String audioPathName = this.strAudioPathName;
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(this.strVideoEnd);
        final String string2 = sb2.toString();
        final String outputPath = this.strOutputPath;
        String[] SongAdd = new String[]{"-i", inputFile, "-ss", string, "-i", audioPathName, "-c:v", "copy", "-c:a", "aac", "-strict", "experimental", "-t", string2, outputPath};
        execFFmpegBinary(SongAdd);
        return Boolean.TRUE;
    }

    protected void onPostExecute(Boolean bool) {
        Log.e("TAG", "Final " + bool);
        super.onPostExecute(bool);
    }


    void deleteRecursive(File file) {
        if (file.isDirectory()) {
            for (File deleteRecursive : file.listFiles()) {
                deleteRecursive(deleteRecursive);
            }
        }
        file.delete();
    }

    public void execFFmpegBinary(final String[] command) {
        try {
            ActivityViewAlImages.ffmpeg.execute(command, new ExecuteBinaryResponseHandler() {
                @Override
                public void onFailure(String s) {
                    Log.e("TAG", "onFailure ffmpeg");
                }

                @Override
                public void onSuccess(String s) {
                    Log.e("TAG", "onSuccess ffmpeg");
                }

                @Override
                public void onProgress(String progress) {
                    Log.e("TAG", "Started command : ffmpeg " +progress);
                }

                @Override
                public void onStart() {

                }

                @Override
                public void onFinish() {
                    Log.e("TAG", "Finished command : ffmpeg");
                    Utils.video_url = strOutputPath;
                    Utils.complete = true;
                    ((ActivityPreview) context).setComplete(strOutputPath);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(strFolder_path);
                    stringBuilder.append("/");
                    stringBuilder.append(context.getString(R.string.temp_folder));
//                    deleteRecursive(new File(stringBuilder.toString()));
                }
            });
        } catch (FFmpegCommandAlreadyRunningException e) {
            e.printStackTrace();
        }
    }
}