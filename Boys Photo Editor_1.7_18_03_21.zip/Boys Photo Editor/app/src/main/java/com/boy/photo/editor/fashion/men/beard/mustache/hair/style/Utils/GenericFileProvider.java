package com.boy.photo.editor.fashion.men.beard.mustache.hair.style.Utils;

import androidx.core.content.FileProvider;
public class GenericFileProvider extends FileProvider {
}
