package com.kotlinz.vehiclemanager.myApp;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.gson.Gson;
import com.kotlinz.vehiclemanager.OpenAppAds.AppOpenAdManager;
import com.kotlinz.vehiclemanager.Preferance.PreferencesManager;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.famousperson.activity.FamousPersonListActivity;
import com.kotlinz.vehiclemanager.fuel.activity.FuelCityStateActivity;
import com.kotlinz.vehiclemanager.model.RToCredentialsModel;
import com.kotlinz.vehiclemanager.model.RToCredentialsModelResponse;
import com.kotlinz.vehiclemanager.retrofit.AppConstant;
import com.kotlinz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.kotlinz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.activity.RtoOfficeInfoActivity;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.activity.RtoPreperationActivity;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.activity.RtoQuestionActivity;
import com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity;
import com.kotlinz.vehiclemanager.utils.Utils;
import com.kotlinz.vehiclemanager.vehicledetails.loancalculator.LoanCalculatoractivity;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.activity.VehicleExpenseActivity;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.activity.VehicleExpenseCategory;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.activity.VehicleExpenseDetailAtivity;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.activity.VehicleMilageDetailActivity;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.activity.VehicleMileageActivity;
import static com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.activity.RtoQuestionActivity.circularView;
import static com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity.ResetData;
import static com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity.input1;
import static com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity.input2;
import static com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity.input3;
import static com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity.input4;
import static com.kotlinz.vehiclemanager.vehicledetails.loancalculator.LoanCalculatoractivity.resetData;

import java.util.ArrayList;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyApplication extends Application implements Application.ActivityLifecycleCallbacks, LifecycleObserver {

    private static MyApplication mInstance;
    private static Context context;


    private AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;

    public static Activity activity;
    public static InterstitialAd mInterstitialAd;
    public static int AdsId;
    public static int isShowAd = 0;

    public static String cityname;
    public static String statename;
    public static String contact;
    public static String address;

    private RtoDetailsInterface rtoCredentialsInterface;
    Gson gson = new Gson();
    public static ArrayList<RToCredentialsModel> rtoCredentialsModelResponses = new ArrayList<>();
    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        context = getApplicationContext();
        rtoCredentialsInterface = RtoDetailsApiClient.getRtoVehicleInformationCredentials().create(RtoDetailsInterface.class);
        SetDashboardsCredentialsInfo();
        this.registerActivityLifecycleCallbacks(this);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        appOpenAdManager = new AppOpenAdManager();
        interstitialAd();
    }

    public static Context getContext() {
        return context;
    }

    public static synchronized MyApplication getInstance() {
        return mInstance;
    }

    public void SetDashboardsCredentialsInfo() {
        if (Utils.checkConnectivity(getBaseContext(), false)) {
            if (PreferencesManager.INSTANCE.getPreferencesData(context, PreferencesManager.credentials).equalsIgnoreCase("")) {
                GetRtoCredentialsInfo();
            } else if (((new Date().getTime() - PreferencesManager.INSTANCE.getPreferencesResponseTime(context, PreferencesManager.credentialsResponseTime, 1588598205L))) >= PreferencesManager.INSTANCE.ApiUpdateTime) {
                GetRtoCredentialsInfo();
            } else if (!PreferencesManager.INSTANCE.getPreferencesData(context, PreferencesManager.credentials).equalsIgnoreCase("")) {
                SetOfflineData(PreferencesManager.INSTANCE.getPreferencesData(context, PreferencesManager.credentials));
            }
        } else {
            if (PreferencesManager.INSTANCE.getPreferencesData(context, PreferencesManager.credentials).equalsIgnoreCase("")) {
                Log.e("TAG", "No Internet And No Offline Data Found");
            } else {
                SetOfflineData(PreferencesManager.INSTANCE.getPreferencesData(context, PreferencesManager.credentials));
            }
        }
    }

    public void GetRtoCredentialsInfo() {
        Call<RToCredentialsModelResponse> call = rtoCredentialsInterface.getRtoCredentials(AppConstant.XAuthorization, AppConstant.AppPackageName);
        call.enqueue(new Callback<RToCredentialsModelResponse>() {
            @Override
            public void onResponse(Call<RToCredentialsModelResponse> call, Response<RToCredentialsModelResponse> response) {
                if (response.isSuccessful()) {
                    PreferencesManager.INSTANCE.setDataToOffline(context, new Gson().toJson(response.body()), PreferencesManager.credentials);
                    PreferencesManager.INSTANCE.SetApiCallResponseTime(context, new Date(), PreferencesManager.credentialsResponseTime);
                    SetOfflineData(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<RToCredentialsModelResponse> call, Throwable t) {
                Toast.makeText(context, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void SetOfflineData(String response) {
        RToCredentialsModelResponse rtoCredentialsModelResponse = gson.fromJson(response, RToCredentialsModelResponse.class);
        rtoCredentialsModelResponses = rtoCredentialsModelResponse.getResponse();
    }

    private void interstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, getResources().getString(R.string.InterstitialAd_id), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        Intent intent;
                                        requestNewInterstitial();
                                        switch (AdsId) {
                                            case 1:
                                                Intent intent1 = new Intent(activity, FuelCityStateActivity.class);
                                                activity.startActivity(intent1);
                                                break;
                                            case 2:
                                                activity.startActivity(new Intent(activity, RtoOwnerDetailActivity.class));
                                                break;
                                            case 3:
                                                activity.startActivity(new Intent(activity, RtoOfficeInfoActivity.class));
                                                break;
                                            case 4:
                                                activity.startActivity(new Intent(new Intent(activity, VehicleExpenseActivity.class)));
                                                break;
                                            case 5:
                                                activity.startActivity(new Intent(activity, VehicleMileageActivity.class));
                                                break;
                                            case 6:
                                                intent = new Intent(activity, FamousPersonListActivity.class);
                                                intent.putExtra("categoryname", "Mr.Perfect");
                                                activity.startActivity(intent);
                                                break;
                                            case 7:
                                                intent = new Intent(activity, FamousPersonListActivity.class);
                                                intent.putExtra("categoryname", "Dancers");
                                                activity.startActivity(intent);
                                                break;
                                            case 8:
                                                intent = new Intent(activity, FamousPersonListActivity.class);
                                                intent.putExtra("categoryname", "Singers");
                                                activity.startActivity(intent);
                                                break;
                                            case 9:
                                                intent = new Intent(activity, FamousPersonListActivity.class);
                                                intent.putExtra("categoryname", "Actors");
                                                activity.startActivity(intent);
                                                break;
                                            case 10:
                                                intent = new Intent(activity, FamousPersonListActivity.class);
                                                intent.putExtra("categoryname", "Politicians");
                                                activity.startActivity(intent);
                                                break;
                                            case 11:
                                                intent = new Intent(activity, FamousPersonListActivity.class);
                                                intent.putExtra("categoryname", "Sports Person");
                                                activity.startActivity(intent);
                                                break;
                                            case 12:
                                                intent = new Intent(activity, FamousPersonListActivity.class);
                                                intent.putExtra("categoryname", "Actresses");
                                                activity.startActivity(intent);
                                                break;
                                            case 13:
                                                activity.startActivity(new Intent(activity, LoanCalculatoractivity.class));
                                                break;
                                            case 14:
                                                goToNearPetrolPump();
                                                break;
                                            case 15:
                                                activity.startActivity(new Intent(activity, RtoQuestionActivity.class));
                                                break;
                                            case 16:
                                                activity.startActivity(new Intent(activity, RtoPreperationActivity.class));
                                                break;
                                            case 17:
                                                gotoNearAutoGas();
                                                break;
                                            case 18:
                                                gotoNearChargingStation();
                                                break;
                                          /*  case 19:
                                                activity.startActivity(new Intent(activity, HistoryTabLayoutActivity.class));
                                                break;*/
                                            case 20:
                                                activity.startActivity(new Intent(activity, MainActivity.class));
                                                activity.finish();
                                                break;
                                            case 21:
                                                Intent intentfule = new Intent(activity, MainActivity.class);
                                                intentfule.putExtra("cityname", cityname);
                                                intentfule.putExtra("statename", statename);
                                                intentfule.putExtra("data", "data");
                                                activity.startActivity(intentfule);
                                                break;
                                            case 22:
                                                Intent intentcall = new Intent(Intent.ACTION_DIAL);
                                                intentcall.setData(Uri.parse("tel:" + contact));
                                                activity.startActivity(intentcall);
                                                break;
                                            case 23:
                                                try {
                                                    Intent intentaddress = new Intent(Intent.ACTION_VIEW);
                                                    intentaddress.setData(Uri.parse("geo:0,0?q=" + address));
                                                    activity.startActivity(intentaddress);
                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                }
                                                break;
                                            case 24:
                                                activity.startActivity(new Intent(activity, RtoOfficeInfoActivity.class));
                                                activity.finish();
                                                break;
                                            case 25:
                                                input1.setEnabled(true);
                                                input2.setEnabled(true);
                                                input3.setEnabled(true);
                                                input4.setEnabled(true);
                                                ResetData();
                                                break;
                                            case 26:
                                                resetData();
                                                break;
                                            case 27:
                                                activity.startActivity(new Intent(activity, VehicleExpenseCategory.class));
                                                break;
                                            case 28:
                                                intent = new Intent(activity, VehicleExpenseDetailAtivity.class);
                                                intent.putExtra("categoryname", "Accessories & Tuning");
                                                intent.putExtra("categoryimg", R.drawable.ic_accessories_tuning);
                                                intent.putExtra("btn", "SAVE");
                                                activity.startActivity(intent);
                                                break;
                                            case 29:
                                                intent = new Intent(activity, VehicleExpenseDetailAtivity.class);
                                                intent.putExtra("categoryname", "Cleanlines & comfort");
                                                intent.putExtra("categoryimg", R.drawable.ic_cleanlines_comfort);
                                                intent.putExtra("btn", "SAVE");
                                                activity.startActivity(intent);
                                                break;
                                            case 30:
                                                intent = new Intent(activity, VehicleExpenseDetailAtivity.class);
                                                intent.putExtra("categoryname", "Car Fuel");
                                                intent.putExtra("categoryimg", R.drawable.ic_carfuel);
                                                intent.putExtra("btn", "SAVE");
                                                activity.startActivity(intent);
                                                break;
                                            case 31:
                                                intent = new Intent(activity, VehicleExpenseDetailAtivity.class);
                                                intent.putExtra("categoryname", "Maintenance");
                                                intent.putExtra("categoryimg", R.drawable.ic_maintenance);
                                                intent.putExtra("btn", "SAVE");
                                                activity.startActivity(intent);
                                                break;
                                            case 32:
                                                intent = new Intent(activity, VehicleExpenseDetailAtivity.class);
                                                intent.putExtra("categoryname", "Other expense");
                                                intent.putExtra("categoryimg", R.drawable.ic_otherexpense);
                                                intent.putExtra("btn", "SAVE");
                                                activity.startActivity(intent);
                                                break;
                                            case 33:
                                                activity.startActivity(new Intent(activity, VehicleExpenseActivity.class));
                                                activity.finish();
                                                break;
                                            case 34:
                                                activity.startActivity(new Intent(activity, VehicleExpenseCategory.class));
                                                break;
                                            case 35:
                                                activity.startActivity(new Intent(activity, VehicleExpenseCategory.class));
                                                activity.finish();
                                                break;
                                            case 36:
                                                circularView.stopTimer();
                                                RtoQuestionActivity.resetData();
                                                activity.startActivity(new Intent(activity, MainActivity.class));
                                                activity.finish();
                                                break;
                                            case 37:
                                                activity.startActivity(new Intent(activity, VehicleMileageActivity.class));
                                                activity.finish();
                                                break;
                                            case 38:
                                                activity.startActivity(new Intent(activity, VehicleMilageDetailActivity.class));
                                                activity.finish();
                                                break;
                                        }

                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    }
                });

    }

    private void requestNewInterstitial() {
        interstitialAd();
    }

    private void goToNearPetrolPump() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:0,0?q=" + "nearBy Petrol Pump"));
        try {
            activity.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void gotoNearAutoGas() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:0,0?q=" + "nearBy Cng Station"));
        try {
           activity.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void gotoNearChargingStation() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:0,0?q=" + "nearBy ev charging station"));
        try {
            activity.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /*AppOpenAds Start*/
    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    protected void onMoveToForeground() {
        appOpenAdManager.showAdIfAvailable(currentActivity);
    }


    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {

        if (!appOpenAdManager.isShowingAd) {
            currentActivity = activity;
        }
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {
    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
    }

    /**
     * Shows an app open ad.
     *
     * @param activity                 the activity that shows the app open ad
     * @param onShowAdCompleteListener the listener to be notified when an app open ad is complete
     */
    public void showAdIfAvailable(
            @NonNull Activity activity,
            @NonNull OnShowAdCompleteListener onShowAdCompleteListener) {
        // We wrap the showAdIfAvailable to enforce that other classes only interact with MyApplication
        // class.
        appOpenAdManager.showAdIfAvailable(activity, onShowAdCompleteListener);
    }

    /**
     * Interface definition for a callback to be invoked when an app open ad is complete
     * (i.e. dismissed or fails to show).
     */
    public interface OnShowAdCompleteListener {
        void onShowAdComplete();
    }

    /*AppOpenAds End*/

}
