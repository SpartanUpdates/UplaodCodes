package com.esc.dailyrandomfacts.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.esc.dailyrandomfacts.model.Pref;
import com.esc.dailyrandomfacts.util.Constants;
import com.esc.dailyrandomfacts.reminders.RemindersUtils;

public class AlarmBootReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
            String str = "1";
            if (Pref.getValue(context, Constants.IS_SLIDER_ON, str).equals(str)) {
                RemindersUtils.setAlarmOnTime(context);
            }
        }
    }
}
