package com.example.womenabsworkout.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.os.StrictMode.VmPolicy;
import android.preference.PreferenceManager;
import android.text.SpannableString;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.adapters.AllDayAdapter;
import com.example.womenabsworkout.adapters.WorkoutData;
import com.example.womenabsworkout.database.DatabaseHelper;
import com.example.womenabsworkout.database.DatabaseOperations;
import com.example.womenabsworkout.kprogresshud.KProgressHUD;
import com.example.womenabsworkout.listners.RecyclerItemClickListener;
import com.example.womenabsworkout.newscreen.Library;
import com.example.womenabsworkout.pref.EPreferences;
import com.example.womenabsworkout.receiver.NotificationReceiver;
import com.example.womenabsworkout.utils.AppUtils;
import com.example.womenabsworkout.utils.CommonMethods;
import com.example.womenabsworkout.utils.Constants;
import com.google.android.exoplayer2.extractor.ts.TsExtractor;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.navigation.NavigationView.OnNavigationItemSelectedListener;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.TimeZone;


public class MainActivity extends AppCompatActivity implements OnNavigationItemSelectedListener {
    Activity activity=MainActivity.this;
    public float Heightincms = 0.0f;
    public AllDayAdapter adapter;
    public ArrayList<String> arr = new ArrayList();
    public Context context;
    public DatabaseOperations databaseOperations;
    public TextView dayleft;
    public int daysCompletionConter = 0;
    public String exc_type;
    public RadioButton female;
    public EditText ft;
    public int height;
    public EditText inches;
    Intent intent;
    public RadioButton kg;
    public RadioButton lbs;
    public Library library;
    public SharedPreferences mSharedPreferences;
    MainActivity mainActivity2;
    public RadioButton male;
    public EditText months;
    public NavigationView nav_view;
    public TextView percentScore1;
    public Editor prefsEditor;
    public ProgressBar progressBar;
    EPreferences ePreferences;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public BroadcastReceiver progressReceiver = new BroadcastReceiver()
    {
        public void onReceive(Context context, Intent intent)
        {
            double doubleExtra = intent.getDoubleExtra(AppUtils.KEY_PROGRESS, 0.0d);
            try
            {
                ((WorkoutData) MainActivity.this.workoutDataList.get(MainActivity.this.workoutPosition)).setProgress((float) doubleExtra);
                MainActivity.this.total_progress = 0.0d;
                int i = 0;
                MainActivity.this.daysCompletionConter = 0;
                while (true) {
                    String str = "dev";
                    if (i < Constants.TOTAL_DAYS) {
                        double d = MainActivity.this.total_progress;
                        double progress = (double) ((WorkoutData) MainActivity.this.workoutDataList.get(i)).getProgress();
                        Double.isNaN(progress);
                        MainActivity.this.total_progress = (double) ((float) (d + ((progress * 4.348d) / 100.0d)));
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("totalprogressreceiver");
                        stringBuilder.append(MainActivity.this.total_progress);
                        Log.i(str, stringBuilder.toString());
                        if (((WorkoutData) MainActivity.this.workoutDataList.get(i)).getProgress() >= 99.0f) {
                            MainActivity.this.daysCompletionConter++;
                        }
                        i++;
                    } else {
                        MainActivity.this.mainActivity2.daysCompletionConter += MainActivity.this.daysCompletionConter / 3;
                        MainActivity.this.progressBar.setProgress((int) MainActivity.this.total_progress);
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("totalprogressreceiver1");
                        stringBuilder2.append(MainActivity.this.total_progress);
                        Log.i(str, stringBuilder2.toString());
                        TextView textView = MainActivity.this.percentScore1;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append((int) MainActivity.this.total_progress);
                        stringBuilder2.append("%");
                        textView.setText(stringBuilder2.toString());
                        textView = MainActivity.this.dayleft;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(Constants.TOTAL_DAYS - MainActivity.this.daysCompletionConter);
                        stringBuilder2.append(MainActivity.this.getString(R.string.dayleft));
                        textView.setText(stringBuilder2.toString());
                        MainActivity.this.adapter.notifyDataSetChanged();
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("");
                        stringBuilder3.append(doubleExtra);
                        Log.i("progress broadcast", stringBuilder3.toString());
                        return;
                    }
                }
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    };

    public RecyclerView recyclerView;
    public double total_progress = 0.0d;
    public EditText weight;
    public int width;
    public List<WorkoutData> workoutDataList;
    public int workoutPosition = -1;
    public EditText year;

    private float calculateHeightinCentimeter(float f)
    {
        return (float) ((int) (f * 100.0f));
    }

    public int calculateBMI(float f, float f2)
    {
        return (int) (f2 / (f * f));
    }

    public boolean isRestDay(int i)
    {
        return i == 4;
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        return false;
    }

    public float calculateMetres(float f, float f2)
    {
        double d = (double) (f + (f2 / 12.0f));
        Double.isNaN(d);
        f = (float) (d / 3.28d);
        this.Heightincms = calculateHeightinCentimeter(f);
        return f;
    }

    public float calculateweight(float f) {
        if (!this.lbs.isChecked()) {
            return f;
        }
        double d = (double) f;
        Double.isNaN(d);
        return (float) (d * 0.453592d);
    }

    public void excRepeatConfirmDialog(final int i) {
        final Dialog dialog = new Dialog(this.context, R.style.Theme_Dialog);
        try {
            dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        } catch (Exception e) {
            e.printStackTrace();
        }
        dialog.setContentView(R.layout.repeat_confirm_addialog_layout);
        dialog.getWindow().setLayout(-1, -2);
        dialog.setCancelable(true);
        ((TextView) dialog.findViewById(R.id.btnYes)).setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {
                try
                {
                    List allDaysProgress;
                    CharSequence stringBuilder;
                    dialog.dismiss();
                    String str = (String) MainActivity.this.arr.get(i);
                    if (MainActivity.this.workoutDataList != null) {
                        MainActivity.this.workoutDataList.clear();
                    }
                    if (MainActivity.this.exc_type.equalsIgnoreCase("beginner")) {
                        MainActivity.this.databaseOperations.insertExcDayData(str, 0.0f);
                        MainActivity.this.databaseOperations.insertExcCounter(str, 0);
                        allDaysProgress = MainActivity.this.databaseOperations.getAllDaysProgress();
                    } else {
                        MainActivity.this.databaseOperations.insertExcDayDataAdv(str, 0.0f);
                        MainActivity.this.databaseOperations.insertExcCounterAdv(str, 0);
                        allDaysProgress = MainActivity.this.databaseOperations.getAllDaysProgressAdv();
                    }
                    MainActivity.this.workoutDataList = allDaysProgress;
                    MainActivity.this.adapter = new AllDayAdapter(MainActivity.this.getApplicationContext(), MainActivity.this.workoutDataList);
                    MainActivity.this.recyclerView.getRecycledViewPool().clear();
                    MainActivity.this.recyclerView.setAdapter(MainActivity.this.adapter);
                    MainActivity.this.daysCompletionConter--;
                    TextView textView = MainActivity.this.dayleft;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(Constants.TOTAL_DAYS - MainActivity.this.daysCompletionConter);
                    stringBuilder2.append(MainActivity.this.getString(R.string.dayleft));
                    textView.setText(stringBuilder2.toString());
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("totalprogress");
                    stringBuilder3.append(MainActivity.this.total_progress);
                    Log.i("dev", stringBuilder3.toString());
                    if (MainActivity.this.daysCompletionConter > 0) {
                        MainActivity.this.progressBar.setProgress((int) (MainActivity.this.total_progress - 4.348d));
                        textView = MainActivity.this.percentScore1;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append((int) (MainActivity.this.total_progress - 4.348d));
                        stringBuilder2.append("%");
                        stringBuilder = stringBuilder2.toString();
                    } else {
                        MainActivity.this.progressBar.setProgress(0);
                        textView = MainActivity.this.percentScore1;
                        stringBuilder = "0%";
                    }
                    textView.setText(stringBuilder);
                    Intent intent = new Intent(MainActivity.this.getApplicationContext(), DayActivity.class);
                    intent.putExtra("day", str);
                    intent.putExtra("day_num", i);
                    MainActivity.this.library.saveInt("workoutPosition", Integer.valueOf(MainActivity.this.workoutPosition), MainActivity.this.getApplicationContext());
                    MainActivity.this.library.preData(str, i, ((WorkoutData) MainActivity.this.workoutDataList.get(i)).getProgress(), MainActivity.this.exc_type, MainActivity.this.getApplicationContext());
                    MainActivity.this.startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        ((TextView) dialog.findViewById(R.id.btnNo)).setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void reminderpopup()
    {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.reminder_popup);
        dialog.setCancelable(true);
        dialog.setOnCancelListener(new OnCancelListener()
        {
            public void onCancel(DialogInterface dialogInterface)
            {
                MainActivity.this.nav_view.getMenu().getItem(0).setChecked(true);
            }
        });
        dialog.getWindow().setLayout(-1, -2);
        final TimePicker timePicker = (TimePicker) dialog.findViewById(R.id.datePicker1reminder);
        ((Button) dialog.findViewById(R.id.set_reminder)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = ":";
                String str2 = "ReminderCheck";
                String str3 = "notification_minute";
                String str4 = "notification_hour";
                try
                {
                    int hour;
                    int minute;
                    dialog.dismiss();
                    if (VERSION.SDK_INT >= 23)
                    {
                        hour = timePicker.getHour();
                        minute = timePicker.getMinute();
                    } else
                    {
                        hour = timePicker.getCurrentHour().intValue();
                        minute = timePicker.getCurrentMinute().intValue();
                    }

                    MainActivity.this.prefsEditor.putBoolean("user_selection", true);
                    MainActivity.this.prefsEditor.putInt(str4, hour);
                    MainActivity.this.prefsEditor.putInt(str3, minute);
                    Log.d(str2, "Reminder set in Main page");
                    MainActivity.this.prefsEditor.apply();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Reminder set in ");
                    stringBuilder.append(MainActivity.this.mSharedPreferences.getInt(str4, hour));
                    stringBuilder.append(str);
                    stringBuilder.append(MainActivity.this.mSharedPreferences.getInt(str3, minute));
                    stringBuilder.append(str);
                    stringBuilder.append(0);
                    Log.d(str2, stringBuilder.toString());
                    MainActivity.this.setAlarm(MainActivity.this.mSharedPreferences.getInt(str4, hour), MainActivity.this.mSharedPreferences.getInt(str3, minute), 0);
                    MainActivity.this.nav_view.getMenu().getItem(0).setChecked(true);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        });

        dialog.show();
    }

    public void restartDialog()
    {
        final Dialog dialog = new Dialog(this, R.style.Theme_Dialog);
        try
        {
            dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        dialog.setContentView(R.layout.restart_confirm_addialog_layout);
        dialog.getWindow().setLayout(-1, -2);
        dialog.setCancelable(true);
        ((TextView) dialog.findViewById(R.id.btnYes)).setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {
                dialog.dismiss();


                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    MainActivity.this.restartExcercise();
                }
            }
        });
        ((TextView) dialog.findViewById(R.id.btnNo)).setOnClickListener(new OnClickListener() {
            public void onClick(View view)
            {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void shareApp() {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("start workout in your Home. : https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        intent.setType("text/plain");
        startActivity(intent);
    }

    public void b() {
        this.mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        final Dialog dialog = new Dialog(this, R.style.AppTheme);
        dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        dialog.getWindow().setLayout(-1, -1);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setFlags(1024, 1024);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setContentView(R.layout.activity_customdialog_heightcheckout);
        dialog.setCancelable(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.setCancelable(true);
        this.lbs = (RadioButton) dialog.findViewById(R.id.lbs);
        this.kg = (RadioButton) dialog.findViewById(R.id.kg);
        this.male = (RadioButton) dialog.findViewById(R.id.male);
        this.female = (RadioButton) dialog.findViewById(R.id.female);
        this.ft = (EditText) dialog.findViewById(R.id.feet);
        this.inches = (EditText) dialog.findViewById(R.id.inches);
        this.year = (EditText) dialog.findViewById(R.id.year);
        this.months = (EditText) dialog.findViewById(R.id.month);
        this.weight = (EditText) dialog.findViewById(R.id.weight);
        ((Button) dialog.findViewById(R.id.calculate)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                int i;
                String str = "";
                if (MainActivity.this.year.getText().toString().equals(str) || MainActivity.this.months.getText().toString().equals(str) || MainActivity.this.ft.getText().toString().equals(str) || MainActivity.this.inches.getText().toString().equals(str) || MainActivity.this.weight.getText().toString().equals(str)) {
                    i = R.string.fields;
                } else if (MainActivity.this.year.getText().toString().matches(str) || Integer.parseInt(MainActivity.this.year.getText().toString()) < 5 || Integer.parseInt(MainActivity.this.year.getText().toString()) > 100) {
                    i = R.string.agerange;
                } else if (MainActivity.this.months.getText().toString().matches(str) || Integer.parseInt(MainActivity.this.months.getText().toString()) < 0 || Integer.parseInt(MainActivity.this.months.getText().toString()) > 12) {
                    i = R.string.monthrange;
                } else if (MainActivity.this.ft.getText().toString().matches(str) || Integer.parseInt(MainActivity.this.ft.getText().toString()) < 2 || Integer.parseInt(MainActivity.this.ft.getText().toString()) > 7) {
                    i = R.string.feetrange;
                } else if (MainActivity.this.inches.getText().toString().matches(str) || Integer.parseInt(MainActivity.this.inches.getText().toString()) < 0 || Integer.parseInt(MainActivity.this.inches.getText().toString()) > 12) {
                    i = R.string.inchrange;
                } else {
                    String str2 = "HEIGHT";
                    String str3 = "BMI";
                    MainActivity mainActivity;
                    float calculateMetres;
                    MainActivity mainActivity2;
                    if (MainActivity.this.kg.isChecked()) {
                        if (!MainActivity.this.weight.getText().toString().matches(str) && Integer.parseInt(MainActivity.this.weight.getText().toString()) >= 5 && Integer.parseInt(MainActivity.this.weight.getText().toString()) <= TsExtractor.TS_STREAM_TYPE_HDMV_DTS) {
                            mainActivity = MainActivity.this;
                            calculateMetres = mainActivity.calculateMetres(Float.parseFloat(mainActivity.ft.getText().toString()), Float.parseFloat(MainActivity.this.inches.getText().toString()));
                            mainActivity2 = MainActivity.this;
                            int calculateBMI = mainActivity2.calculateBMI(calculateMetres, mainActivity2.calculateweight(Float.parseFloat(mainActivity2.weight.getText().toString())));
                            mainActivity2 = MainActivity.this;
                            mainActivity2.prefsEditor = mainActivity2.mSharedPreferences.edit();
                            MainActivity.this.prefsEditor.putFloat(str3, (float) calculateBMI);
                            MainActivity.this.prefsEditor.putFloat(str2, MainActivity.this.Heightincms);
                            MainActivity.this.prefsEditor.apply();
                            MainActivity.this.intent = new Intent(MainActivity.this.mainActivity2, CalculateActivity.class);
                        }
                    } else if (!MainActivity.this.lbs.isChecked()) {
                        return;
                    } else {
                        if (!MainActivity.this.weight.getText().toString().matches(str) && Integer.parseInt(MainActivity.this.weight.getText().toString()) >= 11 && Integer.parseInt(MainActivity.this.weight.getText().toString()) <= 286) {
                            mainActivity = MainActivity.this;
                            calculateMetres = mainActivity.calculateMetres(Float.parseFloat(mainActivity.ft.getText().toString()), Float.parseFloat(MainActivity.this.inches.getText().toString()));
                            mainActivity2 = MainActivity.this;
                            calculateMetres = (float) mainActivity2.calculateBMI(calculateMetres, mainActivity2.calculateweight(Float.parseFloat(mainActivity2.weight.getText().toString())));
                            mainActivity2 = MainActivity.this;
                            mainActivity2.prefsEditor = mainActivity2.mSharedPreferences.edit();
                            MainActivity.this.prefsEditor.putFloat(str3, calculateMetres);
                            MainActivity.this.prefsEditor.putFloat(str2, MainActivity.this.Heightincms);
                            MainActivity.this.prefsEditor.apply();
                            MainActivity.this.intent = new Intent(MainActivity.this.mainActivity2, CalculateActivity.class);
                        }
                    }
                    MainActivity.this.mainActivity2.startActivity(MainActivity.this.intent.putExtra(str3, MainActivity.this.mSharedPreferences.getFloat(str3, 0.0f)).putExtra(str2, MainActivity.this.mSharedPreferences.getFloat(str2, 0.0f)));
                    dialog.dismiss();
                    return;
                }
                Toast.makeText(MainActivity.this.getApplicationContext(), i, Toast.LENGTH_SHORT).show();
            }
        });
        this.nav_view.getMenu().getItem(0).setChecked(true);
        dialog.show();
    }

    @SuppressLint("NewApi")
    public void onCreate(Bundle bundle) {
        Editor edit;
        List allDaysProgress;
        int i;
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        this.context = this;
        this.library = new Library(this.context);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        this.mSharedPreferences = defaultSharedPreferences;
        this.library.updateLocale(defaultSharedPreferences.getString("languageToLoad", ""));
        this.prefsEditor = this.mSharedPreferences.edit();
        String str = "beginner";
        this.exc_type = this.mSharedPreferences.getString("yoga_type", str);
        setContentView(R.layout.activity_main);
        ePreferences= EPreferences.getInstance((Context)this);
        interstitialAd();

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.width = displayMetrics.widthPixels;
        this.height = displayMetrics.heightPixels;
        this.percentScore1 = (TextView) findViewById(R.id.percentScore);
        this.dayleft = (TextView) findViewById(R.id.daysLeft);
        ImageView imageView = (ImageView) findViewById(R.id.b);
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler);
        if (!this.exc_type.equalsIgnoreCase(str)) {
            imageView.setBackground(getResources().getDrawable(R.mipmap.banner_111));
        }
        this.databaseOperations = new DatabaseOperations(this);
        String str2 = "thirtyday";
        boolean z = this.mSharedPreferences.getBoolean(str2, false);
        String str3 = "daysInserted";
        if (!this.mSharedPreferences.getBoolean(str3, false) && this.databaseOperations.CheckDBEmpty(DatabaseHelper.EXC_DAY_TABLE) == 0) {
            this.databaseOperations.insertExcALLDayData();
            edit = this.mSharedPreferences.edit();
            edit.putBoolean(str3, true);
            edit.apply();
        }
        List list = this.workoutDataList;
        if (list != null) {
            list.clear();
        }
        if (this.exc_type.equalsIgnoreCase(str)) {
            allDaysProgress = this.databaseOperations.getAllDaysProgress();
        } else {
            if (!this.databaseOperations.tableExists(DatabaseHelper.EXC_DAY_TABLE_ADVANCED)) {
                this.databaseOperations.createAdvTable();
            }
            if (this.databaseOperations.CheckDBEmpty(DatabaseHelper.EXC_DAY_TABLE_ADVANCED) == 0) {
                this.databaseOperations.insertExcALLDayDataAdv();
                Editor edit2 = this.mSharedPreferences.edit();
                edit2.putBoolean(str3, true);
                edit2.apply();
            }
            allDaysProgress = this.databaseOperations.getAllDaysProgressAdv();
        }



        ((ImageView) findViewById(R.id.back_arrow)).setOnClickListener(new OnClickListener()
        {
            public void onClick(View view) {
                MainActivity.this.onBackPressed();
            }
        });
        ((ImageView) findViewById(R.id.reset_process)).setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {
                MainActivity.this.restartDialog();
            }
        });
        this.workoutDataList = allDaysProgress;
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progress);
        this.progressBar = progressBar;
        progressBar.setProgressDrawable(getResources().getDrawable(R.drawable.launch_progressbar));
        for (i = 0; i < Constants.TOTAL_DAYS; i++)
        {
            double d = this.total_progress;
            double progress = (double) ((WorkoutData) this.workoutDataList.get(i)).getProgress();
            Double.isNaN(progress);
            this.total_progress = (double) ((float) (d + ((progress * 4.348d) / 100.0d)));
            if (((WorkoutData) this.workoutDataList.get(i)).getProgress() >= 99.0f)
            {
                this.daysCompletionConter++;
            }
        }
        i = this.daysCompletionConter;
        this.daysCompletionConter = i + (i / 3);
        this.progressBar.setProgress((int) this.total_progress);
        TextView textView = this.percentScore1;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((int) this.total_progress);
        stringBuilder.append("%");
        textView.setText(stringBuilder.toString());
        textView = this.dayleft;
        stringBuilder = new StringBuilder();
        stringBuilder.append(Constants.TOTAL_DAYS - this.daysCompletionConter);
        stringBuilder.append(getString(R.string.dayleft));
        textView.setText(stringBuilder.toString());
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        this.adapter = new AllDayAdapter(this, this.workoutDataList);
        this.recyclerView.getRecycledViewPool().clear();

        for (int i2 = 1; i2 <= Constants.TOTAL_DAYS; i2++)
        {
            ArrayList arrayList = this.arr;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Day ");
            stringBuilder2.append(i2);
            arrayList.add(stringBuilder2.toString());
        }

        if (z)
        {
            Editor edit3 = this.mSharedPreferences.edit();
            edit3.putBoolean(str2, false);
            edit3.apply();
            restartExcercise();
            this.daysCompletionConter = 0;
        }

        this.recyclerView.setAdapter(this.adapter);
        this.recyclerView.setLayoutManager(linearLayoutManager);

        this.recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(this, new RecyclerItemClickListener.onItemClickListener() {
            public void OnItem(View view, int i)
            {
                Intent intent;
                MainActivity.this.workoutPosition = i;
                if ((MainActivity.this.workoutPosition + 1) % 4 == 0) {
                    intent = new Intent(MainActivity.this.getApplicationContext(), RestDayActivity.class);
                } else if (((WorkoutData) MainActivity.this.workoutDataList.get(i)).getProgress() < 99.0f) {
                    intent = new Intent(MainActivity.this.getApplicationContext(), DayActivity.class);
                    intent.putExtra("day", (String) MainActivity.this.arr.get(i));
                    intent.putExtra("day_num", i);
                    intent.putExtra(NotificationCompat.CATEGORY_PROGRESS, ((WorkoutData) MainActivity.this.workoutDataList.get(i)).getProgress());
                } else {
                    MainActivity.this.excRepeatConfirmDialog(i);
                    return;
                }
                MainActivity.this.startActivity(intent);
            }
        }));

        DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        this.nav_view = navigationView;
        navigationView.setNavigationItemSelectedListener(this);
        this.nav_view.getMenu().getItem(0).setChecked(true);
        final Menu menu = this.nav_view.getMenu();
        this.nav_view.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener()
        {
            public void onGlobalLayout()
            {
                ArrayList arrayList = new ArrayList();
                MainActivity.this.nav_view.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                for (int i = 0; i < menu.size(); i++) {
                    if (i == 0) {
                        menu.getItem(i).setTitle(new SpannableString(menu.getItem(i).getTitle()));
                    }
                    MainActivity.this.nav_view.findViewsWithText(arrayList, menu.getItem(i).getTitle(), View.FIND_VIEWS_WITH_TEXT);
                }
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    ((TextView) it.next()).setTypeface(Typeface.createFromAsset(MainActivity.this.getAssets(), "fonts/roboto_medium.ttf"), Typeface.NORMAL);
                }
            }
        });

        if (VERSION.SDK_INT >= 23 && VERSION.SDK_INT >= 26)
        {
            ((NotificationManager) Objects.requireNonNull((NotificationManager) getSystemService(NotificationManager.class))).createNotificationChannel(new NotificationChannel(getString(R.string.default_notification_channel_id), getString(R.string.default_notification_channel_name), NotificationManager.IMPORTANCE_HIGH));
        }

        if (getIntent().getExtras() != null)
        {
            for (String str4 : getIntent().getExtras().keySet()) {
                Object obj = getIntent().getExtras().get(str4);
                stringBuilder = new StringBuilder();
                stringBuilder.append("Key: ");
                stringBuilder.append(str4);
                stringBuilder.append(" Value: ");
                stringBuilder.append(obj);
                Log.d("selfie camera", stringBuilder.toString());
            }
        }

        StrictMode.setVmPolicy(new VmPolicy.Builder().build());
        Calendar instance = Calendar.getInstance(TimeZone.getDefault());
        String str4 = "%02d";
        String.format(str4, new Object[]{Integer.valueOf(instance.get(11))});
        String str5 = ":";
        String.format(str4, new Object[]{Integer.valueOf(instance.get(12))});
        String.format(str4, new Object[]{Integer.valueOf(instance.get(13))});
        String.format("%03d", new Object[]{Integer.valueOf(instance.get(14))});

        SharedPreferences defaultSharedPreferences2 = PreferenceManager.getDefaultSharedPreferences(this);
        if (!Boolean.valueOf(defaultSharedPreferences2.getBoolean("user_selection", false)).booleanValue())
        {
            str4 = "ReminderCheck";
            Log.d(str4, "Reminder set in Completion page");
            edit = defaultSharedPreferences2.edit();
            String str6 = "notification_hour";
            edit.putInt(str6, instance.get(11));
            String str7 = "notification_minute";
            edit.putInt(str7, instance.get(12));
            edit.apply();
            new CommonMethods(this.context).setAlarm(defaultSharedPreferences2.getInt(str6, instance.get(11)), defaultSharedPreferences2.getInt(str7, instance.get(12)), 0);
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Reminder set in ");
            stringBuilder3.append(defaultSharedPreferences2.getInt(str6, instance.get(11)));
            stringBuilder3.append(str5);
            stringBuilder3.append(defaultSharedPreferences2.getInt(str7, instance.get(12)));
            stringBuilder3.append(str5);
            stringBuilder3.append(0);
            Log.d(str4, stringBuilder3.toString());
        }
        registerReceiver(this.progressReceiver, new IntentFilter(AppUtils.WORKOUT_BROADCAST_FILTER));
    }

    public boolean onNavigationItemSelected(MenuItem menuItem) {
        String str = "android.intent.action.VIEW";
        int itemId = menuItem.getItemId();
        if (!(itemId == R.id.trainingplan || itemId == R.id.meals_plan)) {
            if (itemId == R.id.reminder) {
                reminderpopup();
            } else if (itemId == R.id.restartprogress) {
                restartDialog();
            } else if (itemId == R.id.calculate)
            {
                b();
            } else if (itemId == R.id.share) {
                shareApp();
            } else if (itemId == R.id.rateus) {
                try {
                    startActivity(new Intent(str, Uri.parse("market://details?id="+context.getPackageName())));
                } catch (ActivityNotFoundException unused) {
                    startActivity(new Intent(str, Uri.parse("http://play.google.com/store/apps/details?id="+context.getPackageName())));
                }
            }
        }
        ((DrawerLayout) findViewById(R.id.drawer_layout)).closeDrawer((int) GravityCompat.START);
        return true;
    }

    public void onResume() {
        this.nav_view.getMenu().getItem(0).setChecked(true);
        super.onResume();
    }

    public void onStart() {
        super.onStart();
    }

    public void restartExcercise() {
        Editor edit = this.mSharedPreferences.edit();
        String str = "daysInserted";
        edit.putBoolean(str, false);
        edit.apply();
        for (int i = 0; i < 30; i++) {
            String str2 = (String) this.arr.get(i);
            this.databaseOperations.insertExcDayData(str2, 0.0f);
            this.databaseOperations.insertExcCounter(str2, 0);
        }
        edit.putBoolean(str, true);
        edit.apply();
        List list = this.workoutDataList;
        if (list != null) {
            list.clear();
        }
        this.workoutDataList = this.exc_type.equalsIgnoreCase("beginner") ? this.databaseOperations.getAllDaysProgress() : this.databaseOperations.getAllDaysProgressAdv();
        this.adapter = new AllDayAdapter(this, this.workoutDataList);
        this.recyclerView.getRecycledViewPool().clear();
        this.recyclerView.setAdapter(this.adapter);
        this.progressBar.setProgress(0);
        this.percentScore1.setText("0%");
        TextView textView = this.dayleft;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constants.TOTAL_DAYS);
        stringBuilder.append(" Days left");
        textView.setText(stringBuilder.toString());
    }

    @SuppressLint("WrongConstant")
    public void setAlarm(int i, int i2, int i3)
    {
        Calendar instance = Calendar.getInstance();
        instance.set(11, i);
        instance.set(12, i2);
        instance.set(13, i3);
        ((AlarmManager) getSystemService(NotificationCompat.CATEGORY_ALARM)).setRepeating(AlarmManager.RTC_WAKEUP, instance.getTimeInMillis(), 5000, PendingIntent.getBroadcast(getApplicationContext(), 100, new Intent(getApplicationContext(), NotificationReceiver.class), PendingIntent.FLAG_CANCEL_CURRENT));
    }

   /* public void onBackPressed()
    {
        DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        if (drawerLayout.isDrawerOpen((int) GravityCompat.START)) {
            drawerLayout.closeDrawer((int) GravityCompat.START);
        }
       // startActivity(new Intent(this, After_Main_Activity.class));
        finish();
    }*/

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        MainActivity.this.restartExcercise();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private UnifiedNativeAd nativeAd;

    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(MainActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_Native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();

                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = (ImageView) dialog.findViewById(R.id.ivStar1);
        ivStar2 = (ImageView) dialog.findViewById(R.id.ivStar2);
        ivStar3 = (ImageView) dialog.findViewById(R.id.ivStar3);
        ivStar4 = (ImageView) dialog.findViewById(R.id.ivStar4);
        ivStar5 = (ImageView) dialog.findViewById(R.id.ivStar5);

        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
               /* startActivity(new Intent(After_Main_Activity.this, BackActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));*/
                finish();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        Log.e("ePreferences",ePreferences.toString());
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_Native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);

            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
                //  startActivity(new Intent(After_Main_Activity.this, BackActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));

            }
        });
        dialog.show();
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawerLayout.isDrawerOpen((int) GravityCompat.START)) {
            drawerLayout.closeDrawer((int) GravityCompat.START);
        }

        if (ePreferences.getBoolean("pref_key_rate", false))
        {
            ExitDialog();
        }
        else
        {
            RateDialog();
        }
    }

}
