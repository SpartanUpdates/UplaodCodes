package com.mbit.VideoMaker.Extra;

import android.content.Context;
import android.content.SharedPreferences;

public class d {
    private SharedPreferences a;

    public d(final Context context, final String s) {
        this.a = context.getSharedPreferences(s, 0);
    }

    public static d a(final Context context) {
        try {
            return new d(context, "slideshow_pref");
        } catch (Exception ex) {
            return null;
        }
    }

    public final int a(final String s, final int n) {
        return this.a.getInt(s, n);
    }

    public final String a(final String s, final String s2) {
        return this.a.getString(s, s2);
    }

    public final boolean a(final String s, final boolean b) {
        return this.a.getBoolean(s, b);
    }

    public final int b(final String s, final int n) {
        final SharedPreferences.Editor edit = this.a.edit();
        edit.putInt(s, n);
        edit.apply();
        return 0;
    }

    public final int b(final String s, final boolean b) {
        final SharedPreferences.Editor edit = this.a.edit();
        edit.putBoolean(s, b);
        edit.apply();
        return 0;
    }

    public final void b(final String s, final String s2) {
        final SharedPreferences.Editor edit = this.a.edit();
        edit.putString(s, s2);
        edit.apply();
    }

    public final int c(final String s, final String s2) {
        final SharedPreferences.Editor edit = this.a.edit();
        edit.putString(s, s2);
        edit.apply();
        return 0;
    }

}
