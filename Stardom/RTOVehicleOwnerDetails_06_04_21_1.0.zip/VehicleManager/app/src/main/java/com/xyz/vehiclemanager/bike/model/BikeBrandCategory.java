package com.xyz.vehiclemanager.bike.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class BikeBrandCategory
{
    @SerializedName("data")
    public ArrayList<BikeBrandCategory> data = null;
    @SerializedName("id")
    public String id;
    @SerializedName("brandId")
    public String brandId;
    @SerializedName("brandName")
    public String brandName;
    @SerializedName("bikeModelName")
    public String bikeModelName;
    @SerializedName("bikeModelSlug")
    public String bikeModelSlug;
    @SerializedName("exShowroomPrice")
    public String exShowroomPrice;
    @SerializedName("imageUrl")
    public String imageUrl;
    @SerializedName("isDiscontinued")
    public String isDiscontinued;
    @SerializedName("isBS6Compliant")
    public String isBS6Compliant;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBrandId() {
        return brandId;
    }

    public void setBrandId(String brandId) {
        this.brandId = brandId;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getBikeModelName() {
        return bikeModelName;
    }

    public void setBikeModelName(String bikeModelName) {
        this.bikeModelName = bikeModelName;
    }

    public String getBikeModelSlug() {
        return bikeModelSlug;
    }

    public void setBikeModelSlug(String bikeModelSlug) {
        this.bikeModelSlug = bikeModelSlug;
    }

    public String getExShowroomPrice() {
        return exShowroomPrice;
    }

    public void setExShowroomPrice(String exShowroomPrice) {
        this.exShowroomPrice = exShowroomPrice;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getIsDiscontinued() {
        return isDiscontinued;
    }

    public void setIsDiscontinued(String isDiscontinued) {
        this.isDiscontinued = isDiscontinued;
    }

    public String getIsBS6Compliant() {
        return isBS6Compliant;
    }

    public void setIsBS6Compliant(String isBS6Compliant) {
        this.isBS6Compliant = isBS6Compliant;
    }

    public ArrayList<BikeBrandCategory> getData() {
        return data;
    }

    public void setData(ArrayList<BikeBrandCategory> data) {
        this.data = data;
    }
}
