package com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.Room;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.model.Mileage;
import java.util.List;
@androidx.room.Dao
public interface MileageDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertMileageData(Mileage mileage);

    @Query("select * from Mileage")
    List<Mileage> getMileageData();

    @Query("Delete from Mileage where id=:id")
    void deleteMileage(int id);

}
