package com.wavymusic.RetrofitApiCall;

public class AppConstant {
    /*Wavy Music Start*/
    public static String BASEURL = "http://beatsadmin.trendinganimations.com/public/api/";
    public static String Token = "aciativtyksdfhal5215ajal";
    public static String ApplicationId = "30";
    /*Wavy Music End*/

    /*United Viedeo Start*/

    public static String BASEURL_UV = "http://uvadmin.trendinganimations.com/public/api/";

    /*United Viedeo End*/

    /*Wavy Download Url*/
    public static String ThemeThumburlWavy = "";
    public static String SmallThemeThumbrlWavy = "";
    public static String SoundUrlWavy = "";

    /*Uv Download Url*/
    public static String ThemeThumbUv = "";
    public static String AnimUrlUv = "";
    public static String SoundUrlUv = "";


    /*Partical Url*/
    public static String DefaultCategoryId = "66,68,67,70,69,";
    public static long ApiUpdateTime = 1800000L;
}
