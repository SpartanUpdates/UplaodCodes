package com.esc.socialmediacleaner.activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.drawable.Animatable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.kprogresshud.KProgressHUD;
import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.util.SavedData;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import javax.xml.transform.Result;

public class ResultScreen extends ShareAppScreen implements OnClickListener {
    private Activity activity = ResultScreen.this;
    private long lastClickedTime = 0;
    private ImageView iv_back;
    private FrameLayout adContainerView;
    private InterstitialAd interstitial;
    private AdView adView;
    private AdSize adSize;
    private int id;
    private KProgressHUD hud;

    public int getFacePosition() {
        return super.getFacePosition();
    }

    public void hideKeyboard() {
        super.hideKeyboard();
    }

    public boolean isEmailValid(String str) {
        return super.isEmailValid(str);
    }

    public void setFacePosition(int i) {
        super.setFacePosition(i);
    }

    public void shareApp() {
        super.shareApp();
    }


    public void toast(String str) {
        super.toast(str);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_result_screen);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle((CharSequence) "");
        track("RESULT_VISIT");

        MyApplication.getInstance().allData.dataDeleted = true;
        iv_back = findViewById(R.id.iv_back);
        TextView textView = (TextView) findViewById(R.id.tv_resmsg);
        TextView textView2 = (TextView) findViewById(R.id.tv_title);
        findViewById(R.id.iv_rate).setOnClickListener(this);
        findViewById(R.id.iv_share).setOnClickListener(this);
        String stringExtra = getIntent().getStringExtra("MESSAGE");
        String stringExtra2 = getIntent().getStringExtra("TITLE");
        textView.setText(stringExtra);
        textView2.setText(stringExtra2);
        ((Animatable) ((ImageView) findViewById(R.id.img)).getDrawable()).start();
        iv_back.setOnClickListener(this);
        loadAd();
        BannerAds();
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_rate:
                try {
                    startActivity(new Intent(
                            "android.intent.action.VIEW",
                            Uri.parse(getResources().getString(R.string.rate_us)
                                    + getPackageName())));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(ResultScreen.this, "You don't have Google Play installed",
                            Toast.LENGTH_SHORT).show();
                }
                return;
            case R.id.iv_share:
                if (!doubleClicked()) {
                    shareApp();
                    break;
                }
                return;

            case R.id.iv_back:
                if (interstitial !=null && interstitial.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                id = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);;
                }else {
                    onBackPressed();
                }
                break;
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    public boolean doubleClicked() {
        long elapsedRealtime = SystemClock.elapsedRealtime() - this.lastClickedTime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("diff ");
        stringBuilder.append(elapsedRealtime);
        Log.e("TTTTTTTTT", stringBuilder.toString());
        this.lastClickedTime = SystemClock.elapsedRealtime();
        return elapsedRealtime < 600;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        finish();
        return super.onOptionsItemSelected(menuItem);
    }

    private void loadAd()
    {
        //InterstitialAd
        interstitial = new InterstitialAd(ResultScreen.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {

                switch (id)
                {
                    case 100:
                        onBackPressed();
                        break;

                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(activity);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
