package com.kotlinz.videoeditor.Fragment;

import static com.kotlinz.videoeditor.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoeditor.Adapter.VideoSaveAdp;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.Utils.Constant;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;

import org.apache.commons.io.comparator.LastModifiedFileComparator;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public class MyCreationFragment extends Fragment {

    View view;
    private RecyclerView rv_MyCreation;
    private AppCompatTextView tv_NoVideo;
    int position;



    public static Fragment getInstance(int position) {
        Bundle bundle = new Bundle();
        bundle.putInt("pos", position);
        MyCreationFragment tabFragment = new MyCreationFragment();
        tabFragment.setArguments(bundle);
        return tabFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.mycreation_fragment, container, false);
        position = getArguments().getInt("pos");

        rv_MyCreation = view.findViewById(R.id.RV_Mycreation);
        tv_NoVideo = view.findViewById(R.id.tv_NoVideo);

        rv_MyCreation.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        rv_MyCreation.setItemAnimator(new DefaultItemAnimator());
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2);
        rv_MyCreation.setHasFixedSize(true);
        rv_MyCreation.setLayoutManager(gridLayoutManager);
        if (position == 0) {
            GetCreateVideo1();
        } else if (position == 1) {
            GetCreateVieo();
        } else if (position == 2) {
            GetCreateVideo2();
        } else if (position == 3) {
            GetCreateVideo3();
        } else if (position == 4) {
            GetCreateVideo4();
        } else if (position == 5) {
            GetCreateVideo5();
        } else if (position == 6) {
            GetCreateVideo6();
        } else if (position == 7) {
            GetCreateVideo7();
        } else if (position == 8) {
            GetCreateVideo8();
        } else if (position == 9) {
            GetCreateVideo9();
        } else if (position == 10) {
            GetCreateVideo10();
        } else if (position == 11) {
            GetCreateVideo11();
        }
        return view;
    }




    private void GetCreateVieo() {
        if (!Constant.DCIMFolder.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation.exists()) {
            File[] listFiles = Constant.MyCreation.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }


    private void GetCreateVideo1() {
        if (!Constant.DCIMFolder1.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation1.exists()) {
            File[] listFiles = Constant.MyCreation1.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }

    private void GetCreateVideo2() {
        if (!Constant.DCIMFolder2.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation2.exists()) {
            File[] listFiles = Constant.MyCreation2.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }


    private void GetCreateVideo3() {
        if (!Constant.DCIMFolder3.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation3.exists()) {
            File[] listFiles = Constant.MyCreation3.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }

    private void GetCreateVideo4() {
        if (!Constant.DCIMFolder4.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation4.exists()) {
            File[] listFiles = Constant.MyCreation4.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }

    private void GetCreateVideo5() {
        if (!Constant.DCIMFolder5.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation5.exists()) {
            File[] listFiles = Constant.MyCreation5.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }

    private void GetCreateVideo6() {
        if (!Constant.DCIMFolder6.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation6.exists()) {
            File[] listFiles = Constant.MyCreation6.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }

    private void GetCreateVideo7() {
        if (!Constant.DCIMFolder7.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation7.exists()) {
            File[] listFiles = Constant.MyCreation7.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }

    private void GetCreateVideo8() {
        if (!Constant.DCIMFolder8.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation8.exists()) {
            File[] listFiles = Constant.MyCreation8.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }

    private void GetCreateVideo9() {
        if (!Constant.DCIMFolder9.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation9.exists()) {
            File[] listFiles = Constant.MyCreation9.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }

    private void GetCreateVideo10() {
        if (!Constant.DCIMFolder10.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation10.exists()) {
            File[] listFiles = Constant.MyCreation10.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }


    private void GetCreateVideo11() {
        if (!Constant.DCIMFolder11.exists()) {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else if (Constant.MyCreation11.exists()) {
            File[] listFiles = Constant.MyCreation11.listFiles();
            if (listFiles.length > 0) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                ArrayList arrayList = new ArrayList();
                for (File absolutePath : listFiles) {
                    arrayList.add(absolutePath.getAbsolutePath());
                }
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(arrayList);
                final VideoSaveAdp videoSaveAdp = new VideoSaveAdp(getActivity(), arrayList2);
                rv_MyCreation.setAdapter(videoSaveAdp);
                videoSaveAdp.setOnItemClickListener(new VideoSaveAdp.setOnItemClickListener() {
                    public void onItemClick(int i) {
                        File file = new File(Uri.fromFile(new File((String) arrayList2.get(i))).getPath());
                        if (file.exists() && file.delete()) {
                            arrayList2.remove(i);
                            videoSaveAdp.notifyItemRemoved(i);
                            rv_MyCreation.smoothScrollToPosition(i);
                            if (arrayList2.size() > 0) {
                                tv_NoVideo.setVisibility(View.GONE);
                                rv_MyCreation.setVisibility(View.VISIBLE);
                                return;
                            }
                            tv_NoVideo.setVisibility(View.VISIBLE);
                            rv_MyCreation.setVisibility(View.GONE);
                        }
                    }
                });
                tv_NoVideo.setVisibility(View.GONE);
                rv_MyCreation.setVisibility(View.VISIBLE);
                return;
            }
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        } else {
            tv_NoVideo.setVisibility(View.VISIBLE);
            rv_MyCreation.setVisibility(View.GONE);
        }
    }
}