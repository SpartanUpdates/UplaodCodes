package com.esc.motivationquotes.managers;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.List;

public class QuotesManager {
    private static final String PREF_QUOTES = "pref_quotescom.esc.motivationquotes.motivation_";
    private static final String PREF_QUOTE_REMINDER_POSITION = "pref_quote_reminder_positioncom.esc.motivationquotes.motivation_";

    public static ArrayList<String> getReadQuotes() {
        String string = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext()).getString(PREF_QUOTES, null);
        if (string == null) {
            return null;
        }
        return (ArrayList) new Gson().fromJson(string, new TypeToken<List<String>>() {
        }.getType());
    }

    public static void addReadQuote(String str) {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext());
        ArrayList readQuotes = getReadQuotes();
        if (readQuotes == null) {
            readQuotes = new ArrayList();
        }
        if (!readQuotes.contains(str)) {
            readQuotes.add(str);
        }
        Editor edit = defaultSharedPreferences.edit();
        edit.putString(PREF_QUOTES, new Gson().toJson(readQuotes));
        edit.commit();
    }

    public static void removeQuotesRead() {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext());
        ArrayList arrayList = new ArrayList();
        Editor edit = defaultSharedPreferences.edit();
        edit.putString(PREF_QUOTES, new Gson().toJson(arrayList));
        edit.commit();
    }

    public static int getQuoteReminderPosition() {
        return PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext()).getInt(PREF_QUOTE_REMINDER_POSITION, 0);
    }

    public static void setQuoteReminderPosition(int i) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext()).edit();
        edit.putInt(PREF_QUOTE_REMINDER_POSITION, i);
        edit.commit();
    }
}
