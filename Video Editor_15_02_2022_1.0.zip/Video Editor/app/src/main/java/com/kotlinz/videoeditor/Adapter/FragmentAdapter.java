package com.kotlinz.videoeditor.Adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import com.kotlinz.videoeditor.Fragment.MyCreationFragment;

public class FragmentAdapter extends FragmentPagerAdapter {

    private String title[] = {"Slow Motion", "Fast Motion", "Reverse","Video Compressor","Audio Video Mixer","Crop","Snap Shot","Add Audio","Convert","Rotation","VideoJoiner","Video Collage"};

    public FragmentAdapter(FragmentManager manager) {
        super(manager);
    }

    @Override
    public Fragment getItem(int position) {
        return MyCreationFragment.getInstance(position);
    }

    @Override
    public int getCount() {
        return title.length;
    }



    @Override
    public CharSequence getPageTitle(int position) {
        return title[position];
    }
}