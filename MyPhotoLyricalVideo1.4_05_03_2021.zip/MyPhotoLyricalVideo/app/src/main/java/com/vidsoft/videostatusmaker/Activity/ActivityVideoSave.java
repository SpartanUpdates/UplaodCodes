package com.vidsoft.videostatusmaker.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Parcelable;
import android.os.StrictMode;
import android.os.StrictMode.VmPolicy.Builder;

import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;

import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.vidsoft.videostatusmaker.Utils.Utils;

import static com.vidsoft.videostatusmaker.NativeAds.NativeAdMethod.populateNativeAdView;

public class ActivityVideoSave extends Activity implements OnClickListener {
    ImageView ivBack;
    String strNewUrl;
    LinearLayout playLay;
    ImageView ivPlayPause;
    SeekBar playerSeek;
    Runnable runnable = new Runnable() {
        public void run() {
            ActivityVideoSave.this.seekUpdation();
        }
    };
    Handler seekHandler = new Handler();
    ImageView ivShare;
    TextView startTime;
    VideoView videoView;
    Drawable bitmap;
    RelativeLayout centerLay;
    ImageView delete;
    TextView tvTitle;
    private ImageView ivFacebook;
    private ImageView ivInstagram;
    private ImageView ivTwitter;
    private ImageView ivWhatsApp;
    TextView endTime;
    Typeface typeface;
    File[] listFile = null;
    RelativeLayout relativeLayout;

    private UnifiedNativeAd nativeAd;


    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.saved_video);
        LoadNativeAds();
        getWindow().addFlags(1024);
        Builder builder = new Builder();
        StrictMode.setVmPolicy(builder.build());
        if (VERSION.SDK_INT >= 18) {
            builder.detectFileUriExposure();
        }
        PutAnalyticsEvent();
        bindView();
        init();
        btnclick();
        this.playerSeek.setEnabled(false);
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityVideoSave");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void init() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStorageDirectory());
        stringBuilder.append("/");
        stringBuilder.append(getString(R.string.app_name));
        String stringBuilder2 = stringBuilder.toString();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(stringBuilder2);
        stringBuilder3.append("/Video");
        File absoluteFile = new File(stringBuilder3.toString()).getAbsoluteFile();
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(absoluteFile);
        stringBuilder4.append(File.separator);
        stringBuilder4.append("video_");
        stringBuilder4.append(setDateFormat(System.currentTimeMillis()));
        stringBuilder4.append(".mp4");
        this.strNewUrl = stringBuilder4.toString();
        this.strNewUrl = getIntent().getStringExtra("outpath");
        MediaScannerConnection.scanFile(this, new String[]{this.strNewUrl}, new String[]{"video/*"}, null);
        getFromSdcard();
        MediaPlayer mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(this.strNewUrl);
            mediaPlayer.prepare();
            if (mediaPlayer.getVideoWidth() < mediaPlayer.getVideoHeight()) {
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0);
                layoutParams.weight = 9.1f;
                this.relativeLayout.setLayoutParams(layoutParams);
            } else {
                this.delete.setVisibility(View.VISIBLE);
                this.ivShare.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            this.videoView.setVideoPath(this.strNewUrl);
            this.videoView.setOnCompletionListener(new OnCompletionListener() {
                public void onCompletion(MediaPlayer mediaPlayer) {
                    ActivityVideoSave.this.ivPlayPause.setImageResource(R.drawable.play);
                    ActivityVideoSave.this.playerSeek.setProgress(0);
                }
            });
            this.videoView.start();
            seekUpdation();
        } catch (Exception e2) {
            e2.toString();
        }
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.layout_native_advance, null);
                populateNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void btnclick() {
        this.ivBack.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(ActivityVideoSave.this, ActivityMyCreations.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                finish();
            }

        });
        this.ivShare.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ActivityVideoSave.this.share_video();
            }
        });
        this.delete.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ActivityVideoSave.this.delete_video();
            }
        });
        this.ivPlayPause.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ActivityVideoSave.this.videoView.setBackgroundDrawable(null);
                if (ActivityVideoSave.this.videoView.isPlaying()) {
                    ActivityVideoSave.this.videoView.pause();
                    ActivityVideoSave.this.ivPlayPause.setImageResource(R.drawable.play);
                    return;
                }
                ActivityVideoSave.this.videoView.start();
                ActivityVideoSave.this.ivPlayPause.setImageResource(R.drawable.pause);
            }
        });
        try {
            Glide.with((Activity) this).load(this.strNewUrl).listener(new RequestListener<String, GlideDrawable>() {
                public boolean onException(Exception exception, String str, Target<GlideDrawable> target, boolean z) {
                    Log.e("Error123", "AAA : onLoadFailed image thumb");
                    return true;
                }

                public boolean onResourceReady(GlideDrawable glideDrawable, String str, Target<GlideDrawable> target, boolean z, boolean z2) {
                    ActivityVideoSave.this.bitmap = glideDrawable;
                    return true;
                }
            }).into((ImageView) findViewById(R.id.im));
        } catch (Exception e22) {
            e22.toString();
        }
    }

    private void bindView() {
        this.videoView = (VideoView) findViewById(R.id.bg_video);
        this.ivShare = (ImageView) findViewById(R.id.share);
        this.delete = (ImageView) findViewById(R.id.delete);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.relativeLayout = (RelativeLayout) findViewById(R.id.main);
        this.centerLay = (RelativeLayout) findViewById(R.id.center_lay);
        this.playLay = (LinearLayout) findViewById(R.id.play_lay);
        this.startTime = (TextView) findViewById(R.id.start_time);
        this.endTime = (TextView) findViewById(R.id.end_time);
        this.ivPlayPause = (ImageView) findViewById(R.id.play_pause);
        this.playerSeek = (SeekBar) findViewById(R.id.player_seek);
        this.tvTitle = (TextView) findViewById(R.id.title);
        this.typeface = Typeface.createFromAsset(getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        this.ivWhatsApp = (ImageView) findViewById(R.id.imgFacebook);
        this.ivFacebook = (ImageView) findViewById(R.id.imgWhatsApp);
        this.ivInstagram = (ImageView) findViewById(R.id.imgInstagram);
        this.ivTwitter = (ImageView) findViewById(R.id.imgTwitter);
        this.ivFacebook.setOnClickListener(this);
        this.ivInstagram.setOnClickListener(this);
        this.ivWhatsApp.setOnClickListener(this);
        this.ivTwitter.setOnClickListener(this);
    }


    public void getFromSdcard() {
        File externalStorageDirectory = Environment.getExternalStorageDirectory();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append("/Video");
        File file = new File(externalStorageDirectory, stringBuilder.toString());
        if (file.isDirectory()) {
            this.listFile = file.listFiles();
            for (int i = 0; i < this.listFile.length; i++) {
                if (this.listFile[i].getName().contains("temp")) {
                    this.listFile[i].delete();
                }
            }
        }
    }

    protected void onPause() {
        this.videoView.pause();
        this.videoView.setBackgroundDrawable(this.bitmap);
        this.ivPlayPause.setImageResource(R.drawable.play);
        super.onPause();
    }

    public void seekUpdation() {
        this.playerSeek.setMax(this.videoView.getDuration());
        this.startTime.setText(String.format("%02d:%02d", new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toMinutes((long) this.videoView.getCurrentPosition())), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds((long) this.videoView.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long) this.videoView.getCurrentPosition())))}));
        this.endTime.setText(String.format("%02d:%02d", new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toMinutes((long) this.videoView.getDuration())), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds((long) this.videoView.getDuration()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long) this.videoView.getDuration())))}));
        this.playerSeek.setProgress(this.videoView.getCurrentPosition());
        this.seekHandler.postDelayed(this.runnable, 10);
    }

    public void onBackPressed() {
        this.videoView.stopPlayback();
        startActivity(new Intent(ActivityVideoSave.this, ActivityMyCreations.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
        Utils.count = 0;
    }

    public static String setDateFormat(long j) {
        return new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(new Date(j)).toUpperCase();
    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    void delete_video() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Delete !");
        builder.setMessage("Are you sure to delete Video??");
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                if (new File(ActivityVideoSave.this.strNewUrl).delete()) {
                    MediaScannerConnection.scanFile(ActivityVideoSave.this, new String[]{ActivityVideoSave.this.strNewUrl}, new String[]{"video/*"}, null);
                    Toast.makeText(ActivityVideoSave.this, "File Deleted", Toast.LENGTH_SHORT).show();
                }
                ActivityVideoSave.this.onBackPressed();
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imgFacebook:
                shareImageWhatsApp("com.facebook.katana", "Facebook");
                return;
            case R.id.imgInstagram:
                shareImageWhatsApp("com.instagram.android", "Instagram");
                return;
            case R.id.imgTwitter:
                shareImageWhatsApp("com.twitter.android", "Twitter");
                return;
            case R.id.imgWhatsApp:
                shareImageWhatsApp("com.whatsapp", "Whatsapp");
                return;


            default:
        }

    }

    void share_video() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/*");
        File file = new File(this.strNewUrl);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("file://");
        stringBuilder.append(file.getAbsolutePath());
        intent.putExtra("android.intent.extra.STREAM", Uri.parse(stringBuilder.toString()));
        startActivity(Intent.createChooser(intent, "Share Video"));
    }

    private boolean isPackageInstalled(final String s, final Context context) {
        final PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(s, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ex) {
            return false;
        }
    }

    public void shareImageWhatsApp(String str, String str2) {
        Parcelable fromFile;
        if (VERSION.SDK_INT <= 19) {
            fromFile = Uri.fromFile(new File(this.strNewUrl));
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getPackageName());
            stringBuilder.append(".provider");
            fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(this.strNewUrl));
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/*");
        intent.putExtra("android.intent.extra.STREAM", fromFile);
        if (isPackageInstalled(str, getApplicationContext())) {
            intent.setPackage(str);
            startActivity(Intent.createChooser(intent, "Create Amazing Photo Layrics Videos"));
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Please Install ");
        stringBuilder2.append(str2);
        Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_SHORT).show();
    }
}