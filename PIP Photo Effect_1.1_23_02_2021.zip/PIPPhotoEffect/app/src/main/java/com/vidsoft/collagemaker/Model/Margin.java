package com.vidsoft.collagemaker.Model;

public class Margin
{
  int bottom;
  int left;
  int right;
  int top;

  public Margin(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.left = paramInt1;
    this.top = paramInt2;
    this.right = paramInt3;
    this.bottom = paramInt4;
  }

  public int getBottom()
  {
    return this.bottom;
  }

  public int getLeft()
  {
    return this.left;
  }

  public int getRight()
  {
    return this.right;
  }

  public int getTop()
  {
    return this.top;
  }

  public void setBottom(int paramInt)
  {
    this.bottom = paramInt;
  }

  public void setLeft(int paramInt)
  {
    this.left = paramInt;
  }

  public void setRight(int paramInt)
  {
    this.right = paramInt;
  }

  public void setTop(int paramInt)
  {
    this.top = paramInt;
  }
}