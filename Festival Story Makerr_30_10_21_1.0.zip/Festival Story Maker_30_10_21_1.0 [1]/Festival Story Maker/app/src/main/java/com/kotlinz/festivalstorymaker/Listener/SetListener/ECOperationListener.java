package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;

import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;


public class ECOperationListener implements ImageStickerViewNew.c
{
    public final CanvasEditorActivity activity;

    public ECOperationListener(final CanvasEditorActivity a) {
        this.activity = a;
    }

    @Override
    public void a(final ImageStickerViewNew imageStickerViewNew) {
        imageStickerViewNew.setInEdit(false);
        imageStickerViewNew.setInEdit(true);
    }

    @Override
    public void b(final ImageStickerViewNew imageStickerViewNew) {
        CanvasEditorActivity.j0(activity);
        activity.r0.get(activity.H0).removeView((View)imageStickerViewNew);
    }

    @Override
    public void c(final Boolean b) {
        this.activity.scroll.requestDisallowInterceptTouchEvent((boolean)b);
    }

    @Override
    public void d(final ImageStickerViewNew imageStickerViewNew) {
    }
}
