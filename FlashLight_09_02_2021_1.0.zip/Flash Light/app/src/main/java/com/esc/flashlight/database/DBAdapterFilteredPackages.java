package com.esc.flashlight.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBAdapterFilteredPackages implements IDBFilteredPackageName {

    public static final String TAG = "DBAdapterFilteredPackages";
    private Context mContext;
    private SQLiteDatabase mDatabase;
    private DBHelper mHelper;

    private static class DBHelper extends SQLiteOpenHelper {
        DBHelper(Context context) {
            super(context, IDBFilteredPackageName.DB_NAME, null, 1);
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL(IDBFilteredPackageName.SQL_DB_CREATE);
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS filtered_packages");
            onCreate(sQLiteDatabase);
        }
    }

    public DBAdapterFilteredPackages(Context context) {
        this.mContext = context;
    }

    public DBAdapterFilteredPackages open() throws SQLException {
        DBHelper dBHelper = new DBHelper(this.mContext);
        this.mHelper = dBHelper;
        this.mDatabase = dBHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        this.mHelper.close();
    }

    public long insert(String str) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(IDBFilteredPackageName.FILTERED_PACKAGE_NAME, str);
        return this.mDatabase.insert(IDBFilteredPackageName.DB_TABLE, null, contentValues);
    }

    public boolean update(long j, String str) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(IDBFilteredPackageName.FILTERED_PACKAGE_NAME, str);
        return this.mDatabase.update(IDBFilteredPackageName.DB_TABLE, contentValues, new StringBuilder("_id=").append(j).toString(), null) > 0;
    }

    public boolean delete(long j) {
        return this.mDatabase.delete(IDBFilteredPackageName.DB_TABLE, new StringBuilder("_id=").append(j).toString(), null) > 0;
    }

    public void clear() {
        this.mDatabase.execSQL("drop table filtered_packages");
        this.mDatabase.execSQL(IDBFilteredPackageName.SQL_DB_CREATE);
    }

    public Cursor fetchAll() {
        return this.mDatabase.query(IDBFilteredPackageName.DB_TABLE, QUERY_COLUMNS_FILTERED_APPLICATION, null, null, null, null, null);
    }

    public Cursor fetch(long j) throws SQLException {
        Cursor query = this.mDatabase.query(true, IDBFilteredPackageName.DB_TABLE, QUERY_COLUMNS_FILTERED_APPLICATION, "_id=" + j, null, null, null, null, null);
        if (query != null) {
            query.moveToFirst();
        }
        return query;
    }

    public Cursor fetch(String str) {
        Cursor query = this.mDatabase.query(true, IDBFilteredPackageName.DB_TABLE, QUERY_COLUMNS_FILTERED_APPLICATION, "filtered_package_name='" + str + "'", null, null, null, null, null);
        if (query != null) {
            query.moveToFirst();
        }
        return query;
    }

}
