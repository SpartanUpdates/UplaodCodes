package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;


public class HDFontSpacing implements OnSeekBarChangeListener {
    public final  HighlightDetailsDetailActivity activity;

    public HDFontSpacing(HighlightDetailsDetailActivity highlightDetailsDetailActivity) {
        this.activity = highlightDetailsDetailActivity;
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        if (z) {
            this.activity.n0.setLineSpacing((float) i);
            this.activity.n0.requestLayout();
            com.kotlinz.festivalstorymaker.Models.z.c cVar = (com.kotlinz.festivalstorymaker.Models.z.c) activity.m0.get(((Integer) activity.n0.getTag()).intValue());
            cVar.b = i + 5;
            activity.m0.set(((Integer) activity.n0.getTag()).intValue(), cVar);
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}
