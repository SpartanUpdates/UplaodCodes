package com.videozoneinc.musicvideoeditor.util;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.ExifInterface;

import java.io.IOException;

public class ScalingUtilities {
    public static Bitmap ConvetrSameSizeNew(final Bitmap bitmap, Bitmap doBlur, final int n, final int n2) {
        doBlur = FastBlur.doBlur(doBlur, 25, true);
        final Canvas canvas = new Canvas(doBlur);
        final Paint paint = new Paint();
        final float n3 = bitmap.getWidth();
        final float n4 = bitmap.getHeight();
        final float n5 = n;
        float n6 = n5 / n3;
        final float n7 = n2;
        final float n8 = n7 / n4;
        float n9 = (n7 - n4 * n6) / 2.0f;
        float n12;
        if (n9 < 0.0f) {
            final float n10 = (n5 - n3 * n8) / 2.0f;
            n6 = n8;
            final float n11 = 0.0f;
            n12 = n10;
            n9 = n11;
        } else {
            n12 = 0.0f;
        }
        final Matrix matrix = new Matrix();
        matrix.postTranslate(n12, n9);
        matrix.preScale(n6, n6);
        canvas.drawBitmap(bitmap, matrix, paint);
        return doBlur;
    }

    public static int calculateSampleSize(final int n, final int n2, final int n3, final int n4, final ScalingLogic scalingLogic) {
        if (scalingLogic == ScalingLogic.FIT) {
            if (n / n2 > n3 / n4) {
                return n / n3;
            }
            return n2 / n4;
        } else {
            if (n / n2 > n3 / n4) {
                return n2 / n4;
            }
            return n / n3;
        }
    }

    public static Bitmap checkBitmap(String path) {
        int orientation = 1;
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);
        Bitmap bm = BitmapFactory.decodeFile(path, new BitmapFactory.Options());
        try {
            String orientString = new ExifInterface(path)
                    .getAttribute("Orientation");
            if (orientString != null) {
                orientation = Integer.parseInt(orientString);
            }
            int rotationAngle = 0;
            if (orientation == 6) {
                rotationAngle = 90;
            }
            if (orientation == 3) {
                rotationAngle = 180;
            }
            if (orientation == 8) {
                rotationAngle = 270;
            }
            Matrix matrix = new Matrix();
            matrix.setRotate((float) rotationAngle,
                    ((float) bm.getWidth()) / 2.0f,
                    ((float) bm.getHeight()) / 2.0f);
            return Bitmap.createBitmap(bm, 0, 0, bounds.outWidth,
                    bounds.outHeight, matrix, true);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    public static Bitmap decodeResource(final Resources resources, final int n, final int n2, final int n3, final ScalingLogic scalingLogic) {
        final BitmapFactory.Options bitmapFactory$Options = new BitmapFactory.Options();
        bitmapFactory$Options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(resources, n, bitmapFactory$Options);
        bitmapFactory$Options.inJustDecodeBounds = false;
        bitmapFactory$Options.inSampleSize = calculateSampleSize(bitmapFactory$Options.outWidth, bitmapFactory$Options.outHeight, n2, n3, scalingLogic);
        return BitmapFactory.decodeResource(resources, n, bitmapFactory$Options);
    }


    public static Bitmap overlay(final Bitmap bitmap, final Bitmap bitmap2, final int alpha) {
        final Bitmap bitmap3 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        final Canvas canvas = new Canvas(bitmap3);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, (Paint) null);
        final Paint paint = new Paint();
        paint.setAlpha(alpha);
        canvas.drawBitmap(bitmap2, 0.0f, 0.0f, paint);
        return bitmap3;
    }

    public static Bitmap scaleCenterCrop(final Bitmap bitmap, final int n, final int n2) {
        final int width = bitmap.getWidth();
        final int height = bitmap.getHeight();
        if (width == n && height == n2) {
            return bitmap;
        }
        final float n3 = n;
        final float n4 = width;
        final float n5 = n3 / n4;
        final float n6 = n2;
        final float n7 = height;
        final float max = Math.max(n5, n6 / n7);
        final float n8 = n4 * max;
        final float n9 = max * n7;
        final float n10 = (n3 - n8) / 2.0f;
        final float n11 = (n6 - n9) / 2.0f;
        final RectF rectF = new RectF(n10, n11, n8 + n10, n9 + n11);
        final Bitmap bitmap2 = Bitmap.createBitmap(n, n2, bitmap.getConfig());
        new Canvas(bitmap2).drawBitmap(bitmap, (Rect) null, rectF, (Paint) null);
        return bitmap2;
    }

    public enum ScalingLogic {
        CROP,
        FIT;
    }
}
