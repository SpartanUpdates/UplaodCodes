package com.esc.lovemessages;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;

public abstract class StickerView extends FrameLayout {
    private static final int BUTTON_SIZE_DP = 0;
    private static final int SELF_SIZE_DP = 100;
    public static final String TAG = "com.tz.photocaption";
    private double centerX;
    private double centerY;
    int counter = 0;
    Context ctx;
    boolean isFirst = true;
    private BorderView iv_border;
    private float move_orgX = -1.0f;
    private float move_orgY = -1.0f;
    private float rotate_newX = -1.0f;
    private float rotate_newY = -1.0f;
    private float rotate_orgX = -1.0f;
    private float rotate_orgY = -1.0f;
    double rotation = 0.0d;
    private double scale_orgHeight = -1.0d;
    private double scale_orgWidth = -1.0d;
    private float scale_orgX = -1.0f;
    private float scale_orgY = -1.0f;
    double tempAngle = 0.0d;
    private float this_orgX = -1.0f;
    private float this_orgY = -1.0f;

    private class BorderView extends View {
        public BorderView(Context context) {
            super(context);
        }

        public BorderView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public BorderView(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
        }


        public void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            LayoutParams layoutParams = (LayoutParams) getLayoutParams();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("params.leftMargin: ");
            stringBuilder.append(layoutParams.leftMargin);
            Log.v(StickerView.TAG, stringBuilder.toString());
            Rect rect = new Rect();
            rect.left = getLeft() - layoutParams.leftMargin;
            rect.top = getTop() - layoutParams.topMargin;
            rect.right = getRight() - layoutParams.rightMargin;
            rect.bottom = getBottom() - layoutParams.bottomMargin;
            Paint paint = new Paint();
            paint.setStrokeWidth(6.0f);
            paint.setColor(-1);
            paint.setStyle(Style.STROKE);
            canvas.drawRect(rect, paint);
        }
    }

    public abstract View getMainView();


    public void onScaling(boolean z) {
    }

    public StickerView(Context context) {
        super(context);
        this.ctx = context;
        init(context);
    }

    public StickerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.ctx = context;
        init(context);
    }

    public StickerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.ctx = context;
        init(context);
    }

    private void init(Context context) {
        this.ctx = context;
        this.iv_border = new BorderView(context);
        setTag("DraggableViewGroup");
        this.iv_border.setTag("iv_border");
        int convertDpToPixel = convertDpToPixel(0.0f, getContext()) / 2;
        int convertDpToPixel2 = convertDpToPixel(100.0f, getContext());
        LayoutParams layoutParams = new LayoutParams(convertDpToPixel2, convertDpToPixel2);
        LayoutParams layoutParams2 = new LayoutParams(-1, -1);
        layoutParams2.setMargins(convertDpToPixel, convertDpToPixel, convertDpToPixel, convertDpToPixel);
        LayoutParams layoutParams3 = new LayoutParams(-1, -1);
        layoutParams3.setMargins(convertDpToPixel, convertDpToPixel, convertDpToPixel, convertDpToPixel);
        new LayoutParams(convertDpToPixel(0.0f, getContext()), convertDpToPixel(0.0f, getContext())).gravity = 85;
        new LayoutParams(convertDpToPixel(0.0f, getContext()), convertDpToPixel(0.0f, getContext())).gravity = 51;
        new LayoutParams(convertDpToPixel(0.0f, getContext()), convertDpToPixel(0.0f, getContext())).gravity = 53;
        setLayoutParams(layoutParams);
        addView(getMainView(), layoutParams2);
        addView(this.iv_border, layoutParams3);
    }

    public void reCenter(double d, double d2, double d3, double d4) {
        setX((float) d);
        setY((float) d3);
        getLayoutParams().width = (int) (d2 - d);
        getLayoutParams().height = (int) (d4 - d3);
    }

    /* Access modifiers changed, original: protected */
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    private double getLength(double d, double d2, double d3, double d4) {
        return Math.sqrt(Math.pow(d4 - d2, 2.0d) + Math.pow(d3 - d, 2.0d));
    }

    private float[] getRelativePos(float f, float f2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getRelativePos getX:");
        stringBuilder.append(((View) getParent()).getX());
        String str = "ken";
        Log.v(str, stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("getRelativePos getY:");
        stringBuilder.append(((View) getParent()).getY());
        Log.v(str, stringBuilder.toString());
        float[] fArr = new float[]{f - ((View) getParent()).getX(), f2 - ((View) getParent()).getY()};
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("getRelativePos absY:");
        stringBuilder2.append(f2);
        String stringBuilder3 = stringBuilder2.toString();
        String str2 = TAG;
        Log.v(str2, stringBuilder3);
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("getRelativePos relativeY:");
        stringBuilder2.append(fArr[1]);
        Log.v(str2, stringBuilder2.toString());
        return fArr;
    }

    public void setControlItemsHidden(boolean z) {
        if (z) {
            this.iv_border.setVisibility(GONE);
        } else {
            this.iv_border.setVisibility(VISIBLE);
        }
    }

    public void removeTextView() {
        if (getParent() != null) {
            ((ViewGroup) getParent()).removeView(this);
        }
    }

    private static int convertDpToPixel(float f, Context context) {
        return (int) (f * (((float) context.getResources().getDisplayMetrics().densityDpi) / 160.0f));
    }
}
