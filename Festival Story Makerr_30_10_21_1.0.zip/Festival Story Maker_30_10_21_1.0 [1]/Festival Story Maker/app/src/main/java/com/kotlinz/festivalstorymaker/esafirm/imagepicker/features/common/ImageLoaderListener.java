package com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.common;

import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Folder;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;

import java.util.List;

public interface ImageLoaderListener {
    void onImageLoaded(List<Image> images, List<Folder> folders);
    void onFailed(Throwable throwable);
}
