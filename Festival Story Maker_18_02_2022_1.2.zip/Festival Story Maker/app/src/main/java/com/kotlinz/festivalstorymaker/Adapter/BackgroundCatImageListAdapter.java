package com.kotlinz.festivalstorymaker.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.Background.BackgroundImagesItem;
import com.kotlinz.festivalstorymaker.R;

import java.util.ArrayList;
import butterknife.BindView;
import butterknife.ButterKnife;

public class BackgroundCatImageListAdapter extends RecyclerView.Adapter<BackgroundCatImageListAdapter.ViewHolder> {

    public Activity activity;
    public ArrayList<BackgroundImagesItem> backgroundImagesItemsList;
    public a h;

    public BackgroundCatImageListAdapter(Activity activity, ArrayList<BackgroundImagesItem> arrayList, a aVar) {
        this.activity = activity;
        this.backgroundImagesItemsList = arrayList;
        this.h = aVar;
    }

    public interface a {
        void a(int i);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_highlight_bg_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Glide.with(activity).load(backgroundImagesItemsList.get(position).getThemeThumbnail()).placeholder(R.drawable.progress).into(holder.img);
        holder.img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        holder.img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                h.a(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.backgroundImagesItemsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.imgBg)
        public ImageView img;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
