package com.unitedvideos.CropView.imagezoomcrop.photoview.gestures;

import android.content.Context;
import android.os.Build;

public final class VersionedGestureDetector
{
  public static GestureDetector newInstance(final Context context, final OnGestureListener listener) {
    final int sdkVersion = Build.VERSION.SDK_INT;
    GestureDetector detector;
    if (sdkVersion < 5) {
      detector = new CupcakeGestureDetector(context);
    }
    else if (sdkVersion < 8) {
      detector = new EclairGestureDetector(context);
    }
    else {
      detector = new FroyoGestureDetector(context);
    }
    detector.setOnGestureListener(listener);
    return detector;
  }
}
