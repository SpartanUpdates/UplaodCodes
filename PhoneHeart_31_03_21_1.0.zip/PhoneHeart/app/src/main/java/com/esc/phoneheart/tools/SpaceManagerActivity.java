package com.esc.phoneheart.tools;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.esc.phoneheart.interfaceclass.DownloadDataFetchedListener;
import com.esc.phoneheart.model.DownloadsData;
import com.esc.phoneheart.activity.DownloadsScreen;
import com.esc.phoneheart.activity.FinalScreen;
import com.esc.phoneheart.activity.HomeActivity;
import com.esc.phoneheart.activity.PhoneCleaner;
import com.esc.phoneheart.R;
import com.esc.phoneheart.kprogresshud.KProgressHUD;
import com.esc.phoneheart.model.FileManagerModule;
import com.esc.phoneheart.smedia.FileMedia;
import com.esc.phoneheart.model.MediaList;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.PermitionActivity;
import com.esc.phoneheart.pref.SharedPrefUtil;
import com.esc.phoneheart.utility.Util;
import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;
import com.esc.phoneheart.model.FileType.FileTypes;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

public class SpaceManagerActivity extends PermitionActivity implements OnClickListener {
    public static final int REQUEST_PERMISSIONS = 212;
    private Activity activity = SpaceManagerActivity.this;
    public String TAG = "SpaceManagerActivity";
    public ApkCalculation apkCalculation;
    public AudioCalculation audioCalculation;
    public int completedTask;
    public Context context;
    public int defaultProgress;
    public DocCalculation docCalculation;
    public DownloadsCalculation downloadsCalculation;
    public ExecutorService executorService;
    public FileMedia fileMedia;
    public String from;
    public boolean fromToolBox;
    public RelativeLayout hiddenPermissionLayout;
    public HashMap<String, Boolean> hmExtnApk;
    public HashMap<String, Boolean> hmExtnDocs;
    public HashMap<String, Boolean> hmExtnsOtherMediaAndDocs;
    public ImageCalculation imagecalculation;
    public boolean isExecuting = false;
    public TextView l;
    public ArrayList m;
    public MediaList mediasList;
    public ArrayList<BigSizeFilesWrapper> n = new ArrayList();
    public boolean noti_result_back;
    public OtherCalculation otherCalculation;
    public boolean redirectToNoti;
    public RecyclerView rv_suggestion;
    public SharedPrefUtil sharedPrefUtil;
    public SuggestionListAdapter suggestionListAdapter;
    public TextView t_cpuuses;
    public TextView t_text;
    public TextView t_unit;
    public String title;
    public TextView tv_allSpace;
    public TextView tv_no_result_found;
    public TextView tvdownCount;
    public TextView tvdownSize;
    public VideoCalculation videoCalculation;
    private ImageView iv_back;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitialAd;
    private int id;
    private KProgressHUD hud;

    public class ApkCalculation extends Thread {
        public void run() {
            SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(SpaceManagerActivity.this.title);
            stringBuilder.append(" APK Files");
            final MediaList mediaList = new MediaList(spaceManagerActivity, stringBuilder.toString(), FileTypes.APK);
            mediaList.fetchAPK(0, SpaceManagerActivity.this.hmExtnApk);
            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                SpaceManagerActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        SpaceManagerActivity.this.findViewById(R.id.tv_apk_size).setVisibility(View.VISIBLE);
                        SpaceManagerActivity.this.findViewById(R.id.tv_apk_count).setVisibility(View.VISIBLE);
                        SpaceManagerActivity.this.findViewById(R.id.pbar_apk_count).setVisibility(View.GONE);
                        TextView textView = SpaceManagerActivity.this.findViewById(R.id.tv_apk_size);
                        StringBuilder stringBuilder = new StringBuilder();
                        String str = "";
                        stringBuilder.append(str);
                        stringBuilder.append(Util.convertBytes(mediaList.totalSize));
                        textView.setText(stringBuilder.toString());
                        textView = SpaceManagerActivity.this.findViewById(R.id.tv_apk_count);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str);
                        stringBuilder.append(mediaList.arrContents.size());
                        String str2 = " ";
                        stringBuilder.append(str2);
                        stringBuilder.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                        textView.setText(stringBuilder.toString());
                        SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
                        spaceManagerActivity.completedTask = spaceManagerActivity.completedTask + 1;
                        SpaceManagerActivity.this.m.addAll(mediaList.arrContents);
                        if (SpaceManagerActivity.this.completedTask == 6) {
                            SpaceManagerActivity.this.updateTotalRecoverable();
                            SpaceManagerActivity spaceManagerActivity2 = SpaceManagerActivity.this;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(SpaceManagerActivity.this.title);
                            stringBuilder2.append(" All Files");
                            MediaList mediaList = new MediaList(spaceManagerActivity2, stringBuilder2.toString(), FileTypes.ALL);
                            mediaList.fetchAllFiles(SpaceManagerActivity.this.m);
                            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(str);
                            stringBuilder3.append(Util.convertBytes(mediaList.totalSize));
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(str);
                            stringBuilder3.append(mediaList.arrContents.size());
                            stringBuilder3.append(str2);
                            stringBuilder3.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
                            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                                SpaceManagerActivity spaceManagerActivity3 = SpaceManagerActivity.this;
                                spaceManagerActivity3.suggestionListAdapter = new SuggestionListAdapter(spaceManagerActivity3.n, mediaList);
                                SpaceManagerActivity.this.rv_suggestion.setLayoutManager(new LinearLayoutManager(SpaceManagerActivity.this.context));
                                SpaceManagerActivity.this.rv_suggestion.setAdapter(SpaceManagerActivity.this.suggestionListAdapter);
                                SpaceManagerActivity.this.invalidateOptionsMenu();
                            }
                        }
                    }
                });
            }
        }
    }

    public class AudioCalculation extends Thread {
        public void run() {
            SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(SpaceManagerActivity.this.title);
            stringBuilder.append(" Audio");
            final MediaList mediaList = new MediaList(spaceManagerActivity, stringBuilder.toString(), FileTypes.Audio);
            mediaList.fetchAudio();
            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                SpaceManagerActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        SpaceManagerActivity.this.findViewById(R.id.tv_audios_size).setVisibility(View.VISIBLE);
                        SpaceManagerActivity.this.findViewById(R.id.tv_audios_count).setVisibility(View.VISIBLE);
                        SpaceManagerActivity.this.findViewById(R.id.pbar_audio_count).setVisibility(View.GONE);
                        TextView textView = SpaceManagerActivity.this.findViewById(R.id.tv_audios_size);
                        StringBuilder stringBuilder = new StringBuilder();
                        String str = "";
                        stringBuilder.append(str);
                        stringBuilder.append(Util.convertBytes(mediaList.totalSize));
                        textView.setText(stringBuilder.toString());
                        textView = SpaceManagerActivity.this.findViewById(R.id.tv_audios_count);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str);
                        stringBuilder.append(mediaList.arrContents.size());
                        String str2 = " ";
                        stringBuilder.append(str2);
                        stringBuilder.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                        textView.setText(stringBuilder.toString());
                        SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
                        spaceManagerActivity.completedTask = spaceManagerActivity.completedTask + 1;
                        SpaceManagerActivity.this.m.addAll(mediaList.arrContents);
                        if (SpaceManagerActivity.this.completedTask == 6) {
                            SpaceManagerActivity.this.updateTotalRecoverable();
                            SpaceManagerActivity spaceManagerActivity2 = SpaceManagerActivity.this;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(SpaceManagerActivity.this.title);
                            stringBuilder2.append(" All Files");
                            MediaList mediaList = new MediaList(spaceManagerActivity2, stringBuilder2.toString(), FileTypes.ALL);
                            mediaList.fetchAllFiles(SpaceManagerActivity.this.m);
                            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(str);
                            stringBuilder3.append(Util.convertBytes(mediaList.totalSize));
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(str);
                            stringBuilder3.append(mediaList.arrContents.size());
                            stringBuilder3.append(str2);
                            stringBuilder3.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
                            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                                SpaceManagerActivity spaceManagerActivity3 = SpaceManagerActivity.this;
                                spaceManagerActivity3.suggestionListAdapter = new SuggestionListAdapter(spaceManagerActivity3.m, mediaList);
                                SpaceManagerActivity.this.rv_suggestion.setLayoutManager(new LinearLayoutManager(SpaceManagerActivity.this.context));
                                SpaceManagerActivity.this.rv_suggestion.setAdapter(SpaceManagerActivity.this.suggestionListAdapter);
                                SpaceManagerActivity.this.invalidateOptionsMenu();
                            }
                        }
                    }
                });
            }
        }
    }

    public class DocCalculation extends Thread {
        public void run() {
            SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(SpaceManagerActivity.this.title);
            stringBuilder.append(" Documents");
            final MediaList mediaList = new MediaList(spaceManagerActivity, stringBuilder.toString(), FileTypes.Document);
            mediaList.fetchFilesForExtns(0, SpaceManagerActivity.this.hmExtnDocs);
            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                SpaceManagerActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        SpaceManagerActivity.this.findViewById(R.id.tv_documents_size).setVisibility(View.VISIBLE);
                        SpaceManagerActivity.this.findViewById(R.id.tv_documents_count).setVisibility(View.VISIBLE);
                        SpaceManagerActivity.this.findViewById(R.id.pbar_docs_count).setVisibility(View.GONE);
                        TextView textView = SpaceManagerActivity.this.findViewById(R.id.tv_documents_size);
                        StringBuilder stringBuilder = new StringBuilder();
                        String str = "";
                        stringBuilder.append(str);
                        stringBuilder.append(Util.convertBytes(mediaList.totalSize));
                        textView.setText(stringBuilder.toString());
                        textView = SpaceManagerActivity.this.findViewById(R.id.tv_documents_count);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str);
                        stringBuilder.append(mediaList.arrContents.size());
                        String str2 = " ";
                        stringBuilder.append(str2);
                        stringBuilder.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                        textView.setText(stringBuilder.toString());
                        SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
                        spaceManagerActivity.completedTask = spaceManagerActivity.completedTask + 1;
                        SpaceManagerActivity.this.m.addAll(mediaList.arrContents);
                        if (SpaceManagerActivity.this.completedTask == 6) {
                            SpaceManagerActivity.this.updateTotalRecoverable();
                            SpaceManagerActivity spaceManagerActivity2 = SpaceManagerActivity.this;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(SpaceManagerActivity.this.title);
                            stringBuilder2.append(" All Files");
                            MediaList mediaList = new MediaList(spaceManagerActivity2, stringBuilder2.toString(), FileTypes.ALL);
                            mediaList.fetchAllFiles(SpaceManagerActivity.this.m);
                            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(str);
                            stringBuilder3.append(Util.convertBytes(mediaList.totalSize));
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(str);
                            stringBuilder3.append(mediaList.arrContents.size());
                            stringBuilder3.append(str2);
                            stringBuilder3.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
                            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                                SpaceManagerActivity spaceManagerActivity3 = SpaceManagerActivity.this;
                                spaceManagerActivity3.suggestionListAdapter = new SuggestionListAdapter(spaceManagerActivity3.m, mediaList);
                                SpaceManagerActivity.this.rv_suggestion.setLayoutManager(new LinearLayoutManager(SpaceManagerActivity.this.context));
                                SpaceManagerActivity.this.rv_suggestion.setAdapter(SpaceManagerActivity.this.suggestionListAdapter);
                                SpaceManagerActivity.this.invalidateOptionsMenu();
                            }
                        }
                    }
                });
            }
        }
    }

    public class DownloadsCalculation extends Thread {
        public void run() {
            PhoneCleaner.getInstance().downloadsData = new DownloadsData(SpaceManagerActivity.this);
            PhoneCleaner.getInstance().downloadsData.getDownloadedFiles(SpaceManagerActivity.this, new DownloadDataFetchedListener() {
                public void a(int i, long j) {
                    SpaceManagerActivity.this.tvdownCount.setVisibility(View.VISIBLE);
                    SpaceManagerActivity.this.tvdownSize.setVisibility(View.VISIBLE);
                    SpaceManagerActivity.this.findViewById(R.id.pbar_downloads_count).setVisibility(View.GONE);
                    TextView e = SpaceManagerActivity.this.tvdownCount;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(i);
                    stringBuilder.append(" ");
                    stringBuilder.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                    e.setText(stringBuilder.toString());
                    SpaceManagerActivity.this.tvdownSize.setText(Util.convertBytes(j));
                }

                public void onFetched(int i, long j) {
                    SpaceManagerActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            SpaceManagerActivity.this.tvdownCount.setVisibility(View.VISIBLE);
                            SpaceManagerActivity.this.tvdownSize.setVisibility(View.VISIBLE);
                            SpaceManagerActivity.this.findViewById(R.id.pbar_downloads_count).setVisibility(View.GONE);
                            TextView e = SpaceManagerActivity.this.tvdownCount;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(i);
                            stringBuilder.append(" ");
                            stringBuilder.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                            e.setText(stringBuilder.toString());
                            SpaceManagerActivity.this.tvdownSize.setText(Util.convertBytes(j));
                        }
                    });
                }
            });
        }
    }

    public class ImageCalculation extends Thread {
        public void run() {
            SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(SpaceManagerActivity.this.title);
            stringBuilder.append(" Images");
            final MediaList mediaList = new MediaList(spaceManagerActivity, stringBuilder.toString(), FileTypes.Image);
            mediaList.fetchImages();
            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                SpaceManagerActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        SpaceManagerActivity.this.findViewById(R.id.tv_images_size).setVisibility(View.VISIBLE);
                        SpaceManagerActivity.this.findViewById(R.id.tv_images_count).setVisibility(View.VISIBLE);
                        SpaceManagerActivity.this.findViewById(R.id.pbar_photos_count).setVisibility(View.GONE);
                        TextView textView = (TextView) SpaceManagerActivity.this.findViewById(R.id.tv_images_size);
                        StringBuilder stringBuilder = new StringBuilder();
                        String str = "";
                        stringBuilder.append(str);
                        stringBuilder.append(Util.convertBytes(mediaList.totalSize));
                        textView.setText(stringBuilder.toString());
                        textView = (TextView) SpaceManagerActivity.this.findViewById(R.id.tv_images_count);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str);
                        stringBuilder.append(mediaList.arrContents.size());
                        String str2 = " ";
                        stringBuilder.append(str2);
                        stringBuilder.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                        textView.setText(stringBuilder.toString());
                        SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
                        spaceManagerActivity.completedTask = spaceManagerActivity.completedTask + 1;
                        SpaceManagerActivity.this.m.addAll(mediaList.arrContents);
                        if (SpaceManagerActivity.this.completedTask == 6) {
                            SpaceManagerActivity.this.updateTotalRecoverable();
                            SpaceManagerActivity spaceManagerActivity2 = SpaceManagerActivity.this;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(SpaceManagerActivity.this.title);
                            stringBuilder2.append(" All Files");
                            MediaList mediaList = new MediaList(spaceManagerActivity2, stringBuilder2.toString(), FileTypes.ALL);
                            mediaList.fetchAllFiles(SpaceManagerActivity.this.m);
                            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(str);
                            stringBuilder3.append(Util.convertBytes(mediaList.totalSize));
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(str);
                            stringBuilder3.append(mediaList.arrContents.size());
                            stringBuilder3.append(str2);
                            stringBuilder3.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
                            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                                SpaceManagerActivity spaceManagerActivity3 = SpaceManagerActivity.this;
                                spaceManagerActivity3.suggestionListAdapter = new SuggestionListAdapter(spaceManagerActivity3.m, mediaList);
                                SpaceManagerActivity.this.rv_suggestion.setLayoutManager(new LinearLayoutManager(SpaceManagerActivity.this.context));
                                SpaceManagerActivity.this.rv_suggestion.setAdapter(SpaceManagerActivity.this.suggestionListAdapter);
                                SpaceManagerActivity.this.invalidateOptionsMenu();
                            }
                        }
                    }
                });
            }
        }
    }

    public class OtherCalculation extends Thread {
        public void run() {
            SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(SpaceManagerActivity.this.title);
            stringBuilder.append(" Others");
            final MediaList mediaList = new MediaList(spaceManagerActivity, stringBuilder.toString(), FileTypes.Others);
            mediaList.fetchFilesForNotInExtns(0, SpaceManagerActivity.this.hmExtnsOtherMediaAndDocs);
            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                SpaceManagerActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        StringBuilder stringBuilder = new StringBuilder();
                        String str = "";
                        stringBuilder.append(str);
                        stringBuilder.append(Util.convertBytes(mediaList.totalSize));
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(str);
                        stringBuilder2.append(mediaList.arrContents.size());
                        String str2 = " ";
                        stringBuilder2.append(str2);
                        stringBuilder2.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                        SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
                        spaceManagerActivity.completedTask = spaceManagerActivity.completedTask + 1;
                        SpaceManagerActivity.this.m.addAll(mediaList.arrContents);
                        if (SpaceManagerActivity.this.completedTask == 6) {
                            SpaceManagerActivity.this.updateTotalRecoverable();
                            SpaceManagerActivity spaceManagerActivity2 = SpaceManagerActivity.this;
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(SpaceManagerActivity.this.title);
                            stringBuilder3.append(" All Files");
                            MediaList mediaList = new MediaList(spaceManagerActivity2, stringBuilder3.toString(), FileTypes.ALL);
                            mediaList.fetchAllFiles(SpaceManagerActivity.this.m);
                            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
                            StringBuilder stringBuilder4 = new StringBuilder();
                            stringBuilder4.append(str);
                            stringBuilder4.append(Util.convertBytes(mediaList.totalSize));
                            stringBuilder4 = new StringBuilder();
                            stringBuilder4.append(str);
                            stringBuilder4.append(mediaList.arrContents.size());
                            stringBuilder4.append(str2);
                            stringBuilder4.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
                            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                                SpaceManagerActivity spaceManagerActivity3 = SpaceManagerActivity.this;
                                spaceManagerActivity3.suggestionListAdapter = new SuggestionListAdapter(spaceManagerActivity3.m, mediaList);
                                SpaceManagerActivity.this.rv_suggestion.setLayoutManager(new LinearLayoutManager(SpaceManagerActivity.this.context));
                                SpaceManagerActivity.this.rv_suggestion.setAdapter(SpaceManagerActivity.this.suggestionListAdapter);
                                SpaceManagerActivity.this.invalidateOptionsMenu();
                            }
                        }
                    }
                });
            }
        }
    }

    public class VideoCalculation extends Thread {
        public void run() {
            SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(SpaceManagerActivity.this.title);
            stringBuilder.append(" Videos");
            final MediaList mediaList = new MediaList(spaceManagerActivity, stringBuilder.toString(), FileTypes.Video);
            mediaList.fetchVideos();
            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                SpaceManagerActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        SpaceManagerActivity.this.findViewById(R.id.tv_videos_size).setVisibility(View.VISIBLE);
                        SpaceManagerActivity.this.findViewById(R.id.tv_videos_count).setVisibility(View.VISIBLE);
                        SpaceManagerActivity.this.findViewById(R.id.pbar_videos_count).setVisibility(View.GONE);
                        TextView textView = (TextView) SpaceManagerActivity.this.findViewById(R.id.tv_videos_size);
                        StringBuilder stringBuilder = new StringBuilder();
                        String str = "";
                        stringBuilder.append(str);
                        stringBuilder.append(Util.convertBytes(mediaList.totalSize));
                        textView.setText(stringBuilder.toString());
                        textView = (TextView) SpaceManagerActivity.this.findViewById(R.id.tv_videos_count);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str);
                        stringBuilder.append(mediaList.arrContents.size());
                        String str2 = " ";
                        stringBuilder.append(str2);
                        stringBuilder.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                        textView.setText(stringBuilder.toString());
                        SpaceManagerActivity spaceManagerActivity = SpaceManagerActivity.this;
                        spaceManagerActivity.completedTask = spaceManagerActivity.completedTask + 1;
                        SpaceManagerActivity.this.m.addAll(mediaList.arrContents);
                        if (SpaceManagerActivity.this.completedTask == 6) {
                            SpaceManagerActivity.this.updateTotalRecoverable();
                            SpaceManagerActivity spaceManagerActivity2 = SpaceManagerActivity.this;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(SpaceManagerActivity.this.title);
                            stringBuilder2.append(" All Files");
                            MediaList mediaList = new MediaList(spaceManagerActivity2, stringBuilder2.toString(), FileTypes.ALL);
                            mediaList.fetchAllFiles(SpaceManagerActivity.this.m);
                            SpaceManagerActivity.this.fileMedia.arrContents.add(mediaList);
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(str);
                            stringBuilder3.append(Util.convertBytes(mediaList.totalSize));
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(str);
                            stringBuilder3.append(mediaList.arrContents.size());
                            stringBuilder3.append(str2);
                            stringBuilder3.append(SpaceManagerActivity.this.getString(R.string.file_manage_items));
                            SpaceManagerActivity.this.fileMedia.updateHashMapFileTypeToMediaList();
                            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.clear();
                                PhoneCleaner.getInstance().spaceManagerModule.arrContents.add(SpaceManagerActivity.this.fileMedia);
                                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                                SpaceManagerActivity spaceManagerActivity3 = SpaceManagerActivity.this;
                                spaceManagerActivity3.suggestionListAdapter = new SuggestionListAdapter(spaceManagerActivity3.m, mediaList);
                                SpaceManagerActivity.this.rv_suggestion.setLayoutManager(new LinearLayoutManager(SpaceManagerActivity.this.context));
                                SpaceManagerActivity.this.rv_suggestion.setAdapter(SpaceManagerActivity.this.suggestionListAdapter);
                                SpaceManagerActivity.this.invalidateOptionsMenu();
                            }
                        }
                    }
                });
            }
        }
    }

    public class SuggestionListAdapter extends Adapter<SuggestionListAdapter.MyViewHolder> implements Filterable {
        public ArrayList<BigSizeFilesWrapper> a;
        public ArrayList<BigSizeFilesWrapper> b;
        public ValueFilter c;
        public MediaList d;

        public class ValueFilter extends Filter {
            public FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                if (charSequence == null || charSequence.length() <= 0) {
                    filterResults.count = SuggestionListAdapter.this.a.size();
                    filterResults.values = SuggestionListAdapter.this.a;
                } else {
                    ArrayList arrayList = new ArrayList();
                    Iterator it = SuggestionListAdapter.this.a.iterator();
                    while (it.hasNext()) {
                        BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) it.next();
                        if (bigSizeFilesWrapper.name.toLowerCase().contains(charSequence.toString().toLowerCase())) {
                            arrayList.add(bigSizeFilesWrapper);
                        }
                    }
                    filterResults.count = arrayList.size();
                    filterResults.values = arrayList;
                    String h = SpaceManagerActivity.this.TAG;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("--------------filterResults.count------------");
                    stringBuilder.append(filterResults.count);
                }
                return filterResults;
            }

            public void publishResults(CharSequence charSequence, FilterResults filterResults) {
                if (filterResults.count == 0) {
                    SpaceManagerActivity.this.tv_no_result_found.setVisibility(View.VISIBLE);
                } else {
                    SpaceManagerActivity.this.tv_no_result_found.setVisibility(View.GONE);
                }
                SuggestionListAdapter suggestionListAdapter = SuggestionListAdapter.this;
                suggestionListAdapter.b = (ArrayList) filterResults.values;
                SpaceManagerActivity.this.suggestionListAdapter.notifyDataSetChanged();
            }
        }

        public class MyViewHolder extends ViewHolder {
            public ImageView iv_suggestion_list_icon;
            public TextView tv_suggestion_list_date;
            public TextView tv_suggestion_list_name;
            public TextView tv_suggestion_list_size;

            public MyViewHolder(@NonNull SuggestionListAdapter suggestionListAdapter, View view) {
                super(view);
                this.tv_suggestion_list_name = view.findViewById(R.id.tv_suggestion_list_name);
                this.tv_suggestion_list_size = view.findViewById(R.id.tv_suggestion_list_size);
                this.iv_suggestion_list_icon = view.findViewById(R.id.iv_suggestion_list_icon);
                this.tv_suggestion_list_date = view.findViewById(R.id.tv_suggestion_list_date);
            }
        }

        public SuggestionListAdapter(ArrayList<BigSizeFilesWrapper> arrayList, MediaList mediaList) {
            this.d = mediaList;
            this.a = arrayList;
            this.b = arrayList;
        }

        public void a(BigSizeFilesWrapper bigSizeFilesWrapper, View view) {
            try {
                SpaceManagerActivity.this.openFile(SpaceManagerActivity.this, new File(bigSizeFilesWrapper.path));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public Filter getFilter() {
            if (this.c == null) {
                this.c = new ValueFilter();
            }
            return this.c;
        }

        public int getItemCount() {
            return this.b.size();
        }

        public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
            BigSizeFilesWrapper bigSizeFilesWrapper = this.b.get(i);
            myViewHolder.tv_suggestion_list_name.setText(bigSizeFilesWrapper.name);
            TextView b = myViewHolder.tv_suggestion_list_size;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(Util.convertBytes(bigSizeFilesWrapper.size));
            b.setText(stringBuilder.toString());
            myViewHolder.tv_suggestion_list_date.setText(new SimpleDateFormat("MMM dd,yyyy, hh:mm aaa").format(new Date(bigSizeFilesWrapper.dateTaken)));
            FileTypes fileTypes = this.d.mediaType;
            if (fileTypes == FileTypes.Audio) {
                myViewHolder.iv_suggestion_list_icon.setImageBitmap(BitmapFactory.decodeResource(SpaceManagerActivity.this.getResources(), R.drawable.ic_audio));
            } else if (fileTypes == FileTypes.Others) {
                myViewHolder.iv_suggestion_list_icon.setImageBitmap(BitmapFactory.decodeResource(SpaceManagerActivity.this.getResources(), R.mipmap.ic_launcher));
            } else if (fileTypes == FileTypes.Document) {
                myViewHolder.iv_suggestion_list_icon.setImageBitmap(BitmapFactory.decodeResource(SpaceManagerActivity.this.getResources(), R.drawable.ic_documents));
            } else if (fileTypes == FileTypes.APK) {
                myViewHolder.iv_suggestion_list_icon.setImageBitmap(BitmapFactory.decodeResource(SpaceManagerActivity.this.getResources(), R.drawable.ic_apk));
            } else {
                Bitmap a = SpaceManagerActivity.this.getBitmapFromExt(FilenameUtils.getExtension(bigSizeFilesWrapper.path));
                if (a == null) {
                    Glide.with(SpaceManagerActivity.this).load(new File(bigSizeFilesWrapper.path)).placeholder(R.drawable.broken_drawable).error(R.mipmap.ic_launcher).centerCrop().into(myViewHolder.iv_suggestion_list_icon);
                } else {
                    myViewHolder.iv_suggestion_list_icon.setImageBitmap(a);
                }
            }
            myViewHolder.itemView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {

                        }
                    };
                }
            });
        }

        @NonNull
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new MyViewHolder(this, LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.file_suggestion_list, viewGroup, false));
        }
    }

    private void executeThreads() {
        PhoneCleaner.getInstance().spaceManagerModule = null;
        PhoneCleaner.getInstance().spaceManagerModule = new FileManagerModule();
        invalidateOptionsMenu();
        findViewById(R.id.tv_images_size).setVisibility(View.INVISIBLE);
        findViewById(R.id.tv_images_count).setVisibility(View.GONE);
        findViewById(R.id.pbar_photos_count).setVisibility(View.VISIBLE);
        findViewById(R.id.tv_videos_size).setVisibility(View.INVISIBLE);
        findViewById(R.id.tv_videos_count).setVisibility(View.GONE);
        findViewById(R.id.pbar_videos_count).setVisibility(View.VISIBLE);
        findViewById(R.id.tv_audios_size).setVisibility(View.INVISIBLE);
        findViewById(R.id.tv_audios_count).setVisibility(View.GONE);
        findViewById(R.id.pbar_audio_count).setVisibility(View.VISIBLE);
        findViewById(R.id.tv_documents_count).setVisibility(View.GONE);
        findViewById(R.id.tv_documents_size).setVisibility(View.INVISIBLE);
        findViewById(R.id.pbar_docs_count).setVisibility(View.VISIBLE);
        findViewById(R.id.tv_apk_size).setVisibility(View.INVISIBLE);
        findViewById(R.id.tv_apk_count).setVisibility(View.GONE);
        findViewById(R.id.pbar_apk_count).setVisibility(View.VISIBLE);
        findViewById(R.id.tv_downloads_size).setVisibility(View.INVISIBLE);
        findViewById(R.id.tv_downloads_count).setVisibility(View.GONE);
        findViewById(R.id.pbar_downloads_count).setVisibility(View.VISIBLE);

        String str = "Big ";
        this.title = str;
        this.fileMedia = new FileMedia(str);
        this.m = new ArrayList();
        this.imagecalculation = new ImageCalculation();
        this.videoCalculation = new VideoCalculation();
        this.audioCalculation = new AudioCalculation();
        this.docCalculation = new DocCalculation();
        this.otherCalculation = new OtherCalculation();
        this.apkCalculation = new ApkCalculation();
        this.downloadsCalculation = new DownloadsCalculation();
        ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(7);
        this.executorService = newFixedThreadPool;
        newFixedThreadPool.execute(this.imagecalculation);
        this.executorService.execute(this.videoCalculation);
        this.executorService.execute(this.audioCalculation);
        this.executorService.execute(this.docCalculation);
        this.executorService.execute(this.otherCalculation);
        this.executorService.execute(this.apkCalculation);
        this.executorService.execute(this.downloadsCalculation);
    }

    private Bitmap getBitmapFromExt(String str) {
        String str2 = str;
        if (str2 == null) {
            return BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
        }
        if (Arrays.asList(new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"}).contains(str2)) {
            return BitmapFactory.decodeResource(getResources(), R.drawable.ic_documents);
        }
        if (Arrays.asList(new String[]{"mp3", "aac", "m4a", "wav"}).contains(str2)) {
            return BitmapFactory.decodeResource(getResources(), R.drawable.ic_audio);
        }
        return str2.equalsIgnoreCase("apk") ? BitmapFactory.decodeResource(getResources(), R.drawable.ic_apk) : null;
    }

    private void init() {
        this.tv_allSpace = findViewById(R.id.cpucollerfirst_temp);
        this.t_cpuuses = findViewById(R.id.cpucoolerfirst_usage);
        TextView textView = findViewById(R.id.toolbar_title);
        this.t_unit = findViewById(R.id.symboltext);
        this.t_text = findViewById(R.id.symbol);
        this.rv_suggestion = findViewById(R.id.rv_suggestion);
        this.tv_no_result_found = findViewById(R.id.tv_no_result_found);
        this.hiddenPermissionLayout = findViewById(R.id.hiddenpermissionlayout);
        String str = this.from;
        boolean z = str != null && str.equalsIgnoreCase("TB");
        this.fromToolBox = z;
        if (z) {
            textView.setText(R.string.module_file_manager);
        }
        this.tvdownCount = findViewById(R.id.tv_downloads_count);
        this.tvdownSize = findViewById(R.id.tv_downloads_size);
        this.sharedPrefUtil = new SharedPrefUtil(this);
        findViewById(R.id.iv_permission_close_btn).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                SpaceManagerActivity.this.finish();
            }
        });
    }

    private void listeners() {
        Util.appendLogphonecleaner(this.TAG, "listeners()>>>>>>>>> Calling ", GlobalData.FILE_NAME);
        findViewById(R.id.ll_audios).setOnClickListener(this);
        findViewById(R.id.ll_documents).setOnClickListener(this);
        findViewById(R.id.ll_images).setOnClickListener(this);
        findViewById(R.id.ll_apk_files).setOnClickListener(this);
        findViewById(R.id.ll_downloads).setOnClickListener(this);
        findViewById(R.id.ll_videos).setOnClickListener(this);
    }

    private void makeHashMapExtnApks() {
        String[] strArr = new String[]{"apk"};
        this.hmExtnApk = new HashMap(1);
        for (int i = 0; i < 1; i++) {
            this.hmExtnApk.put(strArr[i].toLowerCase(), Boolean.valueOf(true));
        }
    }

    private void makeHashMapExtnDocs() {
        String[] strArr = new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"};
        this.hmExtnDocs = new HashMap(31);
        for (int i = 0; i < 31; i++) {
            this.hmExtnDocs.put(strArr[i].toLowerCase(), Boolean.valueOf(true));
        }
    }

    private void makeHashMapExtnsOtherMediaAndDocs() {
        String[] strArr = new String[]{"mp4", "3gp", "avi", "mpeg", "jpeg", "jpg", "png", "gif", "mp3", "tiff", "tif", "bmp", "svg", "webp", "webm", "flv", "wmv", "f4v", "swf", "asf", "ts", "mkv", "pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "aac", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm", "db", "ogg", "m4a", "wav", "wma", "mmf", "mp2", "flac", "au", "ac3", "mpg", "mov", "apk"};
        this.hmExtnsOtherMediaAndDocs = new HashMap();
        for (int i = 0; i < 67; i++) {
            this.hmExtnsOtherMediaAndDocs.put(strArr[i].toLowerCase(), Boolean.valueOf(true));
        }
    }

    private void noDataFoundScreen(String str) {
        Intent intent = new Intent(this, FinalScreen.class);
        intent.putExtra("DATA", str);
        intent.putExtra("TYPE", "NODOWNLOAD");
        if (this.redirectToNoti) {
            intent.putExtra(GlobalData.REDIRECTNOTI, false);
        }
        startActivity(intent);
        this.context = null;
    }

    @SuppressLint("WrongConstant")
    private void openFile(Context context, File file) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setFlags(335544320);
        intent.addFlags(1);
        Uri uriForFile = FileProvider.getUriForFile(context, "com.esc.phoneheart.fileprovider", file);
        String mimeType = Util.getMimeType(file.getAbsolutePath());
        if (mimeType != null) {
            intent.setDataAndType(uriForFile, mimeType);
        } else if (file.toString().contains(".doc") || file.toString().contains(".docx")) {
            intent.setDataAndType(uriForFile, "application/msword");
        } else if (file.toString().contains(".pdf")) {
            intent.setDataAndType(uriForFile, "application/pdf");
        } else if (file.toString().contains(".ppt") || file.toString().contains(".pptx")) {
            intent.setDataAndType(uriForFile, "application/vnd.ms-powerpoint");
        } else if (file.toString().contains(".xls") || file.toString().contains(".xlsx")) {
            intent.setDataAndType(uriForFile, "application/vnd.ms-excel");
        } else if (file.toString().contains(".zip") || file.toString().contains(".rar")) {
            intent.setDataAndType(uriForFile, "application/x-wav");
        } else if (file.toString().contains(".rtf")) {
            intent.setDataAndType(uriForFile, "application/rtf");
        } else if (file.toString().contains(".wav") || file.toString().contains(".mp3")) {
            intent.setDataAndType(uriForFile, "audio/*");
        } else if (file.toString().contains(".gif")) {
            intent.setDataAndType(uriForFile, "image/gif");
        } else if (file.toString().contains(".jpg") || file.toString().contains(".jpeg") || file.toString().contains(".png")) {
            intent.setDataAndType(uriForFile, "image/*");
        } else if (file.toString().contains(".txt")) {
            intent.setDataAndType(uriForFile, "text/plain");
        } else if (file.toString().contains(".3gp") || file.toString().contains(".mpg") || file.toString().contains(".mpeg") || file.toString().contains(".mpe") || file.toString().contains(".mp4") || file.toString().contains(".avi")) {
            intent.setDataAndType(uriForFile, "video/*");
        } else if (file.toString().contains(".apk")) {
            intent.setDataAndType(uriForFile, "application/vnd.android.package-archive");
        } else {
            intent.setDataAndType(uriForFile, "*/*");
        }
        try {
            Util.appendLogphonecleaner(this.TAG, "openFile try block", GlobalData.FILE_NAME);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            String str = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("openFile catch block");
            stringBuilder.append(e.getMessage());
            Util.appendLogphonecleaner(str, stringBuilder.toString(), GlobalData.FILE_NAME);
            Toast.makeText(context, getString(R.string.unableToOpenFile), Toast.LENGTH_LONG).show();
        }
    }

    private boolean permissionForStorageGiven() {
        Util.appendLogphonecleaner(this.TAG, "permissionForStorageGiven()>>>>>>>>> Calling ", GlobalData.FILE_NAME);
        return VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == 0;
    }

    private void redirectToNoti() {
        this.redirectToNoti = getIntent().getBooleanExtra(GlobalData.REDIRECTNOTI, false);
        this.noti_result_back = getIntent().getBooleanExtra(GlobalData.NOTI_RESULT_BACK, false);
        getIntent().getBooleanExtra(GlobalData.HEADER_NOTI_TRACK, false);
    }

    private void showFileGridScreen() {
        Intent intent = new Intent(this, FilesGridScreen.class);
        intent.putExtra("fromToolBox", this.fromToolBox);
        if (this.redirectToNoti) {
            intent.putExtra(GlobalData.REDIRECTNOTI, false);
        }
        startActivity(intent);
        this.context = null;
        Util.appendLogphonecleaner(this.TAG, "View_Image Button click>>>>>>>>> Calling ", GlobalData.FILE_NAME);
    }

    private void updateTotalRecoverable() {
        if (PhoneCleaner.getInstance().spaceManagerModule != null) {
            String[] split = Util.convertBytes(PhoneCleaner.getInstance().spaceManagerModule.totalSize).split(" ");
            TextView textView = this.tv_allSpace;
            StringBuilder stringBuilder = new StringBuilder();
            String str = "";
            stringBuilder.append(str);
            stringBuilder.append(split[0]);
            textView.setText(stringBuilder.toString());
            textView = this.t_unit;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(split[1]);
            textView.setText(stringBuilder.toString());
        }
    }

    public void onBackPressed() {
        PhoneCleaner.getInstance().socialModule = null;
        PhoneCleaner.getInstance().spaceManagerModule = null;
        System.runFinalization();
        Runtime.getRuntime().gc();
        System.gc();
        super.onBackPressed();
    }

    public void onClick(View view) {
        String str = GlobalData.REDIRECTNOTI;
        String str2 = "fromToolBox";
        Intent intent;

        String str3 = "View_Image Button click>>>>>>>>> Calling ";

        switch (view.getId())
        {
            case R.id.iv_back:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 100;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    startActivity(new Intent(SpaceManagerActivity.this, HomeActivity.class));
                    finish();
                }
            break;

            case R.id.ll_apk_files:

                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 106;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    if (!doubleClicked() && findViewById(R.id.pbar_apk_count).getVisibility() != View.VISIBLE) {
                        PhoneCleaner.getInstance().spaceManagerModule.currentList = this.fileMedia.hmFileTypeToMediaList.get(Integer.valueOf(FileTypes.APK.ordinal()));
                        try {
                            this.mediasList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                        showFileGridScreen();
                    }
                }
                return;
            case R.id.ll_audios:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 103;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    if (!doubleClicked() && findViewById(R.id.pbar_audio_count).getVisibility() != View.VISIBLE) {
                        PhoneCleaner.getInstance().spaceManagerModule.currentList = this.fileMedia.hmFileTypeToMediaList.get(Integer.valueOf(FileTypes.Audio.ordinal()));
                        try {
                            this.mediasList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
                        } catch (Exception e22) {
                            e22.printStackTrace();
                        }
                        intent = new Intent(this, FilesGridScreen.class);
                        intent.putExtra(str2, this.fromToolBox);
                        if (this.redirectToNoti) {
                            intent.putExtra(str, false);
                        }
                        startActivity(intent);
                        this.context = null;
                        Util.appendLogphonecleaner(this.TAG, "View_Audio Button click>>>>>>>>> Calling ", GlobalData.FILE_NAME);
                    }
                }
                return;
            case R.id.ll_documents:

                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 104;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    if (!doubleClicked() && findViewById(R.id.pbar_docs_count).getVisibility() != View.VISIBLE) {
                        PhoneCleaner.getInstance().spaceManagerModule.currentList = this.fileMedia.hmFileTypeToMediaList.get(Integer.valueOf(FileTypes.Document.ordinal()));
                        try {
                            this.mediasList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
                        } catch (Exception e222) {
                            e222.printStackTrace();
                        }
                        intent = new Intent(this, FilesGridScreen.class);
                        intent.putExtra(str2, this.fromToolBox);
                        if (this.redirectToNoti) {
                            intent.putExtra(str, false);
                        }
                        startActivity(intent);
                        this.context = null;
                        Util.appendLogphonecleaner(this.TAG, "View_Documents Button click>>>>>>>>> Calling ", GlobalData.FILE_NAME);
                    }
                }
                return;
            case R.id.ll_downloads:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 105;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    if (!doubleClicked() && findViewById(R.id.pbar_downloads_count).getVisibility() != View.VISIBLE) {
                        startActivity(new Intent(this, DownloadsScreen.class));
                    }
                }
                return;
            case R.id.ll_images:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 101;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    if (!doubleClicked() && findViewById(R.id.pbar_photos_count).getVisibility() != View.VISIBLE) {
                        PhoneCleaner.getInstance().spaceManagerModule.currentList = this.fileMedia.hmFileTypeToMediaList.get(Integer.valueOf(FileTypes.Image.ordinal()));
                        try {
                            this.mediasList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
                        } catch (Exception e22) {
                            e22.printStackTrace();
                        }
                        intent = new Intent(this, FilesGridScreen.class);
                        intent.putExtra(str2, this.fromToolBox);
                        if (this.redirectToNoti) {
                            intent.putExtra(str, false);
                        }
                        startActivity(intent);
                        this.context = null;
                        Util.appendLogphonecleaner(this.TAG, str3, GlobalData.FILE_NAME);
                    }
                }
                return;

            case R.id.ll_videos:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 102;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    if (!doubleClicked() && findViewById(R.id.pbar_videos_count).getVisibility() != View.VISIBLE) {
                        PhoneCleaner.getInstance().spaceManagerModule.currentList = this.fileMedia.hmFileTypeToMediaList.get(Integer.valueOf(FileTypes.Video.ordinal()));
                        this.mediasList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
                        intent = new Intent(this, FilesGridScreen.class);
                        intent.putExtra(str2, this.fromToolBox);
                        if (this.redirectToNoti) {
                            intent.putExtra(str, false);
                        }
                        startActivity(intent);
                        this.context = null;
                        Util.appendLogphonecleaner(this.TAG, str3, GlobalData.FILE_NAME);
                        Util.appendLogphonecleaner(this.TAG, "View_Videos Button click>>>>>>>>> Calling ", GlobalData.FILE_NAME);
                    }
                }
                return;
        }

    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.context = this;
        GlobalData.SETAPPLAnguage(this);
        setContentView(R.layout.activity_space_manager);
        makeHashMapExtnDocs();
        makeHashMapExtnsOtherMediaAndDocs();
        makeHashMapExtnApks();
        GlobalData.fromSpacemanager = true;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(GlobalData.duplicacyDist);
        stringBuilder.append(" ");
        stringBuilder.append(GlobalData.duplicacyLevel);
        stringBuilder.append("  ");
        stringBuilder.append(GlobalData.duplicacyTime);

        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);

        super.requestAppPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, R.string.pcl_sdcard_permission, REQUEST_PERMISSIONS);
        init();
        BannerAds();
        loadAd();
        redirectToNoti();
        if (permissionForStorageGiven()) {
            listeners();
        }
        findViewById(R.id.rl_permission_close_btn).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (SpaceManagerActivity.this.redirectToNoti || SpaceManagerActivity.this.noti_result_back) {
                    Intent intent = new Intent(SpaceManagerActivity.this, HomeActivity.class);
                    SpaceManagerActivity.this.finish();
                    SpaceManagerActivity.this.startActivity(intent);
                    return;
                }
                SpaceManagerActivity.this.finish();
            }
        });
        this.hiddenPermissionLayout.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });
        PermissionLayout();
        new SharedPrefUtil(this).saveLastTimeUsed(SharedPrefUtil.LUSED_SPACE_MANAGER, System.currentTimeMillis());

    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }

    public void onPermissionsGranted(int i) {
        RelativeLayout relativeLayout = this.hiddenPermissionLayout;
        if (relativeLayout != null) {
            relativeLayout.setVisibility(View.GONE);
            listeners();
            if (!this.isExecuting) {
                executeThreads();
            }
            Util.appendLogphonecleaner(this.TAG, "onPermissionsGranted()>>>>>>>>>GetLargeFilesData().execute() Calling ", GlobalData.FILE_NAME);
        }
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr,
                                           @NonNull int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    public void onResume() {
        String str;
        StringBuilder stringBuilder;
        super.onResume();
        String str2 = "issue.txt";
        if (GlobalData.returnedAfterDeletion) {
            str = this.TAG;
            stringBuilder = new StringBuilder();
            stringBuilder.append(" returned ");
            stringBuilder.append(GlobalData.returnedAfterDeletion);
            Util.appendLogphonecleanerTest(str, stringBuilder.toString(), str2);
            this.completedTask = 0;
            executeThreads();
            GlobalData.returnedAfterDeletion = false;
        }
        if (GlobalData.proceededToAd) {
            str = this.TAG;
            stringBuilder = new StringBuilder();
            stringBuilder.append(" procedded true ");
            stringBuilder.append(GlobalData.proceededToAd);
            Util.appendLogphonecleanerTest(str, stringBuilder.toString(), str2);
            finish();
            return;
        }
        str = this.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append(" procedded false ");
        stringBuilder.append(GlobalData.proceededToAd);
        Util.appendLogphonecleanerTest(str, stringBuilder.toString(), str2);
        if (!this.isExecuting) {
            str = this.TAG;
            stringBuilder = new StringBuilder();
            stringBuilder.append(" isExecuting  ");
            stringBuilder.append(this.isExecuting);
            Util.appendLogphonecleanerTest(str, stringBuilder.toString(), str2);
            if (PhoneCleaner.getInstance().spaceManagerModule != null) {
                PhoneCleaner.getInstance().spaceManagerModule.totalSize = 0;
                PhoneCleaner.getInstance().spaceManagerModule.updateSelf();
                updateTotalRecoverable();
            } else {
                RelativeLayout relativeLayout = this.hiddenPermissionLayout;
                if (relativeLayout != null && relativeLayout.getVisibility() == View.VISIBLE) {
                    if (permissionForStorageGiven()) {
                        listeners();
                        executeThreads();
                        this.hiddenPermissionLayout.setVisibility(View.GONE);
                    }
                }
            }
        }
        GlobalData.shouldContinue = true;
    }

    public void PermissionLayout() {
        if (permissionForStorageGiven()) {
            if (!this.isExecuting) {
                executeThreads();
            }
            RelativeLayout relativeLayout = this.hiddenPermissionLayout;
            if (relativeLayout != null) {
                relativeLayout.setVisibility(View.GONE);
                listeners();
            }
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(SpaceManagerActivity.this);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void loadAd() {

        interstitialAd = new InterstitialAd(SpaceManagerActivity.this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener()
        {
            String str = GlobalData.REDIRECTNOTI;
            String str2 = "fromToolBox";
            String str3 = "View_Image Button click>>>>>>>>> Calling ";
            Intent intent;

            @Override
            public void onAdClosed() {
                switch (id) {

                    case 100:
                        startActivity(new Intent(SpaceManagerActivity.this, HomeActivity.class));
                        finish();
                        break;

                    case 101:
                        if (!doubleClicked() && findViewById(R.id.pbar_photos_count).getVisibility() != View.VISIBLE) {
                            PhoneCleaner.getInstance().spaceManagerModule.currentList = (MediaList) fileMedia.hmFileTypeToMediaList.get(Integer.valueOf(FileTypes.Image.ordinal()));
                            try {
                                mediasList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
                            } catch (Exception e22) {
                                e22.printStackTrace();
                            }                            intent = new Intent(SpaceManagerActivity.this, FilesGridScreen.class);
                            intent.putExtra(str2, fromToolBox);
                            if (redirectToNoti) {
                                intent.putExtra(str, false);
                            }
                            startActivity(intent);
                            context = null;
                            Util.appendLogphonecleaner(TAG, str3, GlobalData.FILE_NAME);
                        }
                        break;
                    case 102:
                        if (!doubleClicked() && findViewById(R.id.pbar_videos_count).getVisibility() != View.VISIBLE) {
                            PhoneCleaner.getInstance().spaceManagerModule.currentList = fileMedia.hmFileTypeToMediaList.get(Integer.valueOf(FileTypes.Video.ordinal()));
                            mediasList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
                            intent = new Intent(SpaceManagerActivity.this, FilesGridScreen.class);
                            intent.putExtra(str2, fromToolBox);
                            if (redirectToNoti) {
                                intent.putExtra(str, false);
                            }
                            startActivity(intent);
                            context = null;
                            Util.appendLogphonecleaner(TAG, str3, GlobalData.FILE_NAME);
                            Util.appendLogphonecleaner(TAG, "View_Videos Button click>>>>>>>>> Calling ", GlobalData.FILE_NAME);
                        }
                        break;

                    case 103:
                        if (!doubleClicked() && findViewById(R.id.pbar_audio_count).getVisibility() != View.VISIBLE) {
                            PhoneCleaner.getInstance().spaceManagerModule.currentList = fileMedia.hmFileTypeToMediaList.get(Integer.valueOf(FileTypes.Audio.ordinal()));
                            try {
                                mediasList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
                            } catch (Exception e22) {
                                e22.printStackTrace();
                            }
                            intent = new Intent(SpaceManagerActivity.this, FilesGridScreen.class);
                            intent.putExtra(str2, fromToolBox);
                            if (redirectToNoti) {
                                intent.putExtra(str, false);
                            }
                            startActivity(intent);
                            context = null;
                            Util.appendLogphonecleaner(TAG, "View_Audio Button click>>>>>>>>> Calling ", GlobalData.FILE_NAME);
                        }
                        break;

                    case 104:
                        if (!doubleClicked() && findViewById(R.id.pbar_docs_count).getVisibility() != View.VISIBLE) {
                            PhoneCleaner.getInstance().spaceManagerModule.currentList = fileMedia.hmFileTypeToMediaList.get(Integer.valueOf(FileTypes.Document.ordinal()));
                            try {
                                mediasList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
                            } catch (Exception e222) {
                                e222.printStackTrace();
                            }
                            intent = new Intent(SpaceManagerActivity.this, FilesGridScreen.class);
                            intent.putExtra(str2, fromToolBox);
                            if (redirectToNoti) {
                                intent.putExtra(str, false);
                            }
                            startActivity(intent);
                            context = null;
                            Util.appendLogphonecleaner(TAG, "View_Documents Button click>>>>>>>>> Calling ", GlobalData.FILE_NAME);
                        }
                        break;

                    case 105:
                        if (!doubleClicked() && findViewById(R.id.pbar_downloads_count).getVisibility() != View.VISIBLE) {
                            startActivity(new Intent(SpaceManagerActivity.this, DownloadsScreen.class));
                        }
                        break;

                    case 106:
                        if (!doubleClicked() && findViewById(R.id.pbar_apk_count).getVisibility() != View.VISIBLE) {
                            PhoneCleaner.getInstance().spaceManagerModule.currentList = fileMedia.hmFileTypeToMediaList.get(Integer.valueOf(FileTypes.APK.ordinal()));
                            try {
                                mediasList = PhoneCleaner.getInstance().spaceManagerModule.currentList;
                            } catch (Exception e2) {
                                e2.printStackTrace();
                            }
                            showFileGridScreen();
                        }
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitialAd = new InterstitialAd(activity);
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
