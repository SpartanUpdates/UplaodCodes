package com.mbit.VideoMaker.Activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.mbit.VideoMaker.Extra.kprogresshud.KProgressHUD;
import com.mbit.VideoMaker.Model.VideoData;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.VideoPlayer.FullscreenVideoLayout;
import com.root.bridge.AndroidPluginClass;
import com.root.bridge.AppUsages;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


public class VideoPlayerActivity extends AppCompatActivity implements View.OnClickListener {
    public boolean IsFromAndroidlist;
    public int videoCurrentposition;
    public ArrayList<VideoData> AllVideolist;
    Activity activity = VideoPlayerActivity.this;
    ProgressBar pbVideoLoading;
    ImageView ivBack, ivWahtsapp, ivFb, ivInsta, ivYoutube, ivMore;
    ImageView ivPrevious, ivNext;
    KProgressHUD hud;
    //    private LinearLayout adContainer;
//    private AdView adView;
    AdRequest adRequest;
    AdView adView;
    private FullscreenVideoLayout videoLayout;
    private String VideoUrl;
    private InterstitialAd mInterstitialAd;
    private int mSeekPosition;
    private ImageView imgfullscreen;
    private LinearLayout layoutAds;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        BindView();
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoPlayerActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        VideoUrl = getIntent().getStringExtra("VideoUrl");
        videoCurrentposition = getIntent().getIntExtra("VideoPosition", 0);
        AllVideolist = (ArrayList<VideoData>) getIntent().getSerializableExtra("AllVideoList");
        IsFromAndroidlist = getIntent().getBooleanExtra("IsVideoFromAndroidList", false);
        loadVideo();
        videoLayout.setActivity(this);
        videoLayout.setShouldAutoplay(true);
        InterstitialAd();
        loadAd();
//        loadNativeBannerAd();
    }

    private void loadAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

//        adContainer = findViewById(R.id.templateContainer);
//        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
//        adContainer.addView(adView);
//        adView.loadAd();
    }

//    private void loadNativeBannerAd() {
//        nativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_nativebanner));
//        nativeBannerAd.setAdListener(new NativeAdListener() {
//            @Override
//            public void onMediaDownloaded(Ad ad) {
//
//            }
//
//            @Override
//            public void onError(Ad ad, AdError adError) {
//                findViewById(R.id.banner_container).setVisibility(View.GONE);
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
//                LinearLayout nativeBannerAdContainer = findViewById(R.id.banner_container);
//                nativeBannerAdContainer.addView(adView);
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//
//            }
//        });
//        if (Utils.checkConnectivity(activity, false)) {
//            nativeBannerAd.loadAd();
//        } else {
//            findViewById(R.id.banner_container).setVisibility(View.GONE);
//        }
//
//    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial_VideoPlayer));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                onBackPressed();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    private void VideoNext() throws IllegalStateException {
        if (!(videoCurrentposition + 1 < AllVideolist.size())) {
            activity.startActivity(new Intent(activity, MyVideoActivity.class));
            activity.finish();
            return;
        }
        videoCurrentposition++;
        try {
            videoLayout.setVideoPath(AllVideolist.get(videoCurrentposition).videoFullPath);
            videoLayout.start();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void VideoPrevious() throws IllegalStateException {

        if ((videoCurrentposition - 1 == -1)) {
            activity.startActivity(new Intent(activity, MyVideoActivity.class));
            activity.finish();
            return;
        }
        videoCurrentposition--;
        try {
            videoLayout.setVideoPath(AllVideolist.get(videoCurrentposition).videoFullPath);
            videoLayout.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void BindView() {
        layoutAds = findViewById(R.id.banner_ad_view_container);
        videoLayout = findViewById(R.id.videoview);
        imgfullscreen = videoLayout.findViewById(R.id.ivFullScreen);
        pbVideoLoading = findViewById(R.id.loading);
        ivBack = findViewById(R.id.ivIconBackFromMyCreation);
        ivWahtsapp = findViewById(R.id.ivVideoShareWhatsApp);
        ivFb = findViewById(R.id.ivVideoShareFb);
        ivInsta = findViewById(R.id.ivVideoShareInsta);
        ivYoutube = findViewById(R.id.ivVideoShareYoutube);
        ivMore = findViewById(R.id.ivVideoShareMore);
        ivPrevious = findViewById(R.id.ivPlayerPrev);
        ivNext = findViewById(R.id.ivPlayerNext);
        ivPrevious.setOnClickListener(this);
        ivNext.setOnClickListener(this);
        ivBack.setOnClickListener(this);
        ivWahtsapp.setOnClickListener(this);
        ivFb.setOnClickListener(this);
        ivInsta.setOnClickListener(this);
        ivYoutube.setOnClickListener(this);
        ivMore.setOnClickListener(this);
        imgfullscreen.setOnClickListener(this);
    }

    public void loadVideo() {
        try {
            videoLayout.setVideoURI(Uri.parse(VideoUrl));
            pbVideoLoading.setVisibility(View.GONE);
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivIconBackFromMyCreation:
                onBackPressed();
                break;
            case R.id.ivVideoShareWhatsApp:
                ShareVideoWhatsApp();
                break;
            case R.id.ivVideoShareFb:
                ShareVideoFb();
                break;
            case R.id.ivVideoShareInsta:
                ShareVideoInsta();
                break;
            case R.id.ivVideoShareYoutube:
                ShareVideoYouTube();
                break;
            case R.id.ivVideoShareMore:
                ShareVideoMore();
                break;
            case R.id.ivPlayerPrev:
                videoLayout.reset();
                VideoPrevious();
                break;
            case R.id.ivPlayerNext:
                videoLayout.reset();
                VideoNext();
                break;
            case R.id.ivFullScreen:
                if (!videoLayout.isFullscreen()) {
                    if (layoutAds != null) {
                        layoutAds.setVisibility(View.GONE);
                    }
                } else {
                    if (layoutAds != null) {
                        layoutAds.setVisibility(View.VISIBLE);
                    }
                }
                videoLayout.setFullscreen(!videoLayout.isFullscreen());
                break;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (videoLayout != null && videoLayout.isPlaying()) {
            mSeekPosition = videoLayout.getCurrentPosition();
            videoLayout.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (videoLayout != null) {
            videoLayout.seekTo(mSeekPosition);
            videoLayout.start();
        }
    }

    @Override
    protected void onDestroy() {
        this.adView.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        super.onDestroy();
    }

    private void ShareVideoWhatsApp() {
        String path = VideoUrl;
        final File file = new File(path);
        Intent whatsappIntent = new Intent(Intent.ACTION_SEND);
        whatsappIntent.setType("video/");
        whatsappIntent.setPackage("com.whatsapp");
        whatsappIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        final Uri ShareUri = FileProvider.getUriForFile(activity, String.valueOf(activity.getPackageName()) + ".provider", file);
        whatsappIntent.putExtra(Intent.EXTRA_STREAM, ShareUri);
        try {
            startActivity(whatsappIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(activity, "Whatsapp have not been installed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void ShareVideoFb() {
        String path = VideoUrl;
        final File file = new File(path);
        Intent fbIntent = new Intent(Intent.ACTION_SEND);
        fbIntent.setType("video/");
        fbIntent.setPackage("com.facebook.katana");
        fbIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        final Uri ShareUri = FileProvider.getUriForFile(activity, String.valueOf(activity.getPackageName()) + ".provider", file);
        fbIntent.putExtra(Intent.EXTRA_STREAM, ShareUri);
        try {
            startActivity(fbIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(activity, "Facebook have not been installed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void ShareVideoInsta() {
        String path = VideoUrl;
        final File file = new File(path);
        Intent instagramIntent = new Intent(Intent.ACTION_SEND);
        instagramIntent.setType("video/");
        instagramIntent.setPackage("com.instagram.android");
        instagramIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        final Uri ShareUri = FileProvider.getUriForFile(activity, String.valueOf(activity.getPackageName()) + ".provider", file);
        instagramIntent.putExtra(Intent.EXTRA_STREAM, ShareUri);
        try {
            startActivity(instagramIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(activity, "Instagram have not been installed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void ShareVideoYouTube() {
        String path = VideoUrl;
        final File file = new File(path);
        Intent youtubeIntent = new Intent(Intent.ACTION_SEND);
        youtubeIntent.setType("video/");
        youtubeIntent.setPackage("com.google.android.youtube");
        youtubeIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        final Uri ShareUri = FileProvider.getUriForFile(activity, String.valueOf(activity.getPackageName()) + ".provider", file);
        youtubeIntent.putExtra(Intent.EXTRA_STREAM, ShareUri);
        try {
            startActivity(youtubeIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(activity, "YouTube have not been installed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void ShareVideoMore() {
        String path = VideoUrl;
        final File file = new File(path);
        final Intent shareIntent = new Intent("android.intent.action.SEND");
        shareIntent.setType("video/*");
        shareIntent.putExtra("android.intent.extra.SUBJECT", activity.getString(R.string.app_name));
        shareIntent.putExtra("android.intent.extra.TEXT", String.valueOf(activity.getString(R.string.get_free)) + activity.getString(R.string.app_name) + " at here : " + "https://play.google.com/store/apps/details?id=" + activity.getPackageName());
        final Uri ShareUri = FileProvider.getUriForFile(activity, String.valueOf(activity.getPackageName()) + ".provider", file);
        shareIntent.putExtra("android.intent.extra.STREAM", ShareUri);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        activity.startActivity(Intent.createChooser(shareIntent, "Share Video"));
    }

    public void onBackPressed() {
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            try {
                hud = KProgressHUD.create(activity)
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Showing Ads")
                        .setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                    }
                }
            }, 2000);
        } else {
            if (IsFromAndroidlist) {
                finish();
            } else {
                AndroidPluginClass.RefereshVideoList(activity, AppUsages.VideoOutputFullPath);
                startActivity(new Intent(activity, HomeActivity.class));
                finish();
            }
        }
    }
}
