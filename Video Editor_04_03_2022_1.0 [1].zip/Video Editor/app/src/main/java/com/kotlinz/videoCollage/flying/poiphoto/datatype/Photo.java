package com.kotlinz.videoCollage.flying.poiphoto.datatype;

import android.os.Parcel;
import android.os.Parcelable;

public class Photo implements Parcelable {
    public static final Creator<Photo> CREATOR = new Creator<Photo>() {
        public Photo createFromParcel(Parcel parcel) {
            return new Photo(parcel);
        }

        public Photo[] newArray(int i) {
            return new Photo[i];
        }
    };
    private long dataAdded;
    private long dataModified;
    private String path;

    public int describeContents() {
        return 0;
    }

    public Photo(String str, long j, long j2) {
        this.path = str;
        this.dataAdded = j;
        this.dataModified = j2;
    }

    protected Photo(Parcel parcel) {
        this.path = parcel.readString();
        this.dataAdded = parcel.readLong();
        this.dataModified = parcel.readLong();
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String str) {
        this.path = str;
    }

    public long getDataAdded() {
        return this.dataAdded;
    }

    public void setDataAdded(long j) {
        this.dataAdded = j;
    }

    public long getDataModified() {
        return this.dataModified;
    }

    public void setDataModified(long j) {
        this.dataModified = j;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.path);
        parcel.writeLong(this.dataAdded);
        parcel.writeLong(this.dataModified);
    }
}
