package com.esc.dailyrandomfacts.util;

import android.content.Context;
import android.graphics.Typeface;
import androidx.recyclerview.widget.ItemTouchHelper;
import com.esc.dailyrandomfacts.model.Pref;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.joda.time.Period;

public class Utils {
    public static Typeface getFont(Context context, int i) {
        if (i == 100) {
            return Typeface.createFromAsset(context.getAssets(), "amatic-bold.ttf");
        }
        if (i == ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION) {
            return Typeface.createFromAsset(context.getAssets(), "NotoSans-Regular.ttf");
        }
        if (i == 300) {
            return Typeface.createFromAsset(context.getAssets(), "Helvetica.ttf");
        }
        return Typeface.DEFAULT;
    }

    public static void systemUpgrade(Context context) {
        String str = "LEVEL";
        int parseInt = Integer.parseInt(Pref.getValue(context, str, "0"));
        if (parseInt == 0) {
            Pref.setValue(context, Constants.IS_SLIDER_ON, "1");
            parseInt++;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(parseInt);
        stringBuilder.append("");
        Pref.setValue(context, str, stringBuilder.toString());
    }

    public static String convertDateToString(Date date, String str) {
        try {
            return new SimpleDateFormat(str).format(date);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static Date convertStringToDate(String str, String str2) {
        try {
            return new SimpleDateFormat(str2).parse(str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String convertDateStringToString(String str, String str2, String str3) {
        try {
            return convertDateToString(convertStringToDate(str, str2), str3);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static int getDaysFromPeriod(String str) {
        Period.parse(str).getDays();
        return 0;
    }
}
