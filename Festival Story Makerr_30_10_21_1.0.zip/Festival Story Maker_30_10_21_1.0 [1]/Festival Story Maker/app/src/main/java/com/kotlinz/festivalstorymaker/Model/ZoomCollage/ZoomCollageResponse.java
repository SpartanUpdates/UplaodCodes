package com.kotlinz.festivalstorymaker.Model.ZoomCollage;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class ZoomCollageResponse {

	@SerializedName("data")
	private ArrayList<ZoomCollageMainCategory> data;

	@SerializedName("status")
	private String status;

	public ArrayList<ZoomCollageMainCategory> getData(){
		return data;
	}

	public String getStatus(){
		return status;
	}
}