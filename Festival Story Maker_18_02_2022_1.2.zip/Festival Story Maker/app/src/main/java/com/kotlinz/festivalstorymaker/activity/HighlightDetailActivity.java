package com.kotlinz.festivalstorymaker.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.HighlightFrameListAdapter;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Model.ZoomCollage.CategoryWiseData.ZoomCollageCategoryWiseData;
import com.kotlinz.festivalstorymaker.Model.ZoomCollage.CategoryWiseData.ZoomCollageCategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.ZoomCollage.ZoomCollageMainCategory;
import com.kotlinz.festivalstorymaker.Model.ZoomCollage.ZoomCollageResponse;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HighlightDetailActivity extends BaseActivity {

    Activity activity = HighlightDetailActivity.this;

    @BindView(R.id.imgSquareSize)
    public ImageView ivSquare;
    @BindView(R.id.imgVerticalSize)
    public ImageView ivVertical;
    @BindView(R.id.imgStorySize)
    public ImageView ivStory;
    @BindView(R.id.rvZoomCollage)
    public RecyclerView rvZoomCollageMaker;

    @BindView(R.id.rl_main_Data)
    RelativeLayout rlMainData;

    @BindView(R.id.llRetry)
    LinearLayout llRetry;

    public ArrayList<com.kotlinz.festivalstorymaker.Models.h> Q = new ArrayList();

    private ProgressDialog progressDialog;
    public int Position;
    APIInterface apiInterface;

    private int ModuleId;
    public ArrayList<ZoomCollageMainCategory> ZoomCollageCategoryList;
    public ArrayList<ZoomCollageCategoryWiseData> categoryWiseZoomCollageList;
    public HighlightFrameListAdapter zoomCollageMakeFrameListAdapter;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    Gson gson = new Gson();

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(com.kotlinz.festivalstorymaker.R.layout.activity_highlight_detail);
        ButterKnife.bind(this);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        ModuleId = getIntent().getIntExtra("moduleid", 0);
        ivSquare.setImageResource(R.drawable.ic_square_press);
        PutAnalyticsEvent();
        InitProgressDialog();
        BannerAds();
        SetZoomCollageMakerMainCategoryData();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "HighlightDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(com.kotlinz.festivalstorymaker.R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(com.kotlinz.festivalstorymaker.R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @OnClick(R.id.llRetry)
    public void RetryData() {
        if (Utils.checkConnectivity(activity, false)) {
            rlMainData.setVisibility(View.VISIBLE);
            llRetry.setVisibility(View.GONE);
            GetCollageCategory(ModuleId);
        } else {
            Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
        }
    }


    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llSquareSize:
                ivSquare.setImageResource(R.drawable.ic_square_press);
                ivVertical.setImageResource(R.drawable.ic_vertical_unpress);
                ivStory.setImageResource(R.drawable.ic_story_unpress);
                SetZoomCollageMethod(String.valueOf(ZoomCollageCategoryList.get(0).getCatId()), String.valueOf(ZoomCollageCategoryList.get(0).getChildCategory().get(0).getChildCatId()));
                break;
            case R.id.llVerticalSize:
                ivVertical.setImageResource(R.drawable.ic_vertical_press);
                ivSquare.setImageResource(R.drawable.ic_square_unpress);
                ivStory.setImageResource(R.drawable.ic_story_unpress);
                SetZoomCollageMethod(String.valueOf(ZoomCollageCategoryList.get(2).getCatId()), String.valueOf(ZoomCollageCategoryList.get(1).getChildCategory().get(0).getChildCatId()));
                break;
            case R.id.llStorySize:
                ivStory.setImageResource(R.drawable.ic_story_press);
                ivSquare.setImageResource(R.drawable.ic_square_unpress);
                ivVertical.setImageResource(R.drawable.ic_vertical_unpress);
                SetZoomCollageMethod(String.valueOf(ZoomCollageCategoryList.get(1).getCatId()), String.valueOf(ZoomCollageCategoryList.get(2).getChildCategory().get(0).getChildCatId()));
                break;
            case R.id.iv_my_creation:
                Intent intent = new Intent(this, MyPostActivity.class);
                startActivityForResult(intent, 724);
                return;
            default:
                return;
        }
    }

    private void SetZoomCollageMakerMainCategoryData() {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollage).equalsIgnoreCase("")) {
                GetCollageCategory(ModuleId);

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.ZoomCollageResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetCollageCategory(ModuleId);

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollage).equalsIgnoreCase("")) {

                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollage));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollage).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollage));
            }
        }
    }

    private void GetCollageCategory(int ModuleId) {
        progressDialog.show();
        Call<ZoomCollageResponse> call = apiInterface.getZoomCollageModuleWiseCategory(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<ZoomCollageResponse>() {
            @Override
            public void onResponse(Call<ZoomCollageResponse> call, Response<ZoomCollageResponse> response) {
                if (response.isSuccessful()) {
                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.ZoomCollage);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.ZoomCollageResponseTime);
                    SetOfflineDataMainCategory(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<ZoomCollageResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollage).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineDataMainCategory(String response) {
        ZoomCollageResponse zoomCollageResponse = gson.fromJson(response, ZoomCollageResponse.class);
        ZoomCollageCategoryList = zoomCollageResponse.getData();
        SetCollageThemeData(0, ZoomCollageCategoryList);
        progressDialog.dismiss();
    }

    public void SetCollageThemeData(int Position, ArrayList<ZoomCollageMainCategory> collageCategoryList) {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + collageCategoryList.get(Position).getCatId() + collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                GetCollageCategoryDataByID(String.valueOf(collageCategoryList.get(Position).getCatId()), String.valueOf(collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.ZoomcollageThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetCollageCategoryDataByID(String.valueOf(collageCategoryList.get(Position).getCatId()), String.valueOf(collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + collageCategoryList.get(Position).getCatId() + collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {

                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + collageCategoryList.get(Position).getCatId() + collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + collageCategoryList.get(Position).getCatId() + collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + collageCategoryList.get(Position).getCatId() + collageCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));
            }
        }
    }

    public void GetCollageCategoryDataByID(String ParentCatId, String ChildCatId) {
        progressDialog.show();
        Call<ZoomCollageCategoryWiseResponse> call = apiInterface.getZoomCollageCategoryWiseData(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId), "0", ParentCatId, ChildCatId);
        call.enqueue(new Callback<ZoomCollageCategoryWiseResponse>() {
            @Override
            public void onResponse(Call<ZoomCollageCategoryWiseResponse> call, Response<ZoomCollageCategoryWiseResponse> response) {
                if (response.isSuccessful()) {
                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.ZoomCollageTheme + ParentCatId + ChildCatId);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.ZoomcollageThemeResponseTime);
                    SetOfflineThemeData(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<ZoomCollageCategoryWiseResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + ParentCatId + ChildCatId).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineThemeData(String response) {
        ZoomCollageCategoryWiseResponse zoomCollageCategoryWiseResponse = gson.fromJson(response, ZoomCollageCategoryWiseResponse.class);
        categoryWiseZoomCollageList = zoomCollageCategoryWiseResponse.getData();
        zoomCollageMakeFrameListAdapter = new HighlightFrameListAdapter(activity, categoryWiseZoomCollageList);
        rvZoomCollageMaker.setLayoutManager(new GridLayoutManager(activity, 3));
        rvZoomCollageMaker.setAdapter(zoomCollageMakeFrameListAdapter);
        progressDialog.dismiss();
    }

    private void SetZoomCollageMethod(String ParentCatId, String ChildCatId) {
        if (com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + ParentCatId + ChildCatId).equalsIgnoreCase("")) {
                GetCollageCategoryDataByID(ParentCatId, ChildCatId);

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.ZoomcollageThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetCollageCategoryDataByID(ParentCatId, ChildCatId);

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + ParentCatId + ChildCatId).equalsIgnoreCase("")) {

                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + ParentCatId + ChildCatId));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + ParentCatId + ChildCatId).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.ZoomCollageTheme + ParentCatId + ChildCatId));
            }
        }
    }



    public void OpenGallery() {
        final ImagePicker.ImagePickerWithActivity a = new ImagePicker.ImagePickerWithActivity(this);
        final ImagePickerConfig a2 = a.config;
        a2.folderMode = true;
        a2.theme = 10;
        a2.showCamera = false;
        a.start(0);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == 0 && resultCode == -1) {
            ArrayList arrayList = new ArrayList();
            List c = ImagePicker.getImages(intent);
            if (c.size() == Constant.NoofImage) {
                for (int i3 = 0; i3 < c.size(); i3++) {
                    arrayList.add(((Image) c.get(i3)).getPath());
                }
                Intent intent1 = new Intent(activity, HighlightDetailsDetailActivity.class);
                intent1.putStringArrayListExtra("list", arrayList);
                intent1.putExtra("moduleid", ModuleId);
                intent1.putExtra("FilePath", Constant.TextFilePath);
                startActivity(intent1);
                return;
            }
            Toast.makeText(activity, "Please select " + Constant.NoofImage + "Images", Toast.LENGTH_SHORT).show();
        }
    }


    @OnClick(R.id.iv_my_creation)
    public void MyCreation() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, MyPostActivity.class).putExtra("IsFrom","Zoom Collage"));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 26;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(activity, MyPostActivity.class).putExtra("IsFrom","Zoom Collage"));
                finish();
            }
        }

    }

    @OnClick(R.id.iv_back)
    public void Back(View view) {
        onBackPressed();
    }


    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, DashBordActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 25;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                startActivity(new Intent(activity, DashBordActivity.class));
                finish();
            }
        }
    }
}